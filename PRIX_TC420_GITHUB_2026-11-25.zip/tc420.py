# Ensaio TCP direto legado: este script abre rede ao executar; não é o ponto de entrada gráfico main.py.
import socket

IP_BALANCA = "192.0.2.21"
PORTA = 9800

print("=== PRIX TC420 ===")
print(f"Conectando em {IP_BALANCA}:{PORTA}...")

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.settimeout (5)  # Define um tempo limite de 5 segundos para a conexão

try:
    sock.connect((IP_BALANCA, PORTA))
    print("TC420 CONECTADA!")
    print("Aguardando peso...\n")

    sock.settimeout(None)

    while True:
        dados = sock.recv(1024)

        if not dados:
            print("A TC420 encerrou a conexão.")
            break

        # Converte os bytes recebidos para ASCII
        texto = dados.decode("ascii", errors="ignore")

        # O peso está entre as posições 3 e 9 do pacote
        campo_peso = texto[3:10].strip()

        if campo_peso.isdigit():
            peso = int(campo_peso) / 1000
            print(f"Peso: {peso:.3f} kg")

except ConnectionRefusedError:
    print("A TC420 recusou a conexão.")

except socket.timeout:
    print("Tempo limite ao tentar conectar.")

except KeyboardInterrupt:
    print("\nLeitura encerrada.")

finally:
    sock.close()
"""Gera uma cópia de publicação por lista de permissões, sem copiar .git.

Não publica, não cria commits e não modifica o código operacional original.
Recusa sobrescrever um destino existente e não percorre diretórios fora
da lista de origem. O manifesto fica ao lado da cópia, fora do repositório.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys


RAIZ = Path(__file__).resolve().parents[1]
ARQUIVOS_RAIZ = (
    '.gitignore', 'AGENTS.md', 'README.md', 'requirements.txt',
    'requirements-dev.txt', 'main.py', 'mensagens_seguras.py',
    'tc420.py', 'teste_approval.py',
)
PASTAS = {
    'config': {'.py'}, 'tc420': {'.py'}, 'rede': {'.py'},
    'interface': {'.py'}, 'prototipos': {'.py'},
    'tests': {'.py', '.txt', '.ps1'},
    'assets': {'.png', '.ico'},
    'empacotamento': {'.py', '.ps1', '.cmd', '.spec', '.txt', '.ico'},
    'documentação': {'.md', '.json'}, 'ferramentas': {'.py'},
}
EXTENSOES_TEXTO = {'.py', '.md', '.txt', '.ps1', '.cmd', '.spec', '.json'}
OMITIR_DOCUMENTOS = {'PLANEJAMENTO_EXTENSAO_TCC.md'}
PADROES_SECRETOS = (
    r'gh[pousr]_[A-Za-z0-9]{30,}', r'github_pat_[A-Za-z0-9_]{30,}',
    r'AKIA[A-Z0-9]{16}', r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
)


def candidatos():
    for nome in ARQUIVOS_RAIZ:
        yield RAIZ / nome
    for nome, extensoes in PASTAS.items():
        for arquivo in sorted((RAIZ / nome).rglob('*')):
            if not arquivo.is_file() or arquivo.is_symlink():
                continue
            if '__pycache__' in arquivo.parts or arquivo.suffix.lower() not in extensoes:
                continue
            if nome == 'documentação' and (
                arquivo.name in OMITIR_DOCUMENTOS or
                arquivo.stem.endswith(('_STATUS', '_PROCESSO'))
            ):
                continue
            yield arquivo


def sanitizar(texto):
    # Substitui somente a rede operacional identificada, conservando loopback
    # e os endereços sintéticos usados para testar outras situações.
    texto = re.sub(r'\b10\.104\.101\.(\d{1,3})\b', r'192.0.2.\1', texto)
    texto = re.sub(r'(?i)[A-Z]:[\\/]+Users[\\/]+(?:pablo|Ideal Agro)[\\/]+',
                   'C:/Users/USUARIO/', texto)
    texto = re.sub(r'\bNT-VV-\d+\b', 'PC_CLIENTE', texto)
    texto = re.sub(r'\bDESKTOP-[A-Z0-9]+\b', 'PC_PRINCIPAL', texto)
    return texto


def validar_texto(nome, texto):
    for padrao in PADROES_SECRETOS:
        if re.search(padrao, texto):
            raise ValueError(f'Possível segredo: {nome}; conteúdo não exibido')
    if nome.endswith('.py'):
        ast.parse(texto, filename=nome)


def preparar(destino, data):
    destino = destino.resolve()
    limite = (RAIZ / 'publicacao_github').resolve()
    if not destino.is_relative_to(limite) or destino == limite:
        raise ValueError('O destino deve ser uma subpasta de publicacao_github')
    if destino.exists():
        raise FileExistsError('Destino já existe; escolha outro nome para preservar a cópia')
    registros = []
    # Prepara e valida os bytes antes de criar a árvore de publicação.
    conteudos = {}
    for origem in candidatos():
        if origem.is_symlink() or not origem.resolve().is_relative_to(RAIZ):
            raise ValueError('Origem não permitida')
        nome = origem.relative_to(RAIZ).as_posix()
        original = origem.read_bytes()
        dados = original
        if origem.suffix.lower() in EXTENSOES_TEXTO or origem.name == '.gitignore':
            texto = sanitizar(original.decode('utf-8-sig'))
            validar_texto(nome, texto)
            dados = texto.encode('utf-8')
        conteudos[nome] = dados

    # O índice público destaca os contratos vigentes; o histórico completo
    # permanece disponível como registro evolutivo, sem apagar marcos antigos.
    conteudos['documentação/README.md'] = (
        '# Documentação técnica PRIX TC420\n\n'
        'Consulte o [README principal](../README.md) para instalação e limites atuais.\n'
        'Esta é uma cópia de publicação, com dados operacionais substituídos por exemplos.\n\n'
        '- [Arquitetura](ARQUITETURA.md) e [módulos](MODULOS.md).\n'
        '- [Protocolos](PROTOCOLOS.md) e [API](API.md).\n'
        '- [Administrador](ADMINISTRADOR_OPERACIONAL.md).\n'
        '- [TCP local](TCP_LOCAL.md).\n'
        '- [Sucessão recorrente](SUCESSAO_RECORRENTE_AB.md).\n'
        '- [Supervisão](SUPERVISAO_PRINCIPAL.md).\n'
        '- [Executável](EXECUTAVEL_WINDOWS.md) e [firewall](FIREWALL_WINDOWS.md).\n'
        '- [Validação](VALIDACAO.md) e [ensaio de uma hora](RESULTADO_2B3_UMA_HORA.md).\n'
        '- [Publicação](PUBLICACAO_GITHUB.md) e [histórico](HISTORICO.md).\n\n'
        'Documentos de investigação e entradas antigas registram o estado de sua época;\n'
        'não substituem os contratos posteriores. TCC, conversas e capturas de trabalho\n'
        'ficam fora desta cópia. Nenhum resultado anterior foi reexecutado pela simples exportação.\n'
    ).encode('utf-8')

    ajustes_links = 0
    # Referências a materiais privados continuam como texto, sem links quebrados.
    # Nenhum conteúdo desses materiais é lido ou copiado.
    for nome, dados in list(conteudos.items()):
        if not nome.endswith('.md'):
            continue
        pasta = Path(nome).parent
        def link(match):
            nonlocal ajustes_links
            titulo, alvo = match.groups()
            if '://' in alvo or alvo.startswith('#'):
                return match.group(0)
            alvo = alvo.strip('<>').split('#')[0]
            absoluto = (destino / pasta / alvo).resolve()
            if absoluto.is_relative_to(destino) and absoluto.relative_to(destino).as_posix() in conteudos:
                return match.group(0)
            ajustes_links += 1
            return titulo + ' (material local não incluído)'
        conteudos[nome] = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', link, dados.decode('utf-8')).encode('utf-8')

    destino.mkdir(parents=True)
    for nome, dados in conteudos.items():
        arquivo = destino / nome
        arquivo.parent.mkdir(parents=True, exist_ok=True)
        arquivo.write_bytes(dados)
        original = (RAIZ / nome).read_bytes() if (RAIZ / nome).is_file() else b''
        registros.append({
            'arquivo': nome, 'bytes': len(dados),
            'sha256': hashlib.sha256(dados).hexdigest(),
            'origem_sha256': hashlib.sha256(original).hexdigest(),
            'ajustado_na_copia': dados != original,
        })
    manifesto = {
        'data': data, 'diretorio': destino.relative_to(RAIZ).as_posix(),
        'arquivos': len(registros), 'bytes': sum(r['bytes'] for r in registros),
        'por_pasta': dict(Counter(Path(r['arquivo']).parts[0] for r in registros)),
        'links_locais_convertidos_em_texto': ajustes_links,
        'historico_git_incluido': False, 'tcc_incluido': False,
        'publicado': False, 'registros': registros,
    }
    (destino.parent / (destino.name + '_MANIFESTO.json')).write_text(
        json.dumps(manifesto, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in manifesto.items() if k != 'registros'}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destino', required=True, type=Path)
    parser.add_argument('--data', required=True, help='Data editorial ISO informada pelo responsável')
    args = parser.parse_args()
    preparar(args.destino, args.data)

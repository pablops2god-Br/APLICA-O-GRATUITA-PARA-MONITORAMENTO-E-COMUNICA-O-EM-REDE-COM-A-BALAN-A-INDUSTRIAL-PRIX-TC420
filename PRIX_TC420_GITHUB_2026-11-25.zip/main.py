# Entrada da aplicação: montagem dos registros, escolha do papel e ligação com as janelas.
"""
Orquestrador Principal do Sistema PRIX TC420
============================================

Este módulo é o ponto de entrada e coordenador geral da aplicação desktop.
Ele implementa a máquina de estados para decisão dinâmica de papéis:

1. DESCOBERTA INICIAL:
   - Procura por um servidor TC420 ativo na rede local via broadcast UDP (porta 42101).

2. MODO CLIENTE:
   - Se encontrar um servidor ativo, conecta-se como CLIENTE.
   - Baixa a configuração metrológica via comando TCP 'CONFIG'.
   - Registra o nome do computador na fila de prioridade de sucessão ('REGISTER').
   - Inicia o streaming contínuo das pesagens em tempo real ('SUBSCRIBE').
   - Mantém rotina de tolerância a falhas para promover-se a PRINCIPAL se o líder cair.

3. MODO PRINCIPAL:
   - Se não houver servidor na rede, tenta o login automático com credenciais do cofre seguro.
   - Conecta-se à balança física via HTTPS (porta 443), lê as faixas W1.1 e W1.2 e inicia o servidor TCP local (porta 42100).
   - Se o login automático não estiver disponível, abre a tela de conexão manual ('JanelaConexao').

4. OBSERVAÇÃO DE REBAIXAMENTO:
   - Se o nó Principal perder comunicação prolongada com a balança física (> 25s), ele renuncia ao posto
     e busca um novo servidor na rede. O leitor recuperado começa sem candidatura;
     após REGISTER, amostra válida de outro PRINCIPAL e prova anterior, volta à fila.
"""

import threading

_proxima_configuracao_administrativa = None

from config.configuracao import carregar_configuracao, carregar_senha
from interface.conexao import JanelaConexao
from interface.janela import JanelaTC420
from rede.buscarservidor import buscar_servidor
from rede.lerdadosserver import LeitorDadosServidor
from rede.servidor import (
    ContextoCicloServidor,
    RegistroTentativasAplicacao,
    definir_configuracao,
    iniciar_servidor,
    obter_dados_atuais,
)
from tc420.web import WebTC420
from rede.promocao_manual import aguardar_prontidao, interromper_tentativa, operacao_vigente


# Só retorna os dados de login se a opção de salvar estiver ativa e a senha existir no keyring.
def obter_credenciais_salvas(*, contexto_arquivos=None):
    """
    Recupera as credenciais de autenticação da balança armazenadas de forma segura.
    
    Os parâmetros de rede (IP e usuário) são lidos do arquivo 'configuracao.json'.
    A senha administrativa é recuperada do cofre seguro do sistema operacional
    (Windows Credential Manager) através da biblioteca 'keyring'.
    """
    configuracao_salva = carregar_configuracao(**({"contexto_arquivos": contexto_arquivos}
                                                if contexto_arquivos is not None else {}))
    if configuracao_salva is None:
        return None
    if not configuracao_salva.get("salvar_login", False):
        return None
    ip = configuracao_salva.get("ip")
    usuario = configuracao_salva.get("usuario")
    if not ip or not usuario:
        return None
    senha = carregar_senha(usuario)
    if not senha:
        return None
    return {"ip": ip, "usuario": usuario, "senha": senha}


# Monta o leitor TCP e conecta seus callbacks de peso, frescor e candidatura ao monitor.
def iniciar_como_cliente(servidor, registro_tentativas=None, infraestrutura_cliente=None, *, vinculo_http=False, contexto_arquivos=None, saida_aplicacao=None):
    """
    Inicializa a aplicação no papel de NÓ CLIENTE.
    
    Conecta-se ao computador Principal, recebe as faixas de pesagem e estabelece
    o streaming de dados em tempo real. Configura os mecanismos de tolerância a falhas
    e promoção automática/manual para assumir a balança se o Principal falhar.
    """
    from interface.saida_aplicacao import SaidaAplicacao
    saida = (saida_aplicacao or getattr(infraestrutura_cliente, 'saida_aplicacao', None)
             or SaidaAplicacao())
    saida.configurar(infraestrutura_cliente, registro_tentativas)
    from rede.entradas_http import criar_validador_entrada
    validar_infraestrutura = criar_validador_entrada(vinculo_http)
    print(f"Servidor encontrado: {servidor}")
    print("Iniciando como CLIENTE.")

    with saida.trabalho():
        leitor = LeitorDadosServidor(
            ip_servidor=servidor,
            **({"infraestrutura_cliente": infraestrutura_cliente} if infraestrutura_cliente is not None else {}),
        )
        if infraestrutura_cliente is not None:
            leitor.infraestrutura_cliente = infraestrutura_cliente

        # Reconfirma a ausência de outro principal, autentica, lê as faixas e inicia um ciclo servidor.
        def promover_para_principal(ip, usuario, senha):
            """
            Callback de promoção: Transforma este nó Cliente em novo nó PRINCIPAL.
            
            Disparado quando o Cliente detecta a queda do líder anterior, vence o prazo
            de candidatura escalonada (posição * 30s) e recebe as credenciais de acesso.
            Autentica na balança física via HTTPS e inicia o servidor TCP local.
            """
            with saida.trabalho():
                contexto = ContextoCicloServidor()
                if saida is not None:
                    saida.acompanhar_contexto(contexto)
                tentativa_id = None
                start_solicitado = False
                categoria_falha = "falha_partida"

                # Registra a falha anterior à partida para que a saída não espere uma execução inexistente.
                def registrar_falha_sem_execucao():
                    contexto.registrar_falha("falha_antes_reserva")
                    if registro_tentativas is not None and tentativa_id is not None:
                        try:
                            registro_tentativas.registrar_falha_partida(
                                tentativa_id, categoria_falha,
                                execucao_nao_iniciada=True,
                            )
                        except Exception:
                            print("MAIN: falha ao registrar erro de partida da promoção.")

                print("")
                print("=== TENTATIVA DE PROMOÇÃO ===")
                try:
                    if registro_tentativas is not None:
                        tentativa_id = registro_tentativas.admitir(contexto)
                        if tentativa_id is None:
                            print("MAIN: admissão de promoção recusada.")
                            return None
                        if not registro_tentativas.marcar_iniciando(tentativa_id):
                            raise RuntimeError("MAIN: registro não autorizou a promoção.")
                    servidor_existente = buscar_servidor(**({"recursos_cliente": leitor.recursos_cliente}
                                                           if infraestrutura_cliente is not None else {}))
                    if servidor_existente:
                        print(
                            "Promoção cancelada: "
                            f"servidor encontrado em {servidor_existente}."
                        )
                        registrar_falha_sem_execucao()
                        return None

                    print("Nenhum servidor encontrado.")
                    print("Tentando login na TC420...")
                    infraestrutura = validar_infraestrutura(infraestrutura_cliente)
                    recursos_origem = leitor.recursos_cliente
                    web = WebTC420(ip, politica_http=infraestrutura.criar_politica_http())
                    contexto_http = infraestrutura.preparar_http_promocao(recursos_origem)
                    infraestrutura.executar_login_promocao(
                        recursos_origem, web, usuario, senha,
                        contexto_http=contexto_http,
                    )
                    print("Login realizado com sucesso.")

                    configuracao_nova = infraestrutura.executar_approval(contexto_http, web)
                    if not operacao_vigente(saida):
                        registrar_falha_sem_execucao()
                        return None
                    if buscar_servidor(**({"recursos_cliente": leitor.recursos_cliente}
                                          if infraestrutura_cliente is not None else {})):
                        print('Promoção cancelada: outro PRINCIPAL identificado na revalidação.')
                        registrar_falha_sem_execucao()
                        return None
                    definir_configuracao(configuracao_nova)
                    print("Configuração da TC420 obtida.")

                    # Registra a entrada efetiva da thread antes de entregar a sessão autenticada ao servidor.
                    def executar_servidor():
                        if registro_tentativas is not None:
                            if not registro_tentativas.registrar_entrada_execucao(tentativa_id):
                                return
                        iniciar_servidor(web, contexto_ciclo=contexto)

                    categoria_falha = "falha_criacao_thread"
                    thread_servidor = threading.Thread(
                        target=executar_servidor,
                        daemon=True,
                    )
                    # A partir daqui, exceção de start não comprova ausência de execução.
                    start_solicitado = True
                    saida.iniciar_servidor_thread(thread_servidor, contexto, registro_tentativas, tentativa_id)
                    if registro_tentativas is not None:
                        if not registro_tentativas.marcar_iniciada(tentativa_id):
                            raise RuntimeError("MAIN: registro não confirmou a promoção.")
                    print("Partida solicitada; aguardando prontidão TCP/UDP e leitura TC420.")
                    if not aguardar_prontidao(contexto, saida):
                        interromper_tentativa(contexto)
                        print('Promoção não concluída: prontidão do serviço não comprovada.')
                        return None
                    leitor.parar()

                    return {
                        "web": web,
                        "configuracao": configuracao_nova,
                        "fonte_dados": obter_dados_atuais,
                        "obter_saude_principal": lambda: __import__(
                            "rede.servidor", fromlist=["obter_saude_tc420"]
                        ).obter_saude_tc420(),
                        "contexto_ciclo": contexto,
                    }
                except Exception as erro:
                    if not start_solicitado:
                        registrar_falha_sem_execucao()
                    else:
                        interromper_tentativa(contexto)
                    # Erros HTTP podem incluir a URL com credenciais.
                    print(f"Falha na promoção: {type(erro).__name__}")
                    leitor.registrar_falha_recuperacao()
                    return None

        # Usa as credenciais salvas na mesma rotina de promoção utilizada pelo caminho manual.
        def tentar_promocao_automatica():
            credenciais = obter_credenciais_salvas(**({"contexto_arquivos": contexto_arquivos}
                                                     if contexto_arquivos is not None else {}))
            if credenciais is None:
                return False
            print("")
            print("Credenciais salvas disponíveis.")
            print("Tentando promoção automática...")
            return promover_para_principal(
                credenciais["ip"],
                credenciais["usuario"],
                credenciais["senha"],
            )

        saida.acompanhar_leitor(leitor)
        leitor.iniciar()

        configuracao = leitor.aguardar_configuracao(timeout=5)
        if configuracao is None:
            print(
                "Não foi possível receber a configuração "
                "da TC420 pelo servidor."
            )
        elif isinstance(configuracao, dict):
            print("Configuração recebida do servidor:")
            for nome, dados in configuracao.items():
                print(nome)
                print(f"  divisao: {dados['divisao']}")
                print(f"  min: {dados['min']}")
                print(f"  max: {dados['max']}")

    if saida.parada_solicitada:
        return

    monitor = JanelaTC420(
        web=None,
        configuracao=configuracao,
        fonte_dados=leitor.obter_dados_atuais,
        comunicacao_atual=getattr(leitor, "comunicacao_esta_atual", None),
        candidatura_liberada=leitor.candidatura_esta_liberada,
        estado_candidatura=leitor.obter_estado_candidatura,
        ao_promover=promover_para_principal,
        ao_promover_automaticamente=tentar_promocao_automatica,
        ao_reconfigurar=getattr(saida, "ao_reconfigurar", None),
        ao_fechar=saida.vincular('monitor_cliente', leitor.parar),
    )
    monitor.saida_aplicacao = saida
    if hasattr(monitor, 'root') and hasattr(monitor, 'concluir_fechamento'):
        saida.conectar_interface(monitor.ao_fechar, getattr(monitor, 'agendar_saida', monitor.root.after), monitor.concluir_fechamento,
                                 getattr(monitor, 'informar_encerramento_pendente', None))
    if infraestrutura_cliente is not None:
        monitor.infraestrutura_cliente = infraestrutura_cliente

    try:
        monitor.executar()

    finally:
        leitor.parar()


# Retorna False na falha, dados do principal no sucesso ou o servidor encontrado para iniciar cliente.
def tentar_login_automatico(registro_tentativas=None, infraestrutura_cliente=None, *, vinculo_http=False, contexto_arquivos=None):
    """
    Tenta iniciar automaticamente como nó PRINCIPAL utilizando credenciais salvas.
    
    Verifica se há credenciais no cofre do Windows, checa novamente se não surgiu
    nenhum servidor na rede, realiza o login HTTPS na TC420 e inicia o servidor local.
    """
    from contextlib import nullcontext
    saida = getattr(infraestrutura_cliente, 'saida_aplicacao', None)
    with nullcontext() if saida is None else saida.trabalho():
        print("")
        print("=== LOGIN AUTOMÁTICO ===")
        configuracao_salva = carregar_configuracao(**({"contexto_arquivos": contexto_arquivos}
                                                    if contexto_arquivos is not None else {}))
        if configuracao_salva is None:
            print("Nenhuma configuração salva.")
            return False
        if not configuracao_salva.get("salvar_login", False):
            print("Login automático desativado.")
            return False

        ip = configuracao_salva.get("ip")
        usuario = configuracao_salva.get("usuario")
        if not ip or not usuario:
            print("Configuração salva incompleta.")
            return False
        senha = carregar_senha(usuario)
        if not senha:
            print("Senha salva não encontrada.")
            return False

        print("Verificando novamente se existe um servidor TC420...")
        servidor = buscar_servidor(**({"infraestrutura_cliente": infraestrutura_cliente}
                                     if infraestrutura_cliente is not None else {}))
        if servidor:
            print(f"Servidor encontrado: {servidor}")
            print("Login automático cancelado.")
            return {"modo": "cliente", "servidor": servidor}

        print("Nenhum servidor encontrado.")
        print("Tentando login automático na TC420...")
        try:
            from rede.entradas_http import criar_validador_entrada
            infraestrutura = criar_validador_entrada(vinculo_http)(infraestrutura_cliente)
            web = WebTC420(ip, politica_http=infraestrutura.criar_politica_http())
            contexto_http = infraestrutura.preparar_http_inicial()
            infraestrutura.executar_login_automatico(web, usuario, senha, contexto_http=contexto_http)
            print("Login automático realizado com sucesso.")
            configuracao_tc420 = infraestrutura.executar_approval(contexto_http, web)
            definir_configuracao(configuracao_tc420)
            contexto = ContextoCicloServidor()
            if saida is not None:
                saida.acompanhar_contexto(contexto)
            tentativa_id = None
            if registro_tentativas is not None:
                tentativa_id = registro_tentativas.admitir(contexto)
                if tentativa_id is None:
                    raise RuntimeError("MAIN: admissão de tentativa recusada.")
                if not registro_tentativas.marcar_iniciando(tentativa_id):
                    raise RuntimeError("MAIN: registro não autorizou a partida.")
            servidor_encerrado = threading.Event()

            # Registra a entrada efetiva da thread antes de entregar a sessão autenticada ao servidor.
            def executar_servidor():
                try:
                    if registro_tentativas is not None:
                        if not registro_tentativas.registrar_entrada_execucao(tentativa_id):
                            return
                    iniciar_servidor(web, contexto_ciclo=contexto)
                finally:
                    # Retorno da rotina, inclusive por erro, não comprova fim dos trabalhadores.
                    print("")
                    print("MAIN: servidor PRINCIPAL foi encerrado.")
                    servidor_encerrado.set()

            try:
                thread_servidor = threading.Thread(
                    target=executar_servidor,
                    daemon=True,
                )
            except Exception:
                contexto.registrar_falha("falha_antes_reserva")
                if registro_tentativas is not None:
                    try:
                        registro_tentativas.registrar_falha_partida(
                            tentativa_id, "falha_criacao_thread",
                            execucao_nao_iniciada=True,
                        )
                    except Exception:
                        print("MAIN: falha ao registrar erro de criação da thread.")
                raise
            # Uma exceção de start não prova ausência de execução.
            if saida is None:
                thread_servidor.start()
            else:
                saida.iniciar_servidor_thread(thread_servidor, contexto, registro_tentativas, tentativa_id)
            if registro_tentativas is not None:
                if not registro_tentativas.marcar_iniciada(tentativa_id):
                    raise RuntimeError("MAIN: registro não confirmou a partida.")
            print("Servidor TC420 iniciado.")
            return {
                "modo": "principal",
                "web": web,
                "configuracao": configuracao_tc420,
                "servidor_encerrado": servidor_encerrado,
                "contexto_ciclo": contexto,
            }
        except Exception as erro:
            # Erros HTTP podem incluir informações sensíveis na URL.
            print(f"Falha no login automático: {type(erro).__name__}")
            return False


# Cria os donos dos recursos uma vez e escolhe entre cliente, principal automático e conexão manual.
def iniciar(forcar_configuracao=False):
    """
    Ponto de entrada principal da orquestração.
    
    1. Se forcar_configuracao=True (ex: flag --reconfigurar), abre direto a tela de conexão;
    2. Procura servidor na rede via broadcast UDP;
    3. Se encontrar servidor -> inicia como CLIENTE;
    4. Se não encontrar -> tenta login automático com a balança para virar PRINCIPAL;
    5. Se falhar -> abre a tela de conexão (JanelaConexao) para entrada manual do operador.
    """
    from interface.saida_aplicacao import SaidaAplicacao
    saida_aplicacao = SaidaAplicacao()
    from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
    from rede.entradas_http import VinculoEntradasHttp
    from config.arquivos import ContextoArquivosConfiguracao

    infraestrutura_cliente = InfraestruturaRegistrosCliente()
    vinculo_http = VinculoEntradasHttp(infraestrutura_cliente)
    contexto_arquivos = ContextoArquivosConfiguracao(infraestrutura_cliente)
    registro_tentativas = RegistroTentativasAplicacao()
    saida_aplicacao.configurar(infraestrutura_cliente, registro_tentativas)

    # Abre outro processo com --reconfigurar após a conclusão da saída coordenada.
    def reabrir_na_tela_conexao():
        from interface.administrador import controle_atual
        if controle_atual() is not None:
            # B2 já concluiu: o mainloop retornará e criará novos donos no mesmo
            # processo, preservando somente a autorização desta reconfiguração.
            global _proxima_configuracao_administrativa
            _proxima_configuracao_administrativa = {
                'restaurar': getattr(saida_aplicacao, 'restaurar_administrador', False)}
            return
        import subprocess
        import sys
        from pathlib import Path
        raiz = Path(__file__).resolve().parent
        comando = ([sys.executable, "--reconfigurar"] if getattr(sys, "frozen", False)
                   else [sys.executable, "-B", str(raiz / "main.py"), "--reconfigurar"])
        if getattr(saida_aplicacao, 'restaurar_administrador', False):
            comando.append('--restaurar-admin')
        subprocess.Popen(comando, cwd=str(raiz))
    saida_aplicacao.ao_reconfigurar = reabrir_na_tela_conexao

    # Repassa ao cliente os mesmos registros e vínculos criados para esta execução.
    def iniciar_cliente_da_execucao(servidor):
        return vinculo_http.vincular(iniciar_como_cliente)(
            servidor, registro_tentativas=registro_tentativas,
            infraestrutura_cliente=infraestrutura_cliente,
            contexto_arquivos=contexto_arquivos,
            saida_aplicacao=saida_aplicacao,
        )

    if forcar_configuracao:
        print("=== PRIX TC420 — RECONFIGURAÇÃO ===")
        app = vinculo_http.vincular(JanelaConexao)(
            ao_encontrar_servidor=iniciar_cliente_da_execucao,
            registro_tentativas=registro_tentativas,
            infraestrutura_cliente=infraestrutura_cliente,
            contexto_arquivos=contexto_arquivos,
            saida_aplicacao=saida_aplicacao,
        )
        app.infraestrutura_cliente = infraestrutura_cliente
        app.executar()
        return

    print("=== PRIX TC420 ===")
    print("Procurando servidor TC420...")

    servidor = buscar_servidor(infraestrutura_cliente=infraestrutura_cliente)

    if servidor:
        iniciar_cliente_da_execucao(servidor)

        return

    print("Nenhum servidor encontrado.")
    resultado = vinculo_http.vincular(tentar_login_automatico)(registro_tentativas=registro_tentativas,
                                      infraestrutura_cliente=infraestrutura_cliente,
                                      contexto_arquivos=contexto_arquivos)
    if resultado:
        if resultado["modo"] == "cliente":
            iniciar_cliente_da_execucao(resultado["servidor"])
            return
        if resultado["modo"] == "principal":
            print("Iniciando como PRINCIPAL.")
            servidor_encerrado = resultado["servidor_encerrado"]
            supervisao = None
            try:
                monitor = JanelaTC420(
                    web=resultado["web"],
                    configuracao=resultado["configuracao"],
                    fonte_dados=obter_dados_atuais,
                    servidor_encerrado=servidor_encerrado.is_set,
                    ao_reconfigurar=reabrir_na_tela_conexao,
                    ao_fechar=saida_aplicacao.vincular('monitor_principal_automatico'),
                )
                monitor.saida_aplicacao = saida_aplicacao
                if hasattr(monitor, 'root') and hasattr(monitor, 'concluir_fechamento'):
                    saida_aplicacao.conectar_interface(
                        monitor.ao_fechar, getattr(monitor, 'agendar_saida', monitor.root.after), monitor.concluir_fechamento,
                        getattr(monitor, 'informar_encerramento_pendente', None))
                monitor.infraestrutura_cliente = infraestrutura_cliente
                supervisao = monitor.supervisionar_principal(resultado["contexto_ciclo"])
                monitor.executar()
            finally:
                if supervisao is not None:
                    supervisao.cancelar()
            return

    print("Login automático indisponível.")
    print("Abrindo tela de conexão.")

    app = vinculo_http.vincular(JanelaConexao)(
        ao_encontrar_servidor=iniciar_cliente_da_execucao,
        registro_tentativas=registro_tentativas,
        infraestrutura_cliente=infraestrutura_cliente,
        contexto_arquivos=contexto_arquivos,
        saida_aplicacao=saida_aplicacao,
    )
    app.infraestrutura_cliente = infraestrutura_cliente
    app.executar()


if __name__ == "__main__":
    from interface.registro_terminal import instalar_registro_terminal
    import sys
    if '--autoteste-pacote' in sys.argv:
        from empacotamento.validar_pacote import executar
        executar(sys.argv[sys.argv.index('--autoteste-pacote') + 1])
        raise SystemExit(0)
    instalar_registro_terminal()
    from interface.administrador import preparar_inicio
    permitido, tcp_local = preparar_inicio(forcar='--reconfigurar' in sys.argv[1:],
                                         restaurar='--restaurar-admin' in sys.argv[1:])
    forcar = tcp_local or '--reconfigurar' in sys.argv[1:]
    while permitido:
        _proxima_configuracao_administrativa = None
        iniciar(forcar_configuracao=forcar)
        proxima = _proxima_configuracao_administrativa
        if proxima is None:
            break
        if proxima['restaurar']:
            permitido, _ = preparar_inicio(forcar=True, restaurar=True)
        forcar = True

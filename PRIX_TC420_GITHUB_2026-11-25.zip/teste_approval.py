# Ensaio manual com equipamento: solicita credenciais e consulta login, approval e refresh reais.
import getpass
import time

from tc420.web import WebTC420
from mensagens_seguras import mensagem_erro_http


print("=== TESTE WebTC420 ===")

usuario = input("Usuário: ")
senha = getpass.getpass("Senha: ")

try:
    web = WebTC420()
    web.login(usuario, senha)

    print("\nLOGIN REALIZADO!")

    dados = web.approval()

    print("\nAPPROVAL RECEBIDO!")
    print(dados)

    configuracao = web.interpretar_approval(dados)

    print("\n=== CONFIGURAÇÃO INTERPRETADA ===")

    for escala, valores in configuracao.items():
        print()
        print(escala)
        print("  e=d =", valores["divisao"])
        print("  Min =", valores["min"])
        print("  Max =", valores["max"])

    print("\n=== MONITORANDO REFRESH ===")
    print("Coloque peso, movimente e depois deixe estabilizar.")
    print("CTRL+C para encerrar.\n")

    try:
        while True:
            dados_refresh = web.refresh()
            refresh = web.interpretar_refresh(dados_refresh)

            print(
                f"Estado: {refresh['estado']:<3} | "
                f"Bruto: {refresh['peso_bruto']:>8} "
                f"{refresh['unidade']} | "
                f"Tara: {refresh['tara']:>8} | "
                f"Líquido: {refresh['peso_liquido']:>8} | "
                f"Faixa: {refresh['multirange']}"
            )

            time.sleep(0.5)

    except KeyboardInterrupt:
        print("\nMonitoramento encerrado.")

except Exception as erro:
    print("\nERRO:")
    print(mensagem_erro_http(erro))

# Transporte TCP direto legado; o caminho principal da aplicação usa o adaptador web.
import socket


# Implementa a recepção TCP direta legada de frames fixos de 18 bytes, separada do fluxo HTTPS principal.
class ConexaoTC420:
    TAMANHO_FRAME = 18

    # Guarda destino e buffer local sem abrir a conexão durante a construção.
    def __init__(self, ip="192.0.2.21", porta=9800):
        self.ip = ip
        self.porta = porta
        self.socket = None
        self.buffer = bytearray()

    # Abre TCP com timeout de conexão, desativa timeout de leitura e descarta bytes acumulados anteriormente.
    def conectar(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.settimeout(5)
        self.socket.connect((self.ip, self.porta))

        # Depois da conexão, deixa a leitura sem timeout
        self.socket.settimeout(None)

        # Garante que não existam dados antigos no buffer
        self.buffer.clear()

    # Acumula pacotes TCP até obter 18 bytes; devolve um frame e conserva o restante para a próxima leitura.
    def receber(self):
        if self.socket is None:
            raise RuntimeError("A TC420 não está conectada.")

        while len(self.buffer) < self.TAMANHO_FRAME:
            dados = self.socket.recv(1024)

            if not dados:
                raise ConnectionError("A TC420 encerrou a conexão.")

            self.buffer.extend(dados)

        frame = bytes(self.buffer[: self.TAMANHO_FRAME])
        del self.buffer[: self.TAMANHO_FRAME]

        return frame

    # Fecha o socket existente, remove sua referência e esvazia o buffer de recepção.
    def desconectar(self):
        if self.socket is not None:
            self.socket.close()
            self.socket = None

        self.buffer.clear()

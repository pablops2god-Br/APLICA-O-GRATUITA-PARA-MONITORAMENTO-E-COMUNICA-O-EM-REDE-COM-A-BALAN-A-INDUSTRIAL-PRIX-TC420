# Interpretação do frame TCP direto legado, sem realizar comunicação de rede.
# Valida o frame de 18 bytes e interpreta o campo ASCII das posições 3 a 9 como inteiro em kg.
def extrair_peso_kg(dados: bytes) -> int:
    """Extrai do frame o peso bruto em quilogramas."""
    if len(dados) != 18:
        raise ValueError("Frame inválido: esperado 18 bytes")

    campo = dados[3:10]

    try:
        texto = campo.decode("ascii").strip()
        return int(texto) if texto else 0
    except (UnicodeDecodeError, ValueError) as erro:
        raise ValueError("Campo de peso inválido") from erro


# Reutiliza a validação em kg e divide por mil para converter o resultado para toneladas.
def extrair_peso_toneladas(dados: bytes) -> float:
    """Extrai do frame o peso convertido para toneladas."""
    return extrair_peso_kg(dados) / 1000


# Mantém a entrada histórica do interpretador com retorno em kg, sem conversão adicional.
def interpretar_peso(dados: bytes) -> int:
    """Mantém compatibilidade retornando o peso bruto em quilogramas."""
    return extrair_peso_kg(dados)

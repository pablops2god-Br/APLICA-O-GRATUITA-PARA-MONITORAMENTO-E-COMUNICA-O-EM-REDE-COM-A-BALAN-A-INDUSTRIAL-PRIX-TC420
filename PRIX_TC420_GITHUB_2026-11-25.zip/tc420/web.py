# Adaptador HTTPS: requisições ao CGI e interpretação textual das respostas da TC420.
"""
Módulo de Comunicação Web com o Terminal Toledo PRIX TC420
==========================================================

Este módulo encapsula todo o canal de aquisição de dados via HTTPS com
o servidor web embarcado do terminal industrial Toledo Prix TC420.

Decisões de Engenharia Implementadas:
1. TLS com Certificado Auto-Assinado:
   - A balança utiliza HTTPS na porta 443 com certificado auto-assinado de fábrica.
   - A validação de CA é desativada via 'verify=False' e o aviso InsecureRequestWarning é suprimido.
2. Autenticação em Duas Etapas:
   - O comando 'login' envia usuário e senha, recebendo um token de sessão (ex: 11.17.24.51.adm);
   - Os comandos subsequentes ('approval' e 'refresh') exigem obrigatoriamente a presença desse token.
3. Obtenção de Configuração Metrológica ('approval'):
   - Lê os parâmetros oficiais de homologação da balança rodoviária (faixas duplas W1.1 e W1.2,
     divisões de escala, valores mínimos e máximos).
4. Polling Periódico de Pesagem ('refresh'):
   - Consulta o estado atual da pesagem, retornando peso bruto, líquido, tara, unidade,
     indicador de zero metrológico (>0<) e estabilidade (~).
"""

import random

import requests
import urllib3


# A TC420 utiliza HTTPS com certificado próprio.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class WebTC420:
    """
    Cliente HTTPS para o endpoint CGI do terminal Toledo Prix TC420.
    
    Gerencia a sessão de rede, o token de autenticação e a normalização
    das respostas brutas textuais emitidas pelo firmware industrial.
    """
    # Monta a URL do CGI, começa sem token e aceita uma política opcional de autorização das operações.
    def __init__(self, ip="192.0.2.21", *, politica_http=None):
        self.ip = ip
        self.url = f"https://{ip}/cgi-bin/cfgcgi.cgi"
        self.token = None
        if politica_http is not None:
            if not callable(getattr(politica_http, "autorizar", None)):
                raise TypeError("politica_http_invalida")
            self._politica_http = politica_http

    @property
    def politica_http(self):
        """None preserva uso independente; vínculo operacional é explícito."""
        return getattr(self, "_politica_http", None)

    # Quando há política instalada, pede autorização antes da requisição protegida pelo chamador.
    def _autorizar_http(self, operacao):
        politica = self.politica_http
        if politica is not None:
            politica.autorizar(self, operacao)

    # Faz POST com parâmetros na URL (params), valida SUCCESS/LOGIN e conserva o token na instância.
    def login(self, usuario, senha):
        """
        Realiza a autenticação administrativa no servidor web da TC420.
        
        Envia uma requisição POST com 'cmd=login', usuário e senha.
        Se bem-sucedido, armazena e retorna o token de sessão retornado pelo equipamento.
        Lança RuntimeError caso a balança recuse as credenciais.
        """
        self._autorizar_http("login")
        params = {
            "cmd": "login",
            "uname": usuario,
            "pwd": senha,
            "math": random.random(),
        }

        resposta = requests.post(
            self.url,
            params=params,
            verify=False,
            timeout=5,
        )
        resposta.raise_for_status()

        texto = resposta.text.strip()
        partes = texto.split(":")

        if len(partes) < 4:
            raise RuntimeError(
                f"Resposta inesperada da TC420: {texto}"
            )

        status = partes[0].strip()
        acao = partes[1].strip()

        if status != "SUCCESS" or acao != "LOGIN":
            raise RuntimeError(
                f"Login recusado pela TC420: {texto}"
            )

        token = partes[3].strip()

        if not token:
            raise RuntimeError(
                "A TC420 retornou um token vazio."
            )

        self.token = token
        return token

    # Faz GET autenticado e separa o cabeçalho da resposta do texto de configuração metrológica.
    def approval(self, escala=1):
        """
        Requisita os dados metrológicos de homologação da balança (comando 'approval').
        
        Exige que o login já tenha sido realizado (self.token não nulo).
        Retorna a string bruta contendo a definição das faixas de pesagem.
        """
        self._autorizar_http("approval")
        if self.token is None:
            raise RuntimeError(
                "É necessário fazer login antes de solicitar o approval."
            )

        params = {
            "cmd": "approval",
            "scale": escala,
            "token": self.token,
            "math": random.random(),
        }

        resposta = requests.get(
            self.url,
            params=params,
            verify=False,
            timeout=5,
        )
        resposta.raise_for_status()

        texto = resposta.text.strip()
        partes = texto.split(":", 2)

        if len(partes) < 3:
            raise RuntimeError(
                f"Resposta inesperada da TC420: {texto}"
            )

        status = partes[0].strip()
        acao = partes[1].strip()
        dados = partes[2].strip()

        if status != "SUCCESS" or acao != "APPROVAL":
            raise RuntimeError(
                f"Approval recusado pela TC420: {texto}"
            )

        return dados

    # Agrupa divisão, mínimo e máximo pela faixa W encontrada; os valores permanecem como texto.
    def interpretar_approval(self, dados):
        """
        Decodifica a string de approval da TC420 em um dicionário estruturado.
        
        Exemplo de entrada:
            '<00W1.1;e=d= 10 kg;Min 200 kg;Max 80000 kg;W1.2;e=d= 20 kg;Min 400 kg;Max 140000 kg;>'
        Retorna:
            {'W1.1': {'divisao': '10 kg', 'min': '200 kg', 'max': '80000 kg'},
             'W1.2': {'divisao': '20 kg', 'min': '400 kg', 'max': '140000 kg'}}
        """
        # Remove < > e espaços desnecessários
        conteudo = dados.strip().strip("<>")

        campos = [
            campo.strip()
            for campo in conteudo.split(";")
            if campo.strip()
        ]

        escalas = {}
        escala_atual = None

        for campo in campos:
            # Primeiro campo normalmente vem como 00W1.1
            if campo.startswith("00W"):
                escala_atual = campo[2:]

                escalas[escala_atual] = {
                    "divisao": None,
                    "min": None,
                    "max": None,
                }

            # Próximas escalas vêm como W1.2
            elif campo.startswith("W"):
                escala_atual = campo

                escalas[escala_atual] = {
                    "divisao": None,
                    "min": None,
                    "max": None,
                }

            elif escala_atual is not None:
                if campo.startswith("e=d="):
                    escalas[escala_atual]["divisao"] = (
                        campo.split("=", 2)[2].strip()
                    )

                elif campo.startswith("Min"):
                    escalas[escala_atual]["min"] = (
                        campo[3:].strip()
                    )

                elif campo.startswith("Max"):
                    escalas[escala_atual]["max"] = (
                        campo[3:].strip()
                    )

        return escalas

    # Consulta uma amostra; a periodicidade vem do chamador e este método não chama _autorizar_http.
    def refresh(self, escala=1):
        """
        Requisita o estado instantâneo da pesagem ao terminal (comando 'refresh').
        
        Disparado periodicamente a cada 1 segundo pelo nó Principal.
        Retorna a string bruta contendo erro, estado, pesos, tara e flags metrológicos.
        """
        if self.token is None:
            raise RuntimeError(
                "É necessário fazer login antes de solicitar o refresh."
            )

        params = {
            "cmd": "refresh",
            "scale": escala,
            "token": self.token,
            "math": random.random(),
        }

        resposta = requests.get(
            self.url,
            params=params,
            verify=False,
            timeout=5,
        )
        resposta.raise_for_status()

        texto = resposta.text.strip()
        partes = texto.split(":", 2)

        if len(partes) < 3:
            raise RuntimeError(
                f"Resposta inesperada da TC420: {texto}"
            )

        status = partes[0].strip()
        acao = partes[1].strip()
        dados = partes[2].strip()

        if status != "SUCCESS" or acao != "REFRESH":
            raise RuntimeError(
                f"Refresh recusado pela TC420: {texto}"
            )

        return dados

    # Mapeia as posições separadas por ponto e vírgula; pesos e estados são retornados como strings.
    def interpretar_refresh(self, dados):
        """
        Faz o parsing da string bruta de refresh em um dicionário com campos nomeados.
        
        Extrai: erro, estado, data, hora, id, balanca, peso_bruto, tara,
        peso_liquido, unidade, modo_tara e multirange.
        """
        conteudo = dados.strip().strip("<>")
        campos = conteudo.split(";")

        if len(campos) < 12:
            raise RuntimeError(
                f"Resposta REFRESH incompleta: {dados}"
            )

        return {
            "erro": campos[0].strip(),
            "estado": campos[1].strip(),
            "data": campos[2].strip(),
            "hora": campos[3].strip(),
            "id": campos[4].strip(),
            "balanca": campos[5].strip(),
            "peso_bruto": campos[6].strip(),
            "tara": campos[7].strip(),
            "peso_liquido": campos[8].strip(),
            "unidade": campos[9].strip(),
            "modo_tara": campos[10].strip(),
            "multirange": campos[11].strip(),
            "extra": campos[12].strip() if len(campos) > 12 else None,
        }

    # Combina consulta approval e interpretação para entregar as faixas em um dicionário.
    def obter_configuracao(self, escala=1):
        dados = self.approval(escala)
        return self.interpretar_approval(dados)

    # Combina consulta refresh e interpretação para entregar uma amostra com campos nomeados.
    def obter_estado(self, escala=1):
        dados = self.refresh(escala)
        return self.interpretar_refresh(dados)

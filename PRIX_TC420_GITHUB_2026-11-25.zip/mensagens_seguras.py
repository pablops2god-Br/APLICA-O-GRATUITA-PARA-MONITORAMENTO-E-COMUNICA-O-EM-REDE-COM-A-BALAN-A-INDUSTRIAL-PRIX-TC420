# Diagnóstico: converte falhas HTTP em mensagens controladas, sem reproduzir URLs com credenciais.
"""Classificação e mensagens HTTP puras, compartilhadas por rede e interface."""

import requests


def classificar_erro_http(erro):
    """Devolve categoria controlada, sem serializar ou modificar a exceção."""
    if isinstance(erro, (requests.Timeout, TimeoutError)):
        return "timeout"
    if isinstance(erro, requests.ConnectionError):
        return "conexao"
    if isinstance(erro, requests.HTTPError):
        resposta = erro.response
        if resposta is not None and resposta.status_code in (401, 403):
            return "autenticacao"
        return "http"
    # WebTC420 usa RuntimeError sem subtipos para recusas e erros de protocolo.
    # Somente reconhecer prefixos da aplicação; nunca copiar corpos/sufixos.
    if isinstance(erro, RuntimeError) and erro.args and type(erro.args[0]) is str:
        texto = erro.args[0]
        if texto == "infraestrutura_http_ausente_ou_invalida":
            return "infraestrutura"
        if texto == "admissao_contexto_http_recusada":
            return "admissao"
        if texto.startswith("Login recusado pela TC420: "):
            return "login_recusado"
        if texto.startswith("Approval recusado pela TC420: "):
            return "approval_recusado"
        if (texto.startswith("Resposta inesperada da TC420: ")
                or texto == "A TC420 retornou um token vazio."):
            return "resposta_invalida"
    return "inesperada"


def mensagem_erro_http(erro):
    """Somente literais da aplicação podem alcançar diagnóstico ou apresentação."""
    mensagens = {
        "timeout": "Tempo de conexão com a TC420 esgotado. Tente novamente.",
        "conexao": "Não foi possível conectar à TC420. Verifique a conexão e tente novamente.",
        "autenticacao": "Autenticação não autorizada pela TC420.",
        "http": "A TC420 retornou um erro de comunicação. Tente novamente.",
        "infraestrutura": "infraestrutura_http_ausente_ou_invalida",
        "admissao": "admissao_contexto_http_recusada",
        "login_recusado": "Login recusado pela TC420. Verifique usuário e senha.",
        "approval_recusado": "Approval recusado pela TC420.",
        "resposta_invalida": "A TC420 retornou uma resposta inválida.",
        "inesperada": "Não foi possível concluir a operação. Tente novamente.",
    }
    return mensagens[classificar_erro_http(erro)]

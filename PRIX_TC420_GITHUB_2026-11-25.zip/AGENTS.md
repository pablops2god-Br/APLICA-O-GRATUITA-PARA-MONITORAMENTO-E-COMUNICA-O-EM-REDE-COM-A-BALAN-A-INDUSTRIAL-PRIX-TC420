# Orientações do projeto

# Detalhamento de resposta final

Sempre dar uma descrição detalhado do que foi feito na resposta final de cada input de texto;

## Documentação obrigatória

Por solicitação do responsável pelo projeto, manter a pasta `documentação/`
atualizada a cada nova solicitação textual relacionada ao projeto.
Antes de concluir a tarefa, atualizar os documentos afetados e registrar a
solicitação, o resultado e as verificações em `documentação/HISTORICO.md`.
Para solicitações sem mudanças no código, registrar o resultado no histórico
quando houver informação relevante ao projeto. Não afirmar validações reais
quando apenas testes simulados foram executados.

Documentar o comportamento efetivo do código e separar funcionalidades
implementadas, limitações e propostas. Não incluir senhas, tokens ou outras
credenciais nos documentos, exemplos, testes versionados ou commits.

## Escopo e referência

A pasta `Navegador model` serve apenas de referência. Excluí-la do inventário,
da documentação técnica e de alterações, salvo pedido explícito do usuário.
Respeitar o escopo de arquivos solicitado para cada etapa e atualizar a
documentação correspondente como parte da tarefa.

## Commits

Não incluir `__pycache__` ou credenciais em commits. Criar commits quando
solicitado. Não fazer push sem solicitação.

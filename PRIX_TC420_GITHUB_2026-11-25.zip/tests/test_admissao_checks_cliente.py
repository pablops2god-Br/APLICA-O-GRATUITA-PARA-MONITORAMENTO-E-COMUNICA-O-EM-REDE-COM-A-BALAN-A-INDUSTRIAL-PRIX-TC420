# Testes de admissao checks cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-C5: CHECKs reais, transporte falso, cancelamento e autorização separados."""
import gc
import socket
import threading
import unittest
import weakref
from unittest.mock import Mock, patch

from rede import buscarservidor as busca
from rede.admissao_checks_cliente import RecursosCheckCliente, AdmissaoChecksCliente as ControleChecks
from rede.lerdadosserver import LeitorDadosServidor
from test_descoberta_cliente_integrada import SocketDescobertaFalso
import test_admissao_descoberta_inicial_cliente as inicial
import test_associacoes_retentativas_cliente as recuperacao


# Grupo de 44 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AdmissaoChecksCliente(unittest.TestCase):
    buscar = inicial.AdmissaoDescobertaInicialCliente.buscar
    resposta = inicial.AdmissaoDescobertaInicialCliente.resposta
    recursos = inicial.AdmissaoDescobertaInicialCliente.recursos
    retido = inicial.AdmissaoDescobertaInicialCliente.retido
    conservador = inicial.AdmissaoDescobertaInicialCliente.conservador

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        inicial.AdmissaoDescobertaInicialCliente.setUp(self)
        self.checks = self.controle._admissao_checks

    def check(self):
        return self.checks.obter_retrato()[0]

    def reservado(self, suspender=None, antes=None):
        udp, tcp = self.resposta(), SocketDescobertaFalso()
        def fabricar(_familia, tipo):
            if tipo == socket.SOCK_DGRAM:
                return udp
            if antes:
                antes()
            if suspender:
                suspender()
            return tcp
        with patch('socket.socket', side_effect=fabricar):
            self.assertEqual('simulado', self.leitor._buscar_servidor_inicial())
        return tcp

    def antes_do_socket(self, durante):
        admitir = self.checks.admitir
        def executar(suspender):
            def atrasar(recursos):
                identidade = admitir(recursos)
                suspender()
                return identidade
            with patch.object(self.checks, 'admitir', side_effect=atrasar):
                self.assertEqual('simulado', self.buscar(self.resposta()))
        self.retido(executar, durante)

    def test_01_CHECK_normal(self):
        self.assertEqual('simulado', self.buscar(self.resposta()))
        item = self.check()
        self.assertEqual(self.infra.aplicacao_id, item['aplicacao_id'])
        self.assertEqual(self.leitor.recursos_cliente.geracao_id, item['geracao_id'])
        self.assertEqual('leitor_permanente', item['origem'])
        self.assertIsNone(item['retentativa_id'])
        self.assertEqual(self.recursos()[0]['recurso_id'], item['descoberta_udp_id'])
        self.assertEqual(1, item['descoberta_inicial_id'])
        self.assertTrue(item['resultado'])
        self.assertTrue(item['responsabilidade_resolvida'])
        self.assertEqual([self.recursos()[1]['recurso_id']], [r['recurso_id'] for r in item['recursos']])

    def test_02_CANCELAMENTO_recusa(self):
        self.assertIsNone(self.buscar(self.resposta(self.leitor.parar)))
        self.assertEqual([], self.checks.obter_retrato())
        self.assertEqual(['socket_udp'], [r['tipo'] for r in self.recursos()])

    def test_03_CANCELAMENTO_simultaneo(self):
        barreira = threading.Barrier(2)
        aceitas, erros = [], []
        def admitir():
            try:
                barreira.wait(3)
                aceitas.append(self.checks.admitir(self.leitor.recursos_cliente))
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=admitir)
        thread.start()
        try:
            barreira.wait(3)
            self.leitor.parar()
        finally:
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(1, len(aceitas))
        self.assertEqual(int(aceitas[0] is not None), len(self.checks.obter_retrato()))
        self.assertIsNone(self.checks.admitir(self.leitor.recursos_cliente))

    def test_04_recusa_sem_fabrica_TCP(self):
        udp = self.resposta(self.leitor.parar)
        def fabricar(_familia, tipo):
            self.assertEqual(socket.SOCK_DGRAM, tipo)
            return udp
        with patch('socket.socket', side_effect=fabricar) as fabrica:
            self.assertIsNone(self.leitor._buscar_servidor_inicial())
        self.assertEqual(1, fabrica.call_count)
        self.assertTrue(udp.fechado)

    def test_05_recusa_sem_conexao_envio(self):
        tcp = SocketDescobertaFalso()
        self.buscar(self.resposta(self.leitor.parar), tcp)
        tcp.connect.assert_not_called()
        tcp.sendall.assert_not_called()
        tcp.recv.assert_not_called()

    def test_06_admitido_antes_parada(self):
        self.antes_do_socket(self.leitor.parar)
        self.assertTrue(self.check()['responsabilidade_resolvida'])
        self.assertEqual(1, len(self.checks.obter_retrato()))

    def test_07_CANCELAMENTO_apos_reserva(self):
        def durante():
            self.leitor.parar()
            self.assertEqual(1, len(self.check()['recursos']))
            self.assertTrue(self.recursos()[1]['criacao_em_curso'])
            self.assertFalse(self.check()['responsabilidade_resolvida'])
        self.retido(lambda suspender: self.reservado(suspender), durante)
        self.assertTrue(self.check()['responsabilidade_resolvida'])

    def test_08_CANCELAMENTO_apos_criacao(self):
        tcp = SocketDescobertaFalso()
        def conectar(*_):
            self.leitor.parar()
            self.assertFalse(self.check()['responsabilidade_resolvida'])
        tcp.connect.side_effect = conectar
        self.buscar(self.resposta(), tcp)
        self.assertTrue(tcp.fechado)
        self.assertTrue(self.check()['responsabilidade_resolvida'])

    def test_09_falha_criacao_com_ausencia_comprovada(self):
        criar = self.infra.registro_recursos.criar
        def falhar(token, fabrica):
            if token.numero != 1:
                raise ValueError('antes_fabrica_simulado')
            return criar(token, fabrica)
        with patch.object(self.infra.registro_recursos, 'criar', side_effect=falhar):
            with self.assertRaises(ValueError):
                self.buscar(self.resposta())
        self.assertTrue(self.check()['recursos'][0]['limpeza_confirmada'])
        self.assertTrue(self.check()['responsabilidade_resolvida'])

    def test_10_erro_comunicacao_preservado(self):
        tcp = SocketDescobertaFalso()
        erro = ValueError('recepcao_simulada')
        tcp.recv.side_effect = erro
        with self.assertRaises(ValueError) as capturado:
            self.buscar(self.resposta(), tcp)
        self.assertIs(erro, capturado.exception)
        self.assertTrue(tcp.fechado)
        self.assertEqual({'categoria': 'falha_operacao'}, self.check()['erro_operacao'])

    def test_11_erro_close_nao_confirma(self):
        tcp = SocketDescobertaFalso()
        tcp.erro_close = OSError('close_simulado')
        with patch('builtins.print'):
            self.assertIsNone(self.buscar(self.resposta(), tcp))
        self.assertFalse(self.check()['responsabilidade_resolvida'])
        self.assertFalse(self.check()['recursos'][0]['limpeza_confirmada'])

    def test_12_falha_publicacao_resultado(self):
        with patch.object(self.checks, '_publicar_saida', side_effect=ValueError()):
            with self.assertRaises(ValueError):
                self.buscar(self.resposta())
        self.assertTrue(self.check()['erro_publicacao'])
        self.assertFalse(self.check()['retorno'])
        self.assertFalse(self.check()['responsabilidade_resolvida'])
        self.assertFalse(self.controle.obter_retrato()['operacoes'][0]['responsabilidade_resolvida'])

    def test_13_recuperacao_vinculos_AC2C(self):
        fx = recuperacao.AssociacoesRetentativasCliente()
        fx.setUp()
        fx.executar_descoberta()
        associacao, = fx.infra.obter_associacoes_retentativas()
        item, = associacao['checks']
        self.assertEqual('recuperacao', item['origem'])
        self.assertEqual(associacao['retentativa_id'], item['retentativa_id'])
        self.assertEqual(associacao['geracao_id'], item['geracao_id'])
        self.assertEqual(associacao['recursos'][1]['recurso_id'], item['recursos'][0]['recurso_id'])
        secundaria, = fx.guarda.obter_retrato()['secundarias']
        self.assertEqual(secundaria['id'], item['autorizacao_secundaria_id'])
        self.assertTrue(secundaria['resolvida'])
        self.assertTrue(item['responsabilidade_resolvida'])

    def test_14_preparacao_independente(self):
        self.leitor.parar()
        udp, tcp = self.resposta(), SocketDescobertaFalso()
        with patch('socket.socket', side_effect=[udp, tcp]):
            self.assertEqual('simulado', busca.buscar_servidor(infraestrutura_cliente=self.infra))
        self.assertNotEqual(self.leitor.recursos_cliente.geracao_id, self.recursos()[1]['geracao_id'])
        self.assertEqual([], self.checks.obter_retrato())
        self.assertEqual([], self.infra.obter_associacoes_retentativas())

    def test_15_promocao_durante_CHECK(self):
        geracao = self.leitor.recursos_cliente.geracao_id
        tcp = SocketDescobertaFalso()
        def conectar(*_):
            self.infra.registro_recursos.promover(geracao)
            self.infra.registro_retentativas.promover(self.leitor.recursos_cliente._geracao_retentativas)
            self.leitor.parar()
            novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
            self.assertEqual('simulado', self.buscar(self.resposta(), leitor=novo))
            self.assertNotEqual(geracao, novo.recursos_cliente.geracao_id)
        tcp.connect.side_effect = conectar
        self.assertEqual('simulado', self.buscar(self.resposta(), tcp))
        self.assertEqual(geracao, self.check()['geracao_id'])
        tcp.sendall.assert_called_once_with(b'CHECK\n')

    def test_16_antigo_representado_apos_nova_geracao(self):
        self.buscar(self.resposta())
        checks = self.checks.obter_retrato()
        referencia = weakref.ref(self.checks)
        del self.leitor, self.controle, self.checks
        gc.collect()
        self.assertIsNotNone(referencia())
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.buscar(self.resposta(), leitor=novo)
        self.assertEqual(checks, self.infra.obter_operacoes_descoberta_inicial()[0]['checks'])

    def test_corrida_A_cancelamento_antes_admissao(self):
        self.test_04_recusa_sem_fabrica_TCP()

    def test_corrida_B_admissao_antes_cancelamento(self):
        def durante():
            self.leitor.parar()
            self.assertEqual([], self.check()['recursos'])
            self.assertEqual(1, len(self.recursos()))
            self.assertFalse(self.check()['responsabilidade_resolvida'])
        self.antes_do_socket(durante)
        self.assertTrue(self.check()['responsabilidade_resolvida'])

    def test_corrida_C_entre_resposta_udp_e_CHECK(self):
        confirmar = busca.confirmar_servidor
        def atrasar(*args, **kwargs):
            self.leitor.parar()
            return confirmar(*args, **kwargs)
        with patch.object(busca, 'confirmar_servidor', side_effect=atrasar):
            self.assertIsNone(self.buscar(self.resposta()))
        self.assertEqual([], self.checks.obter_retrato())
        self.assertEqual(1, len(self.recursos()))

    def test_corrida_D_leitor_cancelado_recuperacao_independente(self):
        fx = recuperacao.AssociacoesRetentativasCliente()
        fx.setUp()
        udp = self.resposta()
        def receber(_):
            fx.leitor.parar()
            with patch('socket.socket') as fabrica:
                self.assertFalse(busca.confirmar_servidor('simulado', fx.leitor.recursos_cliente))
            fabrica.assert_not_called()
            return b'TC420_SERVER_HERE', ('simulado', 42101)
        udp.recvfrom.side_effect = receber
        tcp = SocketDescobertaFalso()
        fx.executar_descoberta(resposta=False, udp=udp, tcp=tcp)
        tcp.sendall.assert_called_once_with(b'CHECK\n')
        self.assertTrue(fx.infra.obter_associacoes_retentativas()[0]['checks'][0]['responsabilidade_resolvida'])

    def test_corrida_E_promocao_com_socket_pendente(self):
        geracao = self.leitor.recursos_cliente.geracao_id
        def durante():
            self.infra.registro_recursos.promover(geracao)
            self.leitor.parar()
            self.assertFalse(self.check()['responsabilidade_resolvida'])
            self.assertEqual(geracao, self.check()['geracao_id'])
            self.conservador()
        self.retido(lambda suspender: self.reservado(suspender), durante)
        self.assertEqual(geracao, self.check()['geracao_id'])

    def test_corrida_F_consulta_autorizada_sem_socket(self):
        def durante():
            antes = self.infra.obter_operacoes_descoberta_inicial()
            self.assertEqual([], self.check()['recursos'])
            self.assertFalse(self.check()['responsabilidade_resolvida'])
            self.conservador()
            self.assertEqual(antes, self.infra.obter_operacoes_descoberta_inicial())
        self.antes_do_socket(durante)

    def test_adicional_cancelamento_nao_interrompe_envio_admitido(self):
        tcp = self.reservado(antes=self.leitor.parar)
        tcp.sendall.assert_called_once_with(b'CHECK\n')
        self.assertFalse(self.leitor.executando)
        # A mesma descoberta pode ter UDP antigo ainda aberto e novo CHECK recusado.
        self.setUp()
        udp = self.resposta(self.leitor.parar)
        tcp = SocketDescobertaFalso()
        self.assertIsNone(self.buscar(udp, tcp))
        tcp.sendall.assert_not_called()
        self.assertEqual([], self.checks.obter_retrato())
        self.assertTrue(udp.fechado)

    def test_recuperacao_cancelada_pela_guarda(self):
        fx = recuperacao.AssociacoesRetentativasCliente()
        fx.setUp()
        udp = self.resposta(fx.guarda.fechar_admissao)
        tcp = SocketDescobertaFalso()
        fx.executar_descoberta(resposta=False, udp=udp, tcp=tcp)
        tcp.connect.assert_not_called()
        self.assertEqual([], fx.infra.obter_associacoes_retentativas()[0]['checks'])

    def test_fabrica_opaca_lanca_reserva_incerta(self):
        udp = self.resposta()
        def fabricar(_familia, tipo):
            if tipo == socket.SOCK_DGRAM:
                return udp
            raise ValueError('fabrica_opaca_simulada')
        with patch('socket.socket', side_effect=fabricar):
            with self.assertRaises(ValueError):
                self.leitor._buscar_servidor_inicial()
        self.assertEqual(1, len(self.check()['recursos']))
        self.assertFalse(self.check()['responsabilidade_resolvida'])

    def test_falha_vinculo_sem_fabrica_TCP(self):
        udp = self.resposta()
        with patch.object(RecursosCheckCliente, '_publicar_vinculo', side_effect=ValueError()), \
                patch('socket.socket', return_value=udp) as fabrica:
            with self.assertRaises(ValueError):
                self.leitor._buscar_servidor_inicial()
        self.assertEqual(1, fabrica.call_count)
        self.assertTrue(self.check()['erro_associacao'])
        self.assertFalse(self.check()['responsabilidade_resolvida'])

    def test_publicador_escreve_e_lanca_sem_confirmar(self):
        publicar = self.checks._publicar_saida
        def falhar(*args):
            publicar(*args)
            raise ValueError('publicacao_simulada')
        with patch.object(self.checks, '_publicar_saida', side_effect=falhar):
            with self.assertRaises(ValueError):
                self.buscar(self.resposta())
        self.assertFalse(self.check()['retorno'])
        self.assertFalse(self.check()['responsabilidade_resolvida'])

    def test_erros_operacao_e_close_preservam_primario(self):
        tcp = SocketDescobertaFalso()
        erro = ValueError('primario_simulado')
        tcp.recv.side_effect = erro
        tcp.erro_close = OSError('close_simulado')
        with self.assertRaises(ValueError) as capturado:
            self.buscar(self.resposta(), tcp)
        self.assertIs(erro, capturado.exception)
        self.assertFalse(self.check()['responsabilidade_resolvida'])

    def test_erros_operacao_e_publicacao_preservam_primario(self):
        tcp = SocketDescobertaFalso()
        erro = ValueError('primario_simulado')
        tcp.recv.side_effect = erro
        with patch.object(self.checks, '_publicar_saida', side_effect=OSError()):
            with self.assertRaises(ValueError) as capturado:
                self.buscar(self.resposta(), tcp)
        self.assertIs(erro, capturado.exception)
        self.assertFalse(self.check()['responsabilidade_resolvida'])

    def test_lock_livre_durante_rede_e_close(self):
        tcp = SocketDescobertaFalso()
        def verificar(*_):
            livre = self.controle._lock.acquire(blocking=False)
            self.assertTrue(livre)
            if livre:
                self.controle._lock.release()
        tcp.connect.side_effect = verificar
        tcp.sendall.side_effect = verificar
        tcp.recv.side_effect = lambda *_: (verificar(), b'TC420_SERVER_OK')[1]
        fechar = tcp.close
        tcp.close = lambda: (verificar(), fechar())[-1]
        self.buscar(self.resposta(), tcp)
        self.assertTrue(self.check()['responsabilidade_resolvida'])

    def test_repeticao_autorizada_mesma_ordem_e_protocolo(self):
        udp, tcp_a, tcp_b = self.resposta(), SocketDescobertaFalso(), SocketDescobertaFalso()
        tcp_a.recv.return_value = b'INVALIDA'
        with patch('socket.socket', side_effect=[udp, tcp_a, tcp_b]):
            self.assertEqual('simulado', self.leitor._buscar_servidor_inicial())
        self.assertEqual([False, True], [c['resultado'] for c in self.checks.obter_retrato()])
        self.assertEqual(1, udp.sendto.call_count)
        udp.sendto.assert_called_once_with(b'TC420_SERVER_DISCOVERY', ('255.255.255.255', 42101))
        for tcp in (tcp_a, tcp_b):
            tcp.connect.assert_called_once_with(('simulado', 42100))
            tcp.sendall.assert_called_once_with(b'CHECK\n')
            tcp.settimeout.assert_called_once_with(2)
        self.assertEqual(2, len({c['recursos'][0]['recurso_id'] for c in self.checks.obter_retrato()}))

    def test_proximo_CHECK_recusado_sem_perder_anterior(self):
        udp, tcp = self.resposta(), SocketDescobertaFalso()
        def receber(_):
            self.leitor.parar()
            return b'INVALIDA'
        tcp.recv.side_effect = receber
        self.assertIsNone(self.buscar(udp, tcp))
        self.assertEqual(2, udp.recvfrom.call_count)
        self.assertEqual(1, len(self.checks.obter_retrato()))
        self.assertTrue(self.check()['responsabilidade_resolvida'])
        self.assertTrue(udp.fechado)

    def test_legado_respeita_parada_sem_prova_recursos(self):
        leitor = LeitorDadosServidor()
        udp, tcp = self.resposta(leitor.parar), SocketDescobertaFalso()
        self.assertIsNone(self.buscar(udp, tcp, leitor))
        tcp.sendall.assert_not_called()
        novo = LeitorDadosServidor()
        self.assertEqual('simulado', self.buscar(self.resposta(), leitor=novo))
        self.assertFalse(novo.obter_operacoes_descoberta_inicial()['checks'][0]['responsabilidade_resolvida'])

    def test_chamada_direta_preserva_retorno_booleano(self):
        self.leitor.parar()
        with patch('socket.socket') as fabrica:
            self.assertIs(False, busca.confirmar_servidor('simulado', self.leitor.recursos_cliente))
        fabrica.assert_not_called()

    def test_consolidado_conservador(self):
        self.buscar(self.resposta())
        antes = self.infra.obter_operacoes_descoberta_inicial()
        self.conservador()
        self.assertEqual(antes, self.infra.obter_operacoes_descoberta_inicial())

    def test_recuperacao_admite_antes_guarda_cria_depois(self):
        fx = recuperacao.AssociacoesRetentativasCliente()
        fx.setUp()
        admitir = ControleChecks.admitir
        def autorizar(controle, recursos):
            identidade = admitir(controle, recursos)
            if controle._recuperacao is not None:
                fx.guarda.fechar_admissao()
                item, = fx.infra.obter_associacoes_retentativas()[0]['checks']
                self.assertEqual([], item['recursos'])
                self.assertFalse(item['responsabilidade_resolvida'])
                self.assertFalse(fx.guarda.obter_retrato()['secundarias'][0]['resolvida'])
            return identidade
        with patch.object(ControleChecks, 'admitir', autorizar):
            _, tcp = fx.executar_descoberta()
        tcp.sendall.assert_called_once_with(b'CHECK\n')
        self.assertTrue(fx.infra.obter_associacoes_retentativas()[0]['checks'][0]['responsabilidade_resolvida'])

    def test_publicacao_secundaria_falsa_ou_ambigua(self):
        for falha in ('false', 'antes', 'depois'):
            with self.subTest(falha=falha):
                fx = recuperacao.AssociacoesRetentativasCliente()
                fx.setUp()
                resolver = fx.guarda.resolver_secundaria
                def publicar(*args, **kwargs):
                    if falha == 'false':
                        return False
                    if falha == 'depois':
                        resolver(*args, **kwargs)
                    raise ValueError('publicacao_secundaria_simulada')
                with patch.object(fx.guarda, 'resolver_secundaria', side_effect=publicar):
                    with self.assertRaises((RuntimeError, ValueError)):
                        fx.executar_descoberta()
                item = fx.infra.obter_associacoes_retentativas()[0]['checks'][0]
                self.assertTrue(item['erro_publicacao'])
                self.assertFalse(item['autorizacao_secundaria_resolvida'])
                self.assertFalse(item['responsabilidade_resolvida'])

    def test_secundaria_falha_preserva_erro_primario(self):
        fx = recuperacao.AssociacoesRetentativasCliente()
        fx.setUp()
        erro = ValueError('primario_simulado')
        tcp = SocketDescobertaFalso()
        tcp.recv.side_effect = erro
        with patch.object(fx.guarda, 'resolver_secundaria', side_effect=RuntimeError()):
            with self.assertRaises(ValueError) as capturado:
                fx.executar_descoberta(tcp=tcp)
        self.assertIs(erro, capturado.exception)
        self.assertFalse(fx.infra.obter_associacoes_retentativas()[0]['checks'][0]['responsabilidade_resolvida'])

    def test_publicacao_criacao_close_falham_handle_retido(self):
        tcp = SocketDescobertaFalso()
        tcp.erro_close = OSError('close_simulado')
        referencia = weakref.ref(tcp)
        criar = self.infra.registro_recursos.criar
        def publicar(token, alocar):
            if token.numero == 1:
                return criar(token, alocar)
            alocar()
            raise ValueError('criacao_simulada')
        with patch.object(self.infra.registro_recursos, 'criar', side_effect=publicar):
            with self.assertRaises(ValueError):
                self.buscar(self.resposta(), tcp)
        del tcp
        gc.collect()
        self.assertIsNotNone(referencia())
        self.assertTrue(self.controle._publicacoes_pendentes)
        self.assertFalse(self.check()['responsabilidade_resolvida'])

    def test_preparacao_sem_cancelamento_proprio_nao_herda_guarda(self):
        udp = self.resposta(self.infra.registro_retentativas.fechar_admissao)
        tcp = SocketDescobertaFalso()
        with patch('socket.socket', side_effect=[udp, tcp]):
            self.assertEqual('simulado', busca.buscar_servidor(infraestrutura_cliente=self.infra))
        tcp.sendall.assert_called_once_with(b'CHECK\n')
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()['secundarias'])

    def test_timeout_TCP_preserva_resultado_e_cleanup(self):
        udp, tcp = self.resposta(), SocketDescobertaFalso()
        udp.recvfrom.side_effect = [(b'TC420_SERVER_HERE', ('simulado', 42101)), socket.timeout()]
        tcp.recv.side_effect = socket.timeout()
        self.assertIsNone(self.buscar(udp, tcp))
        self.assertIs(False, self.check()['resultado'])
        self.assertTrue(self.check()['responsabilidade_resolvida'])
        self.assertTrue(self.recursos()[1]['erros_atendimento'])

    def test_script_descoberta_legado_com_transporte_simulado(self):
        import runpy
        from pathlib import Path
        with patch('socket.socket', return_value=SocketDescobertaFalso()), patch('builtins.print'):
            runpy.run_path(str(Path(busca.__file__)), run_name='__main__')

    def test_candidatura_legada_propaga_autoridade_CHECK(self):
        leitor = LeitorDadosServidor()
        leitor.executando = True
        leitor.posicao_sucessao = 1
        udp, tcp = self.resposta(leitor.parar), SocketDescobertaFalso()
        with patch('socket.socket', side_effect=[udp, tcp]), \
                patch('time.monotonic', return_value=0), patch('builtins.print'):
            self.assertFalse(leitor._aguardar_candidatura())
        tcp.connect.assert_not_called()
        self.assertTrue(udp.fechado)

    def test_loop_legado_propaga_autoridade_CHECK(self):
        leitor = LeitorDadosServidor()
        leitor.executando = True
        udp, tcp = self.resposta(leitor.parar), SocketDescobertaFalso()
        chamadas = []
        def buscar(**kwargs):
            chamadas.append(kwargs)
            if len(chamadas) == 1:
                return None
            return busca.buscar_servidor(**kwargs)
        with patch('rede.lerdadosserver.buscar_servidor', side_effect=buscar), \
                patch('socket.socket', side_effect=[udp, tcp]), patch('builtins.print'):
            leitor._manter_atualizado()
        self.assertEqual(2, len(chamadas))
        tcp.connect.assert_not_called()
        self.assertTrue(udp.fechado)

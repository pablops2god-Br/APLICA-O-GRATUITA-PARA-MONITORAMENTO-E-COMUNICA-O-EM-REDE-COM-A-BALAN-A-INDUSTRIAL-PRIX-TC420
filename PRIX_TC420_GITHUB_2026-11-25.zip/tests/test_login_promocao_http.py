# Testes de login promocao http: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.4: callback real de promoção e HTTP com transporte simulado."""
from types import SimpleNamespace
import threading
import unittest
from unittest.mock import Mock, patch
from urllib.parse import parse_qs, urlsplit

import requests

from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from tc420.web import WebTC420
import test_infraestrutura_cliente as fixtures
import test_login_http_integrado as login


# Grupo de 24 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class LoginPromocaoHttp(unittest.TestCase):
    transporte = login.LoginHttpIntegrado.transporte
    iniciar_thread = login.LoginHttpIntegrado.iniciar_thread
    terminar = login.LoginHttpIntegrado.terminar
    bloquear = login.LoginHttpIntegrado.bloquear
    operacoes = login.LoginHttpIntegrado.operacoes
    negativo = login.LoginHttpIntegrado.negativo

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_http
        self.fixture = fixtures.InfraestruturaCliente()
        self.fixture.setUp()
        self.fixture.env["buscar_servidor"].return_value = None
        self.fixture.iniciar_cliente(self.infra)
        self.dono = self.fixture.leitores[0].recursos_cliente
        self.web = WebTC420("balanca-simulada")
        self.web.obter_configuracao = Mock(return_value={})
        self.fixture.env["WebTC420"].return_value = self.web

    def executar(self, web=None, dono=None):
        return self.infra.executar_login_promocao(dono or self.dono, web or self.web, "simulado", "simulado")

    def promover(self):
        return self.fixture.monitores[0].ao_promover_automaticamente()

    def test_01_callback_normal_protocolo_geracao_real(self):
        geracoes_antes = self.infra.registro_retentativas.obter_retrato()
        with self.transporte() as adaptador, patch("tc420.web.random.random", return_value=0.25):
            resultado = self.promover()
        self.assertIs(self.web, resultado["web"])
        self.assertEqual({}, resultado["configuracao"])
        self.assertEqual(1, len(adaptador.enviados))
        pedido, opcoes = adaptador.enviados[0]
        self.assertEqual("POST", pedido.method)
        self.assertEqual(self.web.url, pedido.url.split('?')[0])
        self.assertEqual(dict(cmd=["login"], uname=["simulado"], pwd=["valor-simulado"], math=["0.25"]),
                         parse_qs(urlsplit(pedido.url).query))
        self.assertIsNone(pedido.body)
        self.assertEqual(5, opcoes["timeout"])
        self.assertFalse(opcoes["verify"])
        self.assertFalse(opcoes["stream"])
        op = self.operacoes()[0]
        self.assertEqual(self.dono.geracao_id, op["geracao_id"])
        self.assertEqual(self.dono.atividade_id, op["atividade_id"])
        self.assertEqual("retorno", op["resultado"])
        self.assertEqual(geracoes_antes, self.infra.registro_retentativas.obter_retrato())

    def test_02_timeout_original_e_callback_none(self):
        original = requests.Timeout("simulada")
        with self.transporte(erro=original) as adaptador:
            with self.assertRaises(requests.Timeout) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertEqual(1, len(adaptador.enviados))
        with self.transporte(erro=original):
            self.assertIsNone(self.promover())
        self.fixture.leitores[0].registrar_falha_recuperacao.assert_called_once_with()
        self.web.obter_configuracao.assert_not_called()
        self.assertEqual([], fixtures.ThreadFila.criadas)

    def test_03_conexao_original(self):
        original = requests.ConnectionError("simulada")
        with self.transporte(erro=original):
            with self.assertRaises(requests.ConnectionError) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertEqual("falha", self.operacoes()[0]["resultado"])

    def test_04_status_http_preserva_response(self):
        for status in (401, 503):
            with self.subTest(status=status), self.transporte(status=status) as adaptador:
                with self.assertRaises(requests.HTTPError) as capturado:
                    self.executar()
            self.assertIs(adaptador.resposta, capturado.exception.response)
            self.assertEqual("falha", self.operacoes()[-1]["resultado"])

    def test_05_parse_original_e_estado_token(self):
        for texto in (b"invalida", b"FAILURE:LOGIN:simulado:simulado", b"SUCCESS:LOGIN:simulado:"):
            with self.subTest(texto=texto), self.transporte(texto):
                with self.assertRaises(RuntimeError):
                    self.executar()
            self.assertIsNone(self.web.token)
            self.assertEqual("falha", self.operacoes()[-1]["resultado"])

    def test_06_falha_antes_callback_prova_ausencia(self):
        original = ValueError("preparacao_simulada")
        with patch.object(self.registro, "_iniciar", side_effect=original), patch("requests.post") as enviar:
            with self.assertRaises(ValueError) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        enviar.assert_not_called()
        op = self.operacoes()[0]
        self.assertTrue(op["execucao_resolvida"])
        self.assertFalse(op["inicio_confirmado"])
        self.assertEqual("nao_execucao_comprovada", op["publicacao_original"]["evidencia"])

    def test_07_recusa_explicita_sem_envio_ou_partida(self):
        self.registro.fechar_admissao()
        self.fixture.env["print"] = Mock()
        with patch("requests.post") as enviar:
            with self.assertRaisesRegex(RuntimeError, "admissao_contexto_http_recusada"):
                self.executar()
            self.assertIsNone(self.promover())
        enviar.assert_not_called()
        self.fixture.env["print"].assert_any_call("Falha na promo\u00e7\u00e3o: RuntimeError")
        self.assertEqual([], self.operacoes())
        self.assertEqual([], fixtures.ThreadFila.criadas)

    def test_08_corrida_d_publicacao_tardia(self):
        entrou, liberar = threading.Event(), threading.Event()
        publicar = self.registro.publicar
        def atrasar(op, recibo):
            self.bloquear(entrou, liberar)
            return publicar(op, recibo)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=atrasar):
            tarefa = self.iniciar_thread(self.promover)
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual("simulado", self.web.token)
                self.assertTrue(self.operacoes()[0]["publicacoes_pendentes"])
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
                self.assertEqual([], fixtures.ThreadFila.criadas)
                self.negativo()
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertIsNotNone(resultados[0])
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_09_publicacao_falha_nao_inicia_servidor(self):
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=OSError()):
            self.assertIsNone(self.promover())
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])
        self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
        self.web.obter_configuracao.assert_not_called()
        self.assertEqual([], fixtures.ThreadFila.criadas)
        self.negativo()

    def test_10_duas_requisicoes_mesma_geracao_ids_distintos(self):
        barreira = threading.Barrier(2)
        erro = requests.ConnectionError("simulada")
        def enviar(url, **kwargs):
            barreira.wait(3)
            self.assertEqual(2, len(self.operacoes()))
            self.assertTrue(all(not op["execucao_resolvida"] for op in self.operacoes()))
            barreira.wait(3)
            if "segunda" in url:
                raise erro
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=enviar):
            a = self.iniciar_thread(self.executar)
            b = self.iniciar_thread(lambda: self.executar(WebTC420("segunda-simulada")))
            ra, ea = self.terminar(a)
            rb, eb = self.terminar(b)
        self.assertEqual((["simulado"], [], [], [erro]), (ra, ea, rb, eb))
        a, b = self.operacoes()
        self.assertNotEqual(a["operacao_id"], b["operacao_id"])
        self.assertEqual(a["geracao_id"], b["geracao_id"])
        self.assertEqual(("retorno", "falha"), (a["resultado"], b["resultado"]))

    def test_11_corrida_b_login_automatico_e_promocao_concorrentes(self):
        barreira = threading.Barrier(2)
        erro = requests.Timeout("simulada")
        def enviar(url, **kwargs):
            barreira.wait(3)
            if "automatico" in url:
                raise erro
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=enviar):
            a = self.iniciar_thread(self.executar)
            b = self.iniciar_thread(lambda: self.infra.executar_login_automatico(
                WebTC420("automatico-simulado"), "simulado", "simulado"))
            ra, ea = self.terminar(a)
            rb, eb = self.terminar(b)
        self.assertEqual((["simulado"], [], [], [erro]), (ra, ea, rb, eb))
        a, b = self.operacoes()
        self.assertNotEqual(a["operacao_id"], b["operacao_id"])
        self.assertNotEqual(a["geracao_id"], b["geracao_id"])
        self.assertEqual(self.dono.geracao_id, a["geracao_id"])
        self.assertEqual(("retorno", "falha"), (a["resultado"], b["resultado"]))

    def test_12_auxiliar_comum_nao_duplica_manual_ou_automatico(self):
        with self.transporte() as adaptador:
            self.assertIsNotNone(self.fixture.monitores[0].ao_promover("simulado", "simulado", "simulado"))
            self.assertIsNotNone(self.promover())
        self.assertEqual(2, len(adaptador.enviados))
        self.assertEqual(["login", "approval"] * 2, [op["operacao"] for op in self.operacoes()])
        self.assertEqual({self.dono.geracao_id}, {op["geracao_id"] for op in self.operacoes()})
        self.assertTrue(all(op["execucao_resolvida"] for op in self.operacoes()))

    def test_13_corrida_c_promocao_e_novo_leitor_sem_reatribuicao(self):
        entrou, liberar = threading.Event(), threading.Event()
        with self.transporte(antes=lambda: self.bloquear(entrou, liberar)):
            tarefa = self.iniciar_thread(self.promover)
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.operacoes()[0]
                self.registro.promover(self.dono.geracao_id)
                self.fixture.iniciar_cliente(self.infra)
                self.assertNotEqual(self.dono.geracao_id, self.fixture.leitores[1].recursos_cliente.geracao_id)
                self.assertIs(self.registro, self.fixture.monitores[1].infraestrutura_cliente.registro_http)
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertIsNotNone(resultados[0])
        depois = self.operacoes()[0]
        for campo in ("operacao_id", "geracao_id", "atividade_id"):
            self.assertEqual(antes[campo], depois[campo])
        self.assertEqual("principal", depois["modo_atual"])
        self.assertEqual("retorno", depois["resultado"])

    def test_14_resposta_recebida_close_falho_nao_confirma_limpeza(self):
        erro = OSError("limpeza_simulada")
        with self.transporte() as adaptador:
            adaptador.close = Mock(side_effect=erro)
            with self.assertRaises(OSError) as capturado:
                self.executar()
        self.assertIs(erro, capturado.exception)
        self.assertEqual(1, adaptador.corpo.lidos)
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.negativo()

    def test_15_approval_pendente_cobertura_incompleta(self):
        with self.transporte():
            self.executar()
        antes = self.registro.obter_retrato()
        with self.transporte(b"SUCCESS:APPROVAL:simulado") as adaptador:
            self.assertEqual("simulado", self.web.approval())
        self.assertEqual("GET", adaptador.enviados[0][0].method)
        self.assertEqual(antes, self.registro.obter_retrato())
        self.negativo()

    def test_16_global_nao_confirmado_mesmo_registros_fechados(self):
        with self.transporte():
            self.executar()
        self.registro.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_17_corrida_a_reserva_antes_fechamento_termina_depois(self):
        reservada, enviar, liberar_partida, liberar_rede = [threading.Event() for _ in range(4)]
        executar = self.registro.executar
        def atrasar(op, chamada):
            self.bloquear(reservada, liberar_partida)
            return executar(op, chamada)
        with self.transporte(antes=lambda: self.bloquear(enviar, liberar_rede)), \
                patch.object(self.registro, "executar", side_effect=atrasar):
            tarefa = self.iniciar_thread(self.executar)
            try:
                self.assertTrue(reservada.wait(3))
                antes = self.operacoes()[0]
                self.assertEqual("reservada", antes["estado"])
                self.registro.fechar_admissao()
                liberar_partida.set()
                self.assertTrue(enviar.wait(3))
                self.assertFalse(self.registro.obter_retrato()["conjunto_http_resolvido"])
                self.assertEqual("em_andamento", self.operacoes()[0]["estado"])
            finally:
                liberar_partida.set()
                liberar_rede.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual((["simulado"], []), (resultados, erros))
        self.assertEqual(antes["operacao_id"], self.operacoes()[0]["operacao_id"])
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])

    def test_18_duplicada_idempotente_e_conflito_retido(self):
        publicar = self.registro.publicar
        def duplicar(op, recibo):
            self.assertTrue(publicar(op, recibo))
            return publicar(op, recibo)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=duplicar):
            self.executar()
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        def conflitar(op, recibo):
            publicar(op, recibo)
            outro = self.registro.preparar_publicacao(op, erro=OSError())
            return publicar(op, outro)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=conflitar):
            with self.assertRaisesRegex(RuntimeError, "publicacao_conflitante"):
                self.executar()
        op = self.operacoes()[1]
        self.assertEqual("retorno", op["publicacao_original"]["resultado"])
        self.assertFalse(op["execucao_resolvida"])

    def test_19_erro_original_preservado_se_publicacao_falhar(self):
        original = requests.Timeout("simulada")
        with self.transporte(erro=original), patch.object(self.registro, "publicar", side_effect=ValueError()):
            with self.assertRaises(requests.Timeout) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertTrue(self.operacoes()[0]["erros_execucao"])
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])

    def test_20_origem_de_outra_aplicacao_recusada(self):
        outro = RecursosLeitorCliente(InfraestruturaRegistrosCliente())
        with patch("requests.post") as enviar:
            with self.assertRaisesRegex(ValueError, "origem_http_invalida"):
                self.executar(dono=outro)
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())

    def test_21_execucao_fora_locks_e_retrato_sem_dados(self):
        def antes():
            for registro in (self.registro, self.infra.registro_recursos, self.infra.registro_retentativas):
                adquiriu = registro._lock.acquire(blocking=False)
                self.assertTrue(adquiriu)
                if adquiriu:
                    registro._lock.release()
            self.assertEqual("em_andamento", self.operacoes()[0]["estado"])
        with self.transporte(b"SUCCESS:LOGIN:simulado:marcador-resultado", antes=antes):
            self.executar()
        texto = repr(self.registro.obter_retrato())
        for proibido in ("marcador-resultado", "https://", "uname", "pwd", "balanca-simulada"):
            self.assertNotIn(proibido, texto)

    def test_22_refresh_principal_fora_registro_cliente(self):
        with self.transporte():
            self.executar()
        antes = self.registro.obter_retrato()
        with self.transporte(b"SUCCESS:REFRESH:simulado"):
            self.assertEqual("simulado", self.web.refresh())
        self.assertEqual(antes, self.registro.obter_retrato())

    def test_23_descoberta_positiva_nao_cria_operacao(self):
        self.fixture.env["buscar_servidor"].return_value = "principal-simulado"
        with patch("requests.post") as enviar:
            self.assertIsNone(self.promover())
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())

    def test_24_recurso_anterior_pendente_permanece(self):
        recursos = self.infra.registro_recursos
        token = recursos.reservar("arquivo_comum", self.dono.geracao_id, self.dono.atividade_id)
        recursos.criar(token, lambda: SimpleNamespace(closed=False, close=Mock(side_effect=OSError())))
        with self.assertRaises(OSError):
            recursos.fechar(token)
        antes = recursos.obter_retrato()
        with self.transporte():
            self.executar()
        self.assertEqual(antes, recursos.obter_retrato())
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.negativo()


if __name__ == "__main__":
    unittest.main()

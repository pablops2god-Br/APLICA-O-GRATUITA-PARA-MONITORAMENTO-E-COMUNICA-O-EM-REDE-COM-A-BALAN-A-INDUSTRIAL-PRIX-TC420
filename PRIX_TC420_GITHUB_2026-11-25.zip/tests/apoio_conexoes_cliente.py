# Apoio aos testes: fornece utilitários para controlar as dependências de conexão dos cenários.
"""Transporte já registrado para regressões do loop, sem DNS ou rede real.

Os ensaios específicos de conectar_tcp exercitam a resolução/fábricas reais
com getaddrinfo/socket falsos; este apoio isola os fluxos anteriores do leitor.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from unittest.mock import Mock, patch

from rede.admissao_register_cliente import RecursosRegisterCliente
from rede.admissao_config_cliente import RecursosConfigCliente


@contextmanager
def conectores_tcp_controlados(dono, conectar):
    """Mesmo transporte para CONFIG e REGISTER; reserva pelo adaptador real."""
    atual = ContextVar('adaptador_tcp_simulado', default=dono)
    chamadas = Mock(side_effect=lambda endereco, *, timeout:
                    conectar(atual.get(), endereco, timeout=timeout))
    def conectar_register(adaptador, endereco, *, timeout):
        contexto = atual.set(adaptador)
        try:
            return chamadas(endereco, timeout=timeout)
        finally:
            atual.reset(contexto)
    def conectar_config(adaptador, endereco, *, timeout):
        # Este apoio substitui o transporte; a autorização continua sendo real.
        with adaptador._escopo_endereco(endereco) as tentativa:
            contexto = atual.set(tentativa)
            try:
                return chamadas(endereco, timeout=timeout)
            finally:
                atual.reset(contexto)
    with patch.object(dono, 'conectar_tcp', new=chamadas), \
            patch.object(RecursosRegisterCliente, 'conectar_tcp', new=conectar_register), \
            patch.object(RecursosConfigCliente, 'conectar_tcp', new=conectar_config):
        yield chamadas


@contextmanager
def conexoes_tcp_simuladas(dono, resultados):
    sequencia = iter(resultados)

    def conectar(adaptador, endereco, *, timeout):
        resultado = next(sequencia)
        if isinstance(resultado, BaseException):
            raise resultado
        return adaptador.abrir_socket(lambda: resultado)

    with conectores_tcp_controlados(dono, conectar) as conectar_falso:
        yield conectar_falso

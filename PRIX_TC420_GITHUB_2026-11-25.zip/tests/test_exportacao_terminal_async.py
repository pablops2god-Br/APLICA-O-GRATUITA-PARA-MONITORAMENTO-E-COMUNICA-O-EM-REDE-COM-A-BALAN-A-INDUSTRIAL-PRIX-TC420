"""Exportação real em diretório temporário; workers reais e Tk controlado."""
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Event, get_ident
import unittest
from unittest.mock import Mock, patch

from interface.ciclo_tk import ciclo
from interface.janela import JanelaTC420
from interface.saida_aplicacao import SaidaAplicacao
from rede.servidor import RegistroTentativasAplicacao
import interface.registro_terminal as terminal
from test_interface_b3 import Raiz


class ExportacaoTerminalAsync(unittest.TestCase):
    def setUp(self):
        self.registro = terminal._RegistroTerminal(limite_linhas=2, limite_caracteres=100)
        self.registro.acrescentar('antiga\nrecente 1\nrecente 2\n')
        self.raiz = Raiz()
        self.saida = SaidaAplicacao(prazo=2, intervalo=.005)
        self.saida.configurar(registro=RegistroTentativasAplicacao())
        self.callback_saida = self.saida.vincular('exportacao')
        self.janela = JanelaTC420.__new__(JanelaTC420)
        self.janela.root = self.raiz
        self.janela.saida_aplicacao = self.saida
        self.eventos = []
        self.pasta = TemporaryDirectory()
        self.destino = Path(self.pasta.name) / 'registro.txt'
        self.addCleanup(self.pasta.cleanup)
        self.addCleanup(self.limpar)
        for p in (
            patch.object(terminal, '_registro', self.registro),
            patch('interface.janela.filedialog.asksaveasfilename', return_value=str(self.destino)),
            patch('interface.janela.messagebox.showinfo', side_effect=lambda *a, **k: self.raiz.usar()),
            patch('interface.janela.messagebox.showerror', side_effect=lambda *a, **k: self.raiz.usar()),
        ):
            p.start()
            self.addCleanup(p.stop)

    def limpar(self):
        for evento in self.eventos:
            evento.set()
        for item in self.saida._threads:
            item['thread'].join(2)
            self.assertFalse(item['thread'].is_alive())
        if self.saida._coordenacao is not None:
            self.saida._coordenacao.join(2)

    def terminar(self):
        for item in self.saida._threads:
            item['thread'].join(2)
            self.assertFalse(item['thread'].is_alive())
        ciclo(self.janela).consumir()

    def bloquear_gravacao(self):
        entrou, liberar = Event(), Event()
        self.eventos.append(liberar)
        original = Path.write_text
        ids = []
        def gravar(caminho, texto, **kwargs):
            ids.append(get_ident())
            entrou.set()
            liberar.wait(2)
            return original(caminho, texto, **kwargs)
        return patch('interface.janela.Path.write_text', autospec=True, side_effect=gravar), entrou, liberar, ids

    def test_exporta_somente_retido_e_informa_cortes_no_arquivo_e_dialogo(self):
        self.assertTrue(self.janela.exportar_log())
        self.terminar()
        texto = self.destino.read_text(encoding='utf-8')
        self.assertIn('HISTÓRICO PARCIAL', texto)
        self.assertTrue(texto.endswith('recente 1\nrecente 2\n'))
        self.assertNotIn('antiga\n', texto)
        from interface.janela import messagebox
        self.assertIn('parcial', messagebox.showinfo.call_args.args[1])
        messagebox.showerror.assert_not_called()

    def test_gravacao_bloqueada_nao_ocupa_tk_e_clique_duplicado_nao_cria_worker(self):
        bloqueio, entrou, liberar, ids = self.bloquear_gravacao()
        with bloqueio:
            self.assertTrue(self.janela.exportar_log())
            self.assertTrue(entrou.wait(1))
            self.raiz.usar()  # Thread da interface permanece disponível durante a gravação.
            self.assertNotEqual(get_ident(), ids[0])
            self.assertFalse(self.janela.exportar_log())
            self.assertEqual(1, len(self.saida._threads))
            liberar.set()
            self.terminar()
        self.assertEqual([], self.raiz.violacoes)

    def test_saida_b2_aguarda_exportacao_sem_aplicar_dialogo_tardio(self):
        bloqueio, entrou, liberar, _ids = self.bloquear_gravacao()
        concluir = Mock()
        self.saida.conectar_interface(
            self.callback_saida, self.janela.agendar_saida, concluir)
        with bloqueio:
            self.janela.exportar_log()
            self.assertTrue(entrou.wait(1))
            self.assertTrue(self.callback_saida())
            self.assertFalse(self.saida.obter_situacao()['parada_operacional_confirmada'])
            concluir.assert_not_called()
            liberar.set()
            self.saida._coordenacao.join(2)
            self.assertTrue(self.saida.obter_situacao()['parada_operacional_confirmada'])
            for identidade, callback in list(self.raiz.callbacks.items()):
                self.raiz.callbacks.pop(identidade, None)
                callback()
        concluir.assert_called_once()
        from interface.janela import messagebox
        messagebox.showinfo.assert_not_called()
        self.assertTrue(self.destino.is_file())

    def test_erro_de_gravacao_aparece_no_tk_sem_mensagem_bruta(self):
        with patch('interface.janela.Path.write_text', side_effect=OSError('pwd=entrada-sintetica')):
            self.assertTrue(self.janela.exportar_log())
            self.terminar()
        from interface.janela import messagebox
        messagebox.showinfo.assert_not_called()
        messagebox.showerror.assert_called_once()
        self.assertNotIn('entrada-sintetica', repr(messagebox.showerror.call_args))
        self.assertEqual([], self.raiz.violacoes)

    def test_cancelamento_do_seletor_nao_inicia_worker(self):
        with patch('interface.janela.filedialog.asksaveasfilename', return_value=''):
            self.assertFalse(self.janela.exportar_log())
        self.assertEqual([], self.saida._threads)
        self.assertFalse(self.destino.exists())

    def test_janela_destruida_descarta_resultado_sem_dialogo(self):
        bloqueio, entrou, liberar, _ids = self.bloquear_gravacao()
        with bloqueio:
            self.janela.exportar_log()
            self.assertTrue(entrou.wait(1))
            ciclo(self.janela).fechar()
            self.raiz.destroy()
            liberar.set()
            self.terminar()
        from interface.janela import messagebox
        messagebox.showinfo.assert_not_called()
        messagebox.showerror.assert_not_called()
        self.assertEqual([], self.raiz.violacoes)


if __name__ == '__main__':
    unittest.main()

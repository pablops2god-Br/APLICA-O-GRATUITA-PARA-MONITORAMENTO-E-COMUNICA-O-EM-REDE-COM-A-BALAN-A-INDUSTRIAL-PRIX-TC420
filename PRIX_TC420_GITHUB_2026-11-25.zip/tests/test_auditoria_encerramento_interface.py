# Testes de auditoria encerramento interface: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Modelo proposto e achados executáveis do código atual, sem Tk ou rede."""
import ast
import threading
import unittest
from pathlib import Path
from types import MethodType, SimpleNamespace
from unittest.mock import Mock, patch

from prototipos.estados_encerramento_interface import ModeloEncerramentoInterface
from rede import servidor


RAIZ = Path(__file__).resolve().parents[1]


# Grupo de 19 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class EstadosEncerramento(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.registro = servidor.RegistroTentativasAplicacao()
        self.modelo = ModeloEncerramentoInterface(self.registro)
        self.controle = servidor.ControleCicloServidor()
        remendo = patch.object(servidor, "controle_ciclo_servidor", self.controle)
        remendo.start()
        self.addCleanup(remendo.stop)

    def tentativa(self, estado="iniciada"):
        contexto = servidor.ContextoCicloServidor()
        chave = self.registro.admitir(contexto)
        self.registro.marcar_iniciando(chave)
        if estado == "iniciada":
            self.registro.registrar_entrada_execucao(chave)
            self.registro.marcar_iniciada(chave)
        return chave, contexto

    def ciclo(self, contexto, pendencia_socket=False, retornar=True):
        workers = servidor.RegistroTrabalhadores()
        self.assertTrue(self.controle.tentar_iniciar(workers))
        contexto.registrar_reserva(workers.ciclo_id)
        if pendencia_socket:
            workers.reservar_criacao_socket()
        workers.bloquear_criacao()
        self.controle.finalizar(workers)
        if retornar:
            contexto.registrar_retorno_coordenador()
        return workers

    def consultar(self, recursos=None):
        self.modelo.atualizar_evidencias(recursos_confirmados=recursos)
        return self.modelo.obter_retrato()

    def test_01_sem_servidor(self):
        self.modelo.solicitar("sim")
        retrato = self.consultar()
        self.assertTrue(retrato["tentativas_confirmadas"])
        self.assertIsNone(retrato["recursos_confirmados"])
        self.assertFalse(self.modelo.registrar_destruicao_simulada())

    def test_02_servidor_ativo(self):
        _, contexto = self.tentativa()
        self.ciclo(contexto, retornar=False)
        self.modelo.solicitar("sim")
        self.assertFalse(self.consultar(True)["tentativas_confirmadas"])
        self.assertFalse(self.modelo.registrar_destruicao_simulada())

    def test_03_durante_promocao(self):
        self.tentativa("iniciando")
        self.modelo.solicitar("sim")
        self.assertFalse(self.consultar(True)["janela_destruida"])
        self.assertFalse(self.registro.admitir(servidor.ContextoCicloServidor()))

    def test_04_durante_partida(self):
        chave, contexto = self.tentativa("iniciando")
        self.modelo.solicitar("sim")
        self.assertFalse(self.consultar(True)["tentativas_confirmadas"])
        self.assertIs(self.registro.obter_retrato()["tentativas"][0].contexto, contexto)
        self.registro.registrar_entrada_execucao(chave)
        self.registro.marcar_iniciada(chave)
        self.ciclo(contexto)
        self.assertTrue(self.consultar()["tentativas_confirmadas"])
        self.assertFalse(self.modelo.registrar_destruicao_simulada())

    def test_05_handler_ativo(self):
        _, contexto = self.tentativa()
        workers = servidor.RegistroTrabalhadores()
        self.controle.tentar_iniciar(workers)
        contexto.registrar_reserva(workers.ciclo_id)
        liberar = threading.Event()
        worker = threading.Thread(target=lambda: liberar.wait(3))
        try:
            workers.registrar_e_iniciar(worker)
            workers.bloquear_criacao()
            self.controle.finalizar(workers)
            contexto.registrar_retorno_coordenador()
            self.modelo.solicitar("sim")
            self.assertFalse(self.consultar(True)["tentativas_confirmadas"])
        finally:
            liberar.set()
            worker.join(3)
            self.assertFalse(worker.is_alive())

    def test_06_socket_pendente(self):
        _, contexto = self.tentativa()
        self.ciclo(contexto, pendencia_socket=True)
        self.modelo.solicitar("sim")
        self.assertFalse(self.consultar(True)["tentativas_confirmadas"])

    def test_07_erro_limpeza(self):
        _, contexto = self.tentativa()
        workers = servidor.RegistroTrabalhadores()
        self.controle.tentar_iniciar(workers)
        contexto.registrar_reserva(workers.ciclo_id)
        workers.registrar_erro_limpeza("falha_simulada")
        workers.bloquear_criacao()
        self.controle.finalizar(workers)
        contexto.registrar_retorno_coordenador()
        self.modelo.solicitar("sim")
        self.assertFalse(self.consultar(True)["tentativas_confirmadas"])

    def test_08_repeticao(self):
        self.assertTrue(self.modelo.solicitar("sim"))
        self.assertFalse(self.modelo.solicitar("sim"))
        self.assertEqual(self.modelo.obter_retrato()["sequencias_parada_modeladas"], 1)

    def test_09_cancelar_e_nao(self):
        for opcao in ("cancelar", "nao"):
            self.assertFalse(self.modelo.solicitar(opcao))
        self.assertEqual(self.modelo.obter_retrato()["estado"], "aberta")
        self.assertFalse(self.registro.obter_retrato()["admissao_fechada"])

    def test_10_antiga_pendente(self):
        _, antiga = self.tentativa("iniciando")
        _, nova = self.tentativa()
        self.ciclo(nova)
        self.modelo.solicitar("sim")
        self.assertFalse(self.consultar(True)["tentativas_confirmadas"])
        self.assertIs(self.registro.obter_retrato()["tentativas"][0].contexto, antiga)

    def test_11_retorno_antes_limpeza(self):
        _, contexto = self.tentativa()
        self.ciclo(contexto, pendencia_socket=True)
        self.assertTrue(contexto.coordenador_retornou.is_set())
        self.modelo.solicitar("sim")
        self.assertFalse(self.consultar(True)["tentativas_confirmadas"])

    def test_12_agregado_e_so_evidencia(self):
        _, contexto = self.tentativa()
        self.ciclo(contexto)
        self.modelo.solicitar("sim")
        self.assertTrue(self.consultar()["tentativas_confirmadas"])
        self.assertFalse(self.modelo.registrar_destruicao_simulada())

    def test_13_recurso_externo_desconhecido(self):
        self.modelo.solicitar("sim")
        for evidencia in (None, False, 1):
            self.consultar(evidencia)
            self.assertFalse(self.modelo.registrar_destruicao_simulada())

    def test_14_consulta_falha(self):
        self.modelo.solicitar("sim")
        self.modelo.atualizar_evidencias(recursos_confirmados=True, avaliar=Mock(side_effect=RuntimeError()))
        self.assertEqual(self.modelo.obter_retrato()["estado"], "erro_consulta")
        self.assertFalse(self.modelo.registrar_destruicao_simulada())

    def test_15_atualizacao_tardia(self):
        geracao_antiga = self.modelo.obter_retrato()["geracao_interface"]
        self.modelo.solicitar("sim")
        self.assertFalse(self.modelo.registrar_atualizacao_simulada(geracao_antiga))
        atual = self.modelo.obter_retrato()["geracao_interface"]
        self.assertTrue(self.modelo.registrar_atualizacao_simulada(atual))
        self.consultar(True)
        self.assertTrue(self.modelo.registrar_destruicao_simulada())
        self.assertFalse(self.modelo.registrar_atualizacao_simulada(atual))

    def test_16_espera_prolongada_interface_simulada(self):
        self.modelo.solicitar("sim")
        entrou = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        def avaliar(registro):
            entrou.wait()
            liberar.wait()
            return servidor.avaliar_encerramento_aplicacao(registro)
        thread = threading.Thread(target=lambda: self.modelo.atualizar_evidencias(avaliar=avaliar))
        thread.start()
        try:
            entrou.wait()
            for _ in range(100):
                self.assertTrue(self.modelo.registrar_pulso_interface())
            self.assertFalse(self.modelo.registrar_destruicao_simulada())
        finally:
            liberar.wait()
            thread.join(5)
            self.assertFalse(thread.is_alive())
        self.assertEqual(self.modelo.obter_retrato()["pulsos_interface"], 100)

    def test_17_critico_a_promocao_concorrente(self):
        for admitir_primeiro in (False, True):
            with self.subTest(admitir_primeiro=admitir_primeiro):
                self.registro = servidor.RegistroTentativasAplicacao()
                self.modelo = ModeloEncerramentoInterface(self.registro)
                pronta = threading.Barrier(2, timeout=5)
                liberar = threading.Barrier(2, timeout=5)
                contexto = servidor.ContextoCicloServidor()
                ids = []
                def promover():
                    if admitir_primeiro:
                        ids.append(self.registro.admitir(contexto))
                    pronta.wait()
                    liberar.wait()
                    if not admitir_primeiro:
                        ids.append(self.registro.admitir(contexto))
                    elif ids[0] is not None:
                        self.registro.marcar_iniciando(ids[0])
                thread = threading.Thread(target=promover)
                thread.start()
                try:
                    pronta.wait()
                    self.modelo.solicitar("sim")
                    self.assertEqual(len(self.registro.obter_retrato()["tentativas"]), int(admitir_primeiro))
                finally:
                    liberar.wait()
                    thread.join(5)
                    self.assertFalse(thread.is_alive())
                self.assertEqual(ids[0] is not None, admitir_primeiro)
                self.assertFalse(self.consultar()["janela_destruida"])
                if admitir_primeiro:
                    self.assertFalse(self.modelo.obter_retrato()["tentativas_confirmadas"])

    def test_18_critico_b_coordenador_antes_recursos(self):
        _, contexto = self.tentativa()
        workers = self.ciclo(contexto, pendencia_socket=True)
        reserva = next(iter(workers._reservas_socket.values())).reserva
        self.modelo.solicitar("sim")
        pronta = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        def resolver():
            pronta.wait()
            liberar.wait()
            workers.resolver_falha_criacao_socket(reserva, sem_alocacao_comprovada=True)
        thread = threading.Thread(target=resolver)
        thread.start()
        try:
            pronta.wait()
            self.assertFalse(self.consultar()["tentativas_confirmadas"])
        finally:
            liberar.wait()
            thread.join(5)
            self.assertFalse(thread.is_alive())
        self.assertTrue(self.consultar()["tentativas_confirmadas"])
        self.assertFalse(self.modelo.registrar_destruicao_simulada())

    def test_19_critico_c_solicitacoes_simultaneas(self):
        barreira = threading.Barrier(3, timeout=5)
        resultados = []
        def solicitar():
            barreira.wait()
            resultados.append(self.modelo.solicitar("sim"))
        threads = [threading.Thread(target=solicitar) for _ in range(2)]
        for thread in threads:
            thread.start()
        barreira.wait()
        for thread in threads:
            thread.join(5)
            self.assertFalse(thread.is_alive())
        self.assertEqual(sorted(resultados), [False, True])
        self.assertEqual(self.modelo.obter_retrato()["sequencias_parada_modeladas"], 1)


def carregar_metodos(caminho, nomes, ambiente):
    arvore = ast.parse((RAIZ / caminho).read_text(encoding="utf-8"))
    metodos = [n for n in ast.walk(arvore) if isinstance(n, ast.FunctionDef) and n.name in nomes]
    exec(compile(ast.Module(body=metodos, type_ignores=[]), caminho, "exec"), ambiente)
    return ambiente


# Grupo de 6 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class FluxoAtualAuditado(unittest.TestCase):
    def monitor(self, resposta, callback):
        ambiente = carregar_metodos("interface/janela.py", {
            "confirmar_fechamento", "fechar", "concluir_fechamento", "atualizar_peso"},
            dict(messagebox=SimpleNamespace(askyesnocancel=lambda **kwargs: resposta), print=lambda *args: None))
        monitor = SimpleNamespace(executando=True, ao_fechar=callback,
                                  root=Mock(), balanca=Mock(), label_peso=Mock())
        for nome in ("confirmar_fechamento", "fechar", "concluir_fechamento", "atualizar_peso"):
            setattr(monitor, nome, MethodType(ambiente[nome], monitor))
        return monitor

    def conexao(self, servidor_iniciado=False):
        from interface.saida_aplicacao import SaidaAplicacao
        nomes = {"iniciar_tentativa_encerramento", "encerrar_aplicacao", "verificar_finalizacao",
                 "concluir_encerramento_confirmado"}
        ambiente = carregar_metodos("interface/conexao.py", nomes,
                                    dict(threading=threading, print=lambda *args: None))
        janela = SimpleNamespace(
            root=Mock(), lock_encerramento=threading.Lock(), estado_encerramento="aberto",
            servidor_iniciado=servidor_iniciado, servidor_encerrado=threading.Event(),
            encerramento_solicitado=threading.Event(), finalizacao_concluida=threading.Event(),
            finalizacao_confirmada=False, verificacao_finalizacao_ativa=False,
            thread_finalizacao=None, leitor_rebaixado=None)
        for nome in nomes:
            setattr(janela, nome, MethodType(ambiente[nome], janela))
        janela.saida_aplicacao = SaidaAplicacao()
        janela._callback_saida = janela.saida_aplicacao.vincular(
            'conexao_manual', lambda: janela.encerrar_aplicacao(_encaminhada=True))
        return janela

    def test_20_sim_sem_callback_nao_fecha(self):
        monitor = self.monitor(True, None)
        monitor.confirmar_fechamento()
        monitor.root.destroy.assert_not_called()
        self.assertTrue(monitor.executando)

    def test_21_sim_nao_cancelar_com_callback(self):
        for resposta in (True, False, None):
            callback = Mock()
            monitor = self.monitor(resposta, callback)
            monitor.confirmar_fechamento()
            self.assertEqual(callback.call_count, int(resposta is True))
            monitor.root.destroy.assert_not_called()
            monitor.root.withdraw.assert_not_called()

    def test_22_fechamento_atual_nao_fecha_admissao(self):
        registro = servidor.RegistroTentativasAplicacao()
        janela = self.conexao()
        janela.registro_tentativas = registro
        janela.encerrar_aplicacao()
        janela.verificar_finalizacao()
        janela.root.destroy.assert_not_called()
        self.assertTrue(janela.saida_aplicacao.obter_situacao()['solicitada'])
        self.assertFalse(janela.saida_aplicacao.obter_situacao()['encerramento_confirmado'])
        self.assertFalse(registro.obter_retrato()["admissao_fechada"])

    def test_23_evento_legado_nao_autoriza_saida_b1(self):
        registro = servidor.RegistroTentativasAplicacao()
        registro.admitir(servidor.ContextoCicloServidor())
        registro.fechar_admissao()
        self.assertFalse(servidor.avaliar_encerramento_aplicacao(registro)["encerramento_confirmado"])
        janela = self.conexao(servidor_iniciado=True)
        janela.servidor_encerrado.set()
        janela.verificar_finalizacao()
        janela.root.destroy.assert_not_called()
        self.assertEqual('encerramento_pendente_b2', janela.estado_encerramento)

    def test_24_b1_nao_alcanca_destroy_sem_b2(self):
        janela = self.conexao()
        janela.root.destroy.side_effect = RuntimeError("simulado")
        self.assertFalse(janela.concluir_encerramento_confirmado())
        self.assertEqual(janela.estado_encerramento, "aberto")
        janela.concluir_encerramento_confirmado()
        janela.root.destroy.assert_not_called()

    def test_25_callback_atual_sem_guarda_de_widget(self):
        monitor = self.monitor(None, None)
        monitor.executando = False
        monitor.label_peso.config.side_effect = RuntimeError("widget simulado destruido")
        monitor.atualizar_peso("1")
        monitor.label_peso.config.assert_not_called()


if __name__ == "__main__":
    unittest.main()

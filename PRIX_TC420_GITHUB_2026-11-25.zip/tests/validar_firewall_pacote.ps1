# Testa somente planos e metadados de cmdlets. Nao cria/remove regras nem pede UAC.
$ErrorActionPreference = 'Stop'
$raizPrix = Split-Path -Parent $PSScriptRoot
$scriptPrix = Join-Path $raizPrix 'empacotamento\Rede-PRIX-TC420.ps1'
$exePrix = Join-Path $raizPrix 'dist\PRIX_TC420\PRIX_TC420.exe'
function Plano-Prix([string]$acaoPrix, [bool]$publicaPrix) {
    $argsPrix = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $scriptPrix,
                  '-Executavel', $exePrix, '-Acao', $acaoPrix, '-Simular')
    if ($publicaPrix) { $argsPrix += '-IncluirPublica' }
    $textoPrix = & powershell @argsPrix
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao simular plano.' }
    return ($textoPrix | ConvertFrom-Json)
}
$privadoPrix = Plano-Prix 'Configurar' $false
$publicoPrix = Plano-Prix 'Configurar' $true
$remocaoPrix = Plano-Prix 'Remover' $false
if (($privadoPrix.Perfis -join ',') -ne 'Private') { throw 'Perfil privado incorreto.' }
if (($publicoPrix.Perfis -join ',') -ne 'Private,Public') { throw 'Perfil publico incorreto.' }
if ($privadoPrix.Remotos -ne 'LocalSubnet' -or $privadoPrix.Direcao -ne 'Inbound') { throw 'Escopo incorreto.' }
if ($privadoPrix.Regras.Count -ne 2) { throw 'Quantidade de regras incorreta.' }
if ($privadoPrix.Regras[0].Protocol -ne 'TCP' -or $privadoPrix.Regras[0].LocalPort -ne 42100) { throw 'TCP incorreto.' }
if ($privadoPrix.Regras[1].Protocol -ne 'UDP' -or $privadoPrix.Regras[1].LocalPort -ne 42101) { throw 'UDP incorreto.' }
if (($privadoPrix.Regras.Name -join ',') -ne ($remocaoPrix.Regras.Name -join ',')) { throw 'Remocao fora de escopo.' }
$camposPrix = @('Name','NewDisplayName','Program','Direction','Action','Enabled','Profile','Protocol',
                'LocalPort','RemoteAddress','EdgeTraversalPolicy','PolicyStore')
$setsPrix = (Get-Command Set-NetFirewallRule).ParameterSets
if (-not ($setsPrix | Where-Object {
    $nomesPrix = $_.Parameters.Name
    @($camposPrix | Where-Object { $_ -notin $nomesPrix }).Count -eq 0
})) { throw 'Parametros de atualizacao incompativeis.' }
Write-Host 'Planos privado/publico, portas, escopo, remocao e parametros de atualizacao OK. Firewall inalterado.'

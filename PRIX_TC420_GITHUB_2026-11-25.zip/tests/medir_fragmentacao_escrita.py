"""2B.8: escrita, fragmentação e grafo misto; execução explícita, sem rede.

Latências sem tracemalloc; memória em construção separada sem guardar timings.
Threads da carga mista são realmente iniciadas e unidas, sockets são dublês.
"""
from array import array
from collections import defaultdict
import gc
import hashlib
import json
import math
from pathlib import Path
import platform
import random
import statistics
import sys
import threading
import time
import tracemalloc
import argparse

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rede import servidor as s
from prototipos.identidades_intervalos import RegistroIntervalosExperimental
from prototipos.identidades_intervalos import ArmazenamentoIntervalos
from prototipos.consultas_intervalos import RegistroConsultasExperimental
from medir_consultas_intervalos import LockMedido, perfil

BACKENDS = dict(atual=s.RegistroTrabalhadores, **{'2B6': RegistroIntervalosExperimental,
                                               '2B7': RegistroConsultasExperimental})


class SocketSimulado:
    def __init__(self):
        self.fechado = False
    def fileno(self):
        return -1 if self.fechado else 1
    def close(self):
        self.fechado = True


def estatistica(valores):
    ordenados = sorted(valores)
    def percentil(p):
        return ordenados[max(0, math.ceil(p*len(ordenados))-1)]
    return dict(n=len(ordenados), mediana_s=statistics.median(ordenados),
        p95_s=percentil(.95), p99_s=percentil(.99), max_s=ordenados[-1])


def montar(versao, carga, medir_latencia=False):
    r = BACKENDS[versao]()
    amostras = defaultdict(lambda: [array('d'), array('d'), array('d')])
    if medir_latencia:
        r.lock = LockMedido()
    pico_faixas = 0
    def chamar(nome, funcao, *args, **kwargs):
        nonlocal pico_faixas
        if not medir_latencia:
            resposta = funcao(*args, **kwargs)
        else:
            r.lock.registros.clear()
            inicio = time.perf_counter()
            resposta = funcao(*args, **kwargs)
            duracao = time.perf_counter()-inicio
            registros = r.lock.registros
            grupo = amostras[nome]
            grupo[0].append(duracao)
            grupo[1].append(sum(e for e, _ in registros))
            grupo[2].append(sum(h for _, h in registros))
        if versao != 'atual':
            pico_faixas = max(pico_faixas, len(r._reservas_socket.intervalos))
        return resposta
    def reserva():
        return chamar('reservar', r.reservar_criacao_socket)
    def resolver(t, nome='resolver_sem_recurso', prova=True):
        return chamar(nome, r.resolver_falha_criacao_socket, t, sem_alocacao_comprovada=prova)
    def thread_encerrada(numero):
        t = threading.Thread(target=lambda: None, name=f'ensaio-{numero}')
        assert chamar('registrar_start_thread', r.registrar_e_iniciar, t)
        t.join(5)
        assert not t.is_alive() and t.ident is not None
    externos = []
    if carga == 'uniforme':
        for _ in range(50000):
            t = reserva()
            resolver(t)
        del t
    elif carga in ('inversa_fragmentada', 'ponte_fusao', 'aleatoria_tokens'):
        tokens = [reserva() for _ in range(50000)]
        if carga == 'aleatoria_tokens':
            ordem = list(range(50000))
            random.Random(280).shuffle(ordem)
            for i in ordem:
                resolver(tokens[i], prova=i % 2 == 0,
                         nome='resolver_sem_recurso' if i % 2 == 0 else 'resolver_incerta')
            externos = tokens
        else:
            for i in reversed(range(0, 50000, 2)):
                resolver(tokens[i], nome='resolver_fragmentar')
            for i in range(1, 50000, 2):
                if carga == 'ponte_fusao':
                    resolver(tokens[i], nome='resolver_fundir')
                else:
                    resolver(tokens[i], nome='resolver_incerta', prova=False)
    elif carga == 'mista_hora':
        sem_recurso = {k*15502//1779 for k in range(1779)}
        for i in range(3):
            thread_encerrada(i)
        sockets = 0
        for i in range(15502):
            t = reserva()
            if i in sem_recurso:
                resolver(t)
                continue
            sock = SocketSimulado()
            chamar('anexar', r.anexar_socket, t, sock)
            chamar('publicar', r.publicar_socket, t)
            sockets += 1
            if sockets > 2:
                chamar('iniciar_handler', r.iniciar_limpeza_handler, t)
                thread_encerrada(sockets)
                chamar('publicar_handler', r.publicar_limpeza_handler, t)
            chamar('encerrar_uso', r.encerrar_uso_socket, t)
            assert chamar('fechar', r.fechar_socket, t)
        del t, sock
        assert sockets == 13723 and len(r.threads) == 13724
    else:
        raise ValueError(carga)
    r.bloquear_criacao()
    # Só explicitamente preservados sobrevivem fora do registro.
    resumo = {nome: dict(total=estatistica(grupo[0]), espera_lock=estatistica(grupo[1]),
                        retencao_lock=estatistica(grupo[2])) for nome, grupo in amostras.items()}
    return r, externos, pico_faixas, resumo


def concorrencia(r, operacoes=200, forcar_sobreposicao=False):
    # Um leitor e um produtor competem sem espera artificial no lock.
    barreira = threading.Barrier(2)
    leitor_no_lock, produtor_tentando = threading.Event(), threading.Event()
    duracoes, erros = [], []
    r.lock = LockMedido()
    def hook():
        if threading.current_thread() is a and not leitor_no_lock.is_set():
            leitor_no_lock.set()
            if not produtor_tentando.wait(10):
                raise RuntimeError('produtor_nao_chegou')
    if forcar_sobreposicao:
        r.lock.hook = hook
    def leitor():
        try:
            barreira.wait(5)
            for _ in range(5):
                r.obter_situacao()
        except BaseException as e:
            erros.append(type(e).__name__)
    def produtor():
        try:
            barreira.wait(5)
            if forcar_sobreposicao and not leitor_no_lock.wait(10):
                raise RuntimeError('leitor_nao_chegou')
            for i in range(operacoes):
                inicio = time.perf_counter()
                if forcar_sobreposicao and i == 0:
                    produtor_tentando.set()
                t = r.reservar_criacao_socket()
                if t is not None:
                    r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True)
                duracoes.append(time.perf_counter()-inicio)
        except BaseException as e:
            erros.append(type(e).__name__)
    # Carga foi bloqueada para confirmar predicado. Reabrir só no harness de
    # medição, antes dos threads, sem modificar o método operacional de gate.
    r.criacao_bloqueada = False
    a, b = threading.Thread(target=leitor), threading.Thread(target=produtor)
    a.start(); b.start()
    a.join(30); b.join(30)
    assert not a.is_alive() and not b.is_alive() and not erros, erros
    registros = list(r.lock.registros)
    r.lock.hook = None
    r.bloquear_criacao()
    return dict(operacoes=operacoes, produtor=estatistica(duracoes),
        espera_aquisicoes=estatistica([e for e, _ in registros]),
        posse_aquisicoes=estatistica([h for _, h in registros]),
        sobreposicao_inicial_controlada=forcar_sobreposicao,
        observacao='Inclui 5 leituras; sincronizacao inicial opcional, nao e latencia de rede.')


def medir(versao, carga):
    gc.collect()
    inicio = time.perf_counter()
    r, externos, pico_faixas, escrita = montar(versao, carga, True)
    carga_s = time.perf_counter()-inicio
    lock_original = r.lock
    consultas = perfil(r, r.obter_situacao)
    agregado = perfil(r, r.encerramento_confirmado)
    retrato = r.obter_situacao()
    digest = hashlib.sha256(repr(retrato).encode()).hexdigest()
    confirmado = r.encerramento_confirmado()
    concorrente = concorrencia(r)
    del r, externos, retrato, lock_original
    gc.collect()
    # Nova construção sem arrays de latência ou registros de lock retidos.
    tracemalloc.start()
    r, externos, _, _ = montar(versao, carga, False)
    gc.collect()
    atual, pico = tracemalloc.get_traced_memory()
    tracemalloc.reset_peak()
    retrato = r.obter_situacao()
    _, pico_consulta = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    assert hashlib.sha256(repr(retrato).encode()).hexdigest() == digest
    storage = r._reservas_socket
    faixas = storage.intervalos if versao != 'atual' else []
    tamanhos = [fim-inicio+1 for inicio, fim, _, _ in faixas]
    return dict(versao=versao, carga=carga, reservas=len(storage), digest=digest,
        threads_retidas=len(r.threads), threads_vivas=sum(t.is_alive() for t in r.threads),
        sockets_referenciados=sum(e.recurso is not None for e in storage.values()),
        confirmado=confirmado, faixas_finais=len(faixas), pico_faixas=pico_faixas,
        distribuicao_faixas=dict(minimo=min(tamanhos, default=0), maximo=max(tamanhos, default=0),
                               unitarias=sum(t == 1 for t in tamanhos)),
        bytes_retidos=atual, bytes_por_reserva=atual/len(storage), pico_carga_bytes=pico,
        pico_consulta_absoluto_bytes=pico_consulta, carga_sem_tracemalloc_s=carga_s,
        escrita=escrita, consulta=consultas, agregado=agregado, concorrencia=concorrente)


def memoria_pareada_mista():
    # Conversão apenas do registro sintético local. Mesmos objetos Thread/socket,
    # mesmo estado global, GC antes/depois: isola custo da representação.
    gc.collect()
    tracemalloc.start()
    r, externos, _, _ = montar('atual', 'mista_hora', False)
    digest_antes = hashlib.sha256(repr(r.obter_situacao()).encode()).hexdigest()
    gc.collect()
    antes, pico_antes = tracemalloc.get_traced_memory()
    tracemalloc.reset_peak()
    original = r._reservas_socket
    novo = ArmazenamentoIntervalos()
    for numero, entrada in original.items():
        novo[numero] = entrada
    r._reservas_socket = novo
    del original, numero, entrada
    gc.collect()
    depois, pico_ate_conversao = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    assert hashlib.sha256(repr(r.obter_situacao()).encode()).hexdigest() == digest_antes
    assert r.encerramento_confirmado()
    return dict(bytes_antes=antes, bytes_depois=depois, diferenca_bytes=antes-depois,
        pico_pre_conversao_inclui_digest=pico_antes, pico_conversao=pico_ate_conversao,
        reservas=len(novo), fortes=len(novo.fortes), faixas=len(novo.intervalos),
        threads_retidas=len(r.threads), threads_vivas=sum(t.is_alive() for t in r.threads),
        limites='Conversao de armazenamento no mesmo grafo sintetico local, sem alterar producao; nao e RSS.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--saida', type=Path, required=True)
    parser.add_argument('--pareada', action='store_true')
    parser.add_argument('--concorrencia', action='store_true')
    args = parser.parse_args()
    if args.pareada:
        args.saida.write_text(json.dumps(memoria_pareada_mista(), indent=2), encoding='utf-8')
        raise SystemExit(0)
    if args.concorrencia:
        resultados = []
        for carga in ('uniforme','inversa_fragmentada','ponte_fusao','aleatoria_tokens','mista_hora'):
            for versao in BACKENDS:
                r, externos, _, _ = montar(versao, carga, False)
                resultados.append(dict(versao=versao, carga=carga,
                    concorrencia=concorrencia(r, forcar_sobreposicao=True)))
                del r, externos
                gc.collect()
        args.saida.write_text(json.dumps(dict(concluido=True, medicoes=resultados), indent=2), encoding='utf-8')
        raise SystemExit(0)
    medicoes = []
    for carga in ('uniforme','inversa_fragmentada','ponte_fusao','aleatoria_tokens','mista_hora'):
        grupo = []
        for versao in BACKENDS:
            resultado = medir(versao, carga)
            grupo.append(resultado)
            medicoes.append(resultado)
            args.saida.write_text(json.dumps(dict(concluido=False, medicoes=medicoes), indent=2), encoding='utf-8')
        assert len({m['digest'] for m in grupo}) == 1
    args.saida.write_text(json.dumps(dict(concluido=True, python=platform.python_version(),
        plataforma=sys.platform, medicoes=medicoes,
        limites='Uma execucao por cenario. Latencias sem tracing, percentis nearest-rank. '
        'Memoria em reconstrucao separada com GC/tracemalloc; nao e RSS. Sockets dubles, '
        'threads realmente start/join. Nao e repeticao do ensaio de rede de uma hora.'), indent=2), encoding='utf-8')

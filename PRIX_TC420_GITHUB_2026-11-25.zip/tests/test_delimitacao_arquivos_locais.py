# Testes de delimitacao arquivos locais: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B2-A: código atual e proposta de arquivo_comum só no harness.

O modelo abaixo não está integrado às funções operacionais de configuração.
Nenhum arquivo de dados, backend keyring, Tk ou equipamento real é acessado.
"""
import ast
import io
import json
from pathlib import Path
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from config import configuracao
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
import test_login_http_integrado as threads


RAIZ = Path(__file__).resolve().parents[1]


def fontes():
    # Diretórios operacionais explícitos; nenhuma leitura da referência excluída.
    caminhos = list(RAIZ.glob("*.py"))
    for pasta in ("config", "interface", "rede", "tc420", "prototipos"):
        caminhos.extend((RAIZ / pasta).rglob("*.py"))
    return sorted(p for p in caminhos if "__pycache__" not in p.parts)


def inventario():
    achados = []
    for caminho in fontes():
        arvore = ast.parse(caminho.read_text(encoding="utf-8"))
        for funcao in ast.walk(arvore):
            if not isinstance(funcao, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for no in ast.walk(funcao):
                if isinstance(no, ast.Call) and ast.unparse(no.func) == "open":
                    achados.append((caminho.relative_to(RAIZ).as_posix(), funcao.name,
                                    no.args[1].value, next(k.value.value for k in no.keywords if k.arg == "encoding")))
    return sorted(achados)


class ArquivoMemoria(io.StringIO):
    def __init__(self, texto="{}", leitura=None, escrita=None, limpeza=None):
        super().__init__(texto)
        self.leitura, self.escrita, self.limpeza = leitura, escrita, limpeza
        self.fechamentos, self.texto_fechado, self.antes_close = 0, None, None

    def read(self, *args):
        if self.leitura is not None:
            raise self.leitura
        return super().read(*args)

    def write(self, texto):
        if self.escrita is not None:
            raise self.escrita
        return super().write(texto)

    def close(self):
        self.fechamentos += 1
        if self.antes_close is not None:
            self.antes_close()
        if self.limpeza is not None:
            raise self.limpeza
        if not self.closed:
            self.texto_fechado = self.getvalue()
        super().close()


class ModeloArquivosEnsaio:
    """Proposta síncrona, sem política de dados ou dono global de aplicação."""
    def __init__(self, infraestrutura, origem):
        self.registro = infraestrutura.registro_recursos
        self.origem = origem

    def executar(self, alocar, operar, *, preparar=None):
        registro = self.registro
        identidade = registro.reservar("arquivo_comum", *self.origem)
        if identidade is None:
            raise RuntimeError("admissao_arquivo_recusada")
        entrou, objetos = [], []
        def fabrica():
            entrou.append(True)
            objeto = alocar()
            objetos.append(objeto)
            return objeto
        try:
            registro.criar(identidade, fabrica, preparar=preparar)
        except BaseException:
            if not entrou:
                registro.comprovar_ausencia(identidade, nao_alocado=True)
            elif objetos:
                try:
                    registro.fechar(identidade)
                except BaseException:
                    pass  # Evidência fica no registro, erro de abertura prevalece.
            raise
        usados = []
        def usar(objeto):
            usados.append(True)
            return operar(objeto)
        try:
            return registro.usar(identidade, usar)
        except BaseException:
            if not usados:
                # Gate fechado depois de publicar: usar não entrou no finally.
                try:
                    registro.fechar(identidade)
                except BaseException:
                    pass
            raise


# Grupo de 25 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class DelimitacaoArquivosLocais(unittest.TestCase):
    iniciar_thread = threads.LoginHttpIntegrado.iniciar_thread
    terminar = threads.LoginHttpIntegrado.terminar
    bloquear = threads.LoginHttpIntegrado.bloquear

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_recursos
        # Preparação experimental sem leitor, HTTP ou retentativa admitida.
        geracao = self.infra.registro_retentativas.nova_geracao_cliente().numero
        self.origem = (geracao, geracao)
        self.modelo = ModeloArquivosEnsaio(self.infra, self.origem)
        self.arquivos = []
        self.addCleanup(self.limpar)

    def limpar(self):
        for arquivo in self.arquivos:
            arquivo.limpeza, arquivo.antes_close = None, None
            if not arquivo.closed:
                arquivo.close()

    def arquivo(self, *args, **kwargs):
        objeto = ArquivoMemoria(*args, **kwargs)
        self.arquivos.append(objeto)
        return objeto

    def retrato(self):
        return self.registro.obter_retrato()["recursos"]

    def negativo(self):
        resultado = self.infra.avaliar()
        self.assertFalse(resultado["cobertura_completa"])
        self.assertFalse(resultado["encerramento_confirmado"])

    def atual(self, arquivo):
        return patch.multiple(configuracao, existe_configuracao=Mock(return_value=True),
                              obter_caminho_configuracao=Mock(return_value="virtual-simulado.json"))

    def test_01_inventario_dois_opens_com_escopo_de_fechamento(self):
        self.assertEqual([
            ("config/configuracao.py", "carregar_configuracao", "r", "utf-8"),
            ("config/configuracao.py", "salvar_configuracao", "w", "utf-8"),
        ], inventario())
        arvore = ast.parse((RAIZ / "config/configuracao.py").read_text(encoding="utf-8"))
        aberturas = [n for n in ast.walk(arvore) if isinstance(n, ast.Call) and ast.unparse(n.func) == "open"]
        self.assertEqual(2, len(aberturas))
        self.assertEqual(2, sum(isinstance(n, ast.Call) and ast.unparse(n.func) == "executar_arquivo"
                                for n in ast.walk(arvore)))
        self.assertEqual(str(RAIZ / "configuracao.json"), configuracao.obter_caminho_configuracao())

    def test_02_atual_leitura_fecha_sem_registro(self):
        arquivo = self.arquivo('{"valor": 1}')
        with self.atual(arquivo), patch("builtins.open", return_value=arquivo) as abrir:
            self.assertEqual({"valor": 1}, configuracao.carregar_configuracao())
        abrir.assert_called_once_with("virtual-simulado.json", "r", encoding="utf-8")
        self.assertTrue(arquivo.closed)
        self.assertEqual([], self.retrato())

    def test_03_atual_escrita_formato_e_conteudo_preservados(self):
        arquivo = self.arquivo("")
        with self.atual(arquivo), patch("builtins.open", return_value=arquivo) as abrir:
            dados = configuracao.salvar_configuracao("estação-simulada", "host-simulado", "9800", "", False)
        abrir.assert_called_once_with("virtual-simulado.json", "w", encoding="utf-8")
        self.assertEqual(json.dumps(dados, indent=4, ensure_ascii=False), arquivo.texto_fechado)
        self.assertEqual({"nome_rede", "ip", "porta", "usuario", "salvar_login"}, set(dados))
        self.assertNotIn("senha", dados)
        self.assertTrue(arquivo.closed)

    def test_04_atual_ausente_nao_abre(self):
        with patch.object(configuracao, "existe_configuracao", return_value=False), patch("builtins.open") as abrir:
            self.assertIsNone(configuracao.carregar_configuracao())
        abrir.assert_not_called()

    def test_05_atual_erro_leitura_retorna_none_e_fecha(self):
        arquivo = self.arquivo(leitura=OSError("leitura_simulada"))
        with self.atual(arquivo), patch("builtins.open", return_value=arquivo):
            self.assertIsNone(configuracao.carregar_configuracao())
        self.assertTrue(arquivo.closed)

    def test_06_atual_erro_escrita_preserva_instancia(self):
        original = OSError("escrita_simulada")
        arquivo = self.arquivo(escrita=original)
        with self.atual(arquivo), patch("builtins.open", return_value=arquivo):
            with self.assertRaises(OSError) as erro:
                configuracao.salvar_configuracao("simulado", "simulado", 9800, "", False)
        self.assertIs(original, erro.exception)
        self.assertTrue(arquivo.closed)

    def test_07_atual_parse_invalido_none_fecha(self):
        arquivo = self.arquivo("{invalido")
        with self.atual(arquivo), patch("builtins.open", return_value=arquivo):
            self.assertIsNone(configuracao.carregar_configuracao())
        self.assertTrue(arquivo.closed)

    def test_08_atual_falha_open_distingue_leitura_escrita(self):
        original = OSError("abertura_simulada")
        with self.atual(None), patch("builtins.open", side_effect=original):
            self.assertIsNone(configuracao.carregar_configuracao())
            with self.assertRaises(OSError) as erro:
                configuracao.salvar_configuracao("simulado", "simulado", 9800, "", False)
        self.assertIs(original, erro.exception)

    def test_09_close_nao_mascara_erro_original(self):
        original, limpeza = ValueError("leitura_simulada"), RuntimeError("close_simulado")
        arquivo = self.arquivo(leitura=original, limpeza=limpeza)
        with self.atual(arquivo), patch("builtins.open", return_value=arquivo):
            self.assertIsNone(configuracao.carregar_configuracao())  # ValueError continua tratado.
        self.assertIs(limpeza, original.__cause__)
        self.assertFalse(arquivo.closed)

    def test_10_modelo_reserva_antes_open_e_prova_closed(self):
        arquivo = self.arquivo()
        def abrir():
            self.assertEqual("arquivo_comum", self.retrato()[0]["tipo"])
            self.assertTrue(self.retrato()[0]["criacao_em_curso"])
            return arquivo
        self.assertEqual({}, self.modelo.executar(abrir, json.load))
        recurso = self.retrato()[0]
        self.assertEqual("close_retornou_e_closed_true", recurso["prova_fechamento"])
        self.assertTrue(recurso["encerramento_confirmado"])
        self.assertIs(self.registro, self.infra.registro_recursos)

    def test_11_modelo_falha_comprovada_antes_fabrica(self):
        abrir = Mock()
        with patch.object(self.registro, "criar", side_effect=OSError("pre_execucao_simulada")):
            with self.assertRaises(OSError):
                self.modelo.executar(abrir, json.load)
        abrir.assert_not_called()
        self.assertTrue(self.retrato()[0]["ausencia_comprovada"])

    def test_12_modelo_fabrica_lanca_sem_handle_ausencia_nao_inferida(self):
        ocultos = []
        def abrir_opaco():
            ocultos.append(self.arquivo())
            raise OSError("abertura_opaca_simulada")
        with self.assertRaises(OSError):
            self.modelo.executar(abrir_opaco, json.load)
        recurso = self.retrato()[0]
        self.assertFalse(recurso["ausencia_comprovada"])
        self.assertFalse(recurso["criacao_resolvida"])
        self.assertEqual("desconhecido", recurso["estado"])
        self.assertFalse(ocultos[0].closed)  # Handle retido só pelo harness, não pelo registro.

    def test_13_modelo_falha_apos_abrir_antes_publicar(self):
        arquivo = self.arquivo()
        original = ValueError("publicacao_simulada")
        with self.assertRaises(ValueError) as erro:
            self.modelo.executar(lambda: arquivo, json.load, preparar=Mock(side_effect=original))
        self.assertIs(original, erro.exception)
        self.assertTrue(arquivo.closed)
        self.assertFalse(self.retrato()[0]["publicado"])
        self.assertTrue(self.retrato()[0]["erros_criacao"])

    def test_14_modelo_leitura_falha_fecha(self):
        arquivo = self.arquivo(leitura=ValueError("leitura_simulada"))
        with self.assertRaises(ValueError):
            self.modelo.executar(lambda: arquivo, json.load)
        self.assertTrue(arquivo.closed)
        self.assertTrue(self.retrato()[0]["erros_atendimento"])

    def test_15_modelo_escrita_e_limpeza_preservam_erro_escrita(self):
        original, limpeza = OSError("escrita_simulada"), RuntimeError("close_simulado")
        arquivo = self.arquivo(escrita=original, limpeza=limpeza)
        with self.assertRaises(OSError) as erro:
            self.modelo.executar(lambda: arquivo, lambda f: json.dump({"valor": 1}, f))
        self.assertIs(original, erro.exception)
        self.assertTrue(self.retrato()[0]["erros_limpeza"])
        self.assertEqual("desconhecido", self.retrato()[0]["estado"])

    def test_16_modelo_close_falho_sem_confirmacao(self):
        arquivo = self.arquivo(limpeza=OSError("close_simulado"))
        with self.assertRaises(OSError):
            self.modelo.executar(lambda: arquivo, json.load)
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])

    def test_17_modelo_closed_false_nao_e_prova(self):
        objeto = SimpleNamespace(close=Mock(), closed=False)
        self.modelo.executar(lambda: objeto, lambda f: None)
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
        self.assertTrue(self.retrato()[0]["erros_evidencia"])

    def test_18_modelo_duas_operacoes_simultaneas_ids_proprios(self):
        barreira = threading.Barrier(2)
        arquivos = [self.arquivo(), self.arquivo()]
        def operar(f):
            barreira.wait(3)
            self.assertEqual(2, len(self.retrato()))
            self.assertTrue(all(r["usos"] == 1 for r in self.retrato()))
            barreira.wait(3)
            return json.load(f)
        a = self.iniciar_thread(lambda: self.modelo.executar(lambda: arquivos[0], operar))
        b = self.iniciar_thread(lambda: self.modelo.executar(lambda: arquivos[1], operar))
        ra, ea = self.terminar(a)
        rb, eb = self.terminar(b)
        self.assertEqual(([{}], [], [{}], []), (ra, ea, rb, eb))
        self.assertEqual(2, len({r["recurso_id"] for r in self.retrato()}))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.retrato()))

    def test_19_modelo_publicacao_tardia_permanece_pendente(self):
        arquivo = self.arquivo()
        entrou, liberar = threading.Event(), threading.Event()
        tarefa = self.iniciar_thread(lambda: self.modelo.executar(lambda: arquivo, json.load,
            preparar=lambda f: self.bloquear(entrou, liberar)))
        try:
            self.assertTrue(entrou.wait(3))
            self.assertTrue(self.retrato()[0]["criacao_em_curso"])
            self.assertFalse(self.retrato()[0]["publicado"])
            self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
            self.negativo()
        finally:
            liberar.set()
            _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)

    def test_20_corrida_abertura_contra_encerramento(self):
        arquivo = self.arquivo()
        entrou, liberar = threading.Event(), threading.Event()
        def abrir():
            self.bloquear(entrou, liberar)
            return arquivo
        tarefa = self.iniciar_thread(lambda: self.modelo.executar(abrir, json.load))
        try:
            self.assertTrue(entrou.wait(3))
            self.registro.fechar_admissao()
            self.assertFalse(self.registro.obter_retrato()["encerramento_confirmado"])
            negada = Mock()
            with self.assertRaises(RuntimeError):
                self.modelo.executar(negada, json.load)
            negada.assert_not_called()
        finally:
            liberar.set()
            _, erros = self.terminar(tarefa)
        self.assertEqual(1, len(erros))  # Uso recusado, reserva aceita antes do gate.
        self.assertIsInstance(erros[0], RuntimeError)
        self.assertTrue(arquivo.closed)
        self.assertTrue(self.retrato()[0]["encerramento_confirmado"])
        self.negativo()

    def test_21_corrida_fechamento_contra_consulta(self):
        arquivo = self.arquivo()
        entrou, liberar = threading.Event(), threading.Event()
        arquivo.antes_close = lambda: self.bloquear(entrou, liberar)
        tarefa = self.iniciar_thread(lambda: self.modelo.executar(lambda: arquivo, json.load))
        try:
            self.assertTrue(entrou.wait(3))
            self.assertTrue(self.retrato()[0]["limpeza_em_curso"])
            self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
        finally:
            liberar.set()
            _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertTrue(self.retrato()[0]["encerramento_confirmado"])

    def test_22_corrida_promocao_com_arquivo_pendente_e_antigos(self):
        antigo = self.arquivo(limpeza=OSError("limpeza_antiga_simulada"))
        entrou, liberar = threading.Event(), threading.Event()
        tarefa = self.iniciar_thread(lambda: self.modelo.executar(lambda: antigo,
            lambda f: self.bloquear(entrou, liberar)))
        try:
            self.assertTrue(entrou.wait(3))
            self.registro.promover(self.origem[0])
            nova = self.infra.registro_retentativas.nova_geracao_cliente().numero
            modelo_novo = ModeloArquivosEnsaio(self.infra, (nova, nova))
            novo = self.arquivo()
            modelo_novo.executar(lambda: novo, json.load)
            self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
            self.assertTrue(self.retrato()[1]["encerramento_confirmado"])
        finally:
            liberar.set()
            _, erros = self.terminar(tarefa)
        self.assertEqual(1, len(erros))
        antigo_retrato = self.retrato()[0]
        self.assertEqual(self.origem[0], antigo_retrato["geracao_id"])
        self.assertEqual("principal", antigo_retrato["modo_atual"])
        self.assertEqual("desconhecido", antigo_retrato["estado"])
        self.assertEqual(2, len(self.retrato()))
        self.negativo()

    def test_23_corrida_limpeza_durante_outra_excecao(self):
        original = ValueError("leitura_simulada")
        arquivo = self.arquivo(leitura=original, limpeza=OSError("limpeza_simulada"))
        with self.assertRaises(ValueError) as erro:
            self.modelo.executar(lambda: arquivo, json.load)
        self.assertIs(original, erro.exception)
        recurso = self.retrato()[0]
        self.assertEqual("falha_operacao", recurso["erros_atendimento"][0]["categoria"])
        self.assertEqual("falha_io", recurso["erros_limpeza"][0]["categoria"])
        self.assertFalse(recurso["encerramento_confirmado"])

    def test_24_modelo_nao_declara_cobertura_global(self):
        arquivo = self.arquivo()
        self.modelo.executar(lambda: arquivo, json.load)
        self.registro.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])
        self.negativo()

    def test_25_limites_tk_keyring_e_escopo_aplicacao(self):
        arvore = ast.parse((RAIZ / "interface/janela.py").read_text(encoding="utf-8"))
        imagens = [n for n in ast.walk(arvore) if isinstance(n, ast.Call) and ast.unparse(n.func) == "tk.PhotoImage"]
        nomes = []
        for imagem in imagens:
            valor = next(k.value for k in imagem.keywords if k.arg == "file")
            self.assertEqual("_caminho_asset", ast.unparse(valor.func))
            nomes.append(ast.literal_eval(valor.args[0]))
        self.assertEqual(["null_cursor.png", "settled.png"], nomes)
        # Registro não oferece escopo de aplicação sem uma origem positiva.
        with self.assertRaises(ValueError):
            self.registro.reservar("arquivo_comum", None, None)
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()["retentativas"])

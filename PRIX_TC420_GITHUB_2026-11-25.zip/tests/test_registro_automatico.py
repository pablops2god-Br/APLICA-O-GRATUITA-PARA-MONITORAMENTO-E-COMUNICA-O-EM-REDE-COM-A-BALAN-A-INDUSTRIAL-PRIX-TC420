# Testes de registro automatico: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Simulações sem rede/Tk: python -B -m unittest discover -s tests -v."""
import ast
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from rede import servidor
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente


RAIZ = Path(__file__).resolve().parents[1]


def carregar_fluxos():
    arvore = ast.parse((RAIZ / "main.py").read_text(encoding="utf-8"))
    funcoes = [n for n in arvore.body if isinstance(n, ast.FunctionDef)
               and n.name in ("tentar_login_automatico", "iniciar")]
    ambiente = dict(
        threading=SimpleNamespace(Thread=ThreadFila, Event=threading.Event),
        RegistroTentativasAplicacao=servidor.RegistroTentativasAplicacao,
        ContextoCicloServidor=servidor.ContextoCicloServidor,
        carregar_configuracao=lambda **kwargs: dict(salvar_login=True, ip="simulado", usuario="simulado"),
        carregar_senha=lambda usuario: "valor-simulado",
        buscar_servidor=Mock(return_value=None),
        # Partida é controlada pelo ensaio; prontidão real tem testes próprios.
        aguardar_prontidao=Mock(return_value=True),
        interromper_tentativa=Mock(),
        operacao_vigente=lambda saida: not saida.parada_solicitada,
        WebTC420=Mock(return_value=SimpleNamespace(
            login=Mock(), obter_configuracao=lambda: {}, token=object())),
        definir_configuracao=Mock(),
        iniciar_servidor=Mock(),
        print=lambda *args: None,
    )
    exec(compile(ast.Module(body=funcoes, type_ignores=[]), "main.py", "exec"), ambiente)
    return ambiente


class ThreadFila:
    """Start retorna; target só roda quando o ensaio ordenar."""
    criadas = []

    def __init__(self, target, daemon):
        self.target = target
        self.started = False
        self.criadas.append(self)

    def start(self):
        self.started = True


# Grupo de 18 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class IntegracaoAutomatica(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        ThreadFila.criadas = []
        self.env = carregar_fluxos()
        self.registro = servidor.RegistroTentativasAplicacao()
        # Contrato HTTP L3-B1.8: ensaios do servidor continuam exercitando a
        # partida real simulada, agora com o dono HTTP explicitamente injetado.
        self.infra = InfraestruturaRegistrosCliente()

    def executar(self, registro=None):
        return self.env["tentar_login_automatico"](
            self.registro if registro is None else registro, infraestrutura_cliente=self.infra)

    def tentativa(self, indice=0):
        return self.registro.obter_retrato()["tentativas"][indice]

    def test_01_normal(self):
        def fabrica(**kwargs):
            self.assertEqual(self.tentativa().estado_partida, "iniciando")
            self.assertTrue(self.registro._lock.acquire(blocking=False))
            self.registro._lock.release()
            return ThreadFila(**kwargs)
        self.env["threading"].Thread = fabrica
        resultado = self.executar()
        self.assertEqual(self.tentativa().estado_partida, "iniciada")
        ThreadFila.criadas[0].target()
        self.assertTrue(self.tentativa().execucao_observada)
        self.env["iniciar_servidor"].assert_called_once_with(
            resultado["web"], contexto_ciclo=self.tentativa().contexto)
        self.assertTrue(resultado["servidor_encerrado"].is_set())

    def test_02_entrada_antes_retorno_start(self):
        caso = self
        class Imediata(ThreadFila):
            def start(self):
                self.target()
                caso.assertTrue(caso.tentativa().execucao_observada)
                caso.assertEqual(caso.tentativa().estado_partida, "iniciando")
        self.env["threading"].Thread = Imediata
        self.assertTrue(self.executar())
        self.assertEqual(self.tentativa().estado_partida, "iniciada")

    def test_03_falha_construcao(self):
        self.env["threading"].Thread = Mock(side_effect=RuntimeError())
        self.assertFalse(self.executar())
        tentativa = self.tentativa()
        self.assertEqual(tentativa.estado_partida, "falha_partida")
        self.assertEqual(tentativa.erro_partida, "falha_criacao_thread")
        self.assertEqual(tentativa.contexto.erro, "falha_antes_reserva")
        self.env["iniciar_servidor"].assert_not_called()

    def test_04_start_ambiguo_target_tardio(self):
        class Ambigua(ThreadFila):
            def start(self):
                raise RuntimeError()
        self.env["threading"].Thread = Ambigua
        self.assertFalse(self.executar())
        self.assertEqual(self.tentativa().estado_partida, "iniciando")
        self.assertFalse(self.tentativa().contexto.resolvido.is_set())
        ThreadFila.criadas[0].target()
        self.assertTrue(self.tentativa().execucao_observada)
        self.assertIsNone(self.tentativa().erro_partida)

    def test_05_admissao_recusada(self):
        contexto = servidor.ContextoCicloServidor()
        self.env["ContextoCicloServidor"] = lambda: contexto
        self.registro.fechar_admissao()
        self.assertFalse(self.executar())
        self.assertFalse(ThreadFila.criadas)
        self.assertFalse(contexto.resolvido.is_set())
        self.assertEqual(self.registro.obter_retrato(),
                         dict(admissao_fechada=True, tentativas=()))

    def test_06_fecha_durante_partida(self):
        caso = self
        class Fecha(ThreadFila):
            def start(self):
                caso.registro.fechar_admissao()
                self.target()
        self.env["threading"].Thread = Fecha
        self.assertTrue(self.executar())
        self.assertEqual(self.tentativa().estado_partida, "iniciada")
        self.assertTrue(self.tentativa().execucao_observada)

    def manual(self):
        arvore = ast.parse((RAIZ / "interface/conexao.py").read_text(encoding="utf-8"))
        bloco = next(n for n in ast.walk(arvore) if isinstance(n, ast.If)
                     and ast.unparse(n.test) == "not self.servidor_iniciado")
        janela = SimpleNamespace(
            servidor_iniciado=False, registro_tentativas=self.registro,
            web=object(), servidor_inicializado=threading.Event(),
            servidor_encerrado=threading.Event(), observar_contexto_ciclo=Mock(),
            supervisionar_inicializacao=Mock(), observar_servidor=Mock())
        ambiente = dict(self.env, self=janela)
        exec(compile(ast.Module(body=[bloco], type_ignores=[]),
                     "interface/conexao.py", "exec"), ambiente)
        return janela

    def test_07_manual_anterior(self):
        janela = self.manual()
        anterior = self.tentativa()
        self.executar()
        self.assertEqual(self.tentativa(), anterior)
        self.assertIs(self.tentativa().contexto, janela.contexto_ciclo_servidor)

    def test_08_automatico_posterior_mesma_instancia(self):
        janela = self.manual()
        resultado = self.executar()
        self.assertIs(janela.registro_tentativas, self.registro)
        self.assertEqual(len(self.registro.obter_retrato()["tentativas"]), 2)
        self.assertIs(self.tentativa(1).contexto, resultado["contexto_ciclo"])
        self.assertNotEqual(self.tentativa().tentativa_id, self.tentativa(1).tentativa_id)

    def test_09_reserva_recusada_servidor_real(self):
        self.env["iniciar_servidor"] = servidor.iniciar_servidor
        resultado = self.executar()
        with patch.object(servidor, "controle_ciclo_servidor") as controle:
            controle.tentar_iniciar.return_value = False
            with self.assertRaises(RuntimeError):
                ThreadFila.criadas[0].target()
        self.assertEqual(self.tentativa().contexto.erro, "reserva_recusada")
        self.assertEqual(self.tentativa().estado_partida, "iniciada")
        self.assertTrue(self.tentativa().contexto.coordenador_retornou.is_set())
        self.assertTrue(resultado["servidor_encerrado"].is_set())

    def test_10_falha_pos_reserva_servidor_real(self):
        self.env["iniciar_servidor"] = servidor.iniciar_servidor
        resultado = self.executar()
        controle = servidor.ControleCicloServidor()
        with patch.object(servidor, "controle_ciclo_servidor", controle), \
             patch.object(servidor, "threading", SimpleNamespace(
                 Lock=threading.Lock, current_thread=threading.current_thread,
                 Thread=Mock(side_effect=RuntimeError()))), \
             patch.object(servidor, "evento_parada_servidor", threading.Event()):
            with self.assertRaises(RuntimeError):
                ThreadFila.criadas[0].target()
        situacao = resultado["contexto_ciclo"].obter_situacao()
        self.assertIs(type(situacao["ciclo_id"]), int)
        self.assertTrue(situacao["coordenador_retornou"])
        self.assertEqual(situacao["erro_coordenador"], "falha_execucao")
        self.assertIsNone(self.tentativa().erro_partida)

    def test_11_antigo_preservado(self):
        primeiro = self.executar()
        antigo = self.tentativa()
        segundo = self.executar()
        self.assertIs(self.tentativa().contexto, primeiro["contexto_ciclo"])
        self.assertIsNot(self.tentativa().contexto, segundo["contexto_ciclo"])
        self.assertEqual(self.tentativa(), antigo)

    def rodar_threads(self, funcoes):
        erros = []
        def executar(funcao):
            try:
                funcao()
            except BaseException as erro:
                erros.append(erro)
        threads = [threading.Thread(target=executar, args=(f,)) for f in funcoes]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(3)
            self.assertFalse(thread.is_alive())
        if erros:
            raise erros[0]

    def test_12_inicializacoes_concorrentes(self):
        barreira = threading.Barrier(2, timeout=3)
        def iniciar():
            barreira.wait()
            self.assertTrue(self.executar())
        self.rodar_threads([iniciar, iniciar])
        tentativas = self.registro.obter_retrato()["tentativas"]
        self.assertEqual(len({t.tentativa_id for t in tentativas}), 2)
        self.assertEqual(len({id(t.contexto) for t in tentativas}), 2)

    def test_13_consulta_durante_partida(self):
        entrou = threading.Barrier(2, timeout=3)
        liberar = threading.Barrier(2, timeout=3)
        caso = self
        class Pausa(ThreadFila):
            def start(self):
                self.target()
                entrou.wait()
                liberar.wait()
        self.env["threading"].Thread = Pausa
        def consultar():
            entrou.wait()
            retrato = caso.registro.obter_retrato()
            try:
                t = retrato["tentativas"][0]
                caso.assertEqual(t.estado_partida, "iniciando")
                caso.assertTrue(t.execucao_observada)
            finally:
                liberar.wait()
            caso.retrato_antigo = retrato
        self.rodar_threads([self.executar, consultar])
        self.assertEqual(self.tentativa().estado_partida, "iniciada")
        self.assertEqual(self.retrato_antigo["tentativas"][0].estado_partida, "iniciando")

    def test_14_fechamento_concorrente_critico_manual_automatico(self):
        for aceita in (True, False):
            with self.subTest(aceita=aceita):
                pronta = threading.Barrier(2, timeout=3)
                liberar = threading.Barrier(2, timeout=3)
                class RegistroPausado(servidor.RegistroTentativasAplicacao):
                    def admitir(registro, contexto):
                        if registro.obter_retrato()["tentativas"]:
                            if aceita:
                                tentativa_id = super().admitir(contexto)
                            pronta.wait()
                            liberar.wait()
                            return tentativa_id if aceita else super().admitir(contexto)
                        return super().admitir(contexto)
                self.registro = RegistroPausado()
                ThreadFila.criadas = []
                janela = self.manual()
                resultados = []
                def automatico():
                    resultados.append(self.executar())
                def fechar():
                    pronta.wait()
                    self.registro.fechar_admissao()
                    self.retrato_fechado = self.registro.obter_retrato()
                    liberar.wait()
                self.rodar_threads([automatico, fechar])
                esperado = 2 if aceita else 1
                self.assertEqual(bool(resultados[0]), aceita)
                self.assertEqual(len(self.retrato_fechado["tentativas"]), esperado)
                self.assertIs(janela.registro_tentativas, self.registro)
                for thread in ThreadFila.criadas:
                    thread.target()
                atuais = self.registro.obter_retrato()["tentativas"]
                self.assertEqual(len(atuais), esperado)
                self.assertTrue(all(t.execucao_observada for t in atuais))
                self.assertTrue(all(t.estado_partida == "iniciada" for t in atuais))
                self.assertEqual([t.contexto for t in atuais],
                                 [t.contexto for t in self.retrato_fechado["tentativas"]])

    def test_15_excecao_apos_entrada_start(self):
        class ExecutaELanca(ThreadFila):
            def start(self):
                self.target()
                raise RuntimeError()
        self.env["threading"].Thread = ExecutaELanca
        self.assertFalse(self.executar())
        self.assertTrue(self.tentativa().execucao_observada)
        self.assertEqual(self.tentativa().estado_partida, "iniciando")
        self.assertIsNone(self.tentativa().erro_partida)

    def test_16_regressao_eleicao_e_injecao(self):
        busca = self.env["buscar_servidor"]
        busca.return_value = "principal-simulado"
        self.assertEqual(self.executar(), dict(modo="cliente", servidor="principal-simulado"))
        self.env["WebTC420"].assert_not_called()
        self.assertFalse(self.registro.obter_retrato()["tentativas"])
        cliente = Mock()
        self.env["iniciar_como_cliente"] = cliente
        self.env["iniciar"]()
        self.assertEqual(cliente.call_args.args, ("principal-simulado",))
        self.assertIsInstance(cliente.call_args.kwargs["registro_tentativas"],
                              servidor.RegistroTentativasAplicacao)
        busca.return_value = None
        registro_criado = servidor.RegistroTentativasAplicacao()
        fabrica = Mock(return_value=registro_criado)
        self.env["RegistroTentativasAplicacao"] = fabrica
        login_original = self.env["tentar_login_automatico"]
        chamadas = []
        def login(**kwargs):
            chamadas.append(kwargs["registro_tentativas"])
            # Força o fallback manual após a tentativa automática real.
            self.assertTrue(login_original(**kwargs))
            return False
        self.env["tentar_login_automatico"] = login
        self.env["JanelaConexao"] = Mock()
        self.env["iniciar"]()
        fabrica.assert_called_once_with()
        self.assertIs(chamadas[0], registro_criado)
        self.assertIs(self.env["JanelaConexao"].call_args.kwargs["registro_tentativas"],
                      registro_criado)
        self.assertEqual(len(registro_criado.obter_retrato()["tentativas"]), 1)

    def test_17_guarda_entrada_e_falha_operacional(self):
        resultado = self.executar()
        with patch.object(self.registro, "registrar_entrada_execucao", return_value=False):
            ThreadFila.criadas[0].target()
        self.env["iniciar_servidor"].assert_not_called()
        self.assertTrue(resultado["servidor_encerrado"].is_set())
        self.env["iniciar_servidor"].side_effect = RuntimeError()
        with self.assertRaises(RuntimeError):
            ThreadFila.criadas[0].target()
        self.assertTrue(self.tentativa().execucao_observada)
        self.assertIsNone(self.tentativa().erro_partida)
        # O evento sinaliza retorno da rotina, inclusive quando a falha continua propagando.
        self.assertTrue(resultado["servidor_encerrado"].is_set())

    def test_18_criterios_login_e_compatibilidade_avulsa(self):
        for configuracao in (None, {}, dict(salvar_login=True),
                             dict(salvar_login=True, ip="simulado")):
            with self.subTest(configuracao=configuracao):
                self.env["carregar_configuracao"] = lambda **kwargs: configuracao
                self.assertFalse(self.executar())
        self.assertFalse(ThreadFila.criadas)
        self.env = carregar_fluxos()
        self.env["carregar_senha"] = lambda usuario: None
        self.assertFalse(self.executar())
        self.env = carregar_fluxos()
        self.env["RegistroTentativasAplicacao"] = Mock(side_effect=AssertionError())
        self.assertFalse(self.env["tentar_login_automatico"]())
        self.assertTrue(self.env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        ThreadFila.criadas[0].target()
        self.env["iniciar_servidor"].assert_called_once()


if __name__ == "__main__":
    unittest.main()

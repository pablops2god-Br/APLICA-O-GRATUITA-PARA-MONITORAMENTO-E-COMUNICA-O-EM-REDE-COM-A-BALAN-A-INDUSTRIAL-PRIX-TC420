# Testes de mensagens seguras http: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.10: apresentação real por AST, transporte/Tk/persistência falsos."""
import ast
import json
import threading
import tkinter as tk
import unittest
from unittest.mock import Mock, patch
from uuid import uuid4

import requests

from interface.mensagens_seguras import mensagem_erro_login
from tc420.web import WebTC420
import test_login_manual_http as manual
import test_login_http_integrado as automatico
import test_login_promocao_http as promocao


# Grupo de 20 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class MensagensSegurasHttp(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.fx = manual.LoginManualHttp()
        self.fx.setUp()
        # Marcadores efêmeros: nenhum dado de autenticação versionado.
        self.marcadores = [uuid4().hex for _ in range(4)]
        self.dados = " ".join(self.marcadores)

    def sem_exposicao(self, fx=None):
        fx = fx or self.fx
        saidas = (fx.janela.label_status.opcoes["text"],
                  repr(fx.env["print"].call_args_list),
                  json.dumps(fx.registro.obter_retrato()), json.dumps(fx.infra.avaliar()))
        for saida in saidas:
            self.assertTrue(all(m not in saida for m in self.marcadores))
        return saidas[0]

    def falhar(self, erro):
        with self.fx.transporte(erro=erro) as adaptador:
            self.fx.executar()
        self.assertEqual(1, len(adaptador.enviados))
        self.assertEqual("falha", self.fx.operacoes()[-1]["resultado"])
        self.assertEqual("normal", self.fx.janela.botao_conectar.opcoes["state"])
        return self.sem_exposicao()

    def test_01_timeout_url_sensivel(self):
        self.assertIn("Tempo de conexão", self.falhar(requests.Timeout(self.dados)))

    def test_02_conexao_token(self):
        self.assertIn("Não foi possível conectar", self.falhar(requests.ConnectionError(self.dados)))

    def test_03_senha_em_excecao_inesperada(self):
        self.assertIn("Não foi possível concluir", self.falhar(Exception(self.dados)))

    def test_04_header_autorizacao(self):
        erro = requests.HTTPError("Authorization: " + self.dados)
        erro.request = requests.Request("GET", "https://simulado.invalid", headers={"Authorization": self.dados}).prepare()
        self.assertIn("erro de comunicação", self.falhar(erro))

    def test_05_recusa_login_sem_corpo(self):
        with self.fx.transporte(("FAILURE:LOGIN:simulado:" + self.dados).encode()):
            self.fx.executar()
        self.assertIn("Login recusado pela TC420.", self.sem_exposicao())
        for status in (401, 403):
            erro = requests.HTTPError(self.dados)
            erro.response = requests.Response()
            erro.response.status_code = status
            self.assertEqual("Autenticação não autorizada pela TC420.", mensagem_erro_login(erro))

    def test_06_resposta_invalida_sem_corpo(self):
        with self.fx.transporte(self.dados.encode()):
            self.fx.executar()
        self.assertIn("resposta inválida", self.sem_exposicao())
        self.assertIn("resposta inválida", mensagem_erro_login(RuntimeError("A TC420 retornou um token vazio.")))

    def test_07_falha_nao_chama_str_nem_repr(self):
        class ErroHostil(Exception):
            def __str__(self):
                raise AssertionError("str_nao_permitido")

            def __repr__(self):
                raise AssertionError("repr_nao_permitido")
        self.falhar(ErroHostil(self.dados))

    def test_08_automatico_preserva_false_console_seguro(self):
        fx = automatico.LoginHttpIntegrado()
        fx.setUp()
        fx.env["print"] = Mock()
        with fx.transporte(erro=requests.Timeout(self.dados)):
            self.assertIs(False, fx.main())
        self.assertTrue(all(m not in repr(fx.env["print"].call_args_list) for m in self.marcadores))
        self.assertEqual("falha", fx.operacoes()[0]["resultado"])

    def test_09_manual_botao_fluxo(self):
        self.falhar(requests.ConnectionError(self.dados))
        self.assertIsNone(self.fx.janela.web)
        self.assertIsNone(self.fx.janela.configuracao)
        self.fx.env["salvar_configuracao"].assert_not_called()
        self.assertFalse(self.fx.janela.servidor_iniciado)
        self.assertEqual([], self.fx.janela.root.agendados)

    def test_10_promocao_preserva_none_e_recuperacao(self):
        fx = promocao.LoginPromocaoHttp()
        fx.setUp()
        fx.fixture.env["print"] = Mock()
        with fx.transporte(erro=requests.ConnectionError(self.dados)):
            self.assertIsNone(fx.promover())
        fx.fixture.leitores[0].registrar_falha_recuperacao.assert_called_once_with()
        self.assertTrue(all(m not in repr(fx.fixture.env["print"].call_args_list) for m in self.marcadores))
        self.assertEqual("falha", fx.operacoes()[0]["resultado"])

    def test_11_approval_falho_alcanca_label_seguro(self):
        # Executa login e approval reais, com Requests falso em cada transporte.
        self.fx.env["WebTC420"].side_effect = lambda ip, **kw: WebTC420(ip, **kw)
        original = requests.HTTPError(self.dados)
        with patch("tc420.web.requests.post", return_value=Mock(text="SUCCESS:LOGIN:simulado:simulado")), \
                patch("tc420.web.requests.get", side_effect=original):
            self.fx.executar()
        self.assertIn("erro de comunicação", self.sem_exposicao())
        self.assertEqual(["retorno", "falha"], [op["resultado"] for op in self.fx.operacoes()])
        with patch("tc420.web.requests.post", return_value=Mock(text="SUCCESS:LOGIN:simulado:simulado")), \
                patch("tc420.web.requests.get", return_value=Mock(text="FAILURE:APPROVAL:" + self.dados)):
            self.fx.executar()
        self.assertIn("Approval recusado pela TC420.", self.sem_exposicao())

    def test_12_registro_identidade_publicacao(self):
        antes = []
        def observar():
            antes.append(self.fx.operacoes()[0])
        with self.fx.transporte(erro=requests.Timeout(self.dados), antes=observar):
            self.fx.executar()
        depois = self.fx.operacoes()[0]
        for campo in ("operacao_id", "geracao_id", "atividade_id"):
            self.assertEqual(antes[0][campo], depois[campo])
        self.assertEqual("em_andamento", antes[0]["estado"])
        self.assertTrue(depois["execucao_resolvida"])
        self.assertIsNotNone(depois["publicacao_original"])
        self.sem_exposicao()

    def test_13_console_sem_texto_http(self):
        self.falhar(requests.HTTPError(self.dados))
        self.fx.env["print"].assert_any_call("Erro ao realizar login:", "HTTPError")

    def test_14_excecao_original_preservada(self):
        original = requests.ConnectionError(self.dados)
        original.request = requests.Request("GET", "https://simulado.invalid").prepare()
        args, pedido = original.args, original.request
        with self.fx.transporte(erro=original):
            with self.assertRaises(requests.ConnectionError) as capturado:
                self.fx.fachada(WebTC420("balanca-simulada"))
        self.assertIs(original, capturado.exception)
        mensagem_erro_login(original)
        self.assertEqual(args, original.args)
        self.assertIs(pedido, original.request)

    def test_15_fronteira_sem_novo_callback_tk(self):
        classe = next(n for n in self.fx.arvore.body if isinstance(n, ast.ClassDef) and n.name == "JanelaConexao")
        conectar = next(n for n in classe.body if isinstance(n, ast.FunctionDef) and n.name == "_conectar_operacional")
        tratador = next(n for n in ast.walk(conectar) if isinstance(n, ast.ExceptHandler) and n.name == "erro")
        self.assertFalse(any(isinstance(n, ast.Attribute) and n.attr in ("after", "destroy", "Thread")
                             for n in ast.walk(tratador)))
        self.assertFalse(any(isinstance(n, (ast.FunctionDef, ast.Lambda)) for n in ast.walk(tratador)))

    def test_16_encerramento_global_nao_confirmado(self):
        self.falhar(requests.Timeout(self.dados))
        self.fx.registro.fechar_admissao()
        self.fx.negativo()

    def test_17_critico_a_url_credenciais_e_query(self):
        usuario, senha, token, extra = self.marcadores
        url = f"https://{usuario}:{senha}@simulado.invalid/login?token={token}&pwd={extra}"
        texto = self.falhar(requests.Timeout(url))
        self.assertNotIn(url, texto)
        self.assertNotIn("https://", texto)

    def test_18_critico_b_formatos_arbitrarios_argumentos_headers(self):
        erro = requests.ConnectionError({"headers": {"Authorization": self.dados}}, self.marcadores)
        erro.response = requests.Response()
        erro.response.headers["Authorization"] = self.dados
        erro.response._content = self.dados.encode()
        self.falhar(erro)

    def test_19_critico_c_concorrencia_identidades_resultados(self):
        outra = self.fx.criar_janela(self.fx.infra)
        outra.campo_ip.valor = "outra-simulada"
        barreira = threading.Barrier(2)
        original = requests.Timeout(self.dados)
        def enviar(url, **kwargs):
            barreira.wait(3)
            if "outra-simulada" in url:
                return Mock(text="SUCCESS:LOGIN:simulado:simulado")
            raise original
        with patch("tc420.web.requests.post", side_effect=enviar):
            a = self.fx.iniciar_thread(self.fx.executar)
            b = self.fx.iniciar_thread(outra.conectar)
            _, ea = self.fx.terminar(a)
            _, eb = self.fx.terminar(b)
        self.assertEqual(([], []), (ea, eb))
        ops = self.fx.operacoes()
        logins = [op for op in ops if op["operacao"] == "login"]
        self.assertEqual(2, len({op["geracao_id"] for op in logins}))
        self.assertEqual(3, len({op["operacao_id"] for op in ops}))
        self.assertEqual({"falha", "retorno"}, {op["resultado"] for op in logins})
        self.assertTrue(all(op["execucao_resolvida"] and op["publicacao_original"] for op in ops))
        self.sem_exposicao()
        self.assertEqual("● Login realizado com sucesso", outra.label_status.opcoes["text"])

    def test_20_critico_d_janela_destruida_antes_erro(self):
        entrou, liberar = threading.Event(), threading.Event()
        original = requests.Timeout(self.dados)
        with self.fx.transporte(erro=original, antes=lambda: self.fx.bloquear(entrou, liberar)):
            tarefa = self.fx.iniciar_thread(self.fx.executar)
            try:
                self.assertTrue(entrou.wait(3))
                self.fx.janela.root.destroy()
                eventos = len(self.fx.janela.root.eventos)
            finally:
                liberar.set()
                _, erros = self.fx.terminar(tarefa)
        self.assertEqual([], erros)
        # Apenas os dois acessos legados: label no except e botão no finally.
        self.assertEqual([], self.fx.janela.root.eventos[eventos:])
        self.assertEqual([], self.fx.janela.root.agendados)
        self.assertEqual("falha", self.fx.operacoes()[0]["resultado"])
        self.assertTrue(self.fx.operacoes()[0]["execucao_resolvida"])
        self.sem_exposicao()

# Testes de admissao subscribe cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-C7: fluxo SUBSCRIBE real, transporte falso e admissões por conexão."""
import gc
import json
import socket
import threading
import unittest
import weakref
from unittest.mock import MagicMock, Mock, patch

from rede.admissao_subscribe_cliente import RecursosSubscribeCliente
from rede.lerdadosserver import LeitorDadosServidor
import test_limpeza_subscribe_cliente as limpeza
import test_admissao_descoberta_inicial_cliente as apoio


# Grupo de 39 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AdmissaoSubscribeCliente(unittest.TestCase):
    novo_leitor = limpeza.LimpezaSubscribeCliente.novo_leitor
    objeto = limpeza.LimpezaSubscribeCliente.objeto
    recursos = limpeza.LimpezaSubscribeCliente.recursos
    transporte = limpeza.LimpezaSubscribeCliente.transporte
    executar = limpeza.LimpezaSubscribeCliente.executar
    duas_conexoes = limpeza.LimpezaSubscribeCliente.duas_conexoes
    retido = apoio.AdmissaoDescobertaInicialCliente.retido
    conservador = apoio.AdmissaoDescobertaInicialCliente.conservador

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        limpeza.LimpezaSubscribeCliente.setUp(self)
        self.controle = self.leitor._admissao_subscribe

    def tentativa(self, indice=0):
        return self.controle.obter_retrato()['tentativas'][indice]

    def antes_da_admissao(self, reconexao=False):
        objetos = [self.objeto() for _ in range(2 if reconexao else 1)]
        admitir = self.controle.admitir
        chamadas = []
        def atrasar():
            chamadas.append(True)
            if len(chamadas) == len(objetos):
                self.leitor.parar()
            return admitir()
        self.leitor._aguardar_candidatura = Mock(side_effect=lambda:
            (setattr(self.leitor, 'ip_servidor', 'principal-simulado'), False)[1])
        with self.transporte(objetos), patch.object(self.controle, 'admitir', side_effect=atrasar):
            self.leitor._manter_atualizado()
        return objetos

    def suspender_apos_admissao(self, durante):
        iniciar = self.controle.iniciar
        objeto = self.objeto()
        def executar(suspender):
            def atrasar(identidade):
                suspender()
                return iniciar(identidade)
            with patch.object(self.controle, 'iniciar', side_effect=atrasar):
                self.executar(objeto)
        self.retido(executar, durante)
        return objeto

    def test_01_inicial_normal(self):
        objeto, _ = self.executar()
        item = self.tentativa()
        self.assertEqual('inicial', item['tipo'])
        self.assertTrue(item['responsabilidade_resolvida'])
        self.assertEqual(['socket_tcp', 'arquivo_socket'], [r['tipo'] for r in item['recursos']])
        objeto.sendall.assert_called_once_with(b'SUBSCRIBE\n')
        objeto.connect.assert_called_once_with(('principal-simulado', 42100))
        prazos = [c.args[0] for c in objeto.settimeout.call_args_list]
        self.assertEqual(5, prazos[0])
        self.assertTrue(all(0 < prazo <= 6 for prazo in prazos[1:]))
        objeto.makefile.assert_called_once_with('r', encoding='utf-8')
        recursos = {r['recurso_id']: r for r in self.recursos()}
        self.assertEqual(item['recursos'][0]['recurso_id'],
                         recursos[item['recursos'][1]['recurso_id']]['associado_a'])

    def test_02_inicial_apos_parada(self):
        self.antes_da_admissao()
        self.assertEqual([], self.controle.obter_retrato()['tentativas'])

    def test_03_reconexao_normal(self):
        self.duas_conexoes(self.objeto(), self.objeto())
        itens = self.controle.obter_retrato()['tentativas']
        self.assertEqual(['inicial', 'reconexao'], [t['tipo'] for t in itens])
        self.assertEqual(2, len({t['tentativa_id'] for t in itens}))
        self.assertTrue(all(t['responsabilidade_resolvida'] for t in itens))
        self.assertEqual(4, len({r['recurso_id'] for t in itens for r in t['recursos']}))

    def test_04_reconexao_apos_parada(self):
        objetos = self.antes_da_admissao(reconexao=True)
        self.assertEqual(1, len(self.controle.obter_retrato()['tentativas']))
        objetos[0].sendall.assert_called_once_with(b'SUBSCRIBE\n')
        objetos[1].sendall.assert_not_called()

    def test_05_admissao_e_parada_simultaneas(self):
        barreira = threading.Barrier(2)
        aceitas, erros = [], []
        def admitir():
            try:
                barreira.wait(3)
                aceitas.append(self.controle.admitir())
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=admitir)
        thread.start()
        try:
            barreira.wait(3)
            self.leitor.parar()
        finally:
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(1, len(aceitas))
        self.assertEqual(int(aceitas[0] is not None), len(self.controle.obter_retrato()['tentativas']))
        self.assertIsNone(self.controle.admitir())

    def test_06_recusa_sem_fabrica_TCP(self):
        objetos = self.antes_da_admissao()
        self.assertEqual(4, len(self.recursos()))  # Apenas CONFIG e REGISTER.
        objetos[0].connect.assert_not_called()
        self.leitor.parar()
        with patch('socket.socket') as fabrica:
            self.assertIsNone(self.controle.admitir())
        fabrica.assert_not_called()

    def test_07_recusa_sem_mensagem(self):
        objeto, = self.antes_da_admissao()
        objeto.sendall.assert_not_called()
        objeto.makefile.assert_not_called()

    def test_08_aceita_antes_da_parada(self):
        objeto = self.suspender_apos_admissao(self.leitor.parar)
        objeto.sendall.assert_called_once_with(b'SUBSCRIBE\n')
        objeto.shutdown.assert_not_called()  # Não havia socket publicado na parada.
        self.assertTrue(self.tentativa()['responsabilidade_resolvida'])
        self.assertIsNone(self.controle.admitir())

    def test_09_aceita_sem_socket_permanece_pendente(self):
        def durante():
            self.assertEqual([], self.tentativa()['recursos'])
            self.assertFalse(self.tentativa()['iniciada'])
            self.assertFalse(self.tentativa()['responsabilidade_resolvida'])
            self.assertIsNone(self.leitor.cliente)
            self.conservador()
        self.suspender_apos_admissao(durante)

    def test_10_criacao_falha_antes_fabrica(self):
        criar = self.reg.criar
        def falhar(token, fabrica):
            if self.leitor.posicao_sucessao is not None:
                raise ValueError('antes_fabrica_simulada')
            return criar(token, fabrica)
        objeto = self.objeto()
        with patch.object(self.reg, 'criar', side_effect=falhar):
            self.executar(objeto)
        objeto.connect.assert_not_called()
        item = self.tentativa()
        self.assertEqual(1, len(item['recursos']))
        self.assertTrue(item['recursos'][0]['limpeza_confirmada'])
        self.assertTrue(item['responsabilidade_resolvida'])

    def test_11_makefile_falha_pai_acompanhado(self):
        objeto = self.objeto()
        objeto.makefile.side_effect = ValueError('makefile_simulado')
        self.executar(objeto)
        item = self.tentativa()
        self.assertTrue(item['recursos'][0]['limpeza_confirmada'])
        self.assertFalse(item['recursos'][1]['limpeza_confirmada'])
        self.assertTrue(objeto.fechado)
        self.assertFalse(item['responsabilidade_resolvida'])

    def test_12_pai_fechado_recusa_makefile(self):
        objeto = self.objeto()
        objeto.settimeout.side_effect = lambda valor: self.leitor.parar() if valor != 5 else None
        self.executar(objeto)
        objeto.makefile.assert_not_called()
        objeto.shutdown.assert_called_once_with(socket.SHUT_RDWR)
        self.assertEqual(['socket_tcp'], [r['tipo'] for r in self.tentativa()['recursos']])

    def test_13_erro_recebimento_preserva_comportamento(self):
        objeto = self.objeto()
        original = ValueError('leitura_simulada')
        objeto.arquivo.readline.side_effect = original
        _, imprimir = self.executar(objeto)
        imprimir.assert_any_call(f'Conexão com servidor perdida: {original}')
        self.leitor._aguardar_candidatura.assert_called_once_with()
        self.assertEqual({'categoria': 'falha_operacao'}, self.tentativa()['erro_operacao'])
        self.assertTrue(self.tentativa()['responsabilidade_resolvida'])

    def test_14_close_falha_sem_confirmacao(self):
        objeto = self.objeto()
        objeto.arquivo.erro_close = OSError()
        self.executar(objeto)
        self.assertTrue(self.tentativa()['recursos'][0]['limpeza_confirmada'])
        self.assertFalse(self.tentativa()['recursos'][1]['limpeza_confirmada'])
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])

    def test_15_promocao_com_SUBSCRIBE_antigo(self):
        origem = self.controle._geracao_id
        objeto = self.objeto()
        def receber():
            self.leitor.parar()
            self.infra.registro_recursos.promover(origem)
            self.assertFalse(self.tentativa()['responsabilidade_resolvida'])
            return ''
        objeto.arquivo.readline.side_effect = receber
        self.executar(objeto)
        self.assertEqual(origem, self.controle.obter_retrato()['geracao_id'])
        self.assertTrue(all(r['geracao_id'] == origem for r in self.recursos()))

    def test_16_consolidado_passivo_conservador(self):
        self.executar()
        antes = self.infra.obter_tentativas_subscribe()
        self.conservador()
        self.assertEqual(antes, self.infra.obter_tentativas_subscribe())

    def test_corrida_A_parada_antes_inicial(self):
        self.test_06_recusa_sem_fabrica_TCP()

    def test_corrida_B_aceita_antes_parada_socket_posterior(self):
        def durante():
            self.leitor.parar()
            self.assertEqual([], self.tentativa()['recursos'])
            self.assertFalse(self.tentativa()['responsabilidade_resolvida'])
        self.suspender_apos_admissao(durante)
        self.assertTrue(self.tentativa()['responsabilidade_resolvida'])

    def test_corrida_C_parada_entre_checagem_e_reconexao(self):
        admitir = self.controle.admitir
        a, b = self.objeto(), self.objeto()
        chamadas = []
        self.leitor._aguardar_candidatura = Mock(side_effect=lambda:
            (setattr(self.leitor, 'ip_servidor', 'principal-simulado'), False)[1])
        def executar(suspender):
            def atrasar():
                chamadas.append(True)
                if len(chamadas) == 2:
                    suspender()
                return admitir()
            with self.transporte([a, b]), patch.object(self.controle, 'admitir', side_effect=atrasar):
                self.leitor._manter_atualizado()
        self.retido(executar, self.leitor.parar)
        self.assertEqual(1, len(self.controle.obter_retrato()['tentativas']))
        b.sendall.assert_not_called()

    def test_corrida_D_fabrica_em_curso_contra_parada(self):
        objeto = self.objeto()
        def executar(suspender):
            with self.transporte([objeto]), patch('socket.socket', side_effect=lambda *_:
                    (suspender(), objeto)[1]):
                self.leitor._manter_atualizado()
        def durante():
            self.leitor.parar()
            self.assertEqual(1, len(self.tentativa()['recursos']))
            recurso_id = self.tentativa()['recursos'][0]['recurso_id']
            recurso = next(r for r in self.recursos() if r['recurso_id'] == recurso_id)
            self.assertTrue(recurso['criacao_em_curso'])
            self.assertFalse(self.tentativa()['responsabilidade_resolvida'])
        self.retido(executar, durante)
        self.assertTrue(self.tentativa()['responsabilidade_resolvida'])

    def test_corrida_E_A_pendente_B_independente(self):
        objeto = self.objeto()
        objeto.arquivo.erro_close = OSError('limpeza_simulada')
        def executar(suspender):
            objeto.arquivo.readline.side_effect = lambda: (suspender(), '')[1]
            self.executar(objeto)
        def durante():
            origem = self.controle._geracao_id
            self.leitor.parar()
            self.infra.registro_recursos.promover(origem)
            novo = self.novo_leitor()
            self.executar(leitor=novo)
            self.assertNotEqual(origem, novo._admissao_subscribe._geracao_id)
            self.assertEqual(2, len(self.infra.obter_tentativas_subscribe()))
            self.assertFalse(self.tentativa()['responsabilidade_resolvida'])
            self.assertIsNone(self.controle.admitir())
            self.conservador()
        self.retido(executar, durante)
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])

    def test_corrida_F_consulta_autorizacao_sem_socket(self):
        def durante():
            antes = self.infra.obter_tentativas_subscribe()
            self.assertEqual([], self.tentativa()['recursos'])
            self.assertFalse(self.tentativa()['responsabilidade_resolvida'])
            self.conservador()
            self.assertEqual(antes, self.infra.obter_tentativas_subscribe())
        self.suspender_apos_admissao(durante)

    def test_adicional_estabilidade_do_peso_e_reconexao(self):
        a, b = self.objeto(), self.objeto()
        pesos = [dict(estado='Z0', peso_bruto='12.50', tara='1.00', peso_liquido='11.50',
                      unidade='kg', multirange='1'),
                 dict(estado='Z1', peso_bruto='23.00', tara='2.00', peso_liquido='21.00',
                      unidade='kg', multirange='2')]
        leituras, recusas = [], []
        linhas_a = iter(['\n', json.dumps(pesos[0]) + '\n'])
        def primeira():
            try:
                return next(linhas_a)
            except StopIteration:
                leituras.append(self.leitor.obter_dados_atuais())
                return ''
        chamadas_b = []
        def segunda():
            chamadas_b.append(True)
            if len(chamadas_b) == 1:
                return json.dumps(pesos[1]) + '\n'
            leituras.append(self.leitor.obter_dados_atuais())
            self.leitor.parar()
            recusas.append(self.controle.admitir())
            return ''
        a.arquivo.readline.side_effect = primeira
        b.arquivo.readline.side_effect = segunda
        self.leitor._aguardar_candidatura = Mock(side_effect=lambda:
            (setattr(self.leitor, 'ip_servidor', 'principal-simulado'), False)[1])
        with self.transporte([a, b]):
            self.leitor._manter_atualizado()
        self.assertEqual(pesos, leituras)
        self.assertEqual(pesos[-1], self.leitor.obter_dados_atuais())
        self.assertEqual([None], recusas)
        self.assertEqual(['inicial', 'reconexao'], [t['tipo'] for t in self.controle.obter_retrato()['tentativas']])
        self.assertTrue(all(t['responsabilidade_resolvida'] for t in self.controle.obter_retrato()['tentativas']))

    def test_parada_repetida_nao_reabre_A(self):
        self.leitor.parar()
        self.leitor.parar()
        novo = self.novo_leitor()
        self.assertIsNone(self.controle.admitir())
        self.assertIsNotNone(novo._admissao_subscribe.admitir())
        self.assertTrue(self.controle.obter_retrato()['admissao_fechada'])

    def test_sem_thread_ou_retry_artificial(self):
        antes = self.infra.obter_atividades_permanentes()
        with patch.object(type(self.infra), 'observar_termino_leitores', side_effect=AssertionError('implicito')):
            self.duas_conexoes(self.objeto(), self.objeto())
            self.conservador()
        self.assertEqual(antes, self.infra.obter_atividades_permanentes())
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()['retentativas'])

    def test_publicador_escreve_e_lanca(self):
        publicar = self.controle._publicar_saida
        def falhar(*args):
            publicar(*args)
            raise ValueError('publicacao_simulada')
        with patch.object(self.controle, '_publicar_saida', side_effect=falhar):
            with self.assertRaises(ValueError):
                self.executar()
        self.assertFalse(self.tentativa()['retorno'])
        self.assertTrue(self.tentativa()['erro_publicacao'])
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])

    def test_erro_leitura_e_publicacao_preservados(self):
        objeto = self.objeto()
        original = ValueError('leitura_simulada')
        diagnostico = OSError('publicacao_simulada')
        objeto.arquivo.readline.side_effect = original
        with patch.object(self.controle, '_publicar_saida', side_effect=diagnostico):
            _, imprimir = self.executar(objeto)
        imprimir.assert_any_call(f'Conexão com servidor perdida: {original}')
        self.assertIs(diagnostico, original.__cause__)
        self.assertTrue(self.tentativa()['erro_publicacao'])

    def test_baseexception_preservada_com_publicacao_falha(self):
        objeto = self.objeto()
        original = KeyboardInterrupt()
        objeto.arquivo.readline.side_effect = original
        with patch.object(self.controle, '_publicar_saida', side_effect=OSError()):
            with self.assertRaises(KeyboardInterrupt) as capturado:
                self.executar(objeto)
        self.assertIs(original, capturado.exception)
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])

    def test_publicacao_criacao_incerta_retem_handle(self):
        objeto = self.objeto()
        objeto.erro_close = OSError('close_simulado')
        referencia = weakref.ref(objeto)
        criar = self.reg.criar
        def falhar(token, fabrica):
            if self.leitor.posicao_sucessao is None:
                return criar(token, fabrica)
            fabrica()
            raise ValueError('publicacao_simulada')
        with patch.object(self.reg, 'criar', side_effect=falhar):
            self.executar(objeto)
        del objeto
        gc.collect()
        self.assertIsNotNone(referencia())
        self.assertTrue(self.controle._publicacoes_pendentes)
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])

    def test_falha_vinculo_sem_alocar(self):
        objeto = self.objeto()
        with patch.object(RecursosSubscribeCliente, '_publicar_vinculo', side_effect=ValueError()):
            self.executar(objeto)
        objeto.connect.assert_not_called()
        self.assertTrue(self.tentativa()['erro_associacao'])
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])

    def test_fabrica_opaca_falha_reserva_incerta(self):
        with self.transporte([ValueError('fabrica_simulada')]):
            self.leitor._manter_atualizado()
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])
        self.assertEqual(1, len(self.tentativa()['recursos']))

    def test_limpeza_individual_socket_nao_prova_arquivo(self):
        objeto = self.objeto()
        def executar(suspender):
            objeto.arquivo.readline.side_effect = lambda: (suspender(), '')[1]
            self.executar(objeto)
        def durante():
            self.leitor.parar()
            self.assertFalse(self.tentativa()['recursos'][0]['limpeza_confirmada'])
            self.assertFalse(self.tentativa()['recursos'][1]['limpeza_confirmada'])
            self.assertTrue(self.tentativa()['em_curso'])
            self.assertFalse(self.tentativa()['responsabilidade_resolvida'])
        self.retido(executar, durante)
        self.assertTrue(self.tentativa()['responsabilidade_resolvida'])

    def test_lock_livre_em_connect_envio_leitura_shutdown_close(self):
        objeto = self.objeto()
        def verificar(*_):
            livre = self.controle._lock.acquire(blocking=False)
            self.assertTrue(livre)
            if livre:
                self.controle._lock.release()
        objeto.connect.side_effect = verificar
        objeto.sendall.side_effect = verificar
        objeto.shutdown.side_effect = verificar
        objeto.arquivo.readline.side_effect = lambda: (verificar(), self.leitor.parar(), '')[-1]
        fechar = objeto.close
        objeto.close = lambda: (verificar(), fechar())[-1]
        self.executar(objeto)

    def test_geracao_antiga_retida_sem_leitor(self):
        self.executar()
        retrato = self.controle.obter_retrato()
        referencia = weakref.ref(self.controle)
        del self.leitor, self.controle
        gc.collect()
        self.assertIsNotNone(referencia())
        self.assertEqual([retrato], self.infra.obter_tentativas_subscribe())

    def test_uma_autorizacao_nao_pode_ser_reutilizada(self):
        identidade = self.controle.admitir()
        self.controle.iniciar(identidade)
        self.controle.finalizar(identidade)
        with self.assertRaises(RuntimeError):
            self.controle.iniciar(identidade)

    def test_socket_de_outra_tentativa_recusado(self):
        a, b = self.controle.admitir(), self.controle.admitir()
        dono_a, dono_b = self.controle.iniciar(a), self.controle.iniciar(b)
        cliente = dono_a.abrir_socket(self.objeto)
        try:
            with self.assertRaises(ValueError):
                dono_b.abrir_socket(cliente)
        finally:
            cliente.close()
            self.controle.finalizar(a)
            self.controle.finalizar(b)

    def test_SUBSCRIBE_terminado_nao_prova_thread_terminada(self):
        entrou, liberar = threading.Event(), threading.Event()
        def candidatura():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return False
        self.leitor._aguardar_candidatura = Mock(side_effect=candidatura)
        self.leitor.executando = False
        with self.transporte([self.objeto()]):
            self.leitor.iniciar()
            try:
                self.assertTrue(entrou.wait(3))
                self.assertTrue(self.tentativa()['responsabilidade_resolvida'])
                atividade, = self.infra.obter_atividades_permanentes()['atividades']
                self.assertTrue(atividade['execucao_em_curso'])
                self.assertFalse(atividade['termino_confirmado'])
                self.assertTrue(self.leitor.thread.is_alive())
                with patch.object(type(self.infra), 'observar_termino_leitores', side_effect=AssertionError('implicito')):
                    self.conservador()
            finally:
                self.leitor.parar()
                liberar.set()
                self.leitor.thread.join(3)
        self.assertFalse(self.leitor.thread.is_alive())
        self.assertFalse(self.infra.obter_atividades_permanentes()['atividades'][0]['termino_confirmado'])

    def test_criacao_e_publicacao_de_ausencia_preservam_original(self):
        criar, comprovar = self.reg.criar, self.reg.comprovar_ausencia
        original = ValueError('criacao_simulada')
        def falhar(token, fabrica):
            if self.leitor.posicao_sucessao is not None:
                raise original
            return criar(token, fabrica)
        def falhar_prova(*args, **kwargs):
            if self.leitor.posicao_sucessao is not None:
                raise OSError('evidencia_simulada')
            return comprovar(*args, **kwargs)
        with patch.object(self.reg, 'criar', side_effect=falhar), \
                patch.object(self.reg, 'comprovar_ausencia', side_effect=falhar_prova):
            _, imprimir = self.executar()
        imprimir.assert_any_call(f'Conexão com servidor perdida: {original}')
        self.assertEqual({'categoria': 'falha_operacao'}, self.tentativa()['erro_operacao'])
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])

    def test_legado_admissao_sem_inventar_prova_de_limpeza(self):
        leitor = LeitorDadosServidor('principal-simulado')
        leitor.executando = True
        config, registro, subscribe = self.objeto(), MagicMock(), self.objeto()
        config.arquivo.readline.return_value = '{}'
        registro.__enter__.return_value = registro
        registro.makefile.return_value.__enter__.return_value.readline.return_value = json.dumps(
            {'nome': leitor.nome_computador, 'posicao': 1})
        subscribe.arquivo.readline.side_effect = lambda: (leitor.parar(), '')[-1]
        with patch('socket.getaddrinfo', return_value=[
                (socket.AF_INET, socket.SOCK_STREAM, 6, '', ('simulado', 42100))]), \
                patch('socket.socket', side_effect=[config, subscribe]), \
                patch('socket.create_connection', return_value=registro), patch('builtins.print'):
            leitor._manter_atualizado()
        subscribe.sendall.assert_called_once_with(b'SUBSCRIBE\n')
        self.assertIsNone(leitor._admissao_subscribe.admitir())
        item, = leitor.obter_tentativas_subscribe()['tentativas']
        self.assertFalse(item['responsabilidade_resolvida'])
        self.assertEqual([], item['recursos'])

# Testes de admissao descoberta inicial cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-C4: entrada inicial real com transporte falso e corridas por eventos."""
import gc
import socket
import threading
import unittest
import weakref
from unittest.mock import Mock, patch

from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.lerdadosserver import LeitorDadosServidor
from rede import buscarservidor as busca
from test_descoberta_cliente_integrada import SocketDescobertaFalso
import test_associacoes_retentativas_cliente as associacoes


# Grupo de 33 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AdmissaoDescobertaInicialCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.leitor.executando = True
        self.controle = self.leitor._admissao_descoberta_inicial

    def recursos(self):
        return self.infra.registro_recursos.obter_retrato()['recursos']

    def operacao(self):
        return self.leitor.obter_operacoes_descoberta_inicial()['operacoes'][0]

    def buscar(self, udp=None, tcp=None, leitor=None):
        udp, tcp = udp or SocketDescobertaFalso(), tcp or SocketDescobertaFalso()
        with patch('socket.socket', side_effect=lambda familia, tipo:
                   udp if tipo == socket.SOCK_DGRAM else tcp):
            return (leitor or self.leitor)._buscar_servidor_inicial()

    def resposta(self, antes=None):
        udp = SocketDescobertaFalso()
        def receber(_):
            if antes:
                antes()
            return b'TC420_SERVER_HERE', ('simulado', 42101)
        udp.recvfrom.side_effect = receber
        return udp

    def conservador(self):
        resultado = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(resultado['encerramento_cliente_confirmado'])
        self.assertFalse(resultado['encerramento_global_confirmado'])
        self.assertEqual('incompleta', resultado['cobertura_operacional'])

    def retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []
        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
        def alvo():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=alvo, daemon=True)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_01_normal_admitida(self):
        self.assertEqual('simulado', self.buscar(self.resposta()))
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])
        self.assertEqual(['socket_udp', 'socket_tcp'],
                         [r['tipo'] for r in self.operacao()['recursos']])

    def test_02_parada_antes_recusa(self):
        self.leitor.parar()
        with patch('rede.lerdadosserver.buscar_servidor') as buscar:
            self.assertIsNone(self.leitor._buscar_servidor_inicial())
        buscar.assert_not_called()
        self.assertEqual([], self.controle.obter_retrato()['operacoes'])

    def test_03_simultanea_atomica(self):
        barreira = threading.Barrier(2)
        aceitas, erros = [], []
        def admitir():
            try:
                barreira.wait(3)
                aceitas.append(self.controle.admitir())
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=admitir)
        thread.start()
        try:
            barreira.wait(3)
            self.leitor.parar()
        finally:
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(1, len(aceitas))
        self.assertEqual(int(aceitas[0] is not None),
                         len(self.controle.obter_retrato()['operacoes']))
        self.assertIsNone(self.controle.admitir())

    def test_04_recusada_sem_socket(self):
        self.leitor.parar()
        with patch('socket.socket') as fabrica:
            self.leitor._manter_atualizado()
        fabrica.assert_not_called()
        self.assertEqual([], self.recursos())

    def test_05_recusada_sem_envio(self):
        udp = SocketDescobertaFalso()
        self.leitor.parar()
        self.buscar(udp)
        udp.sendto.assert_not_called()

    def test_06_aceita_antes_parada_sem_reserva(self):
        identidade = self.controle.admitir()
        self.leitor.parar()
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])
        self.assertEqual([], self.recursos())
        with self.controle.executar(identidade) as dono:
            with patch('socket.socket', return_value=SocketDescobertaFalso()):
                busca.buscar_servidor(recursos_cliente=dono)
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])

    def test_07_parada_depois_reserva(self):
        def executar(suspender):
            with patch('socket.socket', side_effect=lambda *_: (suspender(), SocketDescobertaFalso())[-1]):
                self.leitor._buscar_servidor_inicial()
        def durante():
            self.leitor.parar()
            self.assertEqual(1, len(self.operacao()['recursos']))
            self.assertTrue(self.recursos()[0]['criacao_em_curso'])
            self.assertFalse(self.operacao()['responsabilidade_resolvida'])
        self.retido(executar, durante)
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])

    def test_08_parada_depois_criacao(self):
        udp = SocketDescobertaFalso()
        def receber(_):
            self.leitor.parar()
            self.assertFalse(self.operacao()['responsabilidade_resolvida'])
            raise socket.timeout()
        udp.recvfrom.side_effect = receber
        self.buscar(udp)
        self.assertTrue(udp.fechado)
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])

    def test_09_erro_criacao_opaca_conserva_reserva(self):
        erro = OSError('fabrica_simulada')
        with patch('socket.socket', side_effect=erro):
            with self.assertRaises(OSError) as capturado:
                self.leitor._buscar_servidor_inicial()
        self.assertIs(erro, capturado.exception)
        # Entrar em fábrica opaca e lançar não comprova ausência de alocação.
        self.assertEqual(1, len(self.operacao()['recursos']))
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])

    def test_10_erro_comunicacao_original(self):
        udp = SocketDescobertaFalso()
        erro = ValueError('recepcao_simulada')
        udp.recvfrom.side_effect = erro
        with self.assertRaises(ValueError) as capturado:
            self.buscar(udp)
        self.assertIs(erro, capturado.exception)
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])

    def test_11_erro_close_nao_confirma(self):
        udp = SocketDescobertaFalso()
        udp.erro_close = OSError('close_simulado')
        with self.assertRaises(OSError):
            self.buscar(udp)
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])
        self.assertFalse(self.operacao()['recursos'][0]['limpeza_confirmada'])

    def test_12_publicacao_resultado_conservadora(self):
        with patch.object(self.controle, '_publicar_saida', side_effect=ValueError()):
            with self.assertRaises(ValueError):
                self.buscar()
        self.assertFalse(self.operacao()['retorno'])
        self.assertTrue(self.operacao()['erro_publicacao'])
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])

    def test_13_promocao_durante_busca(self):
        origem = self.leitor.recursos_cliente.geracao_id
        def promover():
            self.infra.registro_recursos.promover(origem)
            self.leitor.parar()
            novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
            self.assertNotEqual(origem, novo.recursos_cliente.geracao_id)
            self.buscar(leitor=novo)
            self.assertEqual(2, len(self.infra.obter_operacoes_descoberta_inicial()))
        self.buscar(self.resposta(promover))
        self.assertEqual(origem, self.operacao()['geracao_id'])
        ids = {r['recurso_id'] for r in self.operacao()['recursos']}
        self.assertTrue(all(r['geracao_id'] == origem for r in self.recursos() if r['recurso_id'] in ids))

    def test_14_nova_geracao_independente(self):
        self.leitor.parar()
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.buscar(leitor=novo)
        self.assertIsNone(self.controle.admitir())
        self.assertTrue(novo.obter_operacoes_descoberta_inicial()['operacoes'][0]['responsabilidade_resolvida'])

    def test_15_recuperacao_preservada(self):
        # A fixture executa a rotina real dentro da guarda/associação AC2-C.
        fx = associacoes.AssociacoesRetentativasCliente()
        fx.setUp()
        fx.leitor._admissao_descoberta_inicial.fechar_admissao()
        fx.executar_descoberta(resposta=False)
        self.assertEqual([], fx.leitor.obter_operacoes_descoberta_inicial()['operacoes'])
        self.assertEqual(1, len(fx.infra.obter_associacoes_retentativas()))

    def test_16_preparacao_independente(self):
        self.leitor.parar()
        udp = SocketDescobertaFalso()
        with patch('socket.socket', return_value=udp):
            busca.buscar_servidor(infraestrutura_cliente=self.infra)
        udp.sendto.assert_called_once()
        self.assertNotEqual(self.leitor.recursos_cliente.geracao_id, self.recursos()[0]['geracao_id'])
        self.assertEqual([], self.infra.obter_associacoes_retentativas())

    def test_corrida_A_parada_primeiro(self):
        self.test_04_recusada_sem_socket()

    def test_corrida_B_admitida_antes_udp(self):
        executar_original = self.controle.executar
        def executar(suspender):
            def atrasar(identidade):
                suspender()
                return executar_original(identidade)
            with patch.object(self.controle, 'executar', side_effect=atrasar):
                self.buscar()
        def durante():
            self.leitor.parar()
            self.assertEqual([], self.recursos())
            self.assertFalse(self.operacao()['iniciada'])
            self.assertFalse(self.operacao()['responsabilidade_resolvida'])
        self.retido(executar, durante)
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])

    def test_corrida_C_parada_entre_checagem_e_admissao(self):
        def imprimir(*args):
            if args == ('Procurando servidor TC420...',):
                self.leitor.parar()
        with patch('builtins.print', side_effect=imprimir), patch('socket.socket') as fabrica:
            self.leitor._manter_atualizado()
        fabrica.assert_not_called()
        self.assertEqual([], self.controle.obter_retrato()['operacoes'])

    def test_corrida_D_geracao_antiga_retida(self):
        self.buscar()
        referencia = weakref.ref(self.controle)
        self.leitor.parar()
        del self.leitor, self.controle
        gc.collect()
        self.assertIsNotNone(referencia())
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.buscar(leitor=novo)
        self.assertEqual(2, len(self.infra.obter_operacoes_descoberta_inicial()))

    def test_corrida_E_autoridades_distintas(self):
        fx = associacoes.AssociacoesRetentativasCliente()
        fx.setUp()
        udp, tcp = SocketDescobertaFalso(), SocketDescobertaFalso()
        def receber(_):
            fx.leitor.parar()
            with patch('rede.lerdadosserver.buscar_servidor') as buscar:
                fx.leitor._buscar_servidor_inicial()
            buscar.assert_not_called()
            return b'TC420_SERVER_HERE', ('simulado', 42101)
        udp.recvfrom.side_effect = receber
        fx.executar_descoberta(resposta=False, udp=udp, tcp=tcp)
        tcp.sendall.assert_called_once_with(b'CHECK\n')
        self.assertEqual(2, len(fx.infra.obter_associacoes_retentativas()[0]['recursos']))
        self.assertEqual([], fx.leitor.obter_operacoes_descoberta_inicial()['operacoes'])

    def test_corrida_F_consulta_sem_socket_nao_resolve(self):
        self.controle.admitir()
        antes = self.infra.obter_operacoes_descoberta_inicial()
        self.assertEqual([], antes[0]['operacoes'][0]['recursos'])
        self.assertFalse(antes[0]['operacoes'][0]['responsabilidade_resolvida'])
        self.conservador()
        self.assertEqual(antes, self.infra.obter_operacoes_descoberta_inicial())

    def test_adicional_CHECK_nao_admitido_apos_parada(self):
        tcp = SocketDescobertaFalso()
        # AC3-C5: ter admitido a busca não autoriza CHECK após a parada.
        self.assertIsNone(self.buscar(self.resposta(self.leitor.parar), tcp))
        tcp.connect.assert_not_called()
        tcp.sendall.assert_not_called()
        self.assertEqual(1, len(self.operacao()['recursos']))
        self.assertEqual([], self.controle.obter_retrato()['checks'])
        self.test_05_recusada_sem_envio()
        self.assertEqual(1, len(self.controle.obter_retrato()['operacoes']))

    def test_falha_antes_reserva_resolve_sem_recurso(self):
        with patch('rede.lerdadosserver.buscar_servidor', side_effect=ValueError()):
            with self.assertRaises(ValueError):
                self.leitor._buscar_servidor_inicial()
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])
        self.assertEqual([], self.recursos())

    def test_falha_publicacao_reserva_sem_fabrica(self):
        from rede.admissao_descoberta_inicial_cliente import RecursosDescobertaInicialCliente
        with patch.object(RecursosDescobertaInicialCliente, '_publicar_vinculo', side_effect=ValueError()), \
                patch('socket.socket') as fabrica:
            with self.assertRaises(ValueError):
                self.leitor._buscar_servidor_inicial()
        fabrica.assert_not_called()
        self.assertTrue(self.operacao()['erro_associacao'])
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])

    def test_erro_operacao_e_close_preserva_primario(self):
        udp = SocketDescobertaFalso()
        erro = ValueError('primario_simulado')
        udp.recvfrom.side_effect = erro
        udp.erro_close = OSError('limpeza_simulada')
        with self.assertRaises(ValueError) as capturado:
            self.buscar(udp)
        self.assertIs(erro, capturado.exception)
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])

    def test_erro_operacao_e_publicacao_preserva_primario(self):
        erro = ValueError('primario_simulado')
        with patch('rede.lerdadosserver.buscar_servidor', side_effect=erro), \
                patch.object(self.controle, '_publicar_saida', side_effect=OSError()):
            with self.assertRaises(ValueError) as capturado:
                self.leitor._buscar_servidor_inicial()
        self.assertIs(erro, capturado.exception)
        self.assertTrue(self.operacao()['erro_publicacao'])

    def test_falha_antes_fabrica_comprova_ausencia(self):
        with patch.object(self.infra.registro_recursos, 'criar', side_effect=ValueError()), \
                patch('socket.socket') as fabrica:
            with self.assertRaises(ValueError):
                self.leitor._buscar_servidor_inicial()
        fabrica.assert_not_called()
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])

    def test_identidades_nao_duplicadas(self):
        self.buscar(self.resposta())
        self.assertEqual({r['recurso_id'] for r in self.recursos()},
                         {r['recurso_id'] for r in self.operacao()['recursos']})
        self.assertEqual([], self.infra.obter_associacoes_retentativas())
        self.assertEqual([], self.leitor.obter_operacoes_register()['operacoes'])

    def test_legado_recusa_sem_alegar_prova(self):
        leitor = LeitorDadosServidor()
        self.buscar(leitor=leitor)
        self.assertFalse(leitor.obter_operacoes_descoberta_inicial()['operacoes'][0]['responsabilidade_resolvida'])
        leitor.parar()
        with patch('socket.socket') as fabrica:
            leitor._manter_atualizado()
        fabrica.assert_not_called()

    def test_publicacao_criacao_e_close_falhos_retem_handle(self):
        udp = SocketDescobertaFalso()
        udp.erro_close = OSError('close_simulado')
        referencia = weakref.ref(udp)
        def falhar(token, alocar):
            alocar()
            raise ValueError('publicacao_simulada')
        with patch.object(self.infra.registro_recursos, 'criar', side_effect=falhar):
            with self.assertRaises(ValueError):
                self.buscar(udp)
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])
        del udp
        gc.collect()
        self.assertIsNotNone(referencia())
        self.assertTrue(self.controle._publicacoes_pendentes)

    def test_erro_apos_alocacao_limpa_sem_perder_reserva(self):
        udp = SocketDescobertaFalso()
        criar = self.infra.registro_recursos.criar
        def falhar(token, fabrica):
            return criar(token, fabrica, preparar=Mock(side_effect=ValueError()))
        with patch.object(self.infra.registro_recursos, 'criar', side_effect=falhar):
            with self.assertRaises(ValueError):
                self.buscar(udp)
        self.assertTrue(udp.fechado)
        self.assertEqual(1, len(self.operacao()['recursos']))
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])

    def test_protocolo_e_timeouts_preservados(self):
        udp, tcp = self.resposta(), SocketDescobertaFalso()
        self.buscar(udp, tcp)
        udp.sendto.assert_called_once_with(b'TC420_SERVER_DISCOVERY', ('255.255.255.255', 42101))
        tcp.sendall.assert_called_once_with(b'CHECK\n')
        udp.settimeout.assert_called_once_with(2)
        tcp.settimeout.assert_called_once_with(2)
        self.conservador()

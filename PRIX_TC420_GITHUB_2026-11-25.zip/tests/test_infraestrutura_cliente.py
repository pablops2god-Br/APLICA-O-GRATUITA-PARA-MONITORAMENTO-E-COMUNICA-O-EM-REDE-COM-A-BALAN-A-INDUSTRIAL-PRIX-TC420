# Testes de infraestrutura cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Instalação passiva: funções reais por AST e dependências de rede/Tk falsas."""
import ast
from dataclasses import FrozenInstanceError
from pathlib import Path
from types import SimpleNamespace
import threading
import unittest
from unittest.mock import Mock, patch

from rede import infraestrutura_cliente as modulo
from rede import servidor
from test_registro_automatico import carregar_fluxos, ThreadFila


class ThreadControlada(ThreadFila):
    def join(self, timeout):
        pass  # Thread falsa; alvo só executa quando o ensaio ordenar.


# Grupo de 21 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class InfraestruturaCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        ThreadFila.criadas = []
        self.env = carregar_fluxos()
        raiz = Path(__file__).resolve().parents[1]
        arvore = ast.parse((raiz / "main.py").read_text(encoding="utf-8"))
        funcoes = [n for n in arvore.body if isinstance(n, ast.FunctionDef)
                   and n.name in ("iniciar_como_cliente", "obter_credenciais_salvas")]
        exec(compile(ast.Module(body=funcoes, type_ignores=[]), "main.py", "exec"), self.env)
        self.env["threading"] = SimpleNamespace(
            Thread=ThreadControlada, Event=threading.Event, Lock=threading.Lock)
        self.env["obter_dados_atuais"] = Mock()
        self.leitores, self.monitores, self.conexoes = [], [], []
        self.durante_monitor = lambda monitor: None
        self.durante_conexao = lambda conexao: None

        def leitor(**kwargs):
            novo = SimpleNamespace(
                argumentos=kwargs, iniciar=Mock(), parar=Mock(),
                recursos_cliente=(modulo.RecursosLeitorCliente(kwargs["infraestrutura_cliente"])
                                  if kwargs.get("infraestrutura_cliente") is not None else None),
                aguardar_configuracao=Mock(return_value=None), obter_dados_atuais=Mock(),
                candidatura_esta_liberada=Mock(return_value=True),
                obter_estado_candidatura=Mock(return_value="liberada"),
                registrar_falha_recuperacao=Mock())
            self.leitores.append(novo)
            return novo

        def monitor(**kwargs):
            novo = SimpleNamespace(**kwargs, observar_rebaixamento=Mock(),
                                   associar_contexto_promocao=Mock(), supervisionar_principal=Mock())
            novo.executar = Mock(side_effect=lambda: self.durante_monitor(novo))
            self.monitores.append(novo)
            return novo

        def conexao(**kwargs):
            novo = SimpleNamespace(**kwargs)
            novo.executar = Mock(side_effect=lambda: self.durante_conexao(novo))
            self.conexoes.append(novo)
            return novo

        self.env["LeitorDadosServidor"] = Mock(side_effect=leitor)
        self.env["JanelaTC420"] = Mock(side_effect=monitor)
        self.env["JanelaConexao"] = Mock(side_effect=conexao)

    def iniciar_cliente(self, infra=None):
        self.env["iniciar_como_cliente"]("principal-simulado", infraestrutura_cliente=infra)

    def iniciar_descoberto(self):
        self.env["buscar_servidor"].return_value = "principal-simulado"
        self.env["iniciar"]()
        return self.monitores[-1].infraestrutura_cliente

    def sem_confirmacao(self, infra):
        resultado = infra.avaliar()
        self.assertFalse(resultado["encerramento_confirmado"])
        self.assertFalse(resultado["cobertura_completa"])
        self.assertEqual("incompleta", resultado["cobertura_operacional"])
        return resultado

    def test_01_criada_uma_vez_na_inicializacao(self):
        with patch.object(modulo, "GuardaRetentativasCliente", wraps=modulo.GuardaRetentativasCliente) as t, \
                patch.object(modulo, "RegistroRecursosCliente", wraps=modulo.RegistroRecursosCliente) as r, \
                patch.object(modulo, "InfraestruturaRegistrosCliente", wraps=modulo.InfraestruturaRegistrosCliente) as f:
            infra = self.iniciar_descoberto()
        f.assert_called_once_with()
        t.assert_called_once_with()
        r.assert_called_once_with()
        self.assertIs(infra, self.leitores[0].infraestrutura_cliente)
        self.leitores[0].iniciar.assert_called_once_with()
        self.leitores[0].parar.assert_called_once_with()

    def test_02_execucoes_independentes(self):
        a, b = self.iniciar_descoberto(), self.iniciar_descoberto()
        self.assertIsNot(a, b)
        self.assertIsNot(a.registro_retentativas, b.registro_retentativas)
        self.assertIsNot(a.registro_recursos, b.registro_recursos)
        self.assertNotEqual(a.aplicacao_id, b.aplicacao_id)

    def preparar_promocao(self):
        self.env["buscar_servidor"].side_effect = ["principal-simulado", None, None]
        resultados = []

        def promover(monitor):
            antes = monitor.infraestrutura_cliente
            resultados.append(monitor.ao_promover_automaticamente())
            self.assertIs(antes, monitor.infraestrutura_cliente)
            self.assertIs(antes, self.leitores[0].infraestrutura_cliente)

        self.durante_monitor = promover
        return resultados

    def test_03_promocao_preserva_registros(self):
        resultados = self.preparar_promocao()
        with patch.object(modulo, "InfraestruturaRegistrosCliente", wraps=modulo.InfraestruturaRegistrosCliente) as f:
            self.env["iniciar"]()
        f.assert_called_once_with()
        self.assertIsNotNone(resultados[0])
        self.env["iniciar_servidor"].assert_not_called()  # Alvo daemon falso ainda não entrou.
        self.leitores[0].parar.assert_called()

    def test_04_clientes_posteriores_mesmo_proprietario(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        self.iniciar_cliente(infra)
        self.iniciar_cliente(infra)
        self.assertEqual(2, len(self.leitores))
        self.assertTrue(all(l.infraestrutura_cliente is infra for l in self.leitores))
        self.assertEqual([], infra.registro_retentativas.obter_retrato()["retentativas"])

    def test_05_sem_atividades_nao_confirma(self):
        self.sem_confirmacao(modulo.InfraestruturaRegistrosCliente())

    def test_06_cobertura_fechada_ainda_incompleta(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        infra.registro_retentativas.fechar_admissao()
        infra.registro_recursos.fechar_admissao()
        resultado = self.sem_confirmacao(infra)
        self.assertTrue(resultado["consistente"])
        self.assertTrue(resultado["admissoes_fechadas"])

    def test_07_consulta_somente_leitura(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        antes = (infra.registro_retentativas.obter_retrato(), infra.registro_recursos.obter_retrato())
        self.sem_confirmacao(infra)
        self.assertEqual(antes, (infra.registro_retentativas.obter_retrato(), infra.registro_recursos.obter_retrato()))

    def test_08_referencias_compartilhadas_no_fallback_manual(self):
        self.env["buscar_servidor"].return_value = None
        self.env["tentar_login_automatico"] = Mock(return_value=False)
        self.durante_conexao = lambda conexao: conexao.ao_encontrar_servidor("principal-simulado")
        self.env["iniciar"]()
        self.assertIs(self.conexoes[0].infraestrutura_cliente, self.monitores[0].infraestrutura_cliente)
        self.assertIs(self.conexoes[0].infraestrutura_cliente, self.leitores[0].infraestrutura_cliente)

    def test_09_compatibilidade_sem_novo_parametro(self):
        with patch.object(modulo, "InfraestruturaRegistrosCliente") as criar:
            self.env["iniciar_como_cliente"]("principal-simulado")
        criar.assert_not_called()
        self.assertFalse(hasattr(self.leitores[0], "infraestrutura_cliente"))
        self.assertFalse(hasattr(self.monitores[0], "infraestrutura_cliente"))
        self.leitores[0].iniciar.assert_called_once_with()
        self.leitores[0].parar.assert_called_once_with()

    def test_10_falha_construcao_nao_publica_pronto(self):
        tipo = modulo.InfraestruturaRegistrosCliente
        objeto = tipo.__new__(tipo)
        with patch.object(modulo, "RegistroRecursosCliente", side_effect=OSError()):
            with self.assertRaises(OSError):
                tipo.__init__(objeto)
        self.assertFalse(hasattr(objeto, "_contexto"))

    def consultar_em_paralelo(self, infra, operacao=lambda: None):
        barreira = threading.Barrier(3)
        erros, resultados = [], []

        def consultar():
            try:
                barreira.wait(3)
                operacao()
                for _ in range(10):
                    resultados.append(self.sem_confirmacao(infra))
            except BaseException as erro:
                erros.append(erro)

        threads = [threading.Thread(target=consultar) for _ in range(2)]
        for thread in threads:
            thread.start()
        barreira.wait(3)
        for thread in threads:
            thread.join(3)
            self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(20, len(resultados))
        self.assertTrue(all(r["aplicacao_id"] == infra.aplicacao_id for r in resultados))

    def test_11_duas_consultas_concorrentes(self):
        self.consultar_em_paralelo(modulo.InfraestruturaRegistrosCliente())

    def test_12_estado_desconhecido_conservador(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        token = infra.registro_recursos.reservar("socket_tcp", 1, 1)
        self.assertIsNotNone(token)
        self.assertEqual("desconhecido", infra.registro_recursos.obter_retrato()["recursos"][0]["estado"])
        self.sem_confirmacao(infra)

    def test_13_retentativas_vazias_nao_provam_global(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        infra.registro_recursos.reservar("socket_udp", 1, 1)
        self.assertEqual([], infra.registro_retentativas.obter_retrato()["retentativas"])
        self.sem_confirmacao(infra)

    def test_14_recursos_vazios_nao_provam_limpeza(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        geracao = infra.registro_retentativas.nova_geracao_cliente()
        infra.registro_retentativas.reservar_retentativa(geracao)
        self.assertEqual([], infra.registro_recursos.obter_retrato()["recursos"])
        self.sem_confirmacao(infra)

    def test_15_servidores_independentes(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        registro = servidor.RegistroTentativasAplicacao()
        registro.fechar_admissao()
        self.assertTrue(servidor.avaliar_encerramento_aplicacao(registro)["encerramento_confirmado"])
        self.assertFalse(infra.registro_retentativas.obter_retrato()["admissao_fechada"])
        self.sem_confirmacao(infra)

    def test_16_promocao_concorrente_nao_recria(self):
        self.preparar_promocao()
        original = self.durante_monitor

        def concorrente(monitor):
            infra = monitor.infraestrutura_cliente
            self.consultar_em_paralelo(infra)
            original(monitor)
            self.sem_confirmacao(infra)

        self.durante_monitor = concorrente
        with patch.object(modulo, "InfraestruturaRegistrosCliente", wraps=modulo.InfraestruturaRegistrosCliente) as criar:
            self.env["iniciar"]()
        criar.assert_called_once_with()

    def test_critico_A_promocao_retida_e_identidade(self):
        self.env["buscar_servidor"].side_effect = ["principal-simulado", None, None]
        entrou, liberar = threading.Event(), threading.Event()
        erros = []

        def login(*args):
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("harness")

        self.env["WebTC420"].return_value.login.side_effect = login

        def durante(monitor):
            infra = monitor.infraestrutura_cliente

            def promover():
                try:
                    resultado = monitor.ao_promover_automaticamente()
                    self.assertIsNotNone(resultado)
                except BaseException as erro:
                    erros.append(erro)

            thread = threading.Thread(target=promover)
            thread.start()
            try:
                self.assertTrue(entrou.wait(3))
                self.assertIs(infra, self.leitores[0].infraestrutura_cliente)
                self.consultar_em_paralelo(infra)
            finally:
                liberar.set()
                thread.join(3)
            self.assertFalse(thread.is_alive())
            self.assertEqual([], erros)
            self.assertIs(infra, monitor.infraestrutura_cliente)

        self.durante_monitor = durante
        with patch.object(modulo, "InfraestruturaRegistrosCliente", wraps=modulo.InfraestruturaRegistrosCliente) as criar:
            self.env["iniciar"]()
        criar.assert_called_once_with()

    def test_critico_B_vazio_fechado_sem_instrumentacao(self):
        infra = self.iniciar_descoberto()
        self.assertEqual([], infra.registro_retentativas.obter_retrato()["retentativas"])
        self.assertEqual([], infra.registro_recursos.obter_retrato()["recursos"])
        infra.registro_retentativas.fechar_admissao()
        infra.registro_recursos.fechar_admissao()
        self.sem_confirmacao(infra)

    def test_critico_C_main_nao_avanca_apos_falha_parcial(self):
        with patch.object(modulo, "RegistroRecursosCliente", side_effect=OSError()):
            with self.assertRaises(OSError):
                self.env["iniciar"]()
        self.env["buscar_servidor"].assert_not_called()
        self.env["LeitorDadosServidor"].assert_not_called()
        self.env["JanelaTC420"].assert_not_called()
        self.env["JanelaConexao"].assert_not_called()

    def test_observador_automatico_recebe_mesmo_proprietario(self):
        evento = threading.Event()
        evento.set()
        self.env["buscar_servidor"].return_value = None
        contexto = servidor.ContextoCicloServidor()
        self.env["tentar_login_automatico"] = Mock(return_value=dict(
            modo="principal", servidor_encerrado=evento, web=object(), configuracao={},
            contexto_ciclo=contexto))

        def durante(monitor):
            monitor.supervisionar_principal.assert_called_once_with(contexto)
            self.assertIs(monitor.infraestrutura_cliente, monitor.saida_aplicacao._infra)

        self.durante_monitor = durante
        self.env["iniciar"]()
        self.monitores[0].supervisionar_principal.return_value.cancelar.assert_called_once_with()

    def test_propriedade_nao_pode_ser_substituida(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        with self.assertRaises((FrozenInstanceError, AttributeError)):
            infra._contexto = object()
        with self.assertRaises((FrozenInstanceError, AttributeError)):
            infra.registro_recursos = object()


if __name__ == "__main__":
    unittest.main()

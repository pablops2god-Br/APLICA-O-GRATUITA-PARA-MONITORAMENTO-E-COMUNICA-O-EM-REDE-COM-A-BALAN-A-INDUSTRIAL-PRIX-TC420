# Testes de admissao config cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-C6: CONFIG real, DNS/transporte falsos, duas admissões por geração."""
from contextlib import contextmanager
import gc
import json
import socket
import threading
import unittest
import weakref
from unittest.mock import Mock, patch

from rede.admissao_config_cliente import ConfigRecusado, RecursosTentativaConfig
from rede.infraestrutura_cliente import RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
import test_admissao_descoberta_inicial_cliente as apoio
from test_recursos_cliente_integrados import SocketLeituraFalso


# Grupo de 40 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AdmissaoConfigCliente(unittest.TestCase):
    retido = apoio.AdmissaoDescobertaInicialCliente.retido
    conservador = apoio.AdmissaoDescobertaInicialCliente.conservador
    recursos = apoio.AdmissaoDescobertaInicialCliente.recursos

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        apoio.AdmissaoDescobertaInicialCliente.setUp(self)
        self.leitor.ip_servidor = 'principal-simulado'
        self.controle = self.leitor._admissao_config

    def objeto(self):
        objeto = SocketLeituraFalso()
        objeto.arquivo.readline = Mock(return_value='{"unidade":"kg"}')
        return objeto

    def enderecos(self, quantidade=1):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (f'destino-{i}', 42100))
                for i in range(quantidade)]

    @contextmanager
    def transporte(self, objetos, quantidade=1):
        with patch('socket.getaddrinfo', return_value=self.enderecos(quantidade)) as resolver, \
                patch('socket.socket', side_effect=objetos) as alocar:
            yield resolver, alocar

    def configurar(self, leitor=None, receber=json.loads):
        leitor = leitor or self.leitor
        controle = leitor._admissao_config
        identidade = controle.admitir()
        if identidade is None:
            return None
        with controle.executar(identidade) as dono:
            return dono.ler_configuracao(
                dono.conectar_tcp(('principal-simulado', 42100), timeout=5), receber)

    def operacao(self):
        return self.controle.obter_retrato()['operacoes'][0]

    def tentativa(self, indice=0):
        return self.operacao()['tentativas'][indice]

    def test_01_CONFIG_normal(self):
        objeto = self.objeto()
        with self.transporte([objeto]) as (resolver, alocar):
            self.assertEqual({'unidade': 'kg'}, self.configurar())
        resolver.assert_called_once_with('principal-simulado', 42100, 0, socket.SOCK_STREAM)
        alocar.assert_called_once_with(socket.AF_INET, socket.SOCK_STREAM, 6)
        objeto.settimeout.assert_called_once_with(5)
        objeto.connect.assert_called_once_with(('destino-0', 42100))
        objeto.sendall.assert_called_once_with(b'CONFIG\n')
        objeto.makefile.assert_called_once_with('r', encoding='utf-8')
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])
        self.assertTrue(self.tentativa()['responsabilidade_resolvida'])
        self.assertEqual(['socket_tcp', 'arquivo_socket'], [r['tipo'] for r in self.tentativa()['recursos']])
        self.assertEqual(self.recursos()[0]['recurso_id'], self.recursos()[1]['associado_a'])

    def test_02_CONFIG_apos_parar(self):
        self.leitor.parar()
        self.assertIsNone(self.configurar())
        self.assertEqual([], self.controle.obter_retrato()['operacoes'])

    def test_03_admissao_e_parada_simultaneas(self):
        barreira = threading.Barrier(2)
        aceitas, erros = [], []
        def admitir():
            try:
                barreira.wait(3)
                aceitas.append(self.controle.admitir())
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=admitir)
        thread.start()
        try:
            barreira.wait(3)
            self.leitor.parar()
        finally:
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(1, len(aceitas))
        self.assertEqual(int(aceitas[0] is not None), len(self.controle.obter_retrato()['operacoes']))
        self.assertIsNone(self.controle.admitir())

    def test_04_operacao_recusada_sem_socket(self):
        self.leitor.parar()
        with patch('socket.socket') as alocar, patch('socket.getaddrinfo') as resolver:
            self.configurar()
        alocar.assert_not_called()
        resolver.assert_not_called()

    def test_05_operacao_recusada_sem_mensagem(self):
        objeto = self.objeto()
        self.leitor.parar()
        with self.transporte([objeto]):
            self.configurar()
        objeto.sendall.assert_not_called()
        objeto.makefile.assert_not_called()

    def test_06_enderecos_com_autorizacoes_individuais(self):
        a, b = self.objeto(), self.objeto()
        a.connect.side_effect = ConnectionRefusedError('simulado')
        with self.transporte([a, b], 2):
            self.assertEqual({'unidade': 'kg'}, self.configurar())
        tentativas = self.operacao()['tentativas']
        self.assertEqual([1, 2], [t['endereco_indice'] for t in tentativas])
        self.assertEqual(2, len({t['identidade_id'] for t in tentativas}))
        self.assertTrue(all(t['responsabilidade_resolvida'] for t in tentativas))
        self.assertEqual([False, True], [t['conectada'] for t in tentativas])

    def test_07_tentativa_apos_cancelamento_recusada(self):
        identidade = self.controle.admitir()
        with self.controle.executar(identidade):
            self.leitor.parar()
            self.assertIsNone(self.controle.admitir_tentativa(identidade))
        self.assertEqual([], self.operacao()['tentativas'])

    def test_08_primeira_tentativa_apos_parada_sem_alocacao(self):
        def resolver(*_):
            self.leitor.parar()
            return self.enderecos()
        with patch('socket.getaddrinfo', side_effect=resolver), patch('socket.socket') as alocar:
            with self.assertRaises(ConfigRecusado):
                self.configurar()
        alocar.assert_not_called()
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])

    def test_09_segunda_tentativa_apos_parada_sem_alocacao(self):
        primeiro, segundo = self.objeto(), self.objeto()
        def falhar(*_):
            self.leitor.parar()
            raise ConnectionRefusedError('simulado')
        primeiro.connect.side_effect = falhar
        with self.transporte([primeiro, segundo], 2) as (_, alocar):
            with self.assertRaises(ConfigRecusado):
                self.configurar()
        self.assertEqual(1, alocar.call_count)
        self.assertEqual(1, len(self.operacao()['tentativas']))
        segundo.sendall.assert_not_called()

    def test_10_admitida_antes_parada_continua(self):
        objeto = self.objeto()
        def alocar(*_):
            self.leitor.parar()
            self.assertFalse(self.tentativa()['responsabilidade_resolvida'])
            return objeto
        with patch('socket.getaddrinfo', return_value=self.enderecos()), \
                patch('socket.socket', side_effect=alocar):
            self.assertEqual({'unidade': 'kg'}, self.configurar())
        objeto.sendall.assert_called_once_with(b'CONFIG\n')
        self.assertTrue(self.tentativa()['responsabilidade_resolvida'])

    def test_11_falha_criacao_com_ausencia_comprovada(self):
        with self.transporte([]) as (_, alocar), \
                patch.object(self.infra.registro_recursos, 'criar', side_effect=ValueError()):
            with self.assertRaises(ValueError):
                self.configurar()
        alocar.assert_not_called()
        self.assertTrue(self.recursos()[0]['ausencia_comprovada'])
        self.assertTrue(self.tentativa()['responsabilidade_resolvida'])

    def test_12_makefile_falha_pai_acompanhado(self):
        objeto = self.objeto()
        erro = ValueError('makefile_simulado')
        objeto.makefile.side_effect = erro
        with self.transporte([objeto]):
            with self.assertRaises(ValueError) as capturado:
                self.configurar()
        self.assertIs(erro, capturado.exception)
        self.assertTrue(objeto.fechado)
        self.assertEqual(['socket_tcp', 'arquivo_socket'], [r['tipo'] for r in self.recursos()])
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])  # Fábrica opaca do arquivo.

    def test_13_comunicacao_e_fechamento_erros_separados(self):
        objeto = self.objeto()
        erro = ValueError('leitura_simulada')
        objeto.arquivo.readline.side_effect = erro
        objeto.arquivo.erro_close = OSError('close_arquivo_simulado')
        objeto.erro_close = OSError('close_socket_simulado')
        with self.transporte([objeto]):
            with self.assertRaises(ValueError) as capturado:
                self.configurar()
        self.assertIs(erro, capturado.exception)
        self.assertEqual({'categoria': 'falha_operacao'}, self.tentativa()['erro_operacao'])
        self.assertTrue(all(r['erros_limpeza'] for r in self.recursos()))
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])

    def test_14_promocao_preserva_origem(self):
        origem = self.leitor.recursos_cliente.geracao_id
        objeto = self.objeto()
        def receber():
            self.infra.registro_recursos.promover(origem)
            self.leitor.parar()
            return '{}'
        objeto.arquivo.readline.side_effect = receber
        with self.transporte([objeto]):
            self.configurar()
        self.assertEqual(origem, self.controle.obter_retrato()['geracao_id'])
        self.assertTrue(all(r['geracao_id'] == origem for r in self.recursos()))

    def test_15_nova_geracao_independente(self):
        self.leitor.parar()
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        with self.transporte([self.objeto()]):
            self.assertEqual({'unidade': 'kg'}, self.configurar(novo))
        self.assertNotEqual(self.controle._geracao_id, novo._admissao_config._geracao_id)
        self.assertIsNone(self.controle.admitir())
        self.assertFalse(novo.obter_operacoes_config()['admissao_fechada'])

    def test_16_global_nao_confirmado(self):
        with self.transporte([self.objeto()]):
            self.configurar()
        antes = self.infra.obter_operacoes_config()
        self.conservador()
        self.assertEqual(antes, self.infra.obter_operacoes_config())

    def test_corrida_A_parada_antes_operacao(self):
        self.test_04_operacao_recusada_sem_socket()

    def test_corrida_B_operacao_aceita_sem_tentativa(self):
        executar_original = self.controle.executar
        def executar(suspender):
            def atrasar(identidade):
                suspender()
                return executar_original(identidade)
            with patch.object(self.controle, 'executar', side_effect=atrasar), self.transporte([]):
                with self.assertRaises(ConfigRecusado):
                    self.configurar()
        def durante():
            self.leitor.parar()
            self.assertEqual([], self.operacao()['tentativas'])
            self.assertFalse(self.operacao()['responsabilidade_resolvida'])
            self.assertEqual([], self.recursos())
        self.retido(executar, durante)
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])

    def test_corrida_C_parada_entre_verificacao_e_primeira_tentativa(self):
        def executar(suspender):
            def resolver(*_):
                suspender()
                return self.enderecos()
            with patch('socket.getaddrinfo', side_effect=resolver), \
                    patch('socket.socket') as alocar, patch('builtins.print'):
                self.leitor._manter_atualizado()
            alocar.assert_not_called()
        self.retido(executar, self.leitor.parar)
        self.assertEqual([], self.operacao()['tentativas'])

    def test_corrida_D_entre_duas_tentativas(self):
        a, b = self.objeto(), self.objeto()
        a.connect.side_effect = ConnectionRefusedError()
        admitir = self.controle.admitir_tentativa
        def executar(suspender):
            contagem = []
            def atrasar(operacao):
                contagem.append(True)
                if len(contagem) == 2:
                    suspender()
                return admitir(operacao)
            with patch.object(self.controle, 'admitir_tentativa', side_effect=atrasar), \
                    self.transporte([a, b], 2) as (_, alocar):
                with self.assertRaises(ConfigRecusado):
                    self.configurar()
                self.assertEqual(1, alocar.call_count)
        def durante():
            self.assertTrue(self.tentativa()['responsabilidade_resolvida'])
            self.leitor.parar()
        self.retido(executar, durante)

    def test_corrida_E_promocao_com_CONFIG_antigo(self):
        antigo = self.objeto()
        def executar(suspender):
            antigo.arquivo.readline.side_effect = lambda: (suspender(), '{}')[-1]
            with self.transporte([antigo]):
                self.configurar()
        def durante():
            origem = self.controle._geracao_id
            self.infra.registro_recursos.promover(origem)
            self.leitor.parar()
            novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
            with self.transporte([self.objeto()]):
                self.configurar(novo)
            self.assertEqual(2, len(self.infra.obter_operacoes_config()))
            self.assertFalse(self.operacao()['responsabilidade_resolvida'])
            self.assertTrue(all(r['geracao_id'] == origem for r in self.recursos()[:2]))
            self.conservador()
        self.retido(executar, durante)
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])

    def test_corrida_F_tentativa_sem_socket(self):
        admitir = self.controle.admitir_tentativa
        def executar(suspender):
            def atrasar(operacao):
                identidade = admitir(operacao)
                suspender()
                return identidade
            with patch.object(self.controle, 'admitir_tentativa', side_effect=atrasar), \
                    self.transporte([self.objeto()]):
                self.configurar()
        def durante():
            antes = self.infra.obter_operacoes_config()
            self.assertEqual([], self.tentativa()['recursos'])
            self.assertFalse(self.tentativa()['responsabilidade_resolvida'])
            self.assertFalse(self.operacao()['responsabilidade_resolvida'])
            self.conservador()
            self.assertEqual(antes, self.infra.obter_operacoes_config())
            self.leitor.parar()
        self.retido(executar, durante)
        self.assertTrue(self.tentativa()['responsabilidade_resolvida'])

    def test_adicional_tres_enderecos_duas_autorizacoes(self):
        a, b, c = self.objeto(), self.objeto(), self.objeto()
        a.connect.side_effect = ConnectionRefusedError('primeiro_simulado')
        recusas = []
        def conectar(*_):
            self.leitor.parar()
            identidade = next(iter(self.controle._operacoes))
            recusas.append(self.controle.admitir_tentativa(identidade))
        b.connect.side_effect = conectar
        with self.transporte([a, b, c], 3) as (_, alocar):
            self.assertEqual({'unidade': 'kg'}, self.configurar())
        self.assertEqual([None], recusas)
        self.assertEqual(2, alocar.call_count)
        b.sendall.assert_called_once_with(b'CONFIG\n')
        c.connect.assert_not_called()
        self.assertEqual(2, len({t['identidade_id'] for t in self.operacao()['tentativas']}))
        self.assertTrue(all(t['responsabilidade_resolvida'] for t in self.operacao()['tentativas']))

    def test_fabrica_opaca_reserva_incerta(self):
        with self.transporte([ValueError('fabrica_simulada')]):
            with self.assertRaises(ValueError):
                self.configurar()
        self.assertEqual(1, len(self.tentativa()['recursos']))
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])

    def test_falha_publicacao_operacao_e_tentativa(self):
        for tipo in ('config', 'endereco_config'):
            with self.subTest(tipo=tipo):
                self.setUp()
                publicar = self.controle._publicar_saida
                def falhar(item, erro):
                    publicar(item, erro)
                    if item['identidade'].tipo == tipo:
                        raise ValueError('publicacao_simulada')
                with patch.object(self.controle, '_publicar_saida', side_effect=falhar), \
                        self.transporte([self.objeto()]):
                    with self.assertRaises(ValueError):
                        self.configurar()
                self.assertFalse(self.operacao()['responsabilidade_resolvida'])
                item = self.operacao() if tipo == 'config' else self.tentativa()
                self.assertFalse(item['retorno'])
                self.assertTrue(item['erro_publicacao'])

    def test_operacao_erro_e_publicacao_preservam_original(self):
        objeto = self.objeto()
        erro = ValueError('primario_simulado')
        objeto.arquivo.readline.side_effect = erro
        with patch.object(self.controle, '_publicar_saida', side_effect=OSError()), \
                self.transporte([objeto]):
            with self.assertRaises(ValueError) as capturado:
                self.configurar()
        self.assertIs(erro, capturado.exception)
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])

    def test_falha_publicacao_vinculo_sem_fabrica(self):
        with patch.object(RecursosTentativaConfig, '_publicar_vinculo', side_effect=ValueError()), \
                self.transporte([]) as (_, alocar):
            with self.assertRaises(ValueError):
                self.configurar()
        alocar.assert_not_called()
        self.assertTrue(self.tentativa()['erro_associacao'])
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])

    def test_makefile_publicacao_falha_retem_handle(self):
        objeto = self.objeto()
        objeto.arquivo.erro_close = OSError()
        referencia = weakref.ref(objeto.arquivo)
        criar = self.infra.registro_recursos.criar
        def falhar(token, alocar):
            if token.numero == 1:
                return criar(token, alocar)
            alocar()
            raise ValueError('publicacao_arquivo_simulada')
        with patch.object(self.infra.registro_recursos, 'criar', side_effect=falhar), \
                self.transporte([objeto]):
            with self.assertRaises(ValueError):
                self.configurar()
        del objeto
        gc.collect()
        self.assertIsNotNone(referencia())
        self.assertTrue(self.controle._publicacoes_pendentes)
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])

    def test_erro_close_sem_erro_funcional_nao_confirma(self):
        objeto = self.objeto()
        erro = OSError('close_simulado')
        objeto.arquivo.erro_close = erro
        with self.transporte([objeto]):
            with self.assertRaises(OSError) as capturado:
                self.configurar()
        self.assertIs(erro, capturado.exception)
        self.assertTrue(objeto.fechado)
        self.assertFalse(self.operacao()['responsabilidade_resolvida'])

    def test_ordem_limpeza_arquivo_antes_socket(self):
        objeto = self.objeto()
        ordem = []
        arquivo_close, socket_close = objeto.arquivo.close, objeto.close
        objeto.arquivo.close = lambda: (ordem.append('arquivo'), arquivo_close())[-1]
        objeto.close = lambda: (ordem.append('socket'), socket_close())[-1]
        with self.transporte([objeto]):
            self.configurar()
        self.assertEqual(['arquivo', 'socket'], ordem)

    def test_lock_livre_durante_DNS_rede_e_close(self):
        objeto = self.objeto()
        def verificar(*_):
            livre = self.controle._lock.acquire(blocking=False)
            self.assertTrue(livre)
            if livre:
                self.controle._lock.release()
        objeto.connect.side_effect = verificar
        objeto.sendall.side_effect = verificar
        objeto.arquivo.readline.side_effect = lambda: (verificar(), '{}')[-1]
        close = objeto.close
        objeto.close = lambda: (verificar(), close())[-1]
        with self.transporte([objeto]):
            self.configurar()

    def test_helper_CONFIG_independente_nao_herda_parada(self):
        self.leitor.parar()
        dono = RecursosLeitorCliente(self.infra)
        objeto = self.objeto()
        self.assertEqual({'unidade': 'kg'}, dono.ler_configuracao(lambda: objeto, json.loads))
        self.assertEqual([], self.controle.obter_retrato()['operacoes'])

    def test_json_invalido_preserva_excecao(self):
        objeto = self.objeto()
        objeto.arquivo.readline.return_value = '{invalido'
        with self.transporte([objeto]):
            with self.assertRaises(json.JSONDecodeError):
                self.configurar()
        self.assertTrue(self.tentativa()['responsabilidade_resolvida'])

    def test_sem_novas_threads_ou_retentativas(self):
        antes = self.infra.obter_atividades_permanentes()
        with self.transporte([self.objeto()]), \
                patch.object(type(self.infra), 'observar_termino_leitores', side_effect=AssertionError('implicito')):
            self.configurar()
            self.conservador()
        self.assertEqual(antes, self.infra.obter_atividades_permanentes())
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()['retentativas'])

    def test_retencao_apos_descartar_leitor(self):
        with self.transporte([self.objeto()]):
            self.configurar()
        retrato = self.controle.obter_retrato()
        referencia = weakref.ref(self.controle)
        del self.leitor, self.controle
        gc.collect()
        self.assertIsNotNone(referencia())
        self.assertEqual([retrato], self.infra.obter_operacoes_config())

    def test_diagnostico_sem_host_resposta_ou_texto_erro(self):
        objeto = self.objeto()
        objeto.arquivo.readline.side_effect = ValueError('texto_sensivel_simulado')
        with self.transporte([objeto]):
            with self.assertRaises(ValueError):
                self.configurar()
        retrato = json.dumps(self.infra.obter_operacoes_config())
        for texto in ('principal-simulado', 'destino-0', 'texto_sensivel_simulado', 'unidade'):
            self.assertNotIn(texto, retrato)

    def test_CONFIG_real_publica_resposta_apos_parada(self):
        objeto = self.objeto()
        objeto.arquivo.readline.side_effect = lambda: (self.leitor.parar(), '{"unidade":"kg"}')[-1]
        with self.transporte([objeto]), patch('builtins.print'):
            self.leitor._manter_atualizado()
        self.assertEqual({'unidade': 'kg'}, self.leitor.obter_configuracao())
        self.assertTrue(self.leitor.configuracao_pronta.is_set())
        self.assertTrue(self.operacao()['responsabilidade_resolvida'])
        self.assertEqual([], self.leitor.obter_operacoes_register()['operacoes'])

    def test_legado_admissao_e_limite_da_prova(self):
        leitor = LeitorDadosServidor()
        objeto = self.objeto()
        objeto.connect.side_effect = lambda *_: leitor.parar()
        with self.transporte([objeto]):
            self.assertEqual({'unidade': 'kg'}, self.configurar(leitor))
        self.assertFalse(leitor.obter_operacoes_config()['operacoes'][0]['responsabilidade_resolvida'])
        with patch('socket.socket') as alocar:
            self.assertIsNone(self.configurar(leitor))
        alocar.assert_not_called()

    def test_criacao_e_evidencia_preservam_erro_primario(self):
        erro = ValueError('criacao_simulada')
        with self.transporte([]), \
                patch.object(self.infra.registro_recursos, 'criar', side_effect=erro), \
                patch.object(self.infra.registro_recursos, 'comprovar_ausencia', side_effect=OSError()):
            with self.assertRaises(ValueError) as capturado:
                self.configurar()
        self.assertIs(erro, capturado.exception)
        self.assertFalse(self.tentativa()['responsabilidade_resolvida'])

    def test_adicional_duas_tentativas_comunicadas_terceira_recusada(self):
        # Exercita o contrato por tentativa, sem fazer o algoritmo continuar
        # automaticamente após uma conexão bem-sucedida (o que ele não faz).
        a, b, c = self.objeto(), self.objeto(), Mock()
        identidade = self.controle.admitir()
        with self.controle.executar(identidade) as dono:
            resultados = []
            for indice, objeto in enumerate((a, b)):
                with dono._escopo_endereco((f'simulado-{indice}', 42100)) as tentativa:
                    if indice == 1:
                        self.leitor.parar()  # Segunda autorização já registrada.
                    cliente = tentativa.abrir_socket(lambda: objeto)
                    cliente.settimeout(5)
                    cliente.connect((f'simulado-{indice}', 42100))
                resultados.append(dono.ler_configuracao(cliente, json.loads))
            self.assertIsNone(self.controle.admitir_tentativa(identidade))
            with self.assertRaises(ConfigRecusado):
                with dono._escopo_endereco(('simulado-2', 42100)) as tentativa:
                    tentativa.abrir_socket(c)
        c.assert_not_called()
        self.assertEqual([{'unidade': 'kg'}] * 2, resultados)
        self.assertEqual(2, len(self.operacao()['tentativas']))
        self.assertTrue(all(t['comunicacao_iniciada'] and t['responsabilidade_resolvida']
                            for t in self.operacao()['tentativas']))

"""Tela real TCP com balança sintética localhost, sem HTTPS ou credenciais."""
from pathlib import Path
import sys
import tkinter as tk
from time import monotonic, sleep
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from interface.conexao import JanelaConexao
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.servidor import RegistroTentativasAplicacao
from test_tcp_local import balanca_local


def executar():
    with patch('interface.conexao.carregar_configuracao', return_value=None), patch(
        'interface.conexao.WebTC420', side_effect=AssertionError('HTTPS proibido')
    ) as https, patch('interface.conexao.buscar_servidor', side_effect=AssertionError('UDP proibido')) as udp, patch(
        'interface.conexao.salvar_senha', side_effect=AssertionError('cofre proibido')
    ) as cofre:
        with balanca_local([b'ABC0000321abcdefgh']) as porta:
            app = JanelaConexao(infraestrutura_cliente=InfraestruturaRegistrosCliente(),
                                registro_tentativas=RegistroTentativasAplicacao())
            erros = []
            app.root.report_callback_exception = lambda *args: erros.append(args)
            try:
                for campo, valor in ((app.campo_ip, '127.0.0.1'), (app.campo_porta, str(porta)),
                                     (app.campo_usuario, ''), (app.campo_senha, '')):
                    campo.delete(0, 'end')
                    campo.insert(0, valor)
                app.metodo_conexao_var.set('TCP')
                assert app.campo_usuario.cget('state') == 'disabled'
                assert app.campo_senha.cget('state') == 'disabled'
                app.conectar()  # Sem nome, usuário ou senha.
                limite = monotonic() + 5
                while not hasattr(app, 'monitor') and monotonic() < limite:
                    app.root.update()
                    sleep(0.01)
                assert hasattr(app, 'monitor'), 'monitor TCP não abriu'
                monitor = app.monitor
                monitor.atualizar_refresh_web(reagendar=False)
                assert monitor.modo_monitor == 'tcp_local'
                assert monitor.label_peso.cget('text') == '321'
                assert monitor.label_tara.cget('text') == '—'
                assert monitor.label_faixa.cget('text') == 'TCP'
                assert monitor.candidatura_liberada is None
                assert not app.servidor_iniciado
                # O formulário ASSUMIR também deve despachar TCP sem passar pelo promotor HTTPS.
                with balanca_local([b'ABC0000456abcdefgh']) as outra_porta:
                    monitor.abrir_janela_promocao()
                    popup = monitor.janela_promocao
                    def campos(widget):
                        encontrados = []
                        for filho in widget.winfo_children():
                            if isinstance(filho, tk.Entry):
                                encontrados.append(filho)
                            encontrados.extend(campos(filho))
                        return encontrados
                    entradas = campos(popup)
                    for campo, valor in zip(entradas, ('127.0.0.1', str(outra_porta), '', '')):
                        campo.delete(0, 'end')
                        campo.insert(0, valor)
                    popup.metodo_conexao.set('TCP')
                    popup.botao_acao.invoke()
                    limite = monotonic() + 5
                    while monitor.janela_promocao is not None and monotonic() < limite:
                        app.root.update()
                        sleep(0.01)
                    assert monitor.janela_promocao is None, 'ASSUMIR TCP não concluiu'
                    monitor.atualizar_refresh_web(reagendar=False)
                    assert monitor.label_peso.cget('text') == '456'
                    assert monitor.modo_monitor == 'tcp_local'
                https.assert_not_called()
                udp.assert_not_called()
                cofre.assert_not_called()
                monitor.fechar()
                limite = monotonic() + 5
                while not app.saida_aplicacao.obter_situacao()['parada_operacional_confirmada'] and monotonic() < limite:
                    app.root.update()
                    sleep(0.01)
                assert app.saida_aplicacao.obter_situacao()['parada_operacional_confirmada']
                try:
                    app.root.update()
                except tk.TclError:
                    pass
                assert not erros, erros
                print('Tk TCP: conexão e ASSUMIR sem credenciais, localhost, sem HTTPS/UDP/servidor e B2 OK.')
            finally:
                for leitor in app.saida_aplicacao._leitores:
                    leitor.parar()
                    if leitor.thread is not None:
                        leitor.thread.join(1)
                try:
                    app.root.destroy()
                except tk.TclError:
                    pass


if __name__ == '__main__':
    executar()

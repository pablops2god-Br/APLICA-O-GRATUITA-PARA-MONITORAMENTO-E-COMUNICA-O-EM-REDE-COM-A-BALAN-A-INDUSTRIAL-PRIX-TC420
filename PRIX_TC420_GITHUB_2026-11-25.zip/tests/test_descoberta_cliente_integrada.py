# Testes de descoberta cliente integrada: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Descoberta real com transporte falso; barreiras sem rede ou equipamento."""
import socket
import threading
import unittest
from unittest.mock import Mock, patch

from rede import buscarservidor as busca
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from test_recursos_cliente_integrados import SocketLeituraFalso


class SocketDescobertaFalso(SocketLeituraFalso):
    def __init__(self):
        super().__init__()
        self.setsockopt = Mock()
        self.sendto = Mock()
        self.recvfrom = Mock(side_effect=socket.timeout())
        self.recv = Mock(return_value=b"TC420_SERVER_OK\n")


# Grupo de 25 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class DescobertaClienteIntegrada(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.dono = RecursosLeitorCliente(self.infra)
        self.registro = self.infra.registro_recursos

    def recursos(self):
        return self.registro.obter_retrato()["recursos"]

    def buscar(self, udp=None, tcp=None, dono=None):
        udp = udp or SocketDescobertaFalso()
        tcp = tcp or SocketDescobertaFalso()
        with patch.object(busca.socket, "socket", side_effect=lambda familia, tipo:
                          udp if tipo == socket.SOCK_DGRAM else tcp):
            return busca.buscar_servidor(recursos_cliente=dono or self.dono)

    def resposta(self):
        udp = SocketDescobertaFalso()
        udp.recvfrom.side_effect = [(b"TC420_SERVER_HERE", ("principal-simulado", 42101)), socket.timeout()]
        return udp

    def pendente(self):
        self.assertFalse(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_01_normal_registra_udp_tcp_sem_arquivo(self):
        self.buscar(self.resposta())
        self.assertEqual(["socket_udp", "socket_tcp"], [r["tipo"] for r in self.recursos()])
        self.assertEqual(2, len({r["recurso_id"] for r in self.recursos()}))

    def test_02_principal_e_protocolo_preservados(self):
        udp, tcp = self.resposta(), SocketDescobertaFalso()
        self.assertEqual("principal-simulado", self.buscar(udp, tcp))
        udp.setsockopt.assert_called_once_with(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        udp.sendto.assert_called_once_with(b"TC420_SERVER_DISCOVERY", ("255.255.255.255", 42101))
        tcp.connect.assert_called_once_with(("principal-simulado", 42100))
        tcp.sendall.assert_called_once_with(b"CHECK\n")
        udp.settimeout.assert_called_once_with(2)
        tcp.settimeout.assert_called_once_with(2)
        udp.makefile.assert_not_called()
        tcp.makefile.assert_not_called()

    def test_03_nao_encontrado_ignora_resposta_invalida(self):
        udp = SocketDescobertaFalso()
        udp.recvfrom.side_effect = [(b"outra", ("outro", 42101)), socket.timeout()]
        self.assertIsNone(self.buscar(udp))
        self.assertEqual(1, len(self.recursos()))

    def test_04_timeout_separa_operacao_e_limpeza(self):
        self.assertIsNone(self.buscar())
        recurso = self.recursos()[0]
        self.assertTrue(recurso["erros_atendimento"])
        self.assertFalse(recurso["erros_limpeza"])
        self.assertTrue(recurso["encerramento_confirmado"])

    def test_05_falha_comprovada_antes_alocacao(self):
        fabrica = Mock()
        with patch.object(self.registro, "criar", side_effect=ValueError()):
            with self.assertRaises(ValueError):
                self.dono.executar_descoberta("socket_udp", fabrica, Mock())
        fabrica.assert_not_called()
        self.registro.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_06_falha_apos_alocacao(self):
        udp = SocketDescobertaFalso()
        criar = self.registro.criar
        def falhar(token, fabrica):
            return criar(token, fabrica, preparar=Mock(side_effect=ValueError()))
        with patch.object(self.registro, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.buscar(udp)
        self.assertTrue(udp.fechado)
        self.assertTrue(self.recursos()[0]["erros_criacao"])

    def test_07_falha_envio_preserva_politica_original(self):
        udp = SocketDescobertaFalso()
        udp.sendto.side_effect = OSError("envio_simulado")
        with patch("builtins.print"):
            self.assertIsNone(self.buscar(udp))
        self.assertTrue(self.recursos()[0]["erros_atendimento"])
        self.assertTrue(udp.fechado)

    def test_08_falha_recepcao_preserva_excecao_original(self):
        udp = SocketDescobertaFalso()
        erro = ValueError("recepcao_simulada")
        udp.recvfrom.side_effect = erro
        with self.assertRaises(ValueError) as capturado:
            self.buscar(udp)
        self.assertIs(erro, capturado.exception)
        self.assertTrue(udp.fechado)

    def test_09_fechamento_normal_individual(self):
        self.buscar(self.resposta())
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))
        self.assertTrue(all(r["prova_fechamento"] for r in self.recursos()))

    def test_10_fechamento_falho_nao_confirma(self):
        udp = SocketDescobertaFalso()
        udp.erro_close = OSError()
        with self.assertRaises(OSError):
            self.buscar(udp)
        self.registro.fechar_admissao()
        self.pendente()
        self.assertTrue(self.recursos()[0]["erros_limpeza"])

    def test_11_publicacao_incerta_retida(self):
        udp = SocketDescobertaFalso()
        def falhar(token, alocar):
            alocar()
            raise ValueError()
        with patch.object(self.registro, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.buscar(udp)
        self.assertTrue(self.dono.obter_publicacoes_pendentes())
        self.assertTrue(udp.fechado)
        self.registro.fechar_admissao()
        self.pendente()

    def paralelo(self, operacoes):
        erros = []
        barreira = threading.Barrier(len(operacoes))
        def executar(op):
            try:
                barreira.wait(3)
                op()
            except BaseException as erro:
                erros.append(erro)
        threads = [threading.Thread(target=executar, args=(op,)) for op in operacoes]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(3)
            self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_12_duas_buscas_simultaneas(self):
        with patch.object(busca.socket, "socket", side_effect=lambda *_: SocketDescobertaFalso()):
            self.paralelo([lambda: busca.buscar_servidor(recursos_cliente=self.dono)] * 2)
        self.assertEqual(2, len({r["recurso_id"] for r in self.recursos()}))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_13_descoberta_register_simultaneos(self):
        tcp = SocketLeituraFalso()
        tcp.arquivo.readline = Mock(return_value='{"nome":"cliente-simulado","posicao":1}')
        with patch.object(busca.socket, "socket", side_effect=lambda *_: SocketDescobertaFalso()):
            self.paralelo([lambda: busca.buscar_servidor(recursos_cliente=self.dono),
                           lambda: self.dono.registrar_cliente(lambda: tcp, "cliente-simulado", lambda linha: None)])
        self.assertEqual(3, len({r["recurso_id"] for r in self.recursos()}))
        self.assertEqual({"socket_tcp", "socket_udp", "arquivo_socket"}, {r["tipo"] for r in self.recursos()})
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_14_geracao_antiga_preservada(self):
        nova = RecursosLeitorCliente(self.infra)
        self.buscar(dono=nova)
        self.buscar()
        self.assertEqual([nova.geracao_id, self.dono.geracao_id], [r["geracao_id"] for r in self.recursos()])

    def test_15_promocao_preserva_historico(self):
        self.buscar()
        antes = self.recursos()
        self.registro.promover(self.dono.geracao_id)
        self.buscar(dono=RecursosLeitorCliente(self.infra))
        self.assertEqual(antes[0]["recurso_id"], self.recursos()[0]["recurso_id"])
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])

    def test_16_cobertura_global_incompleta(self):
        self.buscar()
        self.registro.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])
        resultado = self.infra.avaliar()
        self.assertFalse(resultado["cobertura_completa"])
        self.assertFalse(resultado["encerramento_confirmado"])

    def retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []
        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise AssertionError("barreira_nao_liberada")
        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_critico_A_reserva_antes_gate_alocacao_depois(self):
        udp = SocketDescobertaFalso()
        def executar(suspender):
            with patch.object(busca.socket, "socket", side_effect=lambda *_: (suspender(), udp)[-1]):
                with self.assertRaises(RuntimeError):
                    busca.buscar_servidor(recursos_cliente=self.dono)
        self.retido(executar, lambda: (self.registro.fechar_admissao(), self.pendente()))
        self.assertTrue(udp.fechado)
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])
        self.assertEqual(self.dono.geracao_id, self.recursos()[0]["geracao_id"])

    def test_critico_B_promocao_durante_busca_antiga(self):
        udp = self.resposta()
        def executar(suspender):
            resposta = udp.recvfrom.side_effect
            def receber(_):
                suspender()
                return next(resposta)
            udp.recvfrom.side_effect = receber
            self.assertEqual("principal-simulado", self.buscar(udp))
        def promover():
            self.registro.promover(self.dono.geracao_id)
            nova = RecursosLeitorCliente(self.infra)
            self.assertNotEqual(nova.geracao_id, self.recursos()[0]["geracao_id"])
            self.pendente()
        self.retido(executar, promover)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))
        self.assertTrue(all(r["geracao_id"] == self.dono.geracao_id for r in self.recursos()))

    def test_critico_C_dois_sockets_ativos_sem_sobrescrita(self):
        barreira = threading.Barrier(2)
        def fabricar(*_):
            udp = SocketDescobertaFalso()
            def receber(tamanho):
                barreira.wait(3)
                self.assertEqual(2, len({r["recurso_id"] for r in self.recursos()}))
                raise socket.timeout()
            udp.recvfrom.side_effect = receber
            return udp
        with patch.object(busca.socket, "socket", side_effect=fabricar):
            self.paralelo([lambda: busca.buscar_servidor(recursos_cliente=self.dono)] * 2)
        self.assertEqual(2, len(self.recursos()))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_critico_D_timeout_close_publicado_tardiamente(self):
        udp = SocketDescobertaFalso()
        close = udp.close
        def executar(suspender):
            udp.close = lambda: (suspender(), close())[-1]
            self.assertIsNone(self.buscar(udp))
        def durante():
            self.registro.fechar_admissao()
            self.pendente()
            self.assertTrue(self.recursos()[0]["limpeza_em_curso"])
            self.assertFalse(self.recursos()[0]["prova_fechamento"])
            self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])
        self.retido(executar, durante)
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_paridade_legado_respostas_e_timeout(self):
        for resposta in (b"TC420_SERVER_OK\n", b"invalida"):
            resultados = []
            for observado in (False, True):
                udp, tcp = self.resposta(), SocketDescobertaFalso()
                tcp.recv.return_value = resposta
                with patch.object(busca.socket, "socket", side_effect=[udp, tcp]):
                    resultados.append(busca.buscar_servidor(**({"recursos_cliente": self.dono} if observado else {})))
                self.assertTrue(udp.fechado)
                self.assertTrue(tcp.fechado)
            self.assertEqual(resultados[0], resultados[1])

    def test_configuracao_socket_falha_limpa_recurso_alocado(self):
        udp = SocketDescobertaFalso()
        udp.setsockopt.side_effect = ValueError()
        with self.assertRaises(ValueError):
            self.buscar(udp)
        self.assertTrue(udp.fechado)
        self.assertTrue(self.recursos()[0]["erros_atendimento"])

    def test_preparacao_usa_registro_estavel(self):
        with patch.object(busca.socket, "socket", side_effect=lambda *_: SocketDescobertaFalso()):
            busca.buscar_servidor(infraestrutura_cliente=self.infra)
            busca.buscar_servidor(infraestrutura_cliente=self.infra)
        self.assertEqual(2, len(self.recursos()))
        self.assertEqual(2, len({r["geracao_id"] for r in self.recursos()}))

    def test_corpo_e_close_falham_preservam_original(self):
        udp = SocketDescobertaFalso()
        erro = ValueError()
        udp.recvfrom.side_effect = erro
        udp.erro_close = OSError()
        with self.assertRaises(ValueError) as capturado:
            self.buscar(udp)
        self.assertIs(erro, capturado.exception)
        self.assertTrue(self.recursos()[0]["erros_limpeza"])

    def test_preparacao_retem_handle_com_publicacao_e_close_falhos(self):
        import gc
        import weakref
        udp = SocketDescobertaFalso()
        udp.erro_close = OSError()
        referencia = weakref.ref(udp)
        def falhar(token, alocar):
            alocar()
            raise ValueError()
        with patch.object(self.registro, "criar", side_effect=falhar), \
                patch.object(busca.socket, "socket", return_value=udp):
            with self.assertRaises(ValueError):
                busca.buscar_servidor(infraestrutura_cliente=self.infra)
        del udp
        gc.collect()
        self.assertIsNotNone(referencia())
        self.registro.fechar_admissao()
        self.pendente()


if __name__ == "__main__":
    unittest.main()

"""Retenção limitada e sanitização com dados sintéticos; sem arquivos automáticos."""
from concurrent.futures import ThreadPoolExecutor
from io import StringIO
from threading import Barrier
import unittest
from unittest.mock import Mock, patch

import interface.registro_terminal as modulo


class RetencaoTerminal(unittest.TestCase):
    def test_saida_sem_console_registra_e_sanitiza(self):
        registro = self.registro(caracteres=200)
        saida = modulo._SaidaEspelhada(None, registro)
        texto = 'senha: dado-sintetico\n'
        self.assertEqual(saida.write(texto), len(texto))
        saida.flush()
        self.assertFalse(saida.isatty())
        self.assertNotIn('dado-sintetico', registro.obter_texto())
        self.assertIn('[OCULTO]', registro.obter_texto())

    def test_saida_sem_console_preserva_limite_sem_buffer_extra(self):
        registro = self.registro(caracteres=5)
        saida = modulo._SaidaEspelhada(None, registro)
        saida.write('abcdefghi')
        self.assertEqual(registro.obter_texto(), 'efghi')
        self.assertFalse(hasattr(saida.original, 'getvalue'))

    def registro(self, linhas=3, caracteres=100):
        return modulo._RegistroTerminal(limite_linhas=linhas, limite_caracteres=caracteres)

    def test_api_anterior_preserva_texto_enquanto_nao_houver_corte(self):
        registro = self.registro()
        for parte in ('primeira', ' linha\n', '\n', 'parcial'):
            registro.acrescentar(parte)
        self.assertEqual('primeira linha\n\nparcial', registro.obter_texto())
        self.assertFalse(registro.obter_situacao()['parcial'])

    def test_limite_de_linhas_descarta_as_mais_antigas(self):
        registro = self.registro(linhas=2)
        registro.acrescentar('a\nb\nc\n')
        self.assertEqual('b\nc\n', registro.obter_texto())
        situacao = registro.obter_situacao()
        self.assertEqual(2, situacao['linhas_retidas'])
        self.assertEqual(1, situacao['linhas_descartadas'])
        self.assertEqual(2, situacao['caracteres_descartados'])

    def test_limite_de_caracteres_descarta_prefixo_inclusive_parcial(self):
        registro = self.registro(caracteres=5)
        registro.acrescentar('abcdefghi')
        self.assertEqual('efghi', registro.obter_texto())
        self.assertEqual(4, registro.obter_situacao()['caracteres_descartados'])
        self.assertEqual(0, registro.obter_situacao()['linhas_descartadas'])

    def test_ambos_os_limites_sao_respeitados_a_cada_write(self):
        registro = self.registro(linhas=2, caracteres=7)
        for parte in ('123456\n', 'a\nb\n', '123456789', '\nx\ny\nz\n'):
            registro.acrescentar(parte)
            situacao = registro.obter_situacao()
            self.assertLessEqual(situacao['linhas_retidas'], 2)
            self.assertLessEqual(situacao['caracteres_retidos'], 7)

    def test_linha_parcial_conta_no_limite_sem_criar_linha_fantasma_no_lf(self):
        registro = self.registro(linhas=2)
        registro.acrescentar('a\nb\n')
        self.assertEqual(2, registro.obter_situacao()['linhas_retidas'])
        registro.acrescentar('c')
        self.assertEqual('b\nc', registro.obter_texto())
        registro.acrescentar('\n')
        self.assertEqual(2, registro.obter_situacao()['linhas_retidas'])

    def test_escrita_muito_maior_que_o_limite_fica_limitada(self):
        registro = self.registro(caracteres=31)
        registro.acrescentar('x' * 100_000)
        self.assertEqual('x' * 31, registro.obter_texto())
        self.assertEqual(99_969, registro.obter_situacao()['caracteres_descartados'])

    def test_limite_padrao_de_um_milhao_em_linha_sem_quebra(self):
        registro = modulo._RegistroTerminal()
        registro.acrescentar('x' * 1_100_000)
        situacao = registro.obter_situacao()
        self.assertEqual(1_000_000, situacao['caracteres_retidos'])
        self.assertEqual(100_000, situacao['caracteres_descartados'])
        self.assertEqual(1, situacao['linhas_retidas'])
        self.assertLessEqual(situacao['blocos_retidos'], 246)

    def test_writes_de_um_caractere_nao_retem_um_objeto_por_write(self):
        registro = self.registro(linhas=100, caracteres=10_000)
        for _ in range(30_000):
            registro.acrescentar('x')
        self.assertEqual(10_000, registro.obter_situacao()['caracteres_retidos'])
        self.assertLessEqual(registro.obter_situacao()['blocos_retidos'], 4)
        self.assertTrue(all(len(b) <= modulo.TAMANHO_BLOCO for b in registro._blocos))

    def test_contadores_nao_guardam_conteudo_descartado(self):
        registro = self.registro(linhas=1)
        registro.acrescentar('primeira-sintetica\nsegunda-sintetica\nultima\n')
        self.assertEqual('ultima\n', registro.obter_texto())
        self.assertEqual(2, registro.obter_situacao()['linhas_descartadas'])
        self.assertNotIn('primeira-sintetica', repr(registro._blocos))
        self.assertNotIn('primeira-sintetica', registro._sanitizador._cauda)
        self.assertTrue(all(type(v) in (int, bool) for v in registro.obter_situacao().values()))

    def test_exportacao_parcial_informa_cortes_sem_recuperar_conteudo(self):
        registro = self.registro(linhas=1)
        registro.acrescentar('antiga\nnova\n')
        exportacao = registro.obter_exportacao()
        self.assertTrue(exportacao['parcial'])
        self.assertIn('HISTÓRICO PARCIAL', exportacao['texto'])
        self.assertIn('1 linhas encerradas por LF e 7 caracteres', exportacao['texto'])
        self.assertTrue(exportacao['texto'].endswith('nova\n'))
        self.assertNotIn('antiga\n', exportacao['texto'])

    def test_exportacao_sem_corte_nao_inventa_aviso(self):
        registro = self.registro()
        registro.acrescentar('mensagem\n')
        self.assertEqual('mensagem\n', registro.obter_exportacao()['texto'])

    def test_exportacao_e_imutavel_apos_novas_escritas(self):
        registro = self.registro(linhas=1)
        registro.acrescentar('antes\n')
        exportacao = registro.obter_exportacao()
        registro.acrescentar('depois\n')
        self.assertEqual('antes\n', exportacao['texto'])
        self.assertFalse(exportacao['parcial'])

    def test_unicode_e_crlf_preservados_com_contagem_por_caractere(self):
        registro = self.registro(caracteres=8)
        registro.acrescentar('á😀\r\nç😀\r\n')
        self.assertEqual('á😀\r\nç😀\r\n', registro.obter_texto())
        self.assertEqual(8, registro.obter_situacao()['caracteres_retidos'])
        self.assertEqual(2, registro.obter_situacao()['linhas_retidas'])

    def test_tokens_senhas_e_authorization_rotulados_sao_ocultos(self):
        registro = self.registro(linhas=10, caracteres=1000)
        registro.acrescentar('pwd=segredo-sintetico&cmd=login\nAuthorization: Bearer sessao-sintetica\n')
        texto = registro.obter_texto()
        self.assertNotIn('segredo-sintetico', texto)
        self.assertNotIn('sessao-sintetica', texto)
        self.assertIn('pwd=[OCULTO]\n', texto)

    def test_segredo_com_separadores_e_espacos_e_ocultado_ate_lf(self):
        registro = self.registro()
        registro.acrescentar('senha=parte-sintetica & outra-parte\rresto\nOK')
        self.assertEqual('senha=[OCULTO]\nOK', registro.obter_texto())

    def test_valor_e_rotulo_fragmentados_nao_expoem_segredo(self):
        registro = self.registro(linhas=10, caracteres=1000)
        for parte in ('to', 'ken', '=', 'sessao-', 'sintetica', '\nOK\n'):
            registro.acrescentar(parte)
        self.assertEqual('token=[OCULTO]\nOK\n', registro.obter_texto())
        self.assertNotIn('sessao-', registro._sanitizador._cauda)

    def test_valor_oculto_maior_que_um_bloco_nao_e_retido(self):
        registro = self.registro()
        registro.acrescentar('senha=' + 'z' * 20_000 + '\nOK')
        self.assertEqual('senha=[OCULTO]\nOK', registro.obter_texto())

    def test_escrita_e_exportacao_concorrentes_com_retrato_coerente(self):
        registro = self.registro(linhas=100, caracteres=3000)
        barreira = Barrier(5, timeout=5)
        def escrever(numero):
            barreira.wait()
            for indice in range(500):
                registro.acrescentar(f'{numero}:{indice:04d}\n')
        def ler():
            barreira.wait()
            for _ in range(500):
                retrato = registro.obter_exportacao()
                texto = retrato['texto'].split('\n\n', 1)[1] if retrato['parcial'] else retrato['texto']
                self.assertEqual(len(texto), retrato['caracteres_retidos'])
                self.assertLessEqual(retrato['linhas_retidas'], 100)
                self.assertLessEqual(retrato['caracteres_retidos'], 3000)
        with ThreadPoolExecutor(max_workers=5) as pool:
            futuros = [pool.submit(escrever, i) for i in range(4)] + [pool.submit(ler)]
            for futuro in futuros:
                futuro.result(timeout=10)
        situacao = registro.obter_situacao()
        self.assertEqual(2000, situacao['linhas_retidas'] + situacao['linhas_descartadas'])
        self.assertEqual(14_000, situacao['caracteres_retidos'] + situacao['caracteres_descartados'])

    def test_registro_nao_abre_arquivo_automaticamente(self):
        with patch('builtins.open', side_effect=AssertionError('gravação não autorizada')):
            registro = self.registro()
            registro.acrescentar('mensagem\n')
            registro.obter_exportacao()

    def test_saida_original_recebe_texto_e_resultado_inalterados(self):
        original = StringIO()
        registro = self.registro()
        espelho = modulo._SaidaEspelhada(original, registro)
        self.assertEqual(len('token=entrada-sintetica\n'), espelho.write('token=entrada-sintetica\n'))
        self.assertEqual('token=entrada-sintetica\n', original.getvalue())
        self.assertEqual('token=[OCULTO]\n', registro.obter_texto())
        espelho.flush()

    def test_instalacao_concorrente_e_idempotente(self):
        registro = self.registro()
        original = StringIO()
        with patch.object(modulo, '_registro', registro), patch.object(modulo, '_instalado', False), \
                patch('sys.stdout', original), patch('sys.stderr', original):
            with ThreadPoolExecutor(max_workers=4) as pool:
                resultados = list(pool.map(lambda _: modulo.instalar_registro_terminal(), range(20)))
            self.assertTrue(all(r is registro for r in resultados))
            self.assertIs(original, modulo.sys.stdout.original)
            self.assertIs(original, modulo.sys.stderr.original)
            self.assertIsInstance(modulo.sys.stdout, modulo._SaidaEspelhada)

    def test_limites_invalidos_sao_recusados(self):
        for valor in (0, -1, True, 1.5, None):
            with self.subTest(valor=valor), self.assertRaises(ValueError):
                modulo._RegistroTerminal(limite_linhas=valor)
            with self.subTest(valor=valor), self.assertRaises(ValueError):
                modulo._RegistroTerminal(limite_caracteres=valor)

    def test_write_vazio_e_historico_vazio(self):
        registro = self.registro()
        registro.acrescentar('')
        self.assertEqual('', registro.obter_texto())
        self.assertEqual(0, registro.obter_situacao()['linhas_retidas'])


if __name__ == '__main__':
    unittest.main()

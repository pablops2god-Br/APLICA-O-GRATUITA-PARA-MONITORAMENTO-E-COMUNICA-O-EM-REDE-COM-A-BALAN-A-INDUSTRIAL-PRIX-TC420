# Testes de auditoria consolidada ac1: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC1: fontes reais e evidências conjuntas; sem integrar guarda/coordenador.

Testes de lacuna aprovam ao reproduzir a limitação, sem corrigi-la. Transporte,
dados persistidos, Tk e partidas operacionais são substituídos por fakes.
"""
import ast
from contextlib import contextmanager
import gc
import json
from pathlib import Path
import socket
import threading
import tkinter as tk
from types import SimpleNamespace
import unittest
import weakref
from unittest.mock import Mock, patch

from config import configuracao
from config.arquivos import ContextoArquivosConfiguracao
from rede import buscarservidor, infraestrutura_cliente
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
from tc420.web import WebTC420
from test_delimitacao_arquivos_locais import ArquivoMemoria
from test_recursos_cliente_integrados import SocketLeituraFalso
from test_descoberta_cliente_integrada import SocketDescobertaFalso
import test_infraestrutura_cliente as montagem
import test_login_manual_http as manual
import test_approval_http_integrado as approval
import test_auditoria_cobertura_cliente as inventario_anterior


RAIZ = Path(__file__).resolve().parents[1]


# Grupo de 28 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AuditoriaConsolidadaAC1(unittest.TestCase):
    fluxo_http = approval.ApprovalHttpIntegrado.fluxo_http

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.dono = RecursosLeitorCliente(self.infra)
        self.contexto = ContextoArquivosConfiguracao(self.infra)
        self.registro = self.infra.registro_recursos
        self.arquivos = []
        self.addCleanup(self.limpar)

    def limpar(self):
        for arquivo in self.arquivos:
            arquivo.limpeza, arquivo.antes_close = None, None
            if not arquivo.closed:
                arquivo.close()

    def arquivo(self, *args, **kwargs):
        arquivo = ArquivoMemoria(*args, **kwargs)
        self.arquivos.append(arquivo)
        return arquivo

    def recursos(self):
        return self.registro.obter_retrato()["recursos"]

    def operacoes(self):
        return self.infra.registro_http.obter_retrato()["operacoes"]

    def negativo(self):
        resultado = self.infra.avaliar()
        self.assertFalse(resultado["cobertura_completa"])
        self.assertFalse(resultado["encerramento_confirmado"])
        self.assertEqual("incompleta", resultado["cobertura_operacional"])
        self.assertFalse(self.infra.registro_http.obter_retrato()["encerramento_global_confirmado"])
        return resultado

    @contextmanager
    def persistencia(self, arquivo):
        with patch.object(configuracao, "existe_configuracao", return_value=True), \
                patch.object(configuracao, "obter_caminho_configuracao", return_value="virtual-ac1.json"), \
                patch("builtins.open", return_value=arquivo) as abrir:
            yield abrir

    def ler(self):
        return configuracao.carregar_configuracao(contexto_arquivos=self.contexto)

    def escrever(self):
        return configuracao.salvar_configuracao("simulado", "simulado", 9800, "", False,
                                               contexto_arquivos=self.contexto)

    def par(self, dono=None):
        bruto = SocketLeituraFalso()
        cliente = (dono or self.dono).abrir_socket(lambda: bruto)
        arquivo = cliente.makefile("r", encoding="utf-8")
        return cliente, arquivo, bruto

    def thread(self, rotina):
        erros = []
        def executar():
            try:
                rotina()
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=executar, daemon=True)
        thread.start()
        return thread, erros

    def terminar(self, tarefa):
        tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())
        self.assertEqual([], tarefa[1])

    def esperar(self, entrou, liberar):
        entrou.set()
        if not liberar.wait(3):
            raise TimeoutError("barreira_simulada")

    def test_01_main_leitor_real_config_register_subscribe(self):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        leitores = []
        def criar(**kwargs):
            leitor = LeitorDadosServidor(**kwargs)
            leitores.append(leitor)
            return leitor
        fx.env["LeitorDadosServidor"] = criar
        config, registro, subscribe = [SocketLeituraFalso() for _ in range(3)]
        config.arquivo.readline = Mock(return_value='{"config":1}')
        registro.arquivo.readline = Mock(return_value=json.dumps(dict(nome=socket.gethostname(), posicao=1)))
        def receber():
            leitores[0].executando = False
            return ""
        subscribe.arquivo.readline = Mock(side_effect=receber)
        fx.durante_monitor = lambda monitor: leitores[0].thread.target()
        enderecos = [(socket.AF_INET, socket.SOCK_STREAM, 0, "", ("simulado", 42100))]
        # A descoberta inicial é falsa; o loop CONFIG/REGISTER/SUBSCRIBE é real.
        with patch.object(infraestrutura_cliente, "InfraestruturaRegistrosCliente", return_value=self.infra), \
                patch("rede.lerdadosserver.threading.Thread", montagem.ThreadControlada), \
                patch.object(LeitorDadosServidor, "aguardar_configuracao", return_value=None), \
                patch("rede.lerdadosserver.socket.getaddrinfo", return_value=enderecos), \
                patch("rede.lerdadosserver.socket.socket", side_effect=[config, registro, subscribe]), \
                patch("builtins.print"):
            fx.iniciar_descoberto()
        self.assertEqual(["socket_tcp", "arquivo_socket"] * 3, [r["tipo"] for r in self.recursos()])
        self.assertEqual(6, len({r["recurso_id"] for r in self.recursos()}))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))
        for i in (0, 2, 4):
            self.assertEqual(self.recursos()[i]["recurso_id"], self.recursos()[i + 1]["associado_a"])
        subscribe.sendall.assert_called_once_with(b"SUBSCRIBE\n")
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()["retentativas"])
        self.negativo()

    def tentativas_internas(self, comando):
        falho, sucesso = SocketLeituraFalso(), SocketLeituraFalso()
        falho.connect.side_effect = ConnectionRefusedError("recusa_simulada")
        sucesso.arquivo.readline = Mock(return_value='{"valor":1}')
        destinos = [(socket.AF_INET, socket.SOCK_STREAM, 0, "", (f"simulado-{i}", 42100)) for i in range(2)]
        with patch("rede.infraestrutura_cliente.socket.getaddrinfo", return_value=destinos), \
                patch("rede.infraestrutura_cliente.socket.socket", side_effect=[falho, sucesso]):
            cliente = self.dono.conectar_tcp(("simulado", 42100))
            identidade = cliente.recurso_id.numero
            if comando == "CONFIG":
                resultado = self.dono.ler_configuracao(cliente, json.loads)
            else:
                resultado = self.dono.registrar_cliente(cliente, "simulado", json.loads)
        self.assertEqual({"valor": 1}, resultado)
        recursos = self.recursos()
        self.assertEqual(["socket_tcp", "socket_tcp", "arquivo_socket"], [r["tipo"] for r in recursos])
        self.assertTrue(all(r["encerramento_confirmado"] for r in recursos))
        self.assertTrue(recursos[0]["erros_atendimento"])
        self.assertEqual(identidade, recursos[2]["associado_a"])
        self.assertEqual(3, len({r["recurso_id"] for r in recursos}))
        self.negativo()

    def test_02_config_com_tentativa_interna(self):
        self.tentativas_internas("CONFIG")

    def test_03_register_com_tentativa_interna(self):
        self.tentativas_internas("REGISTER")

    def test_04_descoberta_preparacao_main_udp_tcp_independentes(self):
        udp, tcp = SocketDescobertaFalso(), SocketDescobertaFalso()
        udp.recvfrom.side_effect = [(b"TC420_SERVER_HERE", ("simulado", 42101))]
        def alocar(familia, tipo):
            retrato = self.recursos()[-1]
            self.assertTrue(retrato["criacao_em_curso"])
            return udp if tipo == socket.SOCK_DGRAM else tcp
        with patch.object(buscarservidor.socket, "socket", side_effect=alocar):
            self.assertEqual("simulado", buscarservidor.buscar_servidor(infraestrutura_cliente=self.infra))
        self.assertEqual(["socket_udp", "socket_tcp"], [r["tipo"] for r in self.recursos()])
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))
        self.assertEqual(1, len(self.infra._donos_descobertas))
        self.negativo()

    def caminho_http_e_dados(self, caminho, preservar_antigo=False):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        fx.env["carregar_configuracao"] = configuracao.carregar_configuracao
        fx.env["WebTC420"].side_effect = lambda ip, **kw: WebTC420(ip, **kw)
        if caminho == "promocao":
            fx.preparar_promocao()
            if preservar_antigo:
                promover = fx.durante_monitor
                def com_recurso_antigo(monitor):
                    antigos.extend(self.par(fx.leitores[0].recursos_cliente))
                    promover(monitor)
                antigos = []
                fx.durante_monitor = com_recurso_antigo
        else:
            fx.env["buscar_servidor"].return_value = None
        janelas = []
        if caminho == "manual":
            ui = manual.LoginManualHttp()
            ui.setUp()
            ui.env["carregar_configuracao"] = configuracao.carregar_configuracao
            ui.env["salvar_configuracao"] = configuracao.salvar_configuracao
            ui.env["WebTC420"].side_effect = lambda ip, **kw: WebTC420(ip, **kw)
            def construir(**kwargs):
                janela = ui.criar_janela(kwargs.pop("infraestrutura_cliente"), **kwargs)
                janela.root.mainloop = janela.conectar
                janelas.append(janela)
                return janela
            fx.env["JanelaConexao"] = construir
        dados = dict(salvar_login=caminho != "manual", ip="simulado", usuario="simulado")
        def abrir(*args, **kwargs):
            return self.arquivo(json.dumps(dados) if args[1] == "r" else "")
        with patch.object(infraestrutura_cliente, "InfraestruturaRegistrosCliente", return_value=self.infra), \
                patch.object(configuracao, "existe_configuracao", return_value=True), \
                patch.object(configuracao, "obter_caminho_configuracao", return_value="virtual-ac1.json"), \
                patch("builtins.open", side_effect=abrir), self.fluxo_http() as transporte:
            original_send = transporte.send
            def enviar(pedido, **kwargs):
                op = self.operacoes()[-1]
                self.assertTrue(op["inicio_confirmado"])
                self.assertEqual(1, op["execucoes_ativas"])
                self.assertFalse(op["execucao_resolvida"])
                return original_send(pedido, **kwargs)
            with patch.object(transporte, "send", side_effect=enviar):
                fx.env["iniciar"]()
        self.assertEqual(["POST", "GET"], [p.method for p, _ in transporte.enviados])
        self.assertEqual(["login", "approval"], [o["operacao"] for o in self.operacoes()])
        self.assertTrue(all(o["execucao_resolvida"] and o["resultado"] == "retorno" for o in self.operacoes()))
        definir = ui.env["definir_configuracao"] if caminho == "manual" else fx.env["definir_configuracao"]
        self.assertEqual(approval.CONFIGURACAO, definir.call_args.args[0])
        recursos_locais = self.recursos()[2:] if preservar_antigo else self.recursos()
        self.assertTrue(all(r["encerramento_confirmado"] for r in recursos_locais))
        self.assertEqual(3 if caminho == "manual" else 1, len(recursos_locais))
        if caminho == "promocao":
            origem = fx.leitores[0].recursos_cliente.geracao_id
            self.assertTrue(all(o["geracao_id"] == origem for o in self.operacoes()))
            self.assertNotEqual(origem, recursos_locais[0]["geracao_id"])
        if janelas:
            self.assertIs(self.infra, janelas[0]._contexto_arquivos._proprietario)
        self.negativo()
        if preservar_antigo:
            self.assertEqual(2, len(self.recursos()[:2]))
            self.assertTrue(all(r["geracao_id"] == origem and not r["encerramento_confirmado"]
                                for r in self.recursos()[:2]))
            # Lacuna de metadados: promoção real não chama registro.promover.
            self.assertTrue(all(r["modo_atual"] == "cliente" for r in self.recursos()[:2]))
            fx.leitores[0].parar.assert_called()
            antigos[1].close()
            antigos[0].close()

    def test_05_login_automatico_post_get_e_arquivo(self):
        self.caminho_http_e_dados("automatico")

    def test_06_login_manual_post_get_e_arquivos(self):
        self.caminho_http_e_dados("manual")

    def test_07_promocao_http_preserva_origem_e_arquivo_aplicacao(self):
        self.caminho_http_e_dados("promocao")

    def test_08_leitura_configuracao_reserva_e_closed(self):
        arquivo = self.arquivo('{"valor":1}')
        with self.persistencia(arquivo):
            self.assertEqual({"valor": 1}, self.ler())
        self.assertTrue(arquivo.closed)
        self.assertEqual("close_retornou_e_closed_true", self.recursos()[0]["prova_fechamento"])
        self.negativo()

    def test_09_escrita_configuracao_independente_de_http(self):
        with self.persistencia(self.arquivo("")):
            self.escrever()
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])
        self.assertEqual([], self.operacoes())
        self.negativo()

    def test_10_falha_close_nao_confirma(self):
        with self.persistencia(self.arquivo(limpeza=RuntimeError("limpeza_simulada"))):
            with self.assertRaises(RuntimeError):
                self.ler()
        self.assertTrue(self.recursos()[0]["erros_limpeza"])
        self.assertFalse(self.recursos()[0]["encerramento_confirmado"])
        self.negativo()

    def test_11_operacao_e_limpeza_erros_independentes(self):
        primario, limpeza = OSError("escrita_simulada"), RuntimeError("limpeza_simulada")
        with self.persistencia(self.arquivo(escrita=primario, limpeza=limpeza)):
            with self.assertRaises(OSError) as erro:
                self.escrever()
        self.assertIs(primario, erro.exception)
        self.assertIs(limpeza, primario.__cause__)
        recurso, = self.recursos()
        self.assertTrue(recurso["erros_atendimento"] and recurso["erros_limpeza"])
        self.negativo()

    def test_12_critica_a_promocao_preserva_socket_e_arquivo_antigos(self):
        cliente, arquivo, _ = self.par()
        anterior = self.recursos()
        # Transição explícita no harness: a aplicação ainda não publica estes modos.
        self.registro.promover(self.dono.geracao_id)
        novo = RecursosLeitorCliente(self.infra)
        recente, recente_arquivo, _ = self.par(novo)
        recente_arquivo.close()
        recente.close()
        self.assertEqual([r["recurso_id"] for r in anterior], [r["recurso_id"] for r in self.recursos()[:2]])
        self.assertTrue(all(r["geracao_id"] == self.dono.geracao_id and r["modo_atual"] == "principal"
                            and not r["encerramento_confirmado"] for r in self.recursos()[:2]))
        self.negativo()
        arquivo.close()
        cliente.close()

    def test_13_http_concluido_recurso_pendente(self):
        cliente, arquivo, _ = self.par()
        web = WebTC420("simulado", politica_http=self.infra.criar_politica_http())
        origem = self.infra.preparar_http_inicial()
        with self.fluxo_http():
            self.infra.executar_login_automatico(web, "simulado", "simulado", contexto_http=origem)
            self.infra.executar_approval(origem, web)
        self.assertTrue(all(o["execucao_resolvida"] for o in self.operacoes()))
        self.assertFalse(self.recursos()[0]["encerramento_confirmado"])
        self.negativo()
        arquivo.close()
        cliente.close()

    def test_14_thread_encerrada_recurso_pendente(self):
        criados = []
        tarefa = self.thread(lambda: criados.extend(self.par()))
        self.terminar(tarefa)
        self.assertFalse(tarefa[0].is_alive())
        self.assertTrue(all(not r["encerramento_confirmado"] for r in self.recursos()))
        self.negativo()
        criados[1].close()
        criados[0].close()

    def test_15_critica_d_recursos_fechados_atividade_sem_termino(self):
        cliente, arquivo, _ = self.par()
        arquivo.close()
        cliente.close()
        guarda = self.infra.registro_retentativas
        # Reserva apenas experimental, sem conectar a guarda ao leitor operacional.
        geracao = guarda.nova_geracao_cliente()
        pendente = guarda.reservar_retentativa(geracao)
        self.registro.fechar_admissao()
        guarda.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])
        self.assertEqual("parada_solicitada", guarda.obter_retrato()["retentativas"][0]["estado"])
        self.assertFalse(guarda.obter_retrato()["conjunto_encerrado"])
        self.assertTrue(guarda.parada_solicitada(pendente))
        self.negativo()

    def test_16_registro_vazio_gates_fechados_nao_prova_cobertura(self):
        self.registro.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.infra.registro_http.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])
        self.assertTrue(self.infra.registro_http.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_17_critica_b_http_e_configuracao_concorrentes(self):
        http_entrou, arquivo_entrou, liberar = threading.Event(), threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        web = WebTC420("simulado", politica_http=self.infra.criar_politica_http())
        origem = self.infra.preparar_http_inicial()
        arquivo = self.arquivo()
        def abrir(*args, **kwargs):
            self.esperar(arquivo_entrou, liberar)
            return arquivo
        with self.fluxo_http() as transporte, self.persistencia(arquivo) as abertura:
            transporte.antes = lambda: self.esperar(http_entrou, liberar)
            abertura.side_effect = abrir
            http = self.thread(lambda: self.infra.executar_login_automatico(
                web, "simulado", "simulado", contexto_http=origem))
            local = self.thread(self.ler)
            self.assertTrue(http_entrou.wait(3) and arquivo_entrou.wait(3))
            self.assertEqual(1, len(self.operacoes()))
            self.assertEqual(1, len(self.recursos()))
            self.assertTrue(self.operacoes()[0]["inicio_confirmado"])
            self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
            self.assertTrue(self.recursos()[0]["criacao_em_curso"])
            self.assertNotEqual(origem.geracao_id, self.recursos()[0]["geracao_id"])
            self.negativo()
            liberar.set()
            self.terminar(http)
            self.terminar(local)
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])
        self.negativo()

    def test_18_critica_c_publicacao_falha_apos_alocar(self):
        arquivo = self.arquivo()
        def falhar(token, fabrica):
            fabrica()
            raise RuntimeError("publicacao_simulada")
        with self.persistencia(arquivo), patch.object(self.registro, "criar", side_effect=falhar):
            with self.assertRaises(RuntimeError):
                self.ler()
        self.assertTrue(arquivo.closed)
        self.assertFalse(self.recursos()[0]["criacao_resolvida"])
        self.assertFalse(self.recursos()[0]["encerramento_confirmado"])
        self.assertEqual([], self.contexto.obter_pendencias())
        self.assertTrue(self.contexto.obter_historico()[0]["limpeza_comprovada"])
        self.negativo()

    def test_19_critica_e_thread_terminada_com_limpeza_em_curso(self):
        criados = []
        tarefa = self.thread(lambda: criados.extend(self.par()))
        self.terminar(tarefa)
        cliente, arquivo, bruto = criados
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        fechar = bruto.arquivo.close
        bruto.arquivo.close = lambda: (self.esperar(entrou, liberar), fechar())[-1]
        limpeza = self.thread(arquivo.close)
        self.assertTrue(entrou.wait(3))
        cliente.close()
        self.assertFalse(tarefa[0].is_alive())
        self.assertTrue(self.recursos()[1]["limpeza_em_curso"])
        self.assertFalse(self.recursos()[1]["encerramento_confirmado"])
        self.negativo()
        liberar.set()
        self.terminar(limpeza)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))
        self.negativo()

    def test_20_leitura_permanente_separada_da_partida_de_retentativa(self):
        leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        with patch("rede.lerdadosserver.threading.Thread", montagem.ThreadControlada):
            leitor.iniciar()
            principal = leitor.thread
            leitor.estado_candidatura = "liberada"
            leitor.tentativa_recuperacao = 1
            with patch("builtins.print"):
                self.assertTrue(leitor.registrar_falha_recuperacao())
            leitor.parar()
        self.assertTrue(principal.started)
        tentativa, = self.infra.registro_retentativas.obter_retrato()["retentativas"]
        self.assertTrue(tentativa["start_invocado"])
        self.assertFalse(tentativa["thread_terminada"])
        self.assertEqual(leitor.recursos_cliente.geracao_id, tentativa["geracao"])
        self.negativo()

    def test_21_parar_nao_comprova_thread_nem_makefile(self):
        leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        leitor.executando = True
        cliente, arquivo, bruto = self.par(leitor.recursos_cliente)
        leitor.cliente = cliente
        leitor.thread = SimpleNamespace(is_alive=Mock(return_value=True), join=Mock())
        leitor.parar()
        self.assertTrue(leitor._parada.is_set())
        self.assertTrue(leitor.thread.is_alive())
        leitor.thread.join.assert_not_called()
        bruto.shutdown.assert_called_once()
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])
        self.assertFalse(self.recursos()[1]["encerramento_confirmado"])
        self.negativo()
        arquivo.close()

    def test_22_modo_promocao_nao_publicado_pelos_fluxos_operacionais(self):
        for fonte in ("main.py", "rede/lerdadosserver.py", "interface/conexao.py", "interface/janela.py"):
            arvore = ast.parse((RAIZ / fonte).read_text(encoding="utf-8"))
            self.assertFalse(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                                 and n.func.attr == "promover" for n in ast.walk(arvore)))
        self.negativo()

    def test_23_diagnosticos_genericos_ainda_expoem_mensagem(self):
        udp = SocketDescobertaFalso()
        marcador = "marcador_de_erro_simulado_ac1"
        udp.sendto.side_effect = OSError(marcador)
        with patch.object(buscarservidor.socket, "socket", return_value=udp), patch("builtins.print") as saida:
            buscarservidor.buscar_servidor(infraestrutura_cliente=self.infra)
        self.assertIn(marcador, str(saida.call_args_list))
        self.assertNotIn(marcador, str(self.recursos()))

    def test_24_tk_callback_pendente_reproduzido_sem_tk_real(self):
        arvore = ast.parse((RAIZ / "interface/janela.py").read_text(encoding="utf-8"))
        metodo = next(n for n in ast.walk(arvore) if isinstance(n, ast.FunctionDef)
                      and n.name == "atualizar_refresh_web")
        ambiente = dict(print=Mock(), datetime=__import__('datetime').datetime)
        exec(compile(ast.Module(body=[metodo], type_ignores=[]), "callback_real", "exec"), ambiente)
        erro = tk.TclError("root_simulada_destruida")
        janela = SimpleNamespace(executando=True, fonte_dados=Mock(side_effect=ValueError("fonte_simulada")),
                                 root=SimpleNamespace(after=Mock(side_effect=erro), bind=Mock(), winfo_exists=lambda: True), atualizar_refresh_web=Mock())
        janela._agendar = janela.root.after
        with self.assertRaises(tk.TclError) as recebido:
            ambiente["atualizar_refresh_web"](janela)
        self.assertIs(erro, recebido.exception)  # after está fora do try; nenhuma correção aplicada.

    def test_25_refresh_principal_nao_entra_http_cliente(self):
        web = WebTC420("simulado", politica_http=self.infra.criar_politica_http())
        web.token = "simulado"
        with patch("requests.get", side_effect=RuntimeError("parada_simulada")) as enviar:
            with self.assertRaises(RuntimeError):
                web.refresh()
        enviar.assert_called_once()
        self.assertEqual([], self.operacoes())
        self.assertEqual([], self.recursos())
        self.negativo()

    def test_26_inventario_consolidado_sem_novos_criadores_explicitos(self):
        # Classificações históricas de L2/L3-A não são tomadas como situação atual.
        encontrados = inventario_anterior.inventario()
        self.assertEqual(set(inventario_anterior.REVISADOS), encontrados)
        self.assertEqual(2, sum(tipo == "open" for _, _, tipo in encontrados))
        self.negativo()

    def test_27_handle_nao_associado_preserva_dono_apos_saida_main(self):
        # Não usar StringIO nem lista de cleanup: queremos observar somente a
        # retenção do proprietário operacional, sem __del__ ou retenção do teste.
        referencias = []
        class HandleFalso:
            closed = False
            def close(self):
                raise OSError("limpeza_simulada")
        def abrir(*args, **kwargs):
            handle = HandleFalso()
            referencias.append(weakref.ref(handle))
            return handle
        def publicar(token, fabrica):
            fabrica()
            raise RuntimeError("publicacao_simulada")
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        fx.env["buscar_servidor"].return_value = None
        fx.env["carregar_configuracao"] = configuracao.carregar_configuracao
        with patch.object(infraestrutura_cliente, "InfraestruturaRegistrosCliente", return_value=self.infra), \
                patch.object(configuracao, "existe_configuracao", return_value=True), \
                patch.object(configuracao, "obter_caminho_configuracao", return_value="virtual-ac1.json"), \
                patch("builtins.open", side_effect=abrir), \
                patch.object(self.registro, "criar", side_effect=publicar):
            with self.assertRaises(RuntimeError):
                fx.env["iniciar"]()
        gc.collect()
        self.assertEqual(1, len(referencias))
        self.assertIsNotNone(referencias[0]())
        pendencia, = self.infra.obter_pendencias_arquivos()
        self.assertTrue(pendencia["handle_retido"])
        self.assertFalse(pendencia["limpeza_comprovada"])
        estado, = self.recursos()
        self.assertFalse(estado["criacao_resolvida"])
        self.assertFalse(estado["encerramento_confirmado"])
        self.negativo()
        original = referencias[0]()
        original.close = lambda: setattr(original, "closed", True)
        self.assertTrue(self.infra.tentar_limpeza_arquivo(pendencia["recurso_id"]))
        self.assertTrue(original.closed)
        self.assertEqual([], self.infra.obter_pendencias_arquivos())
        self.assertFalse(self.recursos()[0]["encerramento_confirmado"])
        self.negativo()

    def test_28_promocao_real_mantem_pendencias_cliente_na_infraestrutura(self):
        self.caminho_http_e_dados("promocao", preservar_antigo=True)

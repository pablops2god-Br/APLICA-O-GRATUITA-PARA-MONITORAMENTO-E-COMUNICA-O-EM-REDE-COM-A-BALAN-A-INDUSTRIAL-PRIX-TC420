# Testes de admissao register cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-C2: admissão atômica não equivale a cancelamento de envio aceito."""
import json
import gc
import threading
from types import SimpleNamespace
import unittest
import weakref
from unittest.mock import Mock, patch

from rede.admissao_register_cliente import AdmissaoRegisterCliente, RecursosRegisterCliente
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.lerdadosserver import LeitorDadosServidor
from test_recursos_cliente_integrados import SocketLeituraFalso
from apoio_conexoes_cliente import conexoes_tcp_simuladas
import test_auditoria_atividades_cliente_ac3b as auditoria
import test_partidas_retentativas_cliente as partidas


THREAD_REAL = threading.Thread


# Grupo de 38 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AdmissaoRegisterIntegrada(unittest.TestCase):
    promover_real = auditoria.AuditoriaAtividadesAC3B.promover_real
    fabricar = partidas.PartidasRetentativasCliente.fabricar

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.leitor = LeitorDadosServidor(ip_servidor='simulado', infraestrutura_cliente=self.infra)
        self.controle = self.leitor._admissao_register
        self.registro = self.infra.registro_recursos
        self.threads = []
        self.addCleanup(self.leitor.parar)

    def retrato(self):
        return self.leitor.obter_operacoes_register()

    def item(self):
        return self.retrato()['operacoes'][-1]

    def bruto(self):
        bruto = SocketLeituraFalso()
        bruto.arquivo.readline = Mock(return_value=json.dumps({'nome': self.leitor.nome_computador, 'posicao': 1}))
        return bruto

    def operar(self, bruto=None, identidade=None, fabrica=None, controle=None):
        controle = controle or self.controle
        identidade = identidade or controle.admitir()
        if identidade is None:
            return False
        bruto = bruto or self.bruto()
        with controle.executar(identidade) as dono:
            dono.registrar_cliente(fabrica or (lambda: bruto), self.leitor.nome_computador, json.loads)
        return True

    def negativo(self):
        resultado = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(resultado['encerramento_cliente_confirmado'])
        self.assertFalse(resultado['encerramento_global_confirmado'])
        self.assertFalse(self.retrato()['encerramento_global_confirmado'])
        return resultado

    def tarefa(self, funcao):
        erros = []
        def executar():
            try:
                funcao()
            except BaseException as erro:
                erros.append(erro)
        thread = THREAD_REAL(target=executar, daemon=True)
        thread.start()
        return thread, erros

    def terminar(self, tarefa):
        tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())
        self.assertEqual([], tarefa[1])

    def iniciar_loop(self):
        erros = []
        def fabricar(target, daemon):
            def executar():
                try:
                    target()
                except BaseException as erro:
                    erros.append(erro)
            return THREAD_REAL(target=executar, daemon=daemon)
        with patch('rede.lerdadosserver.threading', SimpleNamespace(Thread=fabricar)):
            self.leitor.iniciar()
        return self.leitor.thread, erros

    def recusar_no_loop(self):
        config = SocketLeituraFalso()
        config.arquivo.readline = Mock(return_value='{}')
        admitir = self.controle.admitir
        def parar_antes():
            self.leitor.parar()
            return admitir()
        self.leitor.executando = True
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config]) as conectar, \
                patch.object(self.controle, 'admitir', side_effect=parar_antes), \
                patch('rede.lerdadosserver.socket.socket') as socket, patch('builtins.print') as imprimir:
            self.leitor._manter_atualizado()
        self.assertEqual(1, conectar.call_count)  # somente CONFIG anterior à parada.
        socket.assert_not_called()
        return config, imprimir

    def test_01_antes_parada_admitido(self):
        self.assertTrue(self.operar())
        self.assertTrue(self.item()['retorno'])
        self.assertTrue(self.item()['responsabilidade_resolvida'])
        self.assertEqual(2, len(self.item()['recursos']))

    def test_02_A_depois_parada_recusado(self):
        self.leitor.parar()
        self.assertIsNone(self.controle.admitir())
        self.assertEqual([], self.retrato()['operacoes'])

    def test_03_parada_simultanea_decisao_atomica(self):
        barreira = threading.Barrier(2)
        aceitas = []
        def admitir():
            barreira.wait(3)
            aceitas.append(self.controle.admitir())
        def parar():
            barreira.wait(3)
            self.leitor.parar()
        a, b = self.tarefa(admitir), self.tarefa(parar)
        self.terminar(a)
        self.terminar(b)
        self.assertTrue(self.retrato()['admissao_fechada'])
        self.assertEqual(int(aceitas[0] is not None), len(self.retrato()['operacoes']))
        self.assertIsNone(self.controle.admitir())

    def test_04_recusa_sem_socket_REGISTER(self):
        self.recusar_no_loop()
        self.assertEqual(['socket_tcp', 'arquivo_socket'], [r['tipo'] for r in self.registro.obter_retrato()['recursos']])
        self.assertEqual([], self.retrato()['operacoes'])

    def test_05_recusa_sem_envio_ou_sucesso(self):
        config, imprimir = self.recusar_no_loop()
        config.sendall.assert_called_once_with(b'CONFIG\n')
        self.assertIsNone(self.leitor.posicao_sucessao)
        self.assertNotIn('Computador registrado:', [c.args[0] for c in imprimir.call_args_list if c.args])

    def test_06_aceita_preserva_identidade(self):
        identidade = self.controle.admitir()
        antes = self.item()
        self.leitor.parar()
        self.assertTrue(self.operar(identidade=identidade))
        self.assertEqual(antes['operacao_id'], self.item()['operacao_id'])
        self.assertEqual(antes['geracao_id'], self.item()['geracao_id'])

    def test_07_aceita_parada_posterior_continua_pendente(self):
        identidade = self.controle.admitir()
        self.leitor.parar()
        self.assertFalse(self.item()['responsabilidade_resolvida'])
        self.assertFalse(self.item()['iniciada'])
        self.assertTrue(self.operar(identidade=identidade))

    def test_08_socket_criado_limpeza_acompanhada(self):
        identidade = self.controle.admitir()
        bruto = self.bruto()
        with self.controle.executar(identidade) as dono:
            cliente = dono.abrir_socket(lambda: bruto)
            self.leitor.parar()
            self.assertFalse(self.item()['responsabilidade_resolvida'])
            dono.registrar_cliente(cliente, self.leitor.nome_computador, json.loads)
        self.assertTrue(self.item()['responsabilidade_resolvida'])
        self.assertTrue(bruto.fechado and bruto.arquivo.closed)

    def test_09_falha_antes_alocacao_reserva_resolvida(self):
        fabrica = Mock()
        original = OSError('antes_alocacao_simulado')
        with patch.object(self.registro, 'criar', side_effect=original):
            with self.assertRaises(OSError) as recebido:
                self.operar(fabrica=fabrica)
        self.assertIs(original, recebido.exception)
        fabrica.assert_not_called()
        recurso, = self.registro.obter_retrato()['recursos']
        self.assertTrue(recurso['ausencia_comprovada'])
        self.assertTrue(self.item()['responsabilidade_resolvida'])

    def test_10_falha_apos_alocacao_mantem_recurso(self):
        bruto = self.bruto()
        criar = self.registro.criar
        original = ValueError('apos_alocacao_simulado')
        def falhar(token, fabrica):
            return criar(token, fabrica, preparar=Mock(side_effect=original))
        with patch.object(self.registro, 'criar', side_effect=falhar):
            with self.assertRaises(ValueError) as recebido:
                self.operar(bruto)
        self.assertIs(original, recebido.exception)
        self.assertEqual(1, len(self.item()['recursos']))
        self.assertTrue(bruto.fechado)
        self.assertTrue(self.item()['recursos'][0]['limpeza_confirmada'])

    def test_11_falha_envio_preserva_original(self):
        bruto = self.bruto()
        original = OSError('envio_simulado')
        bruto.sendall.side_effect = original
        with self.assertRaises(OSError) as recebido:
            self.operar(bruto)
        self.assertIs(original, recebido.exception)
        self.assertTrue(bruto.fechado)
        self.assertEqual({'categoria': 'falha_io'}, self.item()['erro_operacao'])
        self.assertTrue(self.registro.obter_retrato()['recursos'][0]['erros_atendimento'])

    def test_12_falha_close_separada(self):
        bruto = self.bruto()
        original = OSError('close_simulado')
        bruto.erro_close = original
        with self.assertRaises(OSError) as recebido:
            self.operar(bruto)
        self.assertIs(original, recebido.exception)
        self.assertFalse(self.item()['responsabilidade_resolvida'])
        recurso = self.registro.obter_retrato()['recursos'][0]
        self.assertTrue(recurso['erros_limpeza'])
        self.assertFalse(recurso['erros_atendimento'])
        bruto.erro_close = None
        bruto.close()

    def test_13_promocao_preserva_geracao(self):
        identidade = self.controle.admitir()
        antes = self.item()
        self.leitor.executando = True
        with self.controle.executar(identidade) as dono:
            self.promover_real()
            self.assertTrue(self.item()['execucao_em_curso'])
            dono.registrar_cliente(lambda: self.bruto(), self.leitor.nome_computador, json.loads)
        self.assertEqual(antes['geracao_id'], self.item()['geracao_id'])
        self.assertEqual(antes['operacao_id'], self.item()['operacao_id'])

    def test_14_nova_geracao_controle_independente(self):
        self.leitor.parar()
        outro = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.assertIsNone(self.controle.admitir())
        self.assertTrue(self.operar(controle=outro._admissao_register))
        self.assertNotEqual(self.retrato()['geracao_id'], outro.obter_operacoes_register()['geracao_id'])
        self.assertFalse(outro.obter_operacoes_register()['admissao_fechada'])

    def test_15_parada_repetida_nao_reabre(self):
        for _ in range(3):
            self.leitor.parar()
        with patch('rede.lerdadosserver.threading.Thread', side_effect=self.fabricar):
            self.leitor.iniciar()
        self.assertTrue(self.retrato()['admissao_fechada'])
        self.assertIsNone(self.controle.admitir())

    def test_16_global_nunca_confirmado(self):
        self.operar()
        self.assertTrue(self.item()['responsabilidade_resolvida'])
        self.negativo()

    def test_17_C_parada_entre_checagem_e_admissao(self):
        config = SocketLeituraFalso()
        config.arquivo.readline = Mock(return_value='{}')
        entrou, liberar = threading.Event(), threading.Event()
        admitir = self.controle.admitir
        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return admitir()
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config]) as conectar, \
                patch.object(self.controle, 'admitir', side_effect=suspender), patch('builtins.print'):
            tarefa = self.iniciar_loop()
            try:
                self.assertTrue(entrou.wait(3))
                self.leitor.parar()
                self.assertIsNone(admitir())
            finally:
                liberar.set()
                self.terminar(tarefa)
        self.assertEqual(1, conectar.call_count)
        self.assertEqual([], self.retrato()['operacoes'])
        self.assertTrue(self.infra.observar_termino_leitores()[0]['termino_observado'])

    def test_18_B_admitida_antes_envia_depois(self):
        identidade = self.controle.admitir()
        bruto, vistos = self.bruto(), []
        bruto.sendall.side_effect = lambda dados: vistos.append((self.leitor.executando, self.item()))
        self.leitor.parar()
        self.operar(bruto, identidade)
        self.assertFalse(vistos[0][0])
        self.assertTrue(vistos[0][1]['execucao_em_curso'])
        self.assertEqual(identidade.numero, vistos[0][1]['operacao_id'])
        self.assertTrue(self.item()['responsabilidade_resolvida'])

    def test_19_D_criacao_pendente_contra_parada(self):
        entrou, liberar = threading.Event(), threading.Event()
        bruto = self.bruto()
        def fabrica():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return bruto
        tarefa = self.tarefa(lambda: self.operar(bruto, fabrica=fabrica))
        try:
            self.assertTrue(entrou.wait(3))
            antes = self.item()
            self.assertTrue(self.registro.obter_retrato()['recursos'][0]['criacao_em_curso'])
            self.assertTrue(antes['recursos'][0]['associacao_publicada'])
            self.leitor.parar()
            self.assertFalse(self.item()['responsabilidade_resolvida'])
        finally:
            liberar.set()
            self.terminar(tarefa)
        self.assertEqual(antes['operacao_id'], self.item()['operacao_id'])
        self.assertTrue(self.item()['responsabilidade_resolvida'])

    def test_20_E_promocao_com_REGISTER_A_e_geracao_B(self):
        config, registro = SocketLeituraFalso(), self.bruto()
        config.arquivo.readline = Mock(return_value='{}')
        entrou, liberar = threading.Event(), threading.Event()
        def resposta():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return json.dumps({'nome': self.leitor.nome_computador, 'posicao': 1})
        registro.arquivo.readline.side_effect = resposta
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config, registro]), patch('builtins.print'):
            tarefa = self.iniciar_loop()
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.item()
                self.promover_real()
                novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
                self.assertNotEqual(antes['geracao_id'], novo.obter_operacoes_register()['geracao_id'])
                self.assertTrue(self.item()['execucao_em_curso'])
                self.assertEqual(antes['operacao_id'], self.item()['operacao_id'])
                self.negativo()
            finally:
                liberar.set()
                self.terminar(tarefa)
        self.assertTrue(self.item()['responsabilidade_resolvida'])

    def test_21_F_publicacao_pendente_thread_finalizando(self):
        config, registro = SocketLeituraFalso(), self.bruto()
        config.arquivo.readline = Mock(return_value='{}')
        entrou, liberar = threading.Event(), threading.Event()
        def publicar(*args):
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            raise OSError('publicacao_simulada')
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config, registro]), \
                patch.object(self.controle, '_publicar_saida', side_effect=publicar), patch('builtins.print'):
            tarefa = self.iniciar_loop()
            try:
                self.assertTrue(entrou.wait(3))
                self.leitor.parar()
                self.assertFalse(self.item()['responsabilidade_resolvida'])
                self.assertFalse(self.infra.observar_termino_leitores()[0]['termino_observado'])
                self.negativo()
            finally:
                liberar.set()
                self.terminar(tarefa)
        self.assertTrue(self.infra.observar_termino_leitores()[0]['termino_observado'])
        self.assertTrue(self.item()['erro_publicacao'])
        self.assertFalse(self.item()['responsabilidade_resolvida'])
        self.negativo()

    def test_22_adicional_admitir_nao_e_cancelar_envio(self):
        identidade = self.controle.admitir()
        bruto = self.bruto()
        self.leitor.parar()
        self.assertTrue(self.operar(bruto, identidade))
        bruto.sendall.assert_called_once_with(f'REGISTER|{self.leitor.nome_computador}\n'.encode('utf-8'))
        antes = self.registro.obter_retrato()
        fabrica = Mock()
        self.assertFalse(self.operar(fabrica=fabrica))
        fabrica.assert_not_called()
        self.assertEqual(antes, self.registro.obter_retrato())

    def test_23_comunicacao_e_limpeza_preservam_primario(self):
        bruto = self.bruto()
        original, limpeza = ValueError('envio_simulado'), OSError('limpeza_simulada')
        bruto.sendall.side_effect = original
        bruto.erro_close = limpeza
        with self.assertRaises(ValueError) as recebido:
            self.operar(bruto)
        self.assertIs(original, recebido.exception)
        recurso = self.registro.obter_retrato()['recursos'][0]
        self.assertTrue(recurso['erros_atendimento'] and recurso['erros_limpeza'])
        self.assertEqual('falha_operacao', self.item()['erro_operacao']['categoria'])
        bruto.erro_close = None
        bruto.close()

    def test_24_publicacao_tardia_nao_resolve_antes_de_retornar(self):
        entrou, liberar = threading.Event(), threading.Event()
        publicar = self.controle._publicar_saida
        def suspender(*args):
            publicar(*args)
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
        with patch.object(self.controle, '_publicar_saida', side_effect=suspender):
            tarefa = self.tarefa(self.operar)
            try:
                self.assertTrue(entrou.wait(3))
                self.leitor.parar()
                self.assertTrue(self.item()['retorno'])
                self.assertFalse(self.item()['responsabilidade_resolvida'])
            finally:
                liberar.set()
                self.terminar(tarefa)
        self.assertTrue(self.item()['responsabilidade_resolvida'])

    def test_25_gate_recursos_pode_recusar_sem_fabrica(self):
        fabrica = Mock()
        self.registro.fechar_admissao()
        with self.assertRaises(RuntimeError):
            self.operar(fabrica=fabrica)
        fabrica.assert_not_called()
        self.assertEqual([], self.registro.obter_retrato()['recursos'])

    def test_26_socket_alheio_e_token_estrangeiro_recusados(self):
        outro = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        token = outro._admissao_register.admitir()
        with self.assertRaises(ValueError):
            with self.controle.executar(token):
                self.fail('token estrangeiro aceito')
        bruto = self.bruto()
        cliente = self.leitor.recursos_cliente.abrir_socket(lambda: bruto)
        identidade = self.controle.admitir()
        with self.assertRaises(ValueError):
            with self.controle.executar(identidade) as dono:
                dono.registrar_cliente(cliente, self.leitor.nome_computador, json.loads)
        self.assertEqual(0, bruto.close_chamadas)
        cliente.close()

    def test_27_IO_e_cleanup_fora_dos_locks(self):
        bruto = self.bruto()
        def verificar():
            for lock in (self.controle._lock, self.registro._lock):
                self.assertTrue(lock.acquire(blocking=False))
                lock.release()
            self.retrato()
        bruto.sendall.side_effect = lambda dados: verificar()
        bruto.arquivo.readline.side_effect = lambda: (verificar(), '{}')[-1]
        fechar_socket, fechar_arquivo = bruto.close, bruto.arquivo.close
        bruto.close = lambda: (verificar(), fechar_socket())[-1]
        bruto.arquivo.close = lambda: (verificar(), fechar_arquivo())[-1]
        self.operar(bruto, fabrica=lambda: (verificar(), bruto)[-1])

    def test_28_consultas_nao_observam_nem_mutam(self):
        self.operar()
        antes = (self.retrato(), self.registro.obter_retrato(), self.infra.obter_atividades_permanentes(),
                 self.infra.registro_retentativas.obter_retrato())
        with patch.object(type(self.infra), 'observar_termino_leitores', side_effect=AssertionError('implicito')) as observar:
            self.negativo()
            self.retrato()
        observar.assert_not_called()
        self.assertEqual(antes, (self.retrato(), self.registro.obter_retrato(), self.infra.obter_atividades_permanentes(),
                                 self.infra.registro_retentativas.obter_retrato()))

    def test_29_adaptador_apos_saida_nao_cria_recurso(self):
        identidade = self.controle.admitir()
        bruto = self.bruto()
        with self.controle.executar(identidade) as dono:
            cliente = dono.abrir_socket(lambda: bruto)
        fabrica = Mock()
        with self.assertRaises(RuntimeError):
            dono.abrir_socket(fabrica)
        with self.assertRaises(RuntimeError):
            dono.registrar_cliente(cliente, self.leitor.nome_computador, json.loads)
        bruto.sendall.assert_not_called()
        fabrica.assert_not_called()
        self.assertEqual(1, len(self.registro.obter_retrato()['recursos']))
        cliente.close()

    def test_30_associacao_falha_antes_fabrica(self):
        fabrica = Mock()
        with patch.object(RecursosRegisterCliente, '_publicar_vinculo', side_effect=OSError('vinculo_simulado')):
            with self.assertRaises(OSError):
                self.operar(fabrica=fabrica)
        fabrica.assert_not_called()
        self.assertTrue(self.item()['erro_associacao'])
        self.assertTrue(self.registro.obter_retrato()['recursos'][0]['ausencia_comprovada'])
        self.assertFalse(self.item()['responsabilidade_resolvida'])

    def test_31_erro_primario_e_publicacao_falham(self):
        bruto = self.bruto()
        original, secundario = OSError('envio_privado_simulado'), ValueError('publicacao_simulada')
        bruto.sendall.side_effect = original
        with patch.object(self.controle, '_publicar_saida', side_effect=secundario):
            with self.assertRaises(OSError) as recebido:
                self.operar(bruto)
        self.assertIs(original, recebido.exception)
        self.assertIs(secundario, original.__cause__)
        self.assertTrue(self.item()['erro_publicacao'])
        self.assertFalse(self.item()['retorno'])
        self.assertNotIn(str(original), str(self.retrato()))

    def test_32_duas_operacoes_simultaneas(self):
        barreira = threading.Barrier(3)
        liberar = threading.Event()
        def fabrica():
            barreira.wait(3)
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return self.bruto()
        a = self.tarefa(lambda: self.operar(fabrica=fabrica))
        b = self.tarefa(lambda: self.operar(fabrica=fabrica))
        try:
            barreira.wait(3)
            self.leitor.parar()
            itens = self.retrato()['operacoes']
            self.assertEqual(2, len({r['operacao_id'] for r in itens}))
            self.assertTrue(all(r['execucao_em_curso'] and not r['responsabilidade_resolvida'] for r in itens))
        finally:
            liberar.set()
            self.terminar(a)
            self.terminar(b)
        self.assertTrue(all(r['responsabilidade_resolvida'] for r in self.retrato()['operacoes']))
        self.assertEqual(4, len(self.registro.obter_retrato()['recursos']))

    def test_33_closed_false_conserva_pendencia(self):
        bruto = self.bruto()
        fechar = bruto.arquivo.close
        bruto.arquivo.close = Mock()
        self.operar(bruto)
        self.assertFalse(self.item()['responsabilidade_resolvida'])
        self.assertTrue(self.registro.obter_retrato()['recursos'][1]['erros_evidencia'])
        fechar()

    def test_34_nao_fecha_SUBSCRIBE_independente(self):
        bruto = self.bruto()
        cliente = self.leitor.recursos_cliente.abrir_socket(lambda: bruto)
        self.operar()
        self.assertEqual(0, bruto.close_chamadas)
        self.assertNotIn(cliente.recurso_id.numero, [r['recurso_id'] for r in self.item()['recursos']])
        self.assertIn(cliente.recurso_id.numero, self.negativo()['recursos_pendentes'])
        cliente.close()

    def test_35_origem_conteudo_porta_timeout_e_resposta_preservados(self):
        config, registro = SocketLeituraFalso(), self.bruto()
        config.arquivo.readline = Mock(return_value='{}')
        def resposta():
            self.leitor.parar()
            return json.dumps({'nome': self.leitor.nome_computador, 'posicao': 1})
        registro.arquivo.readline.side_effect = resposta
        self.leitor.executando = True
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config, registro]) as conectar, patch('builtins.print'):
            self.leitor._manter_atualizado()
        self.assertEqual(2, conectar.call_count)
        self.assertTrue(all(c.args == (('simulado', 42100),) and c.kwargs == {'timeout': 5}
                            for c in conectar.call_args_list))
        registro.sendall.assert_called_once_with(f'REGISTER|{self.leitor.nome_computador}\n'.encode('utf-8'))
        registro.makefile.assert_called_once_with('r', encoding='utf-8')
        self.assertEqual(1, self.leitor.posicao_sucessao)
        self.assertTrue(self.item()['responsabilidade_resolvida'])

    def test_36_aplicacao_retem_controle_apos_perder_leitor(self):
        antigo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        controle = antigo._admissao_register
        bruto = self.bruto()
        bruto.erro_close = OSError('cleanup_simulado')
        with self.assertRaises(OSError):
            self.operar(bruto, controle=controle)
        leitor_ref, controle_ref = weakref.ref(antigo), weakref.ref(controle)
        del antigo, controle
        gc.collect()
        self.assertIsNone(leitor_ref())
        self.assertIsNotNone(controle_ref())
        self.assertIn(controle_ref(), self.infra.registro_atividades_permanentes.obter_controles_register())
        item, = controle_ref().obter_retrato()['operacoes']
        self.assertFalse(item['responsabilidade_resolvida'])
        self.assertEqual(2, len(item['recursos']))
        bruto.erro_close = None
        bruto.close()

    def test_37_uma_autoridade_por_geracao_e_dono(self):
        registro = self.infra.registro_atividades_permanentes
        origem = self.leitor._origem_atividade_permanente
        registro.reter_admissao_register(origem, self.controle)  # idempotente.
        outro = AdmissaoRegisterCliente(self.leitor.recursos_cliente, self.infra.aplicacao_id)
        with self.assertRaises(ValueError):
            registro.reter_admissao_register(origem, outro)
        segunda_origem = registro.preparar_leitor(self.leitor.recursos_cliente)
        with self.assertRaises(ValueError):
            registro.reter_admissao_register(segunda_origem, outro)
        estrangeira = InfraestruturaRegistrosCliente()
        with self.assertRaises(ValueError):
            estrangeira.registro_atividades_permanentes.reter_admissao_register(origem, self.controle)
        self.assertEqual((self.controle,), registro.obter_controles_register())

    def test_38_handle_REGISTER_nao_associado_retido_pela_aplicacao(self):
        antigo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        controle = antigo._admissao_register
        bruto = self.bruto()
        bruto.erro_close = OSError('cleanup_simulado')
        def falhar(token, fabrica):
            fabrica()
            raise RuntimeError('associacao_simulada')
        with patch.object(self.registro, 'criar', side_effect=falhar):
            with self.assertRaises(RuntimeError):
                self.operar(bruto, controle=controle)
        leitor_ref, controle_ref, handle_ref = weakref.ref(antigo), weakref.ref(controle), weakref.ref(bruto)
        del antigo, controle, bruto
        gc.collect()
        self.assertIsNone(leitor_ref())
        self.assertIsNotNone(controle_ref())
        self.assertIsNotNone(handle_ref())
        item, = controle_ref().obter_retrato()['operacoes']
        self.assertFalse(item['responsabilidade_resolvida'])
        self.assertEqual(1, len(item['recursos']))
        handle_ref().erro_close = None
        handle_ref().close()

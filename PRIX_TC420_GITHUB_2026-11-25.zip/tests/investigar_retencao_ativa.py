"""Medições 2B.5 isoladas, GC explícito, tracemalloc; sem rede."""
import gc
import argparse
import json
from pathlib import Path
import platform
import sys
import time
import tracemalloc
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rede import servidor as s
from prototipos.retencao_ciclo_ativo import SemRecursoMinimo, RegistroSeparacaoExperimental


class SocketSintetico:
    def __init__(self):
        self.fechado = False
    def fileno(self):
        return -1 if self.fechado else 1
    def close(self):
        self.fechado = True


def medir(estrategia, sockets=False, total=50000):
    gc.collect()
    tracemalloc.start()
    inicio = time.perf_counter()
    cls = RegistroSeparacaoExperimental if estrategia == 'B' else s.RegistroTrabalhadores
    r = cls()
    representacao = SemRecursoMinimo if estrategia == 'A' else s._CriacaoSocketResolvida
    with patch.object(s, '_CriacaoSocketResolvida', representacao):
        for _ in range(total):
            token = r.reservar_criacao_socket()
            if sockets:
                sock = SocketSintetico()
                r.anexar_socket(token, sock)
                r.publicar_socket(token)
                r.encerrar_uso_socket(token)
                assert r.fechar_socket(token)
            else:
                r.resolver_falha_criacao_socket(token, sem_alocacao_comprovada=True)
    if sockets:
        del sock
    gc.collect()
    antes, pico_antes = tracemalloc.get_traced_memory()
    retirados = r.separar_recursos_resolvidos() if estrategia == 'B' else 0
    gc.collect()
    retida, pico = tracemalloc.get_traced_memory()
    carga_segundos = time.perf_counter()-inicio
    tracemalloc.reset_peak()
    inicio_consulta = time.perf_counter()
    diagnostico = r.obter_situacao()
    consulta_segundos = time.perf_counter()-inicio_consulta
    _, pico_consulta = tracemalloc.get_traced_memory()
    assert len(diagnostico['criacoes_socket']) == total
    assert r.fechar_socket(token)
    resultado = dict(estrategia=estrategia, carga='sockets_sinteticos_fechados' if sockets else 'sem_recurso',
        reservas=total, entradas=len(r._reservas_socket), threads=len(r.threads),
        referencias_recursos=sum(e.recurso is not None for e in r._reservas_socket.values()),
        recursos_abertos=sum(e.recurso is not None and e.recurso.fileno() != -1 for e in r._reservas_socket.values()),
        bytes_antes_separacao=antes, bytes_retidos=retida, pico_ate_separacao=pico,
        segundos_carga=carga_segundos, consulta_segundos=consulta_segundos,
        consulta_pico_absoluto_bytes=pico_consulta, recursos_separados=retirados)
    tracemalloc.stop()
    return resultado


def verificar_contratos():
    import unittest
    nomes = ['test_guarda_sockets_integrada', 'test_erros_fechamento_handlers',
             'test_saida_aplicacao_b2', 'test_supervisao_principal']
    with patch.object(s, '_CriacaoSocketResolvida', SemRecursoMinimo):
        suite = unittest.defaultTestLoader.loadTestsFromNames(['test_compactacao_registro'] + nomes)
        a = unittest.TextTestRunner(verbosity=0).run(suite)
    class AdaptadorExperimental(RegistroSeparacaoExperimental):
        def obter_situacao(self):
            self.separar_recursos_resolvidos()
            return super().obter_situacao()
    with patch.object(s, 'RegistroTrabalhadores', AdaptadorExperimental):
        suite = unittest.defaultTestLoader.loadTestsFromNames(nomes)
        b = unittest.TextTestRunner(verbosity=0).run(suite)
    return a.wasSuccessful() and b.wasSuccessful()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--contratos', action='store_true')
    args = parser.parse_args()
    if args.contratos:
        raise SystemExit(not verificar_contratos())
    print(json.dumps(dict(python=platform.python_version(), plataforma=sys.platform,
        medicoes=[medir(e) for e in ('atual', 'A', 'B')] +
                 [medir(e, sockets=True) for e in ('atual', 'B')],
        limites='50 mil por carga isolada; sockets sao dubles, nao handles reais; nao e RSS.'), indent=2))

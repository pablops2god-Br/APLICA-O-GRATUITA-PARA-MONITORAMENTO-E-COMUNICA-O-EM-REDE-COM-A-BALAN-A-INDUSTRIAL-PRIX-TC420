"""Telas administrativas de produção com persistência temporária e cofre falso."""
from pathlib import Path
import secrets
import sys
import tempfile
import time
import tkinter as tk
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from config import administrador as armazenamento
from interface import administrador as ui
from interface.saida_aplicacao import SaidaAplicacao


def executar():
    with tempfile.TemporaryDirectory() as pasta, \
         patch('config.configuracao.obter_caminho_configuracao', return_value=str(Path(pasta)/'configuracao.json')), \
         patch('keyring.get_password', return_value=None), \
         patch('keyring.delete_password') as excluir, \
         patch('socket.socket', side_effect=AssertionError('rede proibida')):
        senha = secrets.token_urlsafe(16)
        tk_original = tk.Tk
        erros = []
        telas = []
        def inicio_automatizado(forcar=False, restaurar=False):
            controlador = ui.ControleAdministrador()
            def criar_root():
                root = tk_original()
                root.report_callback_exception = lambda *args: erros.append(args)
                limite = time.monotonic() + 8
                def preencher():
                    if time.monotonic() > limite:
                        erros.append('tempo excedido')
                        root.quit()
                        return
                    tela = controlador.tela
                    if tela is not None and tela.botao.cget('state') == 'normal':
                        telas.append(tela.cadastro)
                        tela.senha.insert(0, senha)
                        if tela.cadastro:
                            tela.repeticao.insert(0, senha)
                        tela.botao.invoke()
                    root.after(20, preencher)
                root.after(20, preencher)
                return root
            with patch.object(ui, 'ControleAdministrador', return_value=controlador), \
                 patch.object(ui.tk, 'Tk', side_effect=criar_root):
                return ui.preparar_inicio(forcar, restaurar)
        try:
            assert inicio_automatizado() == (True, False)
            assert telas == [True, False], telas
            telas.clear()
            assert inicio_automatizado() == (True, False)
            assert telas == [], 'HTTPS automático não deve pedir login'
            armazenamento.salvar_metodo('TCP')
            assert inicio_automatizado() == (True, True)
            assert telas == [False], telas
            root = tk_original()
            root.report_callback_exception = lambda *args: erros.append(args)
            class Dono:
                pass
            dono = Dono()
            dono.root = root
            dono.cadastro_inicial = True
            dono.saida_aplicacao = SaidaAplicacao()
            dono.saida_aplicacao.vincular('teste_administrativo')
            reinicios = []
            dono.reiniciar_administracao = lambda: reinicios.append(True)
            controle = ui.ControleAdministrador()
            liberacoes = []
            def esperar(condicao):
                fim = time.monotonic()+5
                while not condicao() and time.monotonic()<fim:
                    root.update()
                    time.sleep(.01)
                assert condicao()
            controle.pedir(dono, 'Reconfiguração', lambda: liberacoes.append(True))
            tela = controle.tela
            esperar(lambda: tela.botao.cget('state') == 'normal')
            tela.senha.insert(0, secrets.token_urlsafe(16))
            tela.botao.invoke()
            esperar(lambda: tela.botao.cget('state') == 'normal')
            assert not liberacoes
            with patch.object(ui.messagebox, 'askyesno', return_value=False):
                tela.restaurar()
            assert armazenamento.carregar() is not None and not reinicios
            with patch.object(ui.messagebox, 'askyesno', return_value=True):
                tela.restaurar()
            esperar(lambda: bool(reinicios))
            assert armazenamento.carregar() is None
            excluir.assert_not_called()
            root.destroy()
            # Reconfiguração de um monitor real ligado à raiz de conexão.
            # A callback representa o novo processo; não lança nada no ensaio.
            from interface.conexao import JanelaConexao
            from rede.servidor import RegistroTentativasAplicacao
            class Leitor:
                thread = None
                def parar(self):
                    self.parado = True
                def obter_dados_atuais(self):
                    return dict(peso_liquido='0', tara='—', unidade='kg', estado='TCP', multirange='—')
                def comunicacao_esta_atual(self):
                    return True
                def registrar_diagnostico(self, _estado):
                    pass
            armazenamento.cadastrar(senha)
            for restaurando in (False, True):
                controle = ui.ControleAdministrador()
                controle.autorizado = True
                ui._controle = controle
                saida = SaidaAplicacao()
                saida.configurar(registro=RegistroTentativasAplicacao())
                reinicios = []
                saida.ao_reconfigurar = lambda: reinicios.append(True)
                app = JanelaConexao(saida_aplicacao=saida)
                root = app.root
                root.report_callback_exception = lambda *args: erros.append(args)
                leitor = Leitor()
                saida.acompanhar_leitor(leitor)
                with patch('interface.notificacoes.notificar_estado'):
                    app.abrir_monitor_tcp_local(leitor)
                    monitor = app.monitor
                    monitor.menu_opcoes.invoke('Reconfigurar')
                    tela = controle.tela
                    esperar(lambda: tela.botao.cget('state') == 'normal')
                    if restaurando:
                        with patch.object(ui.messagebox, 'askyesno', return_value=True):
                            tela.restaurar()
                        assert armazenamento.carregar() is not None
                    else:
                        tela.senha.insert(0, senha)
                        tela.botao.invoke()
                    esperar(lambda: bool(reinicios))
                assert saida.obter_situacao()['parada_operacional_confirmada']
                assert leitor.parado
                assert reinicios == [True]
                if restaurando:
                    assert saida.restaurar_administrador
                    assert armazenamento.carregar() is not None, 'limpeza deve aguardar nova execução'
            telas.clear()
            assert inicio_automatizado(True, True) == (True, False)
            assert telas == [True, False], telas
            assert not erros, erros
            print('Tk operacional: cadastro/login, HTTPS sem login, TCP com login, senha errada e restauração SIM/NÃO OK.')
            print('Monitor real: login e restauração encerram via B2; limpeza adiada até a nova execução OK.')
        finally:
            ui._controle = None


if __name__ == '__main__':
    executar()

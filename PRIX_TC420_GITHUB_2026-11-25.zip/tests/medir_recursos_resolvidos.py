"""2B.9: mesma carga mista 2B.8, threads e sockets separados. Sem tráfego."""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import platform
import sys
import time
import tracemalloc
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rede import servidor as s
from interface.saida_aplicacao import SaidaAplicacao
from prototipos.recursos_resolvidos import (RegistroThreadsExperimental,
    RegistroSocketsExperimental, RegistroCombinadoExperimental)
from medir_fragmentacao_escrita import montar, BACKENDS
from medir_consultas_intervalos import perfil

CLASSES = dict(atual=s.RegistroTrabalhadores, threads=RegistroThreadsExperimental,
               sockets=RegistroSocketsExperimental, combinado=RegistroCombinadoExperimental)


def construir(modo, timings=False):
    with patch.dict(BACKENDS, atual=CLASSES[modo]):
        return montar('atual', 'mista_hora', timings)


def reduzir(r, modo):
    sockets = r.separar_sockets_resolvidos() if modo in ('sockets','combinado') else 0
    threads = r.resumir_threads_resolvidas() if modo in ('threads','combinado') else 0
    return dict(threads=threads, sockets=sockets)


def verificar_b2(r):
    c = s.ControleCicloServidor()
    assert c.tentar_iniciar(r) and c.finalizar(r)
    ctx = s.ContextoCicloServidor()
    ctx.registrar_reserva(1); ctx.registrar_retorno_coordenador()
    saida = SaidaAplicacao(prazo=2)
    saida.configurar(registro=s.RegistroTentativasAplicacao())
    saida.acompanhar_contexto(ctx)
    with patch.object(s,'controle_ciclo_servidor',c):
        saida.vincular('ensaio_recursos_resolvidos')()
        saida._coordenacao.join(3)
        assert not saida._coordenacao.is_alive()
        resultado = saida.obter_situacao()
        assert resultado['parada_operacional_confirmada'], resultado
        assert s.avaliar_encerramento_tentativa(ctx)['encerramento_confirmado'] is True
    return resultado['estado']


def medir(modo):
    gc.collect()
    r, _, _, escrita = construir(modo, True)
    digest = hashlib.sha256(repr(r.obter_situacao()).encode()).hexdigest()
    r.lock.registros.clear()
    inicio = time.perf_counter()
    retiradas = reduzir(r, modo)
    tempo = time.perf_counter()-inicio
    registros = list(r.lock.registros)
    assert hashlib.sha256(repr(r.obter_situacao()).encode()).hexdigest() == digest
    consulta = perfil(r, r.obter_situacao)
    agregado = perfil(r, r.encerramento_confirmado)
    b2 = verificar_b2(r)
    del r
    gc.collect()
    tracemalloc.start()
    r, _, _, _ = construir(modo)
    gc.collect()
    antes, pico = tracemalloc.get_traced_memory()
    tracemalloc.reset_peak()
    reduzir(r, modo)
    gc.collect()
    depois, pico_reducao = tracemalloc.get_traced_memory()
    tracemalloc.reset_peak()
    retrato = r.obter_situacao()
    _, pico_consulta = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    assert hashlib.sha256(repr(retrato).encode()).hexdigest() == digest
    assert r.encerramento_confirmado()
    return dict(modo=modo, digest=digest, reservas=len(r._reservas_socket),
        threads_retidas=len(r.threads), threads_vivas=sum(t.is_alive() for t in r.threads),
        objetos_thread=sum(type(t).__name__=='Thread' for t in r.threads),
        sockets_referenciados=sum(e.recurso is not None for e in r._reservas_socket.values()),
        retiradas=retiradas, bytes_antes=antes, bytes_depois=depois,
        pico_carga_bytes=pico, pico_reducao_bytes=pico_reducao,
        pico_consulta_absoluto_bytes=pico_consulta, escrita=escrita,
        reducao_s=tempo, reducao_espera_total_s=sum(e for e,_ in registros),
        reducao_posse_total_s=sum(h for _,h in registros),
        reducao_posse_maxima_s=max((h for _,h in registros),default=0),
        consulta=consulta, agregado=agregado, b2=b2)


def externos():
    gc.collect()
    tracemalloc.start()
    r, _, _, _ = construir('threads')
    mantidas = list(r.threads)
    gc.collect()
    antes,_ = tracemalloc.get_traced_memory()
    r.resumir_threads_resolvidas()
    gc.collect()
    depois,_ = tracemalloc.get_traced_memory()
    del mantidas
    gc.collect()
    soltas,_ = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return dict(referencias_externas=13724, bytes_antes=antes,
                bytes_depois_com_referencias=depois, bytes_apos_soltar_referencias=soltas)


def contratos():
    nomes = ['test_compactacao_registro','test_guarda_sockets_integrada',
             'test_erros_fechamento_handlers','test_saida_aplicacao_b2','test_supervisao_principal']
    for base in (RegistroThreadsExperimental, RegistroSocketsExperimental, RegistroCombinadoExperimental):
        class Adaptador(base):
            def obter_situacao(self):
                if hasattr(self, 'separar_sockets_resolvidos'):
                    self.separar_sockets_resolvidos()
                if hasattr(self, 'resumir_threads_resolvidas'):
                    self.resumir_threads_resolvidas()
                return super().obter_situacao()
        with patch.object(s, 'RegistroTrabalhadores', Adaptador):
            resultado = unittest.TextTestRunner(verbosity=0).run(
                unittest.defaultTestLoader.loadTestsFromNames(nomes))
            if not resultado.wasSuccessful():
                return False
    return True


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--saida',type=Path)
    parser.add_argument('--contratos',action='store_true')
    args = parser.parse_args()
    if args.contratos:
        raise SystemExit(not contratos())
    if args.saida is None:
        parser.error('--saida obrigatorio para medicoes')
    medicoes = []
    for modo in CLASSES:
        medicoes.append(medir(modo))
        args.saida.write_text(json.dumps(dict(concluido=False, medicoes=medicoes),indent=2),encoding='utf-8')
    assert len({m['digest'] for m in medicoes}) == 1
    args.saida.write_text(json.dumps(dict(concluido=True,python=platform.python_version(),
        plataforma=sys.platform,medicoes=medicoes,referencias_externas=externos(),
        limites='Grafo sintetico 2B.8; threads start/join reais, sockets dubles; tracemalloc nao e RSS. '
        'B2 avalia contexto ja finalizado, nao mede parada de servidor em funcionamento.'),indent=2),encoding='utf-8')

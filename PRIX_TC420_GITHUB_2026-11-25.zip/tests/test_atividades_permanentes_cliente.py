# Testes de atividades permanentes cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-C1: partida/término do leitor; protocolos e parada preservados."""
import json
import threading
from types import SimpleNamespace
import traceback
import unittest
from unittest.mock import Mock, patch

from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.lerdadosserver import LeitorDadosServidor
import test_partidas_retentativas_cliente as partidas
import test_auditoria_atividades_cliente_ac3b as auditoria
import test_composicao_operacional_cliente as composicao
from test_recursos_cliente_integrados import SocketLeituraFalso
from apoio_conexoes_cliente import conexoes_tcp_simuladas, conectores_tcp_controlados


THREAD_REAL = threading.Thread


# Grupo de 40 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AtividadesPermanentesCliente(unittest.TestCase):
    fabricar = partidas.PartidasRetentativasCliente.fabricar
    permanente_bloqueada = auditoria.AuditoriaAtividadesAC3B.permanente_bloqueada
    promover_real = auditoria.AuditoriaAtividadesAC3B.promover_real
    par_leitor = composicao.ComposicaoOperacionalCliente.par_leitor

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        partidas.PartidasRetentativasCliente.setUp(self)
        self.leitor.executando = False
        self.alvo_real = self.leitor._manter_atualizado
        self.alvo = Mock()
        self.leitor._manter_atualizado = self.alvo
        self.registro = self.infra.registro_atividades_permanentes

    def iniciar(self, leitor=None):
        with patch('rede.lerdadosserver.threading.Thread', side_effect=self.fabrica):
            return (leitor or self.leitor).iniciar()

    def atividades(self):
        return self.infra.obter_atividades_permanentes()['atividades']

    def item(self):
        return self.atividades()[-1]

    def observar(self):
        return self.infra.observar_termino_leitores()[-1]['termino_observado']

    def negativo(self):
        resultado = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(resultado['encerramento_cliente_confirmado'])
        self.assertFalse(resultado['encerramento_global_confirmado'])
        return resultado

    def test_01_reserva_antes_da_fabrica(self):
        def fabricar(**kwargs):
            item, = self.atividades()
            self.assertEqual('leitor_permanente', item['tipo'])
            self.assertTrue(item['partida_em_curso'])
            self.assertEqual(self.leitor.recursos_cliente.geracao_id, item['geracao_id'])
            return self.fabricar(**kwargs)
        self.fabrica = fabricar
        self.assertIsNone(self.iniciar())
        self.assertEqual([], self.guarda.obter_retrato()['retentativas'])

    def test_02_reserva_recusada_sem_flags_ou_start(self):
        self.leitor._parada.set()
        self.registro.fechar_admissao()
        self.assertIsNone(self.iniciar())
        self.assertFalse(self.leitor.executando)
        self.assertTrue(self.leitor._parada.is_set())
        self.assertIsNone(self.leitor.thread)
        self.assertEqual([], self.threads)
        self.assertEqual([], self.atividades())

    def test_03_construcao_falha_preserva_original(self):
        original = OSError('construcao_simulada')
        self.fabrica = Mock(side_effect=original)
        with self.assertRaises(OSError) as recebido:
            self.iniciar()
        self.assertIs(original, recebido.exception)
        self.assertTrue(self.item()['ausencia_comprovada'])
        self.assertFalse(self.item()['start_invocado'])
        self.assertTrue(self.item()['termino_confirmado'])

    def test_04_start_normal_partida_resolvida(self):
        self.iniciar()
        self.assertEqual(1, self.threads[0].starts)
        self.assertTrue(self.item()['start_invocado'])
        self.assertTrue(self.item()['partida_resolvida'])
        self.assertFalse(self.item()['entrada'])

    def test_05_start_ambiguo_sem_entrada_nao_prova_ausencia(self):
        original = RuntimeError('start_simulado')
        def fabricar(**kwargs):
            thread = self.fabricar(**kwargs)
            thread.start = Mock(side_effect=original)
            return thread
        self.fabrica = fabricar
        with self.assertRaises(RuntimeError) as recebido:
            self.iniciar()
        self.assertIs(original, recebido.exception)
        self.assertTrue(self.item()['partida_ambigua'])
        self.assertFalse(self.item()['ausencia_comprovada'])
        self.assertFalse(self.observar())
        self.threads[0].is_alive.assert_not_called()

    def test_06_A_entrada_antes_start_retornar(self):
        vistos = []
        def alvo():
            vistos.append(self.item())
            self.assertFalse(self.observar())
        self.leitor._manter_atualizado = alvo
        def fabricar(**kwargs):
            thread = self.fabricar(**kwargs)
            thread.start = thread.target
            return thread
        self.fabrica = fabricar
        self.iniciar()
        self.assertTrue(vistos[0]['entrada'])
        self.assertTrue(vistos[0]['partida_em_curso'])
        self.assertFalse(vistos[0]['partida_resolvida'])
        self.assertTrue(self.item()['retorno'])
        self.assertTrue(self.item()['partida_resolvida'])

    def test_07_retorno_normal_publicado(self):
        self.alvo.return_value = 'retorno_simulado'
        self.iniciar()
        self.assertEqual('retorno_simulado', self.threads[0].target())
        self.assertTrue(self.item()['entrada'] and self.item()['retorno'])
        self.assertEqual('retorno', self.item()['resultado_alvo'])
        self.assertFalse(self.item()['thread_terminada'])

    def test_08_erro_alvo_preserva_instancia_traceback(self):
        original = ValueError('original_simulado')
        def falhar():
            raise original
        self.leitor._manter_atualizado = falhar
        self.iniciar()
        try:
            self.threads[0].target()
        except ValueError as recebido:
            self.assertIs(original, recebido)
            self.assertIn('falhar', [f.name for f in traceback.extract_tb(recebido.__traceback__)])
        else:
            self.fail('erro do alvo ausente')
        self.assertEqual('falha', self.item()['resultado_alvo'])
        self.assertEqual({'categoria': 'falha_operacao'}, self.item()['erro_operacional'])
        self.assertTrue(self.observar())  # término físico não significa sucesso funcional.

    def test_09_publicacao_saida_apos_publicar_invalida_prova(self):
        self.iniciar()
        publicar = self.registro._publicar_saida
        def falhar(*args):
            publicar(*args)
            raise OSError('publicacao_simulada')
        with patch.object(self.registro, '_publicar_saida', side_effect=falhar):
            with self.assertRaises(OSError):
                self.threads[0].target()
        self.assertFalse(self.item()['retorno'])
        self.assertTrue(self.item()['erro_publicacao'])
        self.assertFalse(self.observar())

    def test_10_alvo_retornou_thread_viva(self):
        self.iniciar()
        self.threads[0].target()
        self.threads[0].is_alive.return_value = True
        self.assertFalse(self.observar())
        self.assertFalse(self.item()['termino_confirmado'])

    def test_11_parar_nao_publica_termino(self):
        self.iniciar()
        self.threads[0].target()
        self.threads[0].is_alive.return_value = True
        antes = self.atividades()
        self.leitor.parar()
        self.assertEqual(antes, self.atividades())
        self.assertFalse(self.observar())

    def test_12_termino_explicito(self):
        self.iniciar()
        self.threads[0].target()
        self.assertFalse(self.item()['termino_confirmado'])
        self.assertTrue(self.observar())
        self.assertTrue(self.item()['thread_terminada'])
        self.assertTrue(self.item()['termino_confirmado'])

    def test_13_reconexao_mesma_atividade(self):
        self.leitor._manter_atualizado = self.alvo_real
        self.leitor.ip_servidor = 'simulado'
        config, reg_a, sub_a, reg_b, sub_b = [SocketLeituraFalso() for _ in range(5)]
        config.arquivo.readline = Mock(return_value='{}')
        for reg in (reg_a, reg_b):
            reg.arquivo.readline = Mock(return_value=json.dumps({'nome': self.leitor.nome_computador, 'posicao': 1}))
        vistos = []
        def receber(final):
            vistos.append(self.item())
            if final:
                self.leitor.parar()
            return ''
        sub_a.arquivo.readline = Mock(side_effect=lambda: receber(False))
        sub_b.arquivo.readline = Mock(side_effect=lambda: receber(True))
        def candidatura():
            self.leitor.ip_servidor = 'simulado'
            return False
        self.iniciar()
        with patch.object(self.leitor, '_aguardar_candidatura', side_effect=candidatura), \
                conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config, reg_a, reg_b]), \
                patch('rede.lerdadosserver.socket.socket', side_effect=[sub_a, sub_b]), patch('builtins.print'):
            self.threads[0].target()
        self.assertEqual(1, len(self.atividades()))
        self.assertEqual({self.item()['atividade_id']}, {r['atividade_id'] for r in vistos})
        self.assertTrue(all(r['execucao_em_curso'] for r in vistos))
        self.assertEqual(10, len(self.negativo()['recursos']))
        self.assertEqual([], self.guarda.obter_retrato()['retentativas'])

    def test_14_promocao_real_preserva_atividade(self):
        with self.permanente_bloqueada() as thread:
            antes = self.item()
            self.promover_real()
            self.assertTrue(thread.is_alive())
            self.assertEqual(antes['atividade_id'], self.item()['atividade_id'])
            self.assertEqual(antes['geracao_id'], self.item()['geracao_id'])
            self.assertTrue(self.item()['execucao_em_curso'])
            self.assertFalse(self.item()['termino_confirmado'])

    def test_15_nova_geracao_independente(self):
        self.iniciar()
        outro = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        outro._manter_atualizado = Mock()
        self.iniciar(outro)
        a, b = self.atividades()
        self.assertNotEqual(a['atividade_id'], b['atividade_id'])
        self.assertNotEqual(a['geracao_id'], b['geracao_id'])

    def test_16_global_permanece_negativo(self):
        self.iniciar()
        self.threads[0].target()
        self.assertTrue(self.observar())
        self.negativo()
        self.assertFalse(self.infra.obter_atividades_permanentes()['encerramento_global_confirmado'])

    def test_17_B_start_entra_e_depois_lanca(self):
        original = RuntimeError('start_apos_entrada_simulado')
        def fabricar(**kwargs):
            thread = self.fabricar(**kwargs)
            def start():
                thread.target()
                raise original
            thread.start = start
            return thread
        self.fabrica = fabricar
        with self.assertRaises(RuntimeError) as recebido:
            self.iniciar()
        self.assertIs(original, recebido.exception)
        self.assertTrue(self.item()['entrada'] and self.item()['retorno'])
        self.assertTrue(self.item()['partida_ambigua'])
        self.assertFalse(self.item()['ausencia_comprovada'])
        self.assertTrue(self.observar())

    def test_18_C_parada_com_corpo_ainda_ativo(self):
        with self.permanente_bloqueada() as thread:
            self.leitor.parar()
            self.assertTrue(thread.is_alive())
            self.assertTrue(self.item()['execucao_em_curso'])
            self.assertFalse(self.observar())
        self.assertFalse(self.item()['termino_confirmado'])
        self.assertTrue(self.observar())

    def test_19_D_REGISTER_apos_parar_atividade_em_curso(self):
        self.leitor._manter_atualizado = self.alvo_real
        self.leitor.ip_servidor = 'simulado'
        config, registro = SocketLeituraFalso(), SocketLeituraFalso()
        config.arquivo.readline = Mock(return_value='{}')
        registro.arquivo.readline = Mock(return_value=json.dumps({'nome': self.leitor.nome_computador, 'posicao': 1}))
        entrou, liberar = threading.Event(), threading.Event()
        chamadas, vistos, erros = [], [], []
        def conectar(dono, *args, **kwargs):
            if chamadas:
                entrou.set()
                if not liberar.wait(3):
                    raise TimeoutError('barreira_simulada')
            objeto = registro if chamadas else config
            chamadas.append(True)
            return dono.abrir_socket(lambda: objeto)
        registro.sendall.side_effect = lambda *a: vistos.append((self.leitor.executando, self.item()))
        def fabrica(target, daemon):
            def executar():
                try:
                    target()
                except BaseException as erro:
                    erros.append(erro)
            return THREAD_REAL(target=executar, daemon=daemon)
        with conectores_tcp_controlados(self.leitor.recursos_cliente, conectar), \
                patch('rede.lerdadosserver.threading', SimpleNamespace(Thread=fabrica)), patch('builtins.print'):
            self.leitor.iniciar()
            try:
                self.assertTrue(entrou.wait(3))
                self.assertTrue(self.leitor._admissao_register.obter_retrato()['operacoes'][0]['execucao_em_curso'])
                self.leitor.parar()
                self.assertTrue(self.item()['execucao_em_curso'])
                self.assertFalse(self.observar())
            finally:
                liberar.set()
                self.leitor.thread.join(3)
        self.assertFalse(self.leitor.thread.is_alive())
        self.assertEqual([], erros)
        self.assertFalse(vistos[0][0])
        self.assertTrue(vistos[0][1]['execucao_em_curso'])
        self.assertFalse(vistos[0][1]['termino_confirmado'])
        self.assertFalse(self.infra.registro_recursos.obter_retrato()['admissao_fechada'])
        self.assertTrue(self.observar())

    def test_20_E_promocao_A_viva_e_B_resolvida(self):
        with self.permanente_bloqueada():
            self.promover_real()
            outro = LeitorDadosServidor(infraestrutura_cliente=self.infra)
            outro._manter_atualizado = Mock()
            self.iniciar(outro)
            self.threads[-1].target()
            observacoes = self.infra.observar_termino_leitores()
            self.assertFalse(observacoes[0]['termino_observado'])
            self.assertTrue(observacoes[1]['termino_observado'])
            a, b = self.atividades()
            self.assertNotEqual(a['geracao_id'], b['geracao_id'])
            self.assertFalse(a['termino_confirmado'])
            self.assertTrue(b['termino_confirmado'])

    def test_21_F_retorno_contra_observacao(self):
        vistos = []
        self.leitor._manter_atualizado = lambda: vistos.append(self.observar())
        self.iniciar()
        self.threads[0].is_alive.return_value = True
        self.threads[0].target()
        self.assertEqual([False], vistos)
        self.assertFalse(self.observar())
        self.threads[0].is_alive.return_value = False
        self.assertFalse(self.item()['termino_confirmado'])
        self.negativo()
        self.assertFalse(self.item()['termino_confirmado'])
        self.assertTrue(self.observar())

    def test_22_adicional_thread_terminada_SUBSCRIBE_pendente(self):
        cliente, arquivo, _ = self.par_leitor()
        self.addCleanup(cliente.close)
        self.addCleanup(arquivo.close)
        self.iniciar()
        self.threads[0].target()
        self.assertTrue(self.observar())
        self.assertTrue(self.item()['termino_confirmado'])
        self.assertIn(cliente.recurso_id.numero, self.negativo()['recursos_pendentes'])

    def test_23_consultas_passivas_nao_observam(self):
        self.iniciar()
        self.threads[0].target()
        antes = self.atividades()
        self.negativo()
        self.assertEqual(antes, self.atividades())
        self.threads[0].is_alive.assert_not_called()

    def test_24_erro_primario_e_publicacao_saida_falham(self):
        original, secundario = ValueError('primario_simulado'), OSError('publicacao_simulada')
        self.alvo.side_effect = original
        self.iniciar()
        with patch.object(self.registro, '_publicar_saida', side_effect=secundario):
            with self.assertRaises(ValueError) as recebido:
                self.threads[0].target()
        self.assertIs(original, recebido.exception)
        self.assertIs(secundario, original.__cause__)
        self.assertEqual({'categoria': 'falha_operacao'}, self.item()['erro_operacional'])
        self.assertFalse(self.item()['retorno'])
        self.assertFalse(self.observar())

    def test_25_publicacao_partida_apos_publicar_falha(self):
        publicar = self.registro._publicar_partida
        def falhar(*args):
            publicar(*args)
            raise RuntimeError('publicacao_simulada')
        with patch.object(self.registro, '_publicar_partida', side_effect=falhar):
            with self.assertRaises(RuntimeError):
                self.iniciar()
        self.threads[0].target()
        self.assertFalse(self.item()['partida_resolvida'])
        self.assertTrue(self.item()['erro_publicacao'])
        self.assertFalse(self.observar())

    def test_26_falha_antes_de_construir_prova_nao_partida(self):
        original = RuntimeError('antes_construcao_simulado')
        with patch.object(self.registro, 'partir', side_effect=original):
            with self.assertRaises(RuntimeError) as recebido:
                self.iniciar()
        self.assertIs(original, recebido.exception)
        self.assertEqual([], self.threads)
        self.assertTrue(self.item()['ausencia_comprovada'])

    def test_27_fabrica_start_is_alive_fora_do_lock(self):
        def sem_lock():
            self.assertTrue(self.registro._lock.acquire(blocking=False))
            self.registro._lock.release()
            self.registro.obter_retrato()
        def fabricar(**kwargs):
            sem_lock()
            thread = self.fabricar(**kwargs)
            thread.start = Mock(side_effect=sem_lock)
            thread.is_alive.side_effect = lambda: (sem_lock(), False)[-1]
            return thread
        self.fabrica = fabricar
        self.iniciar()
        self.threads[0].target()
        self.assertTrue(self.observar())

    def test_28_entrada_tardia_depois_start_ambiguo(self):
        def fabricar(**kwargs):
            thread = self.fabricar(**kwargs)
            thread.start = Mock(side_effect=RuntimeError('start_simulado'))
            return thread
        self.fabrica = fabricar
        with self.assertRaises(RuntimeError):
            self.iniciar()
        self.assertFalse(self.observar())
        self.threads[0].target()
        self.assertTrue(self.observar())
        self.assertTrue(self.item()['partida_ambigua'])

    def test_29_reinicio_retem_thread_antiga(self):
        self.iniciar()
        antiga = self.leitor.thread
        antiga.is_alive.return_value = True
        self.leitor.parar()
        self.iniciar()
        self.assertIsNot(antiga, self.leitor.thread)
        antiga.target()
        self.threads[-1].target()
        a, b = self.infra.observar_termino_leitores()
        self.assertFalse(a['termino_observado'])
        self.assertTrue(b['termino_observado'])
        self.assertEqual(1, antiga.is_alive.call_count)
        self.assertEqual(2, len(self.atividades()))

    def test_30_origem_e_token_estrangeiros_recusados(self):
        outra = InfraestruturaRegistrosCliente()
        estrangeiro = LeitorDadosServidor(infraestrutura_cliente=outra)
        with self.assertRaises(ValueError):
            self.registro.preparar_leitor(estrangeiro.recursos_cliente)
        with self.assertRaises(ValueError):
            self.registro.reservar(estrangeiro._origem_atividade_permanente)
        self.iniciar(estrangeiro)
        token = next(iter(outra.registro_atividades_permanentes._atividades))
        with self.assertRaises(ValueError):
            self.registro.observar_termino(token)

    def test_31_referencia_mutada_nao_migra_dono(self):
        outra = InfraestruturaRegistrosCliente()
        self.leitor.infraestrutura_cliente = outra
        self.iniciar()
        self.assertEqual(1, len(self.atividades()))
        self.assertEqual([], outra.obter_atividades_permanentes()['atividades'])

    def test_32_observacao_invalida_fica_conservadora(self):
        self.iniciar()
        self.threads[0].target()
        self.threads[0].is_alive.return_value = None
        self.assertFalse(self.observar())
        self.threads[0].is_alive.return_value = False
        self.assertFalse(self.observar())
        self.assertTrue(self.item()['erro_observacao'])
        self.assertFalse(self.item()['termino_confirmado'])

    def test_33_gate_fecha_apos_reserva_antes_fabrica(self):
        reservar = self.registro.reservar
        def fechar(origem):
            identidade = reservar(origem)
            self.registro.fechar_admissao()
            return identidade
        with patch.object(self.registro, 'reservar', side_effect=fechar):
            self.iniciar()
        self.assertEqual([], self.threads)
        self.assertFalse(self.leitor.executando)
        self.assertTrue(self.item()['ausencia_comprovada'])

    def test_34_dupla_entrada_invalida_confirmacao(self):
        self.iniciar()
        self.threads[0].target()
        self.assertTrue(self.observar())
        self.threads[0].target()
        self.assertTrue(self.item()['erro_publicacao'])
        self.assertFalse(self.item()['termino_confirmado'])
        self.alvo.assert_called_once_with()

    def test_35_retratos_nao_expoem_excecoes_ou_alias(self):
        self.alvo.side_effect = OSError('texto_privado_simulado')
        self.iniciar()
        with self.assertRaises(OSError):
            self.threads[0].target()
        item = self.item()
        self.assertNotIn('texto_privado_simulado', str(item))
        item['erro_operacional']['categoria'] = 'alteracao_simulada'
        self.assertEqual('falha_io', self.item()['erro_operacional']['categoria'])

    def test_36_BaseException_no_alvo(self):
        original = KeyboardInterrupt('simulado')
        self.alvo.side_effect = original
        self.iniciar()
        with self.assertRaises(KeyboardInterrupt) as recebido:
            self.threads[0].target()
        self.assertIs(original, recebido.exception)
        self.assertEqual('falha_base', self.item()['erro_operacional']['categoria'])

    def test_37_mesma_geracao_ids_distintos(self):
        self.iniciar()
        self.threads[0].target()
        self.leitor.parar()
        self.iniciar()
        a, b = self.atividades()
        self.assertEqual(a['geracao_id'], b['geracao_id'])
        self.assertNotEqual(a['atividade_id'], b['atividade_id'])

    def test_38_legado_sem_infraestrutura_preservado(self):
        leitor = LeitorDadosServidor()
        with patch('rede.lerdadosserver.threading.Thread', side_effect=self.fabricar):
            self.assertIsNone(leitor.iniciar())
        self.assertEqual(leitor._manter_atualizado, self.threads[0].target)
        self.assertEqual([], self.atividades())
        leitor.parar()

    def test_39_erro_start_e_publicacao_preserva_primario(self):
        original, publicacao = OSError('start_simulado'), RuntimeError('publicacao_simulada')
        def fabricar(**kwargs):
            thread = self.fabricar(**kwargs)
            thread.start = Mock(side_effect=original)
            return thread
        self.fabrica = fabricar
        with patch.object(self.registro, '_publicar_partida', side_effect=publicacao):
            with self.assertRaises(OSError) as recebido:
                self.iniciar()
        self.assertIs(original, recebido.exception)
        self.assertIs(publicacao, original.__cause__)
        self.assertFalse(self.item()['partida_resolvida'])
        self.assertFalse(self.item()['termino_confirmado'])

    def test_40_saida_concorrente_observacao_nao_antecipa(self):
        with self.permanente_bloqueada():
            self.assertFalse(self.observar())
            self.assertTrue(self.item()['entrada'])
            self.assertFalse(self.item()['retorno'])
        self.assertTrue(self.item()['retorno'])
        self.assertFalse(self.item()['thread_terminada'])
        self.assertFalse(self.item()['termino_confirmado'])
        self.assertTrue(self.observar())

# Testes de auditoria cobertura cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Auditoria somente de leitura: inventário estático e execução com recursos falsos.

O inventário revisado detecta criadores explícitos conhecidos, não certifica
exaustividade de bibliotecas, aliases ou alocações internas do sistema.
"""
import ast
import gc
import json
from pathlib import Path
import socket
import threading
import unittest
from unittest.mock import Mock, patch
import weakref

from rede import buscarservidor, servidor
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
from tc420.conexao import ConexaoTC420
from tc420.web import WebTC420
import test_infraestrutura_cliente as fixtures_main
from test_descoberta_cliente_integrada import SocketDescobertaFalso
from test_recursos_cliente_integrados import SocketLeituraFalso
from apoio_conexoes_cliente import conexoes_tcp_simuladas


RAIZ = Path(__file__).resolve().parents[1]
# Chave: arquivo, função qualificada, chamada explícita. Classificação refere-se
# ao acompanhamento CLIENTE; delegados não são contados como segunda alocação.
REVISADOS = {
    ("rede/admissao_config_cliente.py", "RecursosConfigCliente.conectar_tcp", "socket.socket"): "condicional",
    ("rede/admissao_config_cliente.py", "RecursosTentativaConfig.ler_configuracao", "makefile"): "condicional",
    ("rede/buscarservidor.py", "confirmar_servidor", "socket.socket"): "condicional",
    ("rede/buscarservidor.py", "buscar_servidor", "socket.socket"): "condicional",
    ("rede/lerdadosserver.py", "LeitorDadosServidor._manter_atualizado", "socket.socket"): "condicional",
    ("rede/lerdadosserver.py", "LeitorDadosServidor._manter_atualizado", "socket.create_connection"): "condicional",
    ("rede/lerdadosserver.py", "LeitorDadosServidor._manter_atualizado", "makefile"): "condicional",
    ("rede/infraestrutura_cliente.py", "RecursosLeitorCliente.ler_configuracao.comunicar", "makefile"): "delegado",
    ("rede/infraestrutura_cliente.py", "RecursosLeitorCliente.registrar_cliente.comunicar", "makefile"): "delegado",
    ("rede/infraestrutura_cliente.py", "SocketClienteRegistrado.makefile", "makefile"): "instrumentado",
    ("rede/infraestrutura_cliente.py", "RecursosLeitorCliente.conectar_tcp", "socket.socket"): "instrumentado",
    ("rede/servidor.py", "_criar_socket_do_ciclo", "socket.socket"): "principal",
    ("rede/servidor.py", "servidor_tcp", "accept"): "principal",
    ("tc420/conexao.py", "ConexaoTC420.conectar", "socket.socket"): "fora_do_leitor",
    ("rede/tcp_local.py", "LeitorTCPLocal._executar", "socket.socket"): "fora_do_leitor",
    ("tc420/web.py", "WebTC420.login", "requests.post"): "lacuna",
    ("tc420/web.py", "WebTC420.approval", "requests.get"): "lacuna",
    ("tc420/web.py", "WebTC420.refresh", "requests.get"): "principal_http",
    ("config/configuracao.py", "salvar_configuracao", "open"): "lacuna",
    ("config/configuracao.py", "carregar_configuracao", "open"): "lacuna",
    ("interface/janela.py", "JanelaTC420.__init__", "PhotoImage"): "recurso_tk",
    ("interface/formularios.py", "montar_formulario", "PhotoImage"): "recurso_tk",
    ("tc420.py", "<modulo>", "socket.socket"): "entrada_independente",
}


def criadores(arvore, arquivo):
    encontrados = set()
    class Visitante(ast.NodeVisitor):
        def __init__(self):
            self.escopo = []

        def bloco(self, node):
            self.escopo.append(node.name)
            self.generic_visit(node)
            self.escopo.pop()

        visit_ClassDef = bloco
        visit_FunctionDef = bloco
        visit_AsyncFunctionDef = bloco

        def visit_Call(self, node):
            nome = ast.unparse(node.func)
            if nome in ("socket.socket", "socket.create_connection", "requests.post", "requests.get", "open"):
                tipo = nome
            elif isinstance(node.func, ast.Attribute) and node.func.attr in ("makefile", "accept", "PhotoImage"):
                tipo = node.func.attr
            else:
                tipo = None
            if tipo:
                encontrados.add((arquivo, ".".join(self.escopo) or "<modulo>", tipo))
            self.generic_visit(node)
    Visitante().visit(arvore)
    return encontrados


def inventario():
    encontrados = set()
    caminhos = [RAIZ / "main.py", RAIZ / "tc420.py"]
    for pasta in ("rede", "interface", "tc420", "config"):
        caminhos.extend((RAIZ / pasta).glob("*.py"))
    for caminho in caminhos:
        encontrados.update(criadores(ast.parse(caminho.read_text(encoding="utf-8")),
                                     caminho.relative_to(RAIZ).as_posix()))
    return encontrados


def conclusao_estatica(encontrados):
    # Exclusivo deste ensaio. Nunca altera certificados ou cobertura operacional.
    if encontrados - REVISADOS.keys():
        return "indeterminada"
    if any(REVISADOS[chave] == "lacuna" for chave in encontrados):
        return "parcial"
    return "sem_lacuna_explicita_no_recorte"


# Grupo de 25 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AuditoriaCoberturaCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.dono = RecursosLeitorCliente(self.infra)
        self.reg = self.infra.registro_recursos

    def recursos(self):
        return self.reg.obter_retrato()["recursos"]

    def socket(self, dono=None):
        objeto = SocketLeituraFalso()
        return (dono or self.dono).abrir_socket(lambda: objeto), objeto

    def global_negativo(self):
        resultado = self.infra.avaliar()
        self.assertFalse(resultado["cobertura_completa"])
        self.assertFalse(resultado["encerramento_confirmado"])

    def fechar_gates(self):
        self.reg.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()

    def test_01_quatro_caminhos_e_inventario_revisado(self):
        encontrados = inventario()
        self.assertEqual(set(REVISADOS), encontrados)
        self.assertEqual("parcial", conclusao_estatica(encontrados))
        config, registro = SocketLeituraFalso(), SocketLeituraFalso()
        config.arquivo.readline = Mock(return_value='{}')
        registro.arquivo.readline = Mock(return_value='{}')
        self.dono.ler_configuracao(lambda: config, json.loads)
        self.dono.registrar_cliente(lambda: registro, "cliente-simulado", json.loads)
        sub, _ = self.socket()
        arquivo = sub.makefile("r", encoding="utf-8")
        sub.close()
        arquivo.close()
        udp, tcp = SocketDescobertaFalso(), SocketDescobertaFalso()
        udp.recvfrom.side_effect = [(b"TC420_SERVER_HERE", ("principal-simulado", 42101))]
        with patch.object(buscarservidor.socket, "socket", side_effect=[udp, tcp]):
            self.assertEqual("principal-simulado", buscarservidor.buscar_servidor(recursos_cliente=self.dono))
        self.assertEqual(8, len({r["recurso_id"] for r in self.recursos()}))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_02_recurso_adicional_http_sem_registro(self):
        web = WebTC420("balanca-simulada")
        web.token = object()  # Marcador de estado, sem credencial real.
        resposta = Mock(text="SUCCESS:APPROVAL:simulado")
        with patch("tc420.web.requests.get", return_value=resposta) as enviar:
            self.assertEqual("simulado", web.approval())
        enviar.assert_called_once()
        self.assertEqual([], self.recursos())
        self.assertEqual("lacuna", REVISADOS[("tc420/web.py", "WebTC420.approval", "requests.get")])
        self.global_negativo()

    def test_03_criacao_socket_direto_sem_reserva(self):
        objeto = SocketLeituraFalso()
        conexao = ConexaoTC420(ip="balanca-simulada")
        with patch("tc420.conexao.socket.socket", return_value=objeto):
            conexao.conectar()
        self.assertIs(objeto, conexao.socket)
        self.assertEqual([], self.recursos())
        self.global_negativo()
        conexao.desconectar()

    def test_04_reserva_sem_publicacao_nao_comprova_cobertura(self):
        token = self.reg.reservar("socket_tcp", self.dono.geracao_id, self.dono.atividade_id)
        self.fechar_gates()
        self.assertFalse(self.recursos()[0]["publicado"])
        self.assertFalse(self.recursos()[0]["criacao_resolvida"])
        self.assertEqual(token.numero, self.recursos()[0]["recurso_id"])
        self.global_negativo()

    def test_05_close_bruto_sem_evidencia_nao_resolve(self):
        cliente, objeto = self.socket()
        objeto.close()
        self.fechar_gates()
        self.assertTrue(objeto.fechado)
        self.assertFalse(self.recursos()[0]["prova_fechamento"])
        self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])
        self.global_negativo()
        cliente.close()

    def test_06_falha_limpeza_preservada_apos_nova_tentativa(self):
        cliente, objeto = self.socket()
        objeto.erro_close = OSError()
        with self.assertRaises(OSError):
            cliente.close()
        erros = self.recursos()[0]["erros_limpeza"]
        objeto.erro_close = None
        cliente.close()
        self.fechar_gates()
        self.assertEqual(erros, self.recursos()[0]["erros_limpeza"])
        self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])

    def test_07_makefile_responsabilidade_independente(self):
        cliente, _ = self.socket()
        arquivo = cliente.makefile("r", encoding="utf-8")
        cliente.close()
        self.fechar_gates()
        pai, filho = self.recursos()
        self.assertEqual(pai["recurso_id"], filho["associado_a"])
        self.assertTrue(pai["encerramento_confirmado"])
        self.assertFalse(filho["encerramento_confirmado"])
        arquivo.close()
        self.assertTrue(self.reg.obter_retrato()["encerramento_confirmado"])

    def test_08_reconexao_real_novo_socket_mesma_geracao(self):
        leitor, config, registros, subs = self.preparar_loop(duas_conexoes=True)
        def recuperar():
            leitor.ip_servidor = "principal-simulado"
            return False
        leitor._aguardar_candidatura = Mock(side_effect=recuperar)
        leitor._parada.wait = Mock(return_value=False)
        subs[0].arquivo.readline = Mock(return_value='')
        subs[1].arquivo.readline = Mock(side_effect=lambda: (setattr(leitor, "executando", False), '')[-1])
        with conexoes_tcp_simuladas(leitor.recursos_cliente, [config, *registros]), \
                patch("rede.lerdadosserver.socket.socket", side_effect=subs), patch("builtins.print"):
            leitor._manter_atualizado()
        linhas = self.recursos()
        self.assertEqual(10, len({r["recurso_id"] for r in linhas}))
        self.assertEqual({leitor.recursos_cliente.geracao_id}, {r["geracao_id"] for r in linhas})
        self.assertTrue(all(r["encerramento_confirmado"] for r in linhas))

    def test_09_geracao_antiga_na_consulta_global(self):
        antigo, _ = self.socket()
        novo, _ = self.socket(RecursosLeitorCliente(self.infra))
        novo.close()
        self.fechar_gates()
        with patch.object(self.reg, "obter_retrato", wraps=self.reg.obter_retrato) as consultar:
            self.global_negativo()
        self.assertTrue(all(not chamada.kwargs for chamada in consultar.call_args_list))
        self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])
        antigo.close()

    def test_10_callback_real_promocao_preserva_proprietario(self):
        fixture = fixtures_main.InfraestruturaCliente()
        fixture.setUp()
        fixture.env["buscar_servidor"].side_effect = ["principal-simulado", None, None]
        observados = []
        def promover(monitor):
            infra = monitor.infraestrutura_cliente
            dono = fixture.leitores[0].recursos_cliente
            cliente = dono.abrir_socket(SocketLeituraFalso)
            resultado = monitor.ao_promover_automaticamente()
            self.assertIsNotNone(resultado)
            self.assertIs(infra, fixture.leitores[0].infraestrutura_cliente)
            self.assertIs(dono.registro, infra.registro_recursos)
            recurso = infra.registro_recursos.obter_retrato()["recursos"][0]
            self.assertFalse(recurso["encerramento_confirmado"])
            self.assertEqual(dono.geracao_id, recurso["geracao_id"])
            self.assertEqual("cliente", recurso["modo_atual"])  # Callback ainda não publica promover no registro.
            observados.append(infra)
            cliente.close()
        fixture.durante_monitor = promover
        fixture.env["iniciar"]()
        self.assertEqual(1, len(observados))

    def test_11_cliente_principal_sem_dupla_atribuicao(self):
        cliente, _ = self.socket()
        principal = servidor.RegistroTrabalhadores()
        objeto = SocketLeituraFalso()
        objeto.fileno = lambda: -1 if objeto.fechado else 10
        token = principal.reservar_criacao_socket()
        principal.anexar_socket(token, objeto)
        principal.publicar_socket(token)
        self.assertEqual(1, len(self.recursos()))
        cliente.close()
        self.assertFalse(objeto.fechado)
        principal.encerrar_uso_socket(token)
        self.assertTrue(principal.fechar_socket(token))
        self.assertEqual(1, len(self.recursos()))

    def test_12_fabrica_opaca_desconhecida(self):
        with self.assertRaises(OSError):
            self.dono.abrir_socket(Mock(side_effect=OSError()))
        self.fechar_gates()
        self.assertEqual("desconhecido", self.recursos()[0]["estado"])
        self.assertFalse(self.recursos()[0]["ausencia_comprovada"])
        self.global_negativo()

    def test_13_limpeza_recursos_nao_comprova_atividades(self):
        cliente, _ = self.socket()
        cliente.close()
        self.fechar_gates()
        self.assertTrue(self.reg.obter_retrato()["encerramento_confirmado"])
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()["retentativas"])
        self.global_negativo()

    def test_14_thread_real_leitor_sem_admissao_de_atividade(self):
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente-simulado"):
            leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        thread = Mock()
        with patch("rede.lerdadosserver.threading.Thread", return_value=thread):
            leitor.iniciar()
        thread.start.assert_called_once_with()
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()["retentativas"])
        self.global_negativo()
        leitor.parar()

    def test_15_consulta_concorrente_close_em_curso(self):
        cliente, objeto = self.socket()
        entrou, liberar = threading.Event(), threading.Event()
        erros = []
        close = objeto.close
        def fechar():
            entrou.set()
            if not liberar.wait(3):
                raise AssertionError("barreira_nao_liberada")
            close()
        objeto.close = fechar
        def tarefa():
            try:
                cliente.close()
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            self.fechar_gates()
            self.assertTrue(self.recursos()[0]["limpeza_em_curso"])
            self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])
            self.global_negativo()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_16_compatibilidade_legado_sem_injecao(self):
        udp = SocketDescobertaFalso()
        with patch.object(buscarservidor.socket, "socket", return_value=udp):
            self.assertIsNone(buscarservidor.buscar_servidor())
        self.assertTrue(udp.fechado)
        self.assertEqual([], self.recursos())
        self.global_negativo()

    def test_critico_A_criador_auxiliar_fora_da_matriz(self):
        caminho = "rede/buscarservidor.py"
        fonte = (RAIZ / caminho).read_text(encoding="utf-8")
        arvore = ast.parse(fonte + '\ndef auxiliar_oculta():\n    return socket.socket(socket.AF_INET, socket.SOCK_STREAM)\n')
        encontrados = inventario() | criadores(arvore, caminho)
        self.assertEqual({(caminho, "auxiliar_oculta", "socket.socket")}, encontrados - REVISADOS.keys())
        self.assertEqual("indeterminada", conclusao_estatica(encontrados))
        self.global_negativo()

    def test_critico_B_publicacao_parcial_nao_apaga_responsabilidade(self):
        objeto = SocketLeituraFalso()
        criar = self.reg.criar
        def falhar(token, fabrica):
            return criar(token, fabrica, preparar=Mock(side_effect=ValueError()))
        with patch.object(self.reg, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.dono.abrir_socket(lambda: objeto)
        recurso = self.recursos()[0]
        self.assertFalse(recurso["publicado"])
        self.assertTrue(recurso["criacao_resolvida"])
        self.assertTrue(recurso["erros_criacao"])
        self.assertTrue(objeto.fechado)
        self.global_negativo()

    def test_critico_C_promocao_antiga_pendente_nova_limpa(self):
        antigo, _ = self.socket()
        arquivo = antigo.makefile("r", encoding="utf-8")
        antigo.close()
        self.reg.promover(self.dono.geracao_id)
        nova = RecursosLeitorCliente(self.infra)
        novo, _ = self.socket(nova)
        novo.close()
        self.fechar_gates()
        self.assertTrue(self.reg.obter_retrato(geracao_id=nova.geracao_id)["encerramento_confirmado"])
        self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])
        self.assertEqual("principal", self.recursos()[0]["modo_atual"])
        self.global_negativo()
        arquivo.close()

    def test_critico_D_sockets_limpos_retentativa_sem_termino_comprovado(self):
        cliente, _ = self.socket()
        arquivo = cliente.makefile("r", encoding="utf-8")
        cliente.close()
        arquivo.close()
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente-simulado"):
            leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        leitor.estado_candidatura = "liberada"
        leitor.tentativa_recuperacao = 1
        with patch("rede.lerdadosserver.threading.Thread", return_value=Mock()) as criar:
            self.assertTrue(leitor.registrar_falha_recuperacao())
        self.assertTrue(callable(criar.call_args.kwargs["target"]))
        tentativa, = self.infra.registro_retentativas.obter_retrato()["retentativas"]
        self.assertTrue(tentativa["start_invocado"])
        self.assertFalse(tentativa["thread_terminada"])
        self.fechar_gates()
        self.assertTrue(self.reg.obter_retrato()["encerramento_confirmado"])
        self.global_negativo()

    def preparar_loop(self, duas_conexoes=False):
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente-simulado"):
            leitor = LeitorDadosServidor("principal-simulado", infraestrutura_cliente=self.infra)
        leitor.executando = True
        config = SocketLeituraFalso()
        config.arquivo.readline = Mock(return_value='{}')
        registros, subs = [], []
        for _ in range(2 if duas_conexoes else 1):
            registro = SocketLeituraFalso()
            registro.arquivo.readline = Mock(return_value='{"nome":"cliente-simulado","posicao":1}')
            registros.append(registro)
            subs.append(SocketLeituraFalso())
        return leitor, config, registros, subs

    def test_lacuna_close_socket_nao_oserror_pula_arquivo(self):
        leitor, config, registros, subs = self.preparar_loop()
        sub = subs[0]
        sub.arquivo.readline = Mock(side_effect=ValueError("corpo_simulado"))
        sub.erro_close = RuntimeError("close_simulado")
        leitor._aguardar_candidatura = Mock(side_effect=lambda: (leitor.parar(), False)[-1])
        with conexoes_tcp_simuladas(leitor.recursos_cliente, [config, *registros]), \
                patch("rede.lerdadosserver.socket.socket", return_value=sub), patch("builtins.print") as imprimir:
            leitor._manter_atualizado()
        imprimir.assert_any_call("Conexão com servidor perdida: corpo_simulado")
        self.assertTrue(sub.arquivo.closed)  # L2 corrigida: socket falho não omite arquivo.
        self.assertTrue(self.recursos()[-2]["erros_limpeza"])
        self.assertTrue(self.recursos()[-1]["prova_fechamento"])
        self.global_negativo()

    def test_lacuna_close_arquivo_subscribe_mascara_erro_corpo(self):
        leitor, config, registros, subs = self.preparar_loop()
        sub = subs[0]
        sub.arquivo.readline = Mock(side_effect=ValueError("corpo_simulado"))
        sub.arquivo.erro_close = OSError("arquivo_simulado")
        leitor._aguardar_candidatura = Mock(side_effect=lambda: (leitor.parar(), False)[-1])
        with conexoes_tcp_simuladas(leitor.recursos_cliente, [config, *registros]), \
                patch("rede.lerdadosserver.socket.socket", return_value=sub), patch("builtins.print") as imprimir:
            leitor._manter_atualizado()
        imprimir.assert_any_call("Conexão com servidor perdida: corpo_simulado")
        # A recepção agora ocorre no socket; o arquivo continua responsável
        # apenas por sua própria falha de fechamento.
        self.assertTrue(self.recursos()[-2]["erros_atendimento"])
        self.assertTrue(self.recursos()[-1]["erros_limpeza"])
        self.global_negativo()

    def test_lacuna_adaptador_leitor_incerto_nao_retido_pela_infra(self):
        # Diferente das preparações retidas, o adaptador de leitor só é retido
        # pelo leitor/chamadores. Falha externa antes de associar handle ao registro.
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente-simulado"):
            leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        def provocar(dono):
            objeto = SocketLeituraFalso()
            objeto.erro_close = OSError()
            referencia = weakref.ref(objeto)
            def falhar(token, alocar):
                alocar()
                raise ValueError()
            with patch.object(self.reg, "criar", side_effect=falhar):
                with self.assertRaises(ValueError):
                    dono.abrir_socket(lambda: objeto)
            return referencia
        referencia = provocar(leitor.recursos_cliente)
        gc.collect()
        self.assertIsNotNone(referencia())
        del leitor
        gc.collect()
        self.assertIsNone(referencia())
        self.assertEqual("desconhecido", self.recursos()[0]["estado"])
        self.global_negativo()

    def test_parse_subscribe_publica_erro_no_socket(self):
        leitor, config, registros, subs = self.preparar_loop()
        sub = subs[0]
        sub.arquivo.readline = Mock(return_value='{invalido\n')
        leitor._aguardar_candidatura = Mock(side_effect=lambda: (leitor.parar(), False)[-1])
        with conexoes_tcp_simuladas(leitor.recursos_cliente, [config, *registros]), \
                patch("rede.lerdadosserver.socket.socket", return_value=sub), patch("builtins.print"), \
                patch("rede.lerdadosserver.json.loads", wraps=json.loads) as decodificar:
            leitor._manter_atualizado()
        self.assertTrue(any('{invalido' in str(chamada.args[0])
                            for chamada in decodificar.call_args_list))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))
        tentativa = leitor.obter_tentativas_subscribe()["tentativas"][0]
        self.assertEqual({"categoria": "falha_operacao"}, tentativa["erro_operacao"])
        self.global_negativo()

    def test_lacuna_create_connection_tentativas_internas_sem_id(self):
        # Caso histórico de fábrica opaca ainda aceita pela API genérica.
        # O leitor instrumentado agora usa conectar_tcp; este ensaio conserva
        # a regressão do limite quando o chamador fornece a fábrica antiga.
        primeiro, segundo = SocketLeituraFalso(), SocketLeituraFalso()
        primeiro.connect.side_effect = ConnectionRefusedError()
        segundo.arquivo.readline = Mock(return_value='{}')
        enderecos = [(socket.AF_INET, socket.SOCK_STREAM, 0, '', ("principal-simulado", 42100))] * 2
        with patch.object(socket, "getaddrinfo", return_value=enderecos), \
                patch.object(socket, "socket", side_effect=[primeiro, segundo]) as alocar:
            resultado = self.dono.ler_configuracao(
                lambda: socket.create_connection(("principal-simulado", 42100), timeout=5), json.loads)
        self.assertEqual({}, resultado)
        self.assertEqual(2, alocar.call_count)
        self.assertTrue(primeiro.fechado)
        self.assertTrue(segundo.fechado)
        # Dois sockets físicos falsos, mas só o socket devolvido e seu arquivo
        # têm IDs; a tentativa interna recusada não tem evidência individual.
        self.assertEqual(["socket_tcp", "arquivo_socket"], [r["tipo"] for r in self.recursos()])
        self.global_negativo()


if __name__ == "__main__":
    unittest.main()

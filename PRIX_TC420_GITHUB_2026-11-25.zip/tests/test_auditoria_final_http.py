# Testes de auditoria final http: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.14: cadeia integrada e contraexemplos, sem alterar código operacional.

Ensaios de mutação aprovam ao reproduzir a lacuna; não significam correção.
"""
import ast
from contextvars import copy_context
from dataclasses import FrozenInstanceError, replace
import json
from pathlib import Path
import threading
from types import SimpleNamespace
from unittest.mock import Mock, patch
import unittest
from uuid import uuid4

import requests

from rede import infraestrutura_cliente as modulo, servidor
from rede.entradas_http import VinculoEntradasHttp, criar_validador_entrada
from tc420.web import WebTC420
from test_registro_automatico import carregar_fluxos
import test_approval_http_integrado as approval
import test_entradas_http_vinculadas as montagem


# Grupo de 29 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AuditoriaFinalHttp(unittest.TestCase):
    setUp = montagem.EntradasHttpVinculadas.setUp
    fluxo_http = montagem.EntradasHttpVinculadas.fluxo_http
    transporte = montagem.EntradasHttpVinculadas.transporte
    automatico = montagem.EntradasHttpVinculadas.automatico
    manual = montagem.EntradasHttpVinculadas.manual
    promocao = montagem.EntradasHttpVinculadas.promocao
    fixture_main = montagem.EntradasHttpVinculadas.fixture_main
    conferir_par = montagem.EntradasHttpVinculadas.conferir_par
    iniciar_thread = montagem.EntradasHttpVinculadas.iniciar_thread
    terminar = montagem.EntradasHttpVinculadas.terminar
    bloquear = montagem.EntradasHttpVinculadas.bloquear
    operacoes = montagem.EntradasHttpVinculadas.operacoes
    negativo = montagem.EntradasHttpVinculadas.negativo

    def cadeia_main(self, caminho):
        fx = self.fixture_main()
        webs, ancoras, envios = [], [], []
        def construir(ip, **kwargs):
            web = WebTC420(ip, **kwargs)
            webs.append(web)
            return web
        fx.env["WebTC420"].side_effect = construir
        if caminho == "manual":
            fx.env["tentar_login_automatico"] = Mock(return_value=False)
            def criar(**kwargs):
                ancora = kwargs["vinculo_http"]
                ancoras.append(ancora)
                ui, janela = self.manual(kwargs["infraestrutura_cliente"], vinculo_http=ancora)
                ui.env["WebTC420"].side_effect = construir
                janela.root.mainloop = janela.conectar
                return janela
            fx.env["JanelaConexao"] = criar
        elif caminho == "promocao":
            fx.preparar_promocao()
        validar = criar_validador_entrada
        def capturar(vinculo=False):
            if vinculo is not False:
                ancoras.append(vinculo)
            return validar(vinculo)
        with self.fluxo_http() as adaptador, \
                patch.object(modulo, "InfraestruturaRegistrosCliente", return_value=self.infra), \
                patch("rede.entradas_http.criar_validador_entrada", side_effect=capturar):
            enviar = adaptador.send
            def observar(pedido, **kwargs):
                op = self.operacoes()[-1]
                self.assertEqual("login" if pedido.method == "POST" else "approval", op["operacao"])
                self.assertTrue(op["inicio_confirmado"])
                self.assertEqual(1, op["execucoes_ativas"])
                self.assertFalse(op["execucao_resolvida"])
                envios.append(op["operacao_id"])
                return enviar(pedido, **kwargs)
            with patch.object(adaptador, "send", side_effect=observar):
                fx.env["iniciar"]()
        self.conferir_par(adaptador)
        self.assertEqual(2, len(set(envios)))
        self.assertTrue(ancoras)
        self.assertTrue(all(a.validar(self.infra) is self.infra for a in ancoras))
        self.assertEqual(1, len(webs))
        self.assertIs(self.infra, webs[0].politica_http.proprietario)
        with patch("requests.api.request") as enviar:
            with self.assertRaisesRegex(RuntimeError, "http_fora_do_executor"):
                webs[0].obter_configuracao()
        enviar.assert_not_called()
        if caminho == "promocao":
            self.assertEqual(fx.leitores[0].recursos_cliente.geracao_id, self.operacoes()[0]["geracao_id"])
        self.negativo()

    def test_01_automatico_cadeia_main_reserva_autorizacao_publicacao(self):
        self.cadeia_main("automatico")

    def test_02_manual_cadeia_main_reserva_autorizacao_publicacao(self):
        self.cadeia_main("manual")

    def test_03_promocao_cadeia_main_reserva_autorizacao_publicacao(self):
        self.cadeia_main("promocao")

    def test_04_fronteira_bidirecional_a_b(self):
        for esperada, apresentada in ((self.infra, self.outra), (self.outra, self.infra)):
            ancora = VinculoEntradasHttp(esperada)
            env = carregar_fluxos()
            with self.fluxo_http() as adaptador:
                self.assertIs(False, ancora.vincular(env["tentar_login_automatico"])(
                    infraestrutura_cliente=apresentada))
            env["WebTC420"].assert_not_called()
            self.assertEqual([], adaptador.enviados)

    def test_05_id_nominal_igual_nao_contorna(self):
        # Mesmo ID nominal desde a construção, mantendo instalação B válida.
        with patch("prototipos.composicao_cliente.uuid4", return_value=SimpleNamespace(hex=self.infra.aplicacao_id)):
            outra = modulo.InfraestruturaRegistrosCliente()
        self.assertIs(outra, modulo.exigir_infraestrutura_http(outra))
        _, executar = self.automatico(outra)
        with self.fluxo_http() as adaptador:
            self.assertIs(False, executar())
        self.assertEqual([], adaptador.enviados)

    def substituir_antes(self, recursos):
        original = self.infra._instalacao
        alterada = (replace(original,
            contexto=replace(original.contexto, recursos=self.outra.registro_recursos))
            if recursos else replace(original, http=self.outra.registro_http))
        object.__setattr__(self.infra, "_instalacao", alterada)
        try:
            _, executar = self.automatico()
            with self.fluxo_http() as adaptador:
                self.assertIs(False, executar())
            self.assertEqual([], adaptador.enviados)
        finally:
            object.__setattr__(self.infra, "_instalacao", original)

    def test_06_http_substituido_antes_da_validacao(self):
        self.substituir_antes(False)

    def test_07_recursos_substituidos_antes_da_validacao(self):
        self.substituir_antes(True)

    def test_08_atributo_publico_nao_muda_autoridade(self):
        _, janela = self.manual()
        janela.infraestrutura_cliente = self.outra
        janela.vinculo_http = VinculoEntradasHttp(self.outra)
        with self.fluxo_http() as adaptador:
            janela.conectar()
        self.assertEqual([], adaptador.enviados)

    def test_09_alias_dict_nao_altera_autoridade_capturada(self):
        env, executar = self.automatico(self.outra)
        with self.fluxo_http() as adaptador:
            self.assertIs(False, executar())
        self.assertEqual([], adaptador.enviados)
        with self.assertRaises(FrozenInstanceError):
            self.vinculo._infraestrutura = self.outra
        # L3-B1.15 elimina o caminho de mutação reproduzido na auditoria.
        with self.assertRaises(TypeError):
            vars(self.vinculo)
        with self.assertRaises(AttributeError):
            self.vinculo.__dict__
        with self.fluxo_http() as adaptador:
            self.assertIs(False, executar())
        self.assertEqual([], adaptador.enviados)
        self.assertEqual([], self.operacoes())
        self.assertEqual([], self.outra.registro_http.obter_retrato()["operacoes"])

    def test_10_gate_fechado_tres_entradas(self):
        _, auto = self.automatico()
        _, janela = self.manual()
        _, promover = self.promocao()
        self.registro.fechar_admissao()
        with patch("requests.api.request") as enviar:
            self.assertIs(False, auto())
            janela.conectar()
            self.assertIsNone(promover())
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())

    def executar_com_callback(self, callback):
        env, executar = self.automatico()
        webs = []
        def construir(ip, **kwargs):
            web = WebTC420(ip, **kwargs)
            webs.append(web)
            obter = web.obter_configuracao
            web.obter_configuracao = lambda: callback(web, obter)
            return web
        env["WebTC420"].side_effect = construir
        return executar, webs

    def test_11_autorizacao_copiada_outra_thread(self):
        def callback(web, obter):
            contexto = copy_context()
            tarefa = self.iniciar_thread(lambda: contexto.run(web.approval))
            _, erros = self.terminar(tarefa)
            self.assertEqual(1, len(erros))
            self.assertEqual("autorizacao_http_invalida", str(erros[0]))
            return obter()
        executar, _ = self.executar_com_callback(callback)
        with self.fluxo_http() as adaptador:
            self.assertTrue(executar())
        self.conferir_par(adaptador)

    def test_12_autorizacao_nao_reutilizada(self):
        def callback(web, obter):
            resultado = obter()
            with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                obter()
            return resultado
        executar, _ = self.executar_com_callback(callback)
        with self.fluxo_http() as adaptador:
            self.assertTrue(executar())
        self.conferir_par(adaptador)

    def test_13_parser_bloqueado_pendente(self):
        env, executar = self.automatico()
        entrou, liberar = threading.Event(), threading.Event()
        def construir(ip, **kwargs):
            web = WebTC420(ip, **kwargs)
            interpretar = web.interpretar_approval
            def parser(dados):
                self.bloquear(entrou, liberar)
                return interpretar(dados)
            web.interpretar_approval = parser
            return web
        env["WebTC420"].side_effect = construir
        with self.fluxo_http() as adaptador:
            tarefa = self.iniciar_thread(executar)
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual(1, adaptador.corpo.lidos)
                self.assertFalse(self.operacoes()[1]["execucao_resolvida"])
                self.assertIsNone(self.operacoes()[1]["publicacao_original"])
                self.negativo()
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertTrue(resultados[0])
        self.conferir_par(adaptador)

    def publicacao_suspensa(self, tentar_reuso):
        entrou, liberar = threading.Event(), threading.Event()
        copias = []
        def callback(web, obter):
            copias.append(copy_context())
            return obter()
        executar, webs = self.executar_com_callback(callback)
        publicar = self.registro.publicar
        def atrasar(op, recibo):
            if self.operacoes()[-1]["operacao"] == "approval":
                if tentar_reuso:
                    with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                        copias[0].run(webs[0].approval)  # Mesma thread: permissão já expirou.
                self.bloquear(entrou, liberar)
            return publicar(op, recibo)
        with self.fluxo_http() as adaptador, patch.object(self.registro, "publicar", side_effect=atrasar):
            tarefa = self.iniciar_thread(executar)
            try:
                self.assertTrue(entrou.wait(3))
                self.registro.fechar_admissao()
                self.assertFalse(self.registro.obter_retrato()["conjunto_http_resolvido"])
                self.assertTrue(self.operacoes()[1]["publicacoes_pendentes"])
                self.negativo()
                if tentar_reuso:
                    with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                        copias[0].run(webs[0].approval)  # Outra thread durante a publicação.
                    self.assertEqual(2, len(adaptador.enviados))
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertTrue(resultados[0])
        self.conferir_par(adaptador)
        self.negativo()

    def test_14_publicacao_atrasada_sem_confirmacao(self):
        self.publicacao_suspensa(False)

    def diagnosticos_multiplos(self):
        marcadores = [uuid4().hex for _ in range(4)]
        u, s, t, h = marcadores
        original = requests.HTTPError(f"https://{u}:{s}@simulado.invalid/?token={t} Authorization: {h}")
        env, auto = self.automatico()
        ui, janela = self.manual()
        cliente, promover = self.promocao()
        with self.transporte(erro=original):
            self.assertIs(False, auto())
            janela.conectar()
            self.assertIsNone(promover())
        saidas = [repr(env["print"].call_args_list), repr(ui.env["print"].call_args_list),
                  repr(cliente.env["print"].call_args_list), janela.label_status.opcoes["text"],
                  json.dumps(self.registro.obter_retrato()), json.dumps(self.infra.avaliar())]
        parada = Mock()
        parada.is_set.return_value = False
        parada.wait.return_value = True
        saude = dict(saudavel=True, falhas_consecutivas=0, ultimo_sucesso=1,
                     ultimo_erro=None, inicio_indisponibilidade=None)
        web = WebTC420("simulado.invalid", politica_http=self.infra.criar_politica_http())
        web.token = t
        with self.transporte(erro=original), patch.object(servidor, "saude_tc420", saude), \
                patch.object(servidor, "evento_parada_servidor", parada), patch("builtins.print") as console:
            servidor.ler_tc420(web)
            saidas.extend((repr(console.call_args_list), servidor.obter_saude_tc420()["ultimo_erro"]))
        self.assertTrue(all(m not in saida for m in marcadores for saida in saidas))
        self.assertEqual(3, len(self.operacoes()))  # Refresh não ganha dono CLIENTE.
        self.assertTrue(all(op["resultado"] == "falha" for op in self.operacoes()))
        contexto = self.infra.preparar_http_inicial()
        with self.transporte(erro=original):
            with self.assertRaises(requests.HTTPError) as capturado:
                self.infra.executar_approval(contexto, web)
        self.assertIs(original, capturado.exception)

    def test_15_diagnosticos_sensiveis_corrigidos(self):
        self.diagnosticos_multiplos()

    def test_16_encerramento_global_nao_confirmado(self):
        _, executar = self.automatico()
        with self.fluxo_http():
            self.assertTrue(executar())
        self.registro.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_17_critico_a_b_coerente_recusada_nas_tres(self):
        env, auto = self.automatico(self.outra)
        ui, janela = self.manual(self.outra)
        cliente, promover = self.promocao(self.outra)
        self.assertIs(self.outra, modulo.exigir_infraestrutura_http(self.outra))
        with self.fluxo_http() as adaptador:
            self.assertIs(False, auto())
            janela.conectar()
            self.assertIsNone(promover())
        self.assertEqual([], adaptador.enviados)
        for fabrica in (env["WebTC420"], ui.env["WebTC420"], cliente.env["WebTC420"]):
            fabrica.assert_not_called()

    def test_18_critico_b_instalacao_trocada_nao_migra_apos_validacao(self):
        _, janela = self.manual()
        original = self.infra._instalacao
        validar = janela._validar_infraestrutura_http
        entrou, liberar = threading.Event(), threading.Event()
        def aguardar(apresentada):
            resultado = validar(apresentada)
            self.bloquear(entrou, liberar)
            return resultado
        janela._validar_infraestrutura_http = aguardar
        with self.fluxo_http() as adaptador:
            tarefa = self.iniciar_thread(janela.conectar)
            try:
                self.assertTrue(entrou.wait(3))
                # Mesmo objeto A, instalação de B. Vínculo não é alterado.
                # vars não existe mais; forçar a troca testa a fixação efetiva.
                object.__setattr__(self.infra, "_instalacao", self.outra._instalacao)
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
                object.__setattr__(self.infra, "_instalacao", original)
        self.assertEqual([], erros)
        self.assertTrue(janela.servidor_iniciado)
        self.assertEqual(2, len(adaptador.enviados))
        self.conferir_par(adaptador)
        ops_b = self.outra.registro_http.obter_retrato()["operacoes"]
        self.assertEqual([], ops_b)
        self.assertIs(self.infra, janela.web.politica_http.proprietario)

    def test_19_critico_c_gate_apos_validacao(self):
        _, janela = self.manual()
        validar = janela._validar_infraestrutura_http
        def fechar(apresentada):
            resultado = validar(apresentada)
            self.registro.fechar_admissao()
            return resultado
        janela._validar_infraestrutura_http = fechar
        with self.fluxo_http() as adaptador:
            janela.conectar()
        self.assertEqual([], adaptador.enviados)
        self.assertEqual([], self.operacoes())

    def test_20_critico_d_publicacao_concorrente_e_permissao_expirada(self):
        self.publicacao_suspensa(True)

    def test_21_critico_e_falha_sensivel_cliente_e_principal(self):
        self.diagnosticos_multiplos()

    def test_22_post_falho_impede_get_nas_tres(self):
        _, auto = self.automatico()
        _, janela = self.manual()
        _, promover = self.promocao()
        with self.transporte(status=401) as adaptador:
            self.assertIs(False, auto())
            janela.conectar()
            self.assertIsNone(promover())
        self.assertEqual(["POST"] * 3, [r.method for r, _ in adaptador.enviados])
        self.assertEqual(["login"] * 3, [o["operacao"] for o in self.operacoes()])

    def test_23_gate_antes_get_impede_nova_reserva(self):
        _, executar = self.automatico()
        with self.fluxo_http() as adaptador:
            enviar = adaptador.send
            def fechar(pedido, **kwargs):
                resposta = enviar(pedido, **kwargs)
                self.registro.fechar_admissao()
                return resposta
            with patch.object(adaptador, "send", side_effect=fechar):
                self.assertIs(False, executar())
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual(["login"], [o["operacao"] for o in self.operacoes()])

    def test_24_permissao_de_approval_nao_autoriza_login_ou_outro_objeto(self):
        def callback(web, obter):
            outra_web = WebTC420("outra-simulada", politica_http=web.politica_http)
            outra_web.token = "simulado"
            for chamada in (outra_web.approval, lambda: web.login("simulado", "simulado")):
                with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                    chamada()
            return obter()
        executar, _ = self.executar_com_callback(callback)
        with self.fluxo_http() as adaptador:
            self.assertTrue(executar())
        self.conferir_par(adaptador)

    def test_25_isolado_e_independente_limitam_cobertura(self):
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        with self.fluxo_http() as adaptador:
            self.assertTrue(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        self.conferir_par(adaptador)
        antes = self.operacoes()
        self.registro.fechar_admissao()
        independente = WebTC420("independente-simulada")
        with self.fluxo_http() as adaptador:
            independente.login("simulado", "simulado")
            independente.obter_configuracao()
        self.assertEqual(2, len(adaptador.enviados))
        self.assertEqual(antes, self.operacoes())
        self.negativo()

    def test_26_publicacao_falha_preserva_desconhecida(self):
        _, executar = self.automatico()
        with self.fluxo_http() as adaptador, patch.object(self.registro, "publicar", side_effect=OSError()):
            self.assertIs(False, executar())
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])
        self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
        self.negativo()

    def test_27_resolucao_nao_prova_limpeza_fisica(self):
        _, executar = self.automatico()
        with self.fluxo_http() as adaptador:
            adaptador.close = Mock(side_effect=OSError("limpeza_simulada"))
            self.assertIs(False, executar())
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        self.assertEqual([], self.infra.registro_recursos.obter_retrato()["recursos"])
        self.negativo()

    def test_28_orig_origem_retida_apos_nova_geracao_e_promocao(self):
        _, auto = self.automatico()
        with self.fluxo_http():
            self.assertTrue(auto())
        antigas = self.operacoes()
        fx, promover = self.promocao()
        origem = fx.leitores[0].recursos_cliente
        entrou, liberar = threading.Event(), threading.Event()
        def post(*args, **kwargs):
            self.bloquear(entrou, liberar)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=post), \
                patch("tc420.web.requests.get", return_value=Mock(text=approval.APROVACAO.decode())):
            tarefa = self.iniciar_thread(promover)
            try:
                self.assertTrue(entrou.wait(3))
                self.registro.promover(origem.geracao_id)
                fx.leitores[0].recursos_cliente = modulo.RecursosLeitorCliente(self.infra)
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertTrue(resultados[0])
        self.assertEqual(antigas, self.operacoes()[:2])
        self.assertEqual(4, len({o["operacao_id"] for o in self.operacoes()}))
        for op in self.operacoes()[2:]:
            self.assertEqual(origem.geracao_id, op["geracao_id"])
            self.assertEqual(origem.atividade_id, op["atividade_id"])
            self.assertEqual("principal", op["modo_atual"])

    def test_29_outro_diagnostico_monitor_permanece_sensivel(self):
        fonte = Path(__file__).resolve().parents[1] / "interface/janela.py"
        arvore = ast.parse(fonte.read_text(encoding="utf-8"))
        metodo = next(n for n in ast.walk(arvore) if isinstance(n, ast.FunctionDef) and n.name == "atualizar_refresh_web")
        env = {"print": Mock(), "datetime": __import__('datetime').datetime}
        exec(compile(ast.Module(body=[metodo], type_ignores=[]), str(fonte), "exec"), env)
        marcador = uuid4().hex
        objeto = SimpleNamespace(executando=True, root=Mock(), atualizar_refresh_web=Mock(),
                                 fonte_dados=Mock(side_effect=requests.HTTPError(marcador)))
        objeto._agendar = objeto.root.after
        env[metodo.name](objeto)
        self.assertNotIn(marcador, repr(env["print"].call_args_list))
        # Não é o worker corrigido: callback genérico injetado, sem HTTP novo.

"""Medições e baterias 2B.6, executadas explicitamente, sem rede."""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import platform
import sys
import time
import tracemalloc
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rede import servidor as s
from prototipos.identidades_intervalos import RegistroIntervalosExperimental


def medir(prototipo, heterogeneo=False, externos='nenhum', total=50000):
    gc.collect()
    tracemalloc.start()
    inicio = time.perf_counter()
    r = RegistroIntervalosExperimental() if prototipo else s.RegistroTrabalhadores()
    preservados = []
    for i in range(total):
        t = r.reservar_criacao_socket()
        r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=not heterogeneo or i % 2 == 0)
        if externos == 'todos' or externos == 'um' and i == 0:
            preservados.append(t)
    del t
    gc.collect()
    atual, pico = tracemalloc.get_traced_memory()
    segundos = time.perf_counter()-inicio
    tracemalloc.reset_peak()
    inicio = time.perf_counter()
    diagnostico = r.obter_situacao()
    tempo_consulta = time.perf_counter()-inicio
    _, pico_consulta = tracemalloc.get_traced_memory()
    assert len(diagnostico['criacoes_socket']) == total
    digest = hashlib.sha256(repr(diagnostico).encode()).hexdigest()
    for t in preservados:
        assert r.fechar_socket(t) is True
    resultado = dict(prototipo=prototipo, carga='alternada_sem_recurso_incerta' if heterogeneo else 'uniforme_sem_recurso',
        tokens_externos=externos, reservas=total, diagnosticos=total,
        entradas_fortes=len(r._reservas_socket.fortes) if prototipo else total,
        intervalos=len(r._reservas_socket.intervalos) if prototipo else 0,
        identidades_fracas=len(r._reservas_socket.identidades) if prototipo else 0,
        threads=len(r.threads), referencias_recursos=sum(e.recurso is not None for e in r._reservas_socket.values()),
        bytes_retidos=atual, bytes_pico_carga=pico, segundos_carga=segundos,
        segundos_consulta=tempo_consulta, pico_consulta_absoluto_bytes=pico_consulta,
        digest_diagnostico=digest)
    tracemalloc.stop()
    return resultado


def contratos():
    nomes = ['test_compactacao_registro', 'test_guarda_sockets_integrada',
             'test_erros_fechamento_handlers', 'test_saida_aplicacao_b2', 'test_supervisao_principal']
    suite = unittest.defaultTestLoader.loadTestsFromNames(nomes)
    with patch.object(s, 'RegistroTrabalhadores', RegistroIntervalosExperimental):
        resultado = unittest.TextTestRunner(verbosity=0).run(suite)
    return resultado.wasSuccessful()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--contratos', action='store_true')
    args = parser.parse_args()
    if args.contratos:
        raise SystemExit(not contratos())
    medicoes = [medir(False), medir(True), medir(True, externos='um'),
                medir(True, externos='todos'), medir(False, heterogeneo=True), medir(True, heterogeneo=True)]
    assert len({m['digest_diagnostico'] for m in medicoes[:4]}) == 1
    assert medicoes[4]['digest_diagnostico'] == medicoes[5]['digest_diagnostico']
    print(json.dumps(dict(python=platform.python_version(), plataforma=sys.platform,
        medicoes=medicoes, limites='Tracemalloc com GC explicito; sem sockets ou threads iniciadas; nao e RSS.'), indent=2))

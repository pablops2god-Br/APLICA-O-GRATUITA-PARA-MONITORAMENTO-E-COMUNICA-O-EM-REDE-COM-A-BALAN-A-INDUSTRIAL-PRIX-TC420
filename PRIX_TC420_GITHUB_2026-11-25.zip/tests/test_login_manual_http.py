# Testes de login manual http: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.5: janela real por AST, widgets/threads/transporte falsos, sem Tk real."""
import ast
from pathlib import Path
from types import SimpleNamespace
import threading
import tkinter as tk
import unittest
from unittest.mock import Mock, patch
from uuid import uuid4

import requests

from rede import servidor
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from tc420.web import WebTC420
import test_login_http_integrado as login
import test_infraestrutura_cliente as fixtures


class WidgetFalso:
    def __init__(self, master=None, **opcoes):
        self.raiz = master.raiz if master is not None else self
        if master is None:
            self.destruida, self.eventos, self.binds, self.agendados = False, [], {}, []
        self.opcoes, self.valor = opcoes, ""

    def _usar(self, acao):
        self.raiz.eventos.append(acao)
        if self.raiz.destruida:
            raise tk.TclError("widget_simulado_destruido")

    def config(self, **opcoes):
        self._usar("config")
        self.opcoes.update(opcoes)

    configure = config

    def get(self):
        self._usar("get")
        return self.valor

    def insert(self, indice, valor):
        self.valor = str(valor)

    def pack(self, **kwargs):
        pass

    grid = pack

    def focus_set(self):
        pass

    def title(self, *args):
        pass

    geometry = title
    resizable = title
    protocol = title

    def winfo_exists(self):
        return not self.raiz.destruida

    def after_cancel(self, identidade):
        pass

    def bind(self, evento, chamada, **kwargs):
        self.binds[evento] = chamada

    def update_idletasks(self):
        self._usar("update_idletasks")

    def after(self, prazo, chamada):
        self._usar("after")
        self.agendados.append((prazo, chamada))

    def destroy(self):
        self.destruida = True
        self.eventos.append("destroy")

    def mainloop(self):
        pass


class VariavelFalsa:
    def __init__(self, value):
        self.valor = value

    def get(self):
        return self.valor

    def set(self, valor):
        self.valor = valor


class ThreadFalsa:
    def __init__(self, target, daemon):
        self.target, self.started = target, False

    def start(self):
        self.started = True  # Nunca executa servidor/observador real.


# Grupo de 26 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class LoginManualHttp(unittest.TestCase):
    transporte = login.LoginHttpIntegrado.transporte
    iniciar_thread = login.LoginHttpIntegrado.iniciar_thread
    terminar = login.LoginHttpIntegrado.terminar
    bloquear = login.LoginHttpIntegrado.bloquear
    operacoes = login.LoginHttpIntegrado.operacoes
    negativo = login.LoginHttpIntegrado.negativo

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_http
        self.webs = []
        self.arvore = ast.parse((Path(__file__).resolve().parents[1] / "interface/conexao.py").read_text(encoding="utf-8"))
        classe = next(n for n in self.arvore.body if isinstance(n, ast.ClassDef) and n.name == "JanelaConexao")
        def criar_web(ip, **kwargs):
            web = WebTC420(ip, **kwargs)
            web.obter_configuracao = Mock(return_value={})  # approval fora desta etapa.
            self.webs.append(web)
            return web
        self.env = dict(
            tk=SimpleNamespace(Tk=WidgetFalso, Label=WidgetFalso, Frame=WidgetFalso,
                               Entry=WidgetFalso, Button=WidgetFalso, Checkbutton=WidgetFalso,
                               BooleanVar=VariavelFalsa),
            threading=SimpleNamespace(Thread=ThreadFalsa, Event=threading.Event, Lock=threading.Lock),
            carregar_configuracao=Mock(return_value=None), carregar_senha=Mock(),
            salvar_configuracao=Mock(), salvar_senha=Mock(return_value=True), remover_senha=Mock(),
            buscar_servidor=Mock(return_value=None), WebTC420=Mock(side_effect=criar_web),
            ContextoCicloServidor=servidor.ContextoCicloServidor,
            definir_configuracao=Mock(), iniciar_servidor=Mock(), print=Mock(),
        )
        exec(compile(ast.Module(body=[classe], type_ignores=[]), "interface/conexao.py", "exec"), self.env)
        self.janela = self.criar_janela(self.infra)

    def criar_janela(self, infra, **kwargs):
        def formulario(root, assumir, confirmar):
            entradas = {nome: WidgetFalso(root) for nome in
                        ('Nome da balança', 'IP da TC420', 'Porta TCP', 'Usuário', 'Senha')}
            return SimpleNamespace(entradas=entradas, salvar=VariavelFalsa(False),
                                   metodo=VariavelFalsa('HTTPS'), botao=WidgetFalso(root, command=confirmar),
                                   status=WidgetFalso(root), check_salvar=WidgetFalso(root))
        # Aparência real é verificada pelo ensaio Tk integrado; aqui isolamos HTTP.
        with patch('interface.formularios.montar_formulario', side_effect=formulario):
            janela = self.env["JanelaConexao"](infraestrutura_cliente=infra, **kwargs)
        # Estas caracterizacoes isolam HTTP/arquivos com executor controlado.
        # A concorrencia real da interface e exercitada em test_interface_b3.
        from interface.ciclo_tk import CicloTk
        class CicloImediato(CicloTk):
            def valido(self, *, encerramento=False):
                return self.aberto and self.root.winfo_exists()

            def agendar(self, prazo, callback, *args, **kwargs):
                return self.root.after(prazo, callback)

            def iniciar(self, chave, trabalho, aplicar):
                from interface.mensagens_seguras import mensagem_erro_login
                try:
                    resultado = trabalho()
                except Exception as erro:
                    self.erro = mensagem_erro_login(erro)
                    aplicar(None, self.erro)
                else:
                    aplicar(resultado, None)
                return True
        janela._ciclo_tk = CicloImediato(janela.root, lambda: janela.saida_aplicacao)
        for nome in ("nome", "usuario", "senha"):
            getattr(janela, "campo_" + nome).valor = "simulado"
        janela.campo_ip.valor = "balanca-simulada"
        janela.campo_porta.valor = "9800"
        return janela

    def executar(self):
        return self.janela.conectar()

    def fachada(self, web):
        return self.infra.executar_login_manual(web, "simulado", "simulado")

    def test_01_manual_normal_callback_e_fluxo_preservados(self):
        with self.transporte() as adaptador:
            self.janela.botao_conectar.opcoes["command"]()
        self.assertEqual(1, len(adaptador.enviados))
        pedido, opcoes = adaptador.enviados[0]
        self.assertEqual("POST", pedido.method)
        self.assertTrue(pedido.url.startswith("https://balanca-simulada/cgi-bin/cfgcgi.cgi?"))
        self.assertEqual(5, opcoes["timeout"])
        self.assertFalse(opcoes["verify"])
        self.assertFalse(opcoes["stream"])
        self.assertIsNone(pedido.body)
        self.assertEqual("retorno", self.operacoes()[0]["resultado"])
        self.assertTrue(self.janela.servidor_iniciado)
        self.assertEqual("normal", self.janela.botao_conectar.opcoes["state"])
        self.assertEqual("green", self.janela.label_status.opcoes["fg"])
        self.assertTrue(any(p == 500 and cb == self.janela.abrir_monitor for p, cb in self.janela.root.agendados))
        self.env["salvar_configuracao"].assert_called_once_with(
            nome_rede="simulado", ip="balanca-simulada", porta=9800, usuario="simulado", salvar_login=False)

    def test_02_rejeicao_preserva_mensagem_e_botao(self):
        texto = b"FAILURE:LOGIN:simulado:simulado"
        with self.transporte(texto):
            self.executar()
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        self.assertIsNone(self.janela.web)
        self.assertIsNone(self.janela.configuracao)
        self.assertEqual("normal", self.janela.botao_conectar.opcoes["state"])
        self.assertTrue(self.janela.label_status.opcoes["text"].endswith("Login recusado pela TC420. Verifique usuário e senha."))
        self.env["salvar_configuracao"].assert_not_called()

    def test_03_timeout_mensagem_segura_sem_retry(self):
        original = requests.Timeout("timeout_simulado")
        with self.transporte(erro=original) as adaptador:
            self.executar()
        self.assertEqual(1, len(adaptador.enviados))
        self.assertTrue(self.janela.label_status.opcoes["text"].endswith("Tempo de conexão com a TC420 esgotado. Tente novamente."))
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        self.assertFalse(self.janela.servidor_iniciado)

    def test_04_conexao_original_na_fachada_e_mensagem_na_janela(self):
        original = requests.ConnectionError("conexao_simulada")
        with self.transporte(erro=original):
            with self.assertRaises(requests.ConnectionError) as capturado:
                self.fachada(WebTC420("balanca-simulada"))
        self.assertIs(original, capturado.exception)
        with self.transporte(erro=original):
            self.executar()
        self.assertTrue(self.janela.label_status.opcoes["text"].endswith("Não foi possível conectar à TC420. Verifique a conexão e tente novamente."))

    def test_05_respostas_invalidas_preservam_validacao(self):
        for texto in (b"invalida", b"SUCCESS:LOGIN:simulado:"):
            with self.subTest(texto=texto), self.transporte(texto):
                self.executar()
            self.assertEqual("falha", self.operacoes()[-1]["resultado"])
            self.assertIsNone(self.janela.web)
        self.env["salvar_configuracao"].assert_not_called()

    def test_06_pre_execucao_prova_sem_envio(self):
        original = OSError("antes_inicio_simulado")
        with patch.object(self.registro, "_iniciar", side_effect=original), patch("requests.post") as enviar:
            self.executar()
        enviar.assert_not_called()
        op = self.operacoes()[0]
        self.assertTrue(op["execucao_resolvida"])
        self.assertFalse(op["inicio_confirmado"])
        self.assertEqual("nao_execucao_comprovada", op["publicacao_original"]["evidencia"])

    def test_07_segundo_conectar_apos_partida_nao_reautentica(self):
        with self.transporte() as adaptador:
            for _ in range(2):
                self.janela.botao_conectar.opcoes["command"]()
        self.assertEqual(1, len(adaptador.enviados))
        self.assertEqual(["login", "approval"], [op["operacao"] for op in self.operacoes()])
        self.assertEqual(2, len({op["operacao_id"] for op in self.operacoes()}))
        self.assertTrue(all(op["execucao_resolvida"] for op in self.operacoes()))

    def test_08_duas_operacoes_http_controladas_independentes(self):
        barreira = threading.Barrier(2)
        def enviar(*args, **kwargs):
            barreira.wait(3)
            self.assertEqual(2, len(self.operacoes()))
            self.assertTrue(all(not op["execucao_resolvida"] for op in self.operacoes()))
            barreira.wait(3)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=enviar) as enviar_http:
            # B3 deduplica os comandos Tk. Este caso conserva a prova HTTP
            # de duas operacoes independentes, invocando somente os workers.
            outra = self.criar_janela(self.infra)
            args = ('simulado', 'balanca-simulada', 9800, 'simulado', object(), False)
            a = self.iniciar_thread(lambda: self.janela._conectar_operacional(*args))
            b = self.iniciar_thread(lambda: outra._conectar_operacional(*args))
            _, ea = self.terminar(a)
            _, eb = self.terminar(b)
        self.assertEqual(([], []), (ea, eb))
        self.assertEqual(2, enviar_http.call_count)
        self.assertEqual(4, len(self.operacoes()))
        self.assertEqual(2, sum(op["operacao"] == "login" for op in self.operacoes()))
        self.assertEqual(2, sum(op["operacao"] == "approval" for op in self.operacoes()))
        self.assertEqual(2, len({op["geracao_id"] for op in self.operacoes()}))
        self.assertTrue(all(op["resultado"] == "retorno" for op in self.operacoes()))

    def test_09_corrida_b_fechamento_mantem_responsabilidade(self):
        entrou, liberar = threading.Event(), threading.Event()
        with self.transporte(antes=lambda: self.bloquear(entrou, liberar)):
            tarefa = self.iniciar_thread(self.executar)
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.operacoes()[0]
                self.janela.root.destroy()
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
                self.negativo()
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        # Acessos legados a widgets destruídos continuam evidenciados, sem nova
        # política Tk. A publicação HTTP já ocorreu antes da falha visual.
        self.assertEqual([], erros)
        depois = self.operacoes()[0]
        self.assertTrue(depois["execucao_resolvida"])
        self.assertEqual("retorno", depois["resultado"])
        self.assertEqual(antes["operacao_id"], depois["operacao_id"])
        self.assertEqual([], self.janela.root.agendados)

    def test_10_resultado_tardio_fachada_nao_acessa_tk(self):
        entrou, liberar = threading.Event(), threading.Event()
        with self.transporte(antes=lambda: self.bloquear(entrou, liberar)):
            tarefa = self.iniciar_thread(lambda: self.fachada(WebTC420("balanca-simulada")))
            try:
                self.assertTrue(entrou.wait(3))
                self.janela.root.destroy()
                eventos = list(self.janela.root.eventos)
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual((["simulado"], []), (resultados, erros))
        self.assertEqual(eventos, self.janela.root.eventos)
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_11_corrida_c_publicacao_pendente(self):
        entrou, liberar = threading.Event(), threading.Event()
        publicar = self.registro.publicar
        def atrasar(op, recibo):
            self.bloquear(entrou, liberar)
            return publicar(op, recibo)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=atrasar):
            tarefa = self.iniciar_thread(self.executar)
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual("simulado", self.webs[0].token)
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
                self.assertTrue(self.operacoes()[0]["publicacoes_pendentes"])
                self.assertEqual([], self.janela.root.agendados)
                self.negativo()
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_12_publicacao_duplicada_idempotente(self):
        publicar = self.registro.publicar
        def duplicar(op, recibo):
            self.assertTrue(publicar(op, recibo))
            return publicar(op, recibo)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=duplicar):
            self.executar()
        self.assertEqual(["login", "approval"], [op["operacao"] for op in self.operacoes()])
        self.assertTrue(all(op["execucao_resolvida"] for op in self.operacoes()))
        self.assertTrue(all(not op["conflitos_publicacao"] for op in self.operacoes()))

    def test_13_manual_e_automatico_independentes(self):
        barreira = threading.Barrier(2)
        original = requests.Timeout("simulada")
        def enviar(url, **kwargs):
            barreira.wait(3)
            if "automatico" in url:
                raise original
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=enviar):
            a = self.iniciar_thread(self.executar)
            b = self.iniciar_thread(lambda: self.infra.executar_login_automatico(
                WebTC420("automatico-simulado"), "simulado", "simulado"))
            _, ea = self.terminar(a)
            _, eb = self.terminar(b)
        self.assertEqual(([], [original]), (ea, eb))
        a, b = [op for op in self.operacoes() if op["operacao"] == "login"]
        self.assertEqual(1, sum(op["operacao"] == "approval" for op in self.operacoes()))
        self.assertNotEqual(a["operacao_id"], b["operacao_id"])
        self.assertNotEqual(a["geracao_id"], b["geracao_id"])
        self.assertEqual(("retorno", "falha"), (a["resultado"], b["resultado"]))

    def test_14_corrida_d_preparacao_antes_leitor(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.assertEqual([], self.registro.obter_retrato()["operacoes"])
        with self.transporte(antes=lambda: self.bloquear(entrou, liberar)):
            tarefa = self.iniciar_thread(self.executar)
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.operacoes()[0]
                leitor = RecursosLeitorCliente(self.infra)
                self.assertNotEqual(antes["geracao_id"], leitor.geracao_id)
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        depois = self.operacoes()[0]
        for campo in ("operacao_id", "geracao_id", "atividade_id"):
            self.assertEqual(antes[campo], depois[campo])
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()["retentativas"])

    def test_15_privacidade_registro_e_console_sucesso_e_falha(self):
        usuario, senha, resultado = (uuid4().hex for _ in range(3))
        self.janela.campo_usuario.valor, self.janela.campo_senha.valor = usuario, senha
        with self.transporte(("SUCCESS:LOGIN:simulado:" + resultado).encode()):
            self.executar()
        console_sucesso = repr(self.env["print"].call_args_list)
        self.assertTrue(all(valor not in console_sucesso for valor in (usuario, senha, resultado)))
        self.janela.servidor_iniciado = False  # nova tentativa isolada de HTTP
        self.env["print"].reset_mock()
        # Interface, console e retrato não recebem texto arbitrário da exceção.
        erro = requests.ConnectionError(" ".join((usuario, senha, resultado)))
        with self.transporte(erro=erro):
            self.executar()
        console = repr(self.env["print"].call_args_list)
        retrato = repr(self.registro.obter_retrato())
        self.assertTrue(all(valor not in console and valor not in retrato for valor in (usuario, senha, resultado)))
        self.env["print"].assert_any_call("Erro ao realizar login:", "ConnectionError")

    def test_16_cobertura_parcial_mesmo_gates_fechados(self):
        with self.transporte():
            self.executar()
        self.registro.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_17_recusa_sem_http_com_mensagem_existente(self):
        self.registro.fechar_admissao()
        with patch("requests.post") as enviar:
            self.executar()
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())
        self.assertFalse(self.janela.servidor_iniciado)
        self.assertEqual("normal", self.janela.botao_conectar.opcoes["state"])
        self.assertTrue(self.janela.label_status.opcoes["text"].endswith("admissao_contexto_http_recusada"))

    def test_18_validacoes_sem_reserva_ou_requisicao(self):
        for campo, valor in (("nome", ""), ("ip", ""), ("porta", ""), ("porta", "invalida"),
                             ("porta", "0"), ("porta", "65536"), ("usuario", ""), ("senha", "")):
            with self.subTest(campo=campo, valor=valor), patch("requests.post") as enviar:
                janela = self.criar_janela(self.infra)
                getattr(janela, "campo_" + campo).valor = valor
                janela.conectar()
                enviar.assert_not_called()
                self.assertEqual([], self.operacoes())
                self.assertEqual("red", janela.label_status.opcoes["fg"])
        self.env["buscar_servidor"].assert_not_called()

    def test_19_descoberta_positiva_sem_login(self):
        self.env["buscar_servidor"].return_value = "principal-simulado"
        self.janela.ao_encontrar_servidor = Mock()
        with patch("requests.post") as enviar:
            self.executar()
        enviar.assert_not_called()
        self.janela.executar()
        self.janela.ao_encontrar_servidor.assert_called_once_with("principal-simulado")
        self.assertTrue(self.janela.root.destruida)
        self.assertEqual([], self.operacoes())

    def test_20_falha_publicacao_impede_persistencia_e_servidor(self):
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=OSError()):
            self.executar()
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])
        self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
        self.env["salvar_configuracao"].assert_not_called()
        self.assertFalse(self.janela.servidor_iniciado)
        self.negativo()

    def test_21_erro_http_preservado_se_publicacao_tambem_falhar(self):
        original = requests.Timeout("simulada")
        with self.transporte(erro=original), patch.object(self.registro, "publicar", side_effect=OSError()):
            with self.assertRaises(requests.Timeout) as capturado:
                self.fachada(WebTC420("balanca-simulada"))
        self.assertIs(original, capturado.exception)
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])

    def test_22_resposta_com_close_falho_sem_confirmacao_global(self):
        original = OSError("limpeza_simulada")
        with self.transporte() as adaptador:
            adaptador.close = Mock(side_effect=original)
            self.executar()
        self.assertEqual(1, adaptador.corpo.lidos)
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.negativo()

    def test_23_main_passa_unico_dono_ate_callback_real(self):
        fixture = fixtures.InfraestruturaCliente()
        fixture.setUp()
        fixture.env["buscar_servidor"].return_value = None
        fixture.env["tentar_login_automatico"] = Mock(return_value=False)
        janelas = []
        def criar(**kwargs):
            janela = self.criar_janela(kwargs["infraestrutura_cliente"])
            janela.root.mainloop = janela.conectar
            janelas.append(janela)
            return janela
        fixture.env["JanelaConexao"] = Mock(side_effect=criar)
        with self.transporte():
            fixture.env["iniciar"]()
        infra = janelas[0].infraestrutura_cliente
        self.assertIs(infra, infra.registro_http.proprietario)
        self.assertEqual(["login", "approval"],
                         [op["operacao"] for op in infra.registro_http.obter_retrato()["operacoes"]])
        self.assertEqual([], self.operacoes())  # Nenhum registro pertencente à janela.

    def test_24_legado_sem_infra_recusa_login_direto(self):
        janela = self.criar_janela(None)
        with self.transporte() as adaptador:
            janela.conectar()
        self.assertEqual(0, len(adaptador.enviados))
        self.assertFalse(janela.servidor_iniciado)
        self.assertEqual("normal", janela.botao_conectar.opcoes["state"])
        self.assertEqual([], self.operacoes())

    def test_25_execucao_sem_locks(self):
        def antes():
            for registro in (self.registro, self.infra.registro_recursos, self.infra.registro_retentativas):
                adquiriu = registro._lock.acquire(blocking=False)
                self.assertTrue(adquiriu)
                if adquiriu:
                    registro._lock.release()
            self.assertEqual("em_andamento", self.operacoes()[0]["estado"])
        with self.transporte(antes=antes):
            self.executar()

    def test_26_http_erro_preserva_response_e_tratamento(self):
        with self.transporte(status=401) as adaptador:
            with self.assertRaises(requests.HTTPError) as capturado:
                self.fachada(WebTC420("balanca-simulada"))
        self.assertIs(adaptador.resposta, capturado.exception.response)
        with self.transporte(status=503):
            self.executar()
        self.assertEqual("falha", self.operacoes()[-1]["resultado"])
        self.env["print"].assert_any_call("Erro ao realizar login:", "HTTPError")
        self.assertFalse(self.janela.servidor_iniciado)


if __name__ == "__main__":
    unittest.main()

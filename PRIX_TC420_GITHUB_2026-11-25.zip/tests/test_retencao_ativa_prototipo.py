"""Provas locais dos protótipos; nenhuma ativação operacional."""
import gc
import threading
import unittest
import weakref
from unittest.mock import patch

from rede import servidor as s
from prototipos.retencao_ciclo_ativo import SemRecursoMinimo, RegistroSeparacaoExperimental
from test_guarda_sockets_integrada import SocketFalso


class RetencaoAtivaPrototipo(unittest.TestCase):
    def setUp(self):
        self.r = RegistroSeparacaoExperimental()
        self.c = s.ControleCicloServidor()
        self.c.tentar_iniciar(self.r)

    def cliente(self):
        t = self.r.reservar_criacao_socket()
        sock = SocketFalso()
        self.r.anexar_socket(t, sock)
        self.r.publicar_socket(t)
        return t, sock

    def test_a_equivalencia_diagnostico_identidade(self):
        resultados = []
        for representacao in (s._CriacaoSocketResolvida, SemRecursoMinimo):
            with patch.object(s, '_CriacaoSocketResolvida', representacao):
                r = s.RegistroTrabalhadores()
                t = r.reservar_criacao_socket()
                r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True)
                self.assertIs(r._reservas_socket[1].reserva, t)
                self.assertTrue(r.fechar_socket(t))
                self.assertFalse(r.publicar_limpeza_handler(t))
                resultados.append(r.obter_situacao())
        self.assertEqual(*resultados)

    def test_b_recurso_coletado_token_diagnostico_preservados(self):
        t, sock = self.cliente()
        ref = weakref.ref(sock)
        self.r.encerrar_uso_socket(t)
        self.r.fechar_socket(t)
        antes = self.r.obter_situacao()
        del sock
        self.assertEqual(self.r.separar_recursos_resolvidos(), 1)
        gc.collect()
        self.assertIsNone(ref())
        self.assertIs(t.dono, self.r)
        self.assertEqual(self.r.obter_situacao(), antes)
        self.assertTrue(self.r.fechar_socket(t))
        self.assertEqual(self.r.separar_recursos_resolvidos(), 0)

    def test_b_pendencia_handler_e_erro_tardio(self):
        t, sock = self.cliente()
        self.r.iniciar_limpeza_handler(t)
        self.r.encerrar_uso_socket(t)
        self.assertEqual(self.r.separar_recursos_resolvidos(), 0)
        self.r.bloquear_criacao()
        self.c.finalizar(self.r)
        self.assertFalse(self.c._obter_situacao_historica(1)['encerramento_confirmado'])
        self.r.publicar_limpeza_handler(t, OSError())
        self.r.fechar_socket(t)
        self.assertEqual(self.r.separar_recursos_resolvidos(), 0)
        self.assertIs(self.r._reservas_socket[t.criacao_id].recurso, sock)
        self.assertFalse(self.r.encerramento_confirmado())

    def test_b_handler_tardio_sucesso_e_publicacao_repetida(self):
        t, sock = self.cliente()
        self.r.iniciar_limpeza_handler(t)
        self.r.encerrar_uso_socket(t)
        self.r.bloquear_criacao()
        self.c.finalizar(self.r)
        self.r.publicar_limpeza_handler(t)
        self.r.fechar_socket(t)
        self.assertEqual(self.r.separar_recursos_resolvidos(), 1)
        self.assertTrue(self.r.publicar_limpeza_handler(t))
        self.assertTrue(self.r.fechar_socket(t))
        self.assertTrue(self.c._obter_situacao_historica(1)['encerramento_confirmado'])

    def test_b_close_concorrente_pendente_nao_separa(self):
        t, sock = self.cliente()
        self.r.encerrar_uso_socket(t)
        entrou, liberar = threading.Event(), threading.Event()
        original = sock.close
        def close():
            entrou.set()
            if not liberar.wait(5):
                raise RuntimeError('prazo do teste')
            original()
        sock.close = close
        resultado = []
        worker = threading.Thread(target=lambda: resultado.append(self.r.fechar_socket(t)))
        worker.start()
        try:
            self.assertTrue(entrou.wait(5))
            self.assertEqual(self.r.separar_recursos_resolvidos(), 0)
            self.assertFalse(self.r.fechar_socket(t))
            self.r.bloquear_criacao()
            self.assertFalse(self.r.encerramento_confirmado())
        finally:
            liberar.set()
            worker.join(5)
        self.assertFalse(worker.is_alive())
        self.assertEqual(resultado, [True])
        self.assertEqual(self.r.separar_recursos_resolvidos(), 1)

    def test_b_criacao_incerta_preservada(self):
        t = self.r.reservar_criacao_socket()
        self.r.resolver_falha_criacao_socket(t)
        self.assertEqual(self.r.separar_recursos_resolvidos(), 0)
        self.r.bloquear_criacao()
        self.assertFalse(self.r.encerramento_confirmado())
        self.assertEqual(self.r._reservas_socket[t.criacao_id].estado, 'criacao_incerta')


if __name__ == '__main__':
    unittest.main()

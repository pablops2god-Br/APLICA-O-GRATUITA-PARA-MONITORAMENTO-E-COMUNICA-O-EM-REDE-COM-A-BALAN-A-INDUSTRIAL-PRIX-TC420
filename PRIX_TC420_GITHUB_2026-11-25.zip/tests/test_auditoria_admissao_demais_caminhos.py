# Testes de auditoria admissao demais caminhos: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-C3: caracteriza lacunas sem instalar controles ou alterar protocolos."""
import ast
from contextlib import contextmanager
import json
from pathlib import Path
import socket
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from rede import buscarservidor as busca
from rede.lerdadosserver import LeitorDadosServidor
from rede.servidor import RegistroTentativasAplicacao
from test_recursos_cliente_integrados import SocketLeituraFalso
from test_descoberta_cliente_integrada import SocketDescobertaFalso
from apoio_conexoes_cliente import conexoes_tcp_simuladas
import test_partidas_retentativas_cliente as partidas
import test_associacoes_retentativas_cliente as associacoes
import test_auditoria_atividades_cliente_ac3b as auditoria
import test_infraestrutura_cliente as montagem


THREAD_REAL = threading.Thread
RAIZ = Path(__file__).resolve().parents[1]


# Grupo de 36 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AuditoriaAdmissaoDemaisCaminhos(unittest.TestCase):
    setUp = partidas.PartidasRetentativasCliente.setUp
    fabricar = partidas.PartidasRetentativasCliente.fabricar
    preparar = partidas.PartidasRetentativasCliente.preparar
    partir = partidas.PartidasRetentativasCliente.partir
    recuperar = associacoes.AssociacoesRetentativasCliente.executar_descoberta
    promover_real = auditoria.AuditoriaAtividadesAC3B.promover_real

    def recursos(self):
        return self.infra.registro_recursos.obter_retrato()['recursos']

    def negativo(self):
        resultado = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(resultado['encerramento_cliente_confirmado'])
        self.assertFalse(resultado['encerramento_global_confirmado'])
        self.assertEqual('incompleta', resultado['cobertura_operacional'])
        return resultado

    def config(self):
        config = SocketLeituraFalso()
        config.arquivo.readline = Mock(return_value='{}')
        return config

    def registro(self):
        registro = SocketLeituraFalso()
        registro.arquivo.readline = Mock(return_value=json.dumps({'nome': self.leitor.nome_computador, 'posicao': 1}))
        return registro

    def iniciar_loop(self):
        erros = []
        self.leitor.executando = False
        def fabricar(target, daemon):
            def executar():
                try:
                    target()
                except BaseException as erro:
                    erros.append(erro)
            return THREAD_REAL(target=executar, daemon=daemon)
        with patch('rede.lerdadosserver.threading', SimpleNamespace(Thread=fabricar)):
            self.leitor.iniciar()
        return self.leitor.thread, erros

    def tarefa(self, funcao):
        erros = []
        def executar():
            try:
                funcao()
            except BaseException as erro:
                erros.append(erro)
        thread = THREAD_REAL(target=executar, daemon=True)
        thread.start()
        return thread, erros

    def terminar(self, tarefa):
        tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())
        self.assertEqual([], tarefa[1])

    def enderecos(self, quantidade=1):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (f'destino-simulado-{i}', 42100))
                for i in range(quantidade)]

    def parar_com_config(self):
        self.leitor.parar()
        return '{}'

    def resposta_udp(self, antes=None):
        udp = SocketDescobertaFalso()
        def receber(*args):
            if antes is not None:
                antes()
            return b'TC420_SERVER_HERE', ('simulado', 42101)
        udp.recvfrom.side_effect = receber
        return udp

    def buscar(self, dono=None, udp=None, tcp=None):
        udp, tcp = udp or SocketDescobertaFalso(), tcp or SocketDescobertaFalso()
        with patch.object(busca.socket, 'socket', side_effect=lambda familia, tipo:
                          udp if tipo == socket.SOCK_DGRAM else tcp):
            return busca.buscar_servidor(recursos_cliente=dono or self.leitor.recursos_cliente)

    def gap_subscribe(self, reconexao=False, reserva_previa=False):
        self.leitor.ip_servidor = 'simulado'
        config, reg_a, reg_b = self.config(), self.registro(), self.registro()
        subs = [SocketLeituraFalso() for _ in range(2 if reconexao else 1)]
        for sub in subs:
            sub.arquivo.readline = Mock(return_value='')
        entrou, liberar = threading.Event(), threading.Event()
        admitir = self.leitor._admissao_subscribe.admitir
        chamadas, alocacoes = [], []
        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
        def admitir_controlado():
            if self.leitor.configuracao_pronta.is_set():
                chamadas.append(True)
                if len(chamadas) == len(subs) and not reserva_previa:
                    suspender()
            return admitir()
        def alocar(*args):
            if len(alocacoes) + 1 == len(subs) and reserva_previa:
                suspender()
            alocacoes.append(self.leitor.executando)
            return subs[len(alocacoes) - 1]
        def candidatura():
            self.leitor.ip_servidor = 'simulado'
            return False
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config, reg_a, reg_b]), \
                patch.object(self.leitor._admissao_subscribe, 'admitir', side_effect=admitir_controlado), \
                patch.object(self.leitor, '_aguardar_candidatura', side_effect=candidatura), \
                patch('rede.lerdadosserver.socket.socket', side_effect=alocar), patch('builtins.print'):
            tarefa = self.iniciar_loop()
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.recursos()
                self.assertIsNone(self.leitor.cliente)
                self.leitor.parar()
                self.assertFalse(self.infra.registro_recursos.obter_retrato()['admissao_fechada'])
                self.negativo()
            finally:
                self.leitor.parar()
                liberar.set()
                self.terminar(tarefa)
        if reserva_previa:
            self.assertFalse(alocacoes[-1])
            subs[-1].sendall.assert_called_once_with(b'SUBSCRIBE\n')
        else:
            # AC3-C7: a parada venceu a admissão, antes da fábrica alvo.
            self.assertEqual(len(subs) - 1, len(alocacoes))
            subs[-1].sendall.assert_not_called()
        subs[-1].shutdown.assert_not_called()  # ainda não estava em self.cliente na parada.
        # A reserva prévia já aparece em ``antes``. Com recv(), a parada após
        # alocação não cria mais um arquivo makefile que nunca seria lido.
        self.assertEqual(len(antes), len(self.recursos()))
        self.assertTrue(all(r['encerramento_confirmado'] for r in self.recursos()))
        return antes, subs

    @contextmanager
    def leitura_pendente(self):
        self.leitor.ip_servidor = 'simulado'
        config, registro, subscribe = self.config(), self.registro(), SocketLeituraFalso()
        entrou, liberar = threading.Event(), threading.Event()
        def receber():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return ''
        subscribe.arquivo.readline = Mock(side_effect=receber)
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config, registro]), \
                patch('rede.lerdadosserver.socket.socket', return_value=subscribe), patch('builtins.print'):
            tarefa = self.iniciar_loop()
            try:
                self.assertTrue(entrou.wait(3))
                yield subscribe
            finally:
                self.leitor.parar()
                liberar.set()
                self.terminar(tarefa)

    def test_01_CONFIG_antes_parada(self):
        self.leitor.ip_servidor = 'simulado'
        config = self.config()
        config.arquivo.readline.side_effect = self.parar_com_config
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config]), patch('builtins.print'):
            self.leitor._manter_atualizado()
        config.sendall.assert_called_once_with(b'CONFIG\n')
        self.assertTrue(self.leitor.configuracao_pronta.is_set())
        self.assertTrue(all(r['encerramento_confirmado'] for r in self.recursos()))

    def test_02_CONFIG_depois_parada_checagem_impede_entrada(self):
        self.leitor.ip_servidor = 'simulado'
        self.leitor.parar()
        with patch.object(self.leitor.recursos_cliente, 'conectar_tcp') as conectar:
            self.leitor._manter_atualizado()
        conectar.assert_not_called()
        self.assertEqual([], self.recursos())

    def test_03_A_CONFIG_entre_checagem_e_primeira_reserva(self):
        self.leitor.ip_servidor = 'simulado'
        entrou, liberar = threading.Event(), threading.Event()
        config = self.config()
        def resolver(*args):
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return self.enderecos()
        with patch('socket.getaddrinfo', side_effect=resolver), \
                patch('socket.socket', return_value=config) as alocar, patch('builtins.print'):
            tarefa = self.iniciar_loop()
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual([], self.recursos())
                self.leitor.parar()
                self.negativo()
            finally:
                liberar.set()
                self.terminar(tarefa)
        # AC3-C6: operação aceita, primeira tentativa recusada após a parada.
        alocar.assert_not_called()
        config.sendall.assert_not_called()
        self.assertEqual([], self.recursos())
        self.assertEqual([], self.leitor.obter_operacoes_register()['operacoes'])

    def test_04_C_CONFIG_tentativa_endereco_seguinte_apos_parar(self):
        self.leitor.ip_servidor = 'simulado'
        primeiro, segundo = SocketLeituraFalso(), self.config()
        def falhar(*args):
            self.leitor.parar()
            raise ConnectionRefusedError('recusa_simulada')
        primeiro.connect.side_effect = falhar
        alocacoes = []
        def alocar(*args):
            alocacoes.append(self.leitor.executando)
            return primeiro if len(alocacoes) == 1 else segundo
        with patch('socket.getaddrinfo', return_value=self.enderecos(2)), \
                patch('socket.socket', side_effect=alocar), patch('builtins.print'):
            self.leitor._manter_atualizado()
        self.assertEqual([True], alocacoes)  # AC3-C6 recusa o segundo endereço.
        segundo.sendall.assert_not_called()
        self.assertEqual(1, len(self.recursos()))
        self.assertTrue(all(r['encerramento_confirmado'] for r in self.recursos()))

    def test_05_SUBSCRIBE_inicial_contrato_real(self):
        self.leitor.ip_servidor = 'simulado'
        config, registro, subscribe = self.config(), self.registro(), SocketLeituraFalso()
        subscribe.arquivo.readline = Mock(side_effect=lambda: (self.leitor.parar(), '')[-1])
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config, registro]), \
                patch('socket.socket', return_value=subscribe), patch('builtins.print'):
            self.leitor._manter_atualizado()
        subscribe.sendall.assert_called_once_with(b'SUBSCRIBE\n')
        prazos = [c.args[0] for c in subscribe.settimeout.call_args_list]
        self.assertEqual(5, prazos[0])
        self.assertTrue(all(0 < prazo <= 6 for prazo in prazos[1:]))
        subscribe.makefile.assert_called_once_with('r', encoding='utf-8')
        self.assertEqual(6, len(self.recursos()))

    def test_06_SUBSCRIBE_cria_apos_parada_antes_reserva(self):
        antes, _ = self.gap_subscribe()
        self.assertEqual(4, len(antes))

    def test_07_B_reconexao_SUBSCRIBE_nova_tentativa_apos_parada(self):
        antes, subs = self.gap_subscribe(reconexao=True)
        self.assertEqual(8, len(antes))
        subs[0].sendall.assert_called_once_with(b'SUBSCRIBE\n')
        self.assertEqual(2, len(self.leitor.obter_operacoes_register()['operacoes']))

    def test_08_SUBSCRIBE_antigo_pendente_parar_nao_e_termino(self):
        with self.leitura_pendente() as subscribe:
            self.leitor.parar()
            self.assertTrue(self.leitor.thread.is_alive())
            subscribe.shutdown.assert_called_once()
            self.assertTrue(subscribe.fechado)
            self.assertFalse(subscribe.arquivo.closed)
            self.assertTrue(self.negativo()['recursos_pendentes'])
            self.assertFalse(self.infra.observar_termino_leitores()[0]['termino_observado'])

    def test_09_UDP_retentativa_identidade_real(self):
        self.recuperar(resposta=False)
        associacao, = self.infra.obter_associacoes_retentativas()
        recurso, = self.recursos()
        self.assertEqual('socket_udp', recurso['tipo'])
        self.assertEqual(associacao['retentativa_id'], recurso['retentativa_id'])
        self.assertEqual(associacao['geracao_id'], recurso['geracao_id'])

    def test_10_CHECK_TCP_retentativa_mesma_origem(self):
        self.recuperar(resposta=False, udp=self.resposta_udp())
        associacao, = self.infra.obter_associacoes_retentativas()
        self.assertEqual(['socket_udp', 'socket_tcp'], [r['tipo'] for r in self.recursos()])
        self.assertEqual({r['recurso_id'] for r in associacao['recursos']}, {r['recurso_id'] for r in self.recursos()})
        self.assertTrue(all(r['retentativa_id'] == associacao['retentativa_id'] for r in self.recursos()))

    def test_11_descoberta_preparacao_independente(self):
        dono = self.infra.preparar_descoberta()
        self.buscar(dono, self.resposta_udp())
        self.assertTrue(all(r['geracao_id'] == dono.geracao_id for r in self.recursos()))
        self.assertNotEqual(self.leitor.recursos_cliente.geracao_id, dono.geracao_id)
        self.assertEqual([], self.infra.obter_associacoes_retentativas())

    def test_12_UDP_novo_apos_cancelamento_na_lacuna_da_checagem(self):
        buscar = busca.buscar_servidor
        vistos = []
        def depois_da_checagem(**kwargs):
            self.leitor.parar()
            vistos.append(len(self.recursos()))
            return buscar(**kwargs)
        with patch('rede.lerdadosserver.buscar_servidor', side_effect=depois_da_checagem):
            udp, _ = self.recuperar(resposta=False)
        self.assertEqual([0], vistos)
        self.assertEqual(1, len(self.recursos()))
        udp.sendto.assert_called_once()
        self.negativo()

    def test_13_E_promocao_A_pendente_B_independente(self):
        with self.leitura_pendente():
            origem = self.leitor.recursos_cliente.geracao_id
            antigos = {r['recurso_id'] for r in self.recursos()}
            self.promover_real()
            novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
            recente = novo.recursos_cliente.abrir_socket(SocketLeituraFalso)
            recente.close()
            self.assertNotEqual(origem, novo.recursos_cliente.geracao_id)
            resultado = self.negativo()
            self.assertTrue(set(resultado['recursos_pendentes']) & antigos)
            self.assertTrue(all(r['geracao_id'] == origem for r in self.recursos() if r['recurso_id'] in antigos))
            self.assertTrue(all(r['modo_atual'] == 'cliente' for r in self.recursos()))

    def test_14_B_nao_reabre_admissao_REGISTER_A(self):
        self.leitor.parar()
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.assertTrue(self.leitor.obter_operacoes_register()['admissao_fechada'])
        self.assertFalse(novo.obter_operacoes_register()['admissao_fechada'])
        self.assertIsNone(self.leitor._admissao_register.admitir())
        self.assertIsNotNone(novo._admissao_register.admitir())
        self.assertFalse(self.infra.registro_recursos.obter_retrato()['admissao_fechada'])

    def test_15_REGISTER_previamente_admitido_continua_valido(self):
        token = self.leitor._admissao_register.admitir()
        self.leitor.parar()
        bruto = self.registro()
        with self.leitor._admissao_register.executar(token) as dono:
            dono.registrar_cliente(lambda: bruto, self.leitor.nome_computador, json.loads)
        bruto.sendall.assert_called_once()
        self.assertTrue(self.leitor.obter_operacoes_register()['operacoes'][0]['responsabilidade_resolvida'])
        self.assertIsNone(self.leitor._admissao_register.admitir())

    def test_16_global_nunca_completo_com_inventario_vazio(self):
        self.leitor.parar()
        self.assertEqual([], self.recursos())
        self.negativo()

    def test_17_gate_recursos_fecha_CONFIG_antes_reserva(self):
        self.leitor.ip_servidor = 'simulado'
        def resolver(*args):
            self.leitor.parar()
            self.infra.registro_recursos.fechar_admissao()
            return self.enderecos()
        with patch('socket.getaddrinfo', side_effect=resolver), patch('socket.socket') as alocar:
            self.leitor._manter_atualizado()
        alocar.assert_not_called()
        self.assertEqual([], self.recursos())

    def test_18_CONFIG_helper_direto_sem_autoridade_de_parada(self):
        self.leitor.parar()
        bruto = self.config()
        self.leitor.recursos_cliente.ler_configuracao(lambda: bruto, json.loads)
        bruto.sendall.assert_called_once_with(b'CONFIG\n')
        self.assertEqual(2, len(self.recursos()))
        self.assertEqual([], self.infra.obter_atividades_permanentes()['atividades'])

    def test_19_SUBSCRIBE_reserva_previa_alocacao_tardia_nao_se_perde(self):
        antes, _ = self.gap_subscribe(reserva_previa=True)
        self.assertTrue(antes[-1]['criacao_em_curso'])
        self.assertFalse(antes[-1]['criacao_resolvida'])

    def test_20_CHECK_de_busca_em_curso_depois_parar(self):
        vistos = []
        udp = self.resposta_udp(antes=self.leitor.parar)
        tcp = SocketDescobertaFalso()
        tcp.connect.side_effect = lambda *args: vistos.append((self.leitor.executando, len(self.recursos())))
        self.recuperar(resposta=False, udp=udp, tcp=tcp)
        self.assertEqual([(False, 2)], vistos)
        self.assertEqual(2, len(self.recursos()))
        self.negativo()

    def test_21_D_guarda_fecha_durante_busca_recusa_novo_CHECK(self):
        pendentes = []
        def promover():
            self.guarda.fechar_admissao()
            pendentes.extend(self.recursos())
            self.promover_real()
        udp = self.resposta_udp(antes=promover)
        tcp = SocketDescobertaFalso()
        self.recuperar(resposta=False, udp=udp, tcp=tcp)
        self.assertTrue(self.guarda.obter_retrato()['admissao_fechada'])
        tcp.connect.assert_not_called()  # AC3-C5: cancelamento da própria retry.
        associacao, = self.infra.obter_associacoes_retentativas()
        self.assertEqual(1, len(associacao['recursos']))
        self.assertEqual({associacao['geracao_id']}, {r['geracao_id'] for r in self.recursos()})
        self.assertFalse(pendentes[0]['encerramento_confirmado'])
        self.assertFalse(self.leitor.executando)

    def test_22_C_CHECK_repetido_depois_cancelamento(self):
        udp, tcp_a, tcp_b = SocketDescobertaFalso(), SocketDescobertaFalso(), SocketDescobertaFalso()
        tcp_a.recv.return_value = b'NAO_CONFIRMADO'
        respostas = []
        def receber(*args):
            respostas.append(True)
            if len(respostas) == 2:
                self.leitor.parar()
            return b'TC420_SERVER_HERE', ('simulado', 42101)
        udp.recvfrom.side_effect = receber
        vistos = []
        tcp_b.connect.side_effect = lambda *args: vistos.append(self.leitor.executando)
        self.preparar()
        self.partir()
        tcps = iter([tcp_a, tcp_b])
        with patch('socket.socket', side_effect=lambda familia, tipo: udp if tipo == socket.SOCK_DGRAM else next(tcps)), \
                patch('builtins.print'):
            self.threads[-1].target()
        self.assertEqual([False], vistos)
        self.assertEqual(3, len(self.recursos()))
        self.assertEqual(3, len(self.infra.obter_associacoes_retentativas()[0]['recursos']))

    def test_23_parar_leitor_nao_cancela_preparacao_da_aplicacao(self):
        origem_leitor = self.leitor.recursos_cliente.geracao_id
        self.leitor.parar()
        with patch('socket.socket', return_value=SocketDescobertaFalso()):
            self.assertIsNone(busca.buscar_servidor(infraestrutura_cliente=self.infra))
        self.assertNotEqual(origem_leitor, self.recursos()[0]['geracao_id'])
        self.assertEqual([], self.infra.obter_associacoes_retentativas())

    def test_24_guarda_fechada_recusa_nova_preparacao(self):
        self.guarda.fechar_admissao()
        with patch('socket.socket') as alocar:
            with self.assertRaises(RuntimeError):
                busca.buscar_servidor(infraestrutura_cliente=self.infra)
        alocar.assert_not_called()

    def test_25_preparacao_existente_sobrevive_gate_da_guarda(self):
        dono = self.infra.preparar_descoberta()
        self.guarda.fechar_admissao()
        self.buscar(dono)
        self.assertEqual(dono.geracao_id, self.recursos()[0]['geracao_id'])
        self.assertTrue(self.recursos()[0]['encerramento_confirmado'])

    def test_26_gate_recursos_recusa_UDP_novo(self):
        dono = self.infra.preparar_descoberta()
        self.infra.registro_recursos.fechar_admissao()
        with patch('socket.socket') as alocar:
            with self.assertRaises(RuntimeError):
                busca.buscar_servidor(recursos_cliente=dono)
        alocar.assert_not_called()
        self.assertEqual([], self.recursos())

    def test_27_recurso_ja_reservado_publica_depois_gate_fechar(self):
        entrou, liberar = threading.Event(), threading.Event()
        udp, erros_esperados = SocketDescobertaFalso(), []
        def fabrica():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return udp
        def executar():
            try:
                self.leitor.recursos_cliente.executar_descoberta('socket_udp', fabrica, lambda c: c.sendto(b'simulado', ('simulado', 1)))
            except RuntimeError as erro:
                erros_esperados.append(type(erro))
        tarefa = self.tarefa(executar)
        try:
            self.assertTrue(entrou.wait(3))
            token = self.recursos()[0]['recurso_id']
            self.infra.registro_recursos.fechar_admissao()
            self.assertIn(token, self.negativo()['recursos_pendentes'])
        finally:
            liberar.set()
            self.terminar(tarefa)
        self.assertEqual([RuntimeError], erros_esperados)
        udp.sendto.assert_not_called()  # usar é recusado; cleanup compensa criação tardia.
        self.assertTrue(self.recursos()[0]['encerramento_confirmado'])

    def test_28_F_recursos_resolvidos_thread_nao_observada(self):
        self.leitor.ip_servidor = 'simulado'
        config = self.config()
        config.arquivo.readline.side_effect = self.parar_com_config
        self.leitor.executando = False
        with patch('rede.lerdadosserver.threading.Thread', side_effect=self.fabricar):
            self.leitor.iniciar()
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config]), patch('builtins.print'):
            self.threads[-1].target()
        atividade, = self.infra.obter_atividades_permanentes()['atividades']
        self.assertTrue(atividade['retorno'])
        self.assertFalse(atividade['thread_terminada'])
        self.assertTrue(all(r['encerramento_confirmado'] for r in self.recursos()))
        # AC3-D1 inclui a atividade cujo término ainda não foi observado.
        self.assertFalse(self.negativo()['responsabilidades_conhecidas_resolvidas'])
        self.threads[-1].is_alive.assert_not_called()

    def test_29_consulta_passiva_com_leitura_pendente(self):
        with self.leitura_pendente():
            antes = (self.recursos(), self.infra.obter_atividades_permanentes(),
                     self.leitor.obter_operacoes_register(), self.guarda.obter_retrato())
            with patch.object(type(self.infra), 'observar_termino_leitores', side_effect=AssertionError('implicito')) as observar:
                self.negativo()
            observar.assert_not_called()
            self.assertEqual(antes, (self.recursos(), self.infra.obter_atividades_permanentes(),
                                    self.leitor.obter_operacoes_register(), self.guarda.obter_retrato()))

    def test_30_CONFIG_producao_so_no_corpo_permanente(self):
        encontrados = []
        chamadores = []
        for nome in ('main.py', 'interface/conexao.py', 'interface/janela.py', 'rede/lerdadosserver.py'):
            raiz = ast.parse((RAIZ / nome).read_text(encoding='utf-8'))
            for funcao in ast.walk(raiz):
                if isinstance(funcao, ast.FunctionDef):
                    for no in ast.walk(funcao):
                        if isinstance(no, ast.Call) and isinstance(no.func, ast.Attribute) and no.func.attr == 'ler_configuracao':
                            encontrados.append((nome, funcao.name))
                        if isinstance(no, ast.Call) and isinstance(no.func, ast.Attribute) and no.func.attr == '_consultar_configuracao':
                            chamadores.append((nome, funcao.name))
        self.assertEqual([('rede/lerdadosserver.py', '_consultar_configuracao')], encontrados)
        self.assertEqual([('rede/lerdadosserver.py', '_manter_atualizado')] * 2, chamadores)

    def test_31_promocao_tem_autoridade_distinta_do_leitor(self):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        fx.env['LeitorDadosServidor'] = lambda **kwargs: self.leitor
        self.leitor.aguardar_configuracao = Mock(return_value=None)
        fx.env['buscar_servidor'] = busca.buscar_servidor
        tentativas = RegistroTentativasAplicacao()
        resultados = []
        fx.durante_monitor = lambda monitor: resultados.append(monitor.ao_promover('simulado', '', ''))
        with patch('socket.socket', side_effect=lambda *args: SocketDescobertaFalso()), patch('builtins.print'):
            fx.env['iniciar_como_cliente']('simulado', registro_tentativas=tentativas, infraestrutura_cliente=self.infra)
        self.assertIsNotNone(resultados[0])
        self.assertEqual(self.leitor.recursos_cliente.geracao_id, self.recursos()[0]['geracao_id'])
        self.assertEqual([], self.infra.obter_associacoes_retentativas())
        self.assertEqual(1, len(tentativas.obter_retrato()['tentativas']))

    def test_32_promocao_recusada_nao_inicia_descoberta(self):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        fx.env['LeitorDadosServidor'] = lambda **kwargs: self.leitor
        self.leitor.aguardar_configuracao = Mock(return_value=None)
        tentativas = RegistroTentativasAplicacao()
        tentativas.fechar_admissao()
        fx.durante_monitor = lambda monitor: self.assertIsNone(monitor.ao_promover('simulado', '', ''))
        with patch('builtins.print'):
            fx.env['iniciar_como_cliente']('simulado', registro_tentativas=tentativas, infraestrutura_cliente=self.infra)
        fx.env['buscar_servidor'].assert_not_called()
        self.assertEqual([], self.recursos())

    def test_33_descoberta_inicial_alvo_entra_depois_parar(self):
        self.leitor.executando = False
        with patch('rede.lerdadosserver.threading.Thread', side_effect=self.fabricar):
            self.leitor.iniciar()
        self.leitor.parar()
        udp = SocketDescobertaFalso()
        with patch('socket.socket', return_value=udp) as fabrica, patch('builtins.print'):
            self.threads[-1].target()
        # AC3-C4 corrigiu esta reprodução: alvo tardio recusa a entrada inicial.
        fabrica.assert_not_called()
        udp.sendto.assert_not_called()
        self.assertEqual([], self.recursos())
        self.assertEqual([], self.infra.obter_associacoes_retentativas())
        self.assertFalse(self.leitor.obter_operacoes_register()['operacoes'])
        self.negativo()

    def test_34_candidatura_busca_na_lacuna_apos_checagem(self):
        self.leitor.posicao_sucessao = 1
        buscar = busca.buscar_servidor
        def depois_da_checagem(**kwargs):
            self.leitor.parar()
            return buscar(**kwargs)
        udp = SocketDescobertaFalso()
        with patch('rede.lerdadosserver.buscar_servidor', side_effect=depois_da_checagem), \
                patch('socket.socket', return_value=udp), patch('time.monotonic', return_value=0), patch('builtins.print'):
            self.assertFalse(self.leitor._aguardar_candidatura())
        udp.sendto.assert_called_once()
        self.assertEqual(self.leitor.recursos_cliente.geracao_id, self.recursos()[0]['geracao_id'])

    def test_35_guarda_fecha_mas_retry_aceita_pode_repetir_UDP(self):
        primeiro, segundo = SocketDescobertaFalso(), SocketDescobertaFalso()
        def encerrar_guarda(*args):
            self.guarda.fechar_admissao()
            raise socket.timeout('simulado')
        primeiro.recvfrom.side_effect = encerrar_guarda
        self.preparar()
        self.partir()
        self.leitor._parada = Mock()
        self.leitor._parada.wait.side_effect = [False, True]
        with patch('socket.socket', side_effect=[primeiro, segundo]), \
                patch('time.monotonic', return_value=0), patch('builtins.print'):
            self.threads[-1].target()
        self.assertTrue(self.guarda.obter_retrato()['admissao_fechada'])
        self.assertEqual(2, len(self.recursos()))
        self.assertEqual(2, len(self.infra.obter_associacoes_retentativas()[0]['recursos']))
        self.assertNotEqual(self.recursos()[0]['recurso_id'], self.recursos()[1]['recurso_id'])
        self.assertTrue(self.leitor.executando)

    def test_36_parent_SUBSCRIBE_fechado_recusa_makefile_novo(self):
        self.leitor.ip_servidor = 'simulado'
        config, registro, subscribe = self.config(), self.registro(), SocketLeituraFalso()
        subscribe.settimeout.side_effect = lambda valor: self.leitor.parar() if valor != 5 else None
        with conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config, registro]), \
                patch('socket.socket', return_value=subscribe), patch('builtins.print'):
            self.leitor._manter_atualizado()
        subscribe.sendall.assert_called_once_with(b'SUBSCRIBE\n')
        subscribe.shutdown.assert_called_once()
        subscribe.makefile.assert_not_called()
        self.assertEqual(5, len(self.recursos()))  # CONFIG/REGISTER + TCP sem arquivo novo.
        self.assertTrue(self.recursos()[-1]['encerramento_confirmado'])
        self.negativo()

"""Investigação 2B.4 isolada, sem rede ou mudança operacional."""
import gc
import json
from pathlib import Path
import platform
import sys
import time
import tracemalloc
import weakref
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rede import servidor as s


def medir(tipo, total=50000):
    gc.collect()
    tracemalloc.start()
    inicio = time.perf_counter()
    c = s.ControleCicloServidor()
    r = s.RegistroTrabalhadores()
    c.tentar_iniciar(r)
    for _ in range(total):
        t = r.reservar_criacao_socket()
        r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True)
    raiz = (t if tipo == 'token_externo' else r if tipo == 'registro_externo'
            else r.obter_situacao() if tipo == 'diagnostico_externo' else None)
    del t
    referencia = weakref.ref(r)
    r.bloquear_criacao()
    assert c.finalizar(r)
    del r
    gc.collect()
    antes, pico_antes = tracemalloc.get_traced_memory()
    assert c._compactar_ciclo(1)
    assert c._compactar_ciclo(1)
    gc.collect()
    depois, pico_depois = tracemalloc.get_traced_memory()
    ainda_retido = referencia() is not None
    if tipo == 'token_externo':
        assert raiz.dono.fechar_socket(raiz) is True
        assert raiz.dono.publicar_limpeza_handler(raiz) is False
        assert len(raiz.dono.obter_situacao()['criacoes_socket']) == total
    assert c._obter_situacao_historica(1)['encerramento_confirmado'] is True
    del raiz
    gc.collect()
    apos_soltar_raiz, _ = tracemalloc.get_traced_memory()
    coletado_sem_raiz = referencia() is None
    tracemalloc.stop()
    return dict(cenario=tipo, reservas=total, bytes_antes=antes, bytes_depois=depois,
        pico_antes=pico_antes, pico_ate_compactacao=pico_depois,
        registro_retido_apos_compactacao=ainda_retido,
        bytes_apos_soltar_raiz=apos_soltar_raiz,
        registro_coletado_sem_raiz=coletado_sem_raiz,
        segundos=time.perf_counter()-inicio)


def investigar_contratos():
    c, r = s.ControleCicloServidor(), s.RegistroTrabalhadores()
    c.tentar_iniciar(r)
    t = r.reservar_criacao_socket()
    assert not c._compactar_ciclo(1)
    r.bloquear_criacao()
    c.finalizar(r)
    assert not c._compactar_ciclo(1)  # Reserva ainda não resolvida.
    r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True)
    antes = c._obter_situacao_historica(1)
    assert c._compactar_ciclo(1)
    assert c._obter_situacao_historica(1) == antes
    ctx = s.ContextoCicloServidor()
    ctx.registrar_reserva(1)
    ctx.registrar_retorno_coordenador()
    with patch.object(s, 'controle_ciclo_servidor', c), patch.object(s, 'evento_parada_servidor', __import__('threading').Event()):
        assert s.avaliar_encerramento_tentativa(ctx)['encerramento_confirmado'] is True
        assert s.consultar_estado_ciclo_servidor(1)['trabalhadores_encerrados'] is True
        try:
            s.solicitar_parada_ciclo(1)
        except AttributeError:
            parada_tardia = 'AttributeError: resumo nao possui bloquear_criacao'
        else:
            raise AssertionError('Reavaliar incompatibilidade: comportamento mudou')
        assert c.tentar_iniciar(s.RegistroTrabalhadores())
        assert s.solicitar_parada_ciclo(1) is False
        assert s.avaliar_encerramento_tentativa(ctx)['encerramento_confirmado'] is True
    return dict(historico_equivalente=True, avaliacao_contexto_confirmada=True,
                pendencia_impede_compactacao=True, parada_tardia_ciclo_atual=parada_tardia,
                parada_ciclo_antigo_apos_novo=False)


if __name__ == '__main__':
    print(json.dumps(dict(python=platform.python_version(), plataforma=sys.platform,
        contratos=investigar_contratos(), medicoes=[medir(t) for t in
            ('sem_raiz_externa', 'token_externo', 'registro_externo', 'diagnostico_externo')],
        limites='Reservas sinteticas sem alocacao. Tracemalloc nao e RSS; GC explicito.'), indent=2))

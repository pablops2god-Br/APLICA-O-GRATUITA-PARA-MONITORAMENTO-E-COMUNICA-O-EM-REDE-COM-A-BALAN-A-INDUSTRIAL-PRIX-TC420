# Testes de preparacoes cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-D3-A: descoberta sem leitor, registros reais e transporte falso."""
import ast
from pathlib import Path
import threading
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from config.arquivos import ContextoArquivosConfiguracao
from rede import buscarservidor as busca
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.lerdadosserver import LeitorDadosServidor
from test_descoberta_cliente_integrada import SocketDescobertaFalso
import test_infraestrutura_cliente as montagem


# Grupo de 35 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class PreparacoesCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_preparacoes

    def retrato(self):
        r = self.infra.obter_preparacoes()
        self.assertFalse(r['encerramento_cliente_confirmado'])
        self.assertFalse(r['encerramento_global_confirmado'])
        self.assertFalse(r['snapshot_atomico'])
        return r

    def item(self, indice=0):
        return self.retrato()['preparacoes'][indice]

    def descobrir(self, sucesso=False):
        udp, tcp = SocketDescobertaFalso(), SocketDescobertaFalso()
        if sucesso:
            udp.recvfrom.side_effect = [(b'TC420_SERVER_HERE', ('principal-simulado', 42101))]
        with patch('socket.socket', side_effect=[udp, tcp]):
            resultado = busca.buscar_servidor(infraestrutura_cliente=self.infra)
        return resultado, udp, tcp

    def trabalho(self, chamada):
        resultados, erros = [], []
        def alvo():
            try:
                resultados.append(chamada())
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=alvo)
        thread.start()
        return thread, resultados, erros

    def concluir(self, tarefa):
        tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())

    def test_01_preparacao_normal(self):
        self.descobrir()
        i = self.item()
        self.assertEqual(1, i['preparacao_id'])
        self.assertEqual('buscar_servidor.sem_leitor', i['origem'])
        self.assertTrue(i['execucao_resolvida'])
        self.assertEqual('retorno', i['resultado'])
        self.assertEqual(self.infra.aplicacao_id, self.retrato()['aplicacao_id'])

    def test_02_antes_UDP_visivel(self):
        def operacao(dono):
            i = self.item()
            self.assertTrue(i['em_curso'])
            self.assertEqual([], i['recursos'])
            self.assertEqual(dono.geracao_id, i['origem_recursos']['geracao_id'])
            self.assertFalse(i['execucao_resolvida'])
        self.infra.executar_descoberta_preparacao(operacao)

    def test_03_reservada_nao_iniciada(self):
        token = self.registro.admitir()
        i = self.item()
        self.assertEqual(token.numero, i['preparacao_id'])
        self.assertFalse(i['iniciada'])
        self.assertFalse(i['execucao_resolvida'])
        self.assertIsNone(i['origem_recursos'])

    def test_04_falha_antes_UDP(self):
        erro = ValueError('falha_simulada')
        with patch.object(InfraestruturaRegistrosCliente, 'preparar_descoberta', side_effect=erro):
            with self.assertRaises(ValueError) as recebido:
                busca.buscar_servidor(infraestrutura_cliente=self.infra)
        self.assertIs(erro, recebido.exception)
        self.assertEqual('falha', self.item()['resultado'])
        self.assertEqual({'categoria': 'falha_operacao'}, self.item()['erro_operacional'])
        self.assertEqual([], self.item()['recursos'])

    def test_05_falha_criacao_UDP(self):
        erro = OSError('alocacao_simulada')
        with patch('socket.socket', side_effect=erro):
            with self.assertRaises(OSError) as recebido:
                busca.buscar_servidor(infraestrutura_cliente=self.infra)
        self.assertIs(erro, recebido.exception)
        self.assertEqual('falha', self.item()['resultado'])
        self.assertEqual(1, len(self.item()['recursos']))
        self.assertFalse(self.item()['recursos_conhecidos_resolvidos'])

    def test_06_descoberta_bem_sucedida(self):
        resultado, udp, tcp = self.descobrir(sucesso=True)
        self.assertEqual('principal-simulado', resultado)
        self.assertEqual('retorno', self.item()['resultado'])
        self.assertTrue(self.item()['recursos_conhecidos_resolvidos'])
        self.assertEqual(2, len(self.item()['recursos']))
        udp.sendto.assert_called_once_with(b'TC420_SERVER_DISCOVERY', ('255.255.255.255', 42101))
        tcp.sendall.assert_called_once_with(b'CHECK\n')
        udp.settimeout.assert_called_once_with(2)
        tcp.settimeout.assert_called_once_with(2)
        tcp.connect.assert_called_once_with(('principal-simulado', 42100))

    def test_07_sem_PRINCIPAL(self):
        resultado, udp, tcp = self.descobrir()
        self.assertIsNone(resultado)
        self.assertTrue(udp.fechado)
        tcp.connect.assert_not_called()
        self.assertTrue(self.item()['execucao_resolvida'])

    def test_08_publicacao_falha_conservadora(self):
        erro = RuntimeError('publicacao_simulada')
        with patch.object(self.registro, '_publicar_resultado', side_effect=erro):
            with self.assertRaises(RuntimeError) as recebido:
                self.descobrir()
        self.assertIs(erro, recebido.exception)
        self.assertTrue(self.item()['erro_publicacao'])
        self.assertFalse(self.item()['execucao_resolvida'])
        self.assertIsNone(self.item()['resultado'])

    def test_09_retorno_com_recurso_pendente(self):
        fechar = self.infra.registro_recursos.fechar
        tokens = []
        def reter(token):
            tokens.append(token)
            return False
        with patch.object(self.infra.registro_recursos, 'fechar', side_effect=reter):
            self.descobrir()
        for token in tokens:
            self.addCleanup(fechar, token)
        self.assertTrue(self.item()['execucao_resolvida'])
        self.assertFalse(self.item()['recursos_conhecidos_resolvidos'])
        self.assertTrue(self.item()['recursos_pendentes'])
        r = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(r['responsabilidades_conhecidas_resolvidas'])
        self.assertFalse(r['encerramento_global_confirmado'])

    def test_10_HTTP_permanece_independente(self):
        def operacao(dono):
            contexto = self.infra.preparar_http_inicial()
            op = self.infra.registro_http.admitir(contexto, 'approval')
            self.infra.registro_http.executar(op, lambda: None)
        # Composicao sintetica de operacoes para verificar isolamento, nao mudar fluxo real.
        self.infra.executar_descoberta_preparacao(operacao)
        http, = self.infra.registro_http.obter_retrato()['operacoes']
        self.assertTrue(http['execucao_resolvida'])
        self.assertNotEqual(http['geracao_id'], self.item()['origem_recursos']['geracao_id'])
        self.assertEqual([], self.item()['recursos'])

    def test_11_JSON_propriedade_aplicacao(self):
        contexto = ContextoArquivosConfiguracao(self.infra)
        arquivo = Mock(closed=False)
        arquivo.close.side_effect = lambda: setattr(arquivo, 'closed', True)
        def operacao(dono):
            contexto.executar(lambda: arquivo, lambda f: None)
        self.infra.executar_descoberta_preparacao(operacao)
        historico, = contexto.obter_historico()
        self.assertNotEqual(historico['geracao_id'], self.item()['origem_recursos']['geracao_id'])
        self.assertEqual([], self.item()['recursos'])
        self.assertTrue(historico['limpeza_comprovada'])
        self.assertIs(contexto._proprietario, self.infra)

    def test_12_promocao_preserva_origem(self):
        def operacao(dono):
            antes = self.item()['origem_recursos']
            self.infra.registro_retentativas.promover(dono._geracao_retentativas)
            self.infra.registro_recursos.promover(dono.geracao_id)
            self.assertEqual(antes, self.item()['origem_recursos'])
            self.assertTrue(self.item()['em_curso'])
        self.infra.executar_descoberta_preparacao(operacao)
        self.assertTrue(self.item()['execucao_resolvida'])

    def test_13_nova_identidade(self):
        self.descobrir()
        self.descobrir()
        a, b = self.retrato()['preparacoes']
        self.assertNotEqual(a['preparacao_id'], b['preparacao_id'])
        self.assertNotEqual(a['origem_recursos'], b['origem_recursos'])

    def test_14_antiga_reservada_continua_pendente(self):
        token = self.registro.admitir()
        self.descobrir()
        self.assertEqual(token.numero, self.item()['preparacao_id'])
        self.assertFalse(self.item()['execucao_resolvida'])
        self.assertTrue(self.item(1)['execucao_resolvida'])

    def test_15_consulta_dentro_execucao(self):
        def operacao(dono):
            a, b = self.retrato(), self.retrato()
            self.assertEqual(a, b)
            self.assertTrue(a['preparacoes'][0]['em_curso'])
        self.infra.executar_descoberta_preparacao(operacao)

    def test_16_aplicacao_global_nao_confirmada(self):
        self.descobrir(sucesso=True)
        r = self.infra.avaliar_responsabilidades_cliente()
        self.assertTrue(self.item()['execucao_resolvida'])
        self.assertFalse(r['encerramento_cliente_confirmado'])
        self.assertFalse(r['encerramento_global_confirmado'])
        self.assertEqual('incompleta', r['cobertura_operacional'])

    def test_corrida_A_antes_UDP(self):
        entrou, liberar = threading.Event(), threading.Event()
        reservar = self.infra.registro_recursos.reservar
        def pausa(*args, **kwargs):
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return reservar(*args, **kwargs)
        with patch.object(self.infra.registro_recursos, 'reservar', side_effect=pausa), \
                patch('socket.socket', return_value=SocketDescobertaFalso()):
            tarefa = self.trabalho(lambda: busca.buscar_servidor(infraestrutura_cliente=self.infra))
            try:
                self.assertTrue(entrou.wait(3))
                self.assertTrue(self.item()['em_curso'])
                self.assertFalse(self.item()['execucao_resolvida'])
                self.assertEqual([], self.item()['recursos'])
            finally:
                liberar.set()
                self.concluir(tarefa)
        self.assertEqual([], tarefa[2])

    def test_corrida_B_reserva_antes_execucao(self):
        reservado, liberar = threading.Event(), threading.Event()
        def rotina():
            token = self.registro.admitir()
            reservado.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            self.registro.executar(token, lambda: None)
        tarefa = self.trabalho(rotina)
        try:
            self.assertTrue(reservado.wait(3))
            self.assertFalse(self.item()['iniciada'])
            self.assertFalse(self.item()['execucao_resolvida'])
        finally:
            liberar.set()
            self.concluir(tarefa)
        self.assertEqual([], tarefa[2])
        self.assertTrue(self.item()['execucao_resolvida'])

    def test_corrida_C_falha_antes_recurso_sem_socket(self):
        erro = KeyboardInterrupt('base_simulada')
        with patch('socket.socket') as fabrica:
            with self.assertRaises(KeyboardInterrupt) as recebido:
                self.infra.executar_descoberta_preparacao(Mock(side_effect=erro))
        fabrica.assert_not_called()
        self.assertIs(erro, recebido.exception)
        self.assertEqual([], self.item()['recursos'])
        self.assertEqual({'categoria': 'falha_base'}, self.item()['erro_operacional'])

    def test_corrida_D_publicacao_retardada(self):
        entrou, liberar = threading.Event(), threading.Event()
        publicar = self.registro._publicar_resultado
        def pausa(*args):
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return publicar(*args)
        with patch.object(self.registro, '_publicar_resultado', side_effect=pausa):
            tarefa = self.trabalho(lambda: self.infra.executar_descoberta_preparacao(lambda dono: 17))
            try:
                self.assertTrue(entrou.wait(3))
                self.assertTrue(self.item()['publicacao_em_curso'])
                self.assertFalse(self.item()['execucao_resolvida'])
            finally:
                liberar.set()
                self.concluir(tarefa)
        self.assertEqual([], tarefa[2])
        self.assertEqual([17], tarefa[1])
        self.assertTrue(self.item()['execucao_resolvida'])

    def test_corrida_E_promocao_com_antiga_pendente(self):
        entrou, liberar = threading.Event(), threading.Event()
        donos = []
        def operacao(dono):
            donos.append(dono)
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
        tarefa = self.trabalho(lambda: self.infra.executar_descoberta_preparacao(operacao))
        try:
            self.assertTrue(entrou.wait(3))
            antes = self.item()['origem_recursos']
            self.infra.registro_retentativas.promover(donos[0]._geracao_retentativas)
            self.descobrir()
            self.assertEqual(antes, self.item()['origem_recursos'])
            self.assertFalse(self.item()['execucao_resolvida'])
            self.assertTrue(self.item(1)['execucao_resolvida'])
        finally:
            liberar.set()
            self.concluir(tarefa)
        self.assertEqual([], tarefa[2])

    def test_corrida_F_duas_preparacoes_independentes(self):
        # Login automatico e conectar manual reais por AST, sem construir Tk.
        env = montagem.carregar_fluxos()
        env['buscar_servidor'] = busca.buscar_servidor
        arvore = ast.parse((Path(__file__).resolve().parents[1] / 'interface/conexao.py').read_text(encoding='utf-8'))
        classe = next(n for n in arvore.body if isinstance(n, ast.ClassDef) and n.name == 'JanelaConexao')
        conectar = next(n for n in classe.body if isinstance(n, ast.FunctionDef) and n.name == '_conectar_operacional')
        manual = {'buscar_servidor': busca.buscar_servidor, 'print': Mock()}
        exec(compile(ast.Module(body=[conectar], type_ignores=[]), 'interface/conexao.py', 'exec'), manual)
        janela = SimpleNamespace(
            infraestrutura_cliente=self.infra, label_status=Mock(), root=Mock(),
            ao_encontrar_servidor=Mock(), salvar_login_var=Mock(get=Mock(return_value=False)))
        for nome in ('campo_nome', 'campo_ip', 'campo_usuario'):
            setattr(janela, nome, Mock(get=Mock(return_value='simulado')))
        janela.campo_porta = Mock(get=Mock(return_value='9800'))
        janela.campo_senha = Mock()  # Nao ha login HTTP neste ramo encontrado.
        ambos, liberar, lock = threading.Event(), threading.Event(), threading.Lock()
        reservar = self.infra.registro_recursos.reservar
        vistos = set()
        def pausa(*args, **kwargs):
            with lock:
                vistos.add(threading.get_ident())
                if len(vistos) == 2:
                    ambos.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return reservar(*args, **kwargs)
        def socket(familia, tipo):
            objeto = SocketDescobertaFalso()
            if tipo == busca.socket.SOCK_DGRAM:
                objeto.recvfrom.side_effect = [(b'TC420_SERVER_HERE', ('principal-simulado', 42101))]
            return objeto
        with patch.object(self.infra.registro_recursos, 'reservar', side_effect=pausa), \
                patch('socket.socket', side_effect=socket):
            a = self.trabalho(lambda: env['tentar_login_automatico'](infraestrutura_cliente=self.infra))
            b = self.trabalho(lambda: manual['_conectar_operacional'](janela, 'simulado', 'simulado', 9800, 'simulado', object(), False))
            try:
                self.assertTrue(ambos.wait(3))
                itens = self.retrato()['preparacoes']
                self.assertEqual(2, len(itens))
                self.assertEqual(2, len({i['preparacao_id'] for i in itens}))
                self.assertTrue(all(i['em_curso'] for i in itens))
                self.assertNotEqual(itens[0]['origem_recursos'], itens[1]['origem_recursos'])
            finally:
                liberar.set()
                self.concluir(a)
                self.concluir(b)
        self.assertEqual([], a[2] + b[2])
        self.assertEqual([{'modo': 'cliente', 'servidor': 'principal-simulado'}], a[1])
        self.assertEqual([{'servidor': 'principal-simulado'}], b[1])
        janela.ao_encontrar_servidor.assert_not_called()  # handoff pertence ao Tk
        self.assertTrue(all(i['execucao_resolvida'] for i in self.retrato()['preparacoes']))

    def test_adicional_lacuna_AC3D2_registro_corrigido_composicao_preservada(self):
        reservar = self.infra.registro_recursos.reservar
        def consultar(*args, **kwargs):
            self.assertTrue(self.item()['em_curso'])
            self.assertEqual([], self.item()['recursos'])
            r = self.infra.avaliar_responsabilidades_cliente()
            self.assertTrue(r['responsabilidades_conhecidas_resolvidas'])
            self.assertEqual('incompleta', r['cobertura_operacional'])
            self.assertFalse(r['encerramento_cliente_confirmado'])
            return reservar(*args, **kwargs)
        with patch.object(self.infra.registro_recursos, 'reservar', side_effect=consultar):
            self.descobrir()

    def test_sem_thread_geracao_leitor_retry_ou_REGISTER_artificial(self):
        with patch('threading.Thread', side_effect=AssertionError('thread_extra')):
            self.descobrir()
        self.assertEqual([], self.infra.obter_atividades_permanentes()['atividades'])
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()['retentativas'])
        self.assertEqual([], self.infra.obter_operacoes_register())
        with patch.object(self.infra.registro_retentativas, 'nova_geracao_cliente', wraps=
                          self.infra.registro_retentativas.nova_geracao_cliente) as nova:
            self.descobrir()
        self.assertEqual(1, nova.call_count)  # Somente o dono de recursos preexistente.

    def test_parar_leitor_nao_bloqueia_preparacao(self):
        leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        leitor.parar()
        self.descobrir(sucesso=True)
        self.assertTrue(self.item()['execucao_resolvida'])
        self.assertEqual('nao_estabelecida', self.retrato()['autoridade_encerramento'])

    def test_falhas_operacional_e_publicacao_preservam_original(self):
        original = ValueError('original_simulado')
        publicacao = RuntimeError('publicacao_simulada')
        with patch.object(self.registro, '_publicar_resultado', side_effect=publicacao):
            with self.assertRaises(ValueError) as recebido:
                self.infra.executar_descoberta_preparacao(Mock(side_effect=original))
        self.assertIs(original, recebido.exception)
        self.assertIs(publicacao, recebido.exception.__cause__)
        self.assertTrue(self.item()['erro_publicacao'])
        self.assertFalse(self.item()['execucao_resolvida'])
        self.assertEqual({'categoria': 'falha_operacao'}, self.item()['erro_operacional'])

    def test_falha_durante_descoberta_preserva_erro(self):
        udp = SocketDescobertaFalso()
        erro = RuntimeError('durante_descoberta')
        udp.recvfrom.side_effect = erro
        with patch('socket.socket', return_value=udp):
            with self.assertRaises(RuntimeError) as recebido:
                busca.buscar_servidor(infraestrutura_cliente=self.infra)
        self.assertIs(erro, recebido.exception)
        self.assertTrue(udp.fechado)
        self.assertEqual('falha', self.item()['resultado'])

    def test_token_estrangeiro_e_reexecucao_recusados(self):
        outro = InfraestruturaRegistrosCliente()
        estrangeiro = outro.registro_preparacoes.admitir()
        with self.assertRaises(ValueError):
            self.registro.executar(estrangeiro, Mock())
        token = self.registro.admitir()
        self.registro.executar(token, lambda: None)
        chamada = Mock()
        with self.assertRaises(RuntimeError):
            self.registro.executar(token, chamada)
        chamada.assert_not_called()

    def test_consulta_passiva_copias_sem_conteudo_operacional(self):
        self.descobrir()
        antes = self.retrato()
        with patch.object(self.registro, 'executar', side_effect=AssertionError()), \
                patch.object(self.registro, '_publicar_resultado', side_effect=AssertionError()), \
                patch.object(self.infra.registro_recursos, 'fechar', side_effect=AssertionError()):
            self.assertEqual(antes, self.retrato())
        copia = self.retrato()
        copia['preparacoes'][0]['origem_recursos']['geracao_id'] = 999
        self.assertEqual(antes, self.retrato())
        self.assertNotIn('principal-simulado', str(antes))

    def test_publicacao_parcial_nao_confirma(self):
        publicar = self.registro._publicar_resultado
        def parcial(*args):
            publicar(*args)
            raise OSError('apos_publicar')
        with patch.object(self.registro, '_publicar_resultado', side_effect=parcial):
            with self.assertRaises(OSError):
                self.descobrir()
        self.assertFalse(self.item()['retorno'])
        self.assertFalse(self.item()['execucao_resolvida'])

    def test_falha_vinculo_nao_resolve_recursos(self):
        with patch.object(self.registro, 'vincular_recursos', side_effect=RuntimeError()):
            with self.assertRaises(RuntimeError):
                self.descobrir()
        self.assertIsNone(self.item()['origem_recursos'])
        self.assertFalse(self.item()['recursos_conhecidos_resolvidos'])
        self.assertEqual('falha', self.item()['resultado'])

    def test_main_iniciar_encaminha_infraestrutura_real(self):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        fx.env['buscar_servidor'] = busca.buscar_servidor
        udp, tcp = SocketDescobertaFalso(), SocketDescobertaFalso()
        udp.recvfrom.side_effect = [(b'TC420_SERVER_HERE', ('principal-simulado', 42101))]
        with patch('socket.socket', side_effect=[udp, tcp]):
            fx.env['iniciar']()
        infra = fx.monitores[-1].infraestrutura_cliente
        preparacao, = infra.obter_preparacoes()['preparacoes']
        self.assertTrue(preparacao['execucao_resolvida'])
        self.assertEqual(2, len(preparacao['recursos']))
        self.assertIs(infra, fx.leitores[0].infraestrutura_cliente)

    def test_caminho_com_dono_existente_nao_inventa_preparacao(self):
        dono = self.infra.preparar_descoberta()
        with patch('socket.socket', return_value=SocketDescobertaFalso()):
            busca.buscar_servidor(recursos_cliente=dono, infraestrutura_cliente=self.infra)
        self.assertEqual([], self.retrato()['preparacoes'])

    def test_registro_sem_geracao_por_admissao(self):
        with patch.object(self.infra.registro_retentativas, 'nova_geracao_cliente', side_effect=AssertionError()):
            self.registro.admitir()
        self.assertEqual([], self.item()['recursos'])
        self.assertIsNone(self.item()['origem_recursos'])

    def test_sem_mudanca_politica_gate_global(self):
        self.infra.registro_retentativas.fechar_admissao()
        with patch('socket.socket') as fabrica:
            with self.assertRaisesRegex(RuntimeError, 'admissao_cliente_fechada'):
                busca.buscar_servidor(infraestrutura_cliente=self.infra)
        fabrica.assert_not_called()
        self.assertEqual('falha', self.item()['resultado'])
        self.assertEqual('nao_estabelecida', self.retrato()['autoridade_encerramento'])


if __name__ == '__main__':
    unittest.main()

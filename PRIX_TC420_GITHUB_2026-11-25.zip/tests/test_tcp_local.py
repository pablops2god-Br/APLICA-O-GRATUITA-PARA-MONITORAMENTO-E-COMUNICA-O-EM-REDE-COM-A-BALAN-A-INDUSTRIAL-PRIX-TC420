"""TCP local com frames sintéticos e sockets exclusivamente localhost."""
from contextlib import contextmanager
import socket
from threading import Event, Thread
from time import monotonic, sleep
from unittest import TestCase
from unittest.mock import Mock

from interface.saida_aplicacao import SaidaAplicacao
from rede.servidor import RegistroTentativasAplicacao
from rede.tcp_local import ErroTCPLocal, LeitorTCPLocal, conectar_local


@contextmanager
def balanca_local(blocos):
    fim = Event()
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind(('127.0.0.1', 0))
    listener.listen(1)
    listener.settimeout(2)
    porta = listener.getsockname()[1]
    def atender():
        try:
            with listener.accept()[0] as cliente:
                for bloco in blocos:
                    cliente.sendall(bloco)
                fim.wait(3)
        except OSError:
            pass
    thread = Thread(target=atender)
    thread.start()
    try:
        yield porta
    finally:
        fim.set()
        listener.close()
        thread.join(3)
        assert not thread.is_alive()


class TCPLocal(TestCase):
    def test_intervalo_de_seis_segundos_nao_produz_falsa_queda(self):
        from unittest.mock import patch
        leitor = LeitorTCPLocal('127.0.0.1', 9800)
        with patch('rede.tcp_local.monotonic', return_value=100) as relogio:
            leitor._publicar_peso(0)
            relogio.return_value = 106
            self.assertTrue(leitor.comunicacao_esta_atual())
            leitor._publicar_peso(0)  # Peso igual também é uma nova recepção válida.
            d = leitor.diagnostico()
            self.assertEqual((d['validos'], d['intervalo_ultimo_s'], d['intervalo_maximo_s']), (2, 6, 6))

    def test_leitura_do_monitor_nao_renova_idade_e_socket_parado_invalida_imediato(self):
        from unittest.mock import patch
        leitor = LeitorTCPLocal('127.0.0.1', 9800)
        with patch('rede.tcp_local.monotonic', return_value=100) as relogio:
            leitor._publicar_peso(0)
            relogio.return_value = 111
            self.assertEqual(leitor.obter_dados_atuais()['peso_liquido'], '0')
            self.assertFalse(leitor.comunicacao_esta_atual())
            leitor._publicar_peso(0)
            self.assertTrue(leitor.comunicacao_esta_atual())
            leitor.parar()
            self.assertFalse(leitor.comunicacao_esta_atual())

    def test_diagnostico_periodico_e_transicoes_sem_log_por_refresh(self):
        from unittest.mock import patch
        leitor = LeitorTCPLocal('127.0.0.1', 9800)
        with patch('rede.tcp_local.monotonic', return_value=100) as relogio, patch('builtins.print') as log:
            leitor._publicar_peso(0)
            leitor.registrar_diagnostico(True)
            for instante in (101, 110, 129):
                relogio.return_value = instante
                leitor.registrar_diagnostico(True)
            self.assertEqual(log.call_count, 1)
            relogio.return_value = 130
            leitor.registrar_diagnostico(True)
            leitor.registrar_diagnostico(False)
            leitor.registrar_diagnostico(False)
            self.assertEqual(log.call_count, 3)

    def saida(self, prazo=2):
        saida = SaidaAplicacao(prazo=prazo, intervalo=0.01)
        saida.configurar(registro=RegistroTentativasAplicacao())
        self.addCleanup(self.limpar, saida)
        return saida

    def limpar(self, saida):
        for leitor in saida._leitores:
            leitor.parar()
        for item in saida._threads:
            item['thread'].join(2)
            self.assertFalse(item['thread'].is_alive())

    def test_frame_fragmentado_sem_tara_faixa_ou_estabilidade_inventadas(self):
        saida = self.saida()
        frame = b'ABC0000123abcdefgh'
        with balanca_local([frame[:4], frame[4:]]) as porta:
            leitor = conectar_local('127.0.0.1', porta, saida, prazo=1)
            self.assertTrue(leitor.comunicacao_esta_atual())
            dados = leitor.obter_dados_atuais()
            self.assertEqual(dados['peso_liquido'], '123')
            self.assertEqual((dados['tara'], dados['multirange'], dados['estado']), ('—', '—', 'TCP'))
            self.assertEqual(saida._contextos, [])
            self.assertFalse(saida._registro.obter_retrato()['tentativas'])
            leitor.parar()
            leitor.thread.join(1)
            self.assertIsNone(leitor._socket)

    def test_b2_fecha_socket_e_thread_sem_criar_ciclo_servidor(self):
        saida = self.saida()
        with balanca_local([b'ABC0000007abcdefgh']) as porta:
            leitor = conectar_local('127.0.0.1', porta, saida, prazo=1)
            saida.vincular('teste_tcp', lambda: None)()
            limite = monotonic() + 3
            while not saida.obter_situacao()['parada_operacional_confirmada'] and monotonic() < limite:
                sleep(0.01)
            self.assertTrue(saida.obter_situacao()['parada_operacional_confirmada'])
            self.assertFalse(leitor.thread.is_alive())
            self.assertIsNone(leitor._socket)

    def test_sem_frame_valido_nao_anuncia_conexao(self):
        saida = self.saida()
        with balanca_local([b'ABCinvalidabcdefgh']) as porta:
            with self.assertRaises(ConnectionError):
                conectar_local('127.0.0.1', porta, saida, prazo=0.1)
            leitor = saida._leitores[-1]
            leitor.thread.join(1)
            self.assertFalse(leitor.comunicacao_esta_atual())
            self.assertIsNone(leitor._socket)

    def test_distingue_socket_aberto_sem_dados_de_frame_incompleto(self):
        for blocos, codigo in (([], 'sem_dados'), ([b'ABC123'], 'frame_incompleto'),
                               ([b'ABCinvalidabcdefgh'], 'formato')):
            with self.subTest(codigo=codigo), balanca_local(blocos) as porta:
                saida = self.saida()
                with self.assertRaises(ErroTCPLocal) as capturado:
                    conectar_local('127.0.0.1', porta, saida, prazo=0.1)
                self.assertEqual(capturado.exception.codigo, codigo)
                leitor = saida._leitores[-1]
                leitor.thread.join(1)
                d = leitor.diagnostico()
                self.assertTrue(d['abriu'])
                self.assertEqual(d['bytes'], sum(map(len, blocos)))
                self.assertIsNone(leitor._socket)

    def test_recusa_de_socket_tem_motivo_proprio_sem_conteudo_do_erro(self):
        from unittest.mock import patch
        saida = self.saida()
        sock = Mock()
        sock.connect.side_effect = ConnectionRefusedError(10061, 'conteudo_nao_deve_ser_exposto')
        sock.fileno.return_value = -1
        with patch('rede.tcp_local.socket.socket', return_value=sock):
            with self.assertRaises(ErroTCPLocal) as capturado:
                conectar_local('127.0.0.1', 9800, saida, prazo=0.5)
        self.assertEqual(capturado.exception.codigo, 'recusada')
        from interface.mensagens_seguras import mensagem_erro_login
        mensagem = mensagem_erro_login(capturado.exception)
        self.assertIn('recusada', mensagem)
        self.assertNotIn('conteudo_nao_deve_ser_exposto', mensagem)
        self.assertEqual(saida._leitores[-1].diagnostico()['erro_sistema'], 10061)

    def test_amostra_antiga_nao_e_atual(self):
        saida = self.saida()
        with balanca_local([b'ABC0000007abcdefgh']) as porta:
            leitor = conectar_local('127.0.0.1', porta, saida, prazo=1)
            with leitor._lock:
                leitor._ultimo = monotonic() - 10
            self.assertFalse(leitor.comunicacao_esta_atual())
            leitor.parar()

    def test_falha_close_preserva_referencia_para_retentativa(self):
        leitor = LeitorTCPLocal('127.0.0.1', 9800)
        sock = Mock()
        leitor._socket = sock
        sock.close.side_effect = OSError('falha_simulada')
        with self.assertRaises(OSError):
            leitor.parar()
        self.assertIs(leitor._socket, sock)
        sock.close.side_effect = None
        sock.fileno.return_value = -1
        leitor.parar()
        self.assertIsNone(leitor._socket)

    def test_ciclo_servidor_pendente_recusa_antes_de_abrir_socket(self):
        from unittest.mock import patch
        saida = self.saida()
        with patch.object(saida, 'ciclos_aptos_promocao', return_value=False), patch(
            'rede.tcp_local.socket.socket'
        ) as criar:
            with self.assertRaises(RuntimeError):
                conectar_local('127.0.0.1', 9800, saida)
            criar.assert_not_called()

    def test_b2_nao_confirma_socket_com_close_falho(self):
        saida = self.saida(prazo=0.1)
        leitor = LeitorTCPLocal('127.0.0.1', 9800)
        sock = Mock()
        leitor._socket = sock
        sock.close.side_effect = OSError('falha_simulada')
        saida.acompanhar_leitor(leitor)
        try:
            saida.vincular('teste_limpeza_tcp', lambda: None)()
            limite = monotonic() + 1
            while saida.obter_situacao()['estado'] not in ('falha', 'timeout') and monotonic() < limite:
                sleep(0.01)
            self.assertFalse(saida.obter_situacao()['parada_operacional_confirmada'])
            self.assertEqual(saida.obter_situacao()['estado'], 'falha')
            self.assertIs(leitor._socket, sock)
        finally:
            sock.close.side_effect = None
            sock.fileno.return_value = -1

    def test_parado_antes_de_start_nao_aloca_e_nao_admite_segundo_start(self):
        from unittest.mock import patch
        saida = self.saida()
        leitor = LeitorTCPLocal('127.0.0.1', 9800)
        leitor.parar()
        with patch('rede.tcp_local.socket.socket') as criar:
            leitor.iniciar(saida)
            leitor.thread.join(1)
            criar.assert_not_called()
            with self.assertRaises(RuntimeError):
                leitor.iniciar(saida)

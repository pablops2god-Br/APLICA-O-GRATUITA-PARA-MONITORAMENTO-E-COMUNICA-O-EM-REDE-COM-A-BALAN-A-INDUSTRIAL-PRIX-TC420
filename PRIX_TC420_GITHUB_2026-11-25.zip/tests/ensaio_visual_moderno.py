"""Modelo visual isolado com monitor original e fonte local, sem iniciar serviços.

python -B tests/ensaio_visual_tk.py --moderno [--autoteste]
"""
import ctypes as c
from ctypes import wintypes as w
from pathlib import Path
import sys
import subprocess
import tkinter as tk

PRETO, CARD, TEXTO, SUAVE, VERDE = '#080a0b', '#171b1e', '#f4f7f6', '#9aa6ad', '#a0dc45'


class Dica:
    """Nome sobreposto ao manter o mouse no botão; sem capturar foco."""
    def __init__(self, widget, texto):
        self.widget, self.texto = widget, texto
        self.popup = None
        self.timer = None
        widget.bind('<Enter>', self.agendar)
        widget.bind('<Leave>', self.ocultar)
        widget.bind('<ButtonPress>', self.ocultar, add='+')
        widget.bind('<Destroy>', self.ocultar, add='+')

    def agendar(self, _evento=None):
        self.ocultar()
        self.timer = self.widget.after(450, self.mostrar)

    def mostrar(self):
        self.timer = None
        self.popup = tk.Toplevel(self.widget)
        self.popup.overrideredirect(True)
        texto = self.texto() if callable(self.texto) else self.texto
        tk.Label(self.popup, text=texto, bg=CARD, fg=TEXTO, wraplength=380,
                 justify='left', font=('Segoe UI', 11), padx=10, pady=6).pack()
        self.popup.update_idletasks()
        x = min(self.widget.winfo_rootx(),
                self.widget.winfo_screenwidth() - self.popup.winfo_reqwidth() - 8)
        y = max(0, self.widget.winfo_rooty() - self.popup.winfo_reqheight() - 6)
        self.popup.geometry(f'+{max(0, x)}+{y}')

    def ocultar(self, _evento=None):
        if self.timer is not None:
            self.widget.after_cancel(self.timer)
            self.timer = None
        if self.popup is not None:
            self.popup.destroy()
            self.popup = None


def centralizar(janela, largura, altura):
    janela.update_idletasks()
    x = max(0, (janela.winfo_screenwidth() - largura) // 2)
    y = max(0, (janela.winfo_screenheight() - altura) // 2)
    janela.geometry(f'{largura}x{altura}+{x}+{y}')


class BandejaWindows:
    """Shell_NotifyIcon nativo; callback preservado até restaurar WndProc."""
    def __init__(self, root, restaurar):
        self.root, self.restaurar = root, restaurar
        self.ativa, self.restauracao_pendente = False, False
        if sys.platform != 'win32':
            return
        self.user = c.WinDLL('user32', use_last_error=True)
        self.shell = c.WinDLL('shell32', use_last_error=True)
        class Dados(c.Structure):
            _fields_ = [('cbSize', w.DWORD), ('hWnd', w.HWND), ('uID', w.UINT),
                        ('uFlags', w.UINT), ('uCallbackMessage', w.UINT), ('hIcon', w.HICON),
                        ('szTip', w.WCHAR * 128), ('dwState', w.DWORD), ('dwStateMask', w.DWORD),
                        ('szInfo', w.WCHAR * 256), ('uTimeout', w.UINT),
                        ('szInfoTitle', w.WCHAR * 64), ('dwInfoFlags', w.DWORD),
                        ('guidItem', c.c_byte * 16), ('hBalloonIcon', w.HICON)]
        self.user.GetParent.argtypes, self.user.GetParent.restype = [w.HWND], w.HWND
        self.user.LoadIconW.argtypes, self.user.LoadIconW.restype = [w.HINSTANCE, c.c_void_p], w.HICON
        self.shell.Shell_NotifyIconW.argtypes = [w.DWORD, c.POINTER(Dados)]
        self.shell.Shell_NotifyIconW.restype = w.BOOL
        root.update_idletasks()
        self.hwnd = self.user.GetParent(root.winfo_id()) or root.winfo_id()
        self.dados = Dados()
        self.dados.cbSize, self.dados.hWnd, self.dados.uID = c.sizeof(Dados), self.hwnd, 1
        self.dados.uFlags, self.dados.uCallbackMessage = 1 | 2 | 4, 0x8001
        self.dados.hIcon = self.user.LoadIconW(None, c.c_void_p(32512))
        self.dados.szTip = 'PRIX TC420 — ENSAIO OFFLINE | clique para restaurar'
        self.proc_tipo = c.WINFUNCTYPE(c.c_ssize_t, w.HWND, w.UINT, w.WPARAM, w.LPARAM)
        setter = 'SetWindowLongPtrW' if c.sizeof(c.c_void_p) == 8 else 'SetWindowLongW'
        self.setter = getattr(self.user, setter)
        self.setter.argtypes, self.setter.restype = [w.HWND, c.c_int, c.c_void_p], c.c_void_p
        self.user.CallWindowProcW.argtypes = [c.c_void_p, w.HWND, w.UINT, w.WPARAM, w.LPARAM]
        self.user.CallWindowProcW.restype = c.c_ssize_t
        def callback(hwnd, msg, wp, lp):
            if msg == 0x8001 and lp in (0x202, 0x203, 0x205, 0x405):
                self.restauracao_pendente = True
            return self.user.CallWindowProcW(self.anterior, hwnd, msg, wp, lp)
        self.callback = self.proc_tipo(callback)
        self.anterior = self.setter(self.hwnd, -4, c.cast(self.callback, c.c_void_p))
        if not self.anterior:
            raise c.WinError(c.get_last_error())
        self.ativa = bool(self.shell.Shell_NotifyIconW(0, c.byref(self.dados)))
        root.after(100, self.verificar)

    def verificar(self):
        if self.restauracao_pendente:
            self.restauracao_pendente = False
            self.restaurar()
        self.root.after(100, self.verificar)

    def notificar(self, titulo, mensagem, erro=False):
        if not self.ativa:
            return False
        self.dados.uFlags = 0x10
        self.dados.szInfoTitle, self.dados.szInfo = titulo[:63], mensagem[:255]
        self.dados.dwInfoFlags, self.dados.uTimeout = (3 if erro else 1), 5000
        return bool(self.shell.Shell_NotifyIconW(1, c.byref(self.dados)))

    def fechar(self):
        if sys.platform == 'win32' and hasattr(self, 'anterior'):
            self.shell.Shell_NotifyIconW(2, c.byref(self.dados))
            self.setter(self.hwnd, -4, self.anterior)
            self.ativa = False


class Modelo:
    def __init__(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.janelas = []
        self.icone = tk.PhotoImage(file=str(Path(__file__).resolve().parents[1] / 'assets/logotc420.png'))
        self.root.iconphoto(True, self.icone)
        self.bandeja = BandejaWindows(self.root, self.restaurar)
        self.painel = self.janela('PRIX TC420 | Ensaio visual', 510, 450)
        area = self.conteudo(self.painel, 'Laboratório visual', 'ENSAIO OFFLINE  /  NENHUMA CONEXÃO REAL')
        for texto, comando in [('Tela de conexão', lambda: self.formulario(False)),
                               ('Tela ASSUMIR', lambda: self.formulario(True)),
                               ('Abrir monitor', self.monitor),
                               ('Simular conexão bem-sucedida', lambda: self.evento(True)),
                               ('Simular queda do servidor', lambda: self.evento(False)),
                               ('Minimizar monitor', self.minimizar)]:
            self.botao(area, texto, comando).pack(fill='x', pady=4)
        self.status = tk.Label(area, text='Notificações e bandeja são deste ensaio.', bg=PRETO, fg=SUAVE)
        self.status.pack(pady=10)
        if not self.bandeja.ativa:
            self.status.config(text='Bandeja indisponível neste desktop. Estados aparecem aqui.')
        self.painel.protocol('WM_DELETE_WINDOW', self.fechar)
        self.formulario(False)

    def janela(self, titulo, largura, altura):
        janela = tk.Toplevel(self.root)
        janela.title(titulo)
        janela.configure(bg=PRETO)
        janela.resizable(False, False)
        janela.iconphoto(False, self.icone)
        centralizar(janela, largura, altura)
        self.janelas.append(janela)
        return janela

    def conteudo(self, janela, titulo, subtitulo):
        area = tk.Frame(janela, bg=PRETO)
        area.pack(fill='both', expand=True, padx=30, pady=25)
        tk.Label(area, text='PRIX  /  TC420', bg=PRETO, fg=VERDE,
                 font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        tk.Label(area, text=titulo, bg=PRETO, fg=TEXTO,
                 font=('Segoe UI', 23, 'bold')).pack(anchor='w', pady=(12, 4))
        tk.Label(area, text=subtitulo, bg=PRETO, fg=SUAVE,
                 font=('Segoe UI', 9)).pack(anchor='w', pady=(0, 20))
        return area

    def botao(self, area, texto, comando, destaque=False):
        return tk.Button(area, text=texto, command=comando, cursor='hand2',
                         bg=VERDE if destaque else CARD, fg=PRETO if destaque else TEXTO,
                         activebackground='#b4ed64', activeforeground=PRETO, bd=0,
                         relief='flat', pady=10, height=1,
                         font=('Segoe UI', 18 if destaque else 10, 'bold'))

    def formulario(self, assumir):
        janela = self.janela('PRIX TC420 | ' + ('Assumir' if assumir else 'Conexão'),
                              560, 600 if not assumir else 550)
        faixa_rodape = tk.Frame(janela, bg=PRETO)
        faixa_rodape.pack(side='bottom', fill='x', padx=20, pady=(0, 10))
        quadrado = tk.Frame(faixa_rodape, bg=CARD, width=34, height=34)
        quadrado.pack(side='right', padx=(10, 0))
        quadrado.pack_propagate(False)
        atalho = tk.Button(quadrado, text='▦', command=self.abrir_ensaio,
                           bg=CARD, fg=TEXTO, activebackground=VERDE,
                           activeforeground=PRETO, relief='flat', bd=0,
                           font=('Segoe UI', 14), cursor='hand2')
        atalho.pack(fill='both', expand=True)
        dica = Dica(atalho, 'Abrir ensaio visual Tk')
        rodape = tk.Label(faixa_rodape, text='v0.0.1 · Pablops2god',
                          bg=PRETO, fg=SUAVE, font=('Segoe UI', 14), anchor='e')
        rodape.pack(side='right')
        area = tk.Frame(janela, bg=PRETO)
        area.pack(fill='both', expand=True, padx=22, pady=(10, 4))
        titulo = tk.Frame(area, bg=PRETO)
        titulo.pack(fill='x', pady=(5, 4))
        # Lanczos suaviza a redução; preserva proporção e canal de transparência.
        janela.tamanho_logo = 90
        caminho_logo = Path(__file__).resolve().parents[1] / 'assets' / 'logotc420.png'
        try:
            from PIL import Image, ImageTk
        except ModuleNotFoundError:
            # Asset pré-calculado com Lanczos: mesmo resultado sem dependência no runtime.
            if janela.tamanho_logo != 90:
                raise RuntimeError('Para outro tamanho, instale tests/requirements-visual.txt') from None
            janela.logo_titulo = tk.PhotoImage(
                master=janela, file=str(caminho_logo.with_name('logotc420-90-lanczos.png')))
        else:
            with Image.open(caminho_logo) as original:
                logo_reduzida = original.convert('RGBA')
                logo_reduzida.thumbnail((janela.tamanho_logo, janela.tamanho_logo),
                                       Image.Resampling.LANCZOS)
            janela.logo_titulo = ImageTk.PhotoImage(logo_reduzida, master=janela)
        logo = tk.Label(titulo, image=janela.logo_titulo, bg=PRETO)
        logo.pack(side='right', padx=(8, 0))
        textos_titulo = tk.Frame(titulo, bg=PRETO)
        textos_titulo.pack(side='left')
        tk.Label(textos_titulo, text='PRIX / TC420', bg=PRETO, fg=VERDE,
                 font=('Segoe UI', 14)).pack(anchor='w')
        tk.Label(textos_titulo, text='Assumir o serviço' if assumir else 'Conectar à balança',
                 bg=PRETO, fg=TEXTO, font=('Segoe UI', 18, 'bold')).pack(anchor='w')
        tk.Label(area, text='Simulação — não informe credenciais reais', bg=PRETO,
                 fg=SUAVE, font=('Segoe UI', 14), wraplength=510,
                 justify='left').pack(anchor='w', pady=(0, 10))
        grade = tk.Frame(area, bg=PRETO)
        grade.pack(fill='x')
        grade.columnconfigure(1, weight=1)
        campos = [('IP da TC420', '192.0.2.10'), ('Porta TCP', '9800'),
                  ('Usuário', 'operador de teste'), ('Senha', '')]
        if not assumir:
            campos.insert(0, ('Nome da balança', 'TC420 — teste visual'))
        for linha, (nome, valor) in enumerate(campos):
            tk.Label(grade, text=nome, bg=PRETO, fg=SUAVE,
                     font=('Segoe UI', 14)).grid(row=linha, column=0, sticky='w', padx=(0, 12), pady=3)
            campo = tk.Entry(grade, bg=CARD, fg=TEXTO, insertbackground=VERDE,
                             relief='flat', width=22, font=('Segoe UI', 14),
                             show='•' if nome == 'Senha' else '')
            campo.grid(row=linha, column=1, sticky='ew', ipady=5, pady=3)
            campo.insert(0, valor)
        metodos = tk.Frame(area, bg=PRETO)
        metodos.pack(fill='x', pady=(8, 2))
        tk.Label(metodos, text='Método de conexão', bg=PRETO, fg=SUAVE,
                 font=('Segoe UI', 14)).pack(side='left', padx=(0, 8))
        metodo = tk.StringVar(master=janela, value='HTTPS')
        opcoes = {}
        for nome in ('HTTPS', 'TCP'):
            opcao = tk.Radiobutton(
                metodos, text=nome, value=nome, variable=metodo,
                bg=PRETO, fg=TEXTO, selectcolor=CARD, activebackground=PRETO,
                activeforeground=TEXTO, font=('Segoe UI', 14), cursor='hand2')
            opcao.pack(side='left', padx=(0, 6))
            opcoes[nome] = opcao
        informacao = tk.Canvas(metodos, width=28, height=28, bg=PRETO,
                               highlightthickness=0, cursor='hand2')
        informacao.create_oval(2, 2, 26, 26, fill=CARD, outline=SUAVE)
        informacao.create_text(14, 14, text='i', fill=TEXTO,
                               font=('Segoe UI', 14, 'bold'))
        informacao.pack(side='right')
        def explicar_metodo():
            if metodo.get() == 'HTTPS':
                return ('HTTPS: comunicação web com criptografia TLS. '
                        'Esta seleção é demonstrativa e não ativa HTTPS na aplicação.')
            return ('TCP: comunicação por socket usando a porta TCP informada '
                    '(padrão 9800). TCP, por si só, não criptografa os dados. '
                    'Esta seleção é demonstrativa e não abre conexão.')
        dica_metodo = Dica(informacao, explicar_metodo)
        informacao.bind('<ButtonRelease-1>', lambda _evento: dica_metodo.mostrar())
        salvar = tk.BooleanVar(value=False)
        tk.Checkbutton(area, text='Salvar senha e ativar login automático', variable=salvar,
                       bg=PRETO, fg=TEXTO, selectcolor=CARD, activebackground=PRETO,
                       activeforeground=TEXTO, wraplength=470, justify='left',
                       font=('Segoe UI', 14)).pack(anchor='w', pady=6)
        botao = self.botao(area, 'ASSUMIR' if assumir else 'CONECTAR',
                          lambda: self.evento(True), True)
        botao.pack(fill='x')
        janela.botao_acao = botao
        janela.campos_modelo = campos
        janela.rodape_modelo = rodape
        janela.atalho_ensaio = atalho
        janela.dica_ensaio = dica
        janela.logo_widget = logo
        janela.metodo_conexao = metodo
        janela.opcoes_metodo = opcoes
        janela.dica_metodo = dica_metodo
        # Formulário somente visual: nenhum campo é enviado ou persistido.
        return janela

    def abrir_ensaio(self):
        """Abre o harness original em processo separado, sem shell ou main.py."""
        raiz = Path(__file__).resolve().parents[1]
        try:
            subprocess.Popen(
                [sys.executable, '-B', str(raiz / 'tests' / 'ensaio_visual_tk.py')],
                cwd=str(raiz),
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0)
        except OSError as erro:
            self.status.config(text='Não foi possível abrir o ensaio: ' + type(erro).__name__)

    def monitor(self):
        if hasattr(self, 'monitor_janela') and self.monitor_janela.winfo_exists():
            self.restaurar()
            return self.monitor_janela
        from interface.janela import JanelaTC420
        self.conectado = getattr(self, 'conectado', True)
        self.monitor_real = JanelaTC420(
            master=self.root,
            fonte_dados=lambda: {'peso_liquido': '12.340', 'tara': '0.000',
                                'unidade': 'kg', 'multirange': '1', 'estado': '00'},
            comunicacao_atual=lambda: self.conectado,
            configuracao={'W1.1': {'max': '80000 kg', 'min': '200 kg', 'divisao': '10 kg'},
                          'W1.2': {'max': '140000 kg', 'min': '400 kg', 'divisao': '20 kg'}},
        )
        janela = self.monitor_real.root
        self.monitor_janela = janela
        janela.title('PRIX TC420 | Monitor original - teste offline')
        janela.update_idletasks()
        centralizar(janela, janela.winfo_width(), janela.winfo_height())
        self.monitor_real.atualizar_refresh_web(reagendar=False)
        janela.bind('<Unmap>', lambda event: self.ao_minimizar(event, janela))
        return janela

    def ao_minimizar(self, event, janela):
        if event.widget is janela and janela.state() == 'iconic':
            self.status.config(text='Monitor minimizado. Clique no ícone da bandeja para restaurar.')

    def minimizar(self):
        self.monitor().iconify()

    def restaurar(self):
        if hasattr(self, 'monitor_janela') and self.monitor_janela.winfo_exists():
            self.monitor_janela.deiconify()
            self.monitor_janela.lift()

    def evento(self, conectado):
        texto = 'Conexão bem-sucedida — SIMULAÇÃO' if conectado else 'Servidor indisponível — SIMULAÇÃO'
        self.status.config(text=texto, fg=VERDE if conectado else '#ff938b')
        self.conectado = conectado
        if hasattr(self, 'monitor_janela') and self.monitor_janela.winfo_exists():
            self.monitor_real.atualizar_refresh_web(reagendar=False)
        self.bandeja.notificar('PRIX TC420 — teste', texto, erro=not conectado)

    def fechar(self):
        self.bandeja.fechar()
        self.root.destroy()

    def autoteste(self):
        formulario = self.formulario(True)
        conexao = self.formulario(False)
        monitor = self.monitor()
        self.root.update()
        for janela in (conexao, formulario, monitor):
            assert abs(janela.winfo_x() - (janela.winfo_screenwidth() - janela.winfo_width()) // 2) <= 10
            assert not janela.overrideredirect()
        for janela in (conexao, formulario):
            from tkinter.font import Font
            assert ('Porta TCP', '9800') in janela.campos_modelo
            assert Font(font=janela.botao_acao.cget('font')).actual('size') == 18
            assert Font(font=janela.rodape_modelo.cget('font')).actual('size') == 14
            assert janela.botao_acao.winfo_height() >= 50
            assert (janela.botao_acao.winfo_rooty() + janela.botao_acao.winfo_height()
                    <= janela.rodape_modelo.winfo_rooty())
            assert janela.rodape_modelo.winfo_ismapped()
            assert 'Pablops2god' in janela.rodape_modelo.cget('text')
            assert 'v0.0.1' in janela.rodape_modelo.cget('text')
            assert janela.winfo_height() < 640
            assert janela.metodo_conexao.get() == 'HTTPS'
            janela.opcoes_metodo['TCP'].invoke()
            assert janela.metodo_conexao.get() == 'TCP'
            assert 'TCP:' in janela.dica_metodo.texto()
            janela.dica_metodo.mostrar()
            self.root.update_idletasks()
            assert janela.dica_metodo.popup.winfo_exists()
            janela.dica_metodo.ocultar()
            janela.opcoes_metodo['HTTPS'].invoke()
            assert janela.metodo_conexao.get() == 'HTTPS'
            assert 'HTTPS:' in janela.dica_metodo.texto()
            assert janela.logo_widget.winfo_ismapped()
            assert max(janela.logo_titulo.width(), janela.logo_titulo.height()) == janela.tamanho_logo
            imagem_tk = janela.logo_widget.tk
            assert any(not int(imagem_tk.call(str(janela.logo_titulo), 'transparency', 'get', x, y))
                       for y in range(janela.logo_titulo.height())
                       for x in range(janela.logo_titulo.width())), 'Logo inteiramente transparente'
            assert janela.atalho_ensaio.winfo_ismapped()
            assert janela.atalho_ensaio.winfo_width() == janela.atalho_ensaio.winfo_height() == 34
            janela.dica_ensaio.mostrar()
            self.root.update_idletasks()
            assert janela.dica_ensaio.popup.winfo_exists()
            janela.dica_ensaio.ocultar()
            from unittest.mock import patch
            with patch.object(subprocess, 'Popen') as abrir:
                janela.atalho_ensaio.invoke()
                comando = abrir.call_args.args[0]
                assert Path(comando[-1]).name == 'ensaio_visual_tk.py'
                assert '--moderno' not in comando
        if sys.platform == 'win32':
            self.bandeja.user.FindWindowW.argtypes = [w.LPCWSTR, w.LPCWSTR]
            self.bandeja.user.FindWindowW.restype = w.HWND
            if self.bandeja.user.FindWindowW('Shell_TrayWnd', None):
                assert self.bandeja.ativa, 'Shell recusou ícone na bandeja'
            else:
                print('PENDENTE: desktop sem Shell_TrayWnd; bandeja/notificações não validadas.')
        self.evento(False)
        self.evento(True)
        monitor.iconify()
        self.root.update()
        assert monitor.state() == 'iconic'
        self.restaurar()
        self.root.update()
        assert monitor.state() == 'normal'
        print('Tk real: formulários, centro, molduras, minimizar/restaurar OK.')
        print('Registro na bandeja:', self.bandeja.ativa)
        print('Notificações solicitadas ao Windows; exibição depende das configurações do sistema.')


def executar():
    modelo = Modelo()
    if '--autoteste' in sys.argv:
        try:
            modelo.autoteste()
        finally:
            modelo.fechar()
    else:
        modelo.root.mainloop()


if __name__ == '__main__':
    executar()

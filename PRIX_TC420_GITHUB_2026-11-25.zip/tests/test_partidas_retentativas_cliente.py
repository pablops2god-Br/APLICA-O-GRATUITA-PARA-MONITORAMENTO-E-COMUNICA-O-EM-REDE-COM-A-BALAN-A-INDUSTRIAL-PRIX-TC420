# Testes de partidas retentativas cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC2-A: partida real do leitor, threads/transporte falsos; sem término integrado."""
import threading
import unittest
from unittest.mock import Mock, patch

from rede import infraestrutura_cliente as modulo
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
from test_recursos_cliente_integrados import SocketLeituraFalso
import test_infraestrutura_cliente as montagem


THREAD_REAL = threading.Thread


class ThreadFalsa:
    def __init__(self, target, daemon):
        self.target, self.daemon, self.starts = target, daemon, 0
        self.is_alive = Mock(return_value=False)

    def start(self):
        self.starts += 1


# Grupo de 30 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class PartidasRetentativasCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.guarda = self.infra.registro_retentativas
        self.leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.leitor.executando = True
        self.threads = []
        self.fabrica = self.fabricar

    def fabricar(self, **kwargs):
        thread = ThreadFalsa(**kwargs)
        self.threads.append(thread)
        return thread

    def preparar(self, leitor=None):
        leitor = leitor or self.leitor
        leitor.estado_candidatura = "liberada"
        leitor.candidatura_liberada.set()
        leitor.tentativa_recuperacao = 1
        return leitor

    def partir(self, leitor=None):
        with patch("rede.lerdadosserver.threading.Thread", side_effect=self.fabrica), patch("builtins.print"):
            return (leitor or self.leitor).registrar_falha_recuperacao()

    def retrato(self):
        return self.guarda.obter_retrato()["retentativas"]

    def negativo(self):
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])
        self.assertFalse(self.infra.avaliar()["cobertura_completa"])
        self.assertTrue(all(not t["thread_terminada"] for t in self.retrato()))

    def tarefa(self, funcao):
        erros, resultados = [], []
        def executar():
            try:
                resultados.append(funcao())
            except BaseException as erro:
                erros.append(erro)
        thread = THREAD_REAL(target=executar, daemon=True)
        thread.start()
        return thread, resultados, erros

    def terminar(self, tarefa):
        tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())

    def bloquear(self, entrou, liberar):
        entrou.set()
        if not liberar.wait(3):
            raise TimeoutError("barreira_simulada")

    def test_01_normal_identidade_e_guarda_originais(self):
        self.preparar()
        self.assertTrue(self.partir())
        tentativa, = self.retrato()
        self.assertEqual(self.leitor.recursos_cliente.geracao_id, tentativa["geracao"])
        self.assertTrue(tentativa["start_invocado"])
        self.assertTrue(tentativa["partida_resolvida"])
        self.assertEqual(1, self.threads[0].starts)

    def test_02_sequenciais_identidades_distintas(self):
        for _ in range(2):
            self.preparar()
            self.assertTrue(self.partir())
        self.assertEqual(2, len({t["id"] for t in self.retrato()}))
        self.assertEqual(1, len({t["geracao"] for t in self.retrato()}))

    def test_03_concorrentes_identidades_independentes(self):
        outro = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        barreira = threading.Barrier(2)
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            original = thread.start
            thread.start = lambda: (barreira.wait(3), original())[-1]
            return thread
        self.preparar()
        self.preparar(outro)
        with patch("rede.lerdadosserver.threading.Thread", side_effect=criar), patch("builtins.print"):
            a = self.tarefa(self.leitor.registrar_falha_recuperacao)
            b = self.tarefa(outro.registrar_falha_recuperacao)
            self.terminar(a)
            self.terminar(b)
        self.assertEqual([], a[2] + b[2])
        self.assertEqual(2, len({t["id"] for t in self.retrato()}))
        self.assertTrue(all(t["start_invocado"] for t in self.retrato()))

    def test_04_recusa_admissao_sem_construcao_ou_start(self):
        self.preparar()
        self.guarda.fechar_admissao()
        self.assertFalse(self.partir())
        self.assertEqual([], self.threads)
        self.assertEqual([], self.retrato())
        self.assertEqual("liberada", self.leitor.estado_candidatura)

    def test_05_falha_antes_construcao_resolve_nao_execucao(self):
        self.preparar()
        erro = RuntimeError("antes_simulado")
        with patch.object(self.guarda, "partir", side_effect=erro):
            with self.assertRaises(RuntimeError) as recebido:
                self.partir()
        self.assertIs(erro, recebido.exception)
        self.assertTrue(self.retrato()[0]["ausencia_comprovada"])
        self.assertFalse(self.retrato()[0]["start_invocado"])
        self.assertEqual([], self.threads)

    def test_06_falha_construcao_preserva_erro_e_resolve(self):
        self.preparar()
        erro = OSError("construcao_simulada")
        self.fabrica = Mock(side_effect=erro)
        with self.assertRaises(OSError) as recebido:
            self.partir()
        self.assertIs(erro, recebido.exception)
        self.assertTrue(self.retrato()[0]["ausencia_comprovada"])
        self.assertEqual("encerramento_confirmado", self.retrato()[0]["estado"])

    def test_07_start_fora_de_locks(self):
        self.preparar()
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            def start():
                self.assertTrue(self.retrato()[0]["start_invocado"])
                for lock in (self.guarda._lock, self.leitor.lock_candidatura):
                    self.assertTrue(lock.acquire(blocking=False))
                    lock.release()
                thread.starts += 1
            thread.start = start
            return thread
        self.fabrica = criar
        self.assertTrue(self.partir())

    def test_08_start_lanca_sem_entrada_nao_prova_ausencia(self):
        self.preparar()
        erro = RuntimeError("start_simulado")
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            thread.start = Mock(side_effect=erro)
            return thread
        self.fabrica = criar
        with self.assertRaises(RuntimeError) as recebido:
            self.partir()
        self.assertIs(erro, recebido.exception)
        self.assertTrue(self.retrato()[0]["partida_ambigua"])
        self.assertFalse(self.retrato()[0]["ausencia_comprovada"])
        self.threads[0].is_alive.assert_not_called()

    def test_09_falha_publicacao_apos_start_nao_inventa_ausencia(self):
        self.preparar()
        partir = self.guarda.partir
        def falhar(*args):
            partir(*args)
            raise RuntimeError("publicacao_simulada")
        with patch.object(self.guarda, "partir", side_effect=falhar):
            with self.assertRaises(RuntimeError):
                self.partir()
        self.assertTrue(self.retrato()[0]["start_invocado"])
        self.assertFalse(self.retrato()[0]["ausencia_comprovada"])
        self.negativo()

    def test_10_nova_espera_de_recuperacao_recebe_novo_id(self):
        # Reconexão comum é loop permanente; nova partida é nova espera de recuperação.
        self.preparar()
        self.partir()
        primeiro = self.retrato()[0]
        self.preparar()
        self.partir()
        self.assertEqual(primeiro, self.retrato()[0])
        self.assertNotEqual(primeiro["id"], self.retrato()[1]["id"])

    def test_11_promocao_no_start_preserva_geracao(self):
        self.preparar()
        token = self.leitor.recursos_cliente._geracao_retentativas
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            thread.start = lambda: self.guarda.promover(token)
            return thread
        self.fabrica = criar
        self.partir()
        self.assertEqual(token.numero, self.retrato()[0]["geracao"])
        self.assertEqual("principal", self.retrato()[0]["modo_atual"])

    def test_12_geracao_antiga_pendente_preservada(self):
        self.preparar()
        self.partir()
        antigo = self.retrato()[0]
        outro = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.preparar(outro)
        self.partir(outro)
        self.assertEqual(antigo, self.retrato()[0])
        self.assertNotEqual(antigo["geracao"], self.retrato()[1]["geracao"])

    def test_13_novo_cliente_mesma_guarda(self):
        outro = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.assertIs(self.guarda, outro._partidas_retentativas._guarda)
        self.assertIs(self.guarda, self.leitor._partidas_retentativas._guarda)

    def test_14_sem_proprietario_nao_parte(self):
        isolado = LeitorDadosServidor()
        self.preparar(isolado)
        self.assertFalse(self.partir(isolado))
        self.assertEqual([], self.threads)
        self.assertEqual([], self.retrato())

    def test_15_gate_fechado_entre_reserva_e_partida(self):
        self.preparar()
        reservar = self.guarda.reservar_retentativa
        def fechar(geracao):
            identidade = reservar(geracao)
            self.guarda.fechar_admissao()
            return identidade
        with patch.object(self.guarda, "reservar_retentativa", side_effect=fechar):
            self.assertFalse(self.partir())
        self.assertEqual([], self.threads)
        self.assertTrue(self.retrato()[0]["ausencia_comprovada"])

    def test_16_global_nao_confirmado(self):
        self.preparar()
        self.partir()
        self.guarda.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        self.negativo()

    def test_17_corrida_a_admissao_contra_fechamento(self):
        self.preparar()
        barreira = threading.Barrier(2)
        def fechar():
            barreira.wait(3)
            self.guarda.fechar_admissao()
        def iniciar():
            barreira.wait(3)
            return self.leitor.registrar_falha_recuperacao()
        with patch("rede.lerdadosserver.threading.Thread", side_effect=self.fabricar), patch("builtins.print"):
            a, b = self.tarefa(iniciar), self.tarefa(fechar)
            self.terminar(a)
            self.terminar(b)
        self.assertEqual([], a[2] + b[2])
        self.assertLessEqual(len(self.retrato()), 1)
        if a[1] == [False]:
            self.assertEqual([], self.threads)
        else:
            self.assertTrue(self.retrato()[0]["start_invocado"])
        self.negativo()

    def test_18_corrida_b_start_entra_e_depois_lanca(self):
        self.preparar()
        self.leitor._aguardar_proxima_tentativa = Mock()
        erro = RuntimeError("start_apos_entrada_simulado")
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            def iniciar():
                thread.target()
                raise erro
            thread.start = iniciar
            return thread
        self.fabrica = criar
        with self.assertRaises(RuntimeError) as recebido:
            self.partir()
        self.assertIs(erro, recebido.exception)
        estado = self.retrato()[0]
        self.assertTrue(estado["entrada"] and estado["retorno"] and estado["partida_ambigua"])
        self.assertFalse(estado["ausencia_comprovada"])
        self.negativo()

    def test_19_corrida_c_promocao_durante_partida(self):
        self.preparar()
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            thread.start = lambda: self.bloquear(entrou, liberar)
            return thread
        with patch("rede.lerdadosserver.threading.Thread", side_effect=criar), patch("builtins.print"):
            trabalho = self.tarefa(self.leitor.registrar_falha_recuperacao)
            self.assertTrue(entrou.wait(3))
            origem = self.retrato()[0]["geracao"]
            self.guarda.promover(self.leitor.recursos_cliente._geracao_retentativas)
            novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
            self.assertIs(self.guarda, novo._partidas_retentativas._guarda)
            liberar.set()
            self.terminar(trabalho)
        self.assertEqual([], trabalho[2])
        self.assertEqual(origem, self.retrato()[0]["geracao"])
        self.negativo()

    def test_20_corrida_d_duas_partidas_resultados_independentes(self):
        outro = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.preparar()
        self.preparar(outro)
        barreira = threading.Barrier(2)
        sequencia, lock = [], threading.Lock()
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            with lock:
                numero = len(sequencia)
                sequencia.append(thread)
            def iniciar():
                barreira.wait(3)
                if numero == 0:
                    raise RuntimeError("start_simulado")
            thread.start = iniciar
            return thread
        with patch("rede.lerdadosserver.threading.Thread", side_effect=criar), patch("builtins.print"):
            a, b = self.tarefa(self.leitor.registrar_falha_recuperacao), self.tarefa(outro.registrar_falha_recuperacao)
            self.terminar(a)
            self.terminar(b)
        self.assertEqual(1, len(a[2] + b[2]))
        self.assertEqual(1, sum(t["partida_ambigua"] for t in self.retrato()))
        self.assertEqual(2, len({t["id"] for t in self.retrato()}))

    def test_21_corrida_e_publicacao_tardia_apos_entrada(self):
        self.preparar()
        self.leitor._aguardar_proxima_tentativa = Mock()
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            def iniciar():
                thread.target()
                self.bloquear(entrou, liberar)
            thread.start = iniciar
            return thread
        with patch("rede.lerdadosserver.threading.Thread", side_effect=criar), patch("builtins.print"):
            trabalho = self.tarefa(self.leitor.registrar_falha_recuperacao)
            self.assertTrue(entrou.wait(3))
            estado = self.retrato()[0]
            self.assertTrue(estado["entrada"] and estado["retorno"] and estado["partida_em_curso"])
            self.assertFalse(estado["partida_resolvida"])
            self.negativo()
            liberar.set()
            self.terminar(trabalho)
        self.assertEqual([], trabalho[2])
        self.negativo()

    def test_22_partida_e_socket_sao_responsabilidades_independentes(self):
        cliente = self.leitor.recursos_cliente.abrir_socket(lambda: SocketLeituraFalso())
        self.preparar()
        self.partir()
        self.assertTrue(self.retrato()[0]["start_invocado"])
        self.assertFalse(self.infra.registro_recursos.obter_retrato()["recursos"][0]["encerramento_confirmado"])
        self.negativo()
        cliente.close()

    def test_23_rotina_real_preserva_espera_e_descoberta(self):
        self.preparar()
        self.partir()
        self.leitor._parada = Mock()
        self.leitor._parada.wait.return_value = True
        with patch("rede.lerdadosserver.buscar_servidor", return_value=None) as descobrir, \
                patch("rede.lerdadosserver.time.monotonic", side_effect=[0, 0]):
            self.threads[0].target()
        descobrir.assert_called_once()
        recursos = descobrir.call_args.kwargs["recursos_cliente"]
        self.assertIs(self.infra.registro_recursos, recursos.registro)
        self.assertEqual(self.leitor.recursos_cliente.geracao_id, recursos.geracao_id)
        self.assertEqual(self.retrato()[0]["id"], recursos.atividade_id)
        self.assertIsNot(self.leitor.recursos_cliente, recursos)
        self.leitor._parada.wait.assert_called_once_with(5)
        self.assertTrue(self.retrato()[0]["entrada"] and self.retrato()[0]["retorno"])
        self.negativo()

    def test_24_criterios_e_limite_nao_criam_reserva(self):
        self.assertFalse(self.partir())
        self.preparar()
        self.leitor.tentativa_recuperacao = 10
        self.assertFalse(self.partir())
        self.assertEqual([], self.retrato())

    def test_25_thread_permanente_nao_vira_retentativa(self):
        self.leitor.executando = False
        with patch.object(self.leitor, "_manter_atualizado") as alvo, \
                patch("rede.lerdadosserver.threading.Thread", side_effect=self.fabricar):
            self.leitor.iniciar()
            self.threads[0].target()
        alvo.assert_called_once_with()
        self.assertEqual([], self.retrato())
        atividade, = self.infra.obter_atividades_permanentes()["atividades"]
        self.assertEqual("leitor_permanente", atividade["tipo"])
        self.assertTrue(atividade["entrada"] and atividade["retorno"])

    def test_26_mutacao_de_referencia_do_leitor_nao_migra_guarda(self):
        outra = InfraestruturaRegistrosCliente()
        self.leitor.infraestrutura_cliente = outra
        self.preparar()
        self.partir()
        self.assertEqual(1, len(self.retrato()))
        self.assertEqual([], outra.registro_retentativas.obter_retrato()["retentativas"])

    def test_27_falha_na_prova_nao_substitui_erro_construcao(self):
        self.preparar()
        original, diagnostico = RuntimeError("construcao_simulada"), OSError("prova_simulada")
        self.fabrica = Mock(side_effect=original)
        with patch.object(self.guarda, "comprovar_nao_execucao", side_effect=diagnostico):
            with self.assertRaises(RuntimeError) as recebido:
                self.partir()
        self.assertIs(original, recebido.exception)
        self.assertIs(diagnostico, original.__cause__)
        self.assertFalse(self.retrato()[0]["ausencia_comprovada"])
        self.negativo()

    def test_28_main_compartilha_guarda_com_leitor_real(self):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        leitores = []
        def criar(**kwargs):
            leitor = LeitorDadosServidor(**kwargs)
            leitores.append(leitor)
            return leitor
        fx.env["LeitorDadosServidor"] = criar
        fx.durante_monitor = lambda monitor: self.preparar(leitores[0]).registrar_falha_recuperacao()
        with patch.object(modulo, "InfraestruturaRegistrosCliente", return_value=self.infra), \
                patch.object(LeitorDadosServidor, "aguardar_configuracao", return_value=None), \
                patch("rede.lerdadosserver.threading.Thread", side_effect=self.fabricar), patch("builtins.print"):
            fx.iniciar_descoberto()
        self.assertIs(self.guarda, leitores[0]._partidas_retentativas._guarda)
        self.assertEqual(1, len(self.retrato()))
        self.negativo()

    def test_29_entrada_tardia_apos_start_ambiguo_permanece_possivel(self):
        self.preparar()
        rotina = Mock()
        self.leitor._aguardar_proxima_tentativa = rotina
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            thread.start = Mock(side_effect=RuntimeError("start_tardio_simulado"))
            return thread
        self.fabrica = criar
        with self.assertRaises(RuntimeError):
            self.partir()
        self.assertFalse(self.retrato()[0]["ausencia_comprovada"])
        self.threads[0].target()
        rotina.assert_called_once_with()
        self.assertTrue(self.retrato()[0]["entrada"] and self.retrato()[0]["retorno"])
        self.negativo()

    def test_30_partida_reivindicada_antes_gate_pode_concluir(self):
        self.preparar()
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            self.bloquear(entrou, liberar)
            return thread
        with patch("rede.lerdadosserver.threading.Thread", side_effect=criar), patch("builtins.print"):
            trabalho = self.tarefa(self.leitor.registrar_falha_recuperacao)
            self.assertTrue(entrou.wait(3))
            self.guarda.fechar_admissao()
            self.assertTrue(self.retrato()[0]["partida_em_curso"])
            liberar.set()
            self.terminar(trabalho)
        self.assertEqual([], trabalho[2])
        self.assertEqual([True], trabalho[1])
        self.assertTrue(self.retrato()[0]["start_invocado"])
        self.preparar()
        self.assertFalse(self.partir())
        self.assertEqual(1, len(self.threads))
        self.negativo()

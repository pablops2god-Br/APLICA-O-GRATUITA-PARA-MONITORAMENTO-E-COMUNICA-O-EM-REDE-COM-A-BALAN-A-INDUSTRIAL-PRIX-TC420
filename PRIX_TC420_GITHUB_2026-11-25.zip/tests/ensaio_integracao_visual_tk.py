"""Tk real das telas integradas, sem rede, configuração ou cofre reais."""
from pathlib import Path
import sys
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from interface.conexao import JanelaConexao
from interface.janela import JanelaTC420


def executar():
    erros = []
    with patch('interface.conexao.carregar_configuracao', return_value=None), patch(
        'interface.conexao.carregar_senha', side_effect=AssertionError('cofre proibido')
    ), patch('interface.conexao.buscar_servidor', side_effect=AssertionError('rede proibida')):
        conexao = JanelaConexao()
        try:
            conexao.root.report_callback_exception = lambda *args: erros.append(args)
            conexao.root.update()
            assert conexao.root.cget('bg') == '#080a0b'
            assert conexao.campo_porta.get() == '9800'
            assert conexao.metodo_conexao_var.get() == 'HTTPS'
            assert conexao.botao_conectar.winfo_height() >= 50
            dados = {'peso_liquido': '12.340', 'tara': '0', 'unidade': 'kg',
                     'multirange': '1', 'estado': '00'}
            monitor = JanelaTC420(master=conexao.root, fonte_dados=lambda: dados,
                                 comunicacao_atual=lambda: True)
            assert monitor.root.cget('bg') == '#B6B6B6'
            monitor.ao_promover = Mock()
            monitor._iniciar_promocao = Mock()
            monitor.abrir_janela_promocao()
            popup = monitor.janela_promocao
            conexao.root.update()
            assert popup.metodo_conexao.get() == 'HTTPS'
            assert popup.rodape_modelo.cget('text') == 'v0.0.1 · Pablops2god'
            assert popup.botao_acao.winfo_height() >= 50
            for janela in (conexao.root, popup):
                assert janela.logo_widget.winfo_ismapped()
                assert janela.botao_acao.winfo_rooty() + janela.botao_acao.winfo_height() <= janela.rodape_modelo.winfo_rooty()
                janela.opcoes_metodo['TCP'].invoke()
                assert janela.metodo_conexao.get() == 'TCP'
                janela.opcoes_metodo['HTTPS'].invoke()
                janela.dica_metodo.mostrar()
                janela.dica_metodo.ocultar()
            monitor.atualizar_refresh_web(reagendar=False)
            monitor.root.iconify()
            conexao.root.update()
            assert monitor.root.state() == 'iconic'
            monitor._bandeja_windows.restaurar()
            conexao.root.update()
            assert monitor.root.state() == 'normal'
            popup.destroy()
            monitor.root.destroy()
            conexao.root.update()
            assert monitor._bandeja_windows.fechada
            assert not erros, erros
            print('Tk integrado: conexão/ASSUMIR, seletor, logo, layout e monitor original OK.')
            print('Sem rede/cofre; bandeja e balões dependem do desktop Windows.')
        finally:
            conexao.root.destroy()


if __name__ == '__main__':
    executar()

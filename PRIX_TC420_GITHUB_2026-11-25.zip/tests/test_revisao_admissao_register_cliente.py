# Testes de revisao admissao register cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-D3-B2-B3-A: controle real, transportes falsos e barreiras locais."""
import threading
import traceback
import unittest
from unittest.mock import Mock, patch

import test_admissao_register_cliente as anterior
from rede.admissao_register_cliente import AdmissaoRegisterCliente, RecursosRegisterCliente
from rede.lerdadosserver import LeitorDadosServidor


# Grupo de 40 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class RevisaoAdmissaoRegisterCliente(unittest.TestCase):
    setUp = anterior.AdmissaoRegisterIntegrada.setUp
    bruto = anterior.AdmissaoRegisterIntegrada.bruto
    operar = anterior.AdmissaoRegisterIntegrada.operar
    promover_real = anterior.AdmissaoRegisterIntegrada.promover_real
    fabricar = anterior.AdmissaoRegisterIntegrada.fabricar

    def evidencia(self, controle=None):
        r = (controle or self.controle).obter_evidencia_temporal()
        for campo in ('dependencias_temporais_cobertas', 'snapshot_atomico',
                      'encerramento_cliente_confirmado', 'encerramento_global_confirmado'):
            self.assertFalse(r[campo])
        return r

    def revisao(self, controle=None):
        return (controle or self.controle).obter_revisao()['revisao']

    def item(self):
        return self.evidencia()['retrato']['operacoes'][-1]

    def concluir(self, identidade=None, controle=None):
        controle = controle or self.controle
        identidade = identidade or controle.admitir()
        with controle.executar(identidade):
            pass

    def tarefa(self, funcao):
        resultados, erros = [], []
        def executar():
            try:
                resultados.append(funcao())
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=executar, daemon=True)
        thread.start()
        return thread, resultados, erros

    def terminar(self, tarefa):
        tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())
        self.assertEqual([], tarefa[2])
        return tarefa[1]

    def aguardar(self, evento):
        self.assertTrue(evento.wait(3), 'barreira simulada nao atingida')

    def test_01_controle_novo(self):
        e = self.evidencia()
        self.assertEqual(0, e['revisao'])
        self.assertTrue(e['confiavel'])
        self.assertEqual(self.controle.fonte_id, e['fonte_id'])
        self.assertEqual([], e['retrato']['operacoes'])

    def test_02_primeira_admissao(self):
        self.controle.admitir()
        self.assertEqual(1, self.revisao())
        self.assertEqual(1, len(self.evidencia()['retrato']['operacoes']))

    def test_03_segunda_admissao(self):
        self.controle.admitir()
        self.controle.admitir()
        self.assertEqual(2, self.revisao())
        self.assertEqual([1, 2], [i['operacao_id'] for i in self.evidencia()['retrato']['operacoes']])

    def test_04_fechamento(self):
        antes = self.revisao()
        self.leitor.parar()
        self.assertEqual(antes + 1, self.revisao())
        self.assertTrue(self.evidencia()['retrato']['admissao_fechada'])

    def test_05_parada_repetida(self):
        self.leitor.parar()
        antes = self.evidencia()
        self.leitor.parar()
        self.assertEqual(antes, self.evidencia())

    def test_06_recusa_estavel(self):
        self.leitor.parar()
        antes = self.evidencia()
        self.assertIsNone(self.controle.admitir())
        self.assertEqual(antes, self.evidencia())

    def test_07_conclusao(self):
        t = self.controle.admitir()
        antes = self.revisao()
        self.concluir(t)
        self.assertGreater(self.revisao(), antes)
        self.assertTrue(self.item()['retorno'])
        self.assertFalse(self.item()['execucao_em_curso'])

    def test_08_antiga_apos_parada(self):
        t = self.controle.admitir()
        self.leitor.parar()
        antes = self.revisao()
        self.operar(identidade=t)
        self.assertGreater(self.revisao(), antes)
        self.assertTrue(self.item()['retorno'])
        self.assertTrue(self.evidencia()['retrato']['admissao_fechada'])

    def test_09_autorizacao_sem_socket(self):
        self.controle.admitir()
        self.assertFalse(self.item()['iniciada'])
        self.assertFalse(self.item()['retorno'])
        self.assertEqual([], self.item()['vinculos'])
        self.assertEqual([], self.registro.obter_retrato()['recursos'])

    def test_10_publicacao_falha(self):
        with patch.object(self.controle, '_publicar_saida', side_effect=OSError('publicacao_simulada')):
            with self.assertRaises(OSError):
                self.concluir()
        self.assertFalse(self.evidencia()['confiavel'])
        self.assertTrue(self.item()['erro_publicacao'])
        self.concluir()
        self.assertFalse(self.evidencia()['confiavel'])

    def test_11_primario_instancia_traceback(self):
        original, publicacao = ValueError('operacao_simulada'), OSError('publicacao_simulada')
        bruto = self.bruto()
        def falhar_envio(_dados):
            raise original
        bruto.sendall.side_effect = falhar_envio
        with patch.object(self.controle, '_publicar_saida', side_effect=publicacao):
            try:
                self.operar(bruto)
            except ValueError as recebido:
                self.assertIs(original, recebido)
                self.assertIn('falhar_envio', [f.name for f in traceback.extract_tb(recebido.__traceback__)])
            else:
                self.fail('erro primario perdido')
        self.assertIs(publicacao, original.__cause__)
        self.assertEqual((publicacao,), original._falhas_acompanhamento_register)
        self.assertFalse(self.evidencia()['confiavel'])
        self.assertNotIn(str(original), str(self.evidencia()))

    def test_12_aba_admissao_conclusao(self):
        antes = self.evidencia()
        self.concluir()
        depois = self.evidencia()
        self.assertGreater(depois['revisao'], antes['revisao'])
        self.assertTrue(all(i['retorno'] for i in depois['retrato']['operacoes']))
        self.assertEqual(antes['fonte_id'], depois['fonte_id'])

    def test_13_promocao_preserva_controle(self):
        t = self.controle.admitir()
        fonte = self.controle.fonte_id
        self.promover_real()
        antes = self.revisao()
        self.concluir(t)
        retidos = self.infra.obter_evidencias_temporais_register()
        self.assertIn(fonte, [r['fonte_id'] for r in retidos])
        self.assertGreater(self.revisao(), antes)

    def test_14_nova_geracao_independente(self):
        outro = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.addCleanup(outro.parar)
        b = outro._admissao_register
        self.assertNotEqual(self.controle.fonte_id, b.fonte_id)
        self.assertNotEqual(self.evidencia()['geracao_id'], self.evidencia(b)['geracao_id'])
        antes = b.obter_evidencia_temporal()
        self.concluir()
        self.assertEqual(antes, b.obter_evidencia_temporal())

    def test_15_consulta_passiva_repetida(self):
        self.operar()
        antes = self.evidencia()
        with patch.object(self.registro, 'obter_retrato', side_effect=AssertionError('consulta_externa')):
            for _ in range(5):
                self.assertEqual(antes, self.evidencia())
                self.assertEqual(antes, self.infra.obter_evidencias_temporais_register()[0])

    def test_16_limpeza_externa(self):
        t = self.controle.admitir()
        with self.controle.executar(t) as dono:
            socket = dono.abrir_socket(self.bruto)
        antes, recursos = self.evidencia(), self.registro.obter_retrato()
        socket.close()
        self.assertNotEqual(recursos, self.registro.obter_retrato())
        self.assertEqual(antes, self.evidencia())

    def test_corrida_a_consulta_nao_ve_estado_novo_revisao_antiga(self):
        entrou, liberar, consultando, consultou = (threading.Event() for _ in range(4))
        avancar = self.controle._avancar_revisao
        def suspender():
            entrou.set()
            self.aguardar(liberar)
            avancar()
        def consultar():
            consultando.set()
            e = self.evidencia()
            consultou.set()
            return e
        with patch.object(self.controle, '_avancar_revisao', side_effect=suspender):
            admissao = self.tarefa(self.controle.admitir)
            try:
                self.aguardar(entrou)
                consulta = self.tarefa(consultar)
                self.aguardar(consultando)
                self.assertFalse(consultou.wait(0.03))
            finally:
                liberar.set()
                self.terminar(admissao)
            e = self.terminar(consulta)[0]
        self.assertEqual(1, e['revisao'])
        self.assertEqual(1, len(e['retrato']['operacoes']))

    def corrida_gate(self, primeiro_admitir):
        entrou, liberar, competindo = (threading.Event() for _ in range(3))
        avancar = self.controle._avancar_revisao
        primeira = True
        def suspender():
            nonlocal primeira
            if primeira:
                primeira = False
                entrou.set()
                self.aguardar(liberar)
            avancar()
        def competir():
            competindo.set()
            return self.leitor.parar() if primeiro_admitir else self.controle.admitir()
        with patch.object(self.controle, '_avancar_revisao', side_effect=suspender):
            a = self.tarefa(self.controle.admitir if primeiro_admitir else self.leitor.parar)
            try:
                self.aguardar(entrou)
                b = self.tarefa(competir)
                self.aguardar(competindo)
            finally:
                liberar.set()
                ra = self.terminar(a)
            rb = self.terminar(b)
        self.assertTrue(self.evidencia()['retrato']['admissao_fechada'])
        self.assertEqual(2 if primeiro_admitir else 1, self.revisao())
        self.assertEqual(1 if primeiro_admitir else 0, len(self.evidencia()['retrato']['operacoes']))
        if primeiro_admitir:
            self.assertIsNotNone(ra[0])
        else:
            self.assertIsNone(rb[0])

    def test_corrida_b_admissao_vence(self):
        self.corrida_gate(True)

    def test_corrida_b_parada_vence(self):
        self.corrida_gate(False)

    def test_corrida_c_aba_entre_consultas(self):
        antes = self.evidencia()
        tarefa = self.tarefa(self.concluir)
        self.terminar(tarefa)
        depois = self.evidencia()
        self.assertTrue(depois['retrato']['operacoes'][0]['retorno'])
        self.assertFalse(depois['retrato']['operacoes'][0]['execucao_em_curso'])
        self.assertGreater(depois['revisao'], antes['revisao'])

    def test_corrida_d_promocao_b_e_publicacao_tardia_a(self):
        entrou, liberar = threading.Event(), threading.Event()
        def operar_antiga():
            with self.controle.executar(self.controle.admitir()):
                entrou.set()
                self.aguardar(liberar)
        tarefa = self.tarefa(operar_antiga)
        try:
            self.aguardar(entrou)
            self.promover_real()
            outro = LeitorDadosServidor(infraestrutura_cliente=self.infra)
            self.addCleanup(outro.parar)
            b = outro._admissao_register
            self.concluir(controle=b)
            antes_a, antes_b = self.evidencia(), self.evidencia(b)
        finally:
            liberar.set()
            self.terminar(tarefa)
        self.assertEqual(antes_a['fonte_id'], self.evidencia()['fonte_id'])
        self.assertGreater(self.revisao(), antes_a['revisao'])
        self.assertEqual(antes_b, self.evidencia(b))
        self.assertEqual(2, len(self.infra.obter_evidencias_temporais_register()))

    def test_corrida_e_mutacao_parcial_publicacao_falha(self):
        entrou, liberar = threading.Event(), threading.Event()
        erro = OSError('publicacao_parcial_simulada')
        publicar = self.controle._publicar_saida
        def parcial(*args):
            publicar(*args)
            entrou.set()
            self.aguardar(liberar)
            raise erro
        with patch.object(self.controle, '_publicar_saida', side_effect=parcial):
            tarefa = self.tarefa(self.concluir)
            try:
                self.aguardar(entrou)
                self.assertTrue(self.item()['retorno'])
                self.assertTrue(self.item()['execucao_em_curso'])
            finally:
                liberar.set()
                tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())
        self.assertEqual([erro], tarefa[2])
        self.assertFalse(self.evidencia()['confiavel'])
        self.assertTrue(self.item()['erro_publicacao'])
        self.assertFalse(self.item()['retorno'])

    def test_corrida_e_consulta_espera_invalidacao_da_mutacao_parcial(self):
        entrou, liberar, consultando, consultou = (threading.Event() for _ in range(4))
        original = OSError('revisao_simulada')
        def falhar():
            entrou.set()
            self.aguardar(liberar)
            raise original
        def consultar():
            consultando.set()
            r = self.evidencia()
            consultou.set()
            return r
        with patch.object(self.controle, '_avancar_revisao', side_effect=falhar):
            admissao = self.tarefa(self.controle.admitir)
            try:
                self.aguardar(entrou)
                consulta = self.tarefa(consultar)
                self.aguardar(consultando)
                self.assertFalse(consultou.wait(0.03))
            finally:
                liberar.set()
                admissao[0].join(3)
            e = self.terminar(consulta)[0]
        self.assertFalse(admissao[0].is_alive())
        self.assertEqual([original], admissao[2])
        self.assertEqual(0, e['revisao'])
        self.assertEqual(1, len(e['retrato']['operacoes']))
        self.assertFalse(e['confiavel'])

    def test_corrida_f_resultado_antigo_e_fechamento(self):
        entrou, liberar = threading.Event(), threading.Event()
        publicar = self.controle._publicar_saida
        def suspender(*args):
            publicar(*args)
            entrou.set()
            self.aguardar(liberar)
        with patch.object(self.controle, '_publicar_saida', side_effect=suspender):
            tarefa = self.tarefa(self.concluir)
            try:
                self.aguardar(entrou)
                antes = self.revisao()
                self.leitor.parar()
                self.assertEqual(antes + 1, self.revisao())
            finally:
                liberar.set()
                self.terminar(tarefa)
        self.assertGreater(self.revisao(), antes + 1)
        self.assertTrue(self.item()['retorno'])
        self.assertTrue(self.evidencia()['retrato']['admissao_fechada'])

    def test_adicional_register_real_e_limpeza_tcp_posterior(self):
        bruto = self.bruto()
        bruto.erro_close = OSError('limpeza_simulada')
        with self.assertRaises(OSError):
            self.operar(bruto)
        antes, recursos = self.evidencia(), self.registro.obter_retrato()
        self.assertTrue(self.item()['retorno'])
        bruto.erro_close = None
        token = next(iter(self.controle._operacoes.values()))['dono']
        token = next(t for t, tipo in token._emitidos.items() if tipo == 'socket_tcp')
        self.registro.fechar(token)
        self.assertNotEqual(recursos, self.registro.obter_retrato())
        self.assertEqual(antes, self.evidencia())
        resultado = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(resultado['encerramento_cliente_confirmado'])
        self.assertFalse(resultado['encerramento_global_confirmado'])

    def test_retencao_incerta_mutacao_observada_antes_de_retornar(self):
        entrou, liberar = threading.Event(), threading.Event()
        bruto = self.bruto()
        t = self.controle.admitir()
        def criar(_token, alocar):
            alocar()
            raise ValueError('criacao_simulada')
        def limpar():
            self.assertTrue(self.controle._lock.acquire(blocking=False))
            self.controle._lock.release()
            entrou.set()
            self.aguardar(liberar)
        bruto.close = limpar
        with patch.object(self.registro, 'criar', side_effect=criar):
            tarefa = self.tarefa(lambda: self.operar(bruto, t))
            try:
                self.aguardar(entrou)
                e = self.evidencia()
                self.assertEqual(1, len(e['retrato']['publicacoes_pendentes']))
                self.assertTrue(e['retrato']['operacoes'][0]['execucao_em_curso'])
                self.assertGreater(e['revisao'], 1)
                self.assertTrue(e['confiavel'])
            finally:
                liberar.set()
                tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())
        self.assertEqual(1, len(tarefa[2]))
        self.assertIsInstance(tarefa[2][0], ValueError)
        self.assertEqual(1, len(self.evidencia()['retrato']['publicacoes_pendentes']))

    def test_buffer_local_insercao_substituicao_remocao_idempotencia(self):
        t = self.controle.admitir()
        with self.controle.executar(t) as dono:
            socket = dono.abrir_socket(self.bruto)
        token = socket.recurso_id
        for valor in ((socket, None), (socket, 'falha_io')):
            antes = self.revisao()
            with self.controle._lock_publicacoes:
                self.controle._publicacoes_pendentes[token] = valor
            self.assertEqual(antes + 1, self.revisao())
            with self.controle._lock_publicacoes:
                self.controle._publicacoes_pendentes[token] = valor
            self.assertEqual(antes + 1, self.revisao())
        antes = self.revisao()
        with self.controle._lock_publicacoes:
            self.controle._publicacoes_pendentes.pop(token)
        self.assertEqual(antes + 1, self.revisao())
        socket.close()

    def test_buffer_herdado_remove_apos_fechamento_confirmado(self):
        criar, fechar, sair = (self.registro.criar, self.registro.fechar,
                              self.controle._saida_preservando)
        revisoes = []
        def falhar(token, alocar):
            criar(token, alocar)
            revisoes.append(self.revisao())
            raise ValueError('criacao_simulada')
        def limpar(token):
            self.assertEqual(revisoes[0] + 1, self.revisao())
            self.assertEqual(1, len(self.evidencia()['retrato']['publicacoes_pendentes']))
            return fechar(token)
        def publicar(*args):
            self.assertEqual(revisoes[0] + 2, self.revisao())
            self.assertEqual([], self.evidencia()['retrato']['publicacoes_pendentes'])
            return sair(*args)
        with patch.object(self.registro, 'criar', side_effect=falhar), \
             patch.object(self.registro, 'fechar', side_effect=limpar), \
             patch.object(self.controle, '_saida_preservando', side_effect=publicar):
            with self.assertRaises(ValueError):
                self.operar()
        self.assertTrue(self.evidencia()['confiavel'])

    def test_buffer_herdado_registra_categoria_de_limpeza(self):
        bruto = self.bruto()
        sair = self.controle._saida_preservando
        revisoes = []
        def falhar(_token, alocar):
            alocar()
            revisoes.append(self.revisao())
            raise ValueError('criacao_simulada')
        bruto.erro_close = OSError('limpeza_simulada')
        def publicar(*args):
            self.assertEqual(revisoes[0] + 2, self.revisao())
            pendentes = self.evidencia()['retrato']['publicacoes_pendentes']
            self.assertEqual('falha_io', pendentes[0]['erro_limpeza'])
            return sair(*args)
        with patch.object(self.registro, 'criar', side_effect=falhar), \
             patch.object(self.controle, '_saida_preservando', side_effect=publicar):
            with self.assertRaises(ValueError):
                self.operar(bruto)
        self.assertTrue(self.evidencia()['confiavel'])
        bruto.erro_close = None
        bruto.close()

    def test_erro_associacao_invalida_sem_fabrica(self):
        fabrica = Mock()
        with patch.object(RecursosRegisterCliente, '_publicar_vinculo', side_effect=OSError('associacao_simulada')):
            with self.assertRaises(OSError):
                self.operar(fabrica=fabrica)
        fabrica.assert_not_called()
        self.assertFalse(self.evidencia()['confiavel'])
        self.assertTrue(self.item()['erro_associacao'])

    def test_revisao_falha_apos_mutacao_invalida(self):
        with patch.object(self.controle, '_avancar_revisao', side_effect=OSError('revisao_simulada')):
            with self.assertRaises(OSError):
                self.controle.admitir()
        self.assertEqual(1, len(self.evidencia()['retrato']['operacoes']))
        self.assertFalse(self.evidencia()['confiavel'])
        self.controle.fechar_admissao()
        self.assertFalse(self.evidencia()['confiavel'])

    def test_revisao_silenciosamente_nao_publicada(self):
        with patch.object(self.controle, '_avancar_revisao', return_value=None):
            with self.assertRaisesRegex(RuntimeError, 'revisao_register_nao_publicada'):
                self.controle.admitir()
        self.assertFalse(self.evidencia()['confiavel'])

    def test_revisao_incrementada_antes_de_falhar_nao_retrocede(self):
        avancar = self.controle._avancar_revisao
        def falhar():
            avancar()
            raise OSError('revisao_simulada')
        with patch.object(self.controle, '_avancar_revisao', side_effect=falhar):
            with self.assertRaises(OSError):
                self.controle.admitir()
        self.assertEqual(1, self.revisao())
        self.assertFalse(self.evidencia()['confiavel'])
        self.controle.admitir()
        self.assertEqual(2, self.revisao())
        self.assertFalse(self.evidencia()['confiavel'])

    def test_publicacao_falha_e_revisao_falha_preservam_publicacao(self):
        t = self.controle.admitir()
        original, adicional = OSError('publicacao_simulada'), RuntimeError('revisao_simulada')
        with self.controle.executar(t):
            with patch.object(self.controle, '_publicar_saida', side_effect=original), \
                 patch.object(self.controle, '_avancar_revisao', side_effect=adicional):
                with self.assertRaises(OSError) as recebido:
                    self.controle._saida_preservando(t, None)
        self.assertIs(original, recebido.exception)
        self.assertIn(adicional, original._falhas_acompanhamento_register)
        self.assertFalse(self.evidencia()['confiavel'])

    def test_recusas_sem_mudanca_nao_comprometem(self):
        outro = AdmissaoRegisterCliente(None)
        t = outro.admitir()
        antes = self.evidencia()
        with self.assertRaises(ValueError):
            with self.controle.executar(t):
                pass
        self.assertEqual(antes, self.evidencia())

    def test_fonte_somente_leitura_e_objetos_distintos(self):
        with self.assertRaises(AttributeError):
            self.controle.fonte_id = 'outra'
        outro = AdmissaoRegisterCliente(None)
        self.assertNotEqual(self.controle.fonte_id, outro.fonte_id)

    def test_evidencia_defensiva(self):
        self.operar()
        e = self.evidencia()
        e['retrato']['operacoes'][0]['vinculos'].clear()
        e['retrato']['operacoes'][0]['retorno'] = False
        self.assertTrue(self.item()['retorno'])
        self.assertTrue(self.item()['vinculos'])

    def test_composicao_nao_consulta_nova_api(self):
        with patch.object(self.controle, 'obter_evidencia_temporal', side_effect=AssertionError('uso_implicito')):
            resultado = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(resultado['encerramento_cliente_confirmado'])
        self.assertFalse(resultado['encerramento_global_confirmado'])

    def test_erros_exclusivamente_operacionais_nao_invalidam(self):
        bruto = self.bruto()
        bruto.sendall.side_effect = OSError('envio_simulado')
        with self.assertRaises(OSError):
            self.operar(bruto)
        self.assertTrue(self.evidencia()['confiavel'])
        self.assertEqual({'categoria': 'falha_io'}, self.item()['erro_operacao'])

    def test_multiplas_falhas_de_acompanhamento_preservadas(self):
        original, publicacao, acompanhamento = ValueError(), OSError(), RuntimeError()
        t = self.controle.admitir()
        with self.assertRaises(ValueError) as recebido:
            with self.controle.executar(t):
                with patch.object(self.controle, '_publicar_saida', side_effect=publicacao), \
                     patch.object(self.controle, '_avancar_revisao', side_effect=acompanhamento):
                    self.controle._saida_preservando(t, original)
                raise original
        self.assertIs(original, recebido.exception)
        self.assertIn(publicacao, original._falhas_acompanhamento_register)
        self.assertIn(acompanhamento, original._falhas_acompanhamento_register)
        self.assertFalse(self.evidencia()['confiavel'])

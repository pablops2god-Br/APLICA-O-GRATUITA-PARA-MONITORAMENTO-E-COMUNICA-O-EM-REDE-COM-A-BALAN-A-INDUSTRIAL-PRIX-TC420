"""Fluxos reais Tk do laboratório, credencial aleatória e transporte proibido."""
import secrets
import socket
import time
import tkinter as tk
from unittest.mock import patch


def executar():
    from ensaio_visual_tk import EnsaioVisual, LeitorTCPOffline
    socket_original = socket.socket
    e = EnsaioVisual()
    erros = []
    e.conexao.root.report_callback_exception = lambda *args: erros.append(args)
    e.rede.atraso = 0.01
    def esperar(condicao):
        limite = time.monotonic() + 5
        while not condicao() and time.monotonic() < limite:
            e.conexao.root.update()
            time.sleep(0.01)
        assert condicao(), 'fluxo não concluiu no prazo'
    try:
        e.conexao.root.update()
        assert len(e.abas.tabs()) == 5
        assert not e.configuracao_autorizada
        senha = secrets.token_urlsafe(16)
        tela = e.admin.tela
        tela.senha.insert(0, senha)
        tela.repeticao.insert(0, senha)
        tela.botao.invoke()
        esperar(lambda: e.admin.tela is not None and not e.admin.tela.cadastro)
        assert not e.admin.autorizado and not e.configuracao_autorizada
        tela = e.admin.tela
        tela.senha.insert(0, senha)
        tela.botao.invoke()
        esperar(lambda: e.admin.tela is None)
        assert e.configuracao_autorizada
        with patch.object(e.painel, 'lift') as abrir_laboratorio:
            e.conexao.root.atalho_ensaio.invoke()
            assert e.admin.tela is not None
            abrir_laboratorio.assert_not_called()
            tela = e.admin.tela
            tela.senha.insert(0, secrets.token_urlsafe(16))
            tela.botao.invoke()
            esperar(lambda: tela.botao.cget('state') == 'normal')
            abrir_laboratorio.assert_not_called()
            tela.senha.insert(0, senha)
            tela.botao.invoke()
            esperar(lambda: e.admin.tela is None)
            abrir_laboratorio.assert_called_once()
        credencial = e.admin.credencial
        with patch.object(e, 'abrir_monitor') as automatico:
            e.admin.iniciar_aplicacao('HTTPS')
            automatico.assert_called_once()
        assert e.admin.tela is None
        assert not e.admin.autorizado
        e.admin.iniciar_aplicacao('TCP')
        assert e.admin.tela is not None and not e.admin.tela.cadastro
        tela = e.admin.tela
        with patch('admin_visual_tk.messagebox.askyesno', return_value=False):
            tela.restaurar()
        assert e.admin.credencial is credencial and e.admin.tela is tela
        with patch('admin_visual_tk.messagebox.askyesno', return_value=True):
            tela.restaurar()
        esperar(lambda: e.admin.tela is not None)
        assert e.admin.credencial is None and e.admin.tela.cadastro
        assert not e.conexao.campo_ip.get() and not e.conexao.campo_senha.get()
        tela = e.admin.tela
        tela.senha.insert(0, senha)
        tela.repeticao.insert(0, senha)
        tela.botao.invoke()
        esperar(lambda: e.admin.tela is not None and not e.admin.tela.cadastro)
        assert not e.admin.autorizado and not e.configuracao_autorizada
        tela = e.admin.tela
        tela.senha.insert(0, senha)
        tela.botao.invoke()
        esperar(lambda: e.admin.tela is None)
        e._preencher_campos()
        e.promocao_manual()
        assert e.monitor.janela_promocao is None
        tela = e.admin.tela
        tela.senha.insert(0, secrets.token_urlsafe(16))
        tela.botao.invoke()
        esperar(lambda: tela.botao.cget('state') == 'normal')
        assert e.monitor.janela_promocao is None
        assert 'não autorizado' in tela.status.cget('text')
        tela.senha.insert(0, senha)
        tela.botao.invoke()
        esperar(lambda: e.monitor.janela_promocao is not None)
        popup = e.monitor.janela_promocao
        popup.metodo_conexao.set('TCP')
        popup.botao_acao.invoke()
        esperar(lambda: e.monitor.janela_promocao is None)
        assert isinstance(e.monitor.leitor_tcp_local, LeitorTCPOffline)
        e.monitor.root.update_idletasks()
        horario = e.monitor.label_atualizacao
        assert horario.winfo_ismapped()
        assert horario.cget('text').startswith('Atualização: ')
        assert horario.winfo_reqwidth() <= horario.winfo_width(), 'data/hora cortada'
        e.tcp_avancar(6)
        assert e.monitor.comunicacao_confirmada
        e.tcp_avancar(11)
        assert not e.monitor.comunicacao_confirmada
        e.tcp_avancar(None)
        assert e.monitor.comunicacao_confirmada
        e.monitor.menu_opcoes.invoke('Reconfigurar')
        assert e.admin.tela is not None
        assert not e.saida.parada_solicitada
        monitor_anterior = e.monitor
        tela = e.admin.tela
        tela.senha.insert(0, senha)
        tela.botao.invoke()
        esperar(lambda: e.monitor is None)
        assert not monitor_anterior.root.winfo_exists()
        assert e.conexao.root.winfo_viewable()
        assert not e.saida.parada_solicitada
        e.abrir_monitor()
        monitor_anterior = e.monitor
        e.monitor.menu_opcoes.invoke('Reconfigurar')
        with patch('admin_visual_tk.messagebox.askyesno', return_value=True):
            e.admin.tela.restaurar()
        esperar(lambda: e.admin.tela is not None and e.admin.tela.cadastro)
        assert e.monitor is None and not monitor_anterior.root.winfo_exists()
        assert not e.conexao.campo_ip.get()
        e.admin.tela.fechar()
        for _ in range(1005):
            e.registrar('autoteste: limite do registro visual')
        assert e.lista.size() == 1000
        assert all(m.call_count == 0 for m in e.efeitos_proibidos)
        with patch('ensaio_visual_tk.messagebox.askyesno', return_value=False):
            e.conexao.root.tk.call(e.conexao.root.protocol('WM_DELETE_WINDOW'))
        assert not e.saida.parada_solicitada
        assert not erros, 'erro em callback Tk'
        print('Laboratório Tk: abas, cadastro/login, recusa, ASSUMIR, reconfiguração e TCP virtual OK.')
    finally:
        with patch('ensaio_visual_tk.messagebox.askyesno', return_value=True):
            e.conexao.root.tk.call(e.conexao.root.protocol('WM_DELETE_WINDOW'))
        limite = time.monotonic() + 5
        while e.isolamento._exit_callbacks and time.monotonic() < limite:
            try:
                e.conexao.root.update()
            except tk.TclError:
                break
            time.sleep(0.01)
        assert not e.isolamento._exit_callbacks, ('isolamento não restaurado após saída',
                                                e.saida.obter_situacao(), len(erros))
        assert socket.socket is socket_original
        assert not erros, 'erro em callback Tk'
        print('Saída B2 e restauração dos patches OK; nenhuma rede/cofre/credencial real.')


if __name__ == '__main__':
    executar()

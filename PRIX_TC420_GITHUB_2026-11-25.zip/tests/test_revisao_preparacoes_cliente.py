# Testes de revisao preparacoes cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-D3-B2-A: revisao da fonte real, IO falso e barreiras de ensaio."""
from contextlib import ExitStack
import threading
import unittest
from unittest.mock import Mock, patch

from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.preparacoes_cliente import RegistroPreparacoesCliente
from test_descoberta_cliente_integrada import SocketDescobertaFalso


# Grupo de 40 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class RevisaoPreparacoesCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_preparacoes

    def evidencia(self):
        r = self.infra.obter_evidencia_temporal_preparacoes()
        self.assertFalse(r['dependencias_temporais_cobertas'])
        self.assertFalse(r['snapshot_atomico'])
        self.assertFalse(r['encerramento_cliente_confirmado'])
        self.assertFalse(r['encerramento_global_confirmado'])
        return r

    def revisao(self):
        return self.registro.obter_revisao()['revisao']

    def executar(self):
        token = self.registro.admitir()
        self.registro.executar(token, lambda: None)
        return token

    def trabalho(self, chamada):
        resultados, erros = [], []
        def alvo():
            try:
                resultados.append(chamada())
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=alvo)
        thread.start()
        return thread, resultados, erros

    def concluir(self, tarefa):
        tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())

    def test_01_estado_inicial(self):
        r = self.evidencia()
        self.assertTrue(r['confiavel'])
        self.assertEqual(0, r['revisao'])
        self.assertEqual([], r['preparacoes'])
        self.assertEqual(self.infra.aplicacao_id, r['aplicacao_id'])

    def test_02_primeira_reserva(self):
        token = self.registro.admitir()
        r = self.evidencia()
        self.assertEqual(1, r['revisao'])
        self.assertEqual(token.numero, r['preparacoes'][0]['preparacao_id'])
        self.assertFalse(r['preparacoes'][0]['iniciada'])

    def test_03_entrada_execucao(self):
        token = self.registro.admitir()
        def corpo():
            r = self.evidencia()
            self.assertEqual(2, r['revisao'])
            self.assertTrue(r['preparacoes'][0]['em_curso'])
        self.registro.executar(token, corpo)

    def test_04_retorno_normal(self):
        token = self.registro.admitir()
        objeto = object()
        self.assertIs(objeto, self.registro.executar(token, lambda: objeto))
        r = self.evidencia()
        self.assertEqual(5, r['revisao'])
        self.assertTrue(r['confiavel'])
        self.assertTrue(r['preparacoes'][0]['retorno'])
        self.assertFalse(r['preparacoes'][0]['em_curso'])

    def test_05_retorno_excepcional(self):
        token = self.registro.admitir()
        original = OSError('falha_simulada')
        with self.assertRaises(OSError) as recebido:
            self.registro.executar(token, Mock(side_effect=original))
        self.assertIs(original, recebido.exception)
        r = self.evidencia()
        self.assertEqual(5, r['revisao'])
        self.assertTrue(r['confiavel'])
        self.assertEqual('falha', r['preparacoes'][0]['resultado'])
        self.assertEqual({'categoria': 'falha_io'}, r['preparacoes'][0]['erro_operacional'])

    def test_06_nova_preparacao(self):
        self.executar()
        antes = self.revisao()
        self.registro.admitir()
        self.assertEqual(antes + 1, self.revisao())
        self.assertEqual(2, len(self.evidencia()['preparacoes']))

    def test_07_preparacao_antiga_alterada(self):
        a = self.executar()
        b = self.executar()
        antes = self.revisao()
        self.registro._publicar_resultado(a, ValueError())
        self.assertEqual(antes + 1, self.revisao())
        itens = self.evidencia()['preparacoes']
        self.assertEqual([a.numero, b.numero], [i['preparacao_id'] for i in itens])
        self.assertEqual(['falha', 'retorno'], [i['resultado'] for i in itens])

    def test_08_consulta_repetida_estavel(self):
        self.executar()
        antes = self.evidencia()
        for _ in range(3):
            self.infra.obter_preparacoes()
            self.assertEqual(antes, self.evidencia())
        self.assertEqual(antes['revisao'], self.revisao())

    def test_09_ABA_pendencias(self):
        def pendentes():
            return sum(not p['retorno'] or p['em_curso'] for p in self.evidencia()['preparacoes'])
        antes, revisao = pendentes(), self.revisao()
        token = self.registro.admitir()
        self.assertEqual(1, pendentes())
        self.registro.executar(token, lambda: None)
        self.assertEqual(antes, pendentes())
        self.assertGreater(self.revisao(), revisao)

    def test_10_falha_antes_mutacao(self):
        antes = self.evidencia()
        with patch('rede.preparacoes_cliente.PreparacaoClienteId', side_effect=MemoryError()):
            with self.assertRaises(MemoryError):
                self.registro.admitir()
        self.assertEqual(antes, self.evidencia())
        self.assertEqual(1, self.registro.admitir().numero)

    def test_11_falha_apos_mutacao(self):
        with patch.object(self.registro, '_avancar_revisao', side_effect=OSError()):
            with self.assertRaises(OSError):
                self.registro.admitir()
        r = self.evidencia()
        self.assertEqual(0, r['revisao'])
        self.assertFalse(r['confiavel'])
        self.assertEqual(1, len(r['preparacoes']))

    def test_12_falha_publicacao(self):
        token = self.registro.admitir()
        with patch.object(self.registro, '_publicar_resultado', side_effect=RuntimeError()):
            with self.assertRaises(RuntimeError):
                self.registro.executar(token, lambda: None)
        r = self.evidencia()
        self.assertFalse(r['confiavel'])
        self.assertTrue(r['preparacoes'][0]['erro_publicacao'])
        self.assertFalse(self.infra.obter_preparacoes()['preparacoes'][0]['execucao_resolvida'])

    def duas_execucoes(self):
        barreira, liberar = threading.Barrier(3), threading.Event()
        def executar():
            token = self.registro.admitir()
            def corpo():
                barreira.wait(3)
                if not liberar.wait(3):
                    raise TimeoutError('barreira_simulada')
            self.registro.executar(token, corpo)
            return token.numero
        a, b = self.trabalho(executar), self.trabalho(executar)
        try:
            barreira.wait(3)
            r = self.evidencia()
            self.assertEqual(4, r['revisao'])
            self.assertTrue(all(p['em_curso'] for p in r['preparacoes']))
        finally:
            liberar.set()
            self.concluir(a)
            self.concluir(b)
        self.assertEqual([], a[2] + b[2])
        self.assertEqual({1, 2}, set(a[1] + b[1]))
        self.assertEqual(10, self.revisao())
        self.assertTrue(self.evidencia()['confiavel'])

    def test_13_alteracoes_concorrentes(self):
        self.duas_execucoes()

    def promocao_publicacao(self):
        entrou, liberar = threading.Event(), threading.Event()
        publicar = self.registro._publicar_resultado
        def atrasar(token, erro):
            if token.numero == 1:
                entrou.set()
                if not liberar.wait(3):
                    raise TimeoutError('barreira_simulada')
            return publicar(token, erro)
        with patch.object(self.registro, '_publicar_resultado', side_effect=atrasar):
            a = self.trabalho(lambda: self.infra.executar_descoberta_preparacao(lambda dono: None))
            try:
                self.assertTrue(entrou.wait(3))
                origem = self.evidencia()['preparacoes'][0]['origem_recursos']
                dono = self.infra._donos_descobertas[0]
                self.infra.registro_retentativas.promover(dono._geracao_retentativas)
                self.infra.executar_descoberta_preparacao(lambda novo: None)
                antes = self.evidencia()
                self.assertFalse(antes['preparacoes'][0]['retorno'])
                self.assertTrue(antes['preparacoes'][1]['retorno'])
            finally:
                liberar.set()
                self.concluir(a)
        self.assertEqual([], a[2])
        depois = self.evidencia()
        self.assertGreater(depois['revisao'], antes['revisao'])
        self.assertEqual(origem, depois['preparacoes'][0]['origem_recursos'])
        self.assertTrue(all(p['retorno'] for p in depois['preparacoes']))

    def test_14_promocao_publicacao(self):
        self.promocao_publicacao()

    def leitura_durante_atualizacao(self):
        entrou, liberar, leitor_iniciado, leitor_terminou = [threading.Event() for _ in range(4)]
        avancar = self.registro._avancar_revisao
        def pausa():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return avancar()
        def ler():
            leitor_iniciado.set()
            resultado = self.evidencia()
            leitor_terminou.set()
            return resultado
        with patch.object(self.registro, '_avancar_revisao', side_effect=pausa):
            escritor = self.trabalho(self.registro.admitir)
            leitor = None
            try:
                self.assertTrue(entrou.wait(3))
                self.assertTrue(self.registro._lock.locked())
                leitor = self.trabalho(ler)
                self.assertTrue(leitor_iniciado.wait(3))
                self.assertFalse(leitor_terminou.is_set())
            finally:
                liberar.set()
                self.concluir(escritor)
                if leitor is not None:
                    self.concluir(leitor)
        self.assertEqual([], escritor[2] + leitor[2])
        r, = leitor[1]
        self.assertTrue(r['confiavel'])
        self.assertEqual(1, r['revisao'])
        self.assertEqual(1, len(r['preparacoes']))

    def test_15_leitura_durante_atualizacao(self):
        self.leitura_durante_atualizacao()

    def test_16_API_legada(self):
        self.infra.executar_descoberta_preparacao(lambda dono: None)
        legado = self.infra.obter_preparacoes()
        self.assertEqual({'aplicacao_id', 'autoridade_encerramento', 'preparacoes',
            'cobertura_operacional', 'snapshot_atomico', 'encerramento_cliente_confirmado',
            'encerramento_global_confirmado'}, set(legado))
        self.assertNotIn('revisao', legado)
        self.assertNotIn('fonte_id', legado)
        self.assertEqual({'preparacao_id', 'origem', 'iniciada', 'em_curso', 'retorno',
            'publicacao_em_curso', 'erro_publicacao', 'erro_associacao', 'resultado',
            'erro_operacional', 'execucao_resolvida', 'origem_recursos', 'recursos',
            'recursos_pendentes', 'publicacoes_recursos_pendentes',
            'recursos_conhecidos_resolvidos'}, set(legado['preparacoes'][0]))

    def test_corrida_A_leitura_simultanea(self):
        self.leitura_durante_atualizacao()

    def test_corrida_B_ABA(self):
        antes = self.registro.obter_revisao()
        tarefa = self.trabalho(self.executar)
        self.concluir(tarefa)
        self.assertEqual([], tarefa[2])
        depois = self.registro.obter_revisao()
        self.assertEqual(antes['fonte_id'], depois['fonte_id'])
        self.assertGreater(depois['revisao'], antes['revisao'])
        self.assertTrue(all(p['retorno'] for p in self.evidencia()['preparacoes']))

    def test_corrida_C_sem_perder_revisoes(self):
        self.duas_execucoes()

    def test_corrida_D_promocao_tardia(self):
        self.promocao_publicacao()

    def test_corrida_E_falha_publicacao_revisao(self):
        token = self.registro.admitir()
        avancar = self.registro._avancar_revisao
        chamadas = []
        def falhar_uma_vez():
            chamadas.append(True)
            if len(chamadas) == 3:  # Resultado ja alterado, revisao ainda nao publicada.
                raise OSError('revisao_simulada')
            avancar()
        with patch.object(self.registro, '_avancar_revisao', side_effect=falhar_uma_vez):
            with self.assertRaises(OSError):
                self.registro.executar(token, lambda: None)
        self.assertFalse(self.evidencia()['confiavel'])
        self.assertFalse(self.evidencia()['preparacoes'][0]['retorno'])
        self.assertTrue(self.evidencia()['preparacoes'][0]['erro_publicacao'])

    def test_corrida_F_antes_UDP(self):
        entrou, liberar = threading.Event(), threading.Event()
        reservar = self.infra.registro_recursos.reservar
        def pausa(*args, **kwargs):
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return reservar(*args, **kwargs)
        from rede.buscarservidor import buscar_servidor
        with patch.object(self.infra.registro_recursos, 'reservar', side_effect=pausa), \
                patch('socket.socket', return_value=SocketDescobertaFalso()):
            tarefa = self.trabalho(lambda: buscar_servidor(infraestrutura_cliente=self.infra))
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.evidencia()
                self.assertGreater(antes['revisao'], 0)
                self.assertTrue(antes['preparacoes'][0]['em_curso'])
                self.assertEqual([], self.infra.registro_recursos.obter_retrato()['recursos'])
                self.assertEqual(antes, self.evidencia())
            finally:
                liberar.set()
                self.concluir(tarefa)
        self.assertEqual([], tarefa[2])
        self.assertGreater(self.revisao(), antes['revisao'])

    def test_adicional_composicao_independente_da_revisao(self):
        antes = self.infra.avaliar_responsabilidades_cliente()
        self.infra.executar_descoberta_preparacao(lambda dono: None)
        revisao = self.registro.obter_revisao()
        with patch.object(self.registro, 'obter_revisao', side_effect=AssertionError()), \
                patch.object(self.registro, 'obter_evidencia_temporal', side_effect=AssertionError()):
            depois = self.infra.avaliar_responsabilidades_cliente()
        self.assertEqual(antes, depois)
        self.assertFalse(depois['encerramento_cliente_confirmado'])
        self.assertFalse(depois['encerramento_global_confirmado'])
        self.assertEqual(revisao, self.registro.obter_revisao())

    def test_recusas_sem_mutacao_nao_avancam(self):
        estrangeiro = InfraestruturaRegistrosCliente().registro_preparacoes.admitir()
        token = self.executar()
        antes = self.evidencia()
        for ident, chamada in ((estrangeiro, lambda: None), (token, lambda: None), (token, None)):
            with self.assertRaises((TypeError, ValueError, RuntimeError)):
                self.registro.executar(ident, chamada)
        self.assertEqual(antes, self.evidencia())

    def test_resultado_identico_nao_avanca(self):
        token = self.executar()
        antes = self.evidencia()
        self.registro._publicar_resultado(token, None)
        self.assertEqual(antes, self.evidencia())

    def test_vinculo_do_dono_e_revisado(self):
        def corpo(dono):
            r = self.evidencia()
            self.assertEqual(3, r['revisao'])
            self.assertEqual(dono.geracao_id, r['preparacoes'][0]['origem_recursos']['geracao_id'])
        self.infra.executar_descoberta_preparacao(corpo)
        self.assertEqual(6, self.revisao())

    def test_erro_associacao_e_mutacao_revisada(self):
        token = self.registro.admitir()
        def corpo():
            antes = self.revisao()
            with self.assertRaises(ValueError):
                self.registro.vincular_recursos(token, object())
            self.assertEqual(antes + 1, self.revisao())
            self.assertTrue(self.evidencia()['preparacoes'][0]['erro_associacao'])
        self.registro.executar(token, corpo)

    def test_consulta_temporal_nao_acessa_dependencias(self):
        self.executar()
        antes = self.evidencia()
        with ExitStack() as pilha:
            for obj, nome in ((self.infra.registro_recursos, 'obter_retrato'),
                              (self.registro, 'admitir'), (self.registro, 'executar'),
                              (self.registro, '_avancar_revisao'), (self.registro, '_publicar_resultado')):
                pilha.enter_context(patch.object(obj, nome, side_effect=AssertionError(nome)))
            self.assertEqual(antes, self.evidencia())

    def test_recurso_externo_muda_sem_alterar_selo_local(self):
        clientes = []
        self.infra.executar_descoberta_preparacao(
            lambda dono: clientes.append(dono.abrir_socket(SocketDescobertaFalso)))
        cliente, = clientes
        self.addCleanup(cliente.close)
        antes = self.evidencia()
        self.assertFalse(self.infra.obter_preparacoes()['preparacoes'][0]['recursos_conhecidos_resolvidos'])
        cliente.close()
        self.assertEqual(antes, self.evidencia())
        self.assertTrue(self.infra.obter_preparacoes()['preparacoes'][0]['recursos_conhecidos_resolvidos'])

    def test_fontes_distintas_com_revisao_zero(self):
        outro = RegistroPreparacoesCliente(self.infra)
        self.assertEqual(self.revisao(), outro.obter_revisao()['revisao'])
        self.assertNotEqual(self.registro.fonte_id, outro.fonte_id)
        with self.assertRaises(AttributeError):
            self.registro.fonte_id = 'outra'

    def test_publicacao_parcial_nao_confirma(self):
        token = self.registro.admitir()
        publicar = self.registro._publicar_resultado
        def parcial(*args):
            publicar(*args)
            raise OSError('apos_publicar')
        with patch.object(self.registro, '_publicar_resultado', side_effect=parcial):
            with self.assertRaises(OSError):
                self.registro.executar(token, lambda: None)
        self.assertFalse(self.evidencia()['confiavel'])
        self.assertFalse(self.evidencia()['preparacoes'][0]['retorno'])

    def test_publicacao_sem_incremento_e_inconfiavel(self):
        with patch.object(self.registro, '_avancar_revisao', return_value=None):
            with self.assertRaisesRegex(RuntimeError, 'revisao_preparacao_nao_publicada'):
                self.registro.admitir()
        self.assertFalse(self.evidencia()['confiavel'])

    def test_incerteza_nao_e_apagada_por_nova_preparacao(self):
        with patch.object(self.registro, '_avancar_revisao', side_effect=OSError()):
            with self.assertRaises(OSError):
                self.registro.admitir()
        self.executar()
        self.assertFalse(self.evidencia()['confiavel'])

    def test_erro_original_e_traceback_preservados(self):
        token = self.registro.admitir()
        original = ValueError('original_simulado')
        recebido_no_corpo = []
        def corpo():
            try:
                raise original
            except ValueError as erro:
                recebido_no_corpo.append(erro.__traceback__)
                raise
        avancar = self.registro._avancar_revisao
        chamadas = []
        falha = OSError('revisao_simulada')
        def falhar():
            chamadas.append(True)
            if len(chamadas) == 2:  # Acompanhamento depois do erro operacional.
                raise falha
            avancar()
        with patch.object(self.registro, '_avancar_revisao', side_effect=falhar):
            try:
                self.registro.executar(token, corpo)
            except ValueError as recebido:
                self.assertIs(original, recebido)
                tb, cadeia = recebido.__traceback__, []
                while tb is not None:
                    cadeia.append(tb)
                    tb = tb.tb_next
            else:
                self.fail('erro operacional nao propagado')
        self.assertIs(falha, original.__cause__)
        self.assertIn(recebido_no_corpo[0], cadeia)
        self.assertEqual('corpo', recebido_no_corpo[0].tb_frame.f_code.co_name)
        self.assertFalse(self.evidencia()['confiavel'])

    def test_falha_finalizacao_e_conservadora(self):
        token = self.registro.admitir()
        avancar = self.registro._avancar_revisao
        chamadas = []
        def falhar():
            chamadas.append(True)
            if len(chamadas) == 4:
                raise OSError('finalizacao_simulada')
            avancar()
        with patch.object(self.registro, '_avancar_revisao', side_effect=falhar):
            with self.assertRaises(OSError):
                self.registro.executar(token, lambda: None)
        self.assertFalse(self.evidencia()['confiavel'])
        self.assertFalse(self.infra.obter_preparacoes()['preparacoes'][0]['execucao_resolvida'])

    def test_falha_incremento_apos_avancar(self):
        avancar = self.registro._avancar_revisao
        def falhar():
            avancar()
            raise OSError()
        with patch.object(self.registro, '_avancar_revisao', side_effect=falhar):
            with self.assertRaises(OSError):
                self.registro.admitir()
        self.assertEqual(1, self.revisao())
        self.assertFalse(self.evidencia()['confiavel'])

    def test_copias_independentes_sem_textos_operacionais(self):
        self.infra.executar_descoberta_preparacao(lambda dono: None)
        antes = self.evidencia()
        copia = self.evidencia()
        copia['preparacoes'][0]['origem_recursos']['geracao_id'] = 999
        self.assertEqual(antes, self.evidencia())
        self.assertNotIn('dono_recursos', str(antes))
        self.assertNotIn('thread', str(antes))

    def test_sem_reutilizacao_em_inteiros_grandes(self):
        with self.registro._lock:
            self.registro._revisao = 2**64  # Estado inicial de ensaio, sem API de reset.
        self.executar()
        self.assertEqual(2**64 + 5, self.revisao())

    def test_falha_revisao_entrada_nao_executa_corpo(self):
        token = self.registro.admitir()
        corpo = Mock()
        with patch.object(self.registro, '_avancar_revisao', side_effect=OSError()):
            with self.assertRaises(OSError):
                self.registro.executar(token, corpo)
        corpo.assert_not_called()
        self.assertFalse(self.evidencia()['confiavel'])
        self.assertFalse(self.infra.obter_preparacoes()['preparacoes'][0]['execucao_resolvida'])

    def test_erro_associacao_preservado_com_falhas_repetidas_de_revisao(self):
        token = self.registro.admitir()
        adicional = OSError('acompanhamento_simulado')
        def corpo():
            with patch.object(self.registro, '_avancar_revisao', side_effect=adicional):
                self.registro.vincular_recursos(token, object())
        with self.assertRaises(ValueError) as recebido:
            self.registro.executar(token, corpo)
        self.assertIs(adicional, recebido.exception.__cause__)
        self.assertIsNot(adicional, adicional.__cause__)
        self.assertTrue(self.evidencia()['preparacoes'][0]['erro_associacao'])
        self.assertFalse(self.evidencia()['confiavel'])


if __name__ == '__main__':
    unittest.main()

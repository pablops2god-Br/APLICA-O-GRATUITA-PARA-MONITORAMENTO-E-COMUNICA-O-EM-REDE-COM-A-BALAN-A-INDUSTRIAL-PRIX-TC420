# Testes de auditoria atividades cliente ac3b: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-B: reproduz lacunas sem instrumentar atividades ou forçar cobertura."""
import ast
from contextlib import contextmanager
import json
from pathlib import Path
import threading
import tkinter as tk
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from config.arquivos import ContextoArquivosConfiguracao
from interface.janela import JanelaTC420
from rede.lerdadosserver import LeitorDadosServidor
from test_recursos_cliente_integrados import SocketLeituraFalso
import test_composicao_operacional_cliente as composicao
import test_infraestrutura_cliente as montagem
from apoio_conexoes_cliente import conexoes_tcp_simuladas, conectores_tcp_controlados


RAIZ = Path(__file__).resolve().parents[1]
THREAD_REAL = threading.Thread


class TkSimulado:
    def __init__(self):
        self.pendentes = []
        self.destruido = False

    def after(self, prazo, callback, *args):
        if self.destruido:
            raise tk.TclError('root_simulada_destruida')
        self.pendentes.append((prazo, callback, args))
        return str(len(self.pendentes))

    def winfo_exists(self):
        return not self.destruido

    def bind(self, *args, **kwargs):
        pass

    def after_cancel(self, identidade):
        pass  # Conserva callbacks para provar a invalidacao mesmo se entregues.

    def destroy(self):
        self.destruido = True


# Grupo de 26 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AuditoriaAtividadesAC3B(unittest.TestCase):
    setUp = composicao.ComposicaoOperacionalCliente.setUp
    fabricar = composicao.ComposicaoOperacionalCliente.fabricar
    preparar = composicao.ComposicaoOperacionalCliente.preparar
    partir = composicao.ComposicaoOperacionalCliente.partir
    executar_descoberta = composicao.ComposicaoOperacionalCliente.executar_descoberta
    executar_sem_busca = composicao.ComposicaoOperacionalCliente.executar_sem_busca
    par_leitor = composicao.ComposicaoOperacionalCliente.par_leitor
    observar = composicao.ComposicaoOperacionalCliente.observar
    fechar_gates = composicao.ComposicaoOperacionalCliente.fechar_gates
    terminal = composicao.ComposicaoOperacionalCliente.terminal
    recurso_pendente = composicao.ComposicaoOperacionalCliente.recurso_pendente
    operacao_http = composicao.ComposicaoOperacionalCliente.operacao_http
    avaliar = composicao.ComposicaoOperacionalCliente.avaliar

    @contextmanager
    def permanente_bloqueada(self):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []
        def alvo():
            entrou.set()
            if not liberar.wait(3):
                erros.append('timeout_harness')
        self.leitor._manter_atualizado = alvo
        self.leitor.executando = False
        with patch('rede.lerdadosserver.threading', SimpleNamespace(Thread=THREAD_REAL)):
            self.leitor.iniciar()
        try:
            self.assertTrue(entrou.wait(3))
            yield self.leitor.thread
        finally:
            self.leitor.parar()
            liberar.set()
            self.leitor.thread.join(3)
            self.assertFalse(self.leitor.thread.is_alive())
            self.assertEqual([], erros)

    def janela(self, **atributos):
        janela = JanelaTC420.__new__(JanelaTC420)
        janela.executando = True
        janela.root = TkSimulado()
        janela.fonte_dados = Mock(side_effect=ValueError('fonte_simulada'))
        vars(janela).update(atributos)
        return janela

    def promover_real(self):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        fx.env['LeitorDadosServidor'] = lambda **kwargs: self.leitor
        fx.env['buscar_servidor'].return_value = None
        self.leitor.aguardar_configuracao = Mock(return_value=None)
        resultados = []
        fx.durante_monitor = lambda monitor: resultados.append(monitor.ao_promover('simulado', '', ''))
        with patch('builtins.print'):
            fx.iniciar_cliente(self.infra)
        self.assertIsNotNone(resultados[0])
        return resultados[0]

    def test_01_leitor_ativo_sem_registro_de_atividade(self):
        with self.permanente_bloqueada() as thread:
            self.assertTrue(thread.is_alive())
            resultado = self.avaliar()
            self.assertEqual([], resultado['retentativas'])
            self.assertEqual([], self.infra.obter_associacoes_retentativas())
            self.assertIs(thread, self.leitor.thread)

    def test_02_A_parar_nao_comprova_termino(self):
        cliente, arquivo, bruto = self.par_leitor()
        self.addCleanup(arquivo.close)
        self.leitor.cliente = cliente
        with self.permanente_bloqueada() as thread:
            self.leitor.parar()
            bruto.shutdown.assert_called_once()
            self.assertTrue(self.leitor._parada.is_set())
            self.assertFalse(self.leitor.executando)
            self.assertTrue(thread.is_alive())
            self.avaliar()

    def test_03_alvo_permanente_retornou_sem_publicacao_de_termino(self):
        self.leitor.ip_servidor = 'simulado'
        self.leitor.executando = False
        with patch('rede.lerdadosserver.threading.Thread', side_effect=self.fabricar):
            self.leitor.iniciar()
        self.leitor.parar()
        self.threads[0].target()  # corpo real retorna sem iniciar IO depois da parada.
        self.assertEqual([], self.avaliar()['retentativas'])
        self.threads[0].is_alive.assert_not_called()

    def test_04_reconexao_interna_mesma_geracao_sem_retry(self):
        self.leitor.ip_servidor = 'simulado'
        config, reg_a, sub_a, reg_b, sub_b = [SocketLeituraFalso() for _ in range(5)]
        config.arquivo.readline = Mock(return_value='{}')
        for reg in (reg_a, reg_b):
            reg.arquivo.readline = Mock(return_value=json.dumps({'nome': self.leitor.nome_computador, 'posicao': 1}))
        sub_a.arquivo.readline = Mock(return_value='')
        sub_b.arquivo.readline = Mock(side_effect=lambda: (self.leitor.parar(), '')[-1])
        def candidatura():
            self.leitor.ip_servidor = 'simulado'
            return False
        origem = self.leitor.recursos_cliente.geracao_id
        with patch.object(self.leitor, '_aguardar_candidatura', side_effect=candidatura), \
                conexoes_tcp_simuladas(self.leitor.recursos_cliente, [config, reg_a, reg_b]), \
                patch('rede.lerdadosserver.socket.socket', side_effect=[sub_a, sub_b]), patch('builtins.print'):
            self.leitor._manter_atualizado()
        recursos = self.avaliar()['recursos']
        self.assertEqual(10, len(recursos))
        self.assertEqual(10, len({r['recurso_id'] for r in recursos}))
        self.assertEqual({origem}, {r['geracao_id'] for r in recursos})
        self.assertEqual([], self.avaliar()['retentativas'])
        sub_a.sendall.assert_called_once_with(b'SUBSCRIBE\n')
        sub_b.sendall.assert_called_once_with(b'SUBSCRIBE\n')

    def test_05_recuperacao_real_identidade_preservada(self):
        self.terminal()
        item, = self.avaliar()['retentativas']
        associacao, = self.infra.obter_associacoes_retentativas()
        self.assertEqual(associacao['retentativa_id'], item['retentativa_id'])
        self.assertEqual(associacao['geracao_id'], item['geracao_id'])
        self.assertTrue(item['encerramento_confirmado'])

    def test_06_geracao_antiga_ativa_nao_desaparece(self):
        cliente, arquivo, _ = self.par_leitor()
        self.addCleanup(cliente.close)
        self.addCleanup(arquivo.close)
        with self.permanente_bloqueada():
            novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
            resultado = self.avaliar()
            self.assertNotEqual(novo.recursos_cliente.geracao_id, self.leitor.recursos_cliente.geracao_id)
            self.assertEqual({self.leitor.recursos_cliente.geracao_id}, {r['geracao_id'] for r in resultado['recursos']})
            self.assertEqual(2, len(resultado['recursos_pendentes']))

    def test_07_B_promocao_real_leitor_antigo_vivo(self):
        cliente, arquivo, _ = self.par_leitor()
        self.addCleanup(cliente.close)
        self.addCleanup(arquivo.close)
        origem = self.leitor.recursos_cliente.geracao_id
        with self.permanente_bloqueada() as thread:
            resultado = self.promover_real()
            janela = self.janela(contextos_promocao=[], contexto_promocao_atual=None)
            with patch('builtins.print'):
                janela.concluir_promocao(resultado)
            self.assertIs(resultado['fonte_dados'], janela.fonte_dados)
            self.assertTrue(thread.is_alive())
            self.assertEqual({origem}, {r['geracao_id'] for r in self.avaliar()['recursos']})

    def test_08_E_modo_divergente_na_promocao_real(self):
        cliente, arquivo, _ = self.par_leitor()
        self.addCleanup(cliente.close)
        self.addCleanup(arquivo.close)
        op = self.operacao_http()
        with self.permanente_bloqueada() as thread:
            self.promover_real()
            self.assertTrue(thread.is_alive())
            recursos = self.infra.registro_recursos.obter_retrato()['recursos']
            self.assertTrue(all(r['modo_atual'] == 'cliente' for r in recursos))
            self.assertTrue(all(o['modo_atual'] == 'cliente' for o in self.infra.registro_http.obter_retrato()['operacoes']))
            self.avaliar()

    def test_09_http_resolvido_nao_termina_thread_chamadora(self):
        op = self.operacao_http()
        concluiu, liberar = threading.Event(), threading.Event()
        erros = []
        def executar():
            try:
                self.infra.registro_http.executar(op, lambda: None)
                concluiu.set()
                if not liberar.wait(3):
                    raise TimeoutError('barreira_simulada')
            except BaseException as erro:
                erros.append(erro)
        thread = THREAD_REAL(target=executar)
        thread.start()
        try:
            self.assertTrue(concluiu.wait(3))
            self.assertTrue(thread.is_alive())
            self.assertTrue(self.avaliar()['http'][0]['execucao_resolvida'])
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_10_http_pendente_representado(self):
        self.operacao_http()
        self.assertFalse(self.avaliar()['http'][0]['execucao_resolvida'])

    def test_11_callback_pendente_sem_cobertura(self):
        janela = self.janela()
        with patch('builtins.print'):
            janela.atualizar_refresh_web()
        self.assertEqual(1, len(janela.root.pendentes))
        self.assertEqual(1000, janela.root.pendentes[0][0])
        self.avaliar()

    def test_12_callback_apos_destroy_reproduz_TclError(self):
        janela = self.janela()
        with patch('builtins.print'):
            janela.atualizar_refresh_web()
        _, callback, args = janela.root.pendentes.pop()
        janela.root.destroy()  # destruição sem quiescência/flag: risco legado.
        with patch('builtins.print'):
            callback(*args)
        self.avaliar()

    def test_13_recurso_retry_aberto_nao_confirma(self):
        self.recurso_pendente('socket_udp')
        self.assertFalse(self.avaliar()['retentativas'][0]['encerramento_confirmado'])

    def test_14_subscribe_independente_aberto(self):
        cliente, arquivo, _ = self.par_leitor()
        self.addCleanup(cliente.close)
        self.addCleanup(arquivo.close)
        self.terminal()
        resultado = self.avaliar()
        self.assertTrue(resultado['retentativas'][0]['encerramento_confirmado'])
        self.assertIn(cliente.recurso_id.numero, resultado['recursos_pendentes'])

    def test_15_retencao_AC1F1_preservada(self):
        contexto = ContextoArquivosConfiguracao(self.infra)
        arquivo = Mock(closed=False)
        contexto.executar(lambda: arquivo, lambda f: None)
        resultado = self.avaliar()
        self.assertTrue(resultado['arquivos'][0]['handle_retido'])
        self.assertEqual(1, len(resultado['retencoes_pendentes']))
        arquivo.closed = True
        self.infra.tentar_limpeza_arquivo(resultado['retencoes_pendentes'][0])

    def test_16_F_conhecidos_resolvidos_leitor_nao_acompanhado(self):
        op = self.operacao_http()
        self.infra.registro_http.executar(op, lambda: None)
        with self.permanente_bloqueada() as thread:
            self.terminal()
            resultado = self.avaliar()
            self.assertTrue(thread.is_alive())
            # AC3-D1 passou a considerar a thread permanente ainda ativa.
            self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])
            self.assertEqual('incompleta', resultado['cobertura_operacional'])

    def test_17_C_REGISTER_pode_alocar_apos_parar_sem_gate(self):
        self.leitor.ip_servidor = 'simulado'
        config, registro = SocketLeituraFalso(), SocketLeituraFalso()
        config.arquivo.readline = Mock(return_value='{}')
        registro.arquivo.readline = Mock(return_value=json.dumps({'nome': self.leitor.nome_computador, 'posicao': 1}))
        entrou, liberar = threading.Event(), threading.Event()
        erros, chamadas = [], []
        def conectar(dono, *args, **kwargs):
            if chamadas:
                entrou.set()
                if not liberar.wait(3):
                    raise TimeoutError('barreira_simulada')
            objeto = registro if chamadas else config
            chamadas.append(True)
            return dono.abrir_socket(lambda: objeto)
        def executar():
            try:
                self.leitor._manter_atualizado()
            except BaseException as erro:
                erros.append(erro)
        with conectores_tcp_controlados(self.leitor.recursos_cliente, conectar), patch('builtins.print'):
            thread = THREAD_REAL(target=executar)
            thread.start()
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual(1, len(self.leitor._admissao_register.obter_retrato()['operacoes']))
                anteriores = len(self.infra.registro_recursos.obter_retrato()['recursos'])
                self.leitor.parar()
                self.assertFalse(self.infra.registro_recursos.obter_retrato()['admissao_fechada'])
            finally:
                liberar.set()
                thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertGreater(len(self.avaliar()['recursos']), anteriores)
        registro.sendall.assert_called_once()

    def test_18_D_http_concluido_callback_ainda_pendente(self):
        op = self.operacao_http()
        janela = self.janela()
        self.infra.registro_http.executar(op, lambda: janela.root.after(0, Mock()))
        self.assertEqual(1, len(janela.root.pendentes))
        self.assertTrue(self.avaliar()['http'][0]['execucao_resolvida'])

    def test_19_avaliar_nao_modifica_registros_nem_observa_threads(self):
        self.executar_descoberta()
        contexto = ContextoArquivosConfiguracao(self.infra)
        def retratos():
            return (self.guarda.obter_retrato(), self.infra.registro_recursos.obter_retrato(),
                    self.infra.registro_http.obter_retrato(), self.infra.obter_associacoes_retentativas(),
                    contexto.obter_historico(), contexto.obter_pendencias())
        antes = retratos()
        with patch.object(type(self.infra), 'observar_termino_retentativas', side_effect=AssertionError('implicito')) as observar:
            self.avaliar()
        self.assertEqual(antes, retratos())
        observar.assert_not_called()
        self.threads[0].is_alive.assert_not_called()

    def test_20_iniciar_ignora_gate_de_atividades_ja_fechado(self):
        self.fechar_gates()
        self.leitor.executando = False
        with patch('rede.lerdadosserver.threading.Thread', side_effect=self.fabricar):
            self.leitor.iniciar()
        self.assertEqual(1, self.threads[0].starts)
        self.assertEqual([], self.avaliar()['retentativas'])
        self.leitor.parar()

    def test_21_callback_atualizar_peso_acessa_widget_destruido(self):
        janela = self.janela(label_peso=Mock())
        janela.root.after(0, janela.atualizar_peso, 'simulado')
        janela.root.destroy()
        janela.label_peso.config.side_effect = tk.TclError('widget_simulado_destruido')
        _, callback, args = janela.root.pendentes.pop()
        callback(*args)
        janela.label_peso.config.assert_not_called()

    def test_22_fechamento_normal_flag_bloqueia_refresh_mas_nao_cancela_fila(self):
        janela = self.janela(balanca=Mock())
        with patch('builtins.print'):
            janela.atualizar_refresh_web()
        janela.concluir_fechamento()
        self.assertFalse(janela.executando)
        self.assertEqual(1, len(janela.root.pendentes))
        _, callback, args = janela.root.pendentes.pop()
        callback(*args)  # a guarda deste callback específico evita novo acesso.

    def test_23_AST_criadores_threads_no_recorte(self):
        esperados = {
            'main.py': 2, 'rede/lerdadosserver.py': 2,
            'interface/conexao.py': 3, 'interface/janela.py': 1,
            'rede/supervisao_principal.py': 1,
        }
        for nome, quantidade in esperados.items():
            raiz = ast.parse((RAIZ / nome).read_text(encoding='utf-8'))
            criadores = [n for n in ast.walk(raiz) if isinstance(n, ast.Call)
                         and ast.unparse(n.func) in ('threading.Thread', 'Thread')]
            self.assertEqual(quantidade, len(criadores), nome)

    def test_24_AST_promocao_nao_publica_modos(self):
        for nome in ('main.py', 'interface/conexao.py', 'interface/janela.py', 'rede/lerdadosserver.py'):
            raiz = ast.parse((RAIZ / nome).read_text(encoding='utf-8'))
            self.assertFalse(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                                 and n.func.attr == 'promover' for n in ast.walk(raiz)), nome)

    def test_25_AST_login_approval_e_descoberta_sem_threads_proprias(self):
        for nome in ('tc420/web.py', 'rede/buscarservidor.py', 'rede/infraestrutura_cliente.py'):
            raiz = ast.parse((RAIZ / nome).read_text(encoding='utf-8'))
            self.assertFalse(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                                 and n.func.attr == 'Thread' for n in ast.walk(raiz)), nome)

    def test_26_AST_via_direta_UI_nao_chamada_pela_montagem(self):
        for nome in ('main.py', 'interface/conexao.py', 'interface/janela.py'):
            raiz = ast.parse((RAIZ / nome).read_text(encoding='utf-8'))
            self.assertFalse(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                                 and n.func.attr == 'iniciar_leitura' for n in ast.walk(raiz)))

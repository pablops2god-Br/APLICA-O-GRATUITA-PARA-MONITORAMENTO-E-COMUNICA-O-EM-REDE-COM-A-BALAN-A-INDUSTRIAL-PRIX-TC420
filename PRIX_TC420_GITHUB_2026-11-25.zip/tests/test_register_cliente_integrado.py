# Testes de register cliente integrado: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""REGISTER real: contrato/validação existentes, transporte falso e sem rede."""
import ast
import json
from pathlib import Path
from types import SimpleNamespace
import threading
import unittest
from unittest.mock import Mock, patch

from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
from test_recursos_cliente_integrados import SocketLeituraFalso
from apoio_conexoes_cliente import conexoes_tcp_simuladas


# Grupo de 22 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class RegisterClienteIntegrado(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.dono = RecursosLeitorCliente(self.infra)
        self.registro = self.infra.registro_recursos
        self.leitor = SimpleNamespace(nome_computador="cliente-simulado", posicao_sucessao=None)
        caminho = Path(__file__).resolve().parents[1] / "rede" / "lerdadosserver.py"
        arvore = ast.parse(caminho.read_text(encoding="utf-8"))
        metodo = next(n for n in ast.walk(arvore) if isinstance(n, ast.FunctionDef) and n.name == "receber_registro")
        ambiente = dict(self=self.leitor, json=json)
        exec(compile(ast.Module(body=[metodo], type_ignores=[]), str(caminho), "exec"), ambiente)
        self.receber = ambiente["receber_registro"]

    def objeto(self):
        objeto = SocketLeituraFalso()
        objeto.arquivo.readline = Mock(return_value='{"nome":"cliente-simulado","posicao":1}')
        return objeto

    def registrar(self, objeto=None, dono=None):
        objeto = self.objeto() if objeto is None else objeto
        return (dono or self.dono).registrar_cliente(lambda: objeto, self.leitor.nome_computador, self.receber)

    def recursos(self):
        return self.registro.obter_retrato()["recursos"]

    def pendente(self):
        self.assertFalse(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_01_register_normal(self):
        objeto = self.objeto()
        self.registrar(objeto)
        self.assertEqual(1, self.leitor.posicao_sucessao)
        objeto.sendall.assert_called_once_with(b"REGISTER|cliente-simulado\n")
        objeto.makefile.assert_called_once_with("r", encoding="utf-8")
        self.assertEqual(2, len(self.recursos()))

    def test_02_ausencia_antes_da_fabrica(self):
        fabrica = Mock()
        with patch.object(self.registro, "criar", side_effect=OSError()):
            with self.assertRaises(OSError):
                self.dono.registrar_cliente(fabrica, "cliente-simulado", self.receber)
        fabrica.assert_not_called()
        self.registro.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_03_falha_apos_alocacao(self):
        objeto = self.objeto()
        criar = self.registro.criar

        def falhar(token, fabrica):
            return criar(token, fabrica, preparar=Mock(side_effect=ValueError()))

        with patch.object(self.registro, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.registrar(objeto)
        self.assertTrue(objeto.fechado)
        self.assertTrue(self.recursos()[0]["erros_criacao"])

    def test_04_falha_de_conexao_opaca(self):
        erro = ConnectionRefusedError()
        with self.assertRaises(ConnectionRefusedError) as capturado:
            self.dono.registrar_cliente(Mock(side_effect=erro), "cliente-simulado", self.receber)
        self.assertIs(erro, capturado.exception)
        self.assertIsNone(self.leitor.posicao_sucessao)
        self.assertEqual("desconhecido", self.recursos()[0]["estado"])

    def test_05_envio_e_close_preservam_original(self):
        objeto = self.objeto()
        erro = OSError("envio_simulado")
        objeto.sendall.side_effect = erro
        objeto.erro_close = ValueError()
        with self.assertRaises(OSError) as capturado:
            self.registrar(objeto)
        self.assertIs(erro, capturado.exception)
        self.assertTrue(self.recursos()[0]["erros_atendimento"])
        self.assertTrue(self.recursos()[0]["erros_limpeza"])

    def test_06_respostas_invalidas_preservam_validacao(self):
        respostas = [{"nome": "outro", "posicao": 1}]
        respostas += [{"nome": "cliente-simulado", "posicao": p} for p in (True, 0, -1, "1", 1.0)]
        for resposta in respostas:
            with self.subTest(resposta=resposta):
                objeto = self.objeto()
                objeto.arquivo.readline.return_value = json.dumps(resposta)
                with self.assertRaisesRegex(ValueError, "Resposta REGISTER inválida"):
                    self.registrar(objeto)
                self.assertIsNone(self.leitor.posicao_sucessao)
                self.assertTrue(objeto.fechado)
                self.assertTrue(objeto.arquivo.closed)

    def test_07_timeout_mantem_excecao(self):
        erro = TimeoutError()
        with self.assertRaises(TimeoutError) as capturado:
            self.dono.registrar_cliente(Mock(side_effect=erro), "cliente-simulado", self.receber)
        self.assertIs(erro, capturado.exception)

    def test_08_close_normal_arquivo_antes_socket(self):
        objeto = self.objeto()
        ordem = []
        arquivo_close, socket_close = objeto.arquivo.close, objeto.close
        objeto.arquivo.close = lambda: (ordem.append("arquivo"), arquivo_close())[-1]
        objeto.close = lambda: (ordem.append("socket"), socket_close())[-1]
        self.registrar(objeto)
        self.assertEqual(["arquivo", "socket"], ordem)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_09_close_falho_nao_confirma(self):
        objeto = self.objeto()
        objeto.arquivo.erro_close = OSError()
        with self.assertRaises(OSError):
            self.registrar(objeto)
        self.registro.fechar_admissao()
        self.pendente()

    def test_10_publicacao_incerta(self):
        objeto = self.objeto()

        def falhar(token, alocar):
            alocar()
            raise ValueError()

        with patch.object(self.registro, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.registrar(objeto)
        self.assertTrue(objeto.fechado)
        self.assertTrue(self.dono.obter_publicacoes_pendentes())
        self.registro.fechar_admissao()
        self.pendente()

    def test_11_register_config_distintos(self):
        self.registrar()
        config = self.objeto()
        config.arquivo.readline.return_value = '{}'
        self.dono.ler_configuracao(lambda: config, json.loads)
        self.assertEqual(4, len({r["recurso_id"] for r in self.recursos()}))

    def test_12_register_subscribe_distintos(self):
        sub = self.dono.abrir_socket(self.objeto)
        arquivo = sub.makefile("r", encoding="utf-8")
        self.registrar()
        self.assertFalse(self.recursos()[0]["encerramento_confirmado"])
        self.assertEqual(4, len({r["recurso_id"] for r in self.recursos()}))
        sub.close()
        arquivo.close()

    def test_13_geracao_antiga_preservada(self):
        objeto = self.objeto()
        objeto.erro_close = OSError()
        with self.assertRaises(OSError):
            self.registrar(objeto)
        nova = RecursosLeitorCliente(self.infra)
        self.registrar(dono=nova)
        self.registro.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato(geracao_id=nova.geracao_id)["encerramento_confirmado"])
        self.pendente()

    def test_14_repeticao_nao_apaga_erro(self):
        objeto = self.objeto()
        objeto.erro_close = OSError()
        abrir = self.dono.abrir_socket
        proxies = []

        def capturar(fabrica):
            proxy = abrir(fabrica)
            proxies.append(proxy)
            return proxy

        with patch.object(self.dono, "abrir_socket", side_effect=capturar):
            with self.assertRaises(OSError):
                self.registrar(objeto)
        objeto.erro_close = None
        proxies[0].close()
        proxies[0].close()
        self.assertEqual(2, objeto.close_chamadas)
        self.assertTrue(self.recursos()[0]["erros_limpeza"])

    def test_15_sem_arquivo_artificial_antes_makefile(self):
        objeto = self.objeto()
        objeto.sendall.side_effect = OSError()
        with self.assertRaises(OSError):
            self.registrar(objeto)
        objeto.makefile.assert_not_called()
        self.assertEqual(["socket_tcp"], [r["tipo"] for r in self.recursos()])

    def test_16_cobertura_incompleta(self):
        self.registrar()
        self.registro.fechar_admissao()
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])

    def executar_retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []

        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("harness")

        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)

        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_critico_A_criacao_tardia_apos_gate(self):
        def executar(suspender):
            def fabrica():
                suspender()
                return self.objeto()
            with self.assertRaises(RuntimeError):
                self.dono.registrar_cliente(fabrica, "cliente-simulado", self.receber)

        self.executar_retido(executar, lambda: (self.registro.fechar_admissao(), self.pendente()))
        self.assertEqual(self.dono.geracao_id, self.recursos()[0]["geracao_id"])
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])

    def test_critico_B_tres_protocolos_concorrentes(self):
        barreira = threading.Barrier(4)
        erros = []

        def executar(protocolo):
            try:
                barreira.wait(3)
                if protocolo == "REGISTER":
                    self.registrar()
                elif protocolo == "CONFIG":
                    self.dono.ler_configuracao(self.objeto, json.loads)
                else:
                    socket = self.dono.abrir_socket(self.objeto)
                    arquivo = socket.makefile("r", encoding="utf-8")
                    socket.close()
                    arquivo.close()
            except BaseException as erro:
                erros.append(erro)

        threads = [threading.Thread(target=executar, args=(p,)) for p in ("REGISTER", "CONFIG", "SUBSCRIBE")]
        for thread in threads:
            thread.start()
        barreira.wait(3)
        for thread in threads:
            thread.join(3)
            self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(6, len({r["recurso_id"] for r in self.recursos()}))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_critico_C_close_falha_tardiamente(self):
        objeto = self.objeto()

        def executar(suspender):
            def close():
                suspender()
                raise OSError()
            objeto.close = close
            with self.assertRaises(OSError):
                self.registrar(objeto)

        self.executar_retido(executar, lambda: (self.registro.fechar_admissao(), self.pendente()))
        self.assertTrue(self.recursos()[0]["erros_limpeza"])
        self.pendente()

    def test_critico_D_promocao_enquanto_register_antigo_pendente(self):
        objeto = self.objeto()

        def executar(suspender):
            objeto.arquivo.readline.side_effect = lambda: (suspender(), '{"nome":"cliente-simulado","posicao":1}')[-1]
            self.registrar(objeto)

        def promover():
            self.registro.promover(self.dono.geracao_id)
            nova = RecursosLeitorCliente(self.infra)
            config = self.objeto()
            nova.ler_configuracao(lambda: config, json.loads)
            self.registro.fechar_admissao()
            self.assertTrue(self.registro.obter_retrato(geracao_id=nova.geracao_id)["encerramento_confirmado"])
            self.pendente()

        self.executar_retido(executar, promover)
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_json_e_duplo_close_falhos_preservam_original(self):
        objeto = self.objeto()
        objeto.arquivo.readline.return_value = '{invalido'
        objeto.arquivo.erro_close = OSError()
        objeto.erro_close = OSError()
        with self.assertRaises(json.JSONDecodeError):
            self.registrar(objeto)
        self.assertTrue(all(r["erros_limpeza"] for r in self.recursos()))

    def test_timeout_no_loop_preserva_timeout_e_candidatura(self):
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente-simulado"):
            leitor = LeitorDadosServidor("principal-simulado", infraestrutura_cliente=self.infra)
        leitor.executando = True
        config = self.objeto()
        config.arquivo.readline.return_value = '{}'

        def parar_candidatura():
            leitor.parar()
            return False

        leitor._aguardar_candidatura = Mock(side_effect=parar_candidatura)
        with conexoes_tcp_simuladas(leitor.recursos_cliente, [config, TimeoutError()]) as criar, \
                patch("rede.lerdadosserver.socket.socket") as subscribe:
            leitor._manter_atualizado()
        self.assertEqual(2, criar.call_count)
        self.assertTrue(all(c.kwargs == {"timeout": 5} for c in criar.call_args_list))
        subscribe.assert_not_called()
        leitor._aguardar_candidatura.assert_called_once_with()
        self.assertIsNone(leitor.posicao_sucessao)


if __name__ == "__main__":
    unittest.main()

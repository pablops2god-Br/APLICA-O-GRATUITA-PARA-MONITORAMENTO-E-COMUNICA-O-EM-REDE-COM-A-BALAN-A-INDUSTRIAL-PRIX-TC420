# Testes de composicao cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Composição de contratos em memória; nenhum módulo operacional importado."""
from dataclasses import replace
import threading
import unittest
from unittest.mock import patch

from prototipos.composicao_cliente import (
    CoberturaCliente, ContextoClienteExperimental, VinculoRecurso, avaliar_cliente,
)
from prototipos.guarda_retentativas_cliente import GuardaRetentativasCliente
from prototipos.recursos_cliente import RegistroRecursosCliente
from test_guarda_retentativas_cliente import ThreadFalsa
from test_recursos_cliente import ArquivoFalso, SocketFalso


# Grupo de 32 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class ComposicaoCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.retentativas = GuardaRetentativasCliente()
        self.recursos = RegistroRecursosCliente()
        self.contexto = ContextoClienteExperimental.vincular(self.retentativas, self.recursos)
        self.geracoes, self.pares, self.vinculos = [], [], []
        self.threads = {}
        self.geracao = self.nova_geracao()

    def nova_geracao(self):
        geracao = self.retentativas.nova_geracao_cliente()
        self.geracoes.append(geracao.numero)
        return geracao

    def admitir(self, geracao=None):
        geracao = self.geracao if geracao is None else geracao
        token = self.retentativas.reservar_retentativa(geracao)
        self.pares.append((geracao.numero, token.numero))
        return token

    def partir(self, token, *, ambiguo=False):
        def fabrica(alvo):
            falsa = ThreadFalsa(alvo, erro_start=ambiguo)
            self.threads[token] = falsa
            return falsa
        if ambiguo:
            with self.assertRaises(RuntimeError):
                self.retentativas.partir(token, fabrica, lambda: None)
        else:
            self.retentativas.partir(token, fabrica, lambda: None)

    def terminar(self, token):
        self.threads[token].executar()
        self.assertTrue(self.retentativas.observar_termino_thread(token))

    def reservar_recurso(self, retentativa=None, *, geracao=None, tipo="socket_tcp", pai=None,
                         atividade=1000):
        geracao_id = self.geracao.numero if geracao is None else geracao.numero
        retry_id = retentativa.numero if retentativa is not None else None
        atividade_id = retry_id if retry_id is not None else atividade
        token = self.recursos.reservar(tipo, geracao_id, atividade_id, associado_a=pai)
        self.vinculos.append(VinculoRecurso(token.numero, geracao_id, atividade_id, retry_id))
        return token

    def recurso(self, retentativa=None, **kwargs):
        token = self.reservar_recurso(retentativa, **kwargs)
        objeto = ArquivoFalso() if kwargs.get("tipo", "socket_tcp").startswith("arquivo_") else SocketFalso()
        self.recursos.criar(token, lambda: objeto)
        return token, objeto

    def par(self, retentativa, geracao=None):
        socket, obj_socket = self.recurso(retentativa, geracao=geracao)
        arquivo, obj_arquivo = self.recurso(retentativa, geracao=geracao, tipo="arquivo_socket", pai=socket)
        return socket, arquivo, obj_socket, obj_arquivo

    def fechar_gates(self):
        self.retentativas.fechar_admissao()
        self.recursos.fechar_admissao()

    def cobertura(self, completa=False):
        # Declaração do ensaio, não inferida automaticamente dos retratos.
        return CoberturaCliente(self.contexto, tuple(self.geracoes), tuple(self.pares),
                               tuple(self.vinculos), completa)

    def avaliar(self, *, completa=True):
        return avaliar_cliente(self.contexto, self.cobertura(completa))

    def pendente(self, **kwargs):
        resultado = self.avaliar(**kwargs)
        self.assertFalse(resultado["encerramento_confirmado"])
        return resultado

    def encerrada(self):
        retry = self.admitir()
        self.partir(retry)
        self.terminar(retry)
        return retry

    def test_01_execucao_e_recursos_encerrados_com_cobertura(self):
        retry = self.admitir()
        self.partir(retry)
        socket, arquivo, _, _ = self.par(retry)
        self.terminar(retry)
        self.recursos.fechar(socket)
        self.recursos.fechar(arquivo)
        self.fechar_gates()
        resultado = self.avaliar()
        self.assertTrue(resultado["consistente"])
        self.assertTrue(resultado["cobertura_completa"])
        self.assertTrue(resultado["encerramento_confirmado"])
        self.assertTrue(resultado["retentativas"][0]["encerramento_confirmado"])
        self.assertEqual([socket.numero, arquivo.numero], resultado["retentativas"][0]["recursos"])

    def test_02_thread_ativa_recursos_fechados(self):
        retry = self.admitir()
        self.partir(retry)
        socket, _ = self.recurso(retry)
        self.recursos.fechar(socket)
        self.fechar_gates()
        self.pendente()

    def test_03_thread_encerrada_socket_ativo(self):
        retry = self.encerrada()
        self.recurso(retry)
        self.fechar_gates()
        self.pendente()

    def test_04_thread_encerrada_arquivo_ativo(self):
        retry = self.encerrada()
        self.recurso(retry, tipo="arquivo_comum")
        self.fechar_gates()
        self.pendente()

    def test_05_socket_fechado_makefile_aberto(self):
        retry = self.encerrada()
        socket, _, _, _ = self.par(retry)
        self.recursos.fechar(socket)
        self.fechar_gates()
        self.pendente()

    def test_06_reserva_recurso_pendente(self):
        retry = self.encerrada()
        self.reservar_recurso(retry)
        self.fechar_gates()
        self.pendente()

    def test_07_reserva_retentativa_pendente(self):
        self.admitir()
        self.fechar_gates()
        self.pendente()

    def test_08_ausencia_comprovada_antes_partida(self):
        retry = self.admitir()
        self.retentativas.comprovar_nao_execucao(retry, ausencia_comprovada=True)
        self.fechar_gates()
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_09_partida_ambigua(self):
        retry = self.admitir()
        self.partir(retry, ambiguo=True)
        self.fechar_gates()
        self.pendente()

    def test_10_erro_close(self):
        retry = self.encerrada()
        socket, objeto = self.recurso(retry)
        objeto.erro_close = OSError()
        with self.assertRaises(OSError):
            self.recursos.fechar(socket)
        self.fechar_gates()
        self.pendente()

    def test_11_recurso_sem_retentativa_nao_desaparece(self):
        socket, _ = self.recurso()
        self.fechar_gates()
        resultado = self.pendente()
        self.assertEqual([socket.numero], resultado["recursos_sem_retentativa"])
        self.recursos.fechar(socket)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_12_recurso_geracao_antiga(self):
        retry = self.encerrada()
        socket, _ = self.recurso(retry)
        self.retentativas.promover(self.geracao)
        self.recursos.promover(self.geracao.numero)
        self.nova_geracao()
        self.fechar_gates()
        self.pendente()
        self.recursos.fechar(socket)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_13_duas_geracoes_so_com_cobertura(self):
        self.encerrada()
        geracao_b = self.nova_geracao()
        retry_b = self.admitir(geracao_b)
        self.partir(retry_b)
        self.terminar(retry_b)
        self.fechar_gates()
        self.pendente(completa=False)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_14_gate_retentativas_aberto(self):
        self.encerrada()
        self.recursos.fechar_admissao()
        self.pendente()

    def test_15_gate_recursos_aberto(self):
        self.encerrada()
        self.retentativas.fechar_admissao()
        self.pendente()

    def test_16_vazio_fechado_coberto(self):
        self.fechar_gates()
        self.pendente(completa=False)
        resultado = self.avaliar()
        self.assertTrue(resultado["encerramento_confirmado"])
        self.assertEqual([], resultado["retentativas"])
        self.assertEqual([], resultado["recursos_sem_retentativa"])

    def test_17_consulta_inconsistente(self):
        self.encerrada()
        self.fechar_gates()
        retrato = self.recursos.obter_retrato()
        alterado = dict(retrato, admissao_fechada=False, encerramento_confirmado=False)
        with patch.object(self.recursos, "obter_retrato", side_effect=[retrato, alterado]):
            resultado = self.pendente()
        self.assertFalse(resultado["consistente"])
        self.assertIn("consulta_inconsistente", resultado["pendencias"])

    def test_18_excecao_avaliacao_conservadora(self):
        self.fechar_gates()
        with patch.object(self.recursos, "obter_retrato", side_effect=OSError("nao_divulgar")):
            resultado = self.pendente()
        self.assertFalse(resultado["consistente"])
        self.assertEqual(["falha_consulta"], resultado["pendencias"])
        self.assertNotIn("nao_divulgar", str(resultado))

    def executar_retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []

        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("harness")

        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)

        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_critico_A_criacao_reservada_durante_avaliacao(self):
        retry = self.admitir()
        self.partir(retry)
        token = self.reservar_recurso(retry)

        def criar(suspender):
            def alocar():
                suspender()
                return SocketFalso()
            self.recursos.criar(token, alocar)

        def avaliar():
            self.terminar(retry)
            self.fechar_gates()
            self.pendente()

        self.executar_retido(criar, avaliar)
        self.pendente()
        self.recursos.fechar(token)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_critico_B_fechamento_entre_releituras(self):
        retry = self.encerrada()
        socket, _ = self.recurso(retry)
        self.fechar_gates()
        segunda_leitura, fechado = threading.Event(), threading.Event()
        erros, chamadas = [], []
        ler = self.retentativas.obter_retrato

        def leitura():
            chamadas.append(True)
            if len(chamadas) == 2:
                segunda_leitura.set()
                if not fechado.wait(3):
                    raise TimeoutError("harness")
            return ler()

        def limpar():
            try:
                if not segunda_leitura.wait(3):
                    raise TimeoutError("harness")
                self.recursos.fechar(socket)
            except BaseException as erro:
                erros.append(erro)
            finally:
                fechado.set()

        thread = threading.Thread(target=limpar)
        thread.start()
        try:
            with patch.object(self.retentativas, "obter_retrato", side_effect=leitura), \
                    patch.object(self.recursos, "obter_retrato", wraps=self.recursos.obter_retrato) as leituras:
                resultado = self.pendente()
                self.assertEqual(2, leituras.call_count)
                self.assertEqual(2, len(chamadas))
        finally:
            segunda_leitura.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertFalse(resultado["consistente"])
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_critico_C_makefile_geracao_antiga(self):
        retry_a = self.encerrada()
        socket, arquivo, _, _ = self.par(retry_a)
        self.retentativas.promover(self.geracao)
        self.recursos.promover(self.geracao.numero)
        geracao_b = self.nova_geracao()
        retry_b = self.admitir(geracao_b)
        self.partir(retry_b)
        self.terminar(retry_b)
        recurso_b, _ = self.recurso(retry_b, geracao=geracao_b)
        self.recursos.fechar(recurso_b)
        self.recursos.fechar(socket)
        self.fechar_gates()
        resultado = self.pendente()
        self.assertEqual(2, len(resultado["retentativas"]))
        self.assertFalse(resultado["retentativas"][0]["encerramento_confirmado"])
        self.assertTrue(resultado["retentativas"][1]["encerramento_confirmado"])
        self.recursos.fechar(arquivo)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_critico_D_publicacao_tardia_erro_limpeza(self):
        retry = self.encerrada()
        socket, objeto = self.recurso(retry)
        self.fechar_gates()

        def limpar(suspender):
            def close():
                suspender()
                raise OSError()
            objeto.close = close
            with self.assertRaises(OSError):
                self.recursos.fechar(socket)

        self.executar_retido(limpar, self.pendente)
        resultado = self.pendente()
        self.assertTrue(resultado["consistente"])
        self.assertTrue(self.recursos.obter_retrato()["recursos"][0]["erros_limpeza"])

    def test_critico_E_cobertura_incompleta_registros_aparentemente_vazios(self):
        self.encerrada()
        self.fechar_gates()
        self.assertEqual([], self.recursos.obter_retrato()["recursos"])
        resultado = self.pendente(completa=False)
        self.assertFalse(resultado["cobertura_completa"])
        self.assertIn("falha_cobertura", resultado["pendencias"])
        self.assertFalse(avaliar_cliente(self.contexto)["encerramento_confirmado"])

    def test_avaliador_somente_leitura(self):
        retry = self.encerrada()
        socket, objeto = self.recurso(retry)
        self.recursos.fechar(socket)
        self.fechar_gates()
        antes_t, antes_r = self.retentativas.obter_retrato(), self.recursos.obter_retrato()
        chamadas_close = objeto.close_chamadas
        for _ in range(3):
            self.assertTrue(self.avaliar()["encerramento_confirmado"])
        self.assertEqual(antes_t, self.retentativas.obter_retrato())
        self.assertEqual(antes_r, self.recursos.obter_retrato())
        self.assertEqual(chamadas_close, objeto.close_chamadas)

    def test_recurso_omitido_do_manifesto_impede_positivo(self):
        retry = self.encerrada()
        socket, _ = self.recurso(retry)
        self.recursos.fechar(socket)
        self.fechar_gates()
        cobertura = replace(self.cobertura(True), vinculos=())
        self.assertFalse(avaliar_cliente(self.contexto, cobertura)["encerramento_confirmado"])

    def test_manifesto_de_outra_aplicacao_recusado(self):
        self.fechar_gates()
        outra = ContextoClienteExperimental.vincular(self.retentativas, self.recursos)
        self.assertNotEqual(outra.aplicacao_id, self.contexto.aplicacao_id)
        cobertura = replace(self.cobertura(True), contexto=outra)
        self.assertFalse(avaliar_cliente(self.contexto, cobertura)["encerramento_confirmado"])

    def test_atividade_sem_retry_com_numero_colidente_continua_independente(self):
        retry = self.encerrada()
        socket, _ = self.recurso(atividade=retry.numero)
        self.fechar_gates()
        resultado = self.pendente()
        self.assertEqual([], resultado["retentativas"][0]["recursos"])
        self.assertEqual([socket.numero], resultado["recursos_sem_retentativa"])

    def test_secundaria_da_guarda_nao_resolvida_por_consulta(self):
        retry = self.admitir()
        secundaria = self.retentativas.reservar_secundaria(retry, "socket")
        socket, _ = self.recurso(retry)
        self.partir(retry)
        self.terminar(retry)
        self.recursos.fechar(socket)
        self.fechar_gates()
        self.pendente()
        self.assertFalse(self.retentativas.obter_retrato()["secundarias"][0]["resolvida"])
        self.retentativas.resolver_secundaria(secundaria, responsabilidades_resolvidas=True)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_snapshot_filtrado_nao_equivale_global(self):
        self.fechar_gates()
        ler = self.recursos.obter_retrato
        with patch.object(self.recursos, "obter_retrato", side_effect=lambda: ler(geracao_id=99)):
            resultado = self.pendente()
        self.assertIn("falha_contratos", resultado["pendencias"])

    def test_associacao_socket_e_arquivo_nao_pode_trocar_responsavel(self):
        retry = self.encerrada()
        socket, arquivo, _, _ = self.par(retry)
        self.recursos.fechar(socket)
        self.recursos.fechar(arquivo)
        self.fechar_gates()
        vinculos = tuple(replace(v, retentativa_id=None) if v.recurso_id == arquivo.numero else v
                         for v in self.vinculos)
        cobertura = replace(self.cobertura(True), vinculos=vinculos)
        self.assertFalse(avaliar_cliente(self.contexto, cobertura)["encerramento_confirmado"])

    def test_declaracao_thread_encerrada_sem_prova_recusada(self):
        self.encerrada()
        self.fechar_gates()
        ler = self.retentativas.obter_retrato

        def sem_prova():
            retrato = ler()
            retrato["retentativas"][0]["thread_terminada"] = False
            return retrato

        with patch.object(self.retentativas, "obter_retrato", side_effect=sem_prova):
            resultado = self.pendente()
        self.assertIn("falha_contratos", resultado["pendencias"])

    def test_prova_socket_nao_substitui_closed_do_arquivo(self):
        retry = self.encerrada()
        arquivo, _ = self.recurso(retry, tipo="arquivo_comum")
        self.recursos.fechar(arquivo)
        self.fechar_gates()
        ler = self.recursos.obter_retrato

        def prova_errada():
            retrato = ler()
            retrato["recursos"][0]["prova_fechamento"] = "close_retornou"
            return retrato

        with patch.object(self.recursos, "obter_retrato", side_effect=prova_errada):
            resultado = self.pendente()
        self.assertIn("falha_contratos", resultado["pendencias"])


if __name__ == "__main__":
    unittest.main()

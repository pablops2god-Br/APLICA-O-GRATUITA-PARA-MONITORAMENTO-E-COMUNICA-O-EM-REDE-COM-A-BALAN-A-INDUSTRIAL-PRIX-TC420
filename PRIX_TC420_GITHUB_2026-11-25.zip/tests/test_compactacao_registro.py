"""Contratos da representação compacta; sem rede ou equipamento real."""
from dataclasses import replace
import threading
import unittest
from unittest.mock import Mock, patch

from rede import servidor as s
from test_guarda_sockets_integrada import SocketFalso


class CompactacaoRegistro(unittest.TestCase):
    def setUp(self):
        self.r = s.RegistroTrabalhadores()
        self.c = s.ControleCicloServidor()
        self.c.tentar_iniciar(self.r)
        self.t = self.resolver()

    def resolver(self):
        t = self.r.reservar_criacao_socket()
        self.assertTrue(self.r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True))
        return t

    def cliente(self):
        t = self.r.reservar_criacao_socket()
        sock = SocketFalso()
        self.r.anexar_socket(t, sock)
        self.r.publicar_socket(t)
        return t, sock

    def test_timeout_preserva_token_e_diagnostico(self):
        e = self.r._reservas_socket[self.t.criacao_id]
        self.assertIsInstance(e, s._CriacaoSocketResolvida)
        self.assertIs(e.reserva, self.t)
        self.assertFalse(hasattr(e, '__dict__'))
        self.assertEqual(self.r.obter_situacao()['criacoes_socket'], ({
            'criacao_id': 1, 'ciclo_id': 1, 'estado': 'sem_recurso',
            'em_uso': False, 'erro': None, 'limpeza_handler_pendente': False,
            'resultado_limpeza_handler_publicado': False},))

    def test_tokens_invalidos_fabricados_e_outro_dono(self):
        outro = s.RegistroTrabalhadores().reservar_criacao_socket()
        for t in (None, object(), replace(self.t), replace(self.t, ciclo_id=2), outro):
            with self.subTest(token=type(t)):
                self.assertFalse(self.r.fechar_socket(t))
                self.assertFalse(self.r.publicar_limpeza_handler(t))

    def test_repeticao_e_publicacao_tardia_sem_handler(self):
        for _ in range(3):
            self.assertTrue(self.r.fechar_socket(self.t))
            self.assertFalse(self.r.publicar_limpeza_handler(self.t, OSError()))
            self.assertFalse(self.r.resolver_falha_criacao_socket(
                self.t, sem_alocacao_comprovada=True))
            self.assertFalse(self.r.iniciar_limpeza_handler(self.t))
            self.assertFalse(self.r.encerrar_uso_socket(self.t))
        with self.assertRaises(ValueError):
            self.r.anexar_socket(self.t, SocketFalso())
        with self.assertRaises(ValueError):
            self.r.publicar_socket(self.t)
        self.assertFalse(self.r.erros_limpeza)

    def test_ordem_conteudo_equivalentes_sem_compactacao(self):
        def executar(compactar):
            with patch.object(s, '_CriacaoSocketResolvida', compactar):
                r = s.RegistroTrabalhadores()
                for _ in range(20):
                    t = r.reservar_criacao_socket()
                    r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True)
                r.bloquear_criacao()
                return r.obter_situacao(), r.encerramento_confirmado()
        self.assertEqual(executar(s._CriacaoSocketResolvida),
                         executar(lambda **kw: s._CriacaoSocket(estado='sem_recurso', em_uso=False, **kw)))

    def test_incerta_nao_compacta_nem_confirma(self):
        t = self.r.reservar_criacao_socket()
        self.r.resolver_falha_criacao_socket(t)
        self.r.bloquear_criacao()
        self.assertIsInstance(self.r._reservas_socket[t.criacao_id], s._CriacaoSocket)
        self.assertFalse(self.r.encerramento_confirmado())

    def test_erro_anterior_nao_desaparece_ao_resolver(self):
        t = self.r.reservar_criacao_socket()
        self.r.resolver_falha_criacao_socket(t)
        self.r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True)
        e = self.r._reservas_socket[t.criacao_id]
        self.assertIsInstance(e, s._CriacaoSocket)
        self.assertEqual(e.erro, 'falha_criacao_incerta')

    def test_close_bloqueado_concorrente_fora_lock(self):
        t, sock = self.cliente()
        self.r.encerrar_uso_socket(t)
        entrou, liberar = threading.Event(), threading.Event()
        original = sock.close
        def fechar():
            self.assertTrue(self.r.lock.acquire(blocking=False))
            self.r.lock.release()
            entrou.set()
            if not liberar.wait(5):
                raise RuntimeError('prazo do teste')
            original()
        sock.close = fechar
        resultados = []
        worker = threading.Thread(target=lambda: resultados.append(self.r.fechar_socket(t)))
        worker.start()
        try:
            self.assertTrue(entrou.wait(5))
            self.assertEqual(self.r._reservas_socket[t.criacao_id].estado, 'fechando')
            self.assertFalse(self.r.fechar_socket(t))
            self.r.bloquear_criacao()
            self.assertFalse(self.r.encerramento_confirmado())
            self.assertTrue(self.c.finalizar(self.r))
            self.assertFalse(self.c._obter_situacao_historica(1)['encerramento_confirmado'])
        finally:
            liberar.set()
            worker.join(5)
        self.assertFalse(worker.is_alive())
        self.assertEqual(resultados, [True])
        self.assertEqual(sock.fechamentos, 1)
        self.assertTrue(self.c._obter_situacao_historica(1)['encerramento_confirmado'])

    def test_handler_tardio_e_repetido(self):
        t, sock = self.cliente()
        self.r.iniciar_limpeza_handler(t)
        self.r.encerrar_uso_socket(t)
        self.r.bloquear_criacao()
        self.c.finalizar(self.r)
        self.assertFalse(self.r.fechar_socket(t))
        self.assertFalse(self.c._compactar_ciclo(1))
        self.assertTrue(self.r.publicar_limpeza_handler(t))
        self.assertTrue(self.r.publicar_limpeza_handler(t))
        self.assertTrue(self.r.fechar_socket(t))
        self.assertTrue(self.r.encerramento_confirmado())

    def test_erro_handler_tardio_impede_confirmacao(self):
        t, sock = self.cliente()
        self.r.iniciar_limpeza_handler(t)
        self.r.encerrar_uso_socket(t)
        self.r.bloquear_criacao()
        self.c.finalizar(self.r)
        self.r.publicar_limpeza_handler(t, OSError())
        self.r.fechar_socket(t)
        self.assertFalse(self.r.encerramento_confirmado())
        self.assertFalse(self.c._compactar_ciclo(1))
        self.assertEqual(self.r.obter_situacao()['falhas_fechamento_handlers'][0]['criacao_id'], t.criacao_id)

    def test_erro_close_preservado(self):
        t, sock = self.cliente()
        self.r.encerrar_uso_socket(t)
        sock.close = Mock(side_effect=OSError())
        self.assertFalse(self.r.fechar_socket(t))
        self.r.bloquear_criacao()
        self.assertFalse(self.r.encerramento_confirmado())
        self.assertEqual(self.r._reservas_socket[t.criacao_id].estado, 'erro_limpeza')

    def test_start_ambiguo_nao_perde_socket(self):
        t, sock = self.cliente()
        thread = Mock()
        thread.start.side_effect = RuntimeError()
        thread.is_alive.return_value = False
        with self.assertRaises(RuntimeError):
            self.r.registrar_e_iniciar(thread)
        self.r.bloquear_criacao()
        self.assertIs(self.r.threads[0], thread)
        self.assertIs(self.r._reservas_socket[t.criacao_id].recurso, sock)
        self.assertFalse(self.r.encerramento_confirmado())

    def test_historico_novo_ciclo_e_compactacao_repetida(self):
        self.r.bloquear_criacao()
        self.c.finalizar(self.r)
        self.assertTrue(self.c.tentar_iniciar(s.RegistroTrabalhadores()))
        self.assertTrue(self.c._obter_situacao_historica(1)['encerramento_confirmado'])
        for _ in range(2):
            self.assertTrue(self.c._compactar_ciclo(1))
            self.assertTrue(self.r.fechar_socket(self.t))


if __name__ == '__main__':
    unittest.main()

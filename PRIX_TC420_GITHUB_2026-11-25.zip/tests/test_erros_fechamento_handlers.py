# Testes de erros fechamento handlers: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Limpeza de handlers reais com sockets simulados; sem rede/Tk."""
import json
import threading
import unittest
from unittest.mock import Mock, patch

from rede import servidor
from test_guarda_sockets_integrada import LockObservado, SocketFalso


# Grupo de 24 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class ErrosFechamentoHandlers(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.controle = servidor.ControleCicloServidor()
        self.controle.lock = LockObservado()
        self.registro = servidor.RegistroTrabalhadores()
        self.registro.lock = LockObservado()
        self.controle.tentar_iniciar(self.registro)

    def fora_lock(self):
        for lock in (self.registro.lock, self.controle.lock):
            self.assertNotEqual(lock.dono, threading.get_ident())

    def cliente(self):
        recurso = SocketFalso(self.fora_lock)
        recurso.comando = b"CONFIG\n"
        reserva = self.registro.reservar_criacao_socket()
        self.registro.anexar_socket(reserva, recurso)
        self.registro.publicar_socket(reserva)
        return reserva, recurso

    def executar(self, reserva, recurso):
        try:
            servidor._atender_cliente_do_ciclo(recurso, ("simulado", 1), self.registro, reserva)
        except BaseException as erro:
            return erro
        return None

    def falhar_close_uma_vez(self, recurso, erro):
        original = recurso.close
        chamadas = []
        def fechar():
            self.fora_lock()
            chamadas.append(True)
            if len(chamadas) == 1:
                raise erro
            original()
        recurso.close = fechar

    def falhas(self):
        return self.registro.obter_situacao()["falhas_fechamento_handlers"]

    def finalizar(self):
        self.registro.limpar_sockets()
        self.controle.finalizar(self.registro)
        return self.controle._obter_situacao_historica(self.registro.ciclo_id)

    def iniciar_thread(self, reserva, recurso, resultados):
        thread = threading.Thread(target=lambda: resultados.append(self.executar(reserva, recurso)))
        self.assertTrue(self.registro.registrar_e_iniciar(thread))
        return thread

    def aguardar(self, thread):
        thread.join(5)
        self.assertFalse(thread.is_alive())

    def test_01_normal(self):
        reserva, recurso = self.cliente()
        self.assertIsNone(self.executar(reserva, recurso))
        self.assertFalse(self.falhas())
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_02_erro_atendimento_preservado(self):
        reserva, recurso = self.cliente()
        original = RuntimeError("mensagem descartada")
        recurso.recv = Mock(side_effect=original)
        self.assertIs(self.executar(reserva, recurso), original)
        self.assertTrue(recurso.fechado)
        self.assertFalse(self.falhas())

    def test_03_close_falha_e_retry_nao_apaga(self):
        reserva, recurso = self.cliente()
        original = OSError("mensagem descartada")
        self.falhar_close_uma_vez(recurso, original)
        self.assertIs(self.executar(reserva, recurso), original)
        self.assertTrue(recurso.fechado)
        self.assertEqual(self.falhas(), ({"criacao_id": reserva.criacao_id,
            "ciclo_id": 1, "origem": "handler.close", "tipo": "OSError"},))
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_04_ambos_erros_separados(self):
        reserva, recurso = self.cliente()
        atendimento = RuntimeError("erro principal")
        fechamento = OSError("erro secundario")
        recurso.recv = Mock(side_effect=atendimento)
        self.falhar_close_uma_vez(recurso, fechamento)
        self.assertIs(self.executar(reserva, recurso), atendimento)
        self.assertEqual(self.falhas()[0]["tipo"], "OSError")
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_05_dois_handlers(self):
        for _ in range(2):
            reserva, recurso = self.cliente()
            self.falhar_close_uma_vez(recurso, OSError())
            self.executar(reserva, recurso)
        self.assertEqual(len(self.falhas()), 2)
        self.assertEqual(len({f["criacao_id"] for f in self.falhas()}), 2)
        self.assertEqual({f["ciclo_id"] for f in self.falhas()}, {1})

    def test_06_ciclo_antigo_com_global_novo(self):
        reserva, recurso = self.cliente()
        self.falhar_close_uma_vez(recurso, OSError())
        outro_controle = servidor.ControleCicloServidor()
        outro_registro = servidor.RegistroTrabalhadores()
        outro_controle.tentar_iniciar(outro_registro)
        with patch.object(servidor, "controle_ciclo_servidor", outro_controle):
            self.executar(reserva, recurso)
        self.assertEqual(len(self.falhas()), 1)
        self.assertFalse(outro_registro.obter_situacao()["erros_limpeza"])

    def test_07_ciclo_novo_nao_recebe_erro_antigo(self):
        reserva, recurso = self.cliente()
        self.falhar_close_uma_vez(recurso, OSError())
        self.executar(reserva, recurso)
        self.finalizar()
        self.assertFalse(self.controle.tentar_iniciar(servidor.RegistroTrabalhadores()))
        independente = servidor.ControleCicloServidor()
        novo = servidor.RegistroTrabalhadores()
        independente.tentar_iniciar(novo)
        novo.limpar_sockets()
        independente.finalizar(novo)
        self.assertTrue(independente._obter_situacao_historica(novo.ciclo_id)["encerramento_confirmado"])
        self.assertFalse(novo.obter_situacao()["falhas_fechamento_handlers"])

    def test_08_repeticao_nao_apaga(self):
        reserva, recurso = self.cliente()
        self.falhar_close_uma_vez(recurso, OSError())
        self.executar(reserva, recurso)
        antes = self.falhas()
        for _ in range(3):
            self.registro.publicar_limpeza_handler(reserva)
            self.registro.limpar_sockets()
        self.assertEqual(self.falhas(), antes)
        self.assertEqual(self.registro.obter_situacao()["erros_limpeza"], ["handler.close:OSError"])

    def test_09_publicacao_falha_mantem_pendencia(self):
        reserva, recurso = self.cliente()
        erro_close = OSError()
        self.falhar_close_uma_vez(recurso, erro_close)
        with patch.object(self.registro, "publicar_limpeza_handler", side_effect=RuntimeError()):
            self.assertIs(self.executar(reserva, recurso), erro_close)
        situacao = self.registro.obter_situacao()
        self.assertTrue(situacao["criacoes_socket"][0]["limpeza_handler_pendente"])
        self.assertFalse(self.finalizar()["encerramento_confirmado"])
        self.assertFalse(self.controle._compactar_ciclo(1))

    def test_10_thread_termina_erro_permanece(self):
        reserva, recurso = self.cliente()
        erro_close = OSError()
        self.falhar_close_uma_vez(recurso, erro_close)
        resultados = []
        thread = self.iniciar_thread(reserva, recurso, resultados)
        self.aguardar(thread)
        self.assertIs(resultados[0], erro_close)
        self.assertFalse(self.registro.obter_situacao()["threads_vivas"])
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_11_consulta_durante_limpeza(self):
        reserva, recurso = self.cliente()
        entrou = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        close_real = recurso.close
        def fechar():
            self.fora_lock()
            entrou.wait()
            liberar.wait()
            close_real()
        recurso.close = fechar
        resultados = []
        thread = self.iniciar_thread(reserva, recurso, resultados)
        try:
            entrou.wait()
            self.assertFalse(self.finalizar()["encerramento_confirmado"])
        finally:
            liberar.wait()
            self.aguardar(thread)
        self.assertEqual(resultados, [None])
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_12_socket_fechado_externamente(self):
        reserva, recurso = self.cliente()
        recurso.close()
        self.assertIsNone(self.executar(reserva, recurso))
        self.assertEqual(recurso.fechamentos, 1)
        self.assertFalse(self.falhas())

    def test_13_finally_publicacao_falha_preserva_principal(self):
        reserva, recurso = self.cliente()
        principal = RuntimeError("principal")
        recurso.recv = Mock(side_effect=principal)
        resultados = []
        with patch.object(self.registro, "publicar_limpeza_handler", side_effect=ValueError()):
            thread = self.iniciar_thread(reserva, recurso, resultados)
            self.aguardar(thread)
        self.assertIs(resultados[0], principal)
        self.assertTrue(recurso.fechado)
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_14_sucesso_nao_inventa_erro(self):
        for _ in range(2):
            reserva, recurso = self.cliente()
            self.executar(reserva, recurso)
        self.assertEqual(self.registro.obter_situacao()["erros_limpeza"], [])
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_15_reserva_pendente_ainda_impede(self):
        reserva, recurso = self.cliente()
        self.executar(reserva, recurso)
        self.registro.reservar_criacao_socket()
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_16_coordenador_retorna_antes_do_handler(self):
        reserva, recurso = self.cliente()
        entrou = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        def receber(*args):
            entrou.wait()
            liberar.wait()
            return b"CONFIG\n"
        recurso.recv = receber
        resultados = []
        thread = self.iniciar_thread(reserva, recurso, resultados)
        try:
            entrou.wait()
            self.assertFalse(self.finalizar()["encerramento_confirmado"])
            self.assertTrue(self.registro.publicacao_limpeza_concluida)
        finally:
            liberar.wait()
            self.aguardar(thread)
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_17_critico_a_erro_publicado_tardiamente(self):
        reserva, recurso = self.cliente()
        erro_close = OSError()
        self.falhar_close_uma_vez(recurso, erro_close)
        chegou = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        publicar_original = self.registro.publicar_limpeza_handler
        def publicar(*args):
            self.fora_lock()
            chegou.wait()
            liberar.wait()
            return publicar_original(*args)
        resultados = []
        with patch.object(self.registro, "publicar_limpeza_handler", side_effect=publicar):
            thread = self.iniciar_thread(reserva, recurso, resultados)
            try:
                chegou.wait()
                self.assertFalse(self.falhas())
                self.assertTrue(self.registro.obter_situacao()["criacoes_socket"][0]["limpeza_handler_pendente"])
                self.assertFalse(self.finalizar()["encerramento_confirmado"])
            finally:
                liberar.wait()
                self.aguardar(thread)
        self.assertIs(resultados[0], erro_close)
        self.assertEqual(len(self.falhas()), 1)
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_18_critico_b_falhas_simultaneas(self):
        barreira = threading.Barrier(2, timeout=5)
        resultados, threads = [], []
        for _ in range(2):
            reserva, recurso = self.cliente()
            close_real = recurso.close
            chamadas = []
            def fechar(close_real=close_real, chamadas=chamadas):
                self.fora_lock()
                chamadas.append(True)
                if len(chamadas) == 1:
                    barreira.wait()
                    raise OSError()
                close_real()
            recurso.close = fechar
            threads.append(self.iniciar_thread(reserva, recurso, resultados))
        for thread in threads:
            self.aguardar(thread)
        self.assertEqual(len(self.falhas()), 2)
        self.assertEqual(len({f["criacao_id"] for f in self.falhas()}), 2)
        self.assertEqual(len(self.registro.obter_situacao()["erros_limpeza"]), 2)
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_19_critico_c_identidade_erro_principal(self):
        reserva, recurso = self.cliente()
        principal, limpeza = RuntimeError("principal"), OSError("limpeza")
        recurso.recv = Mock(side_effect=principal)
        self.falhar_close_uma_vez(recurso, limpeza)
        resultados = []
        thread = self.iniciar_thread(reserva, recurso, resultados)
        self.aguardar(thread)
        self.assertIs(resultados[0], principal)
        self.assertEqual(self.falhas()[0]["tipo"], "OSError")
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_20_sanitizacao_sem_objetos_excecao(self):
        reserva, recurso = self.cliente()
        class FalhaEspecifica(Exception):
            pass
        erro = FalhaEspecifica("conteudo_nao_persistir")
        self.falhar_close_uma_vez(recurso, erro)
        self.executar(reserva, recurso)
        situacao = self.registro.obter_situacao()
        self.assertEqual(self.falhas()[0]["tipo"], "Exception")
        self.assertNotIn("conteudo_nao_persistir", repr(situacao))
        self.assertNotIn("FalhaEspecifica", repr(situacao))
        self.assertTrue(all(type(f["tipo"]) is str for f in self.falhas()))

    def test_21_falha_publicacao_sem_erro_handler(self):
        reserva, recurso = self.cliente()
        original = RuntimeError("publicacao")
        with patch.object(self.registro, "publicar_limpeza_handler", side_effect=original):
            self.assertIs(self.executar(reserva, recurso), original)
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_22_limpeza_posterior_nao_substitui_principal(self):
        reserva, recurso = self.cliente()
        original = RuntimeError("atendimento")
        recurso.recv = Mock(side_effect=original)
        with patch.object(servidor, "_encerrar_socket_do_ciclo", side_effect=ValueError()):
            self.assertIs(self.executar(reserva, recurso), original)
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_23_protocolos_preservados(self):
        for comando in ("CHECK", "CONFIG", "REGISTER|simulado", "SUBSCRIBE", "DESCONHECIDO"):
            with self.subTest(comando=comando):
                reserva, recurso = self.cliente()
                recurso.comando = (comando + "\n").encode()
                parar = threading.Event()
                enviar_original = recurso.sendall
                def enviar(dados):
                    enviar_original(dados)
                    if comando == "SUBSCRIBE":
                        parar.set()
                recurso.sendall = enviar
                with patch.object(servidor, "configuracao_atual", {"escala": "simulada"}), \
                     patch.object(servidor, "dados_atuais", {"peso_liquido": "1"}), \
                     patch.object(servidor, "clientes_registrados", {}), \
                     patch.object(servidor, "evento_parada_servidor", parar), \
                     patch.object(servidor, "obter_saude_tc420", return_value=dict(saudavel=True)):
                    self.assertIsNone(self.executar(reserva, recurso))
                if comando == "CHECK":
                    self.assertEqual(recurso.enviados, [b"TC420_SERVER_OK\n"])
                elif comando == "CONFIG":
                    self.assertEqual(json.loads(recurso.enviados[0]), {"escala": "simulada"})
                elif comando.startswith("REGISTER"):
                    self.assertEqual(json.loads(recurso.enviados[0]), {"nome": "simulado", "posicao": 1})
                elif comando == "SUBSCRIBE":
                    self.assertEqual(json.loads(recurso.enviados[0]), {"peso_liquido": "1"})
                else:
                    self.assertFalse(recurso.enviados)
                self.assertTrue(recurso.fechado)
        self.assertFalse(self.falhas())

    def test_24_erros_de_conexao_ja_tratados_preservados(self):
        reserva, recurso = self.cliente()
        recurso.recv = Mock(side_effect=ConnectionResetError())
        self.assertIsNone(self.executar(reserva, recurso))
        self.assertFalse(self.falhas())
        self.assertTrue(recurso.fechado)


if __name__ == "__main__":
    unittest.main()

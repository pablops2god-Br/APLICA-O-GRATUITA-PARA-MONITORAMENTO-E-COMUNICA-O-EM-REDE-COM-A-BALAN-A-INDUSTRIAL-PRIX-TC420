# Testes de composicao admissoes cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-D1: registros reais, fontes passivas e interleavings simulados."""
from contextlib import ExitStack
from copy import deepcopy
import json
import threading
import unittest
from unittest.mock import Mock, patch

from config.arquivos import ContextoArquivosConfiguracao
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.lerdadosserver import LeitorDadosServidor
from test_recursos_cliente_integrados import SocketLeituraFalso
from test_descoberta_cliente_integrada import SocketDescobertaFalso
import test_composicao_operacional_cliente as anterior
import test_auditoria_atividades_cliente_ac3b as auditoria
import test_admissao_config_cliente as config
import test_admissao_subscribe_cliente as subscribe


# Grupo de 45 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class ComposicaoAdmissoesCliente(unittest.TestCase):
    setUp = anterior.ComposicaoOperacionalCliente.setUp
    fabricar = anterior.ComposicaoOperacionalCliente.fabricar
    preparar = anterior.ComposicaoOperacionalCliente.preparar
    partir = anterior.ComposicaoOperacionalCliente.partir
    executar_descoberta = anterior.ComposicaoOperacionalCliente.executar_descoberta
    executar_sem_busca = anterior.ComposicaoOperacionalCliente.executar_sem_busca
    observar = anterior.ComposicaoOperacionalCliente.observar
    fechar_gates = anterior.ComposicaoOperacionalCliente.fechar_gates
    terminal = anterior.ComposicaoOperacionalCliente.terminal
    operacao_http = anterior.ComposicaoOperacionalCliente.operacao_http
    tarefa = anterior.ComposicaoOperacionalCliente.tarefa
    terminar = anterior.ComposicaoOperacionalCliente.terminar

    def avaliar(self):
        resultado = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(resultado['encerramento_cliente_confirmado'])
        self.assertFalse(resultado['encerramento_global_confirmado'])
        self.assertFalse(resultado['snapshot_atomico'])
        return resultado

    def valido(self):
        resultado = self.avaliar()
        self.assertTrue(resultado['leituras_revalidadas'], resultado['pendencias'])
        return resultado

    def itens(self, familia):
        return [a for a in self.valido()['admissoes'] if a['familia'] == familia]

    def thread_retornada(self, observar=False, alvo=None, leitor=None):
        leitor = leitor or self.leitor
        leitor.executando = False
        leitor._manter_atualizado = alvo or Mock()
        with patch('rede.lerdadosserver.threading.Thread', side_effect=self.fabricar):
            leitor.iniciar()
        self.threads[-1].target()
        if observar:
            self.assertTrue(self.infra.observar_termino_leitores()[-1]['termino_observado'])

    def test_01_permanente_ativa(self):
        entrou, liberar = threading.Event(), threading.Event()
        def alvo():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
        self.leitor.executando = False
        self.leitor._manter_atualizado = alvo
        self.leitor.iniciar()
        try:
            self.assertTrue(entrou.wait(3))
            resultado = self.valido()
            self.assertTrue(resultado['atividades_permanentes'][0]['execucao_em_curso'])
            self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])
        finally:
            self.leitor.parar()
            liberar.set()
            self.leitor.thread.join(3)
        self.assertFalse(self.leitor.thread.is_alive())

    def test_02_parada_sem_observacao_pendente(self):
        self.thread_retornada()
        self.leitor.parar()
        resultado = self.valido()
        self.assertFalse(resultado['atividades_permanentes'][0]['termino_confirmado'])
        self.assertIn('atividades_permanentes_pendentes', resultado['pendencias'])

    def test_03_termino_observado_considerado(self):
        self.thread_retornada(observar=True)
        resultado = self.valido()
        self.assertTrue(resultado['atividades_permanentes'][0]['termino_confirmado'])
        self.assertTrue(resultado['responsabilidades_conhecidas_resolvidas'])

    def test_04_partida_ambigua(self):
        self.leitor.executando = False
        def fabricar(**kwargs):
            thread = self.fabricar(**kwargs)
            thread.start = Mock(side_effect=RuntimeError('start_simulado'))
            return thread
        with patch('rede.lerdadosserver.threading.Thread', side_effect=fabricar):
            with self.assertRaises(RuntimeError):
                self.leitor.iniciar()
        item, = self.valido()['atividades_permanentes']
        self.assertTrue(item['partida_ambigua'])
        self.assertFalse(item['termino_confirmado'])

    def test_05_geracao_antiga_ativa(self):
        self.leitor.executando = False
        with patch('rede.lerdadosserver.threading.Thread', side_effect=self.fabricar):
            self.leitor.iniciar()
        origem = self.leitor.recursos_cliente._geracao_retentativas
        self.guarda.promover(origem)
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.thread_retornada(observar=True, leitor=novo)
        resultado = self.valido()
        self.assertEqual(2, len(resultado['atividades_permanentes']))
        self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])

    def test_06_REGISTER_sem_recurso(self):
        self.leitor._admissao_register.admitir()
        item, = self.itens('register')
        self.assertEqual([], item['recursos'])
        self.assertFalse(item['responsabilidade_resolvida'])

    def test_07_REGISTER_concluido_recurso_pendente(self):
        controle = self.leitor._admissao_register
        with controle.executar(controle.admitir()) as dono:
            cliente = dono.abrir_socket(SocketLeituraFalso)
        self.addCleanup(cliente.close)
        item, = self.itens('register')
        self.assertTrue(item['execucao_concluida'])
        self.assertFalse(item['recursos_resolvidos'])
        self.assertFalse(item['responsabilidade_resolvida'])

    def test_08_descoberta_sem_UDP(self):
        self.leitor._admissao_descoberta_inicial.admitir()
        item, = self.itens('descoberta_inicial')
        self.assertEqual([], item['recursos'])
        self.assertIn('execucao_nao_concluida', item['pendencias'])

    def test_09_CHECK_sem_TCP(self):
        self.leitor._admissao_descoberta_inicial._admissao_checks.admitir(self.leitor.recursos_cliente)
        item, = self.itens('check_tcp')
        self.assertIsNone(item['retentativa_id'])
        self.assertEqual([], item['recursos'])
        self.assertFalse(item['responsabilidade_resolvida'])

    def test_10_CONFIG_sem_tentativa(self):
        self.leitor._admissao_config.admitir()
        item, = self.itens('config')
        self.assertEqual([], item['recursos'])
        self.assertFalse(item['execucao_concluida'])

    def test_11_tentativa_CONFIG_sem_socket(self):
        controle = self.leitor._admissao_config
        with controle.executar(controle.admitir()) as dono:
            controle.admitir_tentativa(dono._operacao)
            item, = self.itens('tentativa_config')
            self.assertEqual([], item['recursos'])
            self.assertFalse(item['responsabilidade_resolvida'])

    def test_12_SUBSCRIBE_sem_TCP(self):
        self.leitor._admissao_subscribe.admitir()
        item, = self.itens('subscribe')
        self.assertEqual([], item['recursos'])
        self.assertFalse(item['responsabilidade_resolvida'])

    def test_13_reconexao_pendente(self):
        controle = self.leitor._admissao_subscribe
        identidade = controle.admitir()
        controle.iniciar(identidade)
        controle.finalizar(identidade)
        controle.admitir()
        a, b = self.itens('subscribe')
        self.assertNotEqual(a['identidade_id'], b['identidade_id'])
        self.assertTrue(a['responsabilidade_resolvida'])
        self.assertFalse(b['responsabilidade_resolvida'])

    def test_14_HTTP_pendente(self):
        self.operacao_http()
        resultado = self.valido()
        self.assertFalse(resultado['http'][0]['execucao_resolvida'])
        self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])

    def test_15_arquivo_retido(self):
        contexto = ContextoArquivosConfiguracao(self.infra)
        arquivo = Mock(closed=False)
        contexto.executar(lambda: arquivo, lambda f: None)
        resultado = self.valido()
        self.assertTrue(resultado['retencoes_pendentes'])
        self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])
        arquivo.closed = True
        self.infra.tentar_limpeza_arquivo(resultado['retencoes_pendentes'][0])

    def test_16_resolvidos_exigem_cobertura(self):
        self.terminal()
        self.thread_retornada(observar=True)
        self.leitor.parar()
        self.infra.registro_atividades_permanentes.fechar_admissao()
        self.infra.registro_http.fechar_admissao()
        resultado = self.valido()
        self.assertTrue(resultado['responsabilidades_conhecidas_resolvidas'])
        self.assertTrue(resultado['admissoes_operacionais_fechadas'])
        self.assertEqual('incompleta', resultado['cobertura_operacional'])

    def test_critica_A_thread_terminada_CONFIG_pendente(self):
        controle = self.leitor._admissao_config
        def alvo():
            with controle.executar(controle.admitir()) as dono:
                controle.admitir_tentativa(dono._operacao)
        self.thread_retornada(observar=True, alvo=alvo)
        resultado = self.valido()
        self.assertTrue(resultado['atividades_permanentes'][0]['termino_confirmado'])
        self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])
        self.assertTrue(self.itens('config')[0]['execucao_concluida'])
        self.assertFalse(self.itens('tentativa_config')[0]['responsabilidade_resolvida'])

    def test_critica_B_reconexao_sem_socket(self):
        self.test_13_reconexao_pendente()
        self.assertIn('admissoes_pendentes', self.valido()['pendencias'])

    def test_critica_C_retry_terminada_CHECK_pendente(self):
        def alvo():
            dono = self.leitor._partidas_retentativas.recursos_da_execucao(
                self.leitor.recursos_cliente, caminho='espera_recuperacao_descoberta')
            dono._admissao_checks.admitir(dono)
        self.leitor._aguardar_proxima_tentativa = alvo
        self.preparar()
        self.partir()
        self.threads[-1].target()
        self.observar()
        self.fechar_gates()
        self.assertTrue(self.guarda.obter_retrato()['retentativas'][0]['thread_terminada'])
        resultado = self.valido()
        self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])
        self.assertTrue(resultado['retentativas'][0]['checks_pendentes'])
        item, = self.itens('check_tcp')
        self.assertEqual('recuperacao', item['origem'])
        self.assertEqual([], item['recursos'])

    def test_critica_D_REGISTER_antigo_B_terminada(self):
        self.leitor._admissao_register.admitir()
        geracao = self.leitor.recursos_cliente._geracao_retentativas
        self.guarda.promover(geracao)
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.thread_retornada(observar=True, leitor=novo)
        item, = self.itens('register')
        self.assertEqual(geracao.numero, item['geracao_id'])
        self.assertFalse(item['responsabilidade_resolvida'])
        self.assertFalse(self.valido()['responsabilidades_conhecidas_resolvidas'])

    def test_critica_E_publicacao_e_limpeza_entre_leituras(self):
        controle = self.leitor._admissao_register
        contexto = controle.executar(controle.admitir())
        dono = contexto.__enter__()
        cliente = dono.abrir_socket(SocketLeituraFalso)
        obter = self.infra.obter_operacoes_register
        chamadas = []
        def consultar():
            retrato = obter()
            if not chamadas:
                contexto.__exit__(None, None, None)
                cliente.close()
            chamadas.append(True)
            return retrato
        with patch.object(InfraestruturaRegistrosCliente, 'obter_operacoes_register', side_effect=consultar):
            resultado = self.avaliar()
        self.assertFalse(resultado['leituras_revalidadas'])
        self.assertIn('consulta_incoerente', resultado['pendencias'])
        self.assertTrue(self.itens('register')[0]['responsabilidade_resolvida'])

    def test_critica_F_passividade_das_consultas(self):
        self.leitor._admissao_subscribe.admitir()
        self.thread_retornada()
        consultas = ('obter_atividades_permanentes', 'obter_operacoes_register',
                     'obter_operacoes_descoberta_inicial', 'obter_operacoes_config',
                     'obter_tentativas_subscribe', 'obter_associacoes_retentativas')
        antes = {nome: getattr(self.infra, nome)() for nome in consultas}
        proibidas = [(InfraestruturaRegistrosCliente, 'observar_termino_leitores'),
                     (InfraestruturaRegistrosCliente, 'observar_termino_retentativas'),
                     (self.leitor, 'parar'), (self.leitor.thread, 'is_alive'),
                     (self.guarda, 'fechar_admissao'), (self.infra.registro_recursos, 'fechar'),
                     (self.infra.registro_recursos, 'criar'),
                     (self.infra.registro_http, 'executar'),
                     (self.infra.registro_atividades_permanentes, 'fechar_admissao'),
                     (self.leitor._admissao_descoberta_inicial, 'fechar_admissao')]
        for controle in (self.leitor._admissao_register, self.leitor._admissao_config,
                         self.leitor._admissao_subscribe):
            proibidas.append((controle, 'admitir'))
        with ExitStack() as pilha:
            mocks = [pilha.enter_context(patch.object(objeto, nome, side_effect=AssertionError(nome)))
                     for objeto, nome in proibidas]
            rastros = [pilha.enter_context(patch.object(InfraestruturaRegistrosCliente, nome,
                       wraps=getattr(self.infra, nome))) for nome in consultas]
            self.valido()
            self.assertTrue(all(m.call_count == 2 for m in rastros))
            self.assertTrue(all(m.call_count == 0 for m in mocks))
        self.assertEqual(antes, {nome: getattr(self.infra, nome)() for nome in consultas})

    def test_adicional_callback_global_fora_da_cobertura(self):
        root = auditoria.TkSimulado()
        root.after(0, Mock())
        self.test_16_resolvidos_exigem_cobertura()
        resultado = self.valido()
        self.assertTrue(resultado['responsabilidades_conhecidas_resolvidas'])
        self.assertEqual(1, len(root.pendentes))
        self.assertFalse(resultado['encerramento_global_confirmado'])
        self.assertIn('aplicacao_fora_do_escopo', resultado['pendencias'])

    def test_CONFIG_real_concluido_e_identidades(self):
        fx = config.AdmissaoConfigCliente()
        fx.setUp()
        with fx.transporte([fx.objeto()]):
            fx.configurar()
        resultado = fx.infra.avaliar_responsabilidades_cliente()
        self.assertTrue(resultado['leituras_revalidadas'])
        itens = [a for a in resultado['admissoes'] if a['familia'] in ('config', 'tentativa_config')]
        self.assertEqual(2, len(itens))
        self.assertTrue(all(a['responsabilidade_resolvida'] for a in itens))

    def test_SUBSCRIBE_real_e_reconexao_concluidas(self):
        fx = subscribe.AdmissaoSubscribeCliente()
        fx.setUp()
        fx.duas_conexoes(fx.objeto(), fx.objeto())
        resultado = fx.infra.avaliar_responsabilidades_cliente()
        self.assertTrue(resultado['leituras_revalidadas'])
        itens = [a for a in resultado['admissoes'] if a['familia'] == 'subscribe']
        self.assertEqual(2, len(itens))
        self.assertTrue(all(a['responsabilidade_resolvida'] for a in itens))

    def test_descoberta_e_CHECK_mesmos_recursos_sem_duplicar(self):
        from rede import buscarservidor as busca
        udp, tcp = SocketDescobertaFalso(), SocketDescobertaFalso()
        udp.recvfrom.side_effect = [(b'TC420_SERVER_HERE', ('simulado', 42101))]
        with patch('socket.socket', side_effect=[udp, tcp]):
            self.assertEqual('simulado', self.leitor._buscar_servidor_inicial())
        resultado = self.valido()
        self.assertEqual(2, len(resultado['recursos']))
        self.assertTrue(all(a['responsabilidade_resolvida'] for a in resultado['admissoes']))
        self.assertEqual({'descoberta_inicial', 'check_tcp'}, {a['familia'] for a in resultado['admissoes']})

    def test_preparacao_sem_autoridade_CHECK_nao_e_lacuna_ficticia(self):
        from rede import buscarservidor as busca
        with patch('socket.socket', return_value=SocketDescobertaFalso()):
            busca.buscar_servidor(infraestrutura_cliente=self.infra)
        resultado = self.valido()
        self.assertEqual([], resultado['admissoes'])
        self.assertTrue(resultado['responsabilidades_conhecidas_resolvidas'])
        self.assertTrue(resultado['origens_admissoes_completas'])

    def test_controle_sem_campo_de_conclusao_nao_confirma(self):
        self.leitor._admissao_subscribe.admitir()
        retrato = self.infra.obter_tentativas_subscribe()
        del retrato[0]['tentativas'][0]['retorno']
        with patch.object(InfraestruturaRegistrosCliente, 'obter_tentativas_subscribe', return_value=retrato):
            resultado = self.avaliar()
        self.assertFalse(resultado['leituras_revalidadas'])
        self.assertIn('falha_consulta_ou_contrato', resultado['pendencias'])

    def test_controle_omitido_por_geracao(self):
        with patch.object(InfraestruturaRegistrosCliente, 'obter_operacoes_config', return_value=[]):
            resultado = self.valido()
        self.assertFalse(resultado['origens_admissoes_completas'])
        self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])

    def test_falha_publicacao_CONFIG_considerada(self):
        fx = config.AdmissaoConfigCliente()
        fx.setUp()
        with fx.transporte([fx.objeto()]), patch.object(fx.controle, '_publicar_saida', side_effect=ValueError()):
            with self.assertRaises(ValueError):
                fx.configurar()
        resultado = fx.infra.avaliar_responsabilidades_cliente()
        self.assertTrue(resultado['leituras_revalidadas'])
        self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])
        self.assertTrue(any('publicacao_incompleta' in a['pendencias'] for a in resultado['admissoes']))

    def test_vinculo_estrangeiro_recusado(self):
        self.test_07_REGISTER_concluido_recurso_pendente()
        retrato = self.infra.obter_operacoes_register()
        retrato[0]['operacoes'][0]['atividade_recursos_id'] += 100
        with patch.object(InfraestruturaRegistrosCliente, 'obter_operacoes_register', return_value=retrato):
            self.assertFalse(self.avaliar()['leituras_revalidadas'])

    def test_recurso_de_outra_operacao_recusado(self):
        self.test_07_REGISTER_concluido_recurso_pendente()
        retrato = self.infra.obter_operacoes_register()
        outro = deepcopy(retrato[0]['operacoes'][0])
        outro['operacao_id'] += 1
        retrato[0]['operacoes'].append(outro)
        with patch.object(InfraestruturaRegistrosCliente, 'obter_operacoes_register', return_value=retrato):
            self.assertFalse(self.avaliar()['leituras_revalidadas'])

    def test_false_positivo_de_limpeza_recusado(self):
        self.test_07_REGISTER_concluido_recurso_pendente()
        retrato = self.infra.obter_operacoes_register()
        retrato[0]['operacoes'][0]['recursos'][0]['limpeza_confirmada'] = True
        retrato[0]['operacoes'][0]['responsabilidade_resolvida'] = True
        with patch.object(InfraestruturaRegistrosCliente, 'obter_operacoes_register', return_value=retrato):
            self.assertFalse(self.avaliar()['leituras_revalidadas'])

    def test_colecao_vazia_malformada_nao_e_prova(self):
        self.leitor._admissao_subscribe.admitir()
        retrato = self.infra.obter_tentativas_subscribe()
        retrato[0]['tentativas'] = {}
        with patch.object(InfraestruturaRegistrosCliente, 'obter_tentativas_subscribe', return_value=retrato):
            self.assertFalse(self.avaliar()['leituras_revalidadas'])

    def test_erro_consulta_nova_sanitizado(self):
        with patch.object(InfraestruturaRegistrosCliente, 'obter_operacoes_register',
                          side_effect=OSError('texto_privado_simulado')):
            resultado = self.avaliar()
        self.assertFalse(resultado['leituras_revalidadas'])
        self.assertNotIn('texto_privado_simulado', json.dumps(resultado))

    def test_atividade_reservada_sem_partida(self):
        self.infra.registro_atividades_permanentes.reservar(self.leitor._origem_atividade_permanente)
        item, = self.valido()['atividades_permanentes']
        self.assertFalse(item['entrada'])
        self.assertFalse(item['termino_confirmado'])

    def test_partida_sem_entrada_apos_start_pendente(self):
        self.leitor.executando = False
        with patch('rede.lerdadosserver.threading.Thread', side_effect=self.fabricar):
            self.leitor.iniciar()
        item, = self.valido()['atividades_permanentes']
        self.assertTrue(item['partida_resolvida'])
        self.assertFalse(item['entrada'])
        self.assertFalse(item['termino_confirmado'])

    def test_alvo_retornou_thread_ainda_viva(self):
        self.thread_retornada()
        self.threads[-1].is_alive.return_value = True
        self.assertFalse(self.infra.observar_termino_leitores()[0]['termino_observado'])
        self.threads[-1].is_alive.reset_mock()
        item, = self.valido()['atividades_permanentes']
        self.assertTrue(item['retorno'])
        self.assertFalse(item['termino_confirmado'])
        self.threads[-1].is_alive.assert_not_called()

    def test_publicacao_incompleta_da_atividade(self):
        registro = self.infra.registro_atividades_permanentes
        with patch.object(registro, '_publicar_saida', side_effect=RuntimeError('publicacao_simulada')):
            with self.assertRaises(RuntimeError):
                self.thread_retornada()
        item, = self.valido()['atividades_permanentes']
        self.assertTrue(item['erro_publicacao'])
        self.assertFalse(item['retorno'])
        self.assertFalse(item['termino_confirmado'])

    def test_CHECK_recuperacao_limpo_publicacao_incerta(self):
        resolver = self.guarda.resolver_secundaria
        def ambiguo(*args, **kwargs):
            resolver(*args, **kwargs)
            raise ValueError('publicacao_simulada')
        with patch.object(self.guarda, 'resolver_secundaria', side_effect=ambiguo):
            with self.assertRaises(ValueError):
                self.executar_descoberta()
        self.observar()
        self.fechar_gates()
        item, = self.itens('check_tcp')
        self.assertTrue(item['recursos_resolvidos'])
        self.assertFalse(item['publicacoes_resolvidas'])
        self.assertFalse(item['responsabilidade_resolvida'])

    def test_TCP_compartilhado_entre_CHECKs_recusado(self):
        self.test_descoberta_e_CHECK_mesmos_recursos_sem_duplicar()
        retrato = self.infra.obter_operacoes_descoberta_inicial()
        outro = deepcopy(retrato[0]['checks'][0])
        outro['check_id'] += 1
        retrato[0]['checks'].append(outro)
        with patch.object(InfraestruturaRegistrosCliente, 'obter_operacoes_descoberta_inicial', return_value=retrato):
            self.assertFalse(self.avaliar()['leituras_revalidadas'])

    def test_controle_duplicado_nao_vira_dupla_evidencia(self):
        retrato = self.infra.obter_operacoes_config()
        retrato.append(deepcopy(retrato[0]))
        with patch.object(InfraestruturaRegistrosCliente, 'obter_operacoes_config', return_value=retrato):
            self.assertFalse(self.avaliar()['leituras_revalidadas'])

    def test_flag_numerica_nao_vira_prova_booleana(self):
        self.leitor._admissao_subscribe.admitir()
        retrato = self.infra.obter_tentativas_subscribe()
        retrato[0]['tentativas'][0]['retorno'] = 1
        with patch.object(InfraestruturaRegistrosCliente, 'obter_tentativas_subscribe', return_value=retrato):
            self.assertFalse(self.avaliar()['leituras_revalidadas'])

    def test_revalidacao_concorrente_com_admissao_e_cleanup(self):
        controle = self.leitor._admissao_register
        contexto = controle.executar(controle.admitir())
        dono = contexto.__enter__()
        cliente = dono.abrir_socket(SocketLeituraFalso)
        capturado, liberar = threading.Event(), threading.Event()
        original = self.infra.obter_tentativas_subscribe
        chamadas = []
        def consultar():
            retrato = original()
            if not chamadas:
                chamadas.append(True)
                capturado.set()
                if not liberar.wait(3):
                    raise TimeoutError('barreira_simulada')
            return retrato
        finalizado = False
        with patch.object(InfraestruturaRegistrosCliente, 'obter_tentativas_subscribe', side_effect=consultar):
            trabalho = self.tarefa(self.infra.avaliar_responsabilidades_cliente)
            try:
                self.assertTrue(capturado.wait(3))
                contexto.__exit__(None, None, None)
                finalizado = True
                cliente.close()
            finally:
                if not finalizado:
                    contexto.__exit__(None, None, None)
                cliente.close()
                liberar.set()
                self.terminar(trabalho)
        self.assertEqual([], trabalho[2])
        resultado, = trabalho[1]
        self.assertFalse(resultado['leituras_revalidadas'])
        self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])
        self.assertIn('consulta_incoerente', resultado['pendencias'])

    def test_autorizacao_na_guarda_antes_da_publicacao_local_CHECK(self):
        reservar = self.guarda.reservar_secundaria
        capturados = []
        def suspender_publicacao(*args, **kwargs):
            identidade = reservar(*args, **kwargs)
            resultado = self.valido()
            secundaria, = resultado['autorizacoes_secundarias']
            self.assertEqual(identidade.numero, secundaria['autorizacao_id'])
            self.assertFalse(secundaria['responsabilidade_resolvida'])
            self.assertFalse(any(a['familia'] == 'check_tcp' for a in resultado['admissoes']))
            self.assertIn('autorizacoes_secundarias_pendentes', resultado['pendencias'])
            self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])
            capturados.append(identidade.numero)
            return identidade
        with patch.object(self.guarda, 'reservar_secundaria', side_effect=suspender_publicacao):
            self.executar_descoberta()
        self.assertEqual(1, len(capturados))
        self.assertTrue(self.valido()['autorizacoes_secundarias'][0]['responsabilidade_resolvida'])

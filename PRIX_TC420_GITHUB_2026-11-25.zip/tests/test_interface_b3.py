# Testes de interface b3: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""B3: concorrencia real, Tk/transporte simulados, sincronizacao por eventos."""
import ast
from pathlib import Path
from threading import Event, get_ident
from types import SimpleNamespace
import tkinter as tk
import unittest
from unittest.mock import Mock, patch

import requests

from interface.ciclo_tk import CicloTk, ciclo
from interface.janela import JanelaTC420
from interface.saida_aplicacao import SaidaAplicacao
from rede.servidor import RegistroTentativasAplicacao
import test_login_manual_http as manual


class Raiz:
    def __init__(self):
        self.dona = get_ident()
        self.viva = True
        self.callbacks = {}
        self.cancelados = []
        self.contador = 0
        self.acessos = []
        self.violacoes = []

    def usar(self):
        if get_ident() != self.dona:
            self.violacoes.append('worker')
            raise AssertionError('Tk acessado por worker')
        if not self.viva:
            self.violacoes.append('destruida')
            raise AssertionError('widget destruido acessado')
        self.acessos.append(get_ident())

    def bind(self, *args, **kwargs):
        self.usar()

    def winfo_exists(self):
        if get_ident() != self.dona:
            self.violacoes.append('worker_winfo')
            raise AssertionError('winfo acessado por worker')
        return self.viva

    def after(self, prazo, callback):
        self.usar()
        self.contador += 1
        self.callbacks[self.contador] = callback
        return self.contador

    def after_cancel(self, identidade):
        self.usar()
        self.cancelados.append(identidade)
        self.callbacks.pop(identidade, None)

    def destroy(self):
        self.usar()
        self.viva = False

    def config(self, **kwargs):
        self.usar()


# Grupo de 26 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class InterfaceB3(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.saida = SaidaAplicacao(prazo=.03, intervalo=.001)
        self.saida.configurar(registro=RegistroTentativasAplicacao())
        self.root = Raiz()
        self.janela = JanelaTC420.__new__(JanelaTC420)
        vars(self.janela).update(
            root=self.root, saida_aplicacao=self.saida, executando=True,
            promocao_em_andamento=False, janela_promocao=None,
            estado_candidatura=lambda: 'liberada', ao_promover=None,
            candidatura_liberada=lambda: True, candidatura_detectada=False,
            contextos_promocao=[], contexto_promocao_atual=None,
            fonte_dados=None, balanca=Mock(), label_peso=self.root,
        )
        self.janela.ao_fechar = self.saida.vincular('monitor_simulado')
        self.saida.conectar_interface(self.janela.ao_fechar,
                                     self.janela.agendar_saida,
                                     self.janela.concluir_fechamento,
                                     lambda estado: None)
        self.liberar = Event()
        self.entrou = Event()
        self.addCleanup(self.limpar)
        transporte = patch('requests.sessions.Session.send')
        self.transporte = transporte.start()
        self.addCleanup(transporte.stop)
        self.addCleanup(self.transporte.assert_not_called)

    def limpar(self):
        self.liberar.set()
        for item in self.saida._threads:
            thread = item['thread']
            if getattr(thread, 'ident', None) is not None:
                thread.join(3)
                self.assertFalse(thread.is_alive())
        if self.saida._coordenacao:
            self.saida._coordenacao.join(3)
        self.assertEqual([], self.root.violacoes)

    def lento(self, resultado=None):
        self.entrou.set()
        if not self.liberar.wait(3):
            raise TimeoutError('harness')
        return resultado

    def test_parada_do_leitor_na_promocao_nao_cancela_worker_nem_formulario(self):
        # O promotor para o leitor antes do login; parar limpa o evento e põe
        # estado inativa. A observação de 500 ms não pode cancelar o próprio login.
        for estado in ('inativa', 'cancelada'):
            with self.subTest(estado=estado):
                self.liberar, self.entrou = Event(), Event()
                formulario = Raiz()
                self.janela.janela_promocao = formulario
                self.janela.concluir_promocao = Mock()
                from rede.lerdadosserver import LeitorDadosServidor
                leitor = LeitorDadosServidor()
                self.addCleanup(leitor.parar)
                leitor.candidatura_liberada.set()
                leitor.definir_estado_candidatura('liberada')
                self.janela.candidatura_liberada = leitor.candidatura_esta_liberada
                self.janela.estado_candidatura = leitor.obter_estado_candidatura
                def promover():
                    leitor.parar()
                    if estado == 'cancelada':
                        leitor.definir_estado_candidatura('cancelada')
                    return self.lento({'promovida': True})
                self.assertTrue(self.janela._iniciar_promocao(
                    promover, formulario))
                self.assertTrue(self.entrou.wait(1))
                token = ciclo(self.janela).operacoes['promocao']
                self.janela.verificar_candidatura()
                self.assertTrue(formulario.viva)
                self.assertFalse(token.is_set())
                self.terminar()
                ciclo(self.janela).consumir()
                self.janela.concluir_promocao.assert_called_once_with({'promovida': True})
                self.assertFalse(formulario.viva)

    def test_candidatura_cancelada_sem_promocao_fecha_formulario(self):
        formulario = Raiz()
        self.janela.janela_promocao = formulario
        self.janela.candidatura_liberada = lambda: False
        self.janela.estado_candidatura = lambda: 'cancelada'
        self.janela.verificar_candidatura()
        self.assertFalse(formulario.viva)

    def test_tentativa_sem_sucesso_mantem_formulario_ate_fechamento_explicito(self):
        formulario = Raiz()
        self.janela.janela_promocao = formulario
        self.janela.candidatura_liberada = lambda: False
        self.janela.estado_candidatura = lambda: 'inativa'
        self.assertTrue(self.janela._iniciar_promocao(lambda: self.lento(None), formulario))
        self.assertTrue(self.entrou.wait(1))
        self.terminar()
        ciclo(self.janela).consumir()
        self.assertFalse(self.janela.promocao_em_andamento)
        self.janela.verificar_candidatura()
        self.assertTrue(formulario.viva)
        self.janela.fechar_janela_promocao(formulario)
        self.assertFalse(formulario.viva)

    def responder(self):
        self.assertTrue(self.entrou.wait(3))
        marcador = []
        ciclo(self.janela).agendar(0, lambda: marcador.append(True))
        ultimo = self.root.callbacks.pop(max(self.root.callbacks))
        ultimo()
        self.assertEqual([True], marcador)
        self.assertFalse(self.liberar.is_set())

    def terminar(self):
        self.liberar.set()
        for item in self.saida._threads:
            thread = item['thread']
            if getattr(thread, 'ident', None) is not None:
                thread.join(3)
                self.assertFalse(thread.is_alive())

    def conexao(self):
        fx = manual.LoginManualHttp()
        fx.setUp()
        janela = fx.janela
        # O controlador real substitui somente o executor imediato da fixture HTTP.
        self.saida = janela.saida_aplicacao
        self.saida._prazo = .03
        self.saida._intervalo = .001
        janela.root = self.root
        janela._ciclo_tk = CicloTk(self.root, lambda: self.saida)
        janela.saida_aplicacao = self.saida
        janela.label_status = self.root
        janela.botao_conectar = self.root
        self.janela = janela
        return fx, janela

    def remendar_http(self, janela, nome, substituto):
        remendo = patch.object(type(janela.infraestrutura_cliente), nome, substituto)
        remendo.start()
        self.addCleanup(remendo.stop)

    def iniciar_login(self, fase):
        fx, janela = self.conexao()
        fx.env['buscar_servidor'] = Mock(side_effect=(lambda **kw: self.lento('principal-simulado')) if fase == 'udp' else lambda **kw: None)
        # Sem transporte real; a fachada e o protocolo foram cobertos na regressao.
        if fase != 'udp':
            self.remendar_http(janela, 'executar_login_manual', Mock(side_effect=lambda *a, **kw: self.lento()))
        janela.conectar()
        self.responder()
        return fx, janela

    def test_01_udp_lento_tk_responde(self):
        self.iniciar_login('udp')

    def test_02_login_lento_tk_responde(self):
        self.iniciar_login('http')

    def test_03_timeout_approval_aplicado_no_tk(self):
        fx, janela = self.conexao()
        fx.env['buscar_servidor'].return_value = None
        self.remendar_http(janela, 'executar_login_manual', Mock())
        def approval(*args):
            self.lento()
            raise requests.Timeout()
        self.remendar_http(janela, 'executar_approval', Mock(side_effect=approval))
        janela.label_status = Mock(wraps=self.root)
        janela.conectar()
        self.responder()
        self.terminar()
        ciclo(janela).consumir()
        self.assertIn('esgotado', janela.label_status.config.call_args.kwargs['text'])
        self.assertFalse(janela.servidor_iniciado)

    def manual(self):
        arvore = ast.parse(Path('interface/janela.py').read_text(encoding='utf8'))
        confirmar = next(n for n in ast.walk(arvore) if isinstance(n, ast.FunctionDef) and n.name == 'confirmar')
        popup = Raiz()
        self.janela.janela_promocao = popup
        env = dict(self=self.janela, janela=popup)
        env['salvar_login_var'] = SimpleNamespace(get=lambda: False)
        for nome in ('entry_ip', 'entry_usuario', 'entry_senha'):
            env[nome] = SimpleNamespace(get=lambda: 'simulado')
        env['entry_senha'] = SimpleNamespace(get=lambda: object())
        exec(compile(ast.Module(body=[confirmar], type_ignores=[]), 'confirmar', 'exec'), env)
        return env['confirmar']

    def test_04_promocao_manual_lenta(self):
        self.janela.ao_promover = lambda *a: self.lento()
        self.manual()()
        self.responder()

    def test_05_promocao_automatica_lenta(self):
        self.janela.ao_promover_automaticamente = self.lento
        self.janela.verificar_candidatura()
        self.responder()

    def test_06_dois_conectar_um_worker(self):
        fx, janela = self.iniciar_login('http')
        janela.conectar()
        self.assertEqual(1, len(self.saida._threads))
        self.assertEqual(1, janela.infraestrutura_cliente.executar_login_manual.call_count)

    def test_07_dois_assumir_uma_promocao(self):
        self.janela.ao_promover = Mock(side_effect=lambda *a: self.lento())
        confirmar = self.manual()
        confirmar()
        self.responder()
        confirmar()
        self.assertEqual(1, self.janela.ao_promover.call_count)

    def test_08_sim_durante_login_impede_partida(self):
        fx, janela = self.iniciar_login('http')
        saida_callback = self.saida.vincular('conexao_simulada')
        saida_callback()
        self.terminar()
        self.saida._coordenacao.join(3)
        fx.env['iniciar_servidor'].assert_not_called()
        # Apenas o worker de login foi admitido; servidor e auxiliares recusados.
        self.assertEqual(1, len(self.saida._threads))
        ciclo(janela).consumir()
        self.assertTrue(self.root.viva)

    def test_09_sim_durante_promocao_impede_partida(self):
        ativou = []
        def promover():
            self.lento()
            from threading import Thread
            self.saida.iniciar_thread(Thread(target=lambda: ativou.append(True)))
            return {'web': object(), 'configuracao': {}, 'fonte_dados': Mock()}
        self.janela._iniciar_promocao(promover)
        self.responder()
        self.janela.ao_fechar()
        self.terminar()
        ciclo(self.janela).consumir()
        self.assertEqual([], ativou)
        self.assertIsNone(self.janela.fonte_dados)

    def test_10_resultado_apos_destruicao_sem_widgets(self):
        aplicou = Mock()
        controle = ciclo(self.janela)
        controle.iniciar('login', self.lento, aplicou)
        self.responder()
        antigos = list(self.root.callbacks.values())
        controle.fechar()
        self.root.destroy()
        self.terminar()
        for callback in antigos:
            callback()
        aplicou.assert_not_called()

    def test_11_peso_apos_destruicao(self):
        ciclo(self.janela).fechar()
        self.root.destroy()
        self.janela.atualizar_peso(1)

    def test_12_rebaixamento_durante_parada(self):
        pronto = Event()
        pronto.set()
        fonte = self.janela.fonte_dados
        leitor = SimpleNamespace(servidor_esta_respondendo=lambda: True, obter_dados_atuais=Mock())
        self.janela.observar_rebaixamento(pronto, lambda: leitor)
        callback = self.root.callbacks.pop(max(self.root.callbacks))
        self.janela.ao_fechar()
        callback()
        self.assertIs(fonte, self.janela.fonte_dados)

    def test_13_timeout_b2_mantem_janela(self):
        ciclo(self.janela).iniciar('login', self.lento, Mock())
        self.responder()
        self.janela.ao_fechar()
        self.saida._coordenacao.join(3)
        self.assertEqual('timeout', self.saida.obter_situacao()['estado'])
        for callback in list(self.root.callbacks.values()):
            callback()
        self.assertTrue(self.root.viva)

    def test_14_retry_nao_duplica_worker_ativo(self):
        ciclo(self.janela).iniciar('login', self.lento, Mock())
        self.responder()
        self.janela.ao_fechar()
        self.saida._coordenacao.join(3)
        self.assertTrue(self.janela.ao_fechar())
        self.saida._coordenacao.join(3)
        self.assertEqual(1, len(self.saida._threads))
        self.assertEqual(2, self.saida.obter_situacao()['tentativa'])

    def test_15_cancelar_preserva_operacao(self):
        aplicou = Mock()
        ciclo(self.janela).iniciar('login', self.lento, aplicou)
        self.responder()
        with patch('interface.janela.messagebox.askyesnocancel', return_value=None):
            self.janela.confirmar_fechamento()
        self.assertFalse(self.saida.parada_solicitada)
        self.terminar()
        ciclo(self.janela).consumir()
        aplicou.assert_called_once_with(None, None)

    def test_16_fechamento_cancela_e_invalida(self):
        aplicou = Mock()
        ciclo(self.janela).iniciar('login', self.lento, aplicou)
        self.responder()
        self.terminar()
        antigos = list(self.root.callbacks.values())
        self.janela.ao_fechar()
        self.saida._coordenacao.join(3)
        self.janela.concluir_fechamento()
        for callback in antigos:
            callback()
        self.assertTrue(self.root.cancelados)
        self.assertFalse(self.root.viva)
        self.assertTrue(self.saida.obter_situacao()['parada_operacional_confirmada'])
        aplicou.assert_not_called()

    def test_17_erro_tcl_de_programacao_permanece_visivel(self):
        self.janela.fonte_dados = Mock(side_effect=tk.TclError('falha_programacao_simulada'))
        with self.assertRaises(tk.TclError):
            self.janela.atualizar_refresh_web()

    def test_18_resultado_antiga_geracao_nao_altera_substituta(self):
        aplicou = Mock()
        antigo = ciclo(self.janela)
        antigo.iniciar('login', self.lento, aplicou)
        self.responder()
        antigo.fechar()
        novo = CicloTk(self.root, lambda: self.saida)
        self.janela._ciclo_tk = novo
        self.terminar()
        antigo.consumir()
        novo.consumir()
        aplicou.assert_not_called()

    def test_19_vinculo_substituido_recusa_resultado(self):
        aplicou = Mock()
        controle = ciclo(self.janela)
        controle.iniciar('login', self.lento, aplicou)
        self.responder()
        self.saida.vincular('nova_janela')
        self.terminar()
        controle.consumir()
        aplicou.assert_not_called()

    def test_20_label_destruido_com_root_vivo(self):
        self.janela.label_peso = Mock()
        self.janela.label_peso.winfo_exists.return_value = False
        self.janela.atualizar_peso(1)
        self.janela.label_peso.config.assert_not_called()

    def test_21_cancelamento_candidatura_impede_partida_tardia(self):
        ativou = []
        def promover():
            self.lento()
            from threading import Thread
            return self.saida.iniciar_thread(Thread(target=lambda: ativou.append(True)))
        self.janela._iniciar_promocao(promover)
        self.responder()
        self.janela.estado_candidatura = lambda: 'cancelada'
        ciclo(self.janela).cancelar('promocao')
        self.terminar()
        ciclo(self.janela).consumir()
        self.assertFalse(self.janela.promocao_em_andamento)
        self.assertEqual([], ativou)

    def test_22_callback_direto_apos_destroy_sem_controlador_previo(self):
        self.root.destroy()
        self.janela.atualizar_peso(1)

    def test_23_main_promocao_real_em_worker_sem_chamada_tk(self):
        import test_infraestrutura_cliente as montagem
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        monitores = []
        fx.durante_monitor = monitores.append
        from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
        fx.iniciar_cliente(InfraestruturaRegistrosCliente())
        monitor, = monitores
        self.saida = monitor.saida_aplicacao
        self.saida._prazo = .03
        self.saida._intervalo = .001
        self.janela.saida_aplicacao = self.saida
        self.janela.ao_fechar = monitor.ao_fechar
        fx.env['buscar_servidor'] = Mock(side_effect=lambda **kw: self.lento())
        self.janela._iniciar_promocao(
            lambda: monitor.ao_promover('balanca-simulada', 'simulado', object()))
        self.responder()
        self.janela.ao_fechar()
        self.terminar()
        self.saida._coordenacao.join(3)
        ciclo(self.janela).consumir()
        fx.env['iniciar_servidor'].assert_not_called()
        monitor.associar_contexto_promocao.assert_not_called()
        self.assertTrue(self.saida._contextos)
        self.assertIsNone(self.janela.fonte_dados)

    def test_24_sucesso_promocao_aplicado_somente_no_tk(self):
        fonte = Mock()
        self.janela._iniciar_promocao(lambda: self.lento(
            {'web': object(), 'configuracao': {}, 'fonte_dados': fonte}))
        self.responder()
        self.terminar()
        self.assertIsNone(self.janela.fonte_dados)
        ciclo(self.janela).consumir()
        self.assertIs(fonte, self.janela.fonte_dados)

    def test_25_conclusao_direta_sem_b2_nao_destroi(self):
        self.assertFalse(self.janela.concluir_fechamento())
        self.assertTrue(self.root.viva)

    def test_26_vinculo_antigo_nao_admite_servico(self):
        ativou = []
        def promover():
            self.lento()
            from threading import Thread
            self.saida.iniciar_thread(Thread(target=lambda: ativou.append(True)))
        ciclo(self.janela).iniciar('promocao', promover, Mock())
        self.responder()
        self.saida.vincular('substituta')
        self.terminar()
        self.assertEqual([], ativou)
        self.assertEqual(1, len(self.saida._threads))


if __name__ == '__main__':
    unittest.main()

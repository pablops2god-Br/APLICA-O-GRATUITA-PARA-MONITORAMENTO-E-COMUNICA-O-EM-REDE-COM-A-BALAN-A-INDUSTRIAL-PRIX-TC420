"""Painel em abas do laboratório offline; callbacks resolvidos na hora do clique."""
import tkinter as tk
from tkinter import ttk
from interface.formularios import centralizar


def montar_painel(e):
    e.painel = tk.Toplevel(e.conexao.root)
    e.painel.title('PRIX TC420 — Laboratório offline')
    centralizar(e.painel, 880, 650)
    e.painel.minsize(700, 520)
    e.painel.protocol('WM_DELETE_WINDOW', e.encerrar_harness)
    topo = ttk.Frame(e.painel, padding=14)
    topo.pack(fill='both', expand=True)
    ttk.Label(topo, text='Laboratório PRIX TC420', font=('Segoe UI', 18, 'bold')).pack(anchor='w')
    ttk.Label(topo, text='OFFLINE • sem TC420, rede, cofre ou configuração reais',
              font=('Segoe UI', 11)).pack(anchor='w', pady=(4, 12))
    e.abas = ttk.Notebook(topo)
    e.abas.pack(fill='both', expand=True)
    paginas = {}
    for nome in ('Cenários', 'TCP local', 'Administrador', 'Checklist', 'Registro'):
        paginas[nome] = ttk.Frame(e.abas, padding=12)
        e.abas.add(paginas[nome], text=nome)
    e.paginas = paginas
    c = paginas['Cenários']
    ttk.Label(c, text='Conexão: escolha um resultado simulado antes de conectar.').pack(anchor='w')
    modos = ttk.Frame(c)
    modos.pack(fill='x', pady=8)
    e.modo = tk.StringVar(value='sucesso')
    for texto, valor in (('Sucesso', 'sucesso'), ('Timeout/sem dados', 'timeout'), ('Descoberta', 'descoberta')):
        ttk.Radiobutton(modos, text=texto, value=valor, variable=e.modo,
                        command=e._alterar_modo).pack(side='left', padx=8)
    grade = ttk.Frame(c)
    grade.pack(fill='x')
    acoes = (
        ('Conectar', lambda: e.conexao.conectar()), ('Abrir monitor', e.abrir_monitor),
        ('Alterar peso', e.alterar_peso), ('ASSUMIR manual', e.promocao_manual),
        ('Promoção automática', e.promocao_automatica), ('Falhar promoção', e.falhar_promocao),
        ('Operação longa / B2', e.operacao_longa), ('Reabrir execução', e.reabrir),
        ('Alternar saúde PRINCIPAL', e.alternar_saude_ap), ('CLIENTE conectado', e.simular_ct_conectado),
        ('CLIENTE sem comunicação', e.simular_ct_sem_comunicacao), ('PRINCIPAL encerrado', e.simular_ap_encerrado))
    for i, (texto, acao) in enumerate(acoes):
        ttk.Button(grade, text=texto, command=acao).grid(row=i // 2, column=i % 2,
                                                     sticky='ew', padx=4, pady=5)
    grade.columnconfigure((0, 1), weight=1)
    ttk.Label(c, text='Feche o monitor para testar CANCELAR/NÃO/SIM. Operação longa: '
              'B2 pode expirar em 10 s; worker liberado 3 s depois.', wraplength=780).pack(anchor='w', pady=12)
    tcp = paginas['TCP local']
    ttk.Label(tcp, text='Fonte simulada: nenhum socket é aberto. Selecione TCP na conexão e clique Conectar.\n'
              'Somente peso; não se inventam mínimo, máximo, divisão ou tara.', wraplength=760).pack(anchor='w', pady=10)
    for texto, acao in (('Avançar 6 s sem frame', lambda: e.tcp_avancar(6)),
                        ('Avançar 11 s sem frame', lambda: e.tcp_avancar(11)),
                        ('Receber novo frame', lambda: e.tcp_avancar(None))):
        ttk.Button(tcp, text=texto, command=acao).pack(anchor='w', pady=6)
    admin = paginas['Administrador']
    ttk.Label(admin, text='Protótipo com senha própria, independente da senha da TC420.\n'
              'Primeiro acesso cadastra senha de teste. Outros acessos exigem confirmação.\n'
              'HTTP automático dispensa login após cadastro; TCP pede em cada nova abertura.\n'
              'Esqueci a senha limpa somente dados simulados. Nada persiste em disco.',
              wraplength=760).pack(anchor='w', pady=12)
    for texto, origem, acao in (
        ('Primeira configuração', 'Primeira configuração', e.mostrar_conexao),
        ('Promoção manual / ASSUMIR', 'Promoção manual', e.promocao_manual_autorizada),
        ('Reconfigurar balança', 'Reconfiguração', e.mostrar_conexao)):
        ttk.Button(admin, text=texto, command=lambda o=origem, a=acao: e.admin.pedir(o, a)).pack(anchor='w', pady=6)
    ttk.Button(admin, text='Simular nova abertura: HTTP automático',
               command=lambda: e.admin.iniciar_aplicacao('HTTPS')).pack(anchor='w', pady=6)
    ttk.Button(admin, text='Simular nova abertura: TCP',
               command=lambda: e.admin.iniciar_aplicacao('TCP')).pack(anchor='w', pady=6)
    lista = paginas['Checklist']
    itens = ('Conexão responde sem bloquear', 'Monitor mantém aparência', 'Timeout não fecha formulário',
             'ASSUMIR requer administrador no ensaio', 'Senha incorreta não libera ação',
             'TCP não usa rede real', 'Frescor TCP e retorno simulados',
             'Reconfiguração requer administrador no ensaio', 'B2 conclui ou sinaliza pendência',
             'Fechamento restaura isolamento')
    e.checks = []
    for texto in itens:
        var = tk.BooleanVar(value=False)
        e.checks.append((texto, var))
        ttk.Checkbutton(lista, text=texto, variable=var, command=e._atualizar_contagem).pack(anchor='w', pady=3)
    e.contagem = ttk.Label(lista, text='0 de 10 aprovados')
    e.contagem.pack(anchor='w', pady=8)
    log = paginas['Registro']
    barra = ttk.Scrollbar(log)
    barra.pack(side='right', fill='y')
    e.lista = tk.Listbox(log, font=('Consolas', 10), yscrollcommand=barra.set)
    e.lista.pack(fill='both', expand=True)
    barra.configure(command=e.lista.yview)
    rodape = ttk.Frame(topo)
    rodape.pack(fill='x', pady=(10, 0))
    ttk.Button(rodape, text='Copiar resultados', command=e.copiar_resultados).pack(side='left')
    ttk.Button(rodape, text='Encerrar laboratório', command=e.encerrar_harness).pack(side='right')

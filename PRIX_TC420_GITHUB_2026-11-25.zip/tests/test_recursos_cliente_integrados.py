# Testes de recursos cliente integrados: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""SUBSCRIBE real instrumentado com sockets/arquivos falsos, sem rede/Tk."""
import ast
from pathlib import Path
from types import SimpleNamespace
import threading
import unittest
from unittest.mock import MagicMock, Mock, patch

from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
from test_recursos_cliente import SocketFalso, ArquivoFalso
from apoio_conexoes_cliente import conexoes_tcp_simuladas


class SocketLeituraFalso(SocketFalso):
    def __init__(self, arquivo=None):
        super().__init__()
        self.arquivo = arquivo or ArquivoFalso()
        self.settimeout = Mock()
        self.connect = Mock()
        self.sendall = Mock()
        def receber(_tamanho):
            linha = self.arquivo.readline()
            return linha.encode("utf-8") if isinstance(linha, str) else linha
        self.recv = Mock(side_effect=receber)
        self.shutdown = Mock()
        self.makefile = Mock(return_value=self.arquivo)


# Grupo de 26 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class RecursosClienteIntegrados(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.dono = RecursosLeitorCliente(self.infra)
        self.registro = self.infra.registro_recursos

    def socket(self, dono=None):
        objeto = SocketLeituraFalso()
        return (dono or self.dono).abrir_socket(lambda: objeto), objeto

    def par(self):
        socket, objeto = self.socket()
        arquivo = socket.makefile("r", encoding="utf-8")
        return socket, arquivo, objeto

    def item(self, token):
        return next(r for r in self.registro.obter_retrato()["recursos"] if r["recurso_id"] == token.numero)

    def fechar_gate(self):
        self.registro.fechar_admissao()

    def pendente(self):
        self.assertFalse(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_01_socket_registrado(self):
        socket, _ = self.socket()
        self.assertTrue(self.item(socket.recurso_id)["publicado"])

    def test_02_makefile_registrado(self):
        socket, arquivo, objeto = self.par()
        self.assertEqual(socket.recurso_id.numero, self.item(arquivo.recurso_id)["associado_a"])
        objeto.makefile.assert_called_once_with("r", encoding="utf-8")

    def test_03_falha_comprovada_antes_da_alocacao(self):
        fabrica = Mock()
        with patch.object(self.registro, "criar", side_effect=RuntimeError()):
            with self.assertRaises(RuntimeError):
                self.dono.abrir_socket(fabrica)
        fabrica.assert_not_called()
        self.fechar_gate()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_04_falha_apos_alocacao_fecha_handle_associado(self):
        objeto = SocketLeituraFalso()
        criar = self.registro.criar

        def falhar(token, fabrica):
            return criar(token, fabrica, preparar=Mock(side_effect=ValueError()))

        with patch.object(self.registro, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.dono.abrir_socket(lambda: objeto)
        self.assertTrue(objeto.fechado)
        self.assertTrue(self.registro.obter_retrato()["recursos"][0]["erros_criacao"])

    def test_05_publicacao_falha_fica_rastreada(self):
        objeto = SocketLeituraFalso()

        def falhar(token, alocar):
            alocar()
            raise ValueError()

        with patch.object(self.registro, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.dono.abrir_socket(lambda: objeto)
        self.assertTrue(objeto.fechado)
        self.assertEqual(1, len(self.dono.obter_publicacoes_pendentes()))
        self.fechar_gate()
        self.pendente()

    def test_06_fechamento_preserva_prova(self):
        socket, _ = self.socket()
        socket.close()
        self.assertEqual("close_retornou", self.item(socket.recurso_id)["prova_fechamento"])

    def test_07_falha_close_registrada(self):
        socket, objeto = self.socket()
        objeto.erro_close = OSError()
        with self.assertRaises(OSError):
            socket.close()
        self.assertTrue(self.item(socket.recurso_id)["erros_limpeza"])

    def test_08_socket_fechado_arquivo_aberto(self):
        socket, arquivo, _ = self.par()
        socket.close()
        self.fechar_gate()
        self.pendente()
        self.assertFalse(self.item(arquivo.recurso_id)["encerramento_confirmado"])

    def test_09_arquivo_fechado_socket_aberto(self):
        socket, arquivo, _ = self.par()
        arquivo.close()
        self.fechar_gate()
        self.pendente()
        self.assertFalse(self.item(socket.recurso_id)["encerramento_confirmado"])

    def test_10_reconexao_novo_id(self):
        a, _ = self.socket()
        a.close()
        b, _ = self.socket()
        self.assertNotEqual(a.recurso_id, b.recurso_id)

    def test_11_geracao_antiga_preservada(self):
        socket, _ = self.socket()
        outro = RecursosLeitorCliente(self.infra)
        self.assertNotEqual(self.dono.geracao_id, outro.geracao_id)
        self.assertEqual(self.dono.geracao_id, self.item(socket.recurso_id)["geracao_id"])

    def test_12_promocao_nao_apaga_historico(self):
        socket, _ = self.socket()
        self.registro.promover(self.dono.geracao_id)
        self.fechar_gate()
        self.pendente()
        self.assertEqual("principal", self.item(socket.recurso_id)["modo_atual"])

    def test_13_conexoes_simultaneas_independentes(self):
        barreira = threading.Barrier(3)
        sockets, erros = [], []

        def criar():
            try:
                barreira.wait(3)
                sockets.append(self.socket()[0])
            except BaseException as erro:
                erros.append(erro)

        threads = [threading.Thread(target=criar) for _ in range(2)]
        for thread in threads:
            thread.start()
        barreira.wait(3)
        for thread in threads:
            thread.join(3)
            self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(2, len({s.recurso_id for s in sockets}))

    def test_14_repeticao_preserva_erros(self):
        socket, objeto = self.socket()
        objeto.erro_close = OSError()
        with self.assertRaises(OSError):
            socket.close()
        objeto.erro_close = None
        socket.close()
        socket.close()
        self.assertEqual(2, objeto.close_chamadas)
        self.fechar_gate()
        self.pendente()

    def executar_retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []

        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("harness")

        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)

        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_15_consulta_durante_limpeza(self):
        socket, objeto = self.socket()

        def fechar(suspender):
            objeto.close = suspender
            socket.close()

        def consultar():
            self.fechar_gate()
            self.assertTrue(self.item(socket.recurso_id)["limpeza_em_curso"])
            self.pendente()

        self.executar_retido(fechar, consultar)

    def test_16_cobertura_parcial_sempre_negativa(self):
        socket, _ = self.socket()
        socket.close()
        self.fechar_gate()
        resultado = self.infra.avaliar()
        self.assertFalse(resultado["cobertura_completa"])
        self.assertFalse(resultado["encerramento_confirmado"])

    def test_critico_A_criacao_aceita_antes_do_gate(self):
        sockets = []

        def criar(suspender):
            def fabrica():
                suspender()
                return SocketLeituraFalso()
            sockets.append(self.dono.abrir_socket(fabrica))

        def fechar():
            self.fechar_gate()
            self.pendente()

        self.executar_retido(criar, fechar)
        self.assertEqual(self.dono.geracao_id, self.item(sockets[0].recurso_id)["geracao_id"])
        sockets[0].close()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_critico_B_erro_close_tardio(self):
        socket, objeto = self.socket()

        def fechar(suspender):
            def close():
                suspender()
                raise OSError()
            objeto.close = close
            with self.assertRaises(OSError):
                socket.close()

        self.executar_retido(fechar, lambda: (self.fechar_gate(), self.pendente()))
        self.pendente()
        self.assertTrue(self.item(socket.recurso_id)["erros_limpeza"])

    def test_critico_C_makefile_independente(self):
        socket, arquivo, _ = self.par()
        socket.close()
        self.fechar_gate()
        self.pendente()
        arquivo.close()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_critico_D_antigo_pendente_nova_geracao_resolvida(self):
        antigo, arquivo, _ = self.par()
        antigo.close()
        self.registro.promover(self.dono.geracao_id)
        nova = RecursosLeitorCliente(self.infra)
        atual, _ = self.socket(nova)
        atual.close()
        self.fechar_gate()
        self.assertTrue(self.registro.obter_retrato(geracao_id=nova.geracao_id)["encerramento_confirmado"])
        self.pendente()
        arquivo.close()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_operacao_e_close_preservam_erros_separados(self):
        socket, arquivo, objeto = self.par()
        objeto.arquivo.readline = Mock(side_effect=ValueError())
        objeto.arquivo.erro_close = OSError()
        with self.assertRaises(ValueError):
            arquivo.readline()
        with self.assertRaises(OSError):
            arquivo.close()
        item = self.item(arquivo.recurso_id)
        self.assertTrue(item["erros_atendimento"])
        self.assertTrue(item["erros_limpeza"])

    def test_publicacao_e_close_falhos_guardam_handle_e_diagnostico(self):
        objeto = SocketLeituraFalso()
        objeto.erro_close = OSError()

        def falhar(token, alocar):
            alocar()
            raise ValueError()

        with patch.object(self.registro, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.dono.abrir_socket(lambda: objeto)
        self.assertEqual("falha_io", self.dono.obter_publicacoes_pendentes()[0]["erro_limpeza"])
        self.fechar_gate()
        self.pendente()

    def test_fabrica_opaca_nao_finge_ausencia(self):
        with self.assertRaises(OSError):
            self.dono.abrir_socket(Mock(side_effect=OSError()))
        self.assertEqual("desconhecido", self.registro.obter_retrato()["recursos"][0]["estado"])

    def test_gate_fechado_nao_chama_fabrica(self):
        self.fechar_gate()
        fabrica = Mock()
        with self.assertRaises(RuntimeError):
            self.dono.abrir_socket(fabrica)
        fabrica.assert_not_called()

    def test_loop_real_config_register_subscribe_registrados(self):
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente-simulado"):
            leitor = LeitorDadosServidor("principal-simulado", infraestrutura_cliente=self.infra)
        leitor.executando = True
        config, registro = SocketLeituraFalso(), SocketLeituraFalso()
        config.arquivo.readline = Mock(return_value='{}')
        registro.arquivo.readline = Mock(return_value=(
            '{"nome":"cliente-simulado","posicao":1}')
        )
        arquivo = ArquivoFalso()
        arquivo.readline = Mock(side_effect=lambda: (leitor.parar(), '')[1])
        objeto = SocketLeituraFalso(arquivo)
        with conexoes_tcp_simuladas(leitor.recursos_cliente, [config, registro]), \
                patch("rede.lerdadosserver.socket.socket", return_value=objeto):
            leitor._manter_atualizado()
        objeto.sendall.assert_called_once_with(b"SUBSCRIBE\n")
        self.assertEqual({}, leitor.configuracao)
        self.assertTrue(leitor.configuracao_pronta.is_set())
        prazos = [c.args[0] for c in objeto.settimeout.call_args_list]
        self.assertEqual(5, prazos[0])
        self.assertTrue(all(0 < prazo <= 6 for prazo in prazos[1:]))
        recursos = self.registro.obter_retrato()["recursos"]
        self.assertEqual(6, len(recursos))
        registro.sendall.assert_called_once_with(b"REGISTER|cliente-simulado\n")
        self.assertEqual(1, leitor.posicao_sucessao)
        self.assertTrue(all(r["encerramento_confirmado"] for r in recursos))
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])

    def test_leitor_interno_manual_recebe_injecao(self):
        # O caminho manual entrega seu contexto e a mesma infraestrutura ao monitor comum.
        from interface.conexao import JanelaConexao
        from interface.saida_aplicacao import SaidaAplicacao
        saida = SaidaAplicacao()
        saida.configurar(self.infra)
        from rede.servidor import ContextoCicloServidor
        contexto = ContextoCicloServidor()
        janela = SimpleNamespace(
            saida_aplicacao=saida, root=Mock(), web=object(), configuracao={},
            servidor_encerrado=threading.Event(), ao_reconfigurar=None,
            encerrar_aplicacao=Mock(), agendar_saida=Mock(),
            concluir_encerramento_confirmado=Mock(), informar_encerramento_pendente=Mock(),
            infraestrutura_cliente=self.infra, contexto_ciclo_servidor=contexto)
        with patch('interface.conexao.JanelaTC420') as fabrica:
            JanelaConexao.abrir_monitor(janela)
        self.assertIs(self.infra, janela.monitor.infraestrutura_cliente)
        janela.monitor.supervisionar_principal.assert_called_once_with(contexto)
        janela.monitor.observar_rebaixamento.assert_not_called()


if __name__ == "__main__":
    unittest.main()

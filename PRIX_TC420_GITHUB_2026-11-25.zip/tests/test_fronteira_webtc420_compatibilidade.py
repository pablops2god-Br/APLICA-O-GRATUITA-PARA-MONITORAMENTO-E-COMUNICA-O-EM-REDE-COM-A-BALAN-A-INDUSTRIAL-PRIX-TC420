# Testes de fronteira webtc420 compatibilidade: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.9: compatibilidade independente e proteção do modo acompanhado aprovado.

Todas as comunicações usam transporte falso, sem Tk/persistência reais.
"""
import ast
from contextvars import copy_context
import inspect
import json
from pathlib import Path
import threading
import unittest
from unittest.mock import Mock, patch
from uuid import uuid4

import requests

from rede import infraestrutura_cliente as modulo
from prototipos.operacoes_http_cliente import OperacaoHttpId
from tc420.web import WebTC420
from test_registro_automatico import carregar_fluxos
import test_auditoria_cobertura_http as auditoria
import test_approval_http_integrado as approval


RAIZ = Path(__file__).resolve().parents[1]


# Grupo de 33 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class FronteiraWebTC420Compatibilidade(unittest.TestCase):
    fluxo_http = approval.ApprovalHttpIntegrado.fluxo_http
    transporte = approval.ApprovalHttpIntegrado.transporte
    iniciar_thread = approval.ApprovalHttpIntegrado.iniciar_thread
    terminar = approval.ApprovalHttpIntegrado.terminar
    bloquear = approval.ApprovalHttpIntegrado.bloquear
    operacoes = approval.ApprovalHttpIntegrado.operacoes
    negativo = approval.ApprovalHttpIntegrado.negativo
    fixture_main = auditoria.AuditoriaCoberturaHttp.fixture_main
    fixture_manual = auditoria.AuditoriaCoberturaHttp.fixture_manual
    conferir_par = auditoria.AuditoriaCoberturaHttp.conferir_par

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = modulo.InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_http
        self.web = WebTC420("balanca-simulada", politica_http=self.infra.criar_politica_http())

    def autenticar(self):
        contexto = self.infra.preparar_http_inicial()
        self.infra.executar_login_automatico(self.web, "simulado", "simulado", contexto_http=contexto)
        return contexto

    def test_01_automatico_acompanhado_preserva_objeto_publico(self):
        env = carregar_fluxos()
        env["WebTC420"].return_value = self.web
        with self.fluxo_http() as adaptador:
            resultado = env["tentar_login_automatico"](infraestrutura_cliente=self.infra)
        self.assertIs(self.web, resultado["web"])
        self.conferir_par(adaptador)
        self.assertIs(self.infra, self.web.politica_http.proprietario)

    def test_02_manual_acompanhado_preserva_contrato(self):
        fixture, janela = self.fixture_manual(self.infra)
        fixture.env["WebTC420"].return_value = self.web
        fixture.env["WebTC420"].side_effect = None
        with self.fluxo_http() as adaptador:
            janela.conectar()
        self.assertIs(self.web, janela.web)
        self.assertTrue(janela.servidor_iniciado)
        self.conferir_par(adaptador)

    def test_03_promocao_acompanhada_preserva_objeto_e_origem(self):
        fixture = self.fixture_main()
        fixture.env["WebTC420"].side_effect = None
        fixture.env["WebTC420"].return_value = self.web
        fixture.iniciar_cliente(self.infra)
        with self.fluxo_http() as adaptador:
            resultado = fixture.monitores[0].ao_promover_automaticamente()
        self.assertIs(self.web, resultado["web"])
        self.assertEqual(fixture.leitores[0].recursos_cliente.geracao_id, self.operacoes()[0]["geracao_id"])
        self.conferir_par(adaptador)

    def test_04_auxiliar_no_executor_um_id_por_get(self):
        with self.fluxo_http() as adaptador:
            contexto = self.autenticar()
            self.assertEqual(approval.CONFIGURACAO, self.infra.executar_approval(contexto, self.web))
        self.conferir_par(adaptador)
        self.assertEqual(2, len(self.operacoes()))

    def test_05_mesma_instancia_apos_executor_recusa_get_cru(self):
        with self.fluxo_http() as adaptador:
            self.autenticar()
            antes = self.registro.obter_retrato()
            with self.assertRaisesRegex(RuntimeError, "http_fora_do_executor"):
                self.web.obter_configuracao()
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual(antes, self.registro.obter_retrato())
        self.assertEqual(["login"], [o["operacao"] for o in self.operacoes()])

    def test_06_gate_fechado_recusa_executor_e_api_crua(self):
        with self.fluxo_http() as adaptador:
            contexto = self.autenticar()
            self.registro.fechar_admissao()
            with self.assertRaisesRegex(RuntimeError, "admissao_operacao_http_recusada"):
                self.infra.executar_approval(contexto, self.web)
            self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
            with self.assertRaisesRegex(RuntimeError, "http_fora_do_executor"):
                self.web.approval()
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual(["login"], [o["operacao"] for o in self.operacoes()])
        self.negativo()

    def test_07_identidade_invalida_recusada_no_executor(self):
        with self.fluxo_http() as adaptador:
            self.autenticar()
            for identidade in (None, object(), OperacaoHttpId(object(), 1)):
                with self.subTest(tipo=type(identidade).__name__), self.assertRaises(ValueError):
                    self.registro.executar(identidade, self.web.obter_configuracao)
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])

    def test_08_identidade_de_outro_dono_recusada(self):
        outra = modulo.InfraestruturaRegistrosCliente()
        contexto = outra.preparar_http_inicial()
        identidade = outra.registro_http.admitir(contexto, "approval")
        with self.fluxo_http() as adaptador:
            self.autenticar()
            with self.assertRaises(ValueError):
                self.registro.executar(identidade, self.web.obter_configuracao)
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])

    def test_09_identidade_concluida_nao_reexecuta_no_registro(self):
        with self.fluxo_http() as adaptador:
            contexto = self.autenticar()
            identidades = []
            admitir = self.registro.admitir
            def guardar(ctx, tipo):
                identidade = admitir(ctx, tipo)
                identidades.append(identidade)
                return identidade
            with patch.object(self.registro, "admitir", side_effect=guardar):
                self.infra.executar_approval(contexto, self.web)
            identidade = identidades[0]
            with self.assertRaisesRegex(RuntimeError, "operacao_nao_iniciavel"):
                self.registro.executar(identidade, self.web.obter_configuracao)
        self.assertEqual(["POST", "GET"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual(2, len(self.operacoes()))

    def test_10_post_falho_nao_chega_a_approval(self):
        env = carregar_fluxos()
        env["WebTC420"].return_value = self.web
        with self.transporte(status=401) as adaptador:
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual(["login"], [o["operacao"] for o in self.operacoes()])

    def test_11_timeout_original_independente_e_acompanhado(self):
        contexto = self.infra.preparar_http_inicial()
        self.web.token = "simulado"
        original = requests.Timeout("simulada")
        independente = WebTC420("independente-simulada")
        independente.token = "simulado"
        for chamada in (independente.obter_configuracao, lambda: self.infra.executar_approval(contexto, self.web)):
            with self.transporte(erro=original):
                with self.assertRaises(requests.Timeout) as capturado:
                    chamada()
            self.assertIs(original, capturado.exception)
        self.assertEqual(1, len(self.operacoes()))

    def test_12_http_erro_preserva_response_e_recusa(self):
        contexto = self.infra.preparar_http_inicial()
        self.web.token = "simulado"
        with self.transporte(status=503) as adaptador:
            with self.assertRaises(requests.HTTPError) as capturado:
                self.infra.executar_approval(contexto, self.web)
        self.assertIs(adaptador.resposta, capturado.exception.response)
        with self.transporte(b"FAILURE:APPROVAL:simulado"):
            with self.assertRaisesRegex(RuntimeError, "Approval recusado pela TC420"):
                self.infra.executar_approval(contexto, self.web)
        self.assertTrue(all(o["resultado"] == "falha" and o["execucao_resolvida"] for o in self.operacoes()))

    def test_13_consumidor_independente_tem_contrato_sem_registro(self):
        independente = WebTC420("independente-simulada")
        with self.fluxo_http() as adaptador:
            self.assertEqual("simulado", independente.login("simulado", "simulado"))
            self.assertEqual(approval.CONFIGURACAO, independente.obter_configuracao())
        self.assertEqual(["POST", "GET"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual([], self.operacoes())
        self.assertEqual({"ip", "url", "token"}, set(vars(independente)))

    def test_14_origem_durante_promocao_preservada(self):
        dono = modulo.RecursosLeitorCliente(self.infra)
        contexto = self.infra.preparar_http_promocao(dono)
        self.web.token = "simulado"
        entrou, liberar = threading.Event(), threading.Event()
        with self.transporte(antes=lambda: self.bloquear(entrou, liberar)):
            tarefa = self.iniciar_thread(lambda: self.infra.executar_approval(contexto, self.web))
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.operacoes()[0]
                self.registro.promover(dono.geracao_id)
                novo = modulo.RecursosLeitorCliente(self.infra)
                self.assertNotEqual(dono.geracao_id, novo.geracao_id)
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual(([approval.CONFIGURACAO], []), (resultados, erros))
        depois = self.operacoes()[0]
        for campo in ("operacao_id", "geracao_id", "atividade_id"):
            self.assertEqual(antes[campo], depois[campo])

    def test_15_critica_d_reuso_e_bypass_bloqueados_durante_publicacao(self):
        contexto = self.infra.preparar_http_inicial()
        self.web.token = "simulado"
        identidades = []
        admitir = self.registro.admitir
        def guardar(ctx, tipo):
            identidade = admitir(ctx, tipo)
            identidades.append(identidade)
            return identidade
        entrou, liberar = threading.Event(), threading.Event()
        publicar = self.registro.publicar
        def atrasar(op, recibo):
            self.bloquear(entrou, liberar)
            return publicar(op, recibo)
        with self.transporte() as adaptador, patch.object(self.registro, "publicar", side_effect=atrasar), \
                patch.object(self.registro, "admitir", side_effect=guardar):
            tarefa = self.iniciar_thread(lambda: self.infra.executar_approval(contexto, self.web))
            try:
                self.assertTrue(entrou.wait(3))
                with self.assertRaisesRegex(RuntimeError, "operacao_nao_iniciavel"):
                    self.registro.executar(identidades[0], self.web.obter_configuracao)
                self.assertEqual(1, len(adaptador.enviados))
                with self.assertRaisesRegex(RuntimeError, "http_fora_do_executor"):
                    self.web.obter_configuracao()
                self.assertEqual(1, len(adaptador.enviados))
                self.assertEqual(1, len(self.operacoes()))
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
                self.negativo()
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual(([approval.CONFIGURACAO], []), (resultados, erros))
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_16_global_negativo_com_gate_fechado(self):
        with self.fluxo_http():
            contexto = self.autenticar()
            self.infra.executar_approval(contexto, self.web)
        self.registro.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_17_critica_a_chamada_crua_concorrente_ao_gate_bloqueada(self):
        with self.fluxo_http() as adaptador:
            self.autenticar()
            entrou, liberar = threading.Event(), threading.Event()
            approval_original = self.web.approval
            def auxiliar():
                self.bloquear(entrou, liberar)
                return approval_original()
            tarefa = self.iniciar_thread(auxiliar)
            try:
                self.assertTrue(entrou.wait(3))
                self.registro.fechar_admissao()
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        self.assertEqual(1, len(erros))
        self.assertEqual("http_fora_do_executor", str(erros[0]))
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual(["login"], [o["operacao"] for o in self.operacoes()])

    def test_18_critica_b_executor_auxiliar_sem_duplicar_reserva(self):
        contexto = self.infra.preparar_http_inicial()
        self.web.token = "simulado"
        entrou, liberar = threading.Event(), threading.Event()
        with self.transporte(antes=lambda: self.bloquear(entrou, liberar)) as adaptador:
            tarefa = self.iniciar_thread(lambda: self.infra.executar_approval(contexto, self.web))
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual(1, len(adaptador.enviados))
                self.assertEqual(1, len(self.operacoes()))
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertEqual(1, len(self.operacoes()))

    def test_19_consumidores_operacionais_e_diagnostico_localizados(self):
        encontrados = {}
        for p in auditoria.fontes_operacionais():
            arvore = ast.parse(p.read_text(encoding="utf-8"))
            quantidade = sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                             and n.func.id == "WebTC420" for n in ast.walk(arvore))
            if quantidade:
                encontrados[p.relative_to(RAIZ).as_posix()] = quantidade
        self.assertEqual({"main.py": 2, "interface/conexao.py": 1,
                          "rede/promocao_manual.py": 1, "teste_approval.py": 1}, encontrados)
        self.assertEqual([
            ("tc420/web.py", "WebTC420.approval", "requests.get"),
            ("tc420/web.py", "WebTC420.login", "requests.post"),
            ("tc420/web.py", "WebTC420.refresh", "requests.get"),
        ], auditoria.inventario_http())

    def test_20_assinatura_aditiva_opcional_sem_id_publico(self):
        for metodo, parametros in (
                (WebTC420.__init__, ["self", "ip", "politica_http"]),
                (WebTC420.login, ["self", "usuario", "senha"]),
                (WebTC420.approval, ["self", "escala"]),
                (WebTC420.obter_configuracao, ["self", "escala"]),
                (WebTC420.refresh, ["self", "escala"]),
                (WebTC420.obter_estado, ["self", "escala"])):
            self.assertEqual(parametros, list(inspect.signature(metodo).parameters))
        self.assertEqual(1, inspect.signature(WebTC420.approval).parameters["escala"].default)
        politica = inspect.signature(WebTC420.__init__).parameters["politica_http"]
        self.assertIsNone(politica.default)
        self.assertEqual(inspect.Parameter.KEYWORD_ONLY, politica.kind)

    def test_21_fronteira_nao_acrescenta_exposicao_no_retrato(self):
        contexto = self.infra.preparar_http_inicial()
        token = uuid4().hex
        self.web.token = token
        original = requests.HTTPError(token)
        with self.transporte(erro=original):
            with self.assertRaises(requests.HTTPError) as capturado:
                self.infra.executar_approval(contexto, self.web)
        self.assertIs(original, capturado.exception)
        self.assertTrue(token not in json.dumps(self.registro.obter_retrato()))
        self.assertTrue(self.operacoes()[0]["erros_execucao"])

    def test_22_principal_e_ferramenta_nao_sao_cliente(self):
        arvore = ast.parse((RAIZ / "rede/servidor.py").read_text(encoding="utf-8"))
        funcao = next(n for n in ast.walk(arvore) if isinstance(n, ast.FunctionDef) and n.name == "ler_tc420")
        metodos = [n.func.attr for n in ast.walk(funcao) if isinstance(n, ast.Call)
                   and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
                   and n.func.value.id == "web"]
        self.assertEqual(["obter_estado"], metodos)
        script = ast.parse((RAIZ / "teste_approval.py").read_text(encoding="utf-8"))
        metodos_script = {n.func.attr for n in ast.walk(script) if isinstance(n, ast.Call)
                          and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
                          and n.func.value.id == "web"}
        self.assertEqual({"login", "approval", "interpretar_approval", "refresh", "interpretar_refresh"}, metodos_script)

    def test_23_operacao_aceita_antes_do_gate_pode_concluir(self):
        contexto = self.infra.preparar_http_inicial()
        self.web.token = "simulado"
        iniciar = self.registro._iniciar
        def fechar_antes_partida(op, gerenciada):
            self.registro.fechar_admissao()
            return iniciar(op, gerenciada)
        with self.transporte(), patch.object(self.registro, "_iniciar", side_effect=fechar_antes_partida):
            resultado = self.infra.executar_approval(contexto, self.web)
        self.assertEqual(approval.CONFIGURACAO, resultado)
        self.assertTrue(self.registro.obter_retrato()["admissao_fechada"])
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_24_principal_refresh_nao_cria_registro_cliente(self):
        self.web.token = "simulado"
        with self.transporte(b"SUCCESS:REFRESH:simulado") as adaptador:
            self.assertEqual("simulado", self.web.refresh())
        self.assertEqual(1, len(adaptador.enviados))
        self.assertEqual([], self.operacoes())

    def test_25_tres_construcoes_operacionais_entregam_vinculo_real(self):
        for caminho in ("automatico", "manual", "promocao"):
            with self.subTest(caminho=caminho):
                inicio = len(self.operacoes())
                webs = []
                def construir(ip, **kwargs):
                    web = WebTC420(ip, **kwargs)
                    webs.append(web)
                    return web
                with self.fluxo_http() as adaptador:
                    if caminho == "automatico":
                        env = carregar_fluxos()
                        env["WebTC420"].side_effect = construir
                        self.assertTrue(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
                    elif caminho == "manual":
                        fixture, janela = self.fixture_manual(self.infra)
                        fixture.env["WebTC420"].side_effect = construir
                        janela.conectar()
                        self.assertTrue(janela.servidor_iniciado)
                    else:
                        fixture = self.fixture_main()
                        fixture.env["WebTC420"].side_effect = construir
                        fixture.iniciar_cliente(self.infra)
                        self.assertIsNotNone(fixture.monitores[0].ao_promover_automaticamente())
                self.assertEqual(1, len(webs))
                self.assertIs(self.infra, webs[0].politica_http.proprietario)
                self.assertEqual(["POST", "GET"], [r.method for r, _ in adaptador.enviados])
                self.assertEqual(["login", "approval"], [o["operacao"] for o in self.operacoes()[inicio:]])
                with patch("requests.api.request") as enviar:
                    with self.assertRaisesRegex(RuntimeError, "http_fora_do_executor"):
                        webs[0].obter_configuracao()
                enviar.assert_not_called()

    def test_26_dono_estrangeiro_nao_concede_autorizacao(self):
        outra = modulo.InfraestruturaRegistrosCliente()
        contexto = outra.preparar_http_inicial()
        self.web.token = "simulado"
        with self.transporte() as adaptador:
            with self.assertRaisesRegex(ValueError, "politica_http_de_outro_proprietario"):
                outra.executar_approval(contexto, self.web)
        self.assertEqual([], adaptador.enviados)
        self.assertEqual([], outra.registro_http.obter_retrato()["operacoes"])
        self.assertEqual([], self.operacoes())

    def test_27_permissao_de_uso_unico_mesmo_dentro_do_callback(self):
        self.web.token = "simulado"
        contexto = self.infra.preparar_http_inicial()
        obter = self.web.obter_configuracao
        def duplicar():
            resultado = obter()
            with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                obter()
            return resultado
        with self.transporte() as adaptador, patch.object(self.web, "obter_configuracao", side_effect=duplicar):
            self.assertEqual(approval.CONFIGURACAO, self.infra.executar_approval(contexto, self.web))
        self.assertEqual(1, len(adaptador.enviados))
        self.assertEqual(1, len(self.operacoes()))
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_28_outro_objeto_e_tipo_nao_aproveitam_permissao(self):
        self.web.token = "simulado"
        outra_web = WebTC420("outra-simulada", politica_http=self.web.politica_http)
        outra_web.token = "simulado"
        contexto = self.infra.preparar_http_inicial()
        obter = self.web.obter_configuracao
        def tentar_desviar():
            with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                outra_web.approval()
            with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                self.web.login("simulado", "simulado")
            return obter()
        with self.transporte() as adaptador, patch.object(self.web, "obter_configuracao", side_effect=tentar_desviar):
            self.infra.executar_approval(contexto, self.web)
        self.assertEqual(["GET"], [r.method for r, _ in adaptador.enviados])

    def test_29_contexto_copiado_nao_transfere_permissao_para_thread(self):
        self.web.token = "simulado"
        contexto = self.infra.preparar_http_inicial()
        obter = self.web.obter_configuracao
        erros = []
        def tentar_em_outra_thread():
            copia = copy_context()
            def indevido():
                try:
                    copia.run(self.web.approval)
                except BaseException as erro:
                    erros.append(erro)
            thread = threading.Thread(target=indevido, daemon=True)
            thread.start()
            thread.join(3)
            self.assertFalse(thread.is_alive())
            return obter()
        with self.transporte() as adaptador, patch.object(self.web, "obter_configuracao", side_effect=tentar_em_outra_thread):
            self.infra.executar_approval(contexto, self.web)
        self.assertEqual(1, len(erros))
        self.assertEqual("autorizacao_http_invalida", str(erros[0]))
        self.assertEqual(1, len(adaptador.enviados))

    def test_30_contexto_copiado_nao_reusa_permissao_apos_retorno(self):
        self.web.token = "simulado"
        contexto = self.infra.preparar_http_inicial()
        obter = self.web.obter_configuracao
        copias = []
        def copiar():
            copias.append(copy_context())
            return obter()
        with self.transporte() as adaptador, patch.object(self.web, "obter_configuracao", side_effect=copiar):
            self.infra.executar_approval(contexto, self.web)
            with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                copias[0].run(self.web.approval)
        self.assertEqual(1, len(adaptador.enviados))
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_31_execucoes_paralelas_no_mesmo_vinculo_sao_isoladas(self):
        self.web.token = "simulado"
        contexto = self.infra.preparar_http_inicial()
        barreira = threading.Barrier(2)
        def enviar(*args, **kwargs):
            barreira.wait(3)
            self.assertEqual(2, len(self.operacoes()))
            self.assertTrue(all(not o["execucao_resolvida"] for o in self.operacoes()))
            barreira.wait(3)
            return Mock(text=approval.APROVACAO.decode())
        with patch("tc420.web.requests.get", side_effect=enviar) as get:
            a = self.iniciar_thread(lambda: self.infra.executar_approval(contexto, self.web))
            b = self.iniciar_thread(lambda: self.infra.executar_approval(contexto, self.web))
            ra, ea = self.terminar(a)
            rb, eb = self.terminar(b)
        self.assertEqual(([approval.CONFIGURACAO], [], [approval.CONFIGURACAO], []), (ra, ea, rb, eb))
        self.assertEqual(2, get.call_count)
        self.assertEqual(2, len({o["operacao_id"] for o in self.operacoes()}))

    def test_32_vinculo_publico_readonly_e_politica_invalida_recusada(self):
        with self.assertRaises(AttributeError):
            self.web.politica_http = None
        with self.assertRaisesRegex(TypeError, "politica_http_invalida"):
            WebTC420("simulada", politica_http=object())
        with patch("requests.api.request") as enviar:
            with self.assertRaisesRegex(RuntimeError, "http_fora_do_executor"):
                self.web.login("simulado", "simulado")
        enviar.assert_not_called()

    def test_33_id_valido_sozinho_nao_concede_permissao_da_fronteira(self):
        self.web.token = "simulado"
        contexto = self.infra.preparar_http_inicial()
        identidade = self.registro.admitir(contexto, "approval")
        with self.transporte() as adaptador:
            with self.assertRaisesRegex(RuntimeError, "http_fora_do_executor"):
                self.registro.executar(identidade, self.web.obter_configuracao)
            self.assertEqual([], adaptador.enviados)
            self.assertEqual(approval.CONFIGURACAO, self.infra.executar_approval(contexto, self.web))
        self.assertEqual(1, len(adaptador.enviados))
        self.assertEqual(["falha", "retorno"], [o["resultado"] for o in self.operacoes()])
        self.assertEqual(2, len({o["operacao_id"] for o in self.operacoes()}))


if __name__ == "__main__":
    unittest.main()

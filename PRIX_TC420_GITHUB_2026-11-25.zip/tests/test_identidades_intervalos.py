"""Propriedades do protótipo 2B.6, sem rede ou equipamento."""
from dataclasses import replace
import gc
import random
import threading
import unittest
import weakref

from rede import servidor as s
from prototipos.identidades_intervalos import RegistroIntervalosExperimental
from test_guarda_sockets_integrada import SocketFalso


class IdentidadesIntervalos(unittest.TestCase):
    def setUp(self):
        self.r = RegistroIntervalosExperimental()

    def resolver(self, t):
        self.assertTrue(self.r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True))

    def test_original_fabricado_outro_dono_e_ciclo(self):
        t = self.r.reservar_criacao_socket()
        self.resolver(t)
        self.assertTrue(self.r.fechar_socket(t))
        for falso in (replace(t), replace(t, ciclo_id=99), s.RegistroTrabalhadores().reservar_criacao_socket()):
            self.assertFalse(self.r.fechar_socket(falso))
            self.assertFalse(self.r.publicar_limpeza_handler(falso))

    def test_gc_nao_autentica_token_com_mesmo_id(self):
        t = self.r.reservar_criacao_socket()
        falso = replace(t)
        ref = weakref.ref(t)
        self.resolver(t)
        del t
        gc.collect()
        self.assertIsNone(ref())
        self.assertEqual(len(self.r._reservas_socket.identidades), 0)
        self.assertFalse(self.r.fechar_socket(falso))
        self.assertEqual(self.r.obter_situacao()['criacoes_socket'][0]['estado'], 'sem_recurso')

    def test_gc_nunca_remove_pendencia(self):
        t = self.r.reservar_criacao_socket()
        ref = weakref.ref(t)
        del t
        gc.collect()
        self.assertIsNotNone(ref())
        self.r.bloquear_criacao()
        self.assertFalse(self.r.encerramento_confirmado())
        self.assertEqual(len(self.r._reservas_socket.fortes), 1)

    def test_merge_fora_de_ordem_e_diagnostico_equivalente(self):
        atual = s.RegistroTrabalhadores()
        a = [atual.reservar_criacao_socket() for _ in range(200)]
        b = [self.r.reservar_criacao_socket() for _ in range(200)]
        ordem = list(range(200))
        random.Random(42).shuffle(ordem)
        for i in ordem:
            atual.resolver_falha_criacao_socket(a[i], sem_alocacao_comprovada=True)
            self.resolver(b[i])
        self.assertEqual(self.r.obter_situacao(), atual.obter_situacao())
        self.assertEqual(len(self.r._reservas_socket.intervalos), 1)

    def test_fragmentacao_preserva_incerta_e_erros(self):
        for i in range(100):
            t = self.r.reservar_criacao_socket()
            if i % 2:
                self.r.resolver_falha_criacao_socket(t)
            else:
                self.resolver(t)
        self.assertEqual(len(self.r._reservas_socket.intervalos), 50)
        self.assertEqual(len(self.r._reservas_socket.fortes), 50)
        self.r.bloquear_criacao()
        self.assertFalse(self.r.encerramento_confirmado())

    def test_repeticao_limpeza_e_publicacao_tardia(self):
        t = self.r.reservar_criacao_socket()
        self.resolver(t)
        for _ in range(3):
            self.assertTrue(self.r.fechar_socket(t))
            self.assertFalse(self.r.publicar_limpeza_handler(t))
            self.assertFalse(self.r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True))
        self.r.limpar_sockets()
        self.assertTrue(self.r.encerramento_confirmado())

    def test_close_bloqueado_e_publicacao_handler(self):
        t = self.r.reservar_criacao_socket()
        sock = SocketFalso()
        self.r.anexar_socket(t, sock)
        self.r.publicar_socket(t)
        self.r.iniciar_limpeza_handler(t)
        self.r.encerrar_uso_socket(t)
        self.assertFalse(self.r.fechar_socket(t))
        self.assertEqual(len(self.r._reservas_socket.fortes), 1)
        self.r.publicar_limpeza_handler(t)
        entrou, liberar = threading.Event(), threading.Event()
        original = sock.close
        def close():
            entrou.set()
            if not liberar.wait(5):
                raise RuntimeError('prazo do teste')
            original()
        sock.close = close
        resultados = []
        worker = threading.Thread(target=lambda: resultados.append(self.r.fechar_socket(t)))
        worker.start()
        try:
            self.assertTrue(entrou.wait(5))
            self.r.bloquear_criacao()
            self.assertFalse(self.r.encerramento_confirmado())
            self.assertFalse(self.r.fechar_socket(t))
            self.assertIs(self.r._reservas_socket[t.criacao_id].recurso, sock)
        finally:
            liberar.set()
            worker.join(5)
        self.assertFalse(worker.is_alive())
        self.assertEqual(resultados, [True])
        self.assertTrue(self.r.publicar_limpeza_handler(t))
        self.assertTrue(self.r.encerramento_confirmado())

    def test_gc_e_resolucao_concorrentes(self):
        erros = []
        barreira = threading.Barrier(5)
        def produtor():
            try:
                barreira.wait(5)
                for _ in range(300):
                    t = self.r.reservar_criacao_socket()
                    self.resolver(t)
                    self.assertTrue(self.r.fechar_socket(t))
                    if t.criacao_id % 50 == 0:
                        gc.collect()
            except BaseException as e:
                erros.append(e)
        def observador():
            try:
                barreira.wait(5)
                for _ in range(30):
                    retrato = self.r.obter_situacao()['criacoes_socket']
                    self.assertEqual([e['criacao_id'] for e in retrato], list(range(1, len(retrato)+1)))
                    gc.collect()
            except BaseException as e:
                erros.append(e)
        workers = [threading.Thread(target=produtor) for _ in range(4)]
        workers.append(threading.Thread(target=observador))
        for w in workers:
            w.start()
        for w in workers:
            w.join(10)
            self.assertFalse(w.is_alive())
        self.assertEqual(erros, [])
        gc.collect()
        self.assertEqual(len(self.r._reservas_socket), 1200)
        self.assertEqual(len(self.r._reservas_socket.identidades), 0)
        self.assertEqual(len(self.r._reservas_socket.fortes), 0)
        self.assertEqual(len(self.r._reservas_socket.intervalos), 1)


if __name__ == '__main__':
    unittest.main()

"""Etapa 1: ciclos, registros e threads reais; transporte e Tk controlados."""
from threading import Event, Thread, get_ident
from unittest.mock import Mock, patch
import unittest

from interface.janela import JanelaTC420
from interface.saida_aplicacao import SaidaAplicacao
from rede import servidor
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.lerdadosserver import LeitorDadosServidor
from rede.supervisao_principal import SupervisaoPrincipal
from test_interface_b3 import Raiz


def amostra(peso):
    return dict(estado='00', peso_liquido=peso, peso_bruto=peso, tara='0',
                unidade='kg', multirange='1')


class SupervisaoPrincipalTestes(unittest.TestCase):
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = servidor.RegistroTentativasAplicacao()
        self.saida = SaidaAplicacao(prazo=.5, intervalo=.005)
        self.saida.configurar(self.infra, self.registro)
        self.pedir_saida = self.saida.vincular('monitor')
        self.controle = servidor.ControleCicloServidor()
        self.eventos, self.threads, self.supervisoes, self.leitores = [], [], [], []
        self.patch_controle = patch.object(servidor, 'controle_ciclo_servidor', self.controle)
        self.patch_controle.start()
        self.addCleanup(self.patch_controle.stop)
        self.patch_leitor = patch('rede.supervisao_principal.LeitorDadosServidor', side_effect=self.criar_leitor)
        self.fabrica = self.patch_leitor.start()
        self.addCleanup(self.patch_leitor.stop)
        self.addCleanup(self.limpar)

    def limpar(self):
        self.saida._parada.set()
        for supervisao in self.supervisoes:
            supervisao.cancelar()
        for evento in self.eventos:
            evento.set()
        for leitor in self.leitores:
            leitor.parar()
        for item in self.saida._threads:
            thread = item['thread']
            if thread.ident is not None:
                thread.join(2)
                self.assertFalse(thread.is_alive())
        for thread in self.threads:
            thread.join(2)
            self.assertFalse(thread.is_alive())
        if self.saida._coordenacao is not None:
            self.saida._coordenacao.join(2)

    def criar_leitor(self, **kwargs):
        # Mantém todo o acompanhamento real; apenas a rotina de transporte é substituída.
        leitor = LeitorDadosServidor(**kwargs)
        leitor._manter_atualizado = lambda: leitor._parada.wait(3)
        self.leitores.append(leitor)
        return leitor

    def ciclo(self, com_trabalhador=False):
        contexto = servidor.ContextoCicloServidor()
        trabalhadores = servidor.RegistroTrabalhadores()
        self.assertTrue(self.controle.tentar_iniciar(trabalhadores))
        contexto.registrar_reserva(trabalhadores.ciclo_id)
        self.saida.acompanhar_contexto(contexto)
        liberar = Event()
        self.eventos.append(liberar)
        if com_trabalhador:
            entrou = Event()
            thread = Thread(target=lambda: (entrou.set(), liberar.wait(3)), daemon=True)
            trabalhadores.registrar_e_iniciar(thread)
            self.threads.append(thread)
            self.assertTrue(entrou.wait(1))
        return contexto, trabalhadores, liberar

    def retornar(self, contexto, trabalhadores):
        trabalhadores.bloquear_criacao()
        self.controle.finalizar(trabalhadores)
        contexto.registrar_retorno_coordenador()

    def iniciar(self, contexto):
        supervisao = SupervisaoPrincipal(contexto, self.saida, self.infra, intervalo=.005)
        self.supervisoes.append(supervisao)
        self.assertTrue(supervisao.iniciar())
        return supervisao

    def monitor(self):
        janela = JanelaTC420.__new__(JanelaTC420)
        root = Raiz()
        root.title = lambda *_args: root.usar()
        vars(janela).update(
            root=root, saida_aplicacao=self.saida, infraestrutura_cliente=self.infra,
            executando=True, fonte_dados=lambda: amostra('12'),
            comunicacao_atual=lambda: False, comunicacao_confirmada=False,
            modo_monitor='cliente', obter_saude_principal=None, servidor_encerrado=None,
            contextos_promocao=[], contexto_promocao_atual=None,
            _supervisao_principal=None, _contextos_supervisionados=[],
            candidatura_liberada=None, candidatura_detectada=False,
            estado_candidatura=None, janela_promocao=None,
            label_estado=Mock(), label_peso=Mock(), label_tara=Mock(),
            label_unidade=Mock(), label_faixa=Mock(), img_zero=object(), img_estavel=object(),
            botao_copiar_peso=Mock(), botao_copiar_tara=Mock(), _sincronizar_status=Mock(),
            labels_configuracao={faixa: {n: Mock() for n in ('max', 'min', 'divisao')}
                                for faixa in ('W1.1', 'W1.2')})
        return janela

    def pulsar(self, janela):
        # Somente a thread do ensaio executa os callbacks da interface.
        for identidade, callback in list(janela.root.callbacks.items()):
            janela.root.callbacks.pop(identidade, None)
            callback()

    def test_retorno_nao_basta_enquanto_trabalhador_vivo(self):
        contexto, registro, liberar = self.ciclo(com_trabalhador=True)
        self.retornar(contexto, registro)
        consultou = Event()
        avaliar = servidor.avaliar_encerramento_tentativa
        def consultar(ctx):
            resultado = avaliar(ctx)
            consultou.set()
            return resultado
        with patch('rede.supervisao_principal.avaliar_encerramento_tentativa', side_effect=consultar):
            supervisao = self.iniciar(contexto)
            self.assertTrue(consultou.wait(1))
            self.fabrica.assert_not_called()
            liberar.set()
            self.threads[-1].join(1)
            self.assertTrue(supervisao.pronto.wait(1))
        self.assertIs(self.infra, self.leitores[0].infraestrutura_cliente)
        self.assertFalse(self.leitores[0].permitir_candidatura)

    def test_tentativa_sem_ciclo_nao_cria_leitor(self):
        contexto = servidor.ContextoCicloServidor()
        contexto.registrar_falha('reserva_recusada')
        supervisao = self.iniciar(contexto)
        self.assertTrue(supervisao.terminou.wait(1))
        self.fabrica.assert_not_called()

    def test_socket_pendente_impede_recuperacao_ate_resolucao_comprovada(self):
        contexto, registro, _ = self.ciclo()
        reserva = registro.reservar_criacao_socket()
        self.retornar(contexto, registro)
        consultou = Event()
        avaliar = servidor.avaliar_encerramento_tentativa
        def consultar(ctx):
            resultado = avaliar(ctx)
            consultou.set()
            return resultado
        with patch('rede.supervisao_principal.avaliar_encerramento_tentativa', side_effect=consultar):
            supervisao = self.iniciar(contexto)
            self.assertTrue(consultou.wait(1))
            self.fabrica.assert_not_called()
            registro.resolver_falha_criacao_socket(reserva, sem_alocacao_comprovada=True)
            self.assertTrue(supervisao.pronto.wait(1))

    def test_refresh_da_troca_de_fonte_nao_cria_segundo_loop(self):
        janela = self.monitor()
        janela._agendar = Mock()
        janela.atualizar_refresh_web(reagendar=False)
        janela._agendar.assert_not_called()

    def test_saida_voluntaria_nao_dispara_recuperacao(self):
        contexto, registro, _ = self.ciclo()
        supervisao = self.iniciar(contexto)
        self.pedir_saida()
        self.retornar(contexto, registro)
        self.assertTrue(supervisao.terminou.wait(1))
        self.fabrica.assert_not_called()
        self.saida._coordenacao.join(2)
        self.assertTrue(self.saida.obter_situacao()['parada_operacional_confirmada'])

    def test_uma_unica_partida_por_supervisao(self):
        contexto, registro, _ = self.ciclo()
        self.retornar(contexto, registro)
        supervisao = self.iniciar(contexto)
        self.assertFalse(supervisao.iniciar())
        self.assertTrue(supervisao.pronto.wait(1))
        self.assertEqual(1, self.fabrica.call_count)

    def test_evento_sem_prova_de_limpeza_nao_dispara_recuperacao(self):
        contexto, registro, _ = self.ciclo()
        registro.registrar_erro_limpeza('falha-simulada')
        self.retornar(contexto, registro)
        consultou = Event()
        avaliar = servidor.avaliar_encerramento_tentativa
        def consultar(ctx):
            resultado = avaliar(ctx)
            consultou.set()
            return resultado
        with patch('rede.supervisao_principal.avaliar_encerramento_tentativa', side_effect=consultar):
            supervisao = self.iniciar(contexto)
            self.assertTrue(consultou.wait(1))
            self.assertFalse(supervisao.pronto.is_set())
            self.fabrica.assert_not_called()

    def test_duas_perdas_cliente_promovido_falha_e_reconecta_no_mesmo_monitor(self):
        # A deixa de fornecer dados; B conserva a última leitura e é promovido.
        janela = self.monitor()
        identidade_monitor = id(janela)
        contexto, registro, _ = self.ciclo()
        janela.concluir_promocao(dict(
            web=object(), contexto_ciclo=contexto, configuracao={},
            fonte_dados=lambda: amostra('15'), obter_saude_principal=lambda: {'saudavel': True}))
        supervisao = janela._supervisao_principal
        self.supervisoes.append(supervisao)
        self.assertIs(supervisao, janela.supervisionar_principal(contexto))
        self.assertEqual(1, len(self.saida._threads))
        janela.atualizar_refresh_web()
        janela.label_peso.config.assert_called_with(text='15')

        # B também falha. Retorno não faz troca visual antes de amostra válida.
        self.retornar(contexto, registro)
        self.assertTrue(supervisao.pronto.wait(1))
        self.pulsar(janela)
        self.assertEqual('principal', janela.modo_monitor)
        self.assertFalse(janela.comunicacao_confirmada)
        janela.label_peso.config.assert_called_with(text='15')
        leitor = supervisao.obter_leitor()
        self.assertFalse(leitor.permitir_candidatura)
        self.assertFalse(leitor._aguardar_candidatura())
        leitor._publicar_mensagem_valida(amostra('18'), 1)
        self.pulsar(janela)
        self.assertEqual(identidade_monitor, id(janela))
        self.assertEqual('cliente', janela.modo_monitor)
        self.assertTrue(janela.comunicacao_confirmada)
        janela.label_peso.config.assert_called_with(text='18')
        self.assertEqual([], janela.root.violacoes)
        self.assertTrue(all(t == get_ident() for t in janela.root.acessos))

        self.pedir_saida()
        self.saida._coordenacao.join(2)
        self.assertTrue(self.saida.obter_situacao()['parada_operacional_confirmada'])
        self.assertFalse(leitor.thread.is_alive())
        self.assertFalse(supervisao.thread.is_alive())

    def test_callback_antigo_nao_troca_fonte_do_ciclo_novo(self):
        janela = self.monitor()
        antigo, registro, _ = self.ciclo()
        primeira = janela.supervisionar_principal(antigo)
        self.supervisoes.append(primeira)
        callbacks_antigos = list(janela.root.callbacks.values())
        self.retornar(antigo, registro)
        novo, _registro_novo, _ = self.ciclo()
        segunda = janela.supervisionar_principal(novo)
        self.supervisoes.append(segunda)
        fonte = janela.fonte_dados
        for callback in callbacks_antigos:
            callback()
        self.assertIs(fonte, janela.fonte_dados)
        self.assertIsNone(janela.supervisionar_principal(antigo))
        self.assertIs(segunda, janela._supervisao_principal)
        self.assertTrue(primeira.terminou.wait(1))

    def test_oferta_manual_no_monitor_manual_sem_candidatura_automatica(self):
        janela = self.monitor()
        janela.ao_promover = None  # Mesmo ponto de partida do login manual.
        janela.promocao_em_andamento = False
        janela.abrir_janela_promocao = Mock()
        contexto, registro, _ = self.ciclo()
        supervisao = janela.supervisionar_principal(contexto)
        self.supervisoes.append(supervisao)
        self.assertFalse(janela.solicitar_promocao_manual())

        self.retornar(contexto, registro)
        self.assertTrue(supervisao.pronto.wait(1))
        self.pulsar(janela)
        self.assertFalse(supervisao.obter_leitor().permitir_candidatura)
        janela.candidatura_liberada = None
        janela.ao_promover_automaticamente = Mock()
        janela.verificar_candidatura()
        janela.ao_promover_automaticamente.assert_not_called()
        self.assertTrue(janela.solicitar_promocao_manual())
        janela.abrir_janela_promocao.assert_called_once()
        with patch('rede.promocao_manual.promover_recuperado', return_value=None) as promover:
            janela.solicitar_promocao_manual()
            janela.ao_promover('simulado', 'simulado', 'valor-simulado')
        promover.assert_called_once_with(supervisao, 'simulado', 'simulado', 'valor-simulado')
        leitor = supervisao.obter_leitor()
        leitor._publicar_mensagem_valida(amostra('20'), 1)
        self.assertFalse(janela.solicitar_promocao_manual())
        janela.promocao_em_andamento = True
        leitor._marcar_comunicacao_indisponivel()
        self.assertFalse(janela.solicitar_promocao_manual())


    def test_retomada_aguarda_gate_da_promocao_e_nao_habilita_automatico(self):
        contexto, registro, _ = self.ciclo()
        self.retornar(contexto, registro)
        supervisao = self.iniciar(contexto)
        self.assertTrue(supervisao.pronto.wait(1))
        antigo = supervisao.obter_leitor()
        antigo.parar()
        antigo.thread.join(1)
        verificou, criou = Event(), Event()
        from rede.promocao_manual import cliente_resolvido
        def verificar(infra):
            resultado = cliente_resolvido(infra)
            verificou.set()
            return resultado
        def construir(**kwargs):
            leitor = self.criar_leitor(**kwargs)
            criou.set()
            return leitor
        self.fabrica.side_effect = construir
        with patch('rede.promocao_manual.cliente_resolvido', side_effect=verificar):
            with self.saida.promocao():
                supervisao.solicitar_retomada()
                self.assertTrue(verificou.wait(1))
                self.assertEqual(1, self.fabrica.call_count)
            self.assertTrue(criou.wait(1))
        self.assertEqual(2, self.fabrica.call_count)
        self.assertFalse(self.leitores[-1].permitir_candidatura)

    def test_cliente_recuperado_entra_na_fila_e_interface_processa_nova_candidatura(self):
        janela = self.monitor()
        janela.candidatura_detectada = False
        janela._iniciar_promocao = Mock()
        contexto, registro, _ = self.ciclo()
        supervisao = janela.supervisionar_principal(contexto)
        self.assertTrue(janela._observando_candidatura)
        quantidade = len(janela.root.callbacks)
        janela.iniciar_observacao_candidatura()
        self.assertEqual(quantidade, len(janela.root.callbacks))
        self.supervisoes.append(supervisao)
        self.retornar(contexto, registro)
        self.assertTrue(supervisao.pronto.wait(1))
        leitor = supervisao.obter_leitor()
        self.assertFalse(leitor.permitir_candidatura)
        leitor.posicao_sucessao = 1
        leitor._publicar_mensagem_valida(amostra('25'), 1)
        self.assertTrue(leitor.permitir_candidatura)
        self.pulsar(janela)
        leitor._marcar_comunicacao_indisponivel()
        with patch('rede.lerdadosserver.JANELA_SUCESSAO', 0), \
                patch('rede.lerdadosserver.buscar_servidor', return_value=None):
            self.assertTrue(leitor._aguardar_candidatura())
        janela.verificar_candidatura()
        janela._iniciar_promocao.assert_called_once_with(janela.ao_promover_automaticamente)
        with patch('rede.promocao_manual.tentar_recuperacao_automatica', return_value=False) as tentar:
            self.pulsar(janela)  # Publica o callback da geração vigente.
            self.assertFalse(janela.ao_promover_automaticamente())
        tentar.assert_called_once_with(supervisao)

    def test_cancelamento_durante_construcao_para_leitor_sem_publicar(self):
        contexto, registro, _ = self.ciclo()
        self.retornar(contexto, registro)
        entrou, liberar = Event(), Event()
        self.eventos.append(liberar)
        def construir(**kwargs):
            leitor = self.criar_leitor(**kwargs)
            entrou.set()
            liberar.wait(2)
            return leitor
        self.fabrica.side_effect = construir
        supervisao = self.iniciar(contexto)
        self.assertTrue(entrou.wait(1))
        supervisao.cancelar()
        liberar.set()
        self.assertTrue(supervisao.terminou.wait(1))
        self.assertFalse(supervisao.pronto.is_set())
        self.assertFalse(self.leitores[0].executando)

    def test_falha_ao_criar_leitor_nao_sinaliza_pronto(self):
        contexto, registro, _ = self.ciclo()
        self.retornar(contexto, registro)
        self.fabrica.side_effect = OSError('falha-simulada')
        supervisao = self.iniciar(contexto)
        self.assertTrue(supervisao.terminou.wait(1))
        self.assertFalse(supervisao.pronto.is_set())

    def test_saida_durante_construcao_aguarda_trabalho_e_nao_publica_leitor(self):
        contexto, registro, _ = self.ciclo()
        self.retornar(contexto, registro)
        entrou, liberar = Event(), Event()
        self.eventos.append(liberar)
        def construir(**kwargs):
            leitor = self.criar_leitor(**kwargs)
            entrou.set()
            liberar.wait(2)
            return leitor
        self.fabrica.side_effect = construir
        supervisao = self.iniciar(contexto)
        self.assertTrue(entrou.wait(1))
        self.pedir_saida()
        liberar.set()
        self.saida._coordenacao.join(2)
        self.assertTrue(supervisao.terminou.is_set())
        self.assertFalse(supervisao.pronto.is_set())
        self.assertFalse(self.leitores[0].executando)
        self.assertTrue(self.saida.obter_situacao()['parada_operacional_confirmada'])


if __name__ == '__main__':
    unittest.main()

"""Medição sintética reproduzível, sem rede, Tk ou credenciais.

Executar da raiz: python -B tests/medir_retencao_terminal.py
Tracemalloc mede alocações Python rastreadas, não memória total do processo.
"""
import gc
import json
from pathlib import Path
import sys
import time
import tracemalloc

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from interface.registro_terminal import _RegistroTerminal


def medir():
    registro = _RegistroTerminal()
    resultados = []
    tracemalloc.start()
    inicio = time.perf_counter()
    anterior = 0
    try:
        for total in (1000, 10000, 100000, 250000, 500000):
            for indice in range(anterior, total):
                registro.acrescentar(
                    'TC420 simulado | estado=00 | peso=12345 kg | amostra=%08d\n' % indice)
            texto = registro.obter_texto()
            caracteres, linhas = len(texto), texto.count('\n')
            del texto
            gc.collect()
            atual, pico = tracemalloc.get_traced_memory()
            resultados.append(dict(mensagens=total, caracteres_retidos=caracteres,
                                   linhas_retidas=linhas, bytes_python_atual=atual,
                                   bytes_python_pico=pico, segundos=round(time.perf_counter() - inicio, 3),
                                   **{k: v for k, v in registro.obter_situacao().items()
                                      if k not in ('caracteres_retidos', 'linhas_retidas')}))
            anterior = total
    finally:
        tracemalloc.stop()
    return resultados


if __name__ == '__main__':
    print(json.dumps(medir(), indent=2, ensure_ascii=True))

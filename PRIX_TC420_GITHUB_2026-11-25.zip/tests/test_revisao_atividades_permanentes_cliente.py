# Testes de revisao atividades permanentes cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-D3-B2-B2: registro real, threads/recursos falsos, corridas no ensaio."""
from contextlib import ExitStack
import threading
import unittest
from unittest.mock import Mock, patch

from rede.atividades_permanentes_cliente import RegistroAtividadesPermanentesCliente
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
from test_recursos_cliente_integrados import SocketLeituraFalso


class ThreadSimulada:
    def __init__(self, target, daemon=True):
        self.target, self.daemon, self.viva = target, daemon, False
        self.start = Mock(side_effect=lambda: setattr(self, 'viva', True))
        self.is_alive = Mock(side_effect=lambda: self.viva)

    def executar(self):
        self.viva = True
        try:
            return self.target()
        finally:
            self.viva = False


# Grupo de 41 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class RevisaoAtividadesPermanentesCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_atividades_permanentes
        self.recursos = RecursosLeitorCliente(self.infra)
        self.origem = self.registro.preparar_leitor(self.recursos)
        self.threads = {}

    def evidencia(self):
        r = self.infra.obter_evidencia_temporal_atividades_permanentes()
        self.assertFalse(r['dependencias_temporais_cobertas'])
        self.assertFalse(r['snapshot_atomico'])
        self.assertFalse(r['encerramento_cliente_confirmado'])
        self.assertFalse(r['encerramento_global_confirmado'])
        return r

    def revisao(self):
        return self.registro.obter_revisao()['revisao']

    def reservar(self, origem=None):
        return self.registro.reservar(origem or self.origem)

    def item(self, token):
        return next(i for i in self.evidencia()['retrato']['atividades'] if i['atividade_id'] == token.numero)

    def partir(self, token, rotina=lambda: None, imediato=False, ambiguo=False):
        def fabricar(alvo):
            t = ThreadSimulada(alvo)
            if imediato:
                t.start.side_effect = t.executar
            if ambiguo:
                t.start.side_effect = RuntimeError('start_simulado')
            self.threads[token] = t
            return t
        return self.registro.partir(token, fabricar, rotina)

    def terminar(self, token):
        self.threads[token].executar()
        self.assertTrue(self.registro.observar_termino(token))

    def tarefa(self, chamada):
        resultados, erros = [], []
        def alvo():
            try:
                resultados.append(chamada())
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=alvo)
        thread.start()
        return thread, resultados, erros

    def concluir(self, tarefa):
        tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())

    def test_01_registro_novo(self):
        r = RegistroAtividadesPermanentesCliente(self.infra).obter_evidencia_temporal()
        self.assertEqual(0, r['revisao'])
        self.assertTrue(r['confiavel'])
        self.assertEqual([], r['retrato']['atividades'])

    def test_02_primeira_reserva(self):
        antes = self.revisao()
        token = self.reservar()
        self.assertEqual(antes + 1, self.revisao())
        self.assertFalse(self.item(token)['entrada'])

    def test_03_segunda_reserva(self):
        a = self.reservar()
        antes = self.revisao()
        b = self.reservar()
        self.assertNotEqual(a, b)
        self.assertEqual(antes + 1, self.revisao())
        self.assertEqual(2, len(self.evidencia()['retrato']['atividades']))

    def test_04_partida_normal(self):
        token = self.reservar()
        antes = self.revisao()
        self.assertTrue(self.partir(token))
        self.assertGreater(self.revisao(), antes)
        self.assertTrue(self.item(token)['partida_resolvida'])
        self.assertTrue(self.item(token)['start_invocado'])

    def test_05_partida_ambigua(self):
        token = self.reservar()
        antes = self.revisao()
        with self.assertRaises(RuntimeError):
            self.partir(token, ambiguo=True)
        self.assertGreater(self.revisao(), antes)
        self.assertTrue(self.item(token)['partida_ambigua'])
        self.assertFalse(self.item(token)['ausencia_comprovada'])
        self.assertFalse(self.item(token)['termino_confirmado'])

    def test_06_entrada_publicada(self):
        token = self.reservar()
        capturas = []
        self.partir(token, lambda: capturas.append(self.evidencia()))
        antes = self.revisao()
        self.threads[token].executar()
        self.assertGreater(capturas[0]['revisao'], antes)
        item = capturas[0]['retrato']['atividades'][0]
        self.assertTrue(item['entrada'])
        self.assertFalse(item['retorno'])

    def test_07_retorno_normal(self):
        token = self.reservar()
        objeto = object()
        self.partir(token, lambda: objeto)
        antes = self.revisao()
        self.assertIs(objeto, self.threads[token].executar())
        self.assertGreater(self.revisao(), antes)
        self.assertTrue(self.item(token)['retorno'])
        self.assertFalse(self.item(token)['thread_terminada'])
        self.threads[token].is_alive.assert_not_called()

    def test_08_retorno_excepcional(self):
        token = self.reservar()
        original = OSError('operacao_simulada')
        self.partir(token, Mock(side_effect=original))
        antes = self.revisao()
        with self.assertRaises(OSError) as recebido:
            self.threads[token].executar()
        self.assertIs(original, recebido.exception)
        self.assertGreater(self.revisao(), antes)
        self.assertEqual('falha', self.item(token)['resultado_alvo'])
        self.assertTrue(self.evidencia()['confiavel'])
        self.assertFalse(self.item(token)['termino_confirmado'])

    def test_09_termino_observado(self):
        token = self.reservar()
        self.partir(token)
        self.threads[token].executar()
        antes = self.revisao()
        self.assertTrue(self.registro.observar_termino(token))
        self.assertEqual(antes + 1, self.revisao())
        self.assertTrue(self.item(token)['termino_confirmado'])

    def test_10_observacao_duplicada(self):
        token = self.reservar()
        self.partir(token)
        self.terminar(token)
        antes = self.evidencia()
        self.assertTrue(self.registro.observar_termino(token))
        self.assertEqual(antes, self.evidencia())

    def test_11_consulta_repetida_passiva(self):
        token = self.reservar()
        self.partir(token)
        antes = self.evidencia()
        with ExitStack() as pilha:
            for obj, nome in ((self.registro, '_avancar_revisao'), (self.registro, 'observar_termino'),
                              (self.registro, 'fechar_admissao'), (self.registro, 'reservar'),
                              (self.infra.registro_recursos, 'obter_retrato')):
                pilha.enter_context(patch.object(obj, nome, side_effect=AssertionError(nome)))
            for _ in range(3):
                self.assertEqual(antes, self.evidencia())
                self.assertEqual(antes['retrato'], self.infra.obter_atividades_permanentes())
                self.assertEqual(antes['revisao'], self.registro.obter_revisao()['revisao'])
        self.threads[token].is_alive.assert_not_called()

    def test_12_ABA_atividade_completa(self):
        antes = self.evidencia()
        token = self.reservar()
        self.partir(token)
        self.terminar(token)
        depois = self.evidencia()
        self.assertGreater(depois['revisao'], antes['revisao'])
        self.assertTrue(all(i['termino_confirmado'] for i in depois['retrato']['atividades']))

    def test_13_publicacao_falha(self):
        token = self.reservar()
        self.partir(token)
        publicar = self.registro._publicar_saida
        def parcial(*args):
            publicar(*args)
            raise OSError('publicacao_simulada')
        with patch.object(self.registro, '_publicar_saida', side_effect=parcial):
            with self.assertRaises(OSError):
                self.threads[token].executar()
        self.assertFalse(self.evidencia()['confiavel'])
        self.assertTrue(self.item(token)['erro_publicacao'])
        self.assertFalse(self.item(token)['retorno'])

    def test_14_promocao_leitor_antigo(self):
        a = self.reservar()
        self.partir(a)
        identidade = self.registro.fonte_id
        self.infra.registro_retentativas.promover(self.recursos._geracao_retentativas)
        recursos_b = RecursosLeitorCliente(self.infra)
        origem_b = self.registro.preparar_leitor(recursos_b)
        b = self.reservar(origem_b)
        self.partir(b)
        self.terminar(b)
        antes = self.revisao()
        self.terminar(a)
        self.assertGreater(self.revisao(), antes)
        self.assertEqual(identidade, self.registro.fonte_id)
        self.assertEqual(self.origem.geracao_id, self.item(a)['geracao_id'])

    def test_15_nova_geracao_preserva_identidades(self):
        token = self.reservar()
        antes = self.evidencia()
        origem = self.registro.preparar_leitor(RecursosLeitorCliente(self.infra))
        depois = self.evidencia()
        self.assertGreater(depois['revisao'], antes['revisao'])
        self.assertNotEqual(self.origem.geracao_id, origem.geracao_id)
        self.assertEqual(token.numero, depois['retrato']['atividades'][0]['atividade_id'])
        self.assertEqual(2, len(depois['origens_preparadas']))

    def test_16_recurso_externo_nao_avanca(self):
        socket = self.recursos.abrir_socket(SocketLeituraFalso)
        self.addCleanup(socket.close)
        token = self.reservar()
        self.partir(token)
        self.terminar(token)
        antes = self.evidencia()
        socket.close()
        self.assertEqual(antes, self.evidencia())

    def test_corrida_A_reserva_contra_leitura(self):
        entrou, liberar, iniciou, leu = [threading.Event() for _ in range(4)]
        avancar = self.registro._avancar_revisao
        antes = self.revisao()
        def pausa():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            avancar()
        def ler():
            iniciou.set()
            r = self.evidencia()
            leu.set()
            return r
        with patch.object(self.registro, '_avancar_revisao', side_effect=pausa):
            escritor = self.tarefa(self.reservar)
            leitor = None
            try:
                self.assertTrue(entrou.wait(3))
                self.assertTrue(self.registro._lock.locked())
                leitor = self.tarefa(ler)
                self.assertTrue(iniciou.wait(3))
                self.assertFalse(leu.is_set())
            finally:
                liberar.set()
                self.concluir(escritor)
                if leitor is not None:
                    self.concluir(leitor)
        self.assertEqual([], escritor[2] + leitor[2])
        r, = leitor[1]
        self.assertEqual(antes + 1, r['revisao'])
        self.assertEqual(1, len(r['retrato']['atividades']))
        self.assertTrue(r['confiavel'])

    def test_corrida_B_entrada_antes_publicacao_partida(self):
        token = self.reservar()
        capturas = []
        def corpo():
            self.assertFalse(self.registro._lock.locked())
            capturas.append(self.evidencia())
        self.partir(token, corpo, imediato=True)
        item = capturas[0]['retrato']['atividades'][0]
        self.assertTrue(item['entrada'])
        self.assertTrue(item['partida_em_curso'])
        self.assertFalse(item['partida_resolvida'])
        self.assertGreater(self.revisao(), capturas[0]['revisao'])
        self.assertFalse(self.item(token)['thread_terminada'])

    def test_corrida_C_ABA_completo(self):
        antes = self.evidencia()
        def ciclo():
            token = self.reservar()
            self.partir(token)
            self.terminar(token)
        tarefa = self.tarefa(ciclo)
        self.concluir(tarefa)
        self.assertEqual([], tarefa[2])
        depois = self.evidencia()
        self.assertEqual(antes['fonte_id'], depois['fonte_id'])
        self.assertGreater(depois['revisao'], antes['revisao'])
        self.assertTrue(all(i['termino_confirmado'] for i in depois['retrato']['atividades']))

    def test_corrida_D_promocao_retorno_tardio(self):
        a = self.reservar()
        entrou, liberar = threading.Event(), threading.Event()
        def corpo():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
        self.partir(a, corpo)
        tarefa = self.tarefa(self.threads[a].executar)
        try:
            self.assertTrue(entrou.wait(3))
            self.infra.registro_retentativas.promover(self.recursos._geracao_retentativas)
            nova = self.registro.preparar_leitor(RecursosLeitorCliente(self.infra))
            b = self.reservar(nova)
            self.partir(b)
            self.terminar(b)
            antes = self.evidencia()
            self.assertFalse(self.item(a)['retorno'])
        finally:
            liberar.set()
            self.concluir(tarefa)
        self.assertEqual([], tarefa[2])
        self.assertGreater(self.revisao(), antes['revisao'])
        self.assertTrue(self.item(a)['retorno'])
        self.assertFalse(self.item(a)['thread_terminada'])
        self.assertTrue(self.registro.observar_termino(a))

    def test_corrida_E_mutacao_parcial(self):
        antes = self.revisao()
        with patch.object(self.registro, '_avancar_revisao', side_effect=OSError()):
            with self.assertRaises(OSError):
                self.reservar()
        r = self.evidencia()
        self.assertFalse(r['confiavel'])
        self.assertEqual(antes, r['revisao'])
        self.assertEqual(1, len(r['retrato']['atividades']))

    def test_corrida_F_observadores_concorrentes(self):
        token = self.reservar()
        self.partir(token)
        self.threads[token].executar()
        barreira = threading.Barrier(2)
        def observar():
            self.assertFalse(self.registro._lock.locked())
            barreira.wait(3)
            return False
        self.threads[token].is_alive.side_effect = observar
        antes = self.revisao()
        a = self.tarefa(lambda: self.registro.observar_termino(token))
        b = self.tarefa(lambda: self.registro.observar_termino(token))
        self.concluir(a)
        self.concluir(b)
        self.assertEqual([], a[2] + b[2])
        self.assertEqual([True, True], a[1] + b[1])
        self.assertEqual(antes + 1, self.revisao())

    def test_adicional_leitor_real_SUBSCRIBE_antigo(self):
        leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        controle = leitor._admissao_subscribe
        retidos, threads = [], []
        def corpo():
            token = controle.admitir()
            dono = controle.iniciar(token)
            socket = dono.abrir_socket(SocketLeituraFalso)
            arquivo = socket.makefile('r', encoding='utf-8')
            retidos.extend((socket, arquivo))
            controle.finalizar(token)
        def fabricar(**kwargs):
            t = ThreadSimulada(**kwargs)
            threads.append(t)
            return t
        leitor._manter_atualizado = corpo
        with patch('rede.lerdadosserver.threading.Thread', side_effect=fabricar):
            leitor.iniciar()
        threads[0].executar()
        self.assertTrue(self.infra.observar_termino_leitores()[-1]['termino_observado'])
        for recurso in retidos:
            self.addCleanup(recurso.close)
        antes = self.evidencia()
        recursos_antes = self.infra.registro_recursos.obter_retrato()
        for recurso in retidos:
            recurso.close()
        self.assertEqual(antes, self.evidencia())
        self.assertNotEqual(recursos_antes, self.infra.registro_recursos.obter_retrato())
        r = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(r['encerramento_cliente_confirmado'])
        self.assertFalse(r['encerramento_global_confirmado'])

    def test_start_entra_lanca_retorna_depois(self):
        token = self.reservar()
        entrou, liberar = threading.Event(), threading.Event()
        threads = []
        original = RuntimeError('start_simulado')
        def rotina():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
        def fabricar(alvo):
            t = threading.Thread(target=alvo)
            threads.append(t)
            def start():
                t.start()
                self.assertTrue(entrou.wait(3))
                raise original
            return Mock(start=start, is_alive=t.is_alive)
        try:
            with self.assertRaises(RuntimeError) as recebido:
                self.registro.partir(token, fabricar, rotina)
            self.assertIs(original, recebido.exception)
            antes = self.evidencia()
            self.assertTrue(self.item(token)['entrada'])
            self.assertTrue(self.item(token)['partida_ambigua'])
            self.assertFalse(self.item(token)['ausencia_comprovada'])
            self.assertFalse(self.registro.observar_termino(token))
        finally:
            liberar.set()
            for t in threads:
                t.join(3)
                self.assertFalse(t.is_alive())
        self.assertGreater(self.revisao(), antes['revisao'])
        self.assertTrue(self.item(token)['retorno'])
        self.assertFalse(self.item(token)['thread_terminada'])
        self.assertTrue(self.registro.observar_termino(token))
        self.assertTrue(self.item(token)['partida_ambigua'])

    def test_idempotencia_e_recusas(self):
        token = self.reservar()
        self.partir(token)
        antes = self.evidencia()
        self.assertFalse(self.partir(token))
        self.assertFalse(self.registro.comprovar_nao_partida(token, nao_iniciada=True))
        self.assertEqual(antes, self.evidencia())
        antes = self.revisao()
        self.assertTrue(self.registro.fechar_admissao())
        self.assertEqual(antes + 1, self.revisao())
        antes = self.evidencia()
        self.assertFalse(self.registro.fechar_admissao())
        self.assertIsNone(self.reservar())
        self.assertEqual(antes, self.evidencia())

    def test_cancelamento_pre_partida_e_prova_ausencia(self):
        a = self.reservar()
        b = self.reservar()
        self.registro.fechar_admissao()
        antes = self.revisao()
        fabrica = Mock()
        self.assertFalse(self.registro.partir(a, fabrica, lambda: None))
        fabrica.assert_not_called()
        self.assertGreater(self.revisao(), antes)
        self.assertTrue(self.item(a)['ausencia_comprovada'])
        self.assertTrue(self.registro.comprovar_nao_partida(b, nao_iniciada=True))
        antes = self.evidencia()
        self.assertTrue(self.registro.comprovar_nao_partida(b, nao_iniciada=True))
        self.assertEqual(antes, self.evidencia())

    def test_fabrica_falha_antes_start(self):
        token = self.reservar()
        original = OSError('fabrica_simulada')
        with self.assertRaises(OSError) as recebido:
            self.registro.partir(token, Mock(side_effect=original), lambda: None)
        self.assertIs(original, recebido.exception)
        self.assertTrue(self.item(token)['ausencia_comprovada'])
        self.assertFalse(self.item(token)['start_invocado'])
        self.assertTrue(self.evidencia()['confiavel'])

    def test_erro_observacao_e_contradicao_revisados(self):
        token = self.reservar()
        self.partir(token)
        self.terminar(token)
        antes = self.revisao()
        self.threads[token].is_alive.side_effect = lambda: True
        self.assertFalse(self.registro.observar_termino(token))
        self.assertEqual(antes + 1, self.revisao())
        self.assertTrue(self.item(token)['erro_observacao'])
        self.assertFalse(self.item(token)['termino_confirmado'])
        antes = self.revisao()
        self.threads[token].is_alive.side_effect = OSError()
        self.assertFalse(self.registro.observar_termino(token))
        self.assertEqual(antes, self.revisao())

    def test_retencao_REGISTER_so_versiona_vinculo_local(self):
        leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        origem = leitor._origem_atividade_permanente
        controle = leitor._admissao_register
        antes = self.evidencia()
        self.registro.reter_admissao_register(origem, controle)
        self.assertEqual(antes, self.evidencia())
        controle.admitir()
        self.assertEqual(antes, self.evidencia())
        self.assertIn(leitor.recursos_cliente.geracao_id, antes['geracoes_register_retidas'])

    def test_SUBSCRIBE_e_CONFIG_nao_avancam(self):
        leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        antes = self.evidencia()
        leitor._admissao_subscribe.admitir()
        leitor._admissao_config.admitir()
        self.assertEqual(antes, self.evidencia())

    def test_fontes_iguais_em_numero_sao_distintas(self):
        a, b = RegistroAtividadesPermanentesCliente(self.infra), RegistroAtividadesPermanentesCliente(self.infra)
        self.assertEqual(a.obter_revisao()['revisao'], b.obter_revisao()['revisao'])
        self.assertNotEqual(a.fonte_id, b.fonte_id)
        with self.assertRaises(AttributeError):
            a.fonte_id = 'outra'

    def test_mutacao_recusada_antes_de_efeito(self):
        antes = self.evidencia()
        with self.assertRaises(ValueError):
            self.registro.reservar(object())
        with self.assertRaises(ValueError):
            self.registro.preparar_leitor(object())
        self.assertEqual(antes, self.evidencia())

    def test_incremento_silencioso_e_sticky(self):
        with patch.object(self.registro, '_avancar_revisao', return_value=None):
            with self.assertRaisesRegex(RuntimeError, 'revisao_atividades_nao_publicada'):
                self.reservar()
        self.assertFalse(self.evidencia()['confiavel'])
        self.reservar()
        self.assertFalse(self.evidencia()['confiavel'])

    def test_falha_apos_incremento(self):
        avancar = self.registro._avancar_revisao
        antes = self.revisao()
        def falhar():
            avancar()
            raise OSError()
        with patch.object(self.registro, '_avancar_revisao', side_effect=falhar):
            with self.assertRaises(OSError):
                self.reservar()
        self.assertEqual(antes + 1, self.revisao())
        self.assertFalse(self.evidencia()['confiavel'])

    def test_erro_operacional_traceback_e_publicacao(self):
        token = self.reservar()
        original, publicacao = ValueError('original_simulado'), OSError('publicacao_simulada')
        tracebacks = []
        def corpo():
            try:
                raise original
            except ValueError as erro:
                tracebacks.append(erro.__traceback__)
                raise
        self.partir(token, corpo)
        with patch.object(self.registro, '_publicar_saida', side_effect=publicacao):
            try:
                self.threads[token].executar()
            except ValueError as recebido:
                self.assertIs(original, recebido)
                tb, cadeia = recebido.__traceback__, []
                while tb is not None:
                    cadeia.append(tb)
                    tb = tb.tb_next
            else:
                self.fail('erro operacional nao propagado')
        self.assertIn(tracebacks[0], cadeia)
        self.assertIs(publicacao, original.__cause__)
        self.assertFalse(self.evidencia()['confiavel'])

    def test_falha_do_invalidador_nao_oculta_incerteza(self):
        token = self.reservar()
        self.partir(token)
        publicacao, invalidacao = OSError('publicacao_simulada'), RuntimeError('invalidacao_simulada')
        with patch.object(self.registro, '_publicar_saida', side_effect=publicacao), \
                patch.object(self.registro, '_invalidar', side_effect=invalidacao):
            with self.assertRaises(OSError) as recebido:
                self.threads[token].executar()
        self.assertIs(publicacao, recebido.exception)
        self.assertIs(invalidacao, publicacao.__cause__)
        self.assertFalse(self.evidencia()['confiavel'])

    def test_API_legada_e_composicao(self):
        self.assertEqual({'aplicacao_id', 'admissao_fechada', 'atividades',
                          'cobertura_operacional', 'encerramento_global_confirmado'},
                         set(self.infra.obter_atividades_permanentes()))
        selo = self.registro.obter_revisao()
        with patch.object(self.registro, 'obter_revisao', side_effect=AssertionError()), \
                patch.object(self.registro, 'obter_evidencia_temporal', side_effect=AssertionError()):
            r = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(r['encerramento_cliente_confirmado'])
        self.assertFalse(r['encerramento_global_confirmado'])
        self.assertEqual(selo, self.registro.obter_revisao())

    def test_erro_operacional_ante_falha_da_revisao_do_diagnostico(self):
        token = self.reservar()
        original, adicional = ValueError('original_simulado'), OSError('revisao_simulada')
        self.partir(token, Mock(side_effect=original))
        avancar = self.registro._avancar_revisao
        chamadas = []
        def falhar():
            chamadas.append(True)
            if len(chamadas) == 2:
                raise adicional
            avancar()
        with patch.object(self.registro, '_avancar_revisao', side_effect=falhar):
            with self.assertRaises(ValueError) as recebido:
                self.threads[token].executar()
        self.assertIs(original, recebido.exception)
        self.assertIs(adicional, original.__cause__)
        self.assertFalse(self.evidencia()['confiavel'])

    def test_start_original_ante_falhas_do_acompanhamento(self):
        token = self.reservar()
        original, adicional = ValueError('start_simulado'), OSError('revisao_simulada')
        avancar = self.registro._avancar_revisao
        def fabricar(alvo):
            def start():
                self.registro._avancar_revisao = Mock(side_effect=adicional)
                raise original
            return Mock(start=start)
        try:
            with self.assertRaises(ValueError) as recebido:
                self.registro.partir(token, fabricar, lambda: None)
        finally:
            self.registro._avancar_revisao = avancar
        self.assertIs(original, recebido.exception)
        self.assertIs(adicional, original.__cause__)
        self.assertFalse(self.evidencia()['confiavel'])

    def test_observacao_falha_e_revisao_adicional_falha(self):
        token = self.reservar()
        self.partir(token)
        self.threads[token].executar()
        self.threads[token].is_alive.side_effect = OSError('observacao_simulada')
        with patch.object(self.registro, '_avancar_revisao', side_effect=RuntimeError()):
            self.assertFalse(self.registro.observar_termino(token))
        self.assertTrue(self.item(token)['erro_observacao'])
        self.assertFalse(self.evidencia()['confiavel'])

    def test_falha_no_diagnostico_nao_substitui_operacional(self):
        token = self.reservar()
        original, adicional = ValueError('original_simulado'), OSError('diagnostico_simulado')
        self.partir(token, Mock(side_effect=original))
        with patch.object(self.registro, '_erro', side_effect=adicional):
            with self.assertRaises(ValueError) as recebido:
                self.threads[token].executar()
        self.assertIs(original, recebido.exception)
        self.assertIs(adicional, original.__cause__)
        self.assertFalse(self.evidencia()['confiavel'])


if __name__ == '__main__':
    unittest.main()

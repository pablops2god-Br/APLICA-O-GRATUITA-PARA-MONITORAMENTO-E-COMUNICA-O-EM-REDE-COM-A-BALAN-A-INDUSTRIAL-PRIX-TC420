# Testes de config cliente integrada: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""CONFIG instrumentado com objetos falsos, sem equipamento/rede/Tk."""
import json
import threading
import unittest
from unittest.mock import Mock, patch

from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
from test_recursos_cliente_integrados import SocketLeituraFalso
from apoio_conexoes_cliente import conexoes_tcp_simuladas


# Grupo de 23 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class ConfigClienteIntegrada(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.dono = RecursosLeitorCliente(self.infra)
        self.registro = self.infra.registro_recursos

    def objeto(self):
        objeto = SocketLeituraFalso()
        objeto.arquivo.readline = Mock(return_value='{"config":1}')
        return objeto

    def ler(self, objeto=None, dono=None):
        objeto = self.objeto() if objeto is None else objeto
        return (dono or self.dono).ler_configuracao(lambda: objeto, json.loads)

    def recursos(self):
        return self.registro.obter_retrato()["recursos"]

    def pendente(self):
        self.assertFalse(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_01_config_normal(self):
        objeto = self.objeto()
        self.assertEqual({"config": 1}, self.ler(objeto))
        objeto.sendall.assert_called_once_with(b"CONFIG\n")
        self.assertEqual(2, len(self.recursos()))

    def test_02_falha_comprovada_antes_alocacao(self):
        fabrica = Mock()
        with patch.object(self.registro, "criar", side_effect=OSError()):
            with self.assertRaises(OSError):
                self.dono.ler_configuracao(fabrica, json.loads)
        fabrica.assert_not_called()
        self.registro.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_03_falha_apos_alocacao(self):
        objeto = self.objeto()
        criar = self.registro.criar

        def falhar(token, fabrica):
            return criar(token, fabrica, preparar=Mock(side_effect=ValueError()))

        with patch.object(self.registro, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.ler(objeto)
        self.assertTrue(objeto.fechado)
        self.assertTrue(self.recursos()[0]["erros_criacao"])

    def test_04_timeout_original(self):
        erro = TimeoutError("timeout_simulado")
        with self.assertRaises(TimeoutError) as capturado:
            self.dono.ler_configuracao(Mock(side_effect=erro), json.loads)
        self.assertIs(erro, capturado.exception)
        self.assertEqual("desconhecido", self.recursos()[0]["estado"])

    def test_05_comunicacao_e_duplo_close_preservam_original(self):
        objeto = self.objeto()
        erro = ValueError("comunicacao_simulada")
        objeto.arquivo.readline.side_effect = erro
        objeto.arquivo.erro_close = OSError()
        objeto.erro_close = OSError()
        with self.assertRaises(ValueError) as capturado:
            self.ler(objeto)
        self.assertIs(erro, capturado.exception)
        self.assertTrue(all(r["erros_limpeza"] for r in self.recursos()))
        self.assertTrue(all(r["erros_atendimento"] for r in self.recursos()))
        self.registro.fechar_admissao()
        self.pendente()

    def test_06_close_normal_arquivo_antes_socket(self):
        objeto = self.objeto()
        ordem = []
        close_a, close_s = objeto.arquivo.close, objeto.close
        objeto.arquivo.close = lambda: (ordem.append("arquivo"), close_a())[-1]
        objeto.close = lambda: (ordem.append("socket"), close_s())[-1]
        self.ler(objeto)
        self.assertEqual(["arquivo", "socket"], ordem)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_07_close_falha_sem_erro_de_corpo(self):
        objeto = self.objeto()
        erro = OSError()
        objeto.arquivo.erro_close = erro
        with self.assertRaises(OSError) as capturado:
            self.ler(objeto)
        self.assertIs(erro, capturado.exception)
        self.assertTrue(objeto.fechado)
        self.registro.fechar_admissao()
        self.pendente()

    def test_08_publicacao_incerta_nao_confirma(self):
        objeto = self.objeto()

        def falhar(token, alocar):
            alocar()
            raise ValueError()

        with patch.object(self.registro, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.ler(objeto)
        self.assertTrue(objeto.fechado)
        self.assertTrue(self.dono.obter_publicacoes_pendentes())
        self.registro.fechar_admissao()
        self.pendente()

    def test_09_config_e_subscribe_identidades_distintas(self):
        sub = self.dono.abrir_socket(self.objeto)
        arquivo = sub.makefile("r", encoding="utf-8")
        self.ler()
        self.assertEqual(4, len({r["recurso_id"] for r in self.recursos()}))
        self.assertFalse(self.recursos()[0]["encerramento_confirmado"])
        sub.close()
        arquivo.close()

    def test_10_nova_conexao_config_novos_ids(self):
        self.ler()
        self.ler()
        self.assertEqual(4, len({r["recurso_id"] for r in self.recursos()}))

    def test_11_geracao_antiga_pendente(self):
        objeto = self.objeto()
        objeto.erro_close = OSError()
        with self.assertRaises(OSError):
            self.ler(objeto)
        nova = RecursosLeitorCliente(self.infra)
        self.ler(dono=nova)
        self.registro.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato(geracao_id=nova.geracao_id)["encerramento_confirmado"])
        self.pendente()

    def test_12_promocao_preserva_historico(self):
        self.ler()
        ids = [r["recurso_id"] for r in self.recursos()]
        self.registro.promover(self.dono.geracao_id)
        self.assertEqual(ids, [r["recurso_id"] for r in self.recursos()])
        self.assertTrue(all(r["modo_atual"] == "principal" for r in self.recursos()))

    def executar_retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []

        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("harness")

        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)

        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_13_consulta_durante_limpeza(self):
        objeto = self.objeto()

        def executar(suspender):
            objeto.close = suspender
            self.ler(objeto)

        self.executar_retido(executar, lambda: (self.registro.fechar_admissao(), self.pendente()))

    def test_14_repeticao_preserva_evidencias(self):
        objeto = self.objeto()
        objeto.erro_close = OSError()
        proxies = []
        abrir = self.dono.abrir_socket

        def capturar(fabrica):
            proxy = abrir(fabrica)
            proxies.append(proxy)
            return proxy

        with patch.object(self.dono, "abrir_socket", side_effect=capturar):
            with self.assertRaises(OSError):
                self.ler(objeto)
        objeto.erro_close = None
        proxies[0].close()
        proxies[0].close()
        self.assertEqual(2, objeto.close_chamadas)
        self.registro.fechar_admissao()
        self.assertTrue(self.recursos()[0]["erros_limpeza"])
        self.pendente()

    def test_15_sem_makefile_se_falha_antes_de_abri_lo(self):
        objeto = self.objeto()
        objeto.sendall.side_effect = OSError()
        with self.assertRaises(OSError):
            self.ler(objeto)
        objeto.makefile.assert_not_called()
        self.assertEqual(["socket_tcp"], [r["tipo"] for r in self.recursos()])

    def test_16_cobertura_global_incompleta(self):
        self.ler()
        self.registro.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])

    def test_critico_A_criacao_retida_apos_gate(self):
        def executar(suspender):
            def fabrica():
                suspender()
                return self.objeto()
            with self.assertRaises(RuntimeError):
                self.dono.ler_configuracao(fabrica, json.loads)

        self.executar_retido(executar, lambda: (self.registro.fechar_admissao(), self.pendente()))
        self.assertEqual(self.dono.geracao_id, self.recursos()[0]["geracao_id"])
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])

    def test_critico_B_config_subscribe_concorrentes(self):
        barreira = threading.Barrier(3)
        erros = []

        def rodar(config):
            try:
                barreira.wait(3)
                if config:
                    self.ler()
                else:
                    sub = self.dono.abrir_socket(self.objeto)
                    arquivo = sub.makefile("r", encoding="utf-8")
                    sub.close()
                    arquivo.close()
            except BaseException as erro:
                erros.append(erro)

        threads = [threading.Thread(target=rodar, args=(flag,)) for flag in (True, False)]
        for thread in threads:
            thread.start()
        barreira.wait(3)
        for thread in threads:
            thread.join(3)
            self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(4, len({r["recurso_id"] for r in self.recursos()}))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_critico_C_erro_de_close_tardio(self):
        objeto = self.objeto()

        def executar(suspender):
            def close():
                suspender()
                raise OSError()
            objeto.close = close
            with self.assertRaises(OSError):
                self.ler(objeto)

        self.executar_retido(executar, lambda: (self.registro.fechar_admissao(), self.pendente()))
        self.pendente()
        self.assertTrue(self.recursos()[0]["erros_limpeza"])

    def test_critico_D_config_antiga_nova_geracao_concluida(self):
        objeto = self.objeto()

        def executar(suspender):
            objeto.arquivo.readline.side_effect = lambda: (suspender(), '{}')[-1]
            self.ler(objeto)

        def nova():
            outro = RecursosLeitorCliente(self.infra)
            self.ler(dono=outro)
            self.registro.fechar_admissao()
            self.assertTrue(self.registro.obter_retrato(geracao_id=outro.geracao_id)["encerramento_confirmado"])
            self.pendente()

        self.executar_retido(executar, nova)
        self.assertTrue(self.registro.obter_retrato()["encerramento_confirmado"])

    def test_timeout_no_leitor_preserva_fluxo_e_parametros(self):
        leitor = LeitorDadosServidor("principal-simulado", infraestrutura_cliente=self.infra)
        leitor.executando = True

        def parar_busca(**kwargs):
            leitor.parar()
            return None

        with conexoes_tcp_simuladas(leitor.recursos_cliente, [TimeoutError()]) as criar, \
                patch("rede.lerdadosserver.buscar_servidor", side_effect=parar_busca) as buscar:
            leitor._manter_atualizado()
        criar.assert_called_once_with(("principal-simulado", 42100), timeout=5)
        buscar.assert_called_once_with(recursos_cliente=leitor.recursos_cliente)
        self.assertIsNone(leitor.ip_servidor)
        self.assertFalse(leitor.configuracao_pronta.is_set())

    def test_config_apos_descoberta_inicial_sem_servidor(self):
        # Reproduz o antigo PRINCIPAL aguardando o PC promovido aparecer.
        leitor = LeitorDadosServidor(permitir_candidatura=False,
                                    infraestrutura_cliente=self.infra)
        leitor.executando = True
        objeto = self.objeto()
        faixas = {'W1.1': {'min': '200 kg', 'max': '80000 kg', 'divisao': '10 kg'}}
        objeto.arquivo.readline.return_value = json.dumps(faixas)
        observados = []
        def registrar():
            observados.append((leitor.obter_configuracao(), leitor.configuracao_pronta.is_set()))
            leitor.parar()
            return None
        with patch.object(leitor, '_buscar_servidor_inicial', return_value=None), \
                patch('rede.lerdadosserver.buscar_servidor', return_value='principal-simulado'), \
                conexoes_tcp_simuladas(leitor.recursos_cliente, [objeto]), \
                patch.object(leitor._admissao_register, 'admitir', side_effect=registrar) as registro:
            leitor._manter_atualizado()
        registro.assert_called_once()
        self.assertEqual([(faixas, True)], observados)
        objeto.sendall.assert_called_once_with(b'CONFIG\n')
        self.assertTrue(objeto.fechado)
        self.assertTrue(objeto.arquivo.closed)

    def test_json_invalido_preserva_erro_mesmo_com_close_falho(self):
        objeto = self.objeto()
        objeto.arquivo.readline.return_value = '{invalido'
        objeto.arquivo.erro_close = OSError()
        with self.assertRaises(json.JSONDecodeError):
            self.ler(objeto)
        self.assertTrue(objeto.fechado)

    def test_gate_fecha_entre_publicar_arquivo_e_entrar_no_uso(self):
        objeto = self.objeto()
        criar = self.registro.criar

        def fechar_depois(token, fabrica):
            resultado = criar(token, fabrica)
            item = next(r for r in self.recursos() if r["recurso_id"] == token.numero)
            if item["tipo"] == "arquivo_socket":
                self.registro.fechar_admissao()
            return resultado

        with patch.object(self.registro, "criar", side_effect=fechar_depois):
            with self.assertRaises(RuntimeError):
                self.ler(objeto)
        self.assertTrue(objeto.fechado)
        self.assertTrue(objeto.arquivo.closed)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))


if __name__ == "__main__":
    unittest.main()

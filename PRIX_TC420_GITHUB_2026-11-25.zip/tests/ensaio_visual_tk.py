# Ensaio visual offline: cria widgets Tk reais com dependências controladas para inspeção manual.
"""Ensaio visual offline das janelas reais do TC420.

Executar a partir da raiz do projeto:
    python -B tests/ensaio_visual_tk.py
    python -B tests/ensaio_visual_tk.py --moderno
    python -B tests/ensaio_visual_tk.py --moderno --autoteste

--moderno abre somente o modelo visual separado, sem construir a aplicação real.

O harness não importa main.py, não abre sockets, não usa requests, keyring ou o
arquivo configuracao.json. Todas as ações externas são substituídas antes da
construção dos widgets reais.
"""
from __future__ import annotations

import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk
from contextlib import ExitStack
from unittest.mock import patch
import secrets


RAIZ = Path(__file__).resolve().parents[1]
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

import interface.conexao as modulo_conexao
from interface.janela import JanelaTC420
from interface.saida_aplicacao import SaidaAplicacao
from rede.servidor import RegistroTentativasAplicacao
from admin_visual_tk import AdministradorEnsaio


class LeitorTCPOffline:
    """Fonte visual sem socket: permite simular idade e retorno da leitura."""
    thread = None

    def __init__(self, rede):
        self.rede, self.parado, self.idade = rede, False, 0

    def parar(self):
        self.parado = True

    def obter_dados_atuais(self):
        dados = self.rede.retrato()
        dados.update(tara='—', estado='TCP', multirange='—')
        return dados

    def comunicacao_esta_atual(self):
        return not self.parado and self.idade <= 10

    def registrar_diagnostico(self, _atual):
        pass


CONFIGURACAO = {
    "W1.1": {"divisao": "10 g", "min": "200 g", "max": "80000 g"},
    "W1.2": {"divisao": "20 g", "min": "400 g", "max": "140000 g"},
}


class RedeOffline:
    def __init__(self):
        self.modo = "sucesso"
        self.atraso = 2.5
        self.dados = {
            "peso_liquido": "12.340",
            "tara": "0.000",
            "unidade": "kg",
            "multirange": "1",
            "estado": "00",
        }
        self.lock = threading.Lock()
        self.promocoes = 0
        self.comunicacao_atual = True
        self.saude_principal = True
        self.servidor_encerrado = False

    def aguardar(self):
        time.sleep(self.atraso)

    def retrato(self):
        with self.lock:
            return dict(self.dados)

    def alternar_peso(self):
        with self.lock:
            atual = self.dados["peso_liquido"]
            self.dados.update(
                peso_liquido="78.920" if atual == "12.340" else "12.340",
                tara="1.250" if atual == "12.340" else "0.000",
                multirange="2" if atual == "12.340" else "1",
                estado="Z0" if atual == "12.340" else "00",
            )


class EnsaioVisual:
    def __init__(self):
        self.reiniciar_solicitado = False
        self.rede = RedeOffline()
        self.registro = RegistroTentativasAplicacao()
        self.saida = SaidaAplicacao()
        self.saida.configurar(registro=self.registro)
        self.saida.ao_reconfigurar = self._reabrir_por_menu
        self.monitor = None
        self.candidatura = False
        self.estado_candidatura = "inativa"
        self.liberar_operacao_longa = None
        self._encerrando = False
        self._instalar_isolamento()
        self.conexao = modulo_conexao.JanelaConexao(
            ao_encontrar_servidor=self._abrir_cliente_simulado,
            registro_tentativas=self.registro,
            saida_aplicacao=self.saida,
        )
        self._preencher_campos()
        self._substituir_fluxo_operacional()
        self._montar_painel()
        self.admin = AdministradorEnsaio(self)
        self.conexao.root.atalho_ensaio.config(command=lambda: self.admin.pedir(
            'Acesso ao laboratório de ensaio', self.painel.lift))
        self.configuracao_autorizada = False
        self._conectar_original = self.conexao.conectar
        self.conexao.conectar = self.conectar_com_admin
        self.conexao.botao_conectar.config(command=self.conectar_com_admin)
        self.conexao.root.bind('<Return>', lambda _evento: self.conectar_com_admin())
        self.conexao.root.bind('<Destroy>', self._fechar_isolamento, add='+')
        # O laboratório tem painel e modais próprios: o X deve encerrar seu dono,
        # não encaminhar a saída ao fluxo operacional da aplicação real.
        self.conexao.root.protocol('WM_DELETE_WINDOW', self.confirmar_saida_ensaio)
        self.conexao.root.withdraw()
        self.admin.iniciar_aplicacao()
        self.registrar("Harness offline iniciado; nenhum transporte externo foi criado.")

    def _instalar_isolamento(self):
        self.isolamento = ExitStack()
        self.efeitos_proibidos = []
        def proibido(*_args, **_kwargs):
            raise AssertionError("efeito externo proibido pelo ensaio visual offline")
        import config.configuracao as persistencia
        simulados = dict(carregar_configuracao=None, carregar_senha=None, salvar_configuracao=None,
                         salvar_senha=True, remover_senha=None, guardar_login_automatico=True)
        for nome, resultado in simulados.items():
            for modulo in (modulo_conexao, persistencia):
                if hasattr(modulo, nome):
                    self.isolamento.enter_context(patch.object(modulo, nome, return_value=resultado))
        for nome in ('buscar_servidor', 'WebTC420', 'iniciar_servidor', 'solicitar_parada_servidor'):
            self.efeitos_proibidos.append(self.isolamento.enter_context(
                patch.object(modulo_conexao, nome, side_effect=proibido)))
        self.isolamento.enter_context(patch.object(modulo_conexao, 'definir_configuracao', return_value=None))
        self.efeitos_proibidos.append(self.isolamento.enter_context(patch('socket.socket', side_effect=proibido)))
        self.efeitos_proibidos.append(self.isolamento.enter_context(patch('requests.sessions.Session.request', side_effect=proibido)))
        self.isolamento.enter_context(patch('interface.janela.filedialog.asksaveasfilename', return_value=''))
        self.isolamento.enter_context(patch('interface.formularios.abrir_ensaio', side_effect=lambda: self.painel.lift()))
        def tcp_offline(_ip, _porta, saida, *_args, **_kwargs):
            self.rede.aguardar()
            if self.rede.modo == 'timeout':
                from rede.tcp_local import ErroTCPLocal
                raise ErroTCPLocal('sem_dados')
            leitor = LeitorTCPOffline(self.rede)
            saida.acompanhar_leitor(leitor)
            return leitor
        self.isolamento.enter_context(patch('rede.tcp_local.conectar_local', side_effect=tcp_offline))

    def _fechar_isolamento(self, evento):
        if evento.widget is self.conexao.root:
            self.isolamento.close()

    def mostrar_conexao(self):
        self.configuracao_autorizada = True
        self.conexao.root.deiconify()
        self.conexao.root.lift()

    def conectar_com_admin(self):
        if self.admin.credencial is None:
            return self.admin.pedir('Primeira configuração', self.mostrar_conexao)
        if self.conexao.metodo_conexao_var.get() == 'TCP' and not self.admin.autorizado:
            return self.admin.pedir('Conexão TCP', self._conectar_original)
        if self.configuracao_autorizada:
            return self._conectar_original()
        self.admin.pedir('Configuração da conexão', self.mostrar_conexao)

    def limpar_configuracao_simulada(self):
        """Apaga apenas o formulário offline; nunca chama cofre ou disco."""
        for campo in (self.conexao.campo_nome, self.conexao.campo_ip,
                      self.conexao.campo_porta, self.conexao.campo_usuario,
                      self.conexao.campo_senha):
            campo.delete(0, 'end')
        self.conexao.salvar_login_var.set(False)
        self.conexao.metodo_conexao_var.set('HTTPS')
        self.configuracao_autorizada = False
        self.registrar('RESTAURAÇÃO: configuração e cadastro administrativos simulados apagados.')

    def _preencher_campos(self):
        valores = {
            self.conexao.campo_nome: "ENSAIO OFFLINE",
            self.conexao.campo_ip: "192.0.2.10",
            self.conexao.campo_porta: "9800",
            self.conexao.campo_usuario: "usuario-simulado",
            self.conexao.campo_senha: secrets.token_urlsafe(12),
        }
        for campo, valor in valores.items():
            campo.delete(0, "end")
            campo.insert(0, valor)
        self.conexao.salvar_login_var.set(False)

    def _substituir_fluxo_operacional(self):
        def conectar_offline(_nome, _ip, _porta, _usuario, _senha, _salvar):
            self.registrar_worker("CONEXÃO: worker iniciado")
            self.rede.aguardar()
            modo = self.rede.modo
            if modo == "timeout":
                raise TimeoutError("timeout_offline_controlado")
            if modo == "descoberta":
                return {"servidor": "principal-offline"}
            return {"principal": True, "offline": True}

        def aplicar_offline(resultado, erro):
            self._assert_tk("resultado da conexão")
            self.conexao.botao_conectar.config(state="normal")
            if erro:
                self.conexao.label_status.config(
                    text="● Falha simulada: " + erro, fg="red"
                )
                self.registrar("Falha/timeout aplicado no Tk; janela preservada.")
                return
            if 'tcp_local' in resultado:
                self.abrir_monitor()
                self.monitor.configurar_tcp_local(resultado['tcp_local'])
                self.monitor.atualizar_refresh_web(reagendar=False)
                self.registrar('TCP local simulado; nenhuma conexão externa foi aberta.')
                return
            if "servidor" in resultado:
                self.conexao.label_status.config(
                    text="● Descoberta simulada concluída", fg="green"
                )
                self.registrar("Descoberta UDP simulada; nenhum socket foi aberto.")
                return
            self.conexao.label_status.config(
                text="● Login e approval simulados concluídos", fg="green"
            )
            self.registrar("Conexão concluída no Tk; abrindo monitor real.")
            self.abrir_monitor()

        self.conexao._conectar_operacional = conectar_offline
        self.conexao._aplicar_conexao = aplicar_offline

    def _montar_painel(self):
        from painel_ensaio_tk import montar_painel
        montar_painel(self)

    def _alterar_modo(self):
        self.rede.modo = self.modo.get()
        self.registrar("Cenário de conexão: " + self.rede.modo)

    def _atualizar_contagem(self):
        total = sum(valor.get() for _texto, valor in self.checks)
        self.contagem.config(text=f"{total} de 10 aprovados")

    def copiar_resultados(self):
        linhas = ["Ensaio visual Tkinter offline:"]
        for texto, valor in self.checks:
            linhas.append(("[x] " if valor.get() else "[ ] ") + texto)
        linhas.append("")
        linhas.extend(self.lista.get(0, "end"))
        self.painel.clipboard_clear()
        self.painel.clipboard_append("\n".join(linhas))
        self.painel.update()
        self.registrar("Checklist e log copiados para a área de transferência.")

    def _assert_tk(self, origem):
        if threading.current_thread() is not threading.main_thread():
            raise AssertionError("Tk acessado fora da thread principal: " + origem)

    def registrar_worker(self, texto):
        # Workers não tocam Tk; o registro também atravessa a fila da janela.
        from interface.ciclo_tk import ciclo
        ciclo(self.conexao).publicar(self.registrar, texto)

    def registrar(self, texto):
        self._assert_tk("registro visual")
        horario = time.strftime("%H:%M:%S")
        self.lista.insert("end", f"{horario}  {texto}")
        if self.lista.size() > 1000:
            self.lista.delete(0, self.lista.size() - 1001)
        self.lista.see("end")

    def abrir_monitor(self):
        self._assert_tk("abrir monitor")
        if self.saida.parada_solicitada:
            messagebox.showinfo(
                "Execução encerrada",
                "Esta execução já concluiu a parada. Use 'Reabrir execução' "
                "para criar um novo proprietário e novas janelas.",
                parent=self.painel,
            )
            self.registrar("Abertura recusada: execução anterior já encerrada.")
            return
        if self.monitor is not None and self.monitor.executando:
            self.monitor.root.lift()
            return
        callback = self.saida.vincular("monitor_visual_offline")
        self.monitor = JanelaTC420(
            web=object(),
            configuracao=CONFIGURACAO,
            fonte_dados=self.rede.retrato,
            comunicacao_atual=lambda: self.rede.comunicacao_atual,
            candidatura_liberada=lambda: self.candidatura,
            estado_candidatura=lambda: self.estado_candidatura,
            ao_promover=self._promover,
            ao_promover_automaticamente=self._promover_automaticamente,
            obter_saude_principal=lambda: {
                "saudavel": self.rede.saude_principal,
            },
            servidor_encerrado=lambda: self.rede.servidor_encerrado,
            ao_reconfigurar=self._reabrir_por_menu,
            master=self.conexao.root,
            ao_fechar=callback,
        )
        self.monitor.saida_aplicacao = self.saida
        self.monitor._abrir_promocao_original = self.monitor.abrir_janela_promocao
        self.monitor.abrir_janela_promocao = lambda: self.admin.pedir(
            'Promoção manual', self.monitor._abrir_promocao_original)
        protegido = lambda: self.admin.pedir('Reconfiguração da balança',
                                             lambda: self.transicionar_configuracao(self.mostrar_conexao))
        self.monitor.solicitar_reconfiguracao = protegido
        self.monitor.menu_opcoes.entryconfigure('Reconfigurar', command=protegido)
        self.saida.conectar_interface(
            callback,
            self.monitor.agendar_saida,
            self.monitor.concluir_fechamento,
            self.monitor.informar_encerramento_pendente,
        )
        self.monitor.atualizar_refresh_web()
        self.monitor.verificar_candidatura()
        self.registrar("Monitor real aberto com fonte de peso simulada.")

    def transicionar_configuracao(self, continuar):
        """Fecha o monitor somente após B2 e prepara um novo dono para configurar."""
        if getattr(self, '_transicao_configuracao', False):
            return
        self._transicao_configuracao = True
        anterior = self.saida
        if not anterior.parada_solicitada:
            self._parar_transicao = anterior.vincular('reconfigurar_ensaio', lambda: None)
            self._parar_transicao()

        def aguardar():
            estado = anterior.obter_situacao()
            if not estado['parada_operacional_confirmada']:
                if estado['estado'] in ('falha', 'timeout'):
                    self._transicao_configuracao = False
                    self.registrar('Reconfiguração pendente: B2 ainda não confirmou a parada.')
                    return
                self.painel.after(50, aguardar)
                return
            if self.monitor is not None:
                self.monitor.concluir_fechamento()
                self.monitor = None
            self.registro = RegistroTentativasAplicacao()
            self.saida = SaidaAplicacao()
            self.saida.configurar(registro=self.registro)
            self.saida.ao_reconfigurar = self._reabrir_por_menu
            self.conexao.saida_aplicacao = self.saida
            self.conexao.registro_tentativas = self.registro
            self.conexao._callback_saida = self.saida.vincular('conexao_ensaio', lambda: None)
            self.candidatura = False
            self.estado_candidatura = 'inativa'
            self._transicao_configuracao = False
            self.registrar('B2 confirmada; monitor fechado antes da configuração.')
            continuar()
        aguardar()

    def alterar_peso(self):
        self.rede.alternar_peso()
        self.registrar("Dados simulados alterados; aguarde o próximo refresh.")

    def alternar_saude_ap(self):
        self.abrir_monitor()
        self.monitor.modo_monitor = "principal"
        self.rede.servidor_encerrado = False
        self.rede.saude_principal = not self.rede.saude_principal
        self.monitor._estado_status = None
        self.registrar("Saúde AP simulada: " + str(self.rede.saude_principal))

    def simular_ct_conectado(self):
        self.abrir_monitor()
        self.monitor.modo_monitor = "cliente"
        self.rede.comunicacao_atual = True
        self.candidatura = False
        self.estado_candidatura = "inativa"
        self.monitor._estado_status = None
        self.registrar("CT simulado conectado e recebendo mensagens válidas.")

    def simular_ct_sem_comunicacao(self):
        self.abrir_monitor()
        self.monitor.modo_monitor = "cliente"
        self.rede.comunicacao_atual = False
        self.candidatura = False
        self.estado_candidatura = "aguardando"
        self.monitor._estado_status = None
        self.registrar("CT simulado sem comunicação e aguardando candidatura.")

    def simular_ap_encerrado(self):
        self.abrir_monitor()
        self.monitor.modo_monitor = "principal"
        self.rede.servidor_encerrado = True
        self.monitor._estado_status = None
        self.registrar("Encerramento do servidor AP simulado.")

    def _promover(self, _ip, _usuario, _senha):
        self.registrar_worker("PROMOÇÃO MANUAL: worker iniciou espera controlada")
        self.rede.aguardar()
        self.rede.promocoes += 1
        return {
            "web": None,
            "configuracao": CONFIGURACAO,
            "fonte_dados": self.rede.retrato,
            "obter_saude_principal": lambda: {
                "saudavel": self.rede.saude_principal,
            },
            "servidor_encerrado": lambda: self.rede.servidor_encerrado,
        }

    def _promover_automaticamente(self):
        self.registrar_worker("PROMOÇÃO AUTOMÁTICA: worker iniciou espera controlada")
        self.rede.aguardar()
        self.rede.promocoes += 1
        return {
            "web": None,
            "configuracao": CONFIGURACAO,
            "fonte_dados": self.rede.retrato,
            "obter_saude_principal": lambda: {
                "saudavel": self.rede.saude_principal,
            },
            "servidor_encerrado": lambda: self.rede.servidor_encerrado,
        }

    def promocao_manual(self):
        self.abrir_monitor()
        self.candidatura = True
        self.estado_candidatura = 'liberada'
        self.monitor.candidatura_detectada = True
        self.monitor.abrir_janela_promocao()
        self.registrar('ASSUMIR solicitado; aguardando administrador do ensaio.')

    def promocao_manual_autorizada(self):
        self.abrir_monitor()
        self.monitor._abrir_promocao_original()

    def tcp_avancar(self, segundos):
        leitor = getattr(self.monitor, 'leitor_tcp_local', None) if self.monitor is not None else None
        if not isinstance(leitor, LeitorTCPOffline):
            self.registrar('TCP: conecte primeiro usando a opção TCP da tela de conexão.')
            return
        leitor.idade = 0 if segundos is None else leitor.idade + segundos
        self.monitor.atualizar_refresh_web(reagendar=False)
        self.registrar(f'TCP simulado: idade virtual {leitor.idade} s, atual={leitor.comunicacao_esta_atual()}.')

    def promocao_automatica(self):
        self.abrir_monitor()
        self.candidatura = True
        self.estado_candidatura = "liberada"
        self.registrar("Candidatura automática liberada; aguarde a detecção.")

    def falhar_promocao(self):
        self.abrir_monitor()

        def falhar(*_args):
            self.registrar_worker("PROMOÇÃO: falha controlada em andamento")
            self.rede.aguardar()
            raise TimeoutError("falha_promocao_offline")

        self.monitor.ao_promover = falhar
        self.monitor.abrir_janela_promocao()
        self.registrar("Promoção configurada para falhar sem bloquear o Tk.")

    def operacao_longa(self):
        self.abrir_monitor()
        if self.liberar_operacao_longa is not None and not self.liberar_operacao_longa.is_set():
            self.registrar("Operação longa já está ativa; nenhum worker duplicado foi criado.")
            return
        liberar = threading.Event()
        self.liberar_operacao_longa = liberar

        def aguardar_timeout_b2():
            if not liberar.wait(60):
                raise TimeoutError("harness_sem_timeout_b2")

        def restaurar(resultado, erro):
            self.registrar("Operação longa retornou; resultado tardio foi descartado.")

        from interface.ciclo_tk import ciclo
        ciclo(self.monitor).iniciar("operacao_visual_longa", aguardar_timeout_b2, restaurar)

        def observar_timeout():
            if liberar.is_set() or not self.painel.winfo_exists():
                return
            estado = self.saida.obter_situacao()["estado"]
            if estado == "timeout":
                self.registrar(
                    "Timeout B2 observado. O worker será liberado em 3 s; "
                    "depois clique novamente no X."
                )
                self.painel.after(3000, liberar.set)
                return
            self.painel.after(100, observar_timeout)

        self.painel.after(100, observar_timeout)
        self.registrar(
            "Operação longa controlada iniciada. Escolha SIM; B2 produzirá timeout "
            "em 10 s e o worker será liberado 3 s depois do aviso."
        )

    def reabrir(self):
        if self.saida.parada_solicitada:
            self.reiniciar_solicitado = True
            self.encerrar_harness()
            return
        self.abrir_monitor()
        self.registrar("Monitor apresentado novamente na mesma execução ativa.")

    def _reabrir_por_menu(self):
        self.reiniciar_solicitado = True
        self.encerrar_harness()

    def _abrir_cliente_simulado(self, servidor):
        self.registrar("Callback de cliente simulado: " + servidor)
        self.abrir_monitor()

    def encerrar_harness(self):
        if self._encerrando:
            return
        self._encerrando = True
        if self.admin.tela is not None:
            self.admin.tela.fechar()
        if self.liberar_operacao_longa is not None:
            self.liberar_operacao_longa.set()
        if not self.saida.parada_solicitada:
            self._callback_encerrar = self.saida.vincular('encerrar_laboratorio', lambda: None)
            self._callback_encerrar()
        elif self.saida.obter_situacao()['estado'] in ('falha', 'timeout'):
            callback = getattr(self, '_callback_encerrar', None)
            if callback is None:
                callback = self.monitor.ao_fechar if self.monitor is not None else self.conexao._callback_saida
            callback()
        self._aguardar_saida()

    def confirmar_saida_ensaio(self):
        if messagebox.askyesno('PRIX TC420 — ensaio',
                              'Encerrar o laboratório e todas as suas janelas?',
                              parent=self.conexao.root):
            self.encerrar_harness()

    def _aguardar_saida(self):
        estado = self.saida.obter_situacao()
        if estado['parada_operacional_confirmada']:
            # Todo este interpretador pertence ao ensaio; remove callbacks antes de destruir.
            for timer in self.conexao.root.tk.call('after', 'info'):
                # As Toplevels possuem comandos Python próprios; destroy fará sua limpeza.
                self.conexao.root.tk.call('after', 'cancel', timer)
            if self.monitor is not None:
                self.monitor.executando = False
            self.conexao.root.destroy()
            return
        if estado['estado'] in ('falha', 'timeout'):
            self.registrar('Saída pendente: aguarde os workers e use Encerrar novamente.')
            self._encerrando = False
            return
        self.painel.after(50, self._aguardar_saida)

    def executar(self):
        self.conexao.root.mainloop()


if __name__ == "__main__":
    if '--moderno' in sys.argv:
        from ensaio_visual_moderno import executar
        executar()
        sys.exit(0)
    if '--autoteste' in sys.argv:
        from autoteste_laboratorio_tk import executar
        executar()
        sys.exit(0)
    from interface.registro_terminal import instalar_registro_terminal
    instalar_registro_terminal()
    while True:
        ensaio = EnsaioVisual()
        ensaio.executar()
        if not ensaio.reiniciar_solicitado:
            break

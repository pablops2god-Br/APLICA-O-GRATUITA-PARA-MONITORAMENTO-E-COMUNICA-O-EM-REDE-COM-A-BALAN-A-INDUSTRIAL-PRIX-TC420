# Testes de arquivos configuracao integrados: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B2-B: funções reais, arquivos em memória, sem dados/rede/Tk reais."""
import ast
import json
from pathlib import Path
import threading
import traceback
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from config import configuracao
from config.arquivos import ContextoArquivosConfiguracao
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from test_delimitacao_arquivos_locais import ArquivoMemoria
import test_infraestrutura_cliente as infraestrutura_falsa
import test_login_manual_http as janela_falsa


# Grupo de 32 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class ArquivosConfiguracaoIntegrados(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_recursos
        self.contexto = ContextoArquivosConfiguracao(self.infra)
        self.arquivos = []
        self.addCleanup(self.limpar)
        self.patches = patch.multiple(configuracao, existe_configuracao=Mock(return_value=True),
                                    obter_caminho_configuracao=Mock(return_value="virtual-simulado.json"))
        self.patches.start()
        self.addCleanup(self.patches.stop)

    def limpar(self):
        for arquivo in self.arquivos:
            arquivo.antes_close, arquivo.limpeza = None, None
            if not arquivo.closed:
                arquivo.close()

    def arquivo(self, *args, **kwargs):
        arquivo = ArquivoMemoria(*args, **kwargs)
        self.arquivos.append(arquivo)
        return arquivo

    def retrato(self):
        return self.registro.obter_retrato()["recursos"]

    def ler(self):
        return configuracao.carregar_configuracao(contexto_arquivos=self.contexto)

    def gravar(self):
        return configuracao.salvar_configuracao("estação-simulada", "host-simulado", "9800", "", False,
                                               contexto_arquivos=self.contexto)

    def confirmado(self, indice=0):
        estado = self.retrato()[indice]
        self.assertTrue(estado["encerramento_confirmado"])
        self.assertEqual("close_retornou_e_closed_true", estado["prova_fechamento"])
        return estado

    def negativo(self):
        estado = self.infra.avaliar()
        self.assertFalse(estado["cobertura_completa"])
        self.assertFalse(estado["encerramento_confirmado"])

    def thread(self, chamada):
        erros, resultados = [], []
        def executar():
            try:
                resultados.append(chamada())
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=executar, daemon=True)
        thread.start()
        return thread, resultados, erros

    def terminar(self, trabalho):
        trabalho[0].join(3)
        self.assertFalse(trabalho[0].is_alive())

    def test_01_leitura_reserva_antes_open_sem_locks_e_fecha(self):
        arquivo = self.arquivo('{"valor": 1}')
        def abrir(*args, **kwargs):
            estado, = self.retrato()
            self.assertEqual("arquivo_comum", estado["tipo"])
            self.assertTrue(estado["criacao_em_curso"])
            self.assertFalse(estado["publicado"])
            for lock in (self.registro._lock, self.contexto._lock):
                self.assertTrue(lock.acquire(blocking=False))
                lock.release()
            return arquivo
        with patch("builtins.open", side_effect=abrir) as chamada:
            self.assertEqual({"valor": 1}, self.ler())
        chamada.assert_called_once_with("virtual-simulado.json", "r", encoding="utf-8")
        self.confirmado()
        self.assertEqual([], self.contexto.obter_pendencias())

    def test_02_escrita_preserva_formato_campos_retorno(self):
        arquivo = self.arquivo("")
        with patch("builtins.open", return_value=arquivo) as chamada:
            dados = self.gravar()
        chamada.assert_called_once_with("virtual-simulado.json", "w", encoding="utf-8")
        self.assertEqual(json.dumps(dados, indent=4, ensure_ascii=False), arquivo.texto_fechado)
        self.assertEqual({"nome_rede", "ip", "porta", "usuario", "salvar_login"}, set(dados))
        self.assertEqual(9800, dados["porta"])
        self.assertIs(False, dados["salvar_login"])
        self.confirmado()

    def test_03_inexistente_na_prechecagem_sem_abertura_ficticia(self):
        with patch.object(configuracao, "existe_configuracao", return_value=False), patch("builtins.open") as abrir:
            self.assertIsNone(self.ler())
        abrir.assert_not_called()
        self.assertEqual([], self.retrato())

    def test_04_desaparece_entre_prechecagem_e_open(self):
        original = FileNotFoundError("ausente_simulado")
        with patch("builtins.open", side_effect=original):
            self.assertIsNone(self.ler())  # Política histórica de leitura.
            with self.assertRaises(FileNotFoundError) as erro:
                self.gravar()
        self.assertIs(original, erro.exception)
        for estado in self.retrato():
            self.assertTrue(estado["erros_criacao"])
            self.assertFalse(estado["criacao_resolvida"])
            self.assertFalse(estado["ausencia_comprovada"])
        self.assertEqual([], self.contexto.obter_pendencias())

    def test_05_json_invalido_mantem_none_e_evidencia(self):
        with patch("builtins.open", return_value=self.arquivo("{invalido")):
            self.assertIsNone(self.ler())
        self.assertTrue(self.confirmado()["erros_atendimento"])

    def test_06_falha_antes_open_resolve_ausencia(self):
        original = RuntimeError("antes_simulado")
        with patch.object(self.registro, "criar", side_effect=original), patch("builtins.open") as abrir:
            with self.assertRaises(RuntimeError) as erro:
                self.ler()
        self.assertIs(original, erro.exception)
        abrir.assert_not_called()
        self.assertTrue(self.retrato()[0]["ausencia_comprovada"])
        self.assertTrue(self.retrato()[0]["encerramento_confirmado"])

    def test_07_falha_apos_associar_fecha_handle(self):
        arquivo = self.arquivo()
        original = RuntimeError("publicacao_simulada")
        criar = self.registro.criar
        def falhar(identidade, fabrica):
            return criar(identidade, fabrica, preparar=Mock(side_effect=original))
        with patch.object(self.registro, "criar", side_effect=falhar), patch("builtins.open", return_value=arquivo):
            with self.assertRaises(RuntimeError) as erro:
                self.ler()
        self.assertIs(original, erro.exception)
        self.assertTrue(arquivo.closed)
        self.assertFalse(self.confirmado()["publicado"])
        self.negativo()

    def test_08_publicacao_falha_antes_associacao_retem_responsabilidade(self):
        arquivo = self.arquivo()
        def falhar(identidade, fabrica):
            fabrica()
            raise RuntimeError("associacao_simulada")
        with patch.object(self.registro, "criar", side_effect=falhar), patch("builtins.open", return_value=arquivo):
            with self.assertRaises(RuntimeError):
                self.ler()
        self.assertTrue(arquivo.closed)
        estado, = self.retrato()
        self.assertFalse(estado["encerramento_confirmado"])
        self.assertFalse(estado["criacao_resolvida"])
        self.assertEqual([], self.contexto.obter_pendencias())
        evidencia, = self.contexto.obter_historico()
        self.assertTrue(evidencia["closed_observado"])
        self.assertTrue(evidencia["limpeza_comprovada"])
        self.assertFalse(evidencia["handle_retido"])
        self.negativo()

    def test_09_erro_leitura_preservado_com_politica_none(self):
        original = OSError("leitura_simulada")
        with patch("builtins.open", return_value=self.arquivo(leitura=original)):
            self.assertIsNone(self.ler())
        self.assertTrue(self.confirmado()["erros_atendimento"])
        self.assertIn("read", [f.name for f in traceback.extract_tb(original.__traceback__)])

    def test_10_erro_escrita_instancia_e_traceback_originais(self):
        original = OSError("escrita_simulada")
        with patch("builtins.open", return_value=self.arquivo(escrita=original)):
            try:
                self.gravar()
            except OSError as erro:
                self.assertIs(original, erro)
                self.assertIn("write", [f.name for f in traceback.extract_tb(erro.__traceback__)])
            else:
                self.fail("erro primário ausente")
        self.assertTrue(self.confirmado()["erros_atendimento"])

    def test_11_close_falha_observavel_sem_sucesso(self):
        limpeza = RuntimeError("limpeza_simulada")
        with patch("builtins.open", return_value=self.arquivo(limpeza=limpeza)):
            with self.assertRaises(RuntimeError) as erro:
                self.ler()
        self.assertIs(limpeza, erro.exception)
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
        self.assertTrue(self.retrato()[0]["erros_limpeza"])
        self.assertEqual("falha_operacao", self.contexto.obter_pendencias()[0]["erro_limpeza"])

    def test_12_primario_e_limpeza_distintos_com_traceback(self):
        original, limpeza = OSError("escrita_simulada"), RuntimeError("limpeza_simulada")
        with patch("builtins.open", return_value=self.arquivo(escrita=original, limpeza=limpeza)):
            try:
                self.gravar()
            except OSError as erro:
                self.assertIs(original, erro)
                self.assertIs(limpeza, erro.__cause__)
                self.assertIn("write", [f.name for f in traceback.extract_tb(erro.__traceback__)])
            else:
                self.fail("erro primário ausente")
        estado, = self.retrato()
        self.assertTrue(estado["erros_atendimento"])
        self.assertTrue(estado["erros_limpeza"])
        self.assertFalse(estado["encerramento_confirmado"])

    def test_13_closed_indisponivel_conservador(self):
        arquivo = SimpleNamespace(read=lambda: "{}", close=Mock())
        with patch("builtins.open", return_value=arquivo):
            with self.assertRaises(AttributeError):
                self.ler()
        arquivo.close.assert_called_once()
        self.assertTrue(self.retrato()[0]["erros_evidencia"])
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])

    def test_14_closed_false_nao_prova_fechamento(self):
        arquivo = SimpleNamespace(read=lambda: "{}", close=Mock(), closed=False)
        with patch("builtins.open", return_value=arquivo):
            self.assertEqual({}, self.ler())
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
        self.assertEqual(1, len(self.contexto.obter_pendencias()))

    def test_15_sucessivas_ids_independentes_e_historico(self):
        with patch("builtins.open", side_effect=[self.arquivo(), self.arquivo("")]):
            self.ler()
            primeiro = self.retrato()[0]
            self.gravar()
        self.assertEqual(primeiro, self.retrato()[0])
        self.assertNotEqual(primeiro["recurso_id"], self.retrato()[1]["recurso_id"])
        self.assertNotEqual(primeiro["geracao_id"], self.retrato()[1]["geracao_id"])
        for indice in (0, 1):
            self.confirmado(indice)

    def test_16_preparacao_aplicacao_antes_leitor_nao_migra(self):
        with patch("builtins.open", return_value=self.arquivo()):
            self.ler()
        antigo = self.retrato()[0]
        leitor = RecursosLeitorCliente(self.infra)
        self.registro.promover(leitor.geracao_id)
        self.assertNotEqual(antigo["geracao_id"], leitor.geracao_id)
        self.assertEqual(antigo, self.retrato()[0])
        self.assertIs(self.infra, self.contexto._proprietario)
        self.assertIs(self.registro, self.contexto._registro)
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()["retentativas"])
        self.negativo()

    def test_17_corrida_a_abertura_tardia_apos_gate(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        arquivo = self.arquivo()
        def abrir(*args, **kwargs):
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("barreira_simulada")
            return arquivo
        with patch("builtins.open", side_effect=abrir) as chamada:
            trabalho = self.thread(self.ler)
            self.assertTrue(entrou.wait(3))
            self.registro.fechar_admissao()
            self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
            liberar.set()
            self.terminar(trabalho)
            with self.assertRaises(RuntimeError):
                self.gravar()
        self.assertEqual(1, chamada.call_count)
        self.assertIsInstance(trabalho[2][0], RuntimeError)
        self.confirmado()
        self.assertTrue(arquivo.closed)
        self.negativo()

    def test_18_corrida_b_consulta_durante_close_e_observacao(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        arquivo = self.arquivo()
        def bloquear():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("barreira_simulada")
        arquivo.antes_close = bloquear
        with patch("builtins.open", return_value=arquivo):
            trabalho = self.thread(self.ler)
            self.assertTrue(entrou.wait(3))
            for _ in range(10):
                estado, = self.retrato()
                self.assertTrue(estado["limpeza_em_curso"])
                self.assertFalse(estado["encerramento_confirmado"])
                self.negativo()
            liberar.set()
            self.terminar(trabalho)
        self.assertEqual([], trabalho[2])
        self.confirmado()

    def test_19_corrida_c_leitura_escrita_simultaneas(self):
        barreira, liberar = threading.Barrier(3), threading.Event()
        self.addCleanup(liberar.set)
        leitura, escrita = self.arquivo(), self.arquivo("")
        def abrir(caminho, modo, **kwargs):
            barreira.wait(3)
            if not liberar.wait(3):
                raise TimeoutError("barreira_simulada")
            return leitura if modo == "r" else escrita
        with patch("builtins.open", side_effect=abrir):
            ler, gravar = self.thread(self.ler), self.thread(self.gravar)
            barreira.wait(3)
            self.assertEqual(2, len({r["recurso_id"] for r in self.retrato()}))
            self.assertTrue(all(not r["encerramento_confirmado"] for r in self.retrato()))
            liberar.set()
            self.terminar(ler)
            self.terminar(gravar)
        self.assertEqual([], ler[2] + gravar[2])
        self.assertTrue(leitura.closed and escrita.closed)
        self.confirmado(0)
        self.confirmado(1)

    def test_20_corrida_d_erro_primario_durante_limpeza_pendente(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        original, limpeza = OSError("escrita_simulada"), RuntimeError("limpeza_simulada")
        arquivo = self.arquivo(escrita=original, limpeza=limpeza)
        def bloquear():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("barreira_simulada")
        arquivo.antes_close = bloquear
        with patch("builtins.open", return_value=arquivo):
            trabalho = self.thread(self.gravar)
            self.assertTrue(entrou.wait(3))
            self.assertTrue(self.retrato()[0]["erros_atendimento"])
            self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
            liberar.set()
            self.terminar(trabalho)
        self.assertIs(original, trabalho[2][0])
        self.assertIs(limpeza, original.__cause__)
        self.assertTrue(self.retrato()[0]["erros_limpeza"])
        self.negativo()

    def test_21_imagens_keyring_e_socket_sem_arquivo_ficticio(self):
        raiz = Path(__file__).resolve().parents[1]
        arvore = ast.parse((raiz / "interface/janela.py").read_text(encoding="utf-8"))
        imagens = [n for n in ast.walk(arvore) if isinstance(n, ast.Assign)
                   and isinstance(n.value, ast.Call) and ast.unparse(n.value.func) == "tk.PhotoImage"]
        self.assertEqual(2, len(imagens))
        ambiente = dict(tk=SimpleNamespace(PhotoImage=Mock()), self=SimpleNamespace(),
                        _caminho_asset=lambda nome: nome,
                        os=__import__("os"), __file__=str(raiz / "interface/janela.py"))
        exec(compile(ast.Module(body=imagens, type_ignores=[]), "imagens_simuladas", "exec"), ambiente)
        with patch.object(configuracao.keyring, "set_password"), \
                patch.object(configuracao.keyring, "get_password", return_value=None), \
                patch.object(configuracao.keyring, "delete_password"):
            configuracao.salvar_senha("usuario-simulado", "valor-simulado")
            configuracao.carregar_senha("usuario-simulado")
            configuracao.remover_senha("usuario-simulado")
        self.assertEqual([], self.retrato())
        leitor = RecursosLeitorCliente(self.infra)
        socket = SimpleNamespace(close=Mock(), makefile=Mock(return_value=self.arquivo()))
        conectado = leitor.abrir_socket(lambda: socket)
        conectado.makefile("r", encoding="utf-8")
        antes = self.retrato()
        with patch("builtins.open", return_value=self.arquivo()):
            self.ler()
        self.assertEqual(antes, self.retrato()[:-1])
        self.assertEqual(["socket_tcp", "arquivo_socket", "arquivo_comum"],
                         [r["tipo"] for r in self.retrato()])

    def test_22_leitura_com_dupla_falha_mantem_none_sem_apagar_limpeza(self):
        original, limpeza = ValueError("leitura_simulada"), RuntimeError("limpeza_simulada")
        with patch("builtins.open", return_value=self.arquivo(leitura=original, limpeza=limpeza)):
            self.assertIsNone(self.ler())
        self.assertIs(limpeza, original.__cause__)
        self.assertTrue(self.retrato()[0]["erros_atendimento"])
        self.assertTrue(self.retrato()[0]["erros_limpeza"])
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])

    def test_23_isolado_preserva_primario_sem_alegar_cobertura(self):
        original, limpeza = OSError("escrita_simulada"), RuntimeError("limpeza_simulada")
        with patch("builtins.open", return_value=self.arquivo(escrita=original, limpeza=limpeza)):
            with self.assertRaises(OSError) as erro:
                configuracao.salvar_configuracao("simulado", "simulado", 9800, "", False)
        self.assertIs(original, erro.exception)
        self.assertIs(limpeza, original.__cause__)
        self.assertEqual([], self.retrato())
        self.negativo()

    def test_24_fechamento_repetido_nao_apaga_historico(self):
        with patch("builtins.open", return_value=self.arquivo(limpeza=RuntimeError("limpeza_simulada"))):
            with self.assertRaises(RuntimeError):
                self.ler()
        identidade, pendencia = next(iter(self.contexto._pendentes.items()))
        anterior = self.retrato()[0]["erros_limpeza"]
        pendencia["arquivo"].limpeza = None
        self.contexto._fechar(identidade, pendencia["arquivo"])
        self.contexto._fechar(identidade, pendencia["arquivo"])
        self.assertEqual(anterior, self.retrato()[0]["erros_limpeza"])
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])

    def test_25_integracao_main_login_automatico_arquivo_real_simulado(self):
        fixture = infraestrutura_falsa.InfraestruturaCliente()
        fixture.setUp()
        fixture.env["buscar_servidor"].return_value = None
        fixture.env["carregar_configuracao"] = configuracao.carregar_configuracao
        dados = json.dumps(dict(salvar_login=True, ip="simulado", usuario="simulado"))
        with patch("builtins.open", return_value=self.arquivo(dados)):
            fixture.env["iniciar"]()
        infra = fixture.monitores[-1].infraestrutura_cliente
        estado, = infra.registro_recursos.obter_retrato()["recursos"]
        self.assertEqual("arquivo_comum", estado["tipo"])
        self.assertTrue(estado["encerramento_confirmado"])
        self.assertEqual([], self.retrato())  # Não usou o registro do ensaio externo.

    def test_26_integracao_main_promocao_arquivo_aplicacao(self):
        fixture = infraestrutura_falsa.InfraestruturaCliente()
        fixture.setUp()
        fixture.env["carregar_configuracao"] = configuracao.carregar_configuracao
        resultados = fixture.preparar_promocao()
        dados = json.dumps(dict(salvar_login=True, ip="simulado", usuario="simulado"))
        with patch("builtins.open", return_value=self.arquivo(dados)):
            fixture.env["iniciar"]()
        self.assertIsNotNone(resultados[0])
        infra = fixture.monitores[-1].infraestrutura_cliente
        estado, = infra.registro_recursos.obter_retrato()["recursos"]
        self.assertTrue(estado["encerramento_confirmado"])
        self.assertNotEqual(fixture.leitores[0].recursos_cliente.geracao_id, estado["geracao_id"])

    def test_27_integracao_main_manual_leitura_escrita_mesmo_contexto(self):
        fixture = infraestrutura_falsa.InfraestruturaCliente()
        ui = janela_falsa.LoginManualHttp()
        fixture.setUp()
        ui.setUp()
        fixture.env["buscar_servidor"].return_value = None
        fixture.env["carregar_configuracao"] = configuracao.carregar_configuracao
        ui.env["carregar_configuracao"] = configuracao.carregar_configuracao
        ui.env["salvar_configuracao"] = configuracao.salvar_configuracao
        janelas = []
        def criar(**kwargs):
            infra = kwargs.pop("infraestrutura_cliente")
            janela = ui.criar_janela(infra, **kwargs)
            janela.root.mainloop = janela.conectar
            janelas.append(janela)
            return janela
        fixture.env["JanelaConexao"] = criar
        # Automático sem credenciais salvas, leitura da janela e escrita manual.
        with patch("builtins.open", side_effect=[self.arquivo(), self.arquivo(), self.arquivo("")]), ui.transporte():
            fixture.env["iniciar"]()
        janela, = janelas
        contexto = janela._contexto_arquivos
        self.assertIs(contexto._proprietario, janela.infraestrutura_cliente)
        self.assertIs(contexto._registro, janela.infraestrutura_cliente.registro_recursos)
        arquivos = [r for r in contexto._registro.obter_retrato()["recursos"] if r["tipo"] == "arquivo_comum"]
        self.assertEqual(3, len(arquivos))
        self.assertTrue(all(r["encerramento_confirmado"] for r in arquivos))
        self.assertEqual(3, len({r["recurso_id"] for r in arquivos}))

    def test_28_falha_publicacao_e_cleanup_retem_handle_e_ambos_erros(self):
        original, limpeza = RuntimeError("publicacao_simulada"), OSError("limpeza_simulada")
        arquivo = self.arquivo(limpeza=limpeza)
        def falhar(identidade, fabrica):
            fabrica()
            raise original
        with patch.object(self.registro, "criar", side_effect=falhar), patch("builtins.open", return_value=arquivo):
            with self.assertRaises(RuntimeError) as erro:
                self.ler()
        self.assertIs(original, erro.exception)
        self.assertIs(limpeza, original.__cause__)
        pendencia, = self.contexto.obter_pendencias()
        self.assertEqual("falha_io", pendencia["erro_limpeza"])
        self.assertIs(arquivo, next(iter(self.contexto._pendentes.values()))["arquivo"])
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])

    def test_29_close_retornou_mas_observacao_pendente_nao_confirma(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        caso = self
        class ArquivoObservado:
            fisicamente_fechado = False
            def read(self):
                return "{}"
            def close(self):
                self.fisicamente_fechado = True
            @property
            def closed(self):
                caso.assertTrue(self.fisicamente_fechado)
                entrou.set()
                if not liberar.wait(3):
                    raise TimeoutError("barreira_simulada")
                return True
        arquivo = ArquivoObservado()
        with patch("builtins.open", return_value=arquivo):
            trabalho = self.thread(self.ler)
            self.assertTrue(entrou.wait(3))
            self.assertTrue(arquivo.fisicamente_fechado)
            self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
            self.assertIsNone(self.retrato()[0]["prova_fechamento"])
            liberar.set()
            self.terminar(trabalho)
        self.assertEqual([], trabalho[2])
        self.confirmado()

    def test_30_promocao_e_novo_arquivo_preservam_antigo_pendente(self):
        antigo = self.arquivo(limpeza=RuntimeError("limpeza_simulada"))
        with patch("builtins.open", return_value=antigo):
            with self.assertRaises(RuntimeError):
                self.ler()
        antes = self.retrato()[0]
        leitor = RecursosLeitorCliente(self.infra)
        self.registro.promover(leitor.geracao_id)
        with patch("builtins.open", return_value=self.arquivo("") ):
            self.gravar()
        self.assertEqual(antes, self.retrato()[0])
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
        self.confirmado(1)
        self.assertIs(antigo, next(iter(self.contexto._pendentes.values()))["arquivo"])
        self.negativo()

    def test_31_admissao_preparacao_fechada_nao_abre(self):
        self.infra.registro_retentativas.fechar_admissao()
        with patch("builtins.open") as abrir:
            with self.assertRaisesRegex(RuntimeError, "admissao_preparacao_arquivo_recusada"):
                self.ler()
        abrir.assert_not_called()
        self.assertEqual([], self.retrato())

    def test_32_validacao_escrita_anterior_nao_inventa_abertura(self):
        with patch("builtins.open") as abrir:
            with self.assertRaises(ValueError):
                configuracao.salvar_configuracao("simulado", "simulado", "invalida", "", False,
                                                contexto_arquivos=self.contexto)
        abrir.assert_not_called()
        self.assertEqual([], self.retrato())

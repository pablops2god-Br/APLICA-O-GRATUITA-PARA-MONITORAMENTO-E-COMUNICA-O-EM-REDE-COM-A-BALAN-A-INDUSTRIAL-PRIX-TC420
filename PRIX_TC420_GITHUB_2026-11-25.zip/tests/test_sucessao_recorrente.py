"""Fila recorrente A/B: leitores/eventos reais, transporte e credenciais simulados."""
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from rede.lerdadosserver import LeitorDadosServidor
from rede.promocao_manual import tentar_recuperacao_automatica
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente


def amostra():
    return dict(estado='00', peso_bruto='20', peso_liquido='20', tara='0',
                unidade='kg', multirange='1')


class SucessaoRecorrente(unittest.TestCase):
    def leitor(self, prova=True):
        leitor = LeitorDadosServidor(permitir_candidatura=False)
        leitor.executando = True
        autorizar = Mock(return_value=prova)
        leitor.preparar_sucessao_recuperada(autorizar)
        self.addCleanup(leitor.parar)
        return leitor, autorizar

    def test_rearma_somente_apos_register_amostra_e_prova(self):
        leitor, autorizar = self.leitor(False)
        leitor._publicar_mensagem_valida(amostra(), 1)
        self.assertFalse(leitor.permitir_candidatura)
        leitor.posicao_sucessao = 1
        leitor._publicar_mensagem_valida(amostra(), 2)
        self.assertFalse(leitor.permitir_candidatura)
        autorizar.return_value = True
        leitor._publicar_mensagem_valida(amostra(), 3)
        self.assertTrue(leitor.permitir_candidatura)
        self.assertFalse(leitor.candidatura_esta_liberada())  # Ainda conectado.

    def test_posicao_invalida_e_prova_incerta_nao_rearmam(self):
        for posicao, prova in ((None, True), (True, True), (0, True), (1, None), (1, 1)):
            leitor, _ = self.leitor(prova)
            leitor.posicao_sucessao = posicao
            leitor._publicar_mensagem_valida(amostra(), 1)
            self.assertFalse(leitor.permitir_candidatura)

    def candidatar(self, leitor):
        leitor._marcar_comunicacao_indisponivel()
        with patch('rede.lerdadosserver.JANELA_SUCESSAO', 0), \
                patch('rede.lerdadosserver.buscar_servidor', return_value=None):
            return leitor._aguardar_candidatura()

    def test_a_b_a_b_recebem_nova_posicao_e_repetem_candidatura(self):
        # Cada rebaixamento publica uma geração nova. Sem novo REGISTER/amostra,
        # o nó recém-rebaixado não se promove imediatamente contra o sucessor.
        for pc in ('A', 'B', 'A', 'B'):
            with self.subTest(pc=pc):
                leitor, _ = self.leitor()
                self.assertFalse(self.candidatar(leitor))
                leitor.posicao_sucessao = 1
                leitor._publicar_mensagem_valida(amostra(), 1)
                self.assertTrue(self.candidatar(leitor))
                self.assertEqual('liberada', leitor.obter_estado_candidatura())
                self.assertTrue(leitor.candidatura_esta_liberada())

    def test_prova_revogada_bloqueia_candidatura_ja_rearmada(self):
        leitor, prova = self.leitor()
        leitor.posicao_sucessao = 1
        leitor._publicar_mensagem_valida(amostra(), 1)
        prova.return_value = False
        self.assertFalse(self.candidatar(leitor))
        self.assertFalse(leitor.candidatura_esta_liberada())

    def test_respeita_posicao_e_cancela_se_outro_principal_aparece(self):
        leitor, _ = self.leitor()
        leitor.posicao_sucessao = 2
        leitor._publicar_mensagem_valida(amostra(), 1)
        with patch('rede.lerdadosserver.buscar_servidor', return_value='principal-simulado'), \
                patch('rede.lerdadosserver.print') as imprimir:
            self.assertFalse(leitor._aguardar_candidatura())
        imprimir.assert_any_call('Candidatura liberada em 60 segundos.')
        self.assertEqual('cancelada', leitor.obter_estado_candidatura())

    def supervisor(self, leitor):
        return SimpleNamespace(vigente=lambda: True,
            saida=SimpleNamespace(ciclos_aptos_promocao=lambda: True),
            infraestrutura=InfraestruturaRegistrosCliente(), obter_leitor=lambda: leitor)

    def test_sem_login_salvo_retorna_para_formulario_manual(self):
        leitor, _ = self.leitor()
        leitor.posicao_sucessao = 1
        leitor._publicar_mensagem_valida(amostra(), 1)
        self.candidatar(leitor)
        with patch('config.configuracao.carregar_configuracao', return_value={'salvar_login': False}), \
                patch('config.configuracao.carregar_senha') as senha, \
                patch('rede.promocao_manual.promover_recuperado') as promover:
            self.assertFalse(tentar_recuperacao_automatica(self.supervisor(leitor)))
        senha.assert_not_called()
        promover.assert_not_called()
        self.assertEqual('liberada', leitor.obter_estado_candidatura())

    def test_login_salvo_usa_promocao_acompanhada_apenas_apos_fila(self):
        leitor, _ = self.leitor()
        supervisor = self.supervisor(leitor)
        config = dict(salvar_login=True, ip='fonte-simulada', usuario='simulado')
        with patch('config.configuracao.carregar_configuracao', return_value=config) as carregar, \
                patch('config.configuracao.carregar_senha', return_value='valor-simulado'), \
                patch('rede.promocao_manual.promover_recuperado', return_value={'sucesso': True}) as promover:
            self.assertFalse(tentar_recuperacao_automatica(supervisor))
            carregar.assert_not_called()
            leitor.posicao_sucessao = 1
            leitor._publicar_mensagem_valida(amostra(), 1)
            self.candidatar(leitor)
            self.assertEqual({'sucesso': True}, tentar_recuperacao_automatica(supervisor))
        promover.assert_called_once_with(supervisor, 'fonte-simulada', 'simulado', 'valor-simulado')

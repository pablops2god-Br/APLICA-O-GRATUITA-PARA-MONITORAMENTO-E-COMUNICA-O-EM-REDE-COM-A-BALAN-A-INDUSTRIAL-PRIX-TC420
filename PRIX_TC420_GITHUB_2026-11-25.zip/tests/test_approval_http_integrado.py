# Testes de approval http integrado: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.6: GET e parse reais; transporte, GUI e persistência simulados."""
from contextlib import contextmanager
from types import SimpleNamespace
import threading
import tkinter as tk
import unittest
from unittest.mock import Mock, patch
from urllib.parse import parse_qs, urlsplit
from uuid import uuid4

import requests

from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from tc420.web import WebTC420
from test_auditoria_http_arquivos_cliente import AdaptadorFalso, CorpoFalso
from test_registro_automatico import carregar_fluxos
import test_infraestrutura_cliente as fixtures
import test_login_http_integrado as login
import test_login_manual_http as manual


APROVACAO = b"SUCCESS:APPROVAL:<00W1.1;e=d=0.5;Min1;Max100>"
CONFIGURACAO = {"W1.1": {"divisao": "0.5", "min": "1", "max": "100"}}


# Grupo de 28 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class ApprovalHttpIntegrado(unittest.TestCase):
    iniciar_thread = login.LoginHttpIntegrado.iniciar_thread
    terminar = login.LoginHttpIntegrado.terminar
    bloquear = login.LoginHttpIntegrado.bloquear
    operacoes = login.LoginHttpIntegrado.operacoes
    negativo = login.LoginHttpIntegrado.negativo

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_http
        self.contexto = self.infra.preparar_http_inicial()
        self.web = WebTC420("balanca-simulada")
        self.web.token = "simulado"

    def executar(self, web=None, contexto=None):
        return self.infra.executar_approval(contexto or self.contexto, web or self.web)

    def transporte(self, texto=APROVACAO, **kwargs):
        return login.LoginHttpIntegrado.transporte(self, texto, **kwargs)

    @contextmanager
    def fluxo_http(self):
        # Uma Session temporária real para cada POST/GET, sem rede/netrc/proxy.
        class AdaptadorFluxo(AdaptadorFalso):
            def send(self, request, **kwargs):
                self.corpo = CorpoFalso([b"SUCCESS:LOGIN:simulado:simulado"
                                         if request.method == "POST" else APROVACAO])
                return super().send(request, **kwargs)
        adaptador = AdaptadorFluxo(CorpoFalso([]))
        classe = requests.Session
        def criar_sessao():
            sessao = classe()
            sessao.trust_env = False
            sessao.mount("https://", adaptador)
            return sessao
        with patch("requests.api.sessions.Session", side_effect=criar_sessao):
            yield adaptador

    def test_01_get_normal_com_parse_e_opcoes_originais(self):
        with self.transporte() as adaptador, patch("tc420.web.random.random", return_value=0.25):
            resultado = self.executar()
        self.assertEqual(CONFIGURACAO, resultado)
        self.assertEqual(1, len(adaptador.enviados))
        pedido, opcoes = adaptador.enviados[0]
        self.assertEqual("GET", pedido.method)
        self.assertEqual(self.web.url, pedido.url.split('?')[0])
        self.assertEqual(dict(cmd=["approval"], scale=["1"], token=["simulado"], math=["0.25"]),
                         parse_qs(urlsplit(pedido.url).query))
        self.assertIsNone(pedido.body)
        self.assertNotIn("Authorization", pedido.headers)
        self.assertEqual(5, opcoes["timeout"])
        self.assertFalse(opcoes["verify"])
        self.assertFalse(opcoes["stream"])
        op = self.operacoes()[0]
        self.assertEqual("approval", op["operacao"])
        self.assertEqual(self.contexto.geracao_id, op["geracao_id"])
        self.assertTrue(op["execucao_resolvida"])

    def test_02_negada_resolve_falha_sem_confundir_limpeza(self):
        antes = self.infra.registro_recursos.obter_retrato()
        with self.transporte(b"FAILURE:APPROVAL:simulado"):
            with self.assertRaisesRegex(RuntimeError, "Approval recusado pela TC420"):
                self.executar()
        op = self.operacoes()[0]
        self.assertEqual("falha", op["resultado"])
        self.assertTrue(op["execucao_resolvida"])
        self.assertEqual([], op["incertezas"])
        self.assertEqual(antes, self.infra.registro_recursos.obter_retrato())
        self.negativo()

    def test_03_http_4xx_5xx_mesma_response(self):
        for status in (401, 503):
            with self.subTest(status=status), self.transporte(status=status) as adaptador:
                with self.assertRaises(requests.HTTPError) as capturado:
                    self.executar()
            self.assertIs(adaptador.resposta, capturado.exception.response)
            self.assertEqual("falha", self.operacoes()[-1]["resultado"])

    def test_04_timeout_original_uma_tentativa(self):
        original = requests.Timeout("simulada")
        with self.transporte(erro=original) as adaptador:
            with self.assertRaises(requests.Timeout) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertEqual(1, len(adaptador.enviados))
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_05_conexao_original(self):
        original = requests.ConnectionError("simulada")
        with self.transporte(erro=original):
            with self.assertRaises(requests.ConnectionError) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertEqual("falha", self.operacoes()[0]["resultado"])

    def test_06_parse_invalido_e_tolerancia_previa_preservados(self):
        for texto in (b"invalida", b"SUCCESS:LOGIN:simulado"):
            with self.subTest(texto=texto), self.transporte(texto):
                with self.assertRaises(RuntimeError):
                    self.executar()
        with self.transporte(b"SUCCESS:APPROVAL:nao-reconhecido"):
            self.assertEqual({}, self.executar())
        self.assertEqual("retorno", self.operacoes()[-1]["resultado"])

    def test_07_pre_execucao_resolvida_com_prova(self):
        original = OSError("antes_inicio_simulado")
        with patch.object(self.registro, "_iniciar", side_effect=original), patch("requests.get") as enviar:
            with self.assertRaises(OSError) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        enviar.assert_not_called()
        op = self.operacoes()[0]
        self.assertFalse(op["inicio_confirmado"])
        self.assertTrue(op["execucao_resolvida"])
        self.assertEqual("nao_execucao_comprovada", op["publicacao_original"]["evidencia"])

    def test_08_admissao_recusada_nao_envia_get(self):
        self.registro.fechar_admissao()
        with patch("requests.get") as enviar:
            with self.assertRaisesRegex(RuntimeError, "admissao_operacao_http_recusada"):
                self.executar()
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())

    def test_09_duas_approval_mesma_origem_ids_e_erros_independentes(self):
        barreira = threading.Barrier(2)
        erro = requests.ConnectionError("simulada")
        segunda = WebTC420("segunda-simulada")
        segunda.token = "simulado"
        def enviar(url, **kwargs):
            barreira.wait(3)
            self.assertEqual(2, len(self.operacoes()))
            self.assertTrue(all(not o["execucao_resolvida"] for o in self.operacoes()))
            barreira.wait(3)
            if "segunda" in url:
                raise erro
            return Mock(text=APROVACAO.decode())
        with patch("tc420.web.requests.get", side_effect=enviar):
            a = self.iniciar_thread(self.executar)
            b = self.iniciar_thread(lambda: self.executar(segunda))
            ra, ea = self.terminar(a)
            rb, eb = self.terminar(b)
        self.assertEqual(([CONFIGURACAO], [], [], [erro]), (ra, ea, rb, eb))
        a, b = self.operacoes()
        self.assertNotEqual(a["operacao_id"], b["operacao_id"])
        self.assertEqual(a["geracao_id"], b["geracao_id"])
        self.assertEqual(("retorno", "falha"), (a["resultado"], b["resultado"]))

    def test_10_corrida_b_approval_e_login(self):
        barreira = threading.Barrier(2)
        erro = requests.Timeout("simulada")
        def obter(*args, **kwargs):
            barreira.wait(3)
            return Mock(text=APROVACAO.decode())
        def autenticar(*args, **kwargs):
            barreira.wait(3)
            raise erro
        with patch("tc420.web.requests.get", side_effect=obter), patch("tc420.web.requests.post", side_effect=autenticar):
            a = self.iniciar_thread(self.executar)
            b = self.iniciar_thread(lambda: self.infra.executar_login_automatico(
                WebTC420("automatico-simulado"), "simulado", "simulado"))
            ra, ea = self.terminar(a)
            rb, eb = self.terminar(b)
        self.assertEqual(([CONFIGURACAO], [], [], [erro]), (ra, ea, rb, eb))
        a, b = self.operacoes()
        self.assertEqual(("approval", "login"), (a["operacao"], b["operacao"]))
        self.assertNotEqual(a["geracao_id"], b["geracao_id"])
        self.assertNotEqual(a["operacao_id"], b["operacao_id"])

    def test_11_corrida_c_promocao_e_nova_geracao(self):
        dono = RecursosLeitorCliente(self.infra)
        contexto = self.infra.preparar_http_promocao(dono)
        entrou, liberar = threading.Event(), threading.Event()
        with self.transporte(antes=lambda: self.bloquear(entrou, liberar)):
            tarefa = self.iniciar_thread(lambda: self.executar(contexto=contexto))
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.operacoes()[0]
                self.registro.promover(dono.geracao_id)
                novo = RecursosLeitorCliente(self.infra)
                self.assertNotEqual(dono.geracao_id, novo.geracao_id)
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual(([CONFIGURACAO], []), (resultados, erros))
        depois = self.operacoes()[0]
        for campo in ("operacao_id", "geracao_id", "atividade_id"):
            self.assertEqual(antes[campo], depois[campo])
        self.assertEqual("principal", depois["modo_atual"])

    def test_12_corrida_d_publicacao_pendente_depois_parse(self):
        entrou, liberar = threading.Event(), threading.Event()
        publicar = self.registro.publicar
        def atrasar(op, recibo):
            self.bloquear(entrou, liberar)
            return publicar(op, recibo)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=atrasar):
            tarefa = self.iniciar_thread(self.executar)
            try:
                self.assertTrue(entrou.wait(3))
                op = self.operacoes()[0]
                self.assertTrue(op["publicacoes_pendentes"])
                self.assertFalse(op["execucao_resolvida"])
                self.negativo()
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual(([CONFIGURACAO], []), (resultados, erros))
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_13_duplicacao_mesmo_recibo_idempotente(self):
        publicar = self.registro.publicar
        def duplicar(op, recibo):
            self.assertTrue(publicar(op, recibo))
            return publicar(op, recibo)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=duplicar):
            self.executar()
        self.assertEqual(1, len(self.operacoes()))
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.assertEqual([], self.operacoes()[0]["conflitos_publicacao"])

    def test_14_retrato_nao_contem_token_resposta_url_ou_erro_integral(self):
        token, dado = uuid4().hex, uuid4().hex
        self.web.token = token
        with self.transporte(("FAILURE:APPROVAL:" + dado).encode()):
            with self.assertRaises(RuntimeError):
                self.executar()
        texto = repr(self.registro.obter_retrato())
        self.assertTrue(all(v not in texto for v in (token, dado, "https://", "Authorization")))
        self.assertTrue(self.operacoes()[0]["erros_execucao"])
        self.assertIsNotNone(self.operacoes()[0]["erro"])

    def test_15_corpo_recebido_com_close_falho_nao_prova_limpeza(self):
        original = OSError("limpeza_simulada")
        with self.transporte() as adaptador:
            adaptador.close = Mock(side_effect=original)
            with self.assertRaises(OSError) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertEqual(1, adaptador.corpo.lidos)
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.negativo()

    def test_16_global_nao_confirmado_mesmo_todos_gates_fechados(self):
        with self.transporte():
            self.executar()
        self.registro.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_17_corrida_a_reserva_e_rede_apos_gate_fechado(self):
        reservada, rede, liberar_partida, liberar_rede = [threading.Event() for _ in range(4)]
        executar = self.registro.executar
        def atrasar(op, chamada):
            self.bloquear(reservada, liberar_partida)
            return executar(op, chamada)
        with self.transporte(antes=lambda: self.bloquear(rede, liberar_rede)), \
                patch.object(self.registro, "executar", side_effect=atrasar):
            tarefa = self.iniciar_thread(self.executar)
            try:
                self.assertTrue(reservada.wait(3))
                antes = self.operacoes()[0]
                self.registro.fechar_admissao()
                liberar_partida.set()
                self.assertTrue(rede.wait(3))
                self.assertEqual("em_andamento", self.operacoes()[0]["estado"])
                self.assertFalse(self.registro.obter_retrato()["conjunto_http_resolvido"])
            finally:
                liberar_partida.set()
                liberar_rede.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual(([CONFIGURACAO], []), (resultados, erros))
        self.assertEqual(antes["operacao_id"], self.operacoes()[0]["operacao_id"])
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])

    def test_18_falha_publicacao_apos_sucesso_conservadora(self):
        original = OSError("publicacao_simulada")
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=original):
            with self.assertRaises(OSError) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])
        self.assertFalse(self.operacoes()[0]["execucao_resolvida"])

    def test_19_erro_original_prevalece_sobre_publicacao(self):
        original = requests.Timeout("simulada")
        with self.transporte(erro=original), patch.object(self.registro, "publicar", side_effect=ValueError()):
            with self.assertRaises(requests.Timeout) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertTrue(self.operacoes()[0]["erros_execucao"])
        self.assertFalse(self.operacoes()[0]["execucao_resolvida"])

    def test_20_tres_fluxos_reais_post_get_mesma_origem_sem_duplicacao(self):
        for fluxo in ("automatico", "promocao", "manual"):
            with self.subTest(fluxo=fluxo):
                inicio = len(self.operacoes())
                with self.fluxo_http() as adaptador:
                    if fluxo == "automatico":
                        env = carregar_fluxos()
                        env["WebTC420"].side_effect = WebTC420
                        resultado = env["tentar_login_automatico"](infraestrutura_cliente=self.infra)
                        self.assertEqual(CONFIGURACAO, resultado["configuracao"])
                    elif fluxo == "promocao":
                        fixture = fixtures.InfraestruturaCliente()
                        fixture.setUp()
                        fixture.env["buscar_servidor"].return_value = None
                        fixture.env["WebTC420"].side_effect = WebTC420
                        fixture.iniciar_cliente(self.infra)
                        resultado = fixture.monitores[0].ao_promover_automaticamente()
                        self.assertEqual(CONFIGURACAO, resultado["configuracao"])
                    else:
                        fixture = manual.LoginManualHttp()
                        fixture.setUp()
                        fixture.env["WebTC420"].side_effect = WebTC420
                        janela = fixture.criar_janela(self.infra)
                        janela.conectar()
                        self.assertEqual(CONFIGURACAO, janela.configuracao)
                self.assertEqual(["POST", "GET"], [r.method for r, _ in adaptador.enviados])
                ops = self.operacoes()[inicio:]
                self.assertEqual(["login", "approval"], [o["operacao"] for o in ops])
                self.assertNotEqual(ops[0]["operacao_id"], ops[1]["operacao_id"])
                self.assertEqual(ops[0]["geracao_id"], ops[1]["geracao_id"])
                self.assertEqual(ops[0]["atividade_id"], ops[1]["atividade_id"])
                self.assertTrue(all(o["execucao_resolvida"] for o in ops))

    def test_21_repeticao_mesma_origem_sem_criar_geracao(self):
        antes = self.infra.registro_retentativas.obter_retrato()
        with self.transporte() as adaptador:
            self.executar()
            self.executar()
        self.assertEqual(2, len(adaptador.enviados))
        self.assertEqual(2, len(self.operacoes()))
        self.assertEqual(antes, self.infra.registro_retentativas.obter_retrato())
        self.assertEqual({self.contexto.geracao_id}, {o["geracao_id"] for o in self.operacoes()})

    def test_22_contexto_estrangeiro_sem_fallback(self):
        contexto = InfraestruturaRegistrosCliente().preparar_http_inicial()
        with patch("requests.get") as enviar:
            with self.assertRaises(ValueError):
                self.executar(contexto=contexto)
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())

    def test_23_origem_mais_antiga_que_ultima_geracao(self):
        nova = self.infra.preparar_http_inicial()
        self.assertNotEqual(nova.geracao_id, self.contexto.geracao_id)
        with self.transporte():
            self.executar()
        self.assertEqual(self.contexto.geracao_id, self.operacoes()[0]["geracao_id"])

    def test_24_tk_destruido_durante_approval_sem_callback_novo(self):
        fixture = manual.LoginManualHttp()
        fixture.setUp()
        fixture.env["WebTC420"].side_effect = WebTC420
        janela = fixture.criar_janela(self.infra)
        entrou, liberar = threading.Event(), threading.Event()
        def obter(*args, **kwargs):
            self.bloquear(entrou, liberar)
            return Mock(text=APROVACAO.decode())
        with patch("tc420.web.requests.post", return_value=Mock(text="SUCCESS:LOGIN:simulado:simulado")), \
                patch("tc420.web.requests.get", side_effect=obter):
            tarefa = self.iniciar_thread(janela.conectar)
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual(["login", "approval"], [o["operacao"] for o in self.operacoes()])
                janela.root.destroy()
                self.assertFalse(self.operacoes()[1]["execucao_resolvida"])
                self.negativo()
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)  # B3 descarta o resultado apos destruicao.
        self.assertTrue(self.operacoes()[1]["execucao_resolvida"])
        self.assertEqual([], janela.root.agendados)

    def test_25_get_e_parse_sem_locks(self):
        def antes():
            for registro in (self.registro, self.infra.registro_recursos, self.infra.registro_retentativas):
                adquiriu = registro._lock.acquire(blocking=False)
                self.assertTrue(adquiriu)
                if adquiriu:
                    registro._lock.release()
            self.assertEqual("em_andamento", self.operacoes()[0]["estado"])
        with self.transporte(antes=antes):
            self.executar()

    def test_26_recurso_anterior_pendente_nao_e_resolvido(self):
        recursos = self.infra.registro_recursos
        token = recursos.reservar("arquivo_comum", self.contexto.geracao_id, self.contexto.atividade_id)
        recursos.criar(token, lambda: SimpleNamespace(closed=False, close=Mock(side_effect=OSError())))
        with self.assertRaises(OSError):
            recursos.fechar(token)
        antes = recursos.obter_retrato()
        with self.transporte():
            self.executar()
        self.assertEqual(antes, recursos.obter_retrato())
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.negativo()

    def test_27_admissao_fechada_apos_login_impede_get_operacional(self):
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        publicar = self.registro.publicar
        def fechar_apos_login(op, recibo):
            resultado = publicar(op, recibo)
            self.registro.fechar_admissao()
            return resultado
        with self.fluxo_http() as adaptador, patch.object(self.registro, "publicar", side_effect=fechar_apos_login):
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual(["login"], [o["operacao"] for o in self.operacoes()])
        env["definir_configuracao"].assert_not_called()

    def test_28_contexto_promocao_de_outro_leitor_recusado(self):
        dono = RecursosLeitorCliente(self.infra)
        outro = RecursosLeitorCliente(self.infra)
        contexto = self.infra.preparar_http_promocao(outro)
        with patch("requests.post") as enviar:
            with self.assertRaisesRegex(ValueError, "origem_http_invalida"):
                self.infra.executar_login_promocao(dono, self.web, "simulado", "simulado", contexto_http=contexto)
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())


if __name__ == "__main__":
    unittest.main()

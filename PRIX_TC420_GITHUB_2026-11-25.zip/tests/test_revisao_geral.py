"""Regressões da revisão geral: dependências externas controladas, sem TC420."""
import io
import runpy
import unittest
from pathlib import Path
from contextlib import ExitStack, redirect_stdout
from unittest.mock import Mock, mock_open, patch

from config.configuracao import carregar_configuracao
from interface.janela import JanelaTC420
from test_registro_automatico import carregar_fluxos, ThreadFila
from rede.servidor import RegistroTentativasAplicacao
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente


class RevisaoGeral(unittest.TestCase):
    def test_data_hora_avancam_com_peso_igual_sem_renovar_comunicacao(self):
        janela = self.monitor(label_atualizacao=Mock(), comunicacao_atual=lambda: False)
        with patch('interface.janela.datetime') as relogio, redirect_stdout(io.StringIO()) as terminal:
            relogio.now.return_value.astimezone.return_value.strftime.side_effect = [
                '23/11/2026 10:00:00', '23/11/2026 10:00:01']
            self.refresh(janela)
            self.refresh(janela)
        janela.label_atualizacao.config.assert_any_call(text='Atualização: 23/11/2026 10:00:00')
        janela.label_atualizacao.config.assert_any_call(text='Atualização: 23/11/2026 10:00:01')
        self.assertIn('[23/11/2026 10:00:01] Estado:', terminal.getvalue())
        self.assertFalse(janela.comunicacao_confirmada)
        self.assertEqual(janela.label_peso.config.call_args.kwargs['text'], '12')

    def test_refresh_sem_fonte_tambem_atualiza_data_hora(self):
        janela = self.monitor(label_atualizacao=Mock(), fonte_dados=None)
        with patch('interface.janela.datetime') as relogio:
            relogio.now.return_value.astimezone.return_value.strftime.return_value = '23/11/2026 11:00:00'
            self.refresh(janela)
        janela.label_atualizacao.config.assert_called_once_with(text='Atualização: 23/11/2026 11:00:00')

    def monitor(self, **mudancas):
        # Métodos reais, widgets simulados e nenhuma janela ou conexão aberta.
        janela = JanelaTC420.__new__(JanelaTC420)
        vars(janela).update(
            executando=True, comunicacao_atual=None, comunicacao_confirmada=True,
            modo_monitor='principal', obter_saude_principal=lambda: {'saudavel': False},
            fonte_dados=lambda: {'estado': '00', 'peso_liquido': '12', 'tara': '0',
                                 'unidade': 'kg', 'multirange': '1'},
            label_estado=Mock(), label_peso=Mock(), label_tara=Mock(),
            label_unidade=Mock(), label_faixa=Mock(), root=Mock(),
            botao_copiar_peso=Mock(), botao_copiar_tara=Mock(),
            img_zero=object(), img_estavel=object(), _agendar=Mock(),
            _sincronizar_status=Mock(), contextos_promocao=[],
        )
        vars(janela).update(mudancas)
        return janela

    def refresh(self, janela):
        with patch('interface.ciclo_tk.ativa', return_value=True):
            janela.atualizar_refresh_web()

    def test_json_valido_com_raiz_nao_objeto_nao_quebra_inicializacao(self):
        for texto in ('[]', 'null', 'true', '42', '"texto"'):
            with self.subTest(texto=texto), \
                    patch('config.configuracao.existe_configuracao', return_value=True), \
                    patch('builtins.open', mock_open(read_data=texto)):
                self.assertIsNone(carregar_configuracao())

    def test_principal_sem_saude_marca_ultima_leitura_e_bloqueia_copia(self):
        janela = self.monitor()
        self.refresh(janela)
        self.assertFalse(janela.comunicacao_confirmada)
        janela.label_faixa.config.assert_any_call(text='SEM COM.', fg='white', bg='#b00020')
        with patch('interface.janela.messagebox.showwarning'):
            self.assertFalse(janela.copiar_medicao('peso'))
        janela.root.clipboard_append.assert_not_called()

    def test_monitor_nao_libera_copia_antes_da_primeira_amostra(self):
        with ExitStack() as pilha:
            for nome in ('Tk', 'Frame', 'Label', 'Button', 'Menu', 'Canvas', 'PhotoImage'):
                pilha.enter_context(patch('interface.janela.tk.' + nome))
            janela = JanelaTC420()
        self.assertFalse(janela.comunicacao_confirmada)
        janela.botao_copiar_peso.config.assert_called_with(state='disabled', cursor='arrow')

    def test_falha_da_fonte_revoga_copia_previamente_habilitada(self):
        janela = self.monitor(fonte_dados=Mock(side_effect=RuntimeError('falha-simulada')))
        self.refresh(janela)
        self.assertFalse(janela.comunicacao_confirmada)
        janela.botao_copiar_peso.config.assert_called_with(state='disabled', cursor='arrow')
        janela._agendar.assert_called_once()

    def test_retorno_da_saude_restaura_medicao_e_copia(self):
        janela = self.monitor()
        self.refresh(janela)
        self.assertFalse(janela.comunicacao_confirmada)
        janela.obter_saude_principal = lambda: {'saudavel': True}
        self.refresh(janela)
        self.assertTrue(janela.comunicacao_confirmada)
        janela.botao_copiar_peso.config.assert_called_with(state='normal', cursor='hand2')

    def test_cabecalho_sem_configuracao_nao_inventa_limites(self):
        janela = self.monitor()
        janela.labels_configuracao = {
            faixa: {campo: Mock() for campo in ('max', 'min', 'divisao')}
            for faixa in ('W1.1', 'W1.2')}
        janela.atualizar_configuracao(None)
        janela.labels_configuracao['W1.1']['max'].config.assert_called_with(text='Max —')
        janela.labels_configuracao['W1.2']['divisao'].config.assert_called_with(text='e=d=—')

    def test_promocao_atualiza_cabecalho_para_novas_faixas(self):
        janela = self.monitor()
        janela.labels_configuracao = {
            faixa: {campo: Mock() for campo in ('max', 'min', 'divisao')}
            for faixa in ('W1.1', 'W1.2')}
        configuracao = {'W1.1': {'max': '500 kg', 'min': '5 kg', 'divisao': '1 kg'}}
        with patch('interface.ciclo_tk.ativa', return_value=True):
            janela.concluir_promocao({'web': object(), 'configuracao': configuracao,
                                     'fonte_dados': janela.fonte_dados})
        janela.labels_configuracao['W1.1']['max'].config.assert_called_with(text='Max 500 kg')
        janela.labels_configuracao['W1.2']['max'].config.assert_called_with(text='Max —')
        self.assertFalse(janela.comunicacao_confirmada)
        janela.botao_copiar_peso.config.assert_called_with(state='disabled', cursor='arrow')

    def test_servidor_automatico_sinaliza_retorno_mesmo_apos_excecao(self):
        ThreadFila.criadas = []
        ambiente = carregar_fluxos()
        ambiente['iniciar_servidor'].side_effect = RuntimeError('falha-simulada')
        resultado = ambiente['tentar_login_automatico'](
            RegistroTentativasAplicacao(), infraestrutura_cliente=InfraestruturaRegistrosCliente())
        with self.assertRaises(RuntimeError):
            ThreadFila.criadas[0].target()
        self.assertTrue(resultado['servidor_encerrado'].is_set())

    def test_ensaio_manual_nao_imprime_token_nem_corpo_de_erro(self):
        # Marcadores sintéticos permitem detectar exposição sem utilizar credenciais reais.
        web = Mock()
        web.login.return_value = 'marcador-sintetico-de-sessao'
        web.approval.side_effect = RuntimeError('Resposta inesperada da TC420: corpo-sintetico')
        texto = io.StringIO()
        with patch('builtins.input', return_value='usuario-simulado'), \
                patch('getpass.getpass', return_value='entrada-sintetica'), \
                patch('tc420.web.WebTC420', return_value=web), redirect_stdout(texto):
            runpy.run_path(str(Path(__file__).resolve().parents[1] / 'teste_approval.py'))
        self.assertNotIn('marcador-sintetico-de-sessao', texto.getvalue())
        self.assertNotIn('corpo-sintetico', texto.getvalue())


if __name__ == '__main__':
    unittest.main()

"""Persistência real em diretório temporário; nenhum cofre ou equipamento real."""
from pathlib import Path
import secrets
import tempfile
import unittest
from unittest.mock import patch
from config import administrador as admin


class AdministradorOperacional(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.config = Path(self.tmp.name) / 'configuracao.json'
        self.patch = patch('config.configuracao.obter_caminho_configuracao', return_value=str(self.config))
        self.patch.start()
        self.addCleanup(self.patch.stop)
        self.senha = secrets.token_urlsafe(16)

    def test_cadastro_persistente_sem_senha_clara(self):
        self.assertIsNone(admin.carregar())
        admin.cadastrar(self.senha)
        self.assertNotIn(self.senha, admin.caminho().read_text())
        self.assertTrue(admin.verificar(self.senha))
        self.assertFalse(admin.verificar(secrets.token_urlsafe(16)))
        with self.assertRaises(ValueError):
            admin.cadastrar(secrets.token_urlsafe(16))

    def test_metodo_tcp_preserva_verificador(self):
        admin.cadastrar(self.senha)
        original = admin.carregar()['resumo']
        admin.salvar_metodo('TCP')
        self.assertEqual(admin.carregar()['metodo'], 'TCP')
        self.assertEqual(admin.carregar()['resumo'], original)
        self.assertTrue(admin.verificar(self.senha))

    def test_cadastro_corrompido_nao_vira_primeiro_acesso(self):
        admin.caminho().write_text('{}')
        with self.assertRaises(ValueError):
            admin.carregar()

    def test_reset_apaga_apenas_escopo_autorizado(self):
        admin.cadastrar(self.senha)
        self.config.write_text('{"usuario":"usuario-sintetico"}')
        outro = self.config.with_name('outro.txt')
        outro.write_text('preservar')
        with patch('keyring.get_password', return_value=secrets.token_urlsafe(16)), \
             patch('keyring.delete_password') as remover:
            self.assertTrue(admin.restaurar())
            remover.assert_called_once()
        self.assertFalse(self.config.exists())
        self.assertIsNone(admin.carregar())
        self.assertTrue(outro.exists())

    def test_falha_cofre_nao_anuncia_reset_nem_apaga_cadastro(self):
        admin.cadastrar(self.senha)
        self.config.write_text('{"usuario":"usuario-sintetico"}')
        with patch('keyring.get_password', side_effect=OSError):
            with self.assertRaises(OSError):
                admin.restaurar()
        self.assertTrue(self.config.exists())
        self.assertTrue(admin.verificar(self.senha))

    def test_falha_gravacao_atomica_preserva_cadastro(self):
        admin.cadastrar(self.senha)
        with patch('config.administrador.os.replace', side_effect=OSError):
            with self.assertRaises(OSError):
                admin.salvar_metodo('TCP')
        self.assertTrue(admin.verificar(self.senha))
        self.assertEqual(admin.carregar()['metodo'], 'HTTPS')
        self.assertFalse(list(Path(self.tmp.name).glob('*.tmp')))

    def executar_loop_main(self, restaurar):
        """Executa o loop real do ponto de entrada sem importar/iniciar a rede."""
        import ast
        from unittest.mock import Mock
        arvore = ast.parse((Path(__file__).resolve().parents[1]/'main.py').read_text(encoding='utf-8'))
        entrada = arvore.body[-1]
        loop = next(n for n in entrada.body if isinstance(n, ast.While))
        chamadas = []
        preparar = Mock(return_value=(False, False))
        ambiente = dict(permitido=True, forcar=False, preparar_inicio=preparar)
        def iniciar(**kwargs):
            chamadas.append(kwargs['forcar_configuracao'])
            ambiente['_proxima_configuracao_administrativa'] = (
                {'restaurar': restaurar} if len(chamadas) == 1 else None)
        ambiente['iniciar'] = iniciar
        exec(compile(ast.Module(body=[loop], type_ignores=[]), 'loop_main', 'exec'), ambiente)
        return chamadas, preparar

    def test_reconfiguracao_preserva_autorizacao_sem_login_duplicado(self):
        chamadas, preparar = self.executar_loop_main(False)
        self.assertEqual(chamadas, [False, True])
        preparar.assert_not_called()

    def test_restauracao_reabre_cadastro_e_cancelamento_nao_inicia_rede(self):
        chamadas, preparar = self.executar_loop_main(True)
        self.assertEqual(chamadas, [False])
        preparar.assert_called_once_with(forcar=True, restaurar=True)

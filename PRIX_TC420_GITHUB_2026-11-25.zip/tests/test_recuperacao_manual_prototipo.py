"""Transições simuladas; sem Tk, credenciais, balança ou sockets de rede."""
import unittest
import json
import socket
from threading import Event, Thread
from unittest.mock import Mock, patch

from prototipos.recuperacao_manual import RecuperacaoManual, ciclo_resolvido
from rede import servidor
from rede.lerdadosserver import LeitorDadosServidor


class RecuperacaoManualTestes(unittest.TestCase):
    def modelo(self, resolvido=True):
        anterior, novo = object(), object()
        provas = {anterior: resolvido, novo: False}
        callbacks = dict(buscar=Mock(return_value=False), fonte=Mock(return_value=True),
                         preparar=Mock(return_value=novo), iniciar=Mock(),
                         pronto=Mock(return_value=True), vigente=Mock(return_value=True),
                         avaliar=lambda c: provas[c])
        return RecuperacaoManual([anterior], **callbacks), callbacks, provas, anterior, novo

    def test_manual_independente_da_automatica(self):
        m, cb, *_ = self.modelo()
        self.assertTrue(m.oferta_manual())
        cb['buscar'].assert_not_called()
        self.assertFalse(m.permitir_candidatura_automatica)
        self.assertEqual('automatica_desabilitada', m.solicitar_automatica())
        cb['iniciar'].assert_not_called()
        self.assertEqual('promovida', m.solicitar_manual())
        self.assertEqual(2, cb['buscar'].call_count)

    def test_pendente_incerto_e_valor_truthy_bloqueiam(self):
        for prova in (False, None, 1):
            with self.subTest(prova=prova):
                m, cb, *_ = self.modelo(prova)
                self.assertFalse(m.oferta_manual())
                self.assertEqual('ciclo_pendente', m.solicitar_manual())
                cb['buscar'].assert_not_called()
                cb['iniciar'].assert_not_called()

    def test_outro_principal_ou_busca_incerta(self):
        for resposta, esperado in ((True, 'principal_detectado'), (None, 'descoberta_incerta')):
            m, cb, *_ = self.modelo()
            cb['buscar'].return_value = resposta
            self.assertEqual(esperado, m.solicitar_manual())
            cb['fonte'].assert_not_called()
            cb['iniciar'].assert_not_called()

    def test_fonte_inacessivel_nao_promove(self):
        m, cb, *_ = self.modelo()
        cb['fonte'].return_value = False
        self.assertEqual('fonte_indisponivel', m.solicitar_manual())
        cb['preparar'].assert_not_called()

    def test_principal_aparece_durante_login(self):
        m, cb, *_ = self.modelo()
        cb['buscar'].side_effect = [False, True]
        self.assertEqual('principal_detectado', m.solicitar_manual())
        cb['iniciar'].assert_not_called()

    def test_prova_muda_durante_login(self):
        m, cb, provas, anterior, _ = self.modelo()
        def fonte():
            provas[anterior] = None
            return True
        cb['fonte'].side_effect = fonte
        self.assertEqual('ciclo_pendente', m.solicitar_manual())
        cb['iniciar'].assert_not_called()

    def test_cancelamento_durante_descoberta(self):
        m, cb, *_ = self.modelo()
        cb['buscar'].side_effect = lambda: (setattr(cb['vigente'], 'return_value', False), False)[1]
        self.assertEqual('ciclo_pendente', m.solicitar_manual())
        cb['iniciar'].assert_not_called()

    def test_falha_ou_ausencia_de_leitura_retém_partida(self):
        for excecao in (False, True):
            m, cb, provas, _, novo = self.modelo()
            if excecao:
                cb['iniciar'].side_effect = RuntimeError('simulado')
            else:
                cb['pronto'].return_value = False
            resultado = m.solicitar_manual()
            self.assertEqual('falha_sem_confirmacao' if excecao else 'partida_pendente', resultado)
            self.assertFalse(m.oferta_manual())
            self.assertEqual('ciclo_pendente', m.solicitar_manual())
            self.assertEqual(1, cb['iniciar'].call_count)
            provas[novo] = True  # Só prova positiva permite nova tentativa.
            self.assertTrue(m.oferta_manual())

    def test_erros_de_consulta_fecham_oferta(self):
        m, cb, *_ = self.modelo()
        m._avaliar = Mock(side_effect=ValueError('simulado'))
        self.assertFalse(m.oferta_manual())
        self.assertEqual('falha_sem_confirmacao', m.solicitar_manual())
        cb['iniciar'].assert_not_called()

    def test_contexto_ausente_ou_reutilizado(self):
        m, cb, _, anterior, _ = self.modelo()
        cb['preparar'].return_value = anterior
        self.assertEqual('contexto_invalido', m.solicitar_manual())
        cb['iniciar'].assert_not_called()
        m._contextos.clear()
        self.assertFalse(m.oferta_manual())

    def test_cliques_concorrentes_nao_duplicam_partida(self):
        m, cb, *_ = self.modelo()
        entrou, liberar = Event(), Event()
        def fonte():
            entrou.set()
            if not liberar.wait(2):
                raise TimeoutError('ensaio')
            return True
        cb['fonte'].side_effect = fonte
        resultados = []
        t = Thread(target=lambda: resultados.append(m.solicitar_manual()))
        t.start()
        try:
            self.assertTrue(entrou.wait(1))
            self.assertFalse(m.oferta_manual())
            self.assertEqual('ocupada', m.solicitar_manual())
        finally:
            liberar.set()
            t.join(3)
        self.assertFalse(t.is_alive())
        self.assertEqual(['promovida'], resultados)
        cb['iniciar'].assert_called_once()

    def test_sequencia_a_b_com_rebaixamentos_sucessivos(self):
        a, ca, pa, _, na = self.modelo()
        b, cb, pb, _, nb = self.modelo()
        # A já perdeu seu ciclo inicial; B assume por ação manual.
        self.assertEqual('promovida', b.solicitar_manual())
        ca['buscar'].return_value = True  # A encontra B e não pode promover.
        self.assertEqual('principal_detectado', a.solicitar_manual())
        self.assertFalse(b.observar_rebaixamento())  # B ainda tem responsabilidades.
        pb[nb] = True
        self.assertTrue(b.observar_rebaixamento())
        ca['buscar'].return_value = False
        self.assertTrue(a.oferta_manual())
        self.assertTrue(b.oferta_manual())
        self.assertEqual('promovida', a.solicitar_manual())
        cb['buscar'].return_value = True
        self.assertEqual('principal_detectado', b.solicitar_manual())
        # Recepção TCP real é deliberadamente fora do alcance deste modelo.
        self.assertFalse(b.permitir_candidatura_automatica)

    def test_adapter_exige_prova_real_e_retorno_do_coordenador(self):
        controle = servidor.ControleCicloServidor()
        registro = servidor.RegistroTrabalhadores()
        contexto = servidor.ContextoCicloServidor()
        with patch.object(servidor, 'controle_ciclo_servidor', controle):
            self.assertTrue(controle.tentar_iniciar(registro))
            contexto.registrar_reserva(registro.ciclo_id)
            self.assertFalse(ciclo_resolvido(contexto))
            registro.bloquear_criacao()
            controle.finalizar(registro)
            self.assertFalse(ciclo_resolvido(contexto))
            contexto.registrar_retorno_coordenador()
            self.assertTrue(ciclo_resolvido(contexto))

    def test_outro_pc_recebe_config_e_peso_em_localhost(self):
        # Serviço sintético de protocolo; leitor de produção e sockets reais.
        # Não inicia o servidor operacional, não descobre LAN nem acessa TC420.
        m, cb, *_ = self.modelo()
        escuta = socket.socket()
        escuta.bind(('127.0.0.1', 0))
        escuta.listen()
        escuta.settimeout(2)
        porta = escuta.getsockname()[1]
        liberar, amostra_recebida = Event(), Event()
        erros = []
        config = {'W1.1': {'max': '80000 kg', 'min': '200 kg', 'divisao': '10 kg'}}
        dados = dict(estado='00', peso_bruto='20', peso_liquido='20', tara='0',
                     unidade='kg', multirange='1')
        def servir():
            try:
                for esperado in ('CONFIG', 'REGISTER', 'SUBSCRIBE'):
                    with escuta.accept()[0] as conexao:
                        conexao.settimeout(2)
                        with conexao.makefile('r', encoding='utf-8') as arquivo:
                            comando = arquivo.readline().strip()
                            if comando.split('|')[0] != esperado:
                                raise AssertionError(comando)
                            resposta = (config if esperado == 'CONFIG' else
                                        {'nome': comando.split('|')[1], 'posicao': 1}
                                        if esperado == 'REGISTER' else dados)
                            conexao.sendall((json.dumps(resposta) + '\n').encode())
                            if esperado == 'SUBSCRIBE':
                                liberar.wait(2)
            except Exception as erro:
                erros.append(type(erro).__name__)
        thread = Thread(target=servir)
        cb['iniciar'].side_effect = lambda contexto: thread.start()
        leitor = LeitorDadosServidor('127.0.0.1', permitir_candidatura=False)
        publicar = leitor._publicar_mensagem_valida
        def receber(dados, instante):
            publicar(dados, instante)
            amostra_recebida.set()
        leitor._publicar_mensagem_valida = receber
        try:
            self.assertEqual('promovida', m.solicitar_manual())
            with patch('rede.lerdadosserver.PORTA_TCP', porta):
                leitor.iniciar()
                self.assertTrue(amostra_recebida.wait(2))
                self.assertEqual(config, leitor.obter_configuracao())
                self.assertEqual('20', leitor.obter_dados_atuais()['peso_liquido'])
                self.assertTrue(leitor.comunicacao_esta_atual())
        finally:
            leitor.parar()
            liberar.set()
            if leitor.thread is not None:
                leitor.thread.join(3)
                self.assertFalse(leitor.thread.is_alive())
            if thread.ident is not None:
                thread.join(3)
                self.assertFalse(thread.is_alive())
            escuta.close()
        self.assertEqual([], erros)

    def test_socket_real_ou_erro_de_limpeza_impedem_prova(self):
        for erro_limpeza in (False, True):
            controle = servidor.ControleCicloServidor()
            registro = servidor.RegistroTrabalhadores()
            contexto = servidor.ContextoCicloServidor()
            recurso = socket.socket()
            try:
                with patch.object(servidor, 'controle_ciclo_servidor', controle):
                    self.assertTrue(controle.tentar_iniciar(registro))
                    contexto.registrar_reserva(registro.ciclo_id)
                    reserva = registro.reservar_criacao_socket()
                    registro.anexar_socket(reserva, recurso)
                    registro.publicar_socket(reserva)
                    registro.bloquear_criacao()
                    if erro_limpeza:
                        registro.registrar_erro_limpeza('simulado')
                    controle.finalizar(registro)
                    contexto.registrar_retorno_coordenador()
                    self.assertFalse(ciclo_resolvido(contexto))
                    registro.encerrar_uso_socket(reserva)
                    registro.fechar_socket(reserva)
                    self.assertEqual(not erro_limpeza, ciclo_resolvido(contexto))
            finally:
                recurso.close()

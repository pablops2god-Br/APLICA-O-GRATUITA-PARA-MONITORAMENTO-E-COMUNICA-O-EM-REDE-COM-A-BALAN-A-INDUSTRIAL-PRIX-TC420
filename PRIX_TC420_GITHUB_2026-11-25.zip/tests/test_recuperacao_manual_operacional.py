"""Recuperação integrada: B2/registros/servidor reais, TC420 e descoberta simuladas."""
import socket
import unittest
from contextlib import ExitStack
from threading import Event, Thread
from time import monotonic
from types import SimpleNamespace
from unittest.mock import Mock, patch

from interface.saida_aplicacao import SaidaAplicacao
from rede import servidor, promocao_manual as promocao
from rede import buscarservidor as descoberta
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.lerdadosserver import LeitorDadosServidor


class RecuperacaoOperacional(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.controle = servidor.ControleCicloServidor()
        self.stack.enter_context(patch.object(servidor, 'controle_ciclo_servidor', self.controle))
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = servidor.RegistroTentativasAplicacao()
        self.saida = SaidaAplicacao(prazo=3, intervalo=.005)
        self.saida.configurar(self.infra, self.registro)
        self.fechar = self.saida.vincular('ensaio')
        self.leitor = LeitorDadosServidor(permitir_candidatura=False, infraestrutura_cliente=self.infra)
        self.leitor._manter_atualizado = lambda: self.leitor._parada.wait(3)
        self.leitor.iniciar()
        self.supervisao = SimpleNamespace(saida=self.saida, infraestrutura=self.infra,
            vigente=lambda: not self.saida.parada_solicitada,
            obter_leitor=lambda: self.leitor, solicitar_retomada=Mock())
        self.anterior = self.ciclo_resolvido()
        self.buscar = self.stack.enter_context(patch.object(promocao, 'buscar_servidor', return_value=None))
        self.amostra = dict(estado='00', peso_liquido='20', peso_bruto='20', tara='0',
                            unidade='kg', multirange='1')
        self.config = {'W1.1': {'min': '200 kg', 'max': '80000 kg', 'divisao': '10 kg'}}
        self.web = SimpleNamespace(token=object(), login=Mock(),
            obter_configuracao=Mock(return_value=self.config), obter_estado=Mock(return_value=self.amostra))
        self.fabrica = self.stack.enter_context(patch.object(promocao, 'WebTC420', return_value=self.web))
        self.stack.enter_context(patch.object(servidor, 'HOST', '127.0.0.1'))
        for nome, tipo in (('PORTA_TCP', socket.SOCK_STREAM), ('PORTA_DESCOBERTA', socket.SOCK_DGRAM)):
            with socket.socket(socket.AF_INET, tipo) as s:
                s.bind(('127.0.0.1', 0))
                self.stack.enter_context(patch.object(servidor, nome, s.getsockname()[1]))
        servidor.evento_parada_servidor.clear()
        self.addCleanup(self.limpar)

    def limpar(self):
        self.fechar()
        if self.saida._coordenacao is not None:
            self.saida._coordenacao.join(4)
        for item in self.saida._threads:
            t = item['thread']
            if t.ident is not None:
                t.join(2)
                self.assertFalse(t.is_alive())
        self.leitor.parar()
        self.leitor.thread.join(2)
        self.assertFalse(self.leitor.thread.is_alive())

    def ciclo_resolvido(self):
        contexto = servidor.ContextoCicloServidor()
        identidade = self.registro.admitir(contexto)
        self.registro.marcar_iniciando(identidade)
        self.registro.registrar_entrada_execucao(identidade)
        trabalhadores = servidor.RegistroTrabalhadores()
        self.assertTrue(self.controle.tentar_iniciar(trabalhadores))
        contexto.registrar_reserva(trabalhadores.ciclo_id)
        trabalhadores.bloquear_criacao()
        self.controle.finalizar(trabalhadores)
        contexto.registrar_retorno_coordenador()
        self.registro.marcar_iniciada(identidade)
        self.saida.acompanhar_contexto(contexto)
        return contexto

    def promover(self):
        return promocao.promover_recuperado(self.supervisao, 'fonte-simulada', 'simulado', 'valor-simulado')

    def test_promove_com_servicos_reais_config_subscribe_e_b2(self):
        resultado = self.promover()
        self.assertIsNotNone(resultado)
        contexto = resultado['contexto_ciclo']
        self.assertTrue(contexto.tcp_pronto.is_set())
        self.assertTrue(contexto.udp_pronto.is_set())
        self.assertTrue(contexto.dados_prontos.is_set())
        self.assertFalse(self.leitor.permitir_candidatura)
        self.supervisao.solicitar_retomada.assert_not_called()
        cliente = LeitorDadosServidor('127.0.0.1', permitir_candidatura=False,
                                     infraestrutura_cliente=self.infra)
        recebeu = Event()
        publicar = cliente._publicar_mensagem_valida
        cliente._publicar_mensagem_valida = lambda d, t: (publicar(d, t), recebeu.set())
        with patch('rede.lerdadosserver.PORTA_TCP', servidor.PORTA_TCP):
            cliente.iniciar()
            try:
                self.assertTrue(recebeu.wait(2))
                self.assertEqual(self.config, cliente.obter_configuracao())
                self.assertEqual('20', cliente.obter_dados_atuais()['peso_liquido'])
            finally:
                cliente.parar()
                cliente.thread.join(2)
        self.fechar()
        self.saida._coordenacao.join(4)
        self.assertTrue(self.saida.obter_situacao()['parada_operacional_confirmada'])

    def test_principal_detectado_nao_parte(self):
        self.buscar.return_value = 'principal-simulado'
        self.assertIsNone(self.promover())
        self.fabrica.assert_not_called()
        self.assertEqual(1, len(self.registro.obter_retrato()['tentativas']))

    def test_descobertas_instrumentadas_nao_impedem_revalidacao(self):
        def descobrir(infraestrutura_cliente, **kwargs):
            return infraestrutura_cliente.executar_descoberta_preparacao(
                lambda recursos: recursos.executar_descoberta(
                    'socket_udp', lambda: socket.socket(socket.AF_INET, socket.SOCK_DGRAM),
                    lambda udp: None))
        self.buscar.side_effect = descobrir
        self.assertIsNotNone(self.promover())
        self.assertEqual(2, self.buscar.call_count)

    def test_recusa_por_pendencia_http_e_erro_limpeza(self):
        origem = self.infra.preparar_http_inicial()
        operacao = self.infra.registro_http.admitir(origem, 'login')
        self.assertIsNotNone(operacao)
        self.assertIsNone(self.promover())
        self.buscar.assert_not_called()

    def test_rebaixamento_e_nova_promocao_no_mesmo_dono(self):
        primeiro = self.promover()
        self.assertIsNotNone(primeiro)
        servidor.solicitar_parada_ciclo(primeiro['contexto_ciclo'].ciclo_id)
        for item in self.saida._threads:
            item['thread'].join(3)
        self.assertTrue(self.saida.ciclos_aptos_promocao())
        self.leitor = LeitorDadosServidor(permitir_candidatura=False, infraestrutura_cliente=self.infra)
        self.leitor._manter_atualizado = lambda: self.leitor._parada.wait(3)
        self.leitor.iniciar()
        segundo = self.promover()
        self.assertIsNotNone(segundo)
        self.assertNotEqual(primeiro['contexto_ciclo'].ciclo_id, segundo['contexto_ciclo'].ciclo_id)
        self.assertTrue(servidor.avaliar_encerramento_tentativa(
            primeiro['contexto_ciclo'])['encerramento_confirmado'])
        self.assertFalse(self.leitor.permitir_candidatura)

    def test_principal_aparece_apos_login(self):
        self.buscar.side_effect = [None, 'principal-simulado']
        self.assertIsNone(self.promover())
        self.assertEqual(1, len(self.registro.obter_retrato()['tentativas']))

    def test_descoberta_incerta_recusa_sem_start(self):
        self.buscar.side_effect = OSError('simulado')
        self.assertIsNone(self.promover())
        self.fabrica.assert_not_called()

    def test_descoberta_estrita_distingue_timeout_de_erro(self):
        udp = Mock()
        udp.recvfrom.side_effect = socket.timeout()
        self.assertIsNone(descoberta._buscar_observado(udp, None, estrito=True))
        udp.recvfrom.side_effect = OSError('simulado')
        with self.assertRaises(OSError):
            descoberta._buscar_observado(udp, None, estrito=True)
        udp.sendto.side_effect = socket.timeout()
        with self.assertRaises(socket.timeout):
            descoberta._buscar_observado(udp, None, estrito=True)

    def test_resposta_udp_sem_check_valido_e_incerta(self):
        udp = Mock()
        udp.recvfrom.return_value = (descoberta.RESPOSTA_DESCOBERTA.encode(), ('127.0.0.1', 1))
        with patch.object(descoberta, 'confirmar_servidor', return_value=False):
            with self.assertRaises(RuntimeError):
                descoberta._buscar_observado(udp, None, estrito=True)

    def test_fonte_inacessivel(self):
        self.web.obter_estado.side_effect = TimeoutError('simulado')
        self.assertIsNone(self.promover())
        self.assertEqual(1, len(self.registro.obter_retrato()['tentativas']))

    def test_revalidacao_cliente_recusada_informa_motivo_sem_partida(self):
        with patch.object(promocao, 'cliente_resolvido', side_effect=[True, False]), \
                patch('builtins.print') as imprimir:
            self.assertIsNone(self.promover())
        imprimir.assert_any_call(
            'PROMOCAO: recusada; responsabilidades CLIENTE pendentes após acesso à fonte.')
        self.assertEqual(1, len(self.registro.obter_retrato()['tentativas']))

    def test_ciclo_pendente_recusa_antes_de_parar_cliente(self):
        c = servidor.ContextoCicloServidor()
        identidade = self.registro.admitir(c)
        self.registro.marcar_iniciando(identidade)
        self.saida.acompanhar_contexto(c)
        self.assertIsNone(self.promover())
        self.buscar.assert_not_called()
        self.assertTrue(self.leitor.executando)

    def test_prontidao_incompleta_recusa_e_mantem_contexto(self):
        with patch.object(promocao, 'aguardar_prontidao', return_value=False):
            self.assertIsNone(self.promover())
        tentativas = self.registro.obter_retrato()['tentativas']
        self.assertEqual(2, len(tentativas))
        self.assertTrue(tentativas[-1].contexto.cancelar_partida.is_set())
        self.assertIn(tentativas[-1].contexto, self.saida._contextos)

    def test_start_ambiguo_bloqueia_nova_tentativa(self):
        with patch.object(promocao, 'Thread') as fabrica:
            fabrica.return_value.ident = None
            fabrica.return_value.is_alive.return_value = False
            fabrica.return_value.start.side_effect = RuntimeError('simulado')
            self.assertIsNone(self.promover())
        self.assertFalse(self.saida.ciclos_aptos_promocao())
        self.assertIsNone(self.promover())
        self.assertEqual(2, len(self.registro.obter_retrato()['tentativas']))

    def test_cliques_concorrentes_uma_partida(self):
        entrou, liberar = Event(), Event()
        def buscar(**kwargs):
            entrou.set()
            if not liberar.wait(2):
                raise TimeoutError('ensaio')
            return None
        self.buscar.side_effect = buscar
        resultados = []
        t = Thread(target=lambda: resultados.append(self.promover()))
        t.start()
        try:
            self.assertTrue(entrou.wait(1))
            self.assertIsNone(self.promover())
        finally:
            liberar.set()
            t.join(3)
        self.assertFalse(t.is_alive())
        self.assertIsNotNone(resultados[0])
        self.assertEqual(2, len(self.registro.obter_retrato()['tentativas']))
        self.supervisao.solicitar_retomada.assert_not_called()

    def test_prontidao_exige_tcp_udp_amostra_e_workers(self):
        c = servidor.ContextoCicloServidor()
        vivos = [Mock(is_alive=Mock(return_value=True)) for _ in range(3)]
        c.trabalhadores_prontidao = vivos
        c.ultimo_dado_monotonico = monotonic()
        with patch.object(servidor, 'obter_saude_tc420', return_value={'saudavel': True}):
            for nome in ('tcp_pronto', 'udp_pronto', 'dados_prontos'):
                self.assertFalse(promocao.aguardar_prontidao(c, self.saida, prazo=0))
                getattr(c, nome).set()
            self.assertTrue(promocao.aguardar_prontidao(c, self.saida, prazo=0))
            vivos[0].is_alive.return_value = False
            self.assertFalse(promocao.aguardar_prontidao(c, self.saida, prazo=0))

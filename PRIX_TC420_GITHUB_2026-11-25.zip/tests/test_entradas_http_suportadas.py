# Testes de entradas http suportadas: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.8: entradas reais por AST e transporte falso; nenhum Tk/rede real."""
import ast
from contextlib import contextmanager
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
import threading
import unittest
from unittest.mock import Mock, patch

import requests

from rede import infraestrutura_cliente as modulo
from tc420.web import WebTC420
from test_registro_automatico import carregar_fluxos
import test_auditoria_cobertura_http as auditoria
import test_approval_http_integrado as approval


# Grupo de 24 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class EntradasHttpSuportadas(unittest.TestCase):
    fluxo_http = approval.ApprovalHttpIntegrado.fluxo_http
    transporte = approval.ApprovalHttpIntegrado.transporte
    iniciar_thread = approval.ApprovalHttpIntegrado.iniciar_thread
    terminar = approval.ApprovalHttpIntegrado.terminar
    bloquear = approval.ApprovalHttpIntegrado.bloquear
    operacoes = approval.ApprovalHttpIntegrado.operacoes
    negativo = approval.ApprovalHttpIntegrado.negativo
    fixture_main = auditoria.AuditoriaCoberturaHttp.fixture_main
    fixture_manual = auditoria.AuditoriaCoberturaHttp.fixture_manual
    conferir_par = auditoria.AuditoriaCoberturaHttp.conferir_par

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = modulo.InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_http

    def ambiente_automatico(self):
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        env["print"] = Mock()
        return env

    @contextmanager
    def sem_novo_registro(self):
        with patch.object(modulo, "InfraestruturaRegistrosCliente", side_effect=AssertionError("novo_dono_inesperado")) as infra, \
                patch.object(modulo, "RegistroOperacoesHttpCliente", side_effect=AssertionError("novo_registro_inesperado")) as http:
            yield
        infra.assert_not_called()
        http.assert_not_called()

    def test_01_automatico_com_infra_sem_novo_registro(self):
        env = self.ambiente_automatico()
        with self.fluxo_http() as adaptador, self.sem_novo_registro():
            resultado = env["tentar_login_automatico"](infraestrutura_cliente=self.infra)
        self.assertEqual("principal", resultado["modo"])
        self.conferir_par(adaptador)

    def test_02_manual_com_infra_sem_novo_registro(self):
        _, janela = self.fixture_manual(self.infra)
        with self.fluxo_http() as adaptador, self.sem_novo_registro():
            janela.conectar()
        self.assertTrue(janela.servidor_iniciado)
        self.conferir_par(adaptador)

    def test_03_promocao_com_infra_sem_novo_registro(self):
        fixture = self.fixture_main()
        fixture.iniciar_cliente(self.infra)
        with self.fluxo_http() as adaptador, self.sem_novo_registro():
            resultado = fixture.monitores[0].ao_promover_automaticamente()
        self.assertIsNotNone(resultado)
        self.conferir_par(adaptador)

    def test_04_tres_entradas_legadas_recusadas_explicitamente(self):
        env = self.ambiente_automatico()
        fixture = self.fixture_main()
        fixture.iniciar_cliente(None)
        fixture.env["print"] = Mock()
        ui, janela = self.fixture_manual(None)
        with self.fluxo_http() as adaptador, self.sem_novo_registro():
            self.assertFalse(env["tentar_login_automatico"]())
            self.assertIsNone(fixture.monitores[0].ao_promover_automaticamente())
            janela.conectar()
        self.assertEqual([], adaptador.enviados)
        env["WebTC420"].assert_not_called()
        fixture.env["WebTC420"].assert_not_called()
        ui.env["WebTC420"].assert_not_called()
        env["print"].assert_any_call("Falha no login autom\u00e1tico: InfraestruturaHttpInvalida")
        fixture.env["print"].assert_any_call("Falha na promo\u00e7\u00e3o: InfraestruturaHttpInvalida")
        self.assertTrue(janela.label_status.opcoes["text"].endswith("infraestrutura_http_ausente_ou_invalida"))
        self.assertEqual("normal", janela.botao_conectar.opcoes["state"])
        self.assertEqual([], self.operacoes())

    def test_05_infra_sem_registro_publicado_falha_antes_web(self):
        incompleta = modulo.InfraestruturaRegistrosCliente.__new__(modulo.InfraestruturaRegistrosCliente)
        env = self.ambiente_automatico()
        with patch("requests.api.request") as enviar:
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=incompleta))
        enviar.assert_not_called()
        env["WebTC420"].assert_not_called()
        env["print"].assert_any_call("Falha no login autom\u00e1tico: InfraestruturaHttpInvalida")

    def test_06_infra_ou_registro_invalido_nao_envia(self):
        env = self.ambiente_automatico()
        original = self.infra._instalacao
        outro = modulo.InfraestruturaRegistrosCliente()
        for invalido in (object(), outro.registro_http):
            with self.subTest(tipo=type(invalido).__name__):
                object.__setattr__(self.infra, "_instalacao", replace(original, http=invalido))
                try:
                    with patch("requests.api.request") as enviar:
                        self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
                    enviar.assert_not_called()
                finally:
                    object.__setattr__(self.infra, "_instalacao", original)
        with patch("requests.api.request") as enviar:
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=SimpleNamespace(registro_http=self.registro)))
        enviar.assert_not_called()
        env["WebTC420"].assert_not_called()

    def test_07_admissao_fechada_sem_post_ou_get_nas_tres(self):
        env = self.ambiente_automatico()
        fixture = self.fixture_main()
        fixture.iniciar_cliente(self.infra)
        _, janela = self.fixture_manual(self.infra)
        self.registro.fechar_admissao()
        with self.fluxo_http() as adaptador:
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
            self.assertIsNone(fixture.monitores[0].ao_promover_automaticamente())
            janela.conectar()
        self.assertEqual([], adaptador.enviados)
        self.assertEqual([], self.operacoes())

    def test_08_origem_inicial_e_preparacao_sem_retentativa(self):
        env = self.ambiente_automatico()
        with self.fluxo_http():
            self.assertTrue(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        a, b = self.operacoes()
        self.assertEqual(a["geracao_id"], a["atividade_id"])
        self.assertEqual(a["geracao_id"], b["geracao_id"])
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()["retentativas"])

    def test_09_promocao_usa_origem_do_leitor(self):
        fixture = self.fixture_main()
        fixture.iniciar_cliente(self.infra)
        dono = fixture.leitores[0].recursos_cliente
        antes = self.infra.registro_retentativas.obter_retrato()
        with self.fluxo_http():
            self.assertIsNotNone(fixture.monitores[0].ao_promover_automaticamente())
        self.assertEqual({dono.geracao_id}, {o["geracao_id"] for o in self.operacoes()})
        self.assertEqual({dono.atividade_id}, {o["atividade_id"] for o in self.operacoes()})
        self.assertEqual(antes, self.infra.registro_retentativas.obter_retrato())

    def test_10_corrida_b_preparacao_antes_de_novo_leitor(self):
        env = self.ambiente_automatico()
        entrou, liberar = threading.Event(), threading.Event()
        def autenticar(*args, **kwargs):
            self.bloquear(entrou, liberar)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=autenticar), \
                patch("tc420.web.requests.get", return_value=Mock(text=approval.APROVACAO.decode())):
            tarefa = self.iniciar_thread(lambda: env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.operacoes()[0]
                leitor = modulo.RecursosLeitorCliente(self.infra)
                self.assertNotEqual(antes["geracao_id"], leitor.geracao_id)
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertEqual("principal", resultados[0]["modo"])
        self.assertTrue(all(o["geracao_id"] == antes["geracao_id"] for o in self.operacoes()))
        self.assertEqual(antes["operacao_id"], self.operacoes()[0]["operacao_id"])

    def test_11_post_get_e_repeticao_nao_reusam_id(self):
        env = self.ambiente_automatico()
        with self.fluxo_http() as adaptador:
            for _ in range(2):
                self.assertTrue(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        self.assertEqual(["POST", "GET"] * 2, [r.method for r, _ in adaptador.enviados])
        self.assertEqual(4, len({o["operacao_id"] for o in self.operacoes()}))
        self.assertEqual(2, len({o["geracao_id"] for o in self.operacoes()}))

    def test_12_post_falha_nao_inicia_get(self):
        env = self.ambiente_automatico()
        with self.transporte(status=401) as adaptador:
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual(["login"], [o["operacao"] for o in self.operacoes()])
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        env["definir_configuracao"].assert_not_called()

    def test_13_timeout_conserva_tratamento(self):
        env = self.ambiente_automatico()
        original = requests.Timeout("simulada")
        with self.transporte(erro=original) as adaptador:
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        self.assertEqual(1, len(adaptador.enviados))
        env["print"].assert_any_call("Falha no login autom\u00e1tico: Timeout")
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_14_corrida_c_automatico_e_manual_sem_recriar_dono(self):
        env = self.ambiente_automatico()
        _, janela = self.fixture_manual(self.infra)
        barreira = threading.Barrier(2)
        def autenticar(*args, **kwargs):
            barreira.wait(3)
            self.assertEqual(2, len(self.operacoes()))
            self.assertTrue(all(not o["execucao_resolvida"] for o in self.operacoes()))
            barreira.wait(3)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=autenticar), \
                patch("tc420.web.requests.get", return_value=Mock(text=approval.APROVACAO.decode())), self.sem_novo_registro():
            a = self.iniciar_thread(lambda: env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
            b = self.iniciar_thread(janela.conectar)
            ra, ea = self.terminar(a)
            _, eb = self.terminar(b)
        self.assertEqual(([], []), (ea, eb))
        self.assertEqual("principal", ra[0]["modo"])
        self.assertTrue(janela.servidor_iniciado)
        self.assertIs(self.registro, janela.infraestrutura_cliente.registro_http)
        self.assertEqual(4, len({o["operacao_id"] for o in self.operacoes()}))
        self.assertEqual(2, len({o["geracao_id"] for o in self.operacoes()}))

    def test_15_assinaturas_preservadas_e_nenhuma_entrada_removida(self):
        raiz = Path(__file__).resolve().parents[1]
        for arquivo, nome, nomes in (
                ("main.py", "tentar_login_automatico", ["registro_tentativas", "infraestrutura_cliente"]),
                ("main.py", "iniciar_como_cliente", ["servidor", "registro_tentativas", "infraestrutura_cliente"]),
                ("interface/conexao.py", "__init__", ["self", "ao_encontrar_servidor", "registro_tentativas", "infraestrutura_cliente"])):
            with self.subTest(entrada=nome):
                arvore = ast.parse((raiz / arquivo).read_text(encoding="utf-8"))
                funcao = next(n for n in ast.walk(arvore) if isinstance(n, ast.FunctionDef) and n.name == nome)
                self.assertEqual(nomes, [a.arg for a in funcao.args.args])
                self.assertTrue(all(isinstance(v, ast.Constant) and v.value is None for v in funcao.args.defaults))
                esperados = ["vinculo_http", "contexto_arquivos"]
                if nome in ("iniciar_como_cliente", "__init__"):
                    esperados.append("saida_aplicacao")
                self.assertEqual(esperados, [a.arg for a in funcao.args.kwonlyargs])
                self.assertIs(False, funcao.args.kw_defaults[0].value)
                self.assertIsNone(funcao.args.kw_defaults[1].value)
        # Os três caminhos têm chamadores operacionais em main; nenhum foi
        # classificado como obsoleto ou eliminado com base em idade.
        fonte = (raiz / "main.py").read_text(encoding="utf-8")
        for nome in ("iniciar_como_cliente", "tentar_login_automatico", "JanelaConexao"):
            self.assertIn("vinculo_http.vincular(" + nome + ")(", fonte)

    def test_16_global_permanece_negativo(self):
        env = self.ambiente_automatico()
        with self.fluxo_http():
            self.assertTrue(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        self.registro.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_17_corrida_a_gate_fecha_antes_da_reserva(self):
        env = self.ambiente_automatico()
        entrou, liberar = threading.Event(), threading.Event()
        admitir = self.registro.admitir
        def atrasar(contexto, operacao):
            self.bloquear(entrou, liberar)
            return admitir(contexto, operacao)
        with self.fluxo_http() as adaptador, patch.object(self.registro, "admitir", side_effect=atrasar):
            tarefa = self.iniciar_thread(lambda: env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
            try:
                self.assertTrue(entrou.wait(3))
                self.registro.fechar_admissao()
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual(([False], []), (resultados, erros))
        self.assertEqual([], adaptador.enviados)
        self.assertEqual([], self.operacoes())

    def test_18_corrida_d_recusa_sem_iniciar_executor(self):
        env = self.ambiente_automatico()
        entrou, liberar = threading.Event(), threading.Event()
        def recusar(contexto, operacao):
            self.bloquear(entrou, liberar)
            return None
        with self.fluxo_http() as adaptador, patch.object(self.registro, "admitir", side_effect=recusar), \
                patch.object(self.registro, "_iniciar", wraps=self.registro._iniciar) as iniciar:
            tarefa = self.iniciar_thread(lambda: env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual([], adaptador.enviados)
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual(([False], []), (resultados, erros))
        iniciar.assert_not_called()
        self.assertEqual([], adaptador.enviados)
        self.assertFalse(self.registro.obter_retrato()["admissao_fechada"])

    def test_19_manual_descoberta_cliente_sem_infra_continua(self):
        fixture, janela = self.fixture_manual(None)
        fixture.env["buscar_servidor"].return_value = "principal-simulado"
        janela.ao_encontrar_servidor = Mock()
        with patch("requests.api.request") as enviar:
            janela.conectar()
        enviar.assert_not_called()
        janela.executar()
        janela.ao_encontrar_servidor.assert_called_once_with("principal-simulado")
        self.assertTrue(janela.root.destruida)

    def test_20_automatico_descoberta_cliente_sem_infra_continua(self):
        env = self.ambiente_automatico()
        env["buscar_servidor"].return_value = "principal-simulado"
        with patch("requests.api.request") as enviar:
            self.assertEqual(dict(modo="cliente", servidor="principal-simulado"), env["tentar_login_automatico"]())
        enviar.assert_not_called()

    def test_21_promocao_cancelada_por_descoberta_sem_http(self):
        fixture = self.fixture_main()
        fixture.iniciar_cliente(None)
        fixture.env["buscar_servidor"].return_value = "principal-simulado"
        with patch("requests.api.request") as enviar:
            self.assertIsNone(fixture.monitores[0].ao_promover_automaticamente())
        enviar.assert_not_called()
        fixture.env["WebTC420"].assert_not_called()

    def test_22_registro_com_aplicacao_divergente_recusado(self):
        env = self.ambiente_automatico()
        self.registro._aplicacao_id = "outra-aplicacao-simulada"
        with patch("requests.api.request") as enviar:
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        enviar.assert_not_called()
        env["WebTC420"].assert_not_called()

    def test_23_api_crua_continua_pendente_l3b19(self):
        self.registro.fechar_admissao()
        web = WebTC420("balanca-simulada")
        web.token = "simulado"
        with self.transporte() as adaptador:
            self.assertEqual(approval.CONFIGURACAO, web.obter_configuracao())
        self.assertEqual(1, len(adaptador.enviados))
        self.assertEqual([], self.operacoes())
        self.negativo()

    def test_24_validacao_nao_formata_objeto_invalido(self):
        class Invalida:
            def __str__(self):
                raise AssertionError("objeto_nao_deve_ser_formatado")
            __repr__ = __str__
        env = self.ambiente_automatico()
        _, janela = self.fixture_manual(Invalida())
        with patch("requests.api.request") as enviar:
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=Invalida()))
            janela.conectar()
        enviar.assert_not_called()
        self.assertTrue(janela.label_status.opcoes["text"].endswith("infraestrutura_http_ausente_ou_invalida"))


if __name__ == "__main__":
    unittest.main()

# Testes de silencio subscribe cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Regressão do defeito físico: PRINCIPAL suspenso com SUBSCRIBE aberto."""
import json
import socket
import threading
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from interface.janela import JanelaTC420
from rede.lerdadosserver import LeitorDadosServidor, SilencioSubscribeError


# Produz uma amostra sintética com os mesmos campos obrigatórios usados pelo consumidor SUBSCRIBE.
def pacote(peso="24.980"):
    return {
        "estado": "00", "peso_bruto": peso, "tara": "0.000",
        "peso_liquido": peso, "unidade": "kg", "multirange": "1",
    }


# Dublê: cada recv devolve um item programado ou lança a exceção informada, sem abrir socket.
class SocketControlado:
    def __init__(self, respostas):
        self.respostas = list(respostas)
        self.timeouts = []
        self.recebimentos = 0

    def settimeout(self, valor):
        self.timeouts.append(valor)

    def recv(self, _tamanho):
        self.recebimentos += 1
        resposta = self.respostas.pop(0)
        if isinstance(resposta, BaseException):
            raise resposta
        if callable(resposta):
            return resposta()
        return resposta


# Grupo de 9 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class SilencioSubscribeCliente(unittest.TestCase):
    # Constrói um leitor com hostname simulado e o coloca em estado de execução sem iniciar thread TCP.
    def leitor(self, permitir=True):
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente-simulado"):
            leitor = LeitorDadosServidor(permitir_candidatura=permitir)
        leitor.executando = True
        return leitor

    # Compara valor e frescor: peso repetido continua atual quando uma mensagem válida chega.
    def test_01_peso_constante_com_pacotes_permanece_atual(self):
        leitor = self.leitor()
        linha = (json.dumps(pacote()) + "\n").encode()
        socket_falso = SocketControlado([
            linha,
            lambda: (setattr(leitor, "executando", False), b"")[1],
        ])
        leitor._receber_subscribe(socket_falso)
        self.assertEqual("24.980", leitor.obter_dados_atuais()["peso_liquido"])
        self.assertTrue(leitor.comunicacao_esta_atual())

    # Avança o relógio simulado além do prazo e exige a exceção específica de silêncio.
    def test_02_tcp_aberto_silencioso_expira(self):
        leitor = self.leitor()
        socket_falso = SocketControlado([socket.timeout()])
        with patch("rede.lerdadosserver.time.monotonic", side_effect=[0, 1, 7]):
            with self.assertRaises(SilencioSubscribeError):
                leitor._receber_subscribe(socket_falso)
        self.assertFalse(leitor.comunicacao_esta_atual())

    # Uma linha JSON incompleta não pode renovar a evidência de comunicação válida.
    def test_03_linha_parcial_nao_renova_prazo(self):
        leitor = self.leitor()
        socket_falso = SocketControlado([b'{"estado":', socket.timeout()])
        with patch("rede.lerdadosserver.time.monotonic", side_effect=[0, 1, 2, 7]):
            with self.assertRaises(SilencioSubscribeError):
                leitor._receber_subscribe(socket_falso)
        self.assertEqual(2, socket_falso.recebimentos)
        self.assertFalse(leitor.comunicacao_esta_atual())

    # Confirma que a expiração interrompe a recepção antes de aceitar um pacote que chegou tarde.
    def test_04_silencio_nao_consumira_mensagem_tardia(self):
        leitor = self.leitor()
        tardia = (json.dumps(pacote("99.999")) + "\n").encode()
        socket_falso = SocketControlado([socket.timeout(), tardia])
        with patch("rede.lerdadosserver.time.monotonic", side_effect=[0, 1, 7]):
            with self.assertRaises(SilencioSubscribeError):
                leitor._receber_subscribe(socket_falso)
        leitor._marcar_comunicacao_indisponivel()
        self.assertEqual(1, socket_falso.recebimentos)
        self.assertEqual("0", leitor.obter_dados_atuais()["peso_liquido"])
        self.assertFalse(leitor.comunicacao_esta_atual())

    # Simula ausência de principal e passagem da janela para confirmar a liberação da candidatura.
    def test_05_candidatura_manual_mantem_janela_de_sucessao(self):
        leitor = self.leitor()
        leitor.posicao_sucessao = 1
        with patch("rede.lerdadosserver.buscar_servidor", return_value=None), \
                patch("rede.lerdadosserver.time.monotonic", side_effect=[0, 1, 2, 31]):
            self.assertTrue(leitor._aguardar_candidatura())
        self.assertTrue(leitor.candidatura_esta_liberada())
        self.assertEqual("liberada", leitor.obter_estado_candidatura())

    # Um leitor rebaixado com candidatura desabilitada não pode entrar na disputa pelo principal.
    def test_06_antigo_principal_continua_sem_candidatura(self):
        leitor = self.leitor(permitir=False)
        leitor.posicao_sucessao = 1
        self.assertFalse(leitor._aguardar_candidatura())
        self.assertFalse(leitor.candidatura_esta_liberada())

    # A descoberta de outro principal durante a espera cancela a candidatura local.
    def test_07_principal_reaparece_antes_da_candidatura(self):
        leitor = self.leitor()
        leitor.posicao_sucessao = 1
        with patch("rede.lerdadosserver.buscar_servidor", return_value="novo-principal"), \
                patch("rede.lerdadosserver.time.monotonic", side_effect=[0, 1, 2]):
            self.assertFalse(leitor._aguardar_candidatura())
        self.assertEqual("cancelada", leitor.obter_estado_candidatura())
        self.assertFalse(leitor.candidatura_esta_liberada())

    # Usa thread e eventos locais para verificar que parar() interrompe a espera de candidatura.
    def test_08_parada_interrompe_espera_sem_worker_pendente(self):
        leitor = self.leitor()
        leitor.posicao_sucessao = 1
        iniciou = threading.Event()

        def busca(**_kwargs):
            iniciou.set()
            return None

        with patch("rede.lerdadosserver.buscar_servidor", side_effect=busca):
            thread = threading.Thread(target=leitor._aguardar_candidatura)
            thread.start()
            self.assertTrue(iniciou.wait(2))
            leitor.parar()
            thread.join(2)
        self.assertFalse(thread.is_alive())
        self.assertFalse(leitor.candidatura_esta_liberada())

    # Com widgets simulados, exige aviso SEM COM. e título de última leitura quando o frescor é falso.
    def test_09_interface_identifica_ultima_leitura(self):
        widget = lambda: Mock(winfo_exists=Mock(return_value=True))
        janela = SimpleNamespace(
            executando=True,
            fonte_dados=Mock(return_value=pacote()),
            comunicacao_atual=Mock(return_value=False),
            label_estado=widget(), label_peso=widget(), label_tara=widget(),
            label_unidade=widget(), label_faixa=widget(), root=Mock(),
            img_zero=object(), img_estavel=object(), _agendar=Mock(),
            atualizar_refresh_web=Mock(),
        )
        with patch("interface.ciclo_tk.ativa", return_value=True), patch("builtins.print"):
            JanelaTC420.atualizar_refresh_web(janela)
        janela.label_faixa.config.assert_any_call(
            text="SEM COM.", fg="white", bg="#b00020")
        janela.root.title.assert_called_with(
            "PRIX TC420 - Monitor — ÚLTIMA LEITURA")
        janela._agendar.assert_called_once()


if __name__ == "__main__":
    unittest.main()

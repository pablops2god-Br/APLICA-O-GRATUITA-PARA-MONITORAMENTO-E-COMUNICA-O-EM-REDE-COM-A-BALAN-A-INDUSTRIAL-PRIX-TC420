# Testes de guarda retentativas cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Retentativas com threads/recursos falsos; concorrência só no harness."""
import threading
import unittest
from unittest.mock import Mock

from prototipos.guarda_retentativas_cliente import GuardaRetentativasCliente


class ThreadFalsa:
    def __init__(self, alvo, *, erro_start=False):
        self.alvo = alvo
        self.erro_start = erro_start
        self.viva = False
        self.starts = 0
        self.daemon = True

    def start(self):
        self.starts += 1
        if self.erro_start:
            raise RuntimeError("partida_ambigua")
        self.viva = True

    def executar(self):
        self.viva = True
        try:
            self.alvo()
        finally:
            self.viva = False

    def is_alive(self):
        return self.viva


# Grupo de 32 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class GuardaRetentativas(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.guarda = GuardaRetentativasCliente()
        self.geracao = self.guarda.nova_geracao_cliente()
        self.threads = {}

    def reserva(self, geracao=None):
        return self.guarda.reservar_retentativa(geracao or self.geracao)

    def partir(self, reserva, rotina=lambda: None, erro_start=False):
        def fabrica(alvo):
            thread = ThreadFalsa(alvo, erro_start=erro_start)
            self.threads[reserva] = thread
            return thread
        return self.guarda.partir(reserva, fabrica, rotina)

    def terminar(self, reserva):
        self.threads[reserva].executar()
        self.assertTrue(self.guarda.observar_termino_thread(reserva))

    def retrato(self):
        return self.guarda.obter_retrato()

    def item(self, reserva):
        return next(i for i in self.retrato()["retentativas"] if i["id"] == reserva.numero)

    def pendente(self):
        self.assertFalse(self.retrato()["conjunto_encerrado"])

    def test_01_retentativa_normal(self):
        reserva = self.reserva()
        self.assertEqual("admitida", self.item(reserva)["estado"])
        self.assertTrue(self.partir(reserva))
        self.assertEqual("iniciando", self.item(reserva)["estado"])
        self.terminar(reserva)
        self.assertEqual("encerramento_confirmado", self.item(reserva)["estado"])

    def test_02_apos_fechamento_recusada(self):
        self.guarda.fechar_admissao()
        self.assertIsNone(self.reserva())
        self.assertIsNone(self.guarda.nova_geracao_cliente())

    def test_03_anterior_preservada(self):
        reserva = self.reserva()
        self.guarda.fechar_admissao()
        self.assertEqual(reserva.numero, self.item(reserva)["id"])
        self.pendente()

    def test_04_falha_pre_execucao_comprovada(self):
        reserva = self.reserva()
        self.assertTrue(self.guarda.comprovar_nao_execucao(reserva, ausencia_comprovada=True))
        self.assertFalse(self.item(reserva)["entrada"])
        self.guarda.fechar_admissao()
        self.assertTrue(self.retrato()["conjunto_encerrado"])
        fabrica = Mock()
        self.assertFalse(self.guarda.partir(reserva, fabrica, Mock()))
        fabrica.assert_not_called()

    def test_05_falha_ambigua(self):
        reserva = self.reserva()
        with self.assertRaises(RuntimeError):
            self.partir(reserva, erro_start=True)
        self.assertEqual("desconhecido", self.item(reserva)["estado"])
        self.guarda.fechar_admissao()
        self.pendente()

    def test_06_thread_executando(self):
        reserva = self.reserva()
        estados = []
        self.partir(reserva, lambda: estados.append(self.item(reserva)["estado"]))
        self.threads[reserva].executar()
        self.assertEqual(["executando"], estados)
        self.assertFalse(self.item(reserva)["thread_terminada"])
        self.pendente()

    def test_07_stop_nao_e_termino(self):
        reserva = self.reserva()
        self.partir(reserva)
        self.guarda.fechar_admissao()
        self.assertTrue(self.guarda.parada_solicitada(reserva))
        self.assertEqual("parada_solicitada", self.item(reserva)["estado"])
        self.pendente()

    def test_08_thread_morta_socket_pendente(self):
        reserva = self.reserva()
        socket = self.guarda.reservar_secundaria(reserva, "socket")
        self.partir(reserva)
        self.terminar(reserva)
        self.guarda.fechar_admissao()
        self.pendente()
        self.guarda.resolver_secundaria(socket, responsabilidades_resolvidas=True)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_09_promocao_preserva_antiga(self):
        reserva = self.reserva()
        self.partir(reserva)
        self.guarda.promover(self.geracao)
        self.guarda.fechar_admissao()
        self.assertEqual("principal", self.item(reserva)["modo_atual"])
        self.assertEqual(self.geracao.numero, self.item(reserva)["geracao"])
        self.pendente()

    def test_10_duas_geracoes(self):
        a = self.reserva()
        geracao_b = self.guarda.nova_geracao_cliente()
        b = self.reserva(geracao_b)
        self.guarda.comprovar_nao_execucao(a, ausencia_comprovada=True)
        self.guarda.fechar_admissao()
        self.assertNotEqual(self.item(a)["geracao"], self.item(b)["geracao"])
        self.assertEqual("encerramento_confirmado", self.item(a)["estado"])
        self.pendente()

    def test_11_duas_retentativas(self):
        a, b = self.reserva(), self.reserva()
        self.assertNotEqual(a, b)
        self.partir(a)
        self.partir(b)
        self.terminar(a)
        self.assertEqual("iniciando", self.item(b)["estado"])

    def test_12_falha_registro_sem_orfao(self):
        reserva = self.reserva()
        secundaria = self.guarda.reservar_secundaria(reserva, "descoberta")
        publicado = []

        def registrar():
            publicado.append("recurso_simulado")
            raise OSError("mensagem_nao_deve_ser_retida")

        with self.assertRaises(OSError):
            self.guarda.publicar_secundaria(secundaria, registrar)
        self.partir(reserva)
        self.terminar(reserva)
        self.guarda.fechar_admissao()
        self.assertEqual(["recurso_simulado"], publicado)
        self.assertEqual(secundaria.numero, self.retrato()["secundarias"][0]["id"])
        self.assertEqual("desconhecido", self.item(reserva)["estado"])
        self.assertNotIn("mensagem_nao", str(self.retrato()))
        self.pendente()

    def test_13_erro_limpeza_retido(self):
        reserva = self.reserva()
        secundaria = self.guarda.reservar_secundaria(reserva, "socket")
        with self.assertRaises(OSError):
            self.guarda.finalizar_secundaria(secundaria, Mock(side_effect=OSError()))
        self.guarda.resolver_secundaria(secundaria, responsabilidades_resolvidas=True)
        self.guarda.comprovar_nao_execucao(reserva, ausencia_comprovada=True)
        self.guarda.fechar_admissao()
        self.pendente()

    def test_14_fechamento_idempotente(self):
        self.reserva()
        self.assertTrue(self.guarda.fechar_admissao())
        antes = self.retrato()
        self.assertFalse(self.guarda.fechar_admissao())
        self.assertEqual(antes, self.retrato())

    def executar_retido(self, funcao, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []

        def reter():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("harness")

        def executar():
            try:
                funcao(reter)
            except BaseException as erro:
                erros.append(erro)

        thread = threading.Thread(target=executar)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_15_consulta_durante_partida(self):
        reserva = self.reserva()

        def partir(reter):
            def fabrica(alvo):
                reter()
                falsa = ThreadFalsa(alvo)
                self.threads[reserva] = falsa
                return falsa
            self.guarda.partir(reserva, fabrica, lambda: None)

        def durante():
            self.assertEqual("iniciando", self.item(reserva)["estado"])
            self.assertTrue(self.item(reserva)["partida_em_curso"])
            self.assertFalse(self.guarda.observar_termino_thread(reserva))
            self.guarda.fechar_admissao()
            self.pendente()

        self.executar_retido(partir, durante)
        self.terminar(reserva)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_16_consulta_durante_finalizacao(self):
        reserva = self.reserva()
        secundaria = self.guarda.reservar_secundaria(reserva, "socket")
        self.partir(reserva)
        self.terminar(reserva)

        def durante():
            self.assertTrue(self.retrato()["secundarias"][0]["limpeza_em_curso"])
            publicador = Mock()
            self.assertFalse(self.guarda.publicar_secundaria(secundaria, publicador))
            publicador.assert_not_called()
            self.guarda.fechar_admissao()
            self.assertFalse(self.guarda.resolver_secundaria(
                secundaria, responsabilidades_resolvidas=True))
            duplicada = Mock()
            self.assertFalse(self.guarda.finalizar_secundaria(secundaria, duplicada))
            duplicada.assert_not_called()
            self.pendente()

        def finalizar(reter):
            def limpar():
                reter()
                return True
            self.guarda.finalizar_secundaria(secundaria, limpar)

        self.executar_retido(finalizar, durante)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_17_vazio_aberto(self):
        self.pendente()
        self.assertEqual([], self.retrato()["retentativas"])

    def test_18_vazio_fechado(self):
        self.guarda.fechar_admissao()
        self.assertTrue(self.retrato()["conjunto_encerrado"])
        self.assertNotIn("encerramento_aplicacao", self.retrato())

    def test_critico_A_admissao_contra_fechamento(self):
        for _ in range(20):
            guarda = GuardaRetentativasCliente()
            geracao = guarda.nova_geracao_cliente()
            barreira = threading.Barrier(3)
            resultados, erros = [], []

            def disputar(operacao):
                try:
                    barreira.wait(3)
                    resultados.append(operacao())
                except BaseException as erro:
                    erros.append(erro)

            a = threading.Thread(target=disputar, args=(lambda: guarda.reservar_retentativa(geracao),))
            b = threading.Thread(target=disputar, args=(guarda.fechar_admissao,))
            a.start()
            b.start()
            barreira.wait(3)
            a.join(3)
            b.join(3)
            self.assertFalse(a.is_alive() or b.is_alive())
            self.assertEqual([], erros)
            reserva = next(r for r in resultados if r is not True)
            retrato = guarda.obter_retrato()
            self.assertTrue(retrato["admissao_fechada"])
            self.assertEqual(0 if reserva is None else 1, len(retrato["retentativas"]))
            self.assertTrue(all(i["parada_solicitada"] for i in retrato["retentativas"]))
            self.assertEqual(reserva is None, retrato["conjunto_encerrado"])
            self.assertIsNone(guarda.reservar_retentativa(geracao))

    def test_critico_B_start_lanca_mas_rotina_pode_entrar(self):
        reserva = self.reserva()
        executou = []
        with self.assertRaises(RuntimeError):
            self.partir(reserva, lambda: executou.append(True), erro_start=True)
        self.guarda.fechar_admissao()
        self.pendente()
        self.assertFalse(self.guarda.observar_termino_thread(reserva))
        # Entrada tardia mesmo após a exceção de start: continua identificada.
        self.terminar(reserva)
        self.assertEqual([True], executou)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_critico_C_promocao_com_geracao_antiga(self):
        reserva = self.reserva()
        self.partir(reserva)
        self.guarda.promover(self.geracao)
        servidor = Mock()
        servidor.encerramento_confirmado = True
        self.guarda.fechar_admissao()
        self.assertTrue(servidor.encerramento_confirmado)
        self.assertEqual(self.geracao.numero, self.item(reserva)["geracao"])
        self.pendente()
        self.terminar(reserva)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_critico_D_thread_retornou_antes_close(self):
        reserva = self.reserva()
        socket = Mock()
        socket.fechado = False
        secundaria = self.guarda.reservar_secundaria(reserva, "socket")
        self.guarda.publicar_secundaria(secundaria, Mock())
        self.partir(reserva)
        self.terminar(reserva)
        self.guarda.fechar_admissao()
        self.assertTrue(self.item(reserva)["thread_terminada"])
        self.assertFalse(socket.fechado)
        self.pendente()
        socket.fechado = True
        self.guarda.resolver_secundaria(secundaria, responsabilidades_resolvidas=socket.fechado)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_secundaria_depois_stop_recusada(self):
        reserva = self.reserva()
        secundaria = self.guarda.reservar_secundaria(reserva, "promocao")
        self.guarda.fechar_admissao()
        self.assertIsNone(self.guarda.reservar_secundaria(reserva, "socket"))
        self.assertIsNone(self.guarda.reservar_secundaria(reserva, "promocao"))
        publicador = Mock()
        self.assertFalse(self.guarda.publicar_secundaria(secundaria, publicador))
        publicador.assert_not_called()
        self.pendente()

    def test_geracao_ou_token_de_outro_registro_recusado(self):
        outra = GuardaRetentativasCliente()
        geracao = outra.nova_geracao_cliente()
        with self.assertRaises(ValueError):
            self.guarda.reservar_retentativa(geracao)
        reserva = outra.reservar_retentativa(geracao)
        with self.assertRaises(ValueError):
            self.partir(reserva)

    def test_partida_unica_e_recusada_depois_stop(self):
        a, b = self.reserva(), self.reserva()
        self.partir(a)
        self.assertFalse(self.partir(a))
        self.assertEqual(1, self.threads[a].starts)
        self.guarda.fechar_admissao()
        fabrica = Mock()
        self.assertFalse(self.guarda.partir(b, fabrica, Mock()))
        fabrica.assert_not_called()
        self.assertEqual("encerramento_confirmado", self.item(b)["estado"])

    def test_falha_fabrica_exige_prova_nao_execucao(self):
        reserva = self.reserva()
        with self.assertRaises(OSError):
            self.guarda.partir(reserva, Mock(side_effect=OSError()), Mock())
        self.guarda.fechar_admissao()
        self.pendente()
        self.guarda.comprovar_nao_execucao(reserva, ausencia_comprovada=True)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_consulta_thread_fora_lock_e_copia_independente(self):
        reserva = self.reserva()
        self.partir(reserva)
        self.threads[reserva].executar()
        self.threads[reserva].is_alive = lambda: not bool(self.retrato())
        self.assertTrue(self.guarda.observar_termino_thread(reserva))
        self.retrato()["retentativas"][0]["erro"] = True
        self.assertFalse(self.item(reserva)["erro"])

    def test_daemon_e_ausencia_de_entrada_nao_confirmam(self):
        reserva = self.reserva()
        self.partir(reserva)
        self.threads[reserva].viva = False
        self.assertTrue(self.threads[reserva].daemon)
        self.assertFalse(self.guarda.observar_termino_thread(reserva))
        self.guarda.fechar_admissao()
        self.pendente()

    def test_erro_observacao_thread_conservador(self):
        reserva = self.reserva()
        self.partir(reserva)
        self.threads[reserva].executar()
        self.threads[reserva].is_alive = Mock(side_effect=OSError())
        self.assertFalse(self.guarda.observar_termino_thread(reserva))
        self.assertEqual("desconhecido", self.item(reserva)["estado"])

    def test_prova_nao_execucao_nao_apaga_entrada(self):
        reserva = self.reserva()
        self.partir(reserva)
        self.threads[reserva].executar()
        self.assertFalse(self.guarda.comprovar_nao_execucao(reserva, ausencia_comprovada=True))
        with self.assertRaises(ValueError):
            self.guarda.comprovar_nao_execucao(reserva, ausencia_comprovada=1)

    def test_retorno_sem_prova_thread_morta(self):
        reserva = self.reserva()
        self.partir(reserva)
        self.threads[reserva].alvo()
        self.assertTrue(self.item(reserva)["retorno"])
        self.assertTrue(self.threads[reserva].viva)
        self.assertFalse(self.guarda.observar_termino_thread(reserva))
        self.guarda.fechar_admissao()
        self.pendente()

    def test_entrada_tardia_contradiz_ausencia_sem_executar_corpo(self):
        reserva = self.reserva()
        corpo = Mock()
        with self.assertRaises(RuntimeError):
            self.partir(reserva, corpo, erro_start=True)
        self.guarda.comprovar_nao_execucao(reserva, ausencia_comprovada=True)
        self.threads[reserva].executar()
        corpo.assert_not_called()
        self.assertEqual("desconhecido", self.item(reserva)["estado"])


if __name__ == "__main__":
    unittest.main()

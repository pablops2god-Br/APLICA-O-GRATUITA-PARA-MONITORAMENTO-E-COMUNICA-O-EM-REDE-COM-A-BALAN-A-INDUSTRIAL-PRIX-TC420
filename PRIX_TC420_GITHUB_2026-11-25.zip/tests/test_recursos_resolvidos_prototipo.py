"""2B.9: elegibilidade e incompatibilidades observáveis, sem TC420."""
import gc
import socket
import threading
import unittest
import weakref
from unittest.mock import patch

from rede import servidor as s
from prototipos.recursos_resolvidos import (RegistroThreadsExperimental,
    RegistroSocketsExperimental, RegistroCombinadoExperimental, ThreadResolvida)
from test_guarda_sockets_integrada import SocketFalso


class RecursosResolvidos(unittest.TestCase):
    def cliente(self, r, sock=None):
        t = r.reservar_criacao_socket()
        sock = sock if sock is not None else SocketFalso()
        r.anexar_socket(t, sock)
        r.publicar_socket(t)
        return t, sock

    def test_thread_join_prova_coleta_e_repeticao(self):
        r = RegistroThreadsExperimental()
        t = threading.Thread(target=lambda: None)
        original_join = t.join
        def join(*args, **kwargs):
            self.assertTrue(r.lock.acquire(blocking=False))
            r.lock.release()
            return original_join(*args, **kwargs)
        t.join = join
        self.assertTrue(r.registrar_e_iniciar(t))
        t.join(3)
        ref = weakref.ref(t)
        nome, ident = t.name, t.ident
        self.assertEqual(r.resumir_threads_resolvidas(), 1)
        self.assertIsInstance(r.threads[0], ThreadResolvida)
        self.assertEqual((r.threads[0].name,r.threads[0].ident), (nome,ident))
        self.assertIsNot(r.threads[0], t)  # diferença de identidade explícita
        self.assertEqual(r.resumir_threads_resolvidas(), 0)
        del original_join, join, t
        gc.collect()
        self.assertIsNone(ref())

    def test_start_ambiguo_apos_execucao_nao_compacta(self):
        r = RegistroThreadsExperimental()
        t = threading.Thread(target=lambda: None)
        original = t.start
        def start():
            original()
            t.join(3)
            raise RuntimeError('partida ambigua')
        t.start = start
        with self.assertRaises(RuntimeError):
            r.registrar_e_iniciar(t)
        self.assertFalse(t.is_alive())
        self.assertIsNotNone(t.ident)
        self.assertEqual(r.resumir_threads_resolvidas(), 0)
        self.assertIs(r.threads[0], t)

    def test_thread_viva_e_responsabilidade_incerta_preservadas(self):
        r = RegistroThreadsExperimental()
        liberar = threading.Event()
        t = threading.Thread(target=lambda: liberar.wait(5))
        r.registrar_e_iniciar(t)
        try:
            self.assertEqual(r.resumir_threads_resolvidas(), 0)
        finally:
            liberar.set(); t.join(3)
        reserva = r.reservar_criacao_socket()
        r.resolver_falha_criacao_socket(reserva)
        self.assertEqual(r.resumir_threads_resolvidas(), 0)
        r.bloquear_criacao()
        self.assertFalse(r.encerramento_confirmado())

    def test_vinculo_explicito_com_listener_ainda_ativo(self):
        r = RegistroThreadsExperimental()
        listener, _ = self.cliente(r)
        token, _ = self.cliente(r)
        r.iniciar_limpeza_handler(token)
        t = threading.Thread(target=lambda: None)
        r.registrar_com_responsabilidades(t, [token])
        t.join(3)
        self.assertEqual(r.resumir_threads_resolvidas(), 0)
        r.publicar_limpeza_handler(token)
        r.encerrar_uso_socket(token)
        r.fechar_socket(token)
        self.assertEqual(r.resumir_threads_resolvidas(), 1)
        self.assertEqual(r._reservas_socket[listener.criacao_id].estado, 'publicada')

    def test_sem_vinculo_nao_libera_com_listener_ativo(self):
        r = RegistroThreadsExperimental()
        self.cliente(r)
        t = threading.Thread(target=lambda: None)
        r.registrar_e_iniciar(t); t.join(3)
        self.assertEqual(r.resumir_threads_resolvidas(), 0)

    def test_sockets_tokens_diagnosticos_coleta_e_idempotencia(self):
        r = RegistroSocketsExperimental()
        token, sock = self.cliente(r)
        ref = weakref.ref(sock)
        r.encerrar_uso_socket(token); r.fechar_socket(token)
        antes = r.obter_situacao()
        self.assertEqual(r.separar_sockets_resolvidos(), 1)
        self.assertEqual(r.separar_sockets_resolvidos(), 0)
        self.assertEqual(r.obter_situacao(), antes)
        self.assertTrue(r.fechar_socket(token))
        self.assertFalse(r.publicar_limpeza_handler(token))
        del sock
        gc.collect()
        self.assertIsNone(ref())

    def test_fileno_fechado_sem_estado_e_handler_erro_nao_autorizam(self):
        r = RegistroSocketsExperimental()
        token, sock = self.cliente(r)
        sock.close()
        self.assertEqual(r.separar_sockets_resolvidos(), 0)
        r.iniciar_limpeza_handler(token)
        r.encerrar_uso_socket(token)
        self.assertEqual(r.separar_sockets_resolvidos(), 0)
        r.publicar_limpeza_handler(token, OSError())
        r.fechar_socket(token)
        self.assertEqual(r.separar_sockets_resolvidos(), 0)
        r.bloquear_criacao()
        self.assertFalse(r.encerramento_confirmado())

    def test_shutdown_tardio_erro_observavel_muda(self):
        class Observavel(SocketFalso):
            def shutdown(self, _):
                raise RuntimeError('efeito observavel')
        resultados = []
        for compactar in (False, True):
            r = RegistroSocketsExperimental()
            c = s.ControleCicloServidor(); c.tentar_iniciar(r)
            token, _ = self.cliente(r, Observavel())
            r.encerrar_uso_socket(token); r.fechar_socket(token)
            if compactar:
                r.separar_sockets_resolvidos()
            with patch.object(s, 'controle_ciclo_servidor', c), patch.object(s, 'evento_parada_servidor', threading.Event()):
                try:
                    resultados.append(s.solicitar_parada_ciclo(1))
                except RuntimeError:
                    resultados.append('RuntimeError')
        self.assertEqual(resultados, ['RuntimeError', True])

    def test_socket_real_fechado_shutdown_oserror_tolerado(self):
        # Socket criado/fechado sem bind, connect ou tráfego de rede.
        for compactar in (False, True):
            r = RegistroSocketsExperimental()
            c = s.ControleCicloServidor(); c.tentar_iniciar(r)
            bruto = socket.socket()
            self.addCleanup(bruto.close)
            token, _ = self.cliente(r, bruto)
            r.encerrar_uso_socket(token); r.fechar_socket(token)
            if compactar:
                r.separar_sockets_resolvidos()
            with patch.object(s,'controle_ciclo_servidor',c), patch.object(s,'evento_parada_servidor',threading.Event()):
                self.assertTrue(s.solicitar_parada_ciclo(1))

    def test_close_bloqueado_e_finalizacao_concorrente(self):
        r = RegistroCombinadoExperimental()
        token, sock = self.cliente(r)
        worker = threading.Thread(target=lambda: None)
        r.registrar_e_iniciar(worker); worker.join(3)
        r.encerrar_uso_socket(token)
        entrou, liberar = threading.Event(), threading.Event()
        original = sock.close
        def close():
            entrou.set()
            if not liberar.wait(5):
                raise RuntimeError('prazo do teste')
            original()
        sock.close = close
        resultados = []
        fechar = threading.Thread(target=lambda: resultados.append(r.fechar_socket(token)))
        fechar.start()
        try:
            self.assertTrue(entrou.wait(5))
            self.assertEqual(r.separar_sockets_resolvidos(),0)
            self.assertEqual(r.resumir_threads_resolvidas(),0)
            r.bloquear_criacao()
            self.assertFalse(r.encerramento_confirmado())
        finally:
            liberar.set(); fechar.join(3)
        self.assertEqual(resultados,[True])
        self.assertEqual(r.separar_sockets_resolvidos(),1)
        self.assertEqual(r.resumir_threads_resolvidas(),1)
        self.assertTrue(r.encerramento_confirmado())


if __name__ == '__main__':
    unittest.main()

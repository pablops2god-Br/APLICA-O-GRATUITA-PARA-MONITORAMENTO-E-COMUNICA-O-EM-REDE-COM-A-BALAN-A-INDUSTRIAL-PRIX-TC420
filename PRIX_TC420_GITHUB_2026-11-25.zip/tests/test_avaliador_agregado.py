# Testes de avaliador agregado: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Protótipo agregado: contextos/registro/histórico reais, sem servidor/rede/Tk."""
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import Mock, patch
import ast
import inspect
import threading
import unittest

from rede import servidor
from prototipos import avaliador_encerramento as prototipo


AVALIAR_INDIVIDUAL_REAL = servidor.avaliar_encerramento_tentativa


# Grupo de 28 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AvaliadorAgregado(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.registro = servidor.RegistroTentativasAplicacao()
        self.controle = servidor.ControleCicloServidor()
        remendo = patch.object(servidor, "controle_ciclo_servidor", self.controle)
        remendo.start()
        self.addCleanup(remendo.stop)

    def consultar(self, registro, callback):
        return prototipo.avaliar_encerramento_aplicacao(registro, callback)

    def fontes_avaliador(self):
        return inspect.getsource(prototipo)

    def avaliar(self, callback=AVALIAR_INDIVIDUAL_REAL):
        resultado = self.consultar(self.registro, callback)
        contagem = sum(resultado[campo] for campo in (
            "confirmadas", "falhas_partida_confirmadas", "pendentes", "desconhecidas"))
        self.assertEqual(contagem, resultado["total_tentativas"])
        for campo in ("admissao_fechada", "consistente", "encerramento_confirmado"):
            self.assertIs(type(resultado[campo]), bool)
        if resultado["encerramento_confirmado"]:
            self.assertTrue(resultado["admissao_fechada"])
            self.assertTrue(resultado["consistente"])
            self.assertEqual(resultado["pendentes"], 0)
            self.assertEqual(resultado["desconhecidas"], 0)
        return resultado

    def tentativa(self, estado="iniciada", observar=True):
        contexto = servidor.ContextoCicloServidor()
        chave = self.registro.admitir(contexto)
        self.assertIsNotNone(chave)
        if estado != "admitida":
            self.registro.marcar_iniciando(chave)
            if observar:
                self.registro.registrar_entrada_execucao(chave)
            if estado == "iniciada":
                self.registro.marcar_iniciada(chave)
        return chave, contexto

    def ciclo(self, contexto, retornar=True, finalizar=True):
        trabalhadores = servidor.RegistroTrabalhadores()
        self.assertTrue(self.controle.tentar_iniciar(trabalhadores))
        contexto.registrar_reserva(trabalhadores.ciclo_id)
        if finalizar:
            trabalhadores.bloquear_criacao()
            self.controle.finalizar(trabalhadores)
        if retornar:
            contexto.registrar_retorno_coordenador()
        return trabalhadores

    def confirmada(self):
        chave, contexto = self.tentativa()
        self.ciclo(contexto)
        return chave, contexto

    def falha_partida(self, chave, contexto):
        contexto.registrar_falha("falha_antes_reserva")
        self.assertTrue(self.registro.registrar_falha_partida(
            chave, "falha_criacao_thread", execucao_nao_iniciada=True))

    def test_01_vazio_aberto(self):
        self.assertFalse(self.avaliar()["encerramento_confirmado"])

    def test_02_vazio_fechado(self):
        self.registro.fechar_admissao()
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_03_confirmada_aberto(self):
        self.confirmada()
        resultado = self.avaliar()
        self.assertEqual(resultado["confirmadas"], 1)
        self.assertFalse(resultado["encerramento_confirmado"])

    def test_04_confirmada_fechado(self):
        self.confirmada()
        self.registro.fechar_admissao()
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_05_duas_confirmadas(self):
        self.confirmada()
        self.confirmada()
        self.registro.fechar_admissao()
        resultado = self.avaliar()
        self.assertEqual(resultado["confirmadas"], 2)
        self.assertTrue(resultado["encerramento_confirmado"])

    def test_06_confirmada_e_pendente(self):
        self.confirmada()
        self.tentativa("iniciando", observar=False)
        self.registro.fechar_admissao()
        resultado = self.avaliar()
        self.assertEqual((resultado["confirmadas"], resultado["pendentes"]), (1, 1))
        self.assertFalse(resultado["encerramento_confirmado"])

    def test_07_falha_comprovada(self):
        chave, contexto = self.tentativa("iniciando", observar=False)
        self.falha_partida(chave, contexto)
        self.registro.fechar_admissao()
        callback = Mock(side_effect=AssertionError("não deve consultar histórico"))
        resultado = self.avaliar(callback)
        self.assertEqual(resultado["falhas_partida_confirmadas"], 1)
        self.assertTrue(resultado["encerramento_confirmado"])
        callback.assert_not_called()

    def test_08_falha_incerta(self):
        chave, _ = self.tentativa("iniciando", observar=False)
        self.assertFalse(self.registro.registrar_falha_partida(chave, "falha_start"))
        self.registro.fechar_admissao()
        self.assertFalse(self.avaliar()["encerramento_confirmado"])

    def test_09_admitida(self):
        self.tentativa("admitida")
        self.registro.fechar_admissao()
        self.assertEqual(self.avaliar()["pendentes"], 1)

    def test_10_iniciando_mesmo_com_ciclo_confirmado(self):
        _, contexto = self.tentativa("iniciando")
        self.ciclo(contexto)
        self.registro.fechar_admissao()
        self.assertEqual(self.avaliar()["pendentes"], 1)

    def test_11_coordenador_ativo(self):
        _, contexto = self.tentativa()
        self.ciclo(contexto, retornar=False)
        self.registro.fechar_admissao()
        resultado = self.avaliar()
        self.assertEqual(resultado["pendentes"], 1)
        self.assertFalse(resultado["encerramento_confirmado"])

    def test_12_trabalhador_vivo(self):
        _, contexto = self.tentativa()
        trabalhadores = self.ciclo(contexto, retornar=False, finalizar=False)
        liberar = threading.Event()
        worker = threading.Thread(target=lambda: liberar.wait(3))
        try:
            trabalhadores.registrar_e_iniciar(worker)
            trabalhadores.bloquear_criacao()
            self.controle.finalizar(trabalhadores)
            contexto.registrar_retorno_coordenador()
            self.registro.fechar_admissao()
            resultado = self.avaliar()
            self.assertEqual(resultado["pendentes"], 1)
            self.assertFalse(resultado["encerramento_confirmado"])
        finally:
            liberar.set()
            worker.join(3)
            self.assertFalse(worker.is_alive())
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_13_sem_ciclo_ativo(self):
        _, contexto = self.tentativa()
        contexto.registrar_falha("reserva_recusada")
        self.registro.fechar_admissao()
        self.assertEqual(self.avaliar()["pendentes"], 1)

    def test_14_sem_ciclo_retornado(self):
        for erro in ("reserva_recusada", "sessao_invalida", "falha_antes_reserva", "falha"):
            for falha in (None, "falha_execucao", "falha_limpeza"):
                with self.subTest(erro=erro, falha=falha):
                    self.registro = servidor.RegistroTentativasAplicacao()
                    _, contexto = self.tentativa()
                    contexto.registrar_falha(erro)
                    contexto.registrar_retorno_coordenador(falha)
                    self.registro.fechar_admissao()
                    resultado = self.avaliar()
                    esperado = erro != "falha" and falha != "falha_limpeza"
                    self.assertEqual(resultado["encerramento_confirmado"], esperado)
                    self.assertEqual(resultado["falhas_partida_confirmadas"], 0)

    def test_15_historico_desconhecido(self):
        _, contexto = self.tentativa()
        contexto.registrar_reserva(99)
        contexto.registrar_retorno_coordenador()
        self.registro.fechar_admissao()
        with self.assertLogs("rede.servidor", level="WARNING"):
            resultado = self.avaliar()
        self.assertEqual(resultado["desconhecidas"], 1)
        self.assertFalse(resultado["encerramento_confirmado"])

    def test_16_ids_duplicados(self):
        self.confirmada()
        self.confirmada()
        self.registro.fechar_admissao()
        retrato = self.registro.obter_retrato()
        a, b = retrato["tentativas"]
        retrato["tentativas"] = (a, replace(b, tentativa_id=a.tentativa_id))
        with patch.object(self.registro, "obter_retrato", return_value=retrato):
            resultado = self.avaliar()
        self.assertFalse(resultado["encerramento_confirmado"])
        self.assertEqual(resultado["desconhecidas"], 2)

    def test_17_excecao_individual(self):
        self.confirmada()
        self.registro.fechar_admissao()
        resultado = self.avaliar(Mock(side_effect=RuntimeError("texto descartado")))
        self.assertEqual(resultado["desconhecidas"], 1)
        self.assertFalse(resultado["consistente"])

    def test_18_registro_invalido(self):
        for registro in (None, object(), {}, SimpleNamespace(obter_retrato=lambda: {})):
            self.assertFalse(self.consultar(
                registro, AVALIAR_INDIVIDUAL_REAL)["encerramento_confirmado"])
        for retrato in (None, {}, dict(admissao_fechada=1, tentativas=()),
                        dict(admissao_fechada=True, tentativas=[]),
                        dict(admissao_fechada=True, tentativas=(), total_tentativas=7)):
            with self.subTest(retrato=retrato), patch.object(self.registro, "obter_retrato", return_value=retrato):
                self.assertFalse(self.avaliar()["encerramento_confirmado"])
        with patch.object(self.registro, "obter_retrato", side_effect=RuntimeError()):
            self.assertFalse(self.avaliar()["encerramento_confirmado"])

    def test_19_ciclos_antigos_novos_e_falha(self):
        for _ in range(3):
            self.confirmada()
        chave, contexto = self.tentativa("iniciando", observar=False)
        self.falha_partida(chave, contexto)
        self.registro.fechar_admissao()
        resultado = self.avaliar()
        self.assertEqual(resultado["confirmadas"], 3)
        self.assertEqual(resultado["falhas_partida_confirmadas"], 1)
        self.assertTrue(resultado["encerramento_confirmado"])

    def threads(self, funcoes):
        erros = []
        def executar(funcao):
            try:
                funcao()
            except BaseException as erro:
                erros.append(erro)
        threads = [threading.Thread(target=executar, args=(f,)) for f in funcoes]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(5)
            self.assertFalse(thread.is_alive())
        if erros:
            raise erros[0]

    def test_20_retratos_concorrentes(self):
        for _ in range(10):
            self.confirmada()
        for _ in range(30):
            self.tentativa("iniciando", observar=False)
        for _ in range(20):
            self.assertFalse(self.avaliar()["encerramento_confirmado"])
        self.registro.fechar_admissao()
        barreira = threading.Barrier(2, timeout=5)
        def produtor():
            barreira.wait()
            for t in self.registro.obter_retrato()["tentativas"][10:]:
                self.registro.registrar_entrada_execucao(t.tentativa_id)
                self.registro.marcar_iniciada(t.tentativa_id)
                self.ciclo(t.contexto)
        def consultar():
            barreira.wait()
            for _ in range(200):
                resultado = self.avaliar()
                if resultado["encerramento_confirmado"]:
                    self.assertEqual(resultado["confirmadas"], 40)
                    self.assertTrue(all(t.contexto.coordenador_retornou.is_set()
                                        for t in self.registro.obter_retrato()["tentativas"]))
        self.threads([produtor, consultar])
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_21_critico_b_iniciando_depois_resolve(self):
        for falha in (False, True):
            with self.subTest(falha=falha):
                self.registro = servidor.RegistroTentativasAplicacao()
                _, contexto_a = self.confirmada()
                chave_b, contexto_b = self.tentativa("iniciando", observar=False)
                self.registro.fechar_admissao()
                capturou = threading.Barrier(2, timeout=5)
                liberar = threading.Barrier(2, timeout=5)
                resultados = []
                def individual(contexto):
                    resultado = AVALIAR_INDIVIDUAL_REAL(contexto)
                    if contexto is contexto_a:
                        capturou.wait()
                        liberar.wait()
                    return resultado
                def auditar():
                    capturou.wait()
                    self.assertEqual(len(self.registro.obter_retrato()["tentativas"]), 2)
                    liberar.wait()
                self.threads([lambda: resultados.append(self.avaliar(individual)), auditar])
                self.assertFalse(resultados[0]["encerramento_confirmado"])
                self.assertEqual(resultados[0]["pendentes"], 1)
                if falha:
                    self.falha_partida(chave_b, contexto_b)
                else:
                    self.registro.registrar_entrada_execucao(chave_b)
                    self.registro.marcar_iniciada(chave_b)
                    self.ciclo(contexto_b)
                self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_22_critico_transicao_durante_consulta(self):
        _, contexto_a = self.confirmada()
        chave_b, contexto_b = self.tentativa("iniciando", observar=False)
        self.registro.fechar_admissao()
        capturou = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        resultados = []
        def individual(contexto):
            resultado = AVALIAR_INDIVIDUAL_REAL(contexto)
            if contexto is contexto_a:
                capturou.wait()
                liberar.wait()
            return resultado
        def mudar():
            capturou.wait()
            self.registro.registrar_entrada_execucao(chave_b)
            self.registro.marcar_iniciada(chave_b)
            self.ciclo(contexto_b)
            liberar.wait()
        self.threads([lambda: resultados.append(self.avaliar(individual)), mudar])
        self.assertFalse(resultados[0]["encerramento_confirmado"])
        self.assertFalse(resultados[0]["consistente"])
        self.assertEqual(resultados[0]["desconhecidas"], 2)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_23_contradicoes_partida_e_contextos(self):
        self.confirmada()
        self.registro.fechar_admissao()
        original = self.registro.obter_retrato()["tentativas"][0]
        variantes = (
            replace(original, erro_partida="falha_start"),
            replace(original, estado_partida="falha_partida", erro_partida="falha_start"),
            replace(original, execucao_observada=False),
            replace(original, contexto=None),
            replace(original, contexto=object()),
            replace(original, tentativa_id=True),
            replace(original, estado_partida="fora_contrato"),
        )
        for tentativa in variantes:
            with self.subTest(tentativa=tentativa), patch.object(self.registro, "obter_retrato", return_value=dict(
                    admissao_fechada=True, tentativas=(tentativa,))):
                self.assertFalse(self.avaliar()["encerramento_confirmado"])

    def test_24_falha_comprovada_sem_contexto(self):
        chave = self.registro.admitir(None)
        self.assertTrue(self.registro.registrar_falha_partida(
            chave, "falha_criacao_thread", execucao_nao_iniciada=True))
        self.registro.fechar_admissao()
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_25_historico_divergente_e_resultados_invalidos(self):
        _, contexto = self.confirmada()
        self.registro.fechar_admissao()
        original = AVALIAR_INDIVIDUAL_REAL(contexto)
        for resultado in (None, {}, dict(original, ciclo_id=999),
                          dict(original, ciclo_id=True), dict(original, encerramento_confirmado=1),
                          dict(original, estado="sem_ciclo"), dict(original, erro_reserva="falha")):
            with self.subTest(resultado=resultado):
                self.assertFalse(self.avaliar(lambda contexto: resultado)["encerramento_confirmado"])
        with patch.object(servidor, "consultar_historico_ciclo_servidor", return_value=dict(
                ciclo_id=999, estado="confirmado", encerramento_confirmado=True,
                threads_vivas=0, erros_limpeza=False)), self.assertLogs("rede.servidor", level="WARNING"):
            self.assertFalse(self.avaliar()["encerramento_confirmado"])

    def test_26_sem_mutacao_esperas_ou_ciclo_global(self):
        self.confirmada()
        self.registro.fechar_admissao()
        antes = self.registro.obter_retrato()
        contextos = [t.contexto.obter_situacao() for t in antes["tentativas"]]
        historico = dict(self.controle._historico)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])
        depois = self.registro.obter_retrato()
        self.assertEqual(antes, depois)
        self.assertEqual(contextos, [t.contexto.obter_situacao() for t in depois["tentativas"]])
        self.assertEqual(historico, self.controle._historico)
        arvore = ast.parse(self.fontes_avaliador())
        proibidos = {"join", "wait", "start", "set", "clear", "admitir", "fechar_admissao",
                     "registrar_reserva", "registrar_retorno_coordenador", "socket", "connect"}
        for no in ast.walk(arvore):
            if isinstance(no, ast.Call) and isinstance(no.func, ast.Attribute):
                self.assertNotIn(no.func.attr, proibidos)
        self.assertNotIn("controle_ciclo_servidor", self.fontes_avaliador())

    def test_27_ciclo_duplicado_em_contextos_distintos(self):
        _, contexto_a = self.confirmada()
        _, contexto_b = self.tentativa()
        contexto_b.registrar_reserva(contexto_a.ciclo_id)
        contexto_b.registrar_retorno_coordenador()
        self.registro.fechar_admissao()
        resultado = self.avaliar()
        self.assertFalse(resultado["consistente"])
        self.assertFalse(resultado["encerramento_confirmado"])

    def test_28_revalidacao_de_contexto_e_retrato(self):
        _, contexto = self.tentativa()
        contexto.registrar_falha("reserva_recusada")
        self.registro.fechar_admissao()
        def individual(contexto):
            resultado = AVALIAR_INDIVIDUAL_REAL(contexto)
            contexto.registrar_retorno_coordenador("falha_execucao")
            return resultado
        resultado = self.avaliar(individual)
        self.assertFalse(resultado["encerramento_confirmado"])
        self.assertFalse(resultado["consistente"])
        self.assertEqual(resultado["desconhecidas"], 1)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])
        primeiro = self.registro.obter_retrato()
        with patch.object(self.registro, "obter_retrato", side_effect=[primeiro, RuntimeError()]):
            self.assertFalse(self.avaliar()["encerramento_confirmado"])
        with patch.object(contexto, "obter_situacao", return_value=dict(
                reserva_resolvida=True, ciclo_id=True, erro_reserva=None,
                coordenador_retornou=True, erro_coordenador=None)):
            self.assertFalse(self.avaliar()["encerramento_confirmado"])


if __name__ == "__main__":
    unittest.main()

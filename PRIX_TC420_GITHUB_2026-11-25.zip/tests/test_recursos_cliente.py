# Testes de recursos cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Recursos falsos; threads só no harness e nenhuma importação operacional."""
import threading
import unittest
from unittest.mock import Mock

from prototipos.recursos_cliente import RegistroRecursosCliente


class SocketFalso:
    def __init__(self):
        self.fechado = False
        self.close_chamadas = 0
        self.erro_close = None

    def close(self):
        self.close_chamadas += 1
        if self.erro_close:
            raise self.erro_close
        self.fechado = True


class ArquivoFalso(SocketFalso):
    @property
    def closed(self):
        return self.fechado


# Grupo de 36 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class RecursosCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.registro = RegistroRecursosCliente()

    def novo(self, tipo="socket_tcp", geracao=1, retentativa=1, associado_a=None, objeto=None):
        token = self.registro.reservar(tipo, geracao, retentativa, associado_a=associado_a)
        if objeto is None:
            objeto = ArquivoFalso() if tipo.startswith("arquivo_") else SocketFalso()
        self.assertTrue(self.registro.criar(token, lambda: objeto))
        return token, objeto

    def par(self, geracao=1, retentativa=1):
        socket, obj_socket = self.novo(geracao=geracao, retentativa=retentativa)
        arquivo, obj_arquivo = self.novo("arquivo_socket", geracao, retentativa, socket)
        return socket, arquivo, obj_socket, obj_arquivo

    def retrato(self, **filtros):
        return self.registro.obter_retrato(**filtros)

    def item(self, token):
        return next(r for r in self.retrato()["recursos"] if r["recurso_id"] == token.numero)

    def pendente(self):
        self.assertFalse(self.retrato()["encerramento_confirmado"])

    def test_01_socket_criado(self):
        token, _ = self.novo()
        self.assertTrue(self.item(token)["publicado"])
        self.assertEqual("ativo", self.item(token)["estado"])

    def test_02_arquivo_socket_criado(self):
        socket, arquivo, _, _ = self.par()
        self.assertEqual(socket.numero, self.item(arquivo)["associado_a"])
        self.assertEqual("arquivo_socket", self.item(arquivo)["tipo"])

    def test_03_falha_antes_criacao_exige_prova(self):
        token = self.registro.reservar("socket_tcp", 1, 1)
        with self.assertRaises(OSError):
            self.registro.criar(token, Mock(side_effect=OSError()))
        self.assertEqual("desconhecido", self.item(token)["estado"])
        self.assertTrue(self.registro.comprovar_ausencia(token, nao_alocado=True))
        self.registro.fechar_admissao()
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_04_falha_apos_alocacao_preserva_handle(self):
        token = self.registro.reservar("socket_tcp", 1, 1)
        objeto = SocketFalso()
        with self.assertRaises(ValueError):
            self.registro.criar(token, lambda: objeto, preparar=Mock(side_effect=ValueError()))
        self.assertFalse(self.item(token)["publicado"])
        self.registro.fechar_admissao()
        self.pendente()
        self.assertTrue(self.registro.fechar(token))
        self.assertTrue(objeto.fechado)
        self.assertTrue(self.retrato()["encerramento_confirmado"])
        self.assertTrue(self.item(token)["erros_criacao"])

    def test_05_publicacao_tardia_mesmo_proprietario(self):
        token = self.registro.reservar("socket_tcp", 3, 7)
        self.registro.fechar_admissao()
        objeto = SocketFalso()
        self.registro.criar(token, lambda: objeto)
        item = self.item(token)
        self.assertEqual((3, 7), (item["geracao_id"], item["retentativa_id"]))
        self.assertEqual("fechamento_solicitado", item["estado"])
        self.pendente()

    def test_06_close_normal(self):
        token, _ = self.novo()
        self.assertTrue(self.registro.fechar(token))
        self.assertEqual("close_retornou", self.item(token)["prova_fechamento"])
        self.registro.fechar_admissao()
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_07_close_com_excecao(self):
        token, objeto = self.novo()
        objeto.erro_close = OSError("nao_reter_mensagem")
        with self.assertRaises(OSError):
            self.registro.fechar(token)
        self.assertEqual("desconhecido", self.item(token)["estado"])
        self.assertNotIn("nao_reter", str(self.retrato()))
        self.registro.fechar_admissao()
        self.pendente()

    def test_08_socket_fechado_arquivo_aberto(self):
        socket, arquivo, _, obj_arquivo = self.par()
        self.registro.fechar(socket)
        self.registro.fechar_admissao()
        self.assertTrue(self.item(socket)["encerramento_confirmado"])
        self.assertFalse(obj_arquivo.closed)
        self.assertFalse(self.item(arquivo)["encerramento_confirmado"])
        self.pendente()

    def test_09_arquivo_fechado_socket_aberto(self):
        socket, arquivo, obj_socket, _ = self.par()
        self.registro.fechar(arquivo)
        self.registro.fechar_admissao()
        self.assertFalse(obj_socket.fechado)
        self.assertFalse(self.item(socket)["encerramento_confirmado"])
        self.pendente()

    def test_10_mesma_retentativa_ids_independentes(self):
        a, _ = self.novo(retentativa=7)
        b, _ = self.novo(retentativa=7)
        self.assertNotEqual(a, b)
        self.registro.fechar(a)
        self.assertEqual("ativo", self.item(b)["estado"])

    def test_11_antigo_apos_promocao(self):
        token, _ = self.novo(geracao=3, retentativa=7)
        self.registro.promover(3)
        self.registro.fechar_admissao()
        item = self.item(token)
        self.assertEqual("principal", item["modo_atual"])
        self.assertEqual((3, 7), (item["geracao_id"], item["retentativa_id"]))
        self.pendente()

    def test_12_geracoes_nao_misturam_registros(self):
        a, _ = self.novo(geracao=1)
        b, _ = self.novo(geracao=2)
        self.registro.fechar(b)
        self.registro.fechar_admissao()
        self.assertTrue(self.retrato(geracao_id=2)["encerramento_confirmado"])
        self.assertFalse(self.retrato(geracao_id=1)["encerramento_confirmado"])
        self.assertEqual(a.numero, self.retrato(geracao_id=1)["recursos"][0]["recurso_id"])
        self.pendente()

    def test_13_repeticao_nao_apaga_erro(self):
        token, objeto = self.novo()
        objeto.erro_close = OSError()
        with self.assertRaises(OSError):
            self.registro.fechar(token)
        objeto.erro_close = None
        self.assertTrue(self.registro.fechar(token))
        self.assertFalse(self.registro.fechar(token))
        self.assertEqual(2, objeto.close_chamadas)
        self.assertTrue(self.item(token)["erros_limpeza"])
        self.registro.fechar_admissao()
        self.pendente()

    def test_14_erro_original_e_close_separados(self):
        token, objeto = self.novo()
        original = ValueError("original_sem_publicar")
        objeto.erro_close = OSError("close_sem_publicar")
        with self.assertRaises(ValueError) as capturado:
            self.registro.usar(token, Mock(side_effect=original))
        self.assertIs(original, capturado.exception)
        item = self.item(token)
        self.assertEqual("atendimento", item["erros_atendimento"][0]["etapa"])
        self.assertEqual("close", item["erros_limpeza"][0]["etapa"])
        self.assertEqual(1, item["geracao_id"])
        self.assertNotIn("sem_publicar", str(item))
        self.registro.fechar_admissao()
        self.pendente()

    def executar_retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []

        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("harness")

        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)

        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_15_consulta_durante_close(self):
        token, objeto = self.novo()

        def limpar(suspender):
            def close():
                suspender()
                objeto.fechado = True
            objeto.close = close
            self.registro.fechar(token)

        def consultar():
            self.registro.fechar_admissao()
            self.assertTrue(self.item(token)["limpeza_em_curso"])
            self.assertIsNone(self.item(token)["prova_fechamento"])
            self.assertFalse(self.registro.fechar(token))
            self.pendente()

        self.executar_retido(limpar, consultar)
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_16_vazio_aberto(self):
        self.assertEqual([], self.retrato()["recursos"])
        self.pendente()

    def test_17_vazio_fechado_apenas_conjunto(self):
        self.assertTrue(self.registro.fechar_admissao())
        self.assertFalse(self.registro.fechar_admissao())
        self.assertTrue(self.retrato()["encerramento_confirmado"])
        self.assertIsNone(self.registro.reservar("socket_tcp", 1, 1))

    def test_18_desconhecido_conservador(self):
        token = self.registro.reservar("socket_tcp", 1, 1)
        self.registro.fechar_admissao()
        self.assertEqual("desconhecido", self.item(token)["estado"])
        self.assertFalse(self.registro.fechar(token))
        self.pendente()

    def test_critico_A_criacao_retida_contra_encerramento(self):
        token = self.registro.reservar("socket_tcp", 3, 7)
        objeto = SocketFalso()

        def criar(suspender):
            def alocar():
                suspender()
                return objeto
            self.registro.criar(token, alocar)

        def encerrar():
            self.registro.promover(3)
            self.registro.fechar_admissao()
            self.assertIsNone(self.registro.reservar("socket_tcp", 4, 8))
            self.assertTrue(self.item(token)["criacao_em_curso"])
            self.assertFalse(self.registro.comprovar_ausencia(token, nao_alocado=True))
            self.pendente()

        self.executar_retido(criar, encerrar)
        self.assertEqual((3, 7), (self.item(token)["geracao_id"], self.item(token)["retentativa_id"]))
        self.pendente()
        self.registro.fechar(token)
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_critico_B_observacao_retida_antes_da_publicacao(self):
        class ArquivoObservado(ArquivoFalso):
            suspender = None

            @property
            def closed(self):
                self.suspender()
                return self.fechado

        arquivo = ArquivoObservado()
        token, _ = self.novo("arquivo_comum", objeto=arquivo)

        def fechar(suspender):
            arquivo.suspender = suspender
            self.registro.fechar(token)

        def consultar():
            self.registro.fechar_admissao()
            self.assertTrue(arquivo.fechado)  # close retornou; prova ainda em coleta.
            for _ in range(30):
                self.assertTrue(self.item(token)["limpeza_em_curso"])
                self.pendente()

        self.executar_retido(fechar, consultar)
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_critico_C_socket_e_makefile_independentes(self):
        socket, arquivo, _, _ = self.par()
        self.registro.fechar(socket)
        self.registro.fechar_admissao()
        self.pendente()
        self.registro.fechar(arquivo)
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_critico_D_geracao_antiga_nao_desaparece(self):
        antiga, _ = self.novo(geracao=1, retentativa=7)
        self.registro.promover(1)
        nova, _ = self.novo(geracao=2, retentativa=8)
        self.registro.fechar(nova)
        self.registro.fechar_admissao()
        self.assertTrue(self.retrato(geracao_id=2)["encerramento_confirmado"])
        self.pendente()
        self.registro.fechar(antiga)
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_arquivo_comum_nao_depende_de_socket(self):
        token, _ = self.novo("arquivo_comum")
        self.assertIsNone(self.item(token)["associado_a"])
        self.registro.fechar(token)
        self.assertEqual("close_retornou_e_closed_true", self.item(token)["prova_fechamento"])

    def test_closed_false_nao_comprova_arquivo(self):
        objeto = ArquivoFalso()
        objeto.close = lambda: None
        token, _ = self.novo("arquivo_comum", objeto=objeto)
        self.assertFalse(self.registro.fechar(token))
        self.assertEqual("desconhecido", self.item(token)["estado"])

    def test_uso_retido_mesmo_com_close_retornado(self):
        token, _ = self.novo()

        def usar(suspender):
            self.registro.usar(token, lambda obj: suspender(), fechar_ao_sair=False)

        def fechar():
            self.registro.fechar_admissao()
            self.registro.fechar(token)
            self.assertEqual(1, self.item(token)["usos"])
            self.pendente()

        self.executar_retido(usar, fechar)
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_criacao_preparada_antes_da_publicacao_nao_fecha(self):
        token = self.registro.reservar("socket_tcp", 1, 1)
        objeto = SocketFalso()

        def criar(suspender):
            self.registro.criar(token, lambda: objeto, preparar=lambda obj: suspender())

        def consultar():
            self.registro.fechar_admissao()
            self.assertFalse(self.registro.fechar(token))
            self.assertFalse(self.item(token)["publicado"])
            self.pendente()

        self.executar_retido(criar, consultar)
        self.assertEqual(0, objeto.close_chamadas)
        self.registro.fechar(token)

    def test_fabrica_opaca_que_aloca_e_lanca_fica_desconhecida(self):
        token = self.registro.reservar("socket_tcp", 1, 1)
        recursos = []

        def fabrica():
            recursos.append(SocketFalso())
            raise OSError()

        with self.assertRaises(OSError):
            self.registro.criar(token, fabrica)
        self.assertEqual(1, len(recursos))
        self.registro.fechar_admissao()
        self.pendente()  # Não inventa prova de ausência quando não recebeu handle.

    def test_tokens_e_associacoes_invalidas(self):
        socket, _ = self.novo()
        with self.assertRaises(ValueError):
            self.registro.reservar("arquivo_socket", 2, 1, associado_a=socket)
        with self.assertRaises(ValueError):
            RegistroRecursosCliente().fechar(socket)
        self.registro.fechar(socket)
        self.assertIsNone(self.registro.reservar("arquivo_socket", 1, 1, associado_a=socket))

    def test_erro_atendimento_com_limpeza_ok_preserva_as_duas_semanticas(self):
        token, _ = self.novo()
        with self.assertRaises(ValueError):
            self.registro.usar(token, Mock(side_effect=ValueError()))
        self.assertTrue(self.item(token)["erros_atendimento"])
        self.assertTrue(self.item(token)["encerramento_confirmado"])

    def test_nao_reutiliza_id_e_copia_nao_muda_estado(self):
        a, _ = self.novo()
        self.registro.fechar(a)
        b, _ = self.novo()
        self.assertGreater(b.numero, a.numero)
        self.retrato()["recursos"][0]["erros_limpeza"].append({"etapa": "inventada"})
        self.assertEqual([], self.item(a)["erros_limpeza"])

    def test_fechamento_sem_lock_durante_operacao(self):
        token, objeto = self.novo()
        objeto.close = lambda: self.assertFalse(self.retrato()["encerramento_confirmado"])
        self.assertTrue(self.registro.fechar(token))

    def test_prova_de_ausencia_estrita_e_sem_dupla_criacao(self):
        token = self.registro.reservar("socket_tcp", 1, 1)
        with self.assertRaises(ValueError):
            self.registro.comprovar_ausencia(token, nao_alocado=1)
        self.registro.comprovar_ausencia(token, nao_alocado=True)
        fabrica = Mock()
        self.assertFalse(self.registro.criar(token, fabrica))
        fabrica.assert_not_called()

    def test_falha_close_concorrente_publicada_atomicamente(self):
        token, objeto = self.novo()

        def fechar(suspender):
            def close():
                suspender()
                raise OSError()
            objeto.close = close
            with self.assertRaises(OSError):
                self.registro.fechar(token)

        def consultar():
            self.registro.fechar_admissao()
            self.assertTrue(self.item(token)["limpeza_em_curso"])
            self.pendente()

        self.executar_retido(fechar, consultar)
        self.assertFalse(self.item(token)["limpeza_em_curso"])
        self.assertEqual("desconhecido", self.item(token)["estado"])
        self.assertTrue(self.item(token)["erros_limpeza"])
        self.pendente()

    def test_makefile_em_criacao_quando_socket_fecha(self):
        socket, _ = self.novo()
        arquivo = self.registro.reservar("arquivo_socket", 1, 1, associado_a=socket)

        def criar(suspender):
            def alocar():
                suspender()
                return ArquivoFalso()
            self.registro.criar(arquivo, alocar)

        def fechar():
            self.registro.fechar(socket)
            self.registro.fechar_admissao()
            self.assertTrue(self.item(socket)["encerramento_confirmado"])
            self.assertEqual(socket.numero, self.item(arquivo)["associado_a"])
            self.pendente()

        self.executar_retido(criar, fechar)
        self.pendente()
        self.registro.fechar(arquivo)
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_handle_duplicado_preserva_proprietario_e_incerteza(self):
        antigo, objeto = self.novo()
        novo = self.registro.reservar("socket_tcp", 2, 8)
        with self.assertRaises(ValueError):
            self.registro.criar(novo, lambda: objeto)
        self.registro.fechar(antigo)
        self.assertTrue(objeto.fechado)
        self.assertEqual(1, self.item(antigo)["geracao_id"])
        self.assertTrue(self.item(antigo)["erros_evidencia"])
        self.assertEqual("desconhecido", self.item(novo)["estado"])
        self.registro.fechar_admissao()
        self.pendente()

    def test_erro_observacao_closed_retido(self):
        class ObservacaoFalha(ArquivoFalso):
            @property
            def closed(self):
                raise OSError()

        token, objeto = self.novo("arquivo_comum", objeto=ObservacaoFalha())
        with self.assertRaises(OSError):
            self.registro.fechar(token)
        self.assertTrue(objeto.fechado)
        self.assertEqual("observacao_closed", self.item(token)["erros_evidencia"][0]["etapa"])
        self.registro.fechar_admissao()
        self.pendente()


if __name__ == "__main__":
    unittest.main()

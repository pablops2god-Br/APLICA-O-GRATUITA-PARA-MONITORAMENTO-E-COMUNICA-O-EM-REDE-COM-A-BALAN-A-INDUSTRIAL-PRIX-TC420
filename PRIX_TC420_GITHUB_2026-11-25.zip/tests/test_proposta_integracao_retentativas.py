# Testes de proposta integracao retentativas: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Ensaios da proposta; nenhuma importação/execução de módulos operacionais.

As etiquetas de caminhos representam futura injeção pelo escopo main.iniciar.
Não são adaptadores conectados ao aplicativo. Todos os recursos são metadados.
"""
import threading
import unittest
from unittest.mock import Mock

from prototipos.guarda_retentativas_cliente import GuardaRetentativasCliente
from test_guarda_retentativas_cliente import ThreadFalsa


CAMINHOS = (
    ("main.iniciar.iniciar_cliente_da_execucao/descoberta", True),
    ("main.tentar_login_automatico/resultado_cliente", True),
    ("interface.conexao.JanelaConexao.conectar/ao_encontrar_servidor", True),
    ("main.iniciar.observar_servidor", False),
    ("interface.conexao.JanelaConexao.observar_servidor", False),
)


# Grupo de 17 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class PropostaIntegracaoRetentativas(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        # Representa o escopo estável de main.iniciar, não uma janela/singleton.
        self.registro = GuardaRetentativasCliente()
        self.leitores = []
        self.threads = {}
        self.cliente = self.novo_cliente(*CAMINHOS[0])

    def novo_cliente(self, caminho, permitir_candidatura):
        geracao = self.registro.nova_geracao_cliente()
        if geracao is None:
            return None
        cliente = {
            "registro": self.registro, "geracao": geracao, "caminho": caminho,
            "permitir_candidatura": permitir_candidatura,
            "parada_local": threading.Event(),
        }
        self.leitores.append(cliente)
        return cliente

    def partir(self, cliente=None, rotina=lambda: None, *, ambiguo=False):
        cliente = self.cliente if cliente is None else cliente
        reserva = cliente["registro"].reservar_retentativa(cliente["geracao"])
        if reserva is None:
            return None

        def fabrica(alvo):
            falsa = ThreadFalsa(alvo, erro_start=ambiguo)
            self.threads[reserva] = falsa
            return falsa

        try:
            self.registro.partir(reserva, fabrica, rotina)
        except RuntimeError:
            if not ambiguo:
                raise
        return reserva

    def concluir_thread(self, reserva):
        self.threads[reserva].executar()
        self.assertTrue(self.registro.observar_termino_thread(reserva))

    def retrato(self):
        return self.registro.obter_retrato()

    def pendente(self):
        self.assertFalse(self.retrato()["conjunto_encerrado"])

    def reservar_recurso(self, reserva, tipo="socket"):
        token = self.registro.reservar_secundaria(reserva, tipo)
        self.assertIsNotNone(token)
        self.registro.publicar_secundaria(token, Mock())
        return token

    def test_01_retentativa_normal_nos_pontos_propostos(self):
        recursos = []
        reserva = None
        reserva = self.partir(rotina=lambda: recursos.append(
            self.reservar_recurso(reserva, "descoberta")))
        self.concluir_thread(reserva)
        self.assertEqual(1, len(recursos))
        self.registro.resolver_secundaria(recursos[0], responsabilidades_resolvidas=True)
        self.registro.fechar_admissao()
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_02_encerramento_recusa_nova_retentativa(self):
        self.registro.fechar_admissao()
        corpo = Mock()
        self.assertIsNone(self.partir(rotina=corpo))
        corpo.assert_not_called()
        self.assertEqual({}, self.threads)

    def test_03_start_ambiguo_nao_prova_ausencia(self):
        reserva = self.partir(ambiguo=True)
        self.registro.fechar_admissao()
        self.assertEqual("desconhecido", self.retrato()["retentativas"][0]["estado"])
        self.assertFalse(self.registro.observar_termino_thread(reserva))
        self.pendente()
        # Mesmo após lançar, o alvo pode entrar: não se perde a identidade.
        self.concluir_thread(reserva)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_04_retentativa_anterior_promocao(self):
        reserva = self.partir()
        geracao = self.cliente["geracao"]
        self.registro.promover(geracao)
        self.registro.fechar_admissao()
        item = self.retrato()["retentativas"][0]
        self.assertEqual(geracao.numero, item["geracao"])
        self.assertEqual("principal", item["modo_atual"])
        self.assertEqual(reserva.numero, item["id"])
        self.pendente()

    def test_05_nova_geracao_apos_promocao_nao_substitui_registro(self):
        antiga = self.partir()
        self.cliente["parada_local"].set()  # Representa leitor.parar na promoção.
        self.registro.promover(self.cliente["geracao"])
        posterior = self.novo_cliente(*CAMINHOS[3])
        nova = self.partir(posterior)
        self.assertIs(posterior["registro"], self.cliente["registro"])
        self.assertNotEqual(self.cliente["geracao"], posterior["geracao"])
        self.assertFalse(posterior["permitir_candidatura"])
        self.concluir_thread(nova)
        self.registro.fechar_admissao()
        self.pendente()
        self.concluir_thread(antiga)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_06_thread_concluida_com_socket_pendente(self):
        reserva = self.partir()
        socket = self.reservar_recurso(reserva)
        self.concluir_thread(reserva)
        self.registro.fechar_admissao()
        self.assertTrue(self.retrato()["retentativas"][0]["thread_terminada"])
        self.assertFalse(self.retrato()["secundarias"][0]["resolvida"])
        self.pendente()
        self.registro.resolver_secundaria(socket, responsabilidades_resolvidas=True)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_07_erro_fechamento_impede_confirmacao(self):
        reserva = self.partir()
        socket = self.reservar_recurso(reserva)
        self.concluir_thread(reserva)
        with self.assertRaises(OSError):
            self.registro.finalizar_secundaria(socket, Mock(side_effect=OSError()))
        self.registro.fechar_admissao()
        self.pendente()
        self.registro.resolver_secundaria(socket, responsabilidades_resolvidas=True)
        self.pendente()  # Erro retido mesmo após nova declaração de liberação.

    def executar_retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []

        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError("ensaio")

        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)

        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_08_consulta_concorrente_durante_finalizacao(self):
        reserva = self.partir()
        socket = self.reservar_recurso(reserva)
        self.concluir_thread(reserva)
        self.registro.fechar_admissao()

        def finalizar(suspender):
            def limpar():
                suspender()
                return True
            self.registro.finalizar_secundaria(socket, limpar)

        def consultar():
            for _ in range(30):
                retrato = self.retrato()
                self.assertTrue(retrato["secundarias"][0]["limpeza_em_curso"])
                self.assertFalse(retrato["conjunto_encerrado"])

        self.executar_retido(finalizar, consultar)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_09_duas_retentativas_independentes(self):
        a, b = self.partir(), self.partir()
        self.assertNotEqual(a, b)
        socket_b = self.reservar_recurso(b)
        self.concluir_thread(a)
        self.concluir_thread(b)
        self.registro.fechar_admissao()
        self.pendente()
        self.registro.resolver_secundaria(socket_b, responsabilidades_resolvidas=True)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_10_encerramento_repetido_preserva_retrato(self):
        self.partir()
        self.assertTrue(self.registro.fechar_admissao())
        antes = self.retrato()
        self.assertFalse(self.registro.fechar_admissao())
        self.assertEqual(antes, self.retrato())

    def test_11_falha_publicacao_deixa_responsabilidade_visivel(self):
        reserva = self.partir()
        token = self.registro.reservar_secundaria(reserva, "socket")
        efeitos = []

        def publicar():
            efeitos.append("socket_falso_criado")
            raise OSError()

        with self.assertRaises(OSError):
            self.registro.publicar_secundaria(token, publicar)
        self.concluir_thread(reserva)
        self.registro.fechar_admissao()
        self.assertEqual(["socket_falso_criado"], efeitos)
        self.assertEqual(token.numero, self.retrato()["secundarias"][0]["id"])
        self.assertEqual("desconhecido", self.retrato()["retentativas"][0]["estado"])
        self.pendente()

    def test_12_mesmo_registro_em_todos_caminhos(self):
        for caminho, candidatura in CAMINHOS:
            leitor = self.novo_cliente(caminho, candidatura)
            self.assertIs(self.registro, leitor["registro"])
            self.partir(leitor)
        self.assertEqual(len(CAMINHOS), len(self.retrato()["retentativas"]))
        self.registro.fechar_admissao()
        for leitor in self.leitores:
            self.assertIsNone(self.partir(leitor))
        self.assertTrue(all(i["parada_solicitada"] for i in self.retrato()["retentativas"]))

    def test_critico_A_admissao_vs_encerramento(self):
        barreira = threading.Barrier(3)
        admitidas, erros = [], []

        def disputar(operacao):
            try:
                barreira.wait(3)
                operacao()
            except BaseException as erro:
                erros.append(erro)

        a = threading.Thread(target=disputar, args=(lambda: admitidas.append(
            self.registro.reservar_retentativa(self.cliente["geracao"])),))
        b = threading.Thread(target=disputar, args=(self.registro.fechar_admissao,))
        a.start()
        b.start()
        barreira.wait(3)
        a.join(3)
        b.join(3)
        self.assertFalse(a.is_alive() or b.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(1, len(admitidas))
        if admitidas[0] is None:
            self.assertEqual([], self.retrato()["retentativas"])
        else:
            self.assertEqual(admitidas[0].numero, self.retrato()["retentativas"][0]["id"])
            self.pendente()
        self.assertIsNone(self.partir())

    def test_critico_B_promocao_nao_fecha_admissao_global(self):
        suspensao = []
        reserva = self.partir(rotina=lambda: suspensao[0]())

        def executar(suspender):
            suspensao.append(suspender)
            self.threads[reserva].executar()

        def promover():
            self.registro.promover(self.cliente["geracao"])
            self.cliente["parada_local"].set()
            self.assertFalse(self.retrato()["admissao_fechada"])
            self.assertTrue(self.retrato()["retentativas"][0]["entrada"])
            self.assertIsNotNone(self.novo_cliente(*CAMINHOS[4]))
            servidor_encerrado = True
            self.assertTrue(servidor_encerrado)
            self.registro.fechar_admissao()
            self.pendente()

        self.executar_retido(executar, promover)
        self.registro.observar_termino_thread(reserva)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_reconexoes_no_mesmo_worker(self):
        tokens = []
        reserva = None

        def rotina():
            for _ in range(2):
                ciclo = self.reservar_recurso(reserva, "operacao")
                tokens.append(self.reservar_recurso(reserva, "socket"))
                self.registro.resolver_secundaria(ciclo, responsabilidades_resolvidas=True)

        reserva = self.partir(rotina=rotina)
        self.concluir_thread(reserva)
        self.assertEqual(1, self.threads[reserva].starts)
        self.assertNotEqual(tokens[0], tokens[1])
        self.registro.fechar_admissao()
        self.pendente()
        self.registro.resolver_secundaria(tokens[0], responsabilidades_resolvidas=True)
        self.pendente()
        self.registro.resolver_secundaria(tokens[1], responsabilidades_resolvidas=True)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_critico_C_conclusao_vs_avaliacao_com_limpeza_pendente(self):
        reserva = self.partir()
        socket = self.reservar_recurso(reserva)

        def finalizar(suspender):
            def limpar():
                suspender()
                return True
            self.registro.finalizar_secundaria(socket, limpar)

        def concluir_e_avaliar():
            self.concluir_thread(reserva)
            self.registro.fechar_admissao()
            retrato = self.retrato()
            self.assertTrue(retrato["retentativas"][0]["thread_terminada"])
            self.assertTrue(retrato["secundarias"][0]["limpeza_em_curso"])
            self.assertFalse(retrato["conjunto_encerrado"])

        self.executar_retido(finalizar, concluir_e_avaliar)
        self.assertTrue(self.retrato()["conjunto_encerrado"])

    def test_critico_D_start_entrou_e_depois_lancou(self):
        reserva = self.registro.reservar_retentativa(self.cliente["geracao"])
        falsas = []

        def executar(suspender):
            class StartAmbiguo(ThreadFalsa):
                def start(self):
                    self.executar()
                    raise RuntimeError("start_apos_entrada")

            def fabrica(alvo):
                falsa = StartAmbiguo(alvo)
                falsas.append(falsa)
                return falsa

            with self.assertRaises(RuntimeError):
                self.registro.partir(reserva, fabrica, suspender)

        def durante():
            self.registro.fechar_admissao()
            item = self.retrato()["retentativas"][0]
            self.assertTrue(item["entrada"])
            self.assertTrue(item["partida_em_curso"])
            self.assertFalse(self.registro.comprovar_nao_execucao(
                reserva, ausencia_comprovada=True))
            self.pendente()

        self.executar_retido(executar, durante)
        self.assertEqual(1, len(falsas))
        self.assertTrue(self.retrato()["retentativas"][0]["partida_ambigua"])
        self.assertTrue(self.registro.observar_termino_thread(reserva))
        self.assertTrue(self.retrato()["conjunto_encerrado"])


if __name__ == "__main__":
    unittest.main()

"""2B.7: mesmas propriedades 2B.6 e equivalência agregada/em lote."""
import random
import unittest
from unittest.mock import patch

from rede import servidor as s
from prototipos.consultas_intervalos import RegistroConsultasExperimental
import test_identidades_intervalos as origem
from test_guarda_sockets_integrada import SocketFalso


class ConsultasIntervalos(origem.IdentidadesIntervalos):
    # Reaplica os oito testes de identidade/GC/concorrência no backend otimizado.
    def setUp(self):
        self.r = RegistroConsultasExperimental()

    def test_predicado_nao_materializa_historico(self):
        for _ in range(100):
            t = self.r.reservar_criacao_socket()
            self.resolver(t)
        self.r.bloquear_criacao()
        with patch.object(self.r, 'obter_situacao', side_effect=AssertionError('nao materializar')):
            self.assertTrue(self.r.encerramento_confirmado())
            self.r.registrar_erro_limpeza('erro simulado')
            self.assertFalse(self.r.encerramento_confirmado())

    def test_ausencia_nao_prova_encerramento(self):
        self.r.reservar_criacao_socket()
        self.r.bloquear_criacao()
        # Falha interna induzida: uma lacuna nunca pode produzir confirmação.
        self.r._reservas_socket.fortes.clear()
        self.assertFalse(self.r.encerramento_confirmado())

    def test_ordem_e_equivalencia_heterogenea_fora_de_ordem(self):
        tokens = [self.r.reservar_criacao_socket() for _ in range(500)]
        ordem = list(range(500))
        random.Random(70).shuffle(ordem)
        for i in ordem:
            if i % 4 == 0:
                self.resolver(tokens[i])
            elif i % 4 == 1:
                self.r.resolver_falha_criacao_socket(tokens[i])
            elif i % 4 == 2:
                sock = SocketFalso()
                self.r.anexar_socket(tokens[i], sock)
                self.r.publicar_socket(tokens[i])
                self.r.iniciar_limpeza_handler(tokens[i])
                self.r.publicar_limpeza_handler(tokens[i], OSError())
                self.r.encerrar_uso_socket(tokens[i])
                self.r.fechar_socket(tokens[i])
        self.r.bloquear_criacao()
        esperado = s.RegistroTrabalhadores.obter_situacao(self.r)
        self.assertEqual(self.r.obter_situacao(), esperado)
        self.assertEqual(self.r.encerramento_confirmado(), s.RegistroTrabalhadores.encerramento_confirmado(self.r))

    def test_fragmentacao_inversa_e_fusao_final(self):
        tokens = [self.r.reservar_criacao_socket() for _ in range(1000)]
        for t in reversed(tokens[::2]):
            self.resolver(t)
        self.assertEqual(len(self.r._reservas_socket.intervalos), 500)
        self.assertEqual(self.r.obter_situacao(), s.RegistroTrabalhadores.obter_situacao(self.r))
        for t in reversed(tokens[1::2]):
            self.resolver(t)
        self.assertEqual(len(self.r._reservas_socket.intervalos), 1)
        self.r.bloquear_criacao()
        self.assertTrue(self.r.encerramento_confirmado())


if __name__ == '__main__':
    unittest.main()

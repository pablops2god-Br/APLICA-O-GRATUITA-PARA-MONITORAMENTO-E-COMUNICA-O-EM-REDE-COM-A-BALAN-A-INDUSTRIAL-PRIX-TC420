# Testes de guarda sockets integrada: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Reservas operacionais reais; sockets simulados, sem portas ou equipamento."""
import threading
import unittest
from unittest.mock import Mock, patch

from rede import servidor


class LockObservado:
    def __init__(self):
        self.lock = threading.Lock()
        self.dono = None

    def acquire(self, *args, **kwargs):
        adquirido = self.lock.acquire(*args, **kwargs)
        if adquirido:
            self.dono = threading.get_ident()
        return adquirido

    def release(self):
        self.dono = None
        self.lock.release()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *args):
        self.release()


class SocketFalso:
    def __init__(self, verificar=lambda: None):
        self.verificar = verificar
        self.fechado = False
        self.fechamentos = 0
        self.enviados = []
        self.comando = b"CHECK\n"
        self.ao_aceitar = None
        self.ao_receber_udp = None

    def fileno(self):
        self.verificar()
        return -1 if self.fechado else 10

    def close(self):
        self.verificar()
        self.fechamentos += 1
        self.fechado = True

    def setsockopt(self, *args):
        self.verificar()

    def settimeout(self, *args):
        self.verificar()

    def bind(self, *args):
        self.verificar()

    def listen(self):
        self.verificar()

    def accept(self):
        self.verificar()
        return self.ao_aceitar()

    def recvfrom(self, *args):
        self.verificar()
        return self.ao_receber_udp()

    def recv(self, *args):
        self.verificar()
        return self.comando

    def sendall(self, dados):
        self.verificar()
        self.enviados.append(dados)

    def sendto(self, dados, endereco):
        self.verificar()
        self.enviados.append((dados, endereco))


# Grupo de 27 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class GuardaSocketsIntegrada(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.controle = servidor.ControleCicloServidor()
        self.controle.lock = LockObservado()
        self.registro = servidor.RegistroTrabalhadores()
        self.registro.lock = LockObservado()
        self.controle.tentar_iniciar(self.registro)
        self.parada = threading.Event()
        for nome, valor in (("evento_parada_servidor", self.parada),
                            ("controle_ciclo_servidor", self.controle)):
            remendo = patch.object(servidor, nome, valor)
            remendo.start()
            self.addCleanup(remendo.stop)

    def fora_lock(self):
        for lock in (self.registro.lock, self.controle.lock):
            self.assertNotEqual(lock.dono, threading.get_ident())

    def socket(self):
        self.fora_lock()
        return SocketFalso(self.fora_lock)

    def criar(self, preparar=lambda recurso: None):
        with patch.object(servidor.socket, "socket", side_effect=lambda *args: self.socket()):
            return servidor._criar_socket_do_ciclo(self.registro, 1, 1, preparar)

    def historico(self):
        return servidor.consultar_historico_ciclo_servidor(self.registro.ciclo_id)

    def finalizar(self):
        self.registro.limpar_sockets()
        self.controle.finalizar(self.registro)
        return self.historico()

    def liberar(self, reserva):
        self.registro.encerrar_uso_socket(reserva)
        self.registro.fechar_socket(reserva)

    def threads(self, funcoes):
        erros = []
        def executar(funcao):
            try:
                funcao()
            except BaseException as erro:
                erros.append(erro)
        threads = [threading.Thread(target=executar, args=(f,)) for f in funcoes]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(5)
            self.assertFalse(thread.is_alive())
        if erros:
            raise erros[0]

    def test_01_tcp_normal(self):
        self.parada.set()
        listener = self.socket()
        with patch.object(servidor.socket, "socket", return_value=listener):
            servidor.servidor_tcp(self.registro)
        self.assertTrue(listener.fechado)
        self.assertEqual(self.registro.obter_situacao()["criacoes_socket"][0]["ciclo_id"], 1)
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_02_udp_normal_e_protocolo(self):
        udp = self.socket()
        def receber():
            self.parada.set()
            return servidor.MENSAGEM_DESCOBERTA, ("simulado", 1)
        udp.ao_receber_udp = receber
        with patch.object(servidor.socket, "socket", return_value=udp), \
             patch.object(servidor, "obter_saude_tc420", return_value=dict(saudavel=True)):
            servidor.servidor_descoberta(self.registro)
        self.assertEqual(udp.enviados, [(servidor.MENSAGEM_RESPOSTA, ("simulado", 1))])
        self.assertTrue(udp.fechado)
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_03_cliente_associado_e_check_tcp(self):
        listener, cliente = self.socket(), self.socket()
        def aceitar():
            self.parada.set()
            return cliente, ("simulado", 1)
        listener.ao_aceitar = aceitar
        with patch.object(servidor.socket, "socket", return_value=listener), \
             patch.object(servidor, "obter_saude_tc420", return_value=dict(saudavel=True)):
            servidor.servidor_tcp(self.registro)
            for thread in self.registro.threads:
                thread.join(3)
                self.assertFalse(thread.is_alive())
        self.assertEqual(cliente.enviados, [b"TC420_SERVER_OK\n"])
        self.assertTrue(cliente.fechado)
        self.assertEqual(len(self.registro.obter_situacao()["criacoes_socket"]), 2)
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_04_bloqueio_recusa_alocador(self):
        self.registro.bloquear_criacao()
        with patch.object(servidor.socket, "socket") as alocar:
            self.assertEqual(servidor._criar_socket_do_ciclo(self.registro, 1, 1, lambda s: None), (None, None))
        alocar.assert_not_called()

    def test_05_antes_do_bloqueio(self):
        reserva = self.registro.reservar_criacao_socket()
        self.registro.bloquear_criacao()
        recurso = self.socket()
        self.registro.anexar_socket(reserva, recurso)
        self.assertFalse(self.registro.publicar_socket(reserva))
        self.assertTrue(self.registro.fechar_socket(reserva))
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_06_sem_alocacao_comprovada(self):
        reserva = self.registro.reservar_criacao_socket()
        self.assertTrue(self.registro.resolver_falha_criacao_socket(
            reserva, sem_alocacao_comprovada=True))
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_07_falha_apos_alocar(self):
        recurso = self.socket()
        with patch.object(servidor.socket, "socket", return_value=recurso):
            with self.assertRaises(RuntimeError):
                servidor._criar_socket_do_ciclo(self.registro, 1, 1, Mock(side_effect=RuntimeError()))
        self.assertTrue(recurso.fechado)
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_08_falha_registro(self):
        for metodo in ("anexar_socket", "publicar_socket"):
            with self.subTest(metodo=metodo):
                recurso = self.socket()
                with patch.object(servidor.socket, "socket", return_value=recurso), \
                     patch.object(self.registro, metodo, side_effect=RuntimeError()):
                    with self.assertRaises(RuntimeError):
                        servidor._criar_socket_do_ciclo(self.registro, 1, 1, lambda s: None)
                self.assertTrue(recurso.fechado)
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_09_encerramento_durante_criacao(self):
        retidos = []
        def preparar(recurso):
            retidos.append(recurso)
            self.assertFalse(self.finalizar()["encerramento_confirmado"])
        self.assertEqual(self.criar(preparar), (None, None))
        self.assertTrue(retidos[0].fechado)
        self.assertTrue(self.historico()["encerramento_confirmado"])

    def test_10_publicacao_tardia(self):
        recurso = self.socket()
        def preparar(recurso):
            self.registro.bloquear_criacao()
        with patch.object(servidor.socket, "socket", return_value=recurso):
            resultado = servidor._criar_socket_do_ciclo(self.registro, 1, 1, preparar)
        self.assertEqual(resultado, (None, None))
        self.assertTrue(recurso.fechado)

    def test_11_dois_ciclos(self):
        reserva_a, recurso_a = self.criar()
        b = servidor.RegistroTrabalhadores()
        reserva_b = b.reservar_criacao_socket()
        recurso_b = SocketFalso()
        b.anexar_socket(reserva_b, recurso_b)
        b.publicar_socket(reserva_b)
        self.assertFalse(b.fechar_socket(reserva_a))
        self.liberar(reserva_a)
        self.finalizar()
        self.assertTrue(recurso_a.fechado)
        self.assertFalse(recurso_b.fechado)
        self.assertFalse(self.registro.fechar_socket(reserva_b))

    def test_12_reserva_pendente_impede_historico(self):
        self.registro.reservar_criacao_socket()
        self.assertFalse(self.finalizar()["encerramento_confirmado"])
        self.assertFalse(self.controle._compactar_ciclo(1))
        self.assertFalse(self.controle.tentar_iniciar(servidor.RegistroTrabalhadores()))

    def test_13_falha_close(self):
        reserva, recurso = self.criar()
        self.registro.encerrar_uso_socket(reserva)
        with patch.object(recurso, "close", side_effect=OSError()):
            self.assertFalse(self.finalizar()["encerramento_confirmado"])
        self.assertEqual(self.registro.obter_situacao()["erros_limpeza"], ["falha_limpeza_socket"])
        self.assertFalse(self.controle._compactar_ciclo(1))

    def test_14_limpeza_repetida(self):
        reserva, recurso = self.criar()
        self.liberar(reserva)
        for _ in range(3):
            self.registro.limpar_sockets()
        self.assertEqual(recurso.fechamentos, 1)

    def test_15_excecao_handler_recurso_rastreado(self):
        reserva, recurso = self.criar()
        with patch.object(recurso, "recv", side_effect=RuntimeError()):
            with self.assertRaises(RuntimeError):
                servidor._atender_cliente_do_ciclo(recurso, ("simulado", 1), self.registro, reserva)
        self.assertTrue(recurso.fechado)
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_16_historico_durante_close(self):
        reserva, recurso = self.criar()
        self.registro.encerrar_uso_socket(reserva)
        entrou = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        close_real = recurso.close
        def fechar():
            self.fora_lock()
            entrou.wait()
            liberar.wait()
            close_real()
        def consultar():
            entrou.wait()
            self.registro.bloquear_criacao()
            self.controle.finalizar(self.registro)
            self.assertFalse(self.historico()["encerramento_confirmado"])
            self.assertFalse(self.controle._compactar_ciclo(1))
            liberar.wait()
        with patch.object(recurso, "close", side_effect=fechar):
            self.threads([lambda: self.registro.fechar_socket(reserva), consultar])
        self.assertTrue(self.historico()["encerramento_confirmado"])

    def test_17_critico_a_publicacao_tardia(self):
        entrou = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        terminou = threading.Barrier(2, timeout=5)
        recursos = []
        def preparar(recurso):
            self.fora_lock()
            recursos.append(recurso)
            entrou.wait()
            liberar.wait()
        def produzir():
            self.assertEqual(self.criar(preparar), (None, None))
            terminou.wait()
        def encerrar():
            entrou.wait()
            self.assertFalse(self.finalizar()["encerramento_confirmado"])
            self.assertIsNone(self.registro.reservar_criacao_socket())
            liberar.wait()
            terminou.wait()
        self.threads([produzir, encerrar])
        self.assertTrue(recursos[0].fechado)
        self.assertTrue(self.historico()["encerramento_confirmado"])

    def test_18_critico_b_parcial_sem_prova(self):
        recurso = self.socket()
        with patch.object(servidor.socket, "socket", return_value=recurso), \
             patch.object(self.registro, "anexar_socket", side_effect=RuntimeError()), \
             patch.object(recurso, "close", side_effect=OSError()):
            with self.assertRaises(RuntimeError):
                servidor._criar_socket_do_ciclo(self.registro, 1, 1, lambda s: None)
        self.assertFalse(self.finalizar()["encerramento_confirmado"])
        self.assertFalse(recurso.fechado)
        self.assertEqual(self.registro.obter_situacao()["criacoes_socket"][0]["estado"], "erro_limpeza")

    def test_19_critico_c_accept_tardio(self):
        listener, cliente = self.socket(), self.socket()
        aceitando = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        def aceitar():
            self.fora_lock()
            aceitando.wait()
            liberar.wait()
            return cliente, ("simulado", 1)
        listener.ao_aceitar = aceitar
        def encerrar():
            aceitando.wait()
            self.assertFalse(self.finalizar()["encerramento_confirmado"])
            liberar.wait()
        with patch.object(servidor.socket, "socket", return_value=listener):
            self.threads([lambda: servidor.servidor_tcp(self.registro), encerrar])
        self.assertFalse(self.registro.threads)
        self.assertTrue(cliente.fechado)
        self.assertTrue(listener.fechado)
        self.assertTrue(self.historico()["encerramento_confirmado"])

    def test_20_timeout_accept_resolve_sem_recurso(self):
        listener = self.socket()
        def aceitar():
            self.parada.set()
            raise servidor.socket.timeout()
        listener.ao_aceitar = aceitar
        with patch.object(servidor.socket, "socket", return_value=listener):
            servidor.servidor_tcp(self.registro)
        self.assertTrue(self.finalizar()["encerramento_confirmado"])

    def test_21_alocacao_opaca_incerta(self):
        with patch.object(servidor.socket, "socket", side_effect=OSError()):
            with self.assertRaises(OSError):
                servidor._criar_socket_do_ciclo(self.registro, 1, 1, lambda s: None)
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_22_start_ambiguo_handler(self):
        listener, cliente = self.socket(), self.socket()
        listener.ao_aceitar = lambda: (cliente, ("simulado", 1))
        classe = threading.Thread
        class Ambigua(classe):
            def start(thread):
                raise RuntimeError()
        with patch.object(servidor.socket, "socket", return_value=listener), \
             patch.object(servidor.threading, "Thread", Ambigua):
            with self.assertRaises(RuntimeError):
                servidor.servidor_tcp(self.registro)
        self.assertFalse(cliente.fechado)
        self.assertEqual(len(self.registro.threads), 1)
        self.assertFalse(self.finalizar()["encerramento_confirmado"])

    def test_23_a_antigo_nao_limpa_b_novo(self):
        reserva_a, recurso_a = self.criar()
        self.liberar(reserva_a)
        self.assertTrue(self.finalizar()["encerramento_confirmado"])
        b = servidor.RegistroTrabalhadores()
        self.assertTrue(self.controle.tentar_iniciar(b))
        reserva_b = b.reservar_criacao_socket()
        recurso_b = SocketFalso()
        b.anexar_socket(reserva_b, recurso_b)
        b.publicar_socket(reserva_b)
        self.registro.limpar_sockets()
        self.assertFalse(recurso_b.fechado)
        self.assertEqual(reserva_b.ciclo_id, 2)
        self.assertEqual(recurso_a.fechamentos, 1)
        self.assertTrue(self.controle._compactar_ciclo(1))

    def test_24_close_handler_falha_recurso_pendente(self):
        reserva, recurso = self.criar()
        with patch.object(recurso, "close", side_effect=OSError()), \
             patch.object(servidor, "obter_saude_tc420", return_value=dict(saudavel=True)):
            with self.assertRaises(OSError):
                servidor._atender_cliente_do_ciclo(recurso, ("simulado", 1), self.registro, reserva)
        self.assertFalse(self.finalizar()["encerramento_confirmado"])
        self.assertFalse(recurso.fechado)

    def test_25_publicos_respeitam_reserva_pendente(self):
        contexto = servidor.ContextoCicloServidor()
        contexto.registrar_reserva(self.registro.ciclo_id)
        contexto.registrar_retorno_coordenador()
        aplicacao = servidor.RegistroTentativasAplicacao()
        tentativa = aplicacao.admitir(contexto)
        aplicacao.marcar_iniciando(tentativa)
        aplicacao.registrar_entrada_execucao(tentativa)
        aplicacao.marcar_iniciada(tentativa)
        aplicacao.fechar_admissao()
        reserva = self.registro.reservar_criacao_socket()
        self.finalizar()
        self.assertFalse(servidor.avaliar_encerramento_tentativa(contexto)["encerramento_confirmado"])
        self.assertFalse(servidor.avaliar_encerramento_aplicacao(aplicacao)["encerramento_confirmado"])
        self.registro.resolver_falha_criacao_socket(reserva, sem_alocacao_comprovada=True)
        self.assertTrue(servidor.avaliar_encerramento_aplicacao(aplicacao)["encerramento_confirmado"])

    def test_26_coordenador_injeta_registro_em_tcp_e_udp(self):
        criadas = []
        parada = self.parada
        class ThreadSimulada:
            def __init__(thread, target, args=(), kwargs=None, daemon=True):
                thread.target, thread.kwargs = target, kwargs or {}
                thread.name = "worker-simulado"
                criadas.append(thread)

            def start(thread):
                if thread.target is servidor.ler_tc420:
                    parada.set()

            def join(thread, timeout=None):
                pass

            def is_alive(thread):
                return False
        controle = servidor.ControleCicloServidor()
        with patch.object(servidor, "controle_ciclo_servidor", controle), \
             patch.object(servidor.threading, "Thread", ThreadSimulada):
            servidor.iniciar_servidor(Mock(token=object()))
        tcp = next(t for t in criadas if t.target is servidor.servidor_tcp)
        udp = next(t for t in criadas if t.target is servidor.servidor_descoberta)
        self.assertIs(tcp.kwargs["registro_trabalhadores"], udp.kwargs["registro_trabalhadores"])

    def test_27_gate_fecha_entre_publicacao_e_partida_handler(self):
        listener, cliente = self.socket(), self.socket()
        def aceitar():
            self.parada.set()
            return cliente, ("simulado", 1)
        listener.ao_aceitar = aceitar
        iniciar_original = self.registro.registrar_e_iniciar
        def bloquear_e_iniciar(thread):
            self.registro.bloquear_criacao()
            return iniciar_original(thread)
        with patch.object(servidor.socket, "socket", return_value=listener), \
             patch.object(self.registro, "registrar_e_iniciar", side_effect=bloquear_e_iniciar):
            servidor.servidor_tcp(self.registro)
        self.assertFalse(self.registro.threads)
        self.assertTrue(cliente.fechado)
        self.assertTrue(self.finalizar()["encerramento_confirmado"])


if __name__ == "__main__":
    unittest.main()

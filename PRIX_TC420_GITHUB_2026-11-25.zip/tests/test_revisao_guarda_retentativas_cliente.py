# Testes de revisao guarda retentativas cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-D3-B2-B1: guarda real, threads falsas e concorrencia apenas no ensaio."""
from contextlib import ExitStack
import threading
import unittest
from unittest.mock import Mock, patch

from prototipos.guarda_retentativas_cliente import GuardaRetentativasCliente
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from test_guarda_retentativas_cliente import ThreadFalsa
from test_descoberta_cliente_integrada import SocketDescobertaFalso
import test_associacoes_retentativas_cliente as ac2c


# Grupo de 41 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class RevisaoGuardaRetentativasCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.guarda = self.infra.registro_retentativas
        self.geracao = self.guarda.nova_geracao_cliente()
        self.threads = {}

    def evidencia(self):
        r = self.infra.obter_evidencia_temporal_retentativas()
        self.assertFalse(r['dependencias_temporais_cobertas'])
        self.assertFalse(r['snapshot_atomico'])
        self.assertFalse(r['encerramento_cliente_confirmado'])
        self.assertFalse(r['encerramento_global_confirmado'])
        return r

    def revisao(self):
        return self.guarda.obter_revisao()['revisao']

    def reservar(self, geracao=None):
        return self.guarda.reservar_retentativa(geracao or self.geracao)

    def partir(self, token, rotina=lambda: None, imediato=False, ambiguo=False):
        def fabricar(alvo):
            thread = ThreadFalsa(alvo, erro_start=ambiguo)
            thread.is_alive = Mock(wraps=thread.is_alive)
            if imediato:
                thread.start = Mock(side_effect=thread.executar)
            self.threads[token] = thread
            return thread
        return self.guarda.partir(token, fabricar, rotina)

    def terminar(self, token):
        self.threads[token].executar()
        self.assertTrue(self.guarda.observar_termino_thread(token))

    def item(self, token):
        return next(i for i in self.evidencia()['retrato']['retentativas'] if i['id'] == token.numero)

    def tarefa(self, chamada):
        resultados, erros = [], []
        def alvo():
            try:
                resultados.append(chamada())
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=alvo)
        thread.start()
        return thread, resultados, erros

    def concluir(self, tarefa):
        tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())

    def test_01_guarda_nova(self):
        guarda = GuardaRetentativasCliente()
        selo = guarda.obter_revisao()
        self.assertEqual(0, selo['revisao'])
        self.assertTrue(selo['confiavel'])
        self.assertEqual([], guarda.obter_evidencia_temporal()['geracoes'])

    def test_02_primeira_reserva(self):
        antes = self.revisao()
        token = self.reservar()
        self.assertEqual(antes + 1, self.revisao())
        self.assertEqual('admitida', self.item(token)['estado'])

    def test_03_segunda_reserva(self):
        a = self.reservar()
        antes = self.revisao()
        b = self.reservar()
        self.assertEqual(antes + 1, self.revisao())
        self.assertNotEqual(a, b)
        self.assertEqual(2, len(self.evidencia()['retrato']['retentativas']))

    def test_04_recusa_sem_efeito(self):
        self.guarda.fechar_admissao()
        antes = self.evidencia()
        self.assertIsNone(self.reservar())
        self.assertIsNone(self.guarda.nova_geracao_cliente())
        self.assertFalse(self.guarda.fechar_admissao())
        self.assertEqual(antes, self.evidencia())

    def test_05_partida_normal(self):
        token = self.reservar()
        antes = self.revisao()
        self.assertTrue(self.partir(token))
        self.assertGreater(self.revisao(), antes)
        self.assertTrue(self.item(token)['partida_resolvida'])
        self.assertTrue(self.item(token)['start_invocado'])

    def test_06_partida_ambigua(self):
        token = self.reservar()
        antes = self.revisao()
        with self.assertRaises(RuntimeError):
            self.partir(token, ambiguo=True)
        self.assertGreater(self.revisao(), antes)
        item = self.item(token)
        self.assertTrue(item['partida_ambigua'])
        self.assertFalse(item['ausencia_comprovada'])
        self.assertEqual('desconhecido', item['estado'])

    def test_07_entrada_publicada(self):
        token = self.reservar()
        versao = []
        def rotina():
            versao.append(self.revisao())
            self.assertTrue(self.item(token)['entrada'])
            self.assertFalse(self.item(token)['retorno'])
        self.partir(token, rotina)
        antes = self.revisao()
        self.threads[token].executar()
        self.assertGreater(versao[0], antes)

    def test_08_retorno_normal_sem_observacao(self):
        token = self.reservar()
        self.partir(token)
        antes = self.revisao()
        self.threads[token].executar()
        self.assertGreater(self.revisao(), antes)
        self.assertTrue(self.item(token)['retorno'])
        self.assertFalse(self.item(token)['thread_terminada'])
        self.threads[token].is_alive.assert_not_called()

    def test_09_retorno_excepcional(self):
        token = self.reservar()
        original = OSError('operacao_simulada')
        self.partir(token, Mock(side_effect=original))
        antes = self.revisao()
        with self.assertRaises(OSError) as recebido:
            self.threads[token].executar()
        self.assertIs(original, recebido.exception)
        self.assertGreater(self.revisao(), antes)
        self.assertTrue(self.item(token)['retorno'])
        self.assertTrue(self.item(token)['erro'])
        self.assertTrue(self.evidencia()['confiavel'])

    def test_10_termino_observado(self):
        token = self.reservar()
        self.partir(token)
        self.threads[token].executar()
        antes = self.revisao()
        self.assertTrue(self.guarda.observar_termino_thread(token))
        self.assertEqual(antes + 1, self.revisao())
        self.assertTrue(self.item(token)['thread_terminada'])

    def test_11_observacao_repetida(self):
        token = self.reservar()
        self.partir(token)
        self.terminar(token)
        antes = self.evidencia()
        self.assertTrue(self.guarda.observar_termino_thread(token))
        self.assertEqual(antes, self.evidencia())

    def test_12_ABA(self):
        antes = self.evidencia()
        token = self.reservar()
        self.partir(token)
        self.terminar(token)
        depois = self.evidencia()
        self.assertGreater(depois['revisao'], antes['revisao'])
        self.assertTrue(all(i['estado'] == 'encerramento_confirmado' for i in depois['retrato']['retentativas']))

    def test_13_falha_publicacao(self):
        token = self.reservar()
        self.partir(token)
        publicar = self.guarda._publicar_saida
        def parcial(*args, **kwargs):
            publicar(*args, **kwargs)
            raise OSError('publicacao_simulada')
        with patch.object(self.guarda, '_publicar_saida', side_effect=parcial):
            with self.assertRaises(OSError):
                self.threads[token].executar()
        self.assertFalse(self.evidencia()['confiavel'])
        self.assertFalse(self.item(token)['retorno'])
        self.assertTrue(self.item(token)['erro'])

    def test_14_promocao_antiga(self):
        a = self.reservar()
        self.partir(a)
        identidade = self.guarda.fonte_id
        self.guarda.promover(self.geracao)
        nova = self.guarda.nova_geracao_cliente()
        b = self.reservar(nova)
        self.partir(b)
        self.terminar(b)
        antes = self.revisao()
        self.terminar(a)
        self.assertGreater(self.revisao(), antes)
        self.assertEqual(identidade, self.guarda.fonte_id)
        self.assertEqual(self.geracao.numero, self.item(a)['geracao'])
        self.assertEqual('principal', self.item(a)['modo_atual'])

    def test_15_consultas_passivas(self):
        token = self.reservar()
        self.partir(token)
        antes = self.evidencia()
        with ExitStack() as pilha:
            for obj, nome in ((self.guarda, 'observar_termino_thread'),
                              (self.guarda, 'fechar_admissao'), (self.guarda, '_avancar_revisao'),
                              (self.infra.registro_recursos, 'obter_retrato'),
                              (InfraestruturaRegistrosCliente, 'obter_associacoes_retentativas')):
                pilha.enter_context(patch.object(obj, nome, side_effect=AssertionError(nome)))
            self.assertEqual(antes, self.evidencia())
            self.assertEqual(antes['revisao'], self.guarda.obter_revisao()['revisao'])
            self.assertEqual(antes['retrato'], self.guarda.obter_retrato())
        self.threads[token].is_alive.assert_not_called()

    def test_16_limpeza_externa_nao_muda_selo(self):
        dono = self.infra.preparar_descoberta()
        socket = dono.abrir_socket(SocketDescobertaFalso)
        self.addCleanup(socket.close)
        token = self.reservar()
        self.partir(token)
        self.terminar(token)
        antes = self.evidencia()
        socket.close()
        self.assertEqual(antes, self.evidencia())

    def test_corrida_A_reserva_consulta(self):
        entrou, liberar, leu, iniciou = [threading.Event() for _ in range(4)]
        avancar = self.guarda._avancar_revisao
        antes = self.revisao()
        def pausa():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            avancar()
        def ler():
            iniciou.set()
            r = self.evidencia()
            leu.set()
            return r
        with patch.object(self.guarda, '_avancar_revisao', side_effect=pausa):
            escritor = self.tarefa(self.reservar)
            leitor = None
            try:
                self.assertTrue(entrou.wait(3))
                self.assertTrue(self.guarda._lock.locked())
                leitor = self.tarefa(ler)
                self.assertTrue(iniciou.wait(3))
                self.assertFalse(leu.is_set())
            finally:
                liberar.set()
                self.concluir(escritor)
                if leitor is not None:
                    self.concluir(leitor)
        self.assertEqual([], escritor[2] + leitor[2])
        r, = leitor[1]
        self.assertEqual(antes + 1, r['revisao'])
        self.assertEqual(1, len(r['retrato']['retentativas']))
        self.assertTrue(r['confiavel'])

    def test_corrida_B_entrada_antes_partida_publicada(self):
        token = self.reservar()
        capturas = []
        def corpo():
            capturas.append(self.evidencia())
            self.assertFalse(self.guarda._lock.locked())
        self.partir(token, corpo, imediato=True)
        dentro = capturas[0]
        item = dentro['retrato']['retentativas'][0]
        self.assertTrue(item['entrada'])
        self.assertTrue(item['partida_em_curso'])
        self.assertFalse(item['partida_resolvida'])
        self.assertGreater(self.revisao(), dentro['revisao'])
        self.assertFalse(self.item(token)['thread_terminada'])

    def test_corrida_C_ABA_completo(self):
        antes = self.guarda.obter_revisao()
        def ciclo():
            token = self.reservar()
            self.partir(token)
            self.terminar(token)
        tarefa = self.tarefa(ciclo)
        self.concluir(tarefa)
        self.assertEqual([], tarefa[2])
        self.assertGreater(self.revisao(), antes['revisao'])
        self.assertTrue(all(i['estado'] == 'encerramento_confirmado'
                            for i in self.evidencia()['retrato']['retentativas']))

    def test_corrida_D_retorno_antigo(self):
        a = self.reservar()
        entrou, liberar = threading.Event(), threading.Event()
        def corpo():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
        self.partir(a, corpo)
        tarefa = self.tarefa(self.threads[a].executar)
        try:
            self.assertTrue(entrou.wait(3))
            self.guarda.promover(self.geracao)
            b = self.reservar(self.guarda.nova_geracao_cliente())
            self.partir(b)
            self.terminar(b)
            antes = self.evidencia()
            self.assertFalse(self.item(a)['retorno'])
        finally:
            liberar.set()
            self.concluir(tarefa)
        self.assertEqual([], tarefa[2])
        self.assertGreater(self.revisao(), antes['revisao'])
        self.assertTrue(self.item(a)['retorno'])
        self.assertFalse(self.item(a)['thread_terminada'])
        self.assertTrue(self.guarda.observar_termino_thread(a))

    def test_corrida_E_mutacao_parcial(self):
        antes = self.revisao()
        with patch.object(self.guarda, '_avancar_revisao', side_effect=OSError()):
            with self.assertRaises(OSError):
                self.reservar()
        r = self.evidencia()
        self.assertFalse(r['confiavel'])
        self.assertEqual(antes, r['revisao'])
        self.assertEqual(1, len(r['retrato']['retentativas']))

    def test_corrida_F_observadores_concorrentes(self):
        token = self.reservar()
        self.partir(token)
        self.threads[token].executar()
        barreira = threading.Barrier(2)
        def observar():
            self.assertFalse(self.guarda._lock.locked())
            barreira.wait(3)
            return False
        self.threads[token].is_alive.side_effect = observar
        antes = self.revisao()
        a = self.tarefa(lambda: self.guarda.observar_termino_thread(token))
        b = self.tarefa(lambda: self.guarda.observar_termino_thread(token))
        self.concluir(a)
        self.concluir(b)
        self.assertEqual([], a[2] + b[2])
        self.assertEqual([True, True], a[1] + b[1])
        self.assertEqual(antes + 1, self.revisao())

    def test_adicional_guarda_AC2C_independente_de_UDP(self):
        fx = ac2c.AssociacoesRetentativasCliente()
        fx.setUp()
        registro = fx.infra.registro_recursos
        fechar = registro.fechar
        tokens = []
        def reter(token):
            recurso = next(r for r in registro.obter_retrato()['recursos'] if r['recurso_id'] == token.numero)
            if recurso['tipo'] == 'socket_udp':
                tokens.append(token)
                return False
            return fechar(token)
        with patch.object(registro, 'fechar', side_effect=reter):
            fx.executar_descoberta()
        for token in tokens:
            self.addCleanup(fechar, token)
        self.assertTrue(fx.infra.observar_termino_retentativas()[-1]['termino_observado'])
        antes = fx.infra.obter_evidencia_temporal_retentativas()
        associacoes = fx.infra.obter_associacoes_retentativas()
        self.assertTrue(tokens)
        for token in tokens:
            fechar(token)
        self.assertEqual(antes, fx.infra.obter_evidencia_temporal_retentativas())
        self.assertNotEqual(associacoes, fx.infra.obter_associacoes_retentativas())
        self.assertFalse(fx.infra.avaliar_responsabilidades_cliente()['encerramento_cliente_confirmado'])

    def test_identidades_temporais_independentes(self):
        a, b = GuardaRetentativasCliente(), GuardaRetentativasCliente()
        self.assertEqual(a.obter_revisao()['revisao'], b.obter_revisao()['revisao'])
        self.assertNotEqual(a.fonte_id, b.fonte_id)
        with self.assertRaises(AttributeError):
            a.fonte_id = 'outra'

    def test_geracao_sem_reserva_e_papel_sao_revisados(self):
        legado = self.guarda.obter_retrato()
        antes = self.revisao()
        geracao = self.guarda.nova_geracao_cliente()
        self.assertEqual(legado, self.guarda.obter_retrato())
        self.assertEqual(antes + 1, self.revisao())
        self.guarda.promover(geracao)
        self.assertEqual(antes + 2, self.revisao())
        self.guarda.promover(geracao)
        self.assertEqual(antes + 2, self.revisao())

    def test_gate_e_cancelamento_antes_partida(self):
        token = self.reservar()
        antes = self.revisao()
        self.guarda.fechar_admissao()
        self.assertEqual(antes + 1, self.revisao())
        fabrica = Mock()
        self.assertFalse(self.guarda.partir(token, fabrica, lambda: None))
        fabrica.assert_not_called()
        self.assertGreater(self.revisao(), antes + 1)
        self.assertTrue(self.item(token)['ausencia_comprovada'])

    def test_prova_ausencia_e_idempotencia(self):
        token = self.reservar()
        antes = self.revisao()
        self.assertTrue(self.guarda.comprovar_nao_execucao(token, ausencia_comprovada=True))
        self.assertEqual(antes + 1, self.revisao())
        self.assertTrue(self.guarda.comprovar_nao_execucao(token, ausencia_comprovada=True))
        self.assertEqual(antes + 1, self.revisao())

    def test_secundarias_publicacao_resolucao_e_limpeza(self):
        token = self.reservar()
        secundaria = self.guarda.reservar_secundaria(token, 'socket')
        antes = self.revisao()
        def publicar():
            self.assertFalse(self.guarda._lock.locked())
            self.assertGreater(self.revisao(), antes)
        self.assertTrue(self.guarda.publicar_secundaria(secundaria, publicar))
        self.assertGreater(self.revisao(), antes)
        self.assertIn(secundaria.numero, self.evidencia()['publicacoes_tentadas'])
        antes = self.revisao()
        self.assertTrue(self.guarda.finalizar_secundaria(secundaria, lambda: True))
        self.assertGreater(self.revisao(), antes)
        antes = self.revisao()
        self.assertTrue(self.guarda.resolver_secundaria(secundaria, responsabilidades_resolvidas=True))
        self.assertEqual(antes, self.revisao())

    def test_secundaria_falha_publicacao_confianca_sticky(self):
        token = self.reservar()
        s = self.guarda.reservar_secundaria(token, 'operacao')
        with self.assertRaises(OSError):
            self.guarda.publicar_secundaria(s, Mock(side_effect=OSError()))
        self.assertFalse(self.evidencia()['confiavel'])
        self.guarda.nova_geracao_cliente()
        self.assertFalse(self.evidencia()['confiavel'])

    def test_erro_limpeza_e_revisao_sem_duplicar(self):
        token = self.reservar()
        s = self.guarda.reservar_secundaria(token, 'socket')
        antes = self.revisao()
        self.guarda.registrar_erro_limpeza(s)
        self.assertEqual(antes + 1, self.revisao())
        self.guarda.registrar_erro_limpeza(s)
        self.assertEqual(antes + 1, self.revisao())

    def test_falha_antes_mutacao_preserva_estado(self):
        antes = self.evidencia()
        estrangeira = GuardaRetentativasCliente().nova_geracao_cliente()
        with self.assertRaises(ValueError):
            self.guarda.reservar_retentativa(estrangeira)
        self.assertEqual(antes, self.evidencia())

    def test_incremento_silencioso_e_falha_apos_incremento(self):
        with patch.object(self.guarda, '_avancar_revisao', return_value=None):
            with self.assertRaisesRegex(RuntimeError, 'revisao_guarda_nao_publicada'):
                self.reservar()
        self.assertFalse(self.evidencia()['confiavel'])
        avancar = self.guarda._avancar_revisao
        def parcial():
            avancar()
            raise OSError()
        with patch.object(self.guarda, '_avancar_revisao', side_effect=parcial):
            with self.assertRaises(OSError):
                self.reservar()
        self.assertFalse(self.evidencia()['confiavel'])

    def test_erro_operacional_preservado_ante_falha_temporal(self):
        token = self.reservar()
        original = ValueError('original_simulado')
        self.partir(token, Mock(side_effect=original))
        avancar = self.guarda._avancar_revisao
        chamadas = []
        adicional = OSError('revisao_simulada')
        def falhar():
            chamadas.append(True)
            if len(chamadas) == 2:
                raise adicional
            avancar()
        with patch.object(self.guarda, '_avancar_revisao', side_effect=falhar):
            with self.assertRaises(ValueError) as recebido:
                self.threads[token].executar()
        self.assertIs(original, recebido.exception)
        self.assertIs(adicional, original.__cause__)
        self.assertFalse(self.evidencia()['confiavel'])

    def test_start_preserva_erro_apesar_de_falhas_posteriores(self):
        token = self.reservar()
        original = ValueError('start_simulado')
        adicional = OSError('revisao_simulada')
        def fabricar(alvo):
            def start():
                self.guarda._avancar_revisao = Mock(side_effect=adicional)
                raise original
            return Mock(start=start)
        avancar = self.guarda._avancar_revisao
        try:
            with self.assertRaises(ValueError) as recebido:
                self.guarda.partir(token, fabricar, lambda: None)
        finally:
            self.guarda._avancar_revisao = avancar
        self.assertIs(original, recebido.exception)
        self.assertIs(adicional, original.__cause__)
        self.assertFalse(self.evidencia()['confiavel'])

    def test_API_legada_e_composicao_independentes(self):
        antes = self.guarda.obter_retrato()
        self.assertEqual({'admissao_fechada', 'retentativas', 'secundarias', 'conjunto_encerrado'}, set(antes))
        self.assertNotIn('revisao', antes)
        selo = self.guarda.obter_revisao()
        with patch.object(self.guarda, 'obter_revisao', side_effect=AssertionError()), \
                patch.object(self.guarda, 'obter_evidencia_temporal', side_effect=AssertionError()):
            r = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(r['encerramento_cliente_confirmado'])
        self.assertFalse(r['encerramento_global_confirmado'])
        self.assertEqual(selo, self.guarda.obter_revisao())

    def test_thread_nao_e_comparada_por_igualdade(self):
        token = self.reservar()
        class ThreadSemIgualdade(ThreadFalsa):
            def __eq__(self, outra):
                raise AssertionError('comparacao_de_thread')
        thread = []
        def fabricar(alvo):
            t = ThreadSemIgualdade(alvo)
            thread.append(t)
            return t
        self.guarda.partir(token, fabricar, lambda: None)
        thread[0].executar()
        self.assertTrue(self.guarda.observar_termino_thread(token))

    def test_start_entra_lanca_e_alvo_retorna_tardiamente(self):
        token = self.reservar()
        entrou, liberar = threading.Event(), threading.Event()
        threads = []
        original = RuntimeError('start_ambiguo_simulado')
        def rotina():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
        def fabricar(alvo):
            real = threading.Thread(target=alvo)
            threads.append(real)
            def start():
                self.assertFalse(self.guarda._lock.locked())
                real.start()
                self.assertTrue(entrou.wait(3))
                raise original
            return Mock(start=start, is_alive=real.is_alive)
        try:
            with self.assertRaises(RuntimeError) as recebido:
                self.guarda.partir(token, fabricar, rotina)
            self.assertIs(original, recebido.exception)
            antes = self.evidencia()
            item = self.item(token)
            self.assertTrue(item['entrada'])
            self.assertTrue(item['partida_ambigua'])
            self.assertFalse(item['ausencia_comprovada'])
            self.assertFalse(self.guarda.observar_termino_thread(token))
        finally:
            liberar.set()
            for thread in threads:
                thread.join(3)
                self.assertFalse(thread.is_alive())
        self.assertGreater(self.revisao(), antes['revisao'])
        self.assertTrue(self.item(token)['retorno'])
        self.assertFalse(self.item(token)['thread_terminada'])
        self.assertTrue(self.guarda.observar_termino_thread(token))
        self.assertTrue(self.item(token)['partida_ambigua'])
        self.assertFalse(self.item(token)['ausencia_comprovada'])

    def test_erro_observacao_e_repeticao_sem_nova_evidencia(self):
        token = self.reservar()
        self.partir(token)
        self.threads[token].executar()
        self.threads[token].is_alive.side_effect = OSError('observacao_simulada')
        antes = self.revisao()
        self.assertFalse(self.guarda.observar_termino_thread(token))
        self.assertEqual(antes + 1, self.revisao())
        self.assertTrue(self.item(token)['erro'])
        self.assertTrue(self.evidencia()['confiavel'])
        self.assertFalse(self.guarda.observar_termino_thread(token))
        self.assertEqual(antes + 1, self.revisao())

    def test_observacao_contraditoria_e_revisada(self):
        token = self.reservar()
        self.partir(token)
        self.terminar(token)
        antes = self.revisao()
        self.threads[token].is_alive.return_value = True
        self.assertFalse(self.guarda.observar_termino_thread(token))
        self.assertEqual(antes + 1, self.revisao())
        self.assertEqual('desconhecido', self.item(token)['estado'])

    def test_traceback_original_preservado_na_dupla_falha(self):
        token = self.reservar()
        original, adicional = ValueError('operacional_simulado'), OSError('publicacao_simulada')
        tracebacks = []
        def corpo():
            try:
                raise original
            except ValueError as erro:
                tracebacks.append(erro.__traceback__)
                raise
        self.partir(token, corpo)
        with patch.object(self.guarda, '_publicar_saida', side_effect=adicional):
            try:
                self.threads[token].executar()
            except ValueError as recebido:
                self.assertIs(original, recebido)
                tb, cadeia = recebido.__traceback__, []
                while tb is not None:
                    cadeia.append(tb)
                    tb = tb.tb_next
            else:
                self.fail('erro operacional nao propagado')
        self.assertIn(tracebacks[0], cadeia)
        self.assertIs(adicional, original.__cause__)
        self.assertFalse(self.evidencia()['confiavel'])

    def test_falha_do_proprio_invalidador_nao_oculta_incerteza(self):
        token = self.reservar()
        original = ValueError('original_simulado')
        publicacao, invalidacao = OSError('publicacao_simulada'), RuntimeError('invalidacao_simulada')
        self.partir(token, Mock(side_effect=original))
        with patch.object(self.guarda, '_publicar_saida', side_effect=publicacao), \
                patch.object(self.guarda, '_invalidar_saida', side_effect=invalidacao):
            with self.assertRaises(ValueError) as recebido:
                self.threads[token].executar()
        self.assertIs(original, recebido.exception)
        self.assertIs(publicacao, original.__cause__)
        self.assertIs(invalidacao, publicacao.__cause__)
        self.assertFalse(self.evidencia()['confiavel'])


if __name__ == '__main__':
    unittest.main()

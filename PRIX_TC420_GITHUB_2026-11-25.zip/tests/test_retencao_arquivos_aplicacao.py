# Testes de retencao arquivos aplicacao: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC1-F1: retenção pela aplicação e cleanup explícito; sem IO/Tk reais."""
import gc
import threading
import traceback
import unittest
from unittest.mock import Mock, patch
import weakref

from config.arquivos import ContextoArquivosConfiguracao
from rede.infraestrutura_cliente import RecursosLeitorCliente
import test_arquivos_configuracao_integrados as anterior


# Grupo de 29 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class RetencaoArquivosAplicacao(unittest.TestCase):
    setUp = anterior.ArquivosConfiguracaoIntegrados.setUp
    limpar = anterior.ArquivosConfiguracaoIntegrados.limpar
    arquivo = anterior.ArquivosConfiguracaoIntegrados.arquivo
    retrato = anterior.ArquivosConfiguracaoIntegrados.retrato
    ler = anterior.ArquivosConfiguracaoIntegrados.ler
    gravar = anterior.ArquivosConfiguracaoIntegrados.gravar
    negativo = anterior.ArquivosConfiguracaoIntegrados.negativo
    thread = anterior.ArquivosConfiguracaoIntegrados.thread
    terminar = anterior.ArquivosConfiguracaoIntegrados.terminar

    def pendencias(self):
        return self.infra.obter_pendencias_arquivos()

    def falhar_associacao(self, identidade, fabrica):
        fabrica()
        raise RuntimeError("associacao_simulada")

    def bloqueio(self, entrou, liberar):
        entrou.set()
        if not liberar.wait(3):
            raise TimeoutError("barreira_simulada")

    def test_01_leitura_normal_sem_handle_retido(self):
        with patch("builtins.open", return_value=self.arquivo()):
            self.assertEqual({}, self.ler())
        self.assertEqual([], self.pendencias())
        estado, = self.contexto.obter_historico()
        self.assertTrue(estado["limpeza_comprovada"])
        self.assertFalse(estado["handle_retido"])

    def test_02_escrita_normal_sem_handle_retido(self):
        with patch("builtins.open", return_value=self.arquivo("")):
            self.gravar()
        self.assertEqual([], self.pendencias())
        self.assertTrue(self.retrato()[0]["encerramento_confirmado"])

    def test_03_associacao_preserva_identidade_e_reserva_anterior(self):
        def abrir(*args, **kwargs):
            estado, = self.retrato()
            pendencia, = self.pendencias()
            self.assertEqual(estado["recurso_id"], pendencia["recurso_id"])
            self.assertEqual("abertura", pendencia["fase"])
            self.assertFalse(pendencia["handle_retido"])
            for lock in (self.registro._lock, self.contexto._lock, self.infra._lock_arquivos):
                self.assertTrue(lock.acquire(blocking=False))
                lock.release()
            return self.arquivo()
        with patch("builtins.open", side_effect=abrir):
            self.ler()
        self.assertEqual(self.retrato()[0]["recurso_id"], self.contexto.obter_historico()[0]["recurso_id"])

    def test_04_associacao_falha_close_compensatorio_comprovado(self):
        arquivo = self.arquivo()
        with patch("builtins.open", return_value=arquivo), \
                patch.object(self.registro, "criar", side_effect=self.falhar_associacao):
            with self.assertRaises(RuntimeError):
                self.ler()
        self.assertTrue(arquivo.closed)
        self.assertEqual(1, arquivo.fechamentos)
        self.assertEqual([], self.pendencias())
        self.assertTrue(self.contexto.obter_historico()[0]["limpeza_comprovada"])
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])

    def test_05_associacao_e_close_falham_retem_original(self):
        arquivo = self.arquivo(limpeza=OSError("limpeza_simulada"))
        with patch("builtins.open", return_value=arquivo), \
                patch.object(self.registro, "criar", side_effect=self.falhar_associacao):
            with self.assertRaises(RuntimeError) as erro:
                self.ler()
        self.assertIs(arquivo.limpeza, erro.exception.__cause__)
        self.assertTrue(self.pendencias()[0]["handle_retido"])
        self.assertIs(arquivo, next(iter(self.contexto._pendentes.values()))["arquivo"])
        self.negativo()

    def test_06_leitura_e_close_falham_preservam_politica_e_causa(self):
        primario, limpeza = ValueError("leitura_simulada"), OSError("limpeza_simulada")
        with patch("builtins.open", return_value=self.arquivo(leitura=primario, limpeza=limpeza)):
            self.assertIsNone(self.ler())
        self.assertIs(limpeza, primario.__cause__)
        self.assertIn("read", [f.name for f in traceback.extract_tb(primario.__traceback__)])
        self.assertTrue(self.pendencias()[0]["handle_retido"])

    def test_07_escrita_e_close_falham_preservam_instancia_traceback(self):
        primario, limpeza = OSError("escrita_simulada"), RuntimeError("limpeza_simulada")
        with patch("builtins.open", return_value=self.arquivo(escrita=primario, limpeza=limpeza)):
            try:
                self.gravar()
            except OSError as erro:
                self.assertIs(primario, erro)
                self.assertIs(limpeza, erro.__cause__)
                self.assertIn("write", [f.name for f in traceback.extract_tb(erro.__traceback__)])
            else:
                self.fail("primario ausente")
        self.assertTrue(self.pendencias()[0]["handle_retido"])

    def test_08_publicacao_cleanup_falha_conserva_handle(self):
        arquivo = self.arquivo()
        publicar = self.contexto._publicar_limpeza
        def falhar(item, comprovada):
            publicar(item, comprovada)
            raise RuntimeError("publicacao_limpeza_simulada")
        with patch("builtins.open", return_value=arquivo), \
                patch.object(ContextoArquivosConfiguracao, "_publicar_limpeza", side_effect=falhar):
            with self.assertRaises(RuntimeError):
                self.ler()
        self.assertTrue(arquivo.closed)
        pendencia, = self.pendencias()
        self.assertFalse(pendencia["limpeza_comprovada"])
        self.assertTrue(pendencia["handle_retido"])
        self.assertEqual("falha_operacao", pendencia["erro_publicacao"])
        self.negativo()
        self.assertTrue(self.infra.tentar_limpeza_arquivo(pendencia["recurso_id"]))
        self.assertEqual([], self.pendencias())

    def test_09_closed_false_mantem_referencia(self):
        arquivo = Mock(closed=False, read=Mock(return_value="{}"))
        with patch("builtins.open", return_value=arquivo):
            self.ler()
        self.assertTrue(self.pendencias()[0]["handle_retido"])
        self.assertFalse(self.pendencias()[0]["limpeza_comprovada"])

    def test_10_closed_true_observado_somente_depois_close(self):
        arquivo = self.arquivo()
        def antes():
            self.assertFalse(arquivo.closed)
            self.assertFalse(self.pendencias()[0]["limpeza_comprovada"])
            self.assertIsNone(self.retrato()[0]["prova_fechamento"])
        arquivo.antes_close = antes
        with patch("builtins.open", return_value=arquivo):
            self.ler()
        self.assertTrue(self.contexto.obter_historico()[0]["closed_observado"])
        self.assertEqual([], self.pendencias())

    def test_11_fechamento_repetido_nao_apaga_historico(self):
        arquivo = self.arquivo(limpeza=RuntimeError("limpeza_simulada"))
        with patch("builtins.open", return_value=arquivo):
            with self.assertRaises(RuntimeError):
                self.ler()
        recurso = self.pendencias()[0]["recurso_id"]
        erro_antigo = self.retrato()[0]["erros_limpeza"]
        arquivo.limpeza = None
        self.assertTrue(self.infra.tentar_limpeza_arquivo(recurso))
        historico = self.contexto.obter_historico()
        self.assertFalse(self.infra.tentar_limpeza_arquivo(recurso))
        self.assertEqual(historico, self.contexto.obter_historico())
        self.assertEqual(erro_antigo, self.retrato()[0]["erros_limpeza"])
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])

    def test_12_cleanup_posterior_no_mesmo_handle_sem_nova_identidade(self):
        arquivo = self.arquivo(limpeza=RuntimeError("limpeza_simulada"))
        with patch("builtins.open", return_value=arquivo), \
                patch.object(self.registro, "criar", side_effect=self.falhar_associacao):
            with self.assertRaises(RuntimeError):
                self.ler()
        recurso = self.pendencias()[0]["recurso_id"]
        arquivo.limpeza = None
        self.assertTrue(self.infra.tentar_limpeza_arquivo(recurso))
        self.assertTrue(arquivo.closed)
        self.assertEqual(2, arquivo.fechamentos)
        self.assertEqual([recurso], [r["recurso_id"] for r in self.retrato()])
        self.assertEqual([], self.pendencias())
        self.assertTrue(self.contexto.obter_historico()[0]["limpeza_comprovada"])
        self.assertFalse(self.retrato()[0]["criacao_resolvida"])
        self.negativo()

    def test_13_duas_aberturas_normais_simultaneas_independentes(self):
        barreira = threading.Barrier(2)
        def abrir(*args, **kwargs):
            barreira.wait(3)
            return self.arquivo("{}" if args[1] == "r" else "")
        with patch("builtins.open", side_effect=abrir):
            ler, gravar = self.thread(self.ler), self.thread(self.gravar)
            self.terminar(ler)
            self.terminar(gravar)
        self.assertEqual([], ler[2] + gravar[2])
        self.assertEqual(2, len({r["recurso_id"] for r in self.retrato()}))
        self.assertEqual([], self.pendencias())

    def test_14_contexto_retido_pela_aplicacao_antes_leitor(self):
        self.assertIn(self.contexto, self.infra.obter_contextos_arquivos())
        self.assertIs(self.infra, self.contexto._proprietario)
        self.assertIs(self.registro, self.contexto._registro)
        self.assertEqual([], self.infra.registro_retentativas.obter_retrato()["retentativas"])

    def test_15_nova_geracao_nao_apaga_handle_anterior(self):
        arquivo = self.arquivo(limpeza=RuntimeError("limpeza_simulada"))
        with patch("builtins.open", return_value=arquivo):
            with self.assertRaises(RuntimeError):
                self.ler()
        antigo = self.pendencias()[0]
        leitor = RecursosLeitorCliente(self.infra)
        self.registro.promover(leitor.geracao_id)
        novo = ContextoArquivosConfiguracao(self.infra)
        self.assertNotEqual(antigo["geracao_id"], leitor.geracao_id)
        self.assertIn(self.contexto, self.infra.obter_contextos_arquivos())
        self.assertIn(novo, self.infra.obter_contextos_arquivos())
        self.assertEqual(antigo, self.pendencias()[0])

    def test_16_global_permanece_negativo_apos_cleanup(self):
        with patch("builtins.open", return_value=self.arquivo()):
            self.ler()
        self.registro.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.infra.registro_http.fechar_admissao()
        self.assertEqual([], self.pendencias())
        self.negativo()

    def test_17_corrida_a_gc_nao_remove_handle_com_dupla_falha(self):
        referencias = []
        def abrir(*args, **kwargs):
            arquivo = self.arquivo(limpeza=OSError("limpeza_simulada"))
            referencias.append(weakref.ref(arquivo))
            self.arquivos.remove(arquivo)  # Somente o proprietário deve retê-lo.
            return arquivo
        with patch("builtins.open", side_effect=abrir), \
                patch.object(self.registro, "criar", side_effect=self.falhar_associacao):
            with self.assertRaises(RuntimeError):
                self.ler()
        gc.collect()
        original = referencias[0]()
        self.assertIsNotNone(original)
        self.assertTrue(self.pendencias()[0]["handle_retido"])
        original.limpeza = None
        self.assertTrue(self.infra.tentar_limpeza_arquivo(self.pendencias()[0]["recurso_id"]))
        self.assertTrue(original.closed)

    def test_18_corrida_b_consulta_na_publicacao_pendente(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        publicar = self.contexto._publicar_limpeza
        def suspender(item, comprovada):
            publicar(item, comprovada)
            self.bloqueio(entrou, liberar)
        with patch("builtins.open", return_value=self.arquivo()), \
                patch.object(ContextoArquivosConfiguracao, "_publicar_limpeza", side_effect=suspender):
            trabalho = self.thread(self.ler)
            self.assertTrue(entrou.wait(3))
            pendencia, = self.pendencias()
            self.assertEqual("limpeza", pendencia["fase"])
            self.assertTrue(pendencia["handle_retido"])
            self.assertFalse(pendencia["limpeza_comprovada"])
            self.assertFalse(self.infra.tentar_limpeza_arquivo(pendencia["recurso_id"]))
            self.negativo()
            liberar.set()
            self.terminar(trabalho)
        self.assertEqual([], trabalho[2])
        self.assertEqual([], self.pendencias())

    def test_19_corrida_c_leitura_cleanup_falha_escrita_normal(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        leitura = self.arquivo(leitura=ValueError("leitura_simulada"), limpeza=OSError("limpeza_simulada"))
        escrita = self.arquivo("")
        leitura.antes_close = lambda: self.bloqueio(entrou, liberar)
        with patch("builtins.open", side_effect=lambda caminho, modo, **kw: leitura if modo == "r" else escrita):
            trabalho = self.thread(self.ler)
            self.assertTrue(entrou.wait(3))
            primeira = self.pendencias()[0]["recurso_id"]
            self.gravar()
            self.assertTrue(escrita.closed)
            self.assertTrue(self.retrato()[1]["encerramento_confirmado"])
            self.assertEqual([primeira], [p["recurso_id"] for p in self.pendencias()])
            liberar.set()
            self.terminar(trabalho)
        self.assertEqual([], trabalho[2])
        self.assertEqual([None], trabalho[1])
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])

    def test_20_corrida_d_promocao_durante_close_pendente(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        arquivo = self.arquivo(limpeza=OSError("limpeza_simulada"))
        arquivo.antes_close = lambda: self.bloqueio(entrou, liberar)
        with patch("builtins.open", return_value=arquivo):
            trabalho = self.thread(self.ler)
            self.assertTrue(entrou.wait(3))
            identidade = self.pendencias()[0]["recurso_id"]
            leitor = RecursosLeitorCliente(self.infra)
            self.registro.promover(leitor.geracao_id)
            self.assertEqual(identidade, self.pendencias()[0]["recurso_id"])
            self.assertIs(arquivo, next(iter(self.contexto._pendentes.values()))["arquivo"])
            liberar.set()
            self.terminar(trabalho)
        self.assertEqual([], trabalho[2])  # OSError mantém a política None da leitura.
        self.assertTrue(self.pendencias()[0]["handle_retido"])
        self.negativo()

    def test_21_corrida_e_retencao_falha_compensacao_preserva_handle(self):
        retencao, limpeza = RuntimeError("retencao_simulada"), OSError("limpeza_simulada")
        arquivo = self.arquivo(limpeza=limpeza)
        with patch("builtins.open", return_value=arquivo), \
                patch.object(ContextoArquivosConfiguracao, "_reter_handle", side_effect=retencao):
            with self.assertRaises(RuntimeError) as erro:
                self.ler()
        self.assertIs(retencao, erro.exception)
        self.assertIs(limpeza, retencao.__cause__)
        pendencia, = self.pendencias()
        self.assertTrue(pendencia["handle_retido"])
        self.assertEqual("falha_operacao", pendencia["erro_retencao"])
        self.assertFalse(pendencia["limpeza_comprovada"])
        self.assertEqual(1, arquivo.fechamentos)
        arquivo.limpeza = None
        self.assertTrue(self.infra.tentar_limpeza_arquivo(pendencia["recurso_id"]))
        self.negativo()

    def test_22_terceira_falha_na_anotacao_nao_apaga_primario_ou_close(self):
        primario, limpeza, anotacao = OSError("escrita_simulada"), RuntimeError("limpeza_simulada"), ValueError("anotacao_simulada")
        with patch("builtins.open", return_value=self.arquivo(escrita=primario, limpeza=limpeza)), \
                patch.object(ContextoArquivosConfiguracao, "_registrar_falha", side_effect=anotacao):
            with self.assertRaises(OSError) as erro:
                self.gravar()
        self.assertIs(primario, erro.exception)
        self.assertIs(limpeza, primario.__cause__)
        self.assertIs(anotacao, limpeza.__cause__)
        self.assertTrue(self.pendencias()[0]["handle_retido"])
        self.assertFalse(self.pendencias()[0]["limpeza_comprovada"])
        self.assertTrue(self.retrato()[0]["erros_atendimento"])
        self.assertTrue(self.retrato()[0]["erros_limpeza"])

    def test_23_falha_na_retencao_com_close_normal_compensa_sem_vazamento(self):
        arquivo = self.arquivo()
        with patch("builtins.open", return_value=arquivo), \
                patch.object(ContextoArquivosConfiguracao, "_reter_handle", side_effect=RuntimeError("retencao_simulada")):
            with self.assertRaises(RuntimeError):
                self.ler()
        self.assertTrue(arquivo.closed)
        self.assertEqual([], self.pendencias())
        self.assertTrue(self.contexto.obter_historico()[0]["limpeza_comprovada"])
        self.assertFalse(self.retrato()[0]["criacao_resolvida"])

    def test_24_retencao_do_contexto_falha_antes_qualquer_open(self):
        with patch.object(type(self.infra), "_reter_contexto_arquivos", side_effect=RuntimeError("montagem_simulada")), \
                patch("builtins.open") as abrir:
            with self.assertRaises(RuntimeError):
                ContextoArquivosConfiguracao(self.infra)
        abrir.assert_not_called()
        self.assertEqual([], self.retrato())

    def test_25_limpeza_explicita_nao_fecha_durante_uso(self):
        arquivo = self.arquivo()
        original_read = arquivo.read
        def ler(*args):
            pendencia, = self.pendencias()
            self.assertEqual("uso", pendencia["fase"])
            self.assertFalse(self.infra.tentar_limpeza_arquivo(pendencia["recurso_id"]))
            self.assertFalse(arquivo.closed)
            return original_read(*args)
        arquivo.read = ler
        with patch("builtins.open", return_value=arquivo):
            self.ler()
        self.assertEqual(1, arquivo.fechamentos)

    def test_26_registro_contexto_idempotente_sem_duplicidade_de_dono(self):
        self.infra._reter_contexto_arquivos(self.contexto)
        self.infra._reter_contexto_arquivos(self.contexto)
        self.assertEqual((self.contexto,), self.infra.obter_contextos_arquivos())
        self.assertEqual([], self.pendencias())
        self.assertIs(self.registro, self.contexto._registro)

    def test_27_retratos_sanitizados_e_copias_independentes(self):
        with patch("builtins.open", return_value=self.arquivo(limpeza=RuntimeError("marcador_simulado"))):
            with self.assertRaises(RuntimeError):
                self.ler()
        retrato = self.pendencias()
        self.assertNotIn("marcador_simulado", str(retrato))
        self.assertNotIn("virtual", str(retrato))
        self.assertTrue(all(type(v) in (bool, int, str, type(None)) for v in retrato[0].values()))
        retrato[0]["handle_retido"] = False
        self.assertTrue(self.pendencias()[0]["handle_retido"])

    def test_28_falha_publicacao_no_registro_apos_close_retem_handle(self):
        arquivo = self.arquivo()
        def fechar_sem_publicar(identidade):
            arquivo.close()
            raise RuntimeError("publicacao_registro_simulada")
        with patch("builtins.open", return_value=arquivo), \
                patch.object(self.registro, "fechar", side_effect=fechar_sem_publicar):
            with self.assertRaises(RuntimeError):
                self.ler()
        self.assertTrue(arquivo.closed)
        self.assertFalse(self.retrato()[0]["encerramento_confirmado"])
        pendencia, = self.pendencias()
        self.assertTrue(pendencia["handle_retido"])
        self.assertFalse(pendencia["limpeza_comprovada"])
        self.assertTrue(self.infra.tentar_limpeza_arquivo(pendencia["recurso_id"]))
        self.assertTrue(self.retrato()[0]["encerramento_confirmado"])

    def test_29_falha_preparar_celula_nao_abre_e_comprova_ausencia(self):
        class MapaFalho(dict):
            def __setitem__(self, chave, valor):
                raise MemoryError("reserva_retencao_simulada")
        self.contexto._pendentes = MapaFalho()
        with patch("builtins.open") as abrir:
            with self.assertRaises(MemoryError):
                self.ler()
        abrir.assert_not_called()
        self.assertTrue(self.retrato()[0]["ausencia_comprovada"])
        self.assertEqual([], self.pendencias())

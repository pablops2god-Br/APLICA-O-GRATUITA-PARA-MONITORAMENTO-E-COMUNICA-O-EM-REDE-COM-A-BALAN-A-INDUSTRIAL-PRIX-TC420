"""Caminhos do EXE simulados; não escreve em Program Files nem em dados reais."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from config import caminhos


class CaminhosInstalacao(unittest.TestCase):
    def test_desenvolvimento_conserva_local_atual(self):
        with patch.object(caminhos.sys, 'frozen', False, create=True):
            self.assertEqual(caminhos.pasta_dados(), Path(__file__).resolve().parents[1])

    def test_exe_cria_dados_e_logs_por_usuario(self):
        with tempfile.TemporaryDirectory() as pasta, \
             patch.object(caminhos.sys, 'frozen', True, create=True), \
             patch.dict(caminhos.os.environ, {'LOCALAPPDATA': pasta}):
            esperado = Path(pasta) / 'PRIX TC420'
            self.assertEqual(caminhos.arquivo_dados('configuracao.json'), esperado / 'configuracao.json')
            self.assertEqual(caminhos.pasta_logs(), esperado / 'logs')
            self.assertTrue((esperado / 'logs').is_dir())

    def test_nome_nao_pode_escapar_da_pasta(self):
        for nome in ('../fora.json', '..', ''):
            with self.subTest(nome=nome), self.assertRaises(ValueError):
                caminhos.arquivo_dados(nome)

# Testes de autoridade http estavel: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.15: autoridade fixada, transporte/GUI/persistência simulados."""
from dataclasses import FrozenInstanceError, replace
import threading
import unittest
from unittest.mock import Mock, patch

from rede import infraestrutura_cliente as modulo
from rede.entradas_http import VinculoEntradasHttp
import test_approval_http_integrado as approval
import test_entradas_http_vinculadas as montagem
from test_registro_automatico import carregar_fluxos
from tc420.web import WebTC420


# Grupo de 26 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AutoridadeHttpEstavel(unittest.TestCase):
    setUp = montagem.EntradasHttpVinculadas.setUp
    fluxo_http = montagem.EntradasHttpVinculadas.fluxo_http
    automatico = montagem.EntradasHttpVinculadas.automatico
    manual = montagem.EntradasHttpVinculadas.manual
    promocao = montagem.EntradasHttpVinculadas.promocao
    fixture_main = montagem.EntradasHttpVinculadas.fixture_main
    conferir_par = montagem.EntradasHttpVinculadas.conferir_par
    iniciar_thread = montagem.EntradasHttpVinculadas.iniciar_thread
    terminar = montagem.EntradasHttpVinculadas.terminar
    bloquear = montagem.EntradasHttpVinculadas.bloquear
    operacoes = montagem.EntradasHttpVinculadas.operacoes
    negativo = montagem.EntradasHttpVinculadas.negativo

    def _somente_a(self):
        ops = self.operacoes()
        self.assertEqual(["login", "approval"], [o["operacao"] for o in ops])
        self.assertEqual(2, len({o["operacao_id"] for o in ops}))
        self.assertEqual(1, len({(o["geracao_id"], o["atividade_id"]) for o in ops}))
        self.assertTrue(all(o["execucao_resolvida"] for o in ops))
        self.assertEqual([], self.outra.registro_http.obter_retrato()["operacoes"])

    def _executar(self, caminho):
        if caminho == "automatico":
            _, executar = self.automatico()
            self.assertTrue(executar())
        elif caminho == "manual":
            _, janela = self.manual()
            janela.conectar()
            self.assertTrue(janela.servidor_iniciado)
            self.assertIs(self.infra, janela.web.politica_http.proprietario)
        else:
            _, executar = self.promocao()
            resultado = executar()
            self.assertIs(self.infra, resultado["web"].politica_http.proprietario)

    def test_01_vinculo_original_a_aceito(self):
        self.assertIs(self.infra, self.vinculo.validar(self.infra))
        with self.fluxo_http() as adaptador:
            self._executar("automatico")
        self.conferir_par(adaptador)
        self._somente_a()

    def test_02_b_coerente_recusada(self):
        self.assertIs(self.outra, modulo.exigir_infraestrutura_http(self.outra))
        env, executar = self.automatico(self.outra)
        with self.fluxo_http() as adaptador:
            self.assertIs(False, executar())
        self.assertEqual([], adaptador.enviados)
        env["WebTC420"].assert_not_called()

    def test_03_vars_vinculo_nao_fornece_alias(self):
        with self.assertRaises(TypeError):
            vars(self.vinculo)
        self.assertIs(self.infra, self.vinculo.validar(self.infra))

    def test_04_dict_ausente_em_todas_referencias_de_autoridade(self):
        for objeto in (self.vinculo, self.infra, self.infra._instalacao, self.infra._referencias_http):
            with self.subTest(tipo=type(objeto).__name__):
                self.assertFalse(hasattr(objeto, "__dict__"))
                with self.assertRaises(TypeError):
                    vars(objeto)
                with self.assertRaises((AttributeError, TypeError)):
                    objeto.__dict__ = {}

    def _trocar_depois_validacao(self, campos=False):
        original = self.infra._instalacao
        contexto = original.contexto
        campos_contexto = vars(contexto).copy()
        http_original = original.http
        validar = self.vinculo.validar
        def trocar(apresentada):
            resultado = validar(apresentada)
            if campos:
                # Forçar campos internos e o contexto ainda dotado de __dict__
                # demonstra que fixar só o objeto de instalação não bastaria.
                object.__setattr__(original, "http", self.outra.registro_http)
                vars(contexto).update(vars(self.outra._contexto))
            else:
                object.__setattr__(self.infra, "_instalacao", self.outra._instalacao)
            return resultado
        return trocar, lambda: self._restaurar(original, contexto, campos_contexto, http_original)

    def _restaurar(self, original, contexto, campos, http):
        object.__setattr__(self.infra, "_instalacao", original)
        object.__setattr__(original, "http", http)
        vars(contexto).clear()
        vars(contexto).update(campos)

    def test_05_instalacao_alterada_apos_validacao_sem_reserva_b(self):
        trocar, restaurar = self._trocar_depois_validacao()
        try:
            with patch("rede.entradas_http.criar_validador_entrada", return_value=trocar), self.fluxo_http():
                self._executar("automatico")
            self._somente_a()
            with self.assertRaises(modulo.InfraestruturaHttpInvalida):
                self.vinculo.validar(self.infra)  # Próxima entrada rejeita a troca.
        finally:
            restaurar()

    def test_06_http_b_inserido_antes_validacao_recusado(self):
        original = self.infra._instalacao
        object.__setattr__(original, "http", self.outra.registro_http)
        try:
            env, executar = self.automatico()
            with self.fluxo_http() as adaptador:
                self.assertIs(False, executar())
            self.assertEqual([], adaptador.enviados)
            env["WebTC420"].assert_not_called()
        finally:
            object.__setattr__(original, "http", self.registro)

    def test_07_recursos_contexto_substituidos_recusados(self):
        contexto = self.infra._contexto
        original = contexto.recursos
        vars(contexto)["recursos"] = self.outra.registro_recursos
        try:
            _, executar = self.automatico()
            with self.fluxo_http() as adaptador:
                self.assertIs(False, executar())
            self.assertEqual([], adaptador.enviados)
            self.assertIs(original, self.infra.registro_recursos)
        finally:
            vars(contexto)["recursos"] = original

    def test_08_automatico_autoridade_original(self):
        with self.fluxo_http():
            self._executar("automatico")
        self._somente_a()

    def test_09_manual_autoridade_original(self):
        with self.fluxo_http():
            self._executar("manual")
        self._somente_a()

    def test_10_promocao_autoridade_original(self):
        with self.fluxo_http():
            self._executar("promocao")
        self._somente_a()

    def test_11_aplicacoes_independentes(self):
        for infra in (self.infra, self.outra):
            _, executar = self.automatico(infra, VinculoEntradasHttp(infra))
            with self.fluxo_http():
                self.assertTrue(executar())
            self.assertEqual(2, len(infra.registro_http.obter_retrato()["operacoes"]))

    def test_12_isolada_e_web_independente_preservados(self):
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        with self.fluxo_http():
            self.assertTrue(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        antes = self.operacoes()
        self.registro.fechar_admissao()
        web = WebTC420("independente-simulada")
        with self.fluxo_http():
            web.login("simulado", "simulado")
            web.obter_configuracao()
        self.assertEqual(antes, self.operacoes())

    def test_13_post_get_ids_e_mesma_origem(self):
        with self.fluxo_http() as adaptador:
            self._executar("manual")
        self.conferir_par(adaptador)

    def test_14_gate_fechado_nas_tres(self):
        _, auto = self.automatico()
        _, janela = self.manual()
        _, promover = self.promocao()
        self.registro.fechar_admissao()
        with self.fluxo_http() as adaptador:
            self.assertIs(False, auto())
            janela.conectar()
            self.assertIsNone(promover())
        self.assertEqual([], adaptador.enviados)

    def test_15_preparacao_anterior_a_nova_geracao(self):
        _, executar = self.automatico()
        entrou, liberar = threading.Event(), threading.Event()
        def post(*args, **kwargs):
            self.bloquear(entrou, liberar)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=post), \
                patch("tc420.web.requests.get", return_value=Mock(text=approval.APROVACAO.decode())):
            tarefa = self.iniciar_thread(executar)
            try:
                self.assertTrue(entrou.wait(3))
                origem = self.operacoes()[0]
                novo = modulo.RecursosLeitorCliente(self.infra)
                self.assertNotEqual(origem["geracao_id"], novo.geracao_id)
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertTrue(resultados[0])
        self.assertEqual({origem["geracao_id"]}, {o["geracao_id"] for o in self.operacoes()})
        self._somente_a()

    def test_16_encerramento_global_continua_negativo(self):
        with self.fluxo_http():
            self._executar("automatico")
        self.registro.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_17_corrida_a_troca_instalacao_apos_validar(self):
        _, janela = self.manual()
        validar = janela._validar_infraestrutura_http
        entrou, liberar = threading.Event(), threading.Event()
        def bloquear(apresentada):
            resultado = validar(apresentada)
            self.bloquear(entrou, liberar)
            return resultado
        janela._validar_infraestrutura_http = bloquear
        original = self.infra._instalacao
        with self.fluxo_http() as adaptador:
            tarefa = self.iniciar_thread(janela.conectar)
            try:
                self.assertTrue(entrou.wait(3))
                object.__setattr__(self.infra, "_instalacao", self.outra._instalacao)
            finally:
                liberar.set()
                try:
                    _, erros = self.terminar(tarefa)
                finally:
                    object.__setattr__(self.infra, "_instalacao", original)
        self.assertEqual([], erros)
        self.conferir_par(adaptador)
        self._somente_a()

    def test_18_corrida_b_aliases_nao_trocam_vinculo(self):
        env, executar = self.automatico(self.outra)
        for objeto in (self.vinculo, self.infra._referencias_http):
            with self.assertRaises(TypeError):
                vars(objeto)
            with self.assertRaises(AttributeError):
                objeto.__dict__
        with self.assertRaises(FrozenInstanceError):
            self.vinculo._infraestrutura = self.outra
        with self.fluxo_http() as adaptador:
            self.assertIs(False, executar())
        self.assertEqual([], adaptador.enviados)
        env["WebTC420"].assert_not_called()

    def test_19_corrida_c_promocao_durante_http(self):
        fx, promover = self.promocao()
        origem = fx.leitores[0].recursos_cliente
        entrou, liberar = threading.Event(), threading.Event()
        def post(*args, **kwargs):
            self.bloquear(entrou, liberar)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=post), \
                patch("tc420.web.requests.get", return_value=Mock(text=approval.APROVACAO.decode())):
            tarefa = self.iniciar_thread(promover)
            try:
                self.assertTrue(entrou.wait(3))
                self.registro.promover(origem.geracao_id)
                fx.leitores[0].recursos_cliente = modulo.RecursosLeitorCliente(self.infra)
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertIs(self.infra, resultados[0]["web"].politica_http.proprietario)
        self.assertEqual({origem.geracao_id}, {o["geracao_id"] for o in self.operacoes()})
        self._somente_a()

    def test_20_corrida_d_duas_aplicacoes(self):
        _, a = self.automatico()
        _, b = self.automatico(self.outra, VinculoEntradasHttp(self.outra))
        barreira = threading.Barrier(2)
        def post(*args, **kwargs):
            barreira.wait(3)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=post), \
                patch("tc420.web.requests.get", return_value=Mock(text=approval.APROVACAO.decode())):
            ta, tb = self.iniciar_thread(a), self.iniciar_thread(b)
            ra, ea = self.terminar(ta)
            rb, eb = self.terminar(tb)
        self.assertEqual(([], []), (ea, eb))
        self.assertIs(self.infra, ra[0]["web"].politica_http.proprietario)
        self.assertIs(self.outra, rb[0]["web"].politica_http.proprietario)
        for infra in (self.infra, self.outra):
            self.assertEqual(2, len(infra.registro_http.obter_retrato()["operacoes"]))

    def test_21_corrida_e_gate_entre_validar_e_reservar(self):
        _, janela = self.manual()
        validar = janela._validar_infraestrutura_http
        entrou, liberar = threading.Event(), threading.Event()
        def aguardar(apresentada):
            resultado = validar(apresentada)
            self.bloquear(entrou, liberar)
            return resultado
        janela._validar_infraestrutura_http = aguardar
        with self.fluxo_http() as adaptador:
            tarefa = self.iniciar_thread(janela.conectar)
            try:
                self.assertTrue(entrou.wait(3))
                self.registro.fechar_admissao()
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertEqual([], adaptador.enviados)
        self.assertEqual([], self.operacoes())

    def test_22_adicional_troca_apos_validar_nas_tres(self):
        for caminho in ("automatico", "manual", "promocao"):
            with self.subTest(caminho=caminho):
                self.setUp()
                trocar, restaurar = self._trocar_depois_validacao()
                try:
                    with patch("rede.entradas_http.criar_validador_entrada", return_value=trocar), self.fluxo_http():
                        self._executar(caminho)
                    self._somente_a()
                finally:
                    restaurar()

    def test_23_parser_pendente_na_instalacao_original(self):
        env, executar = self.automatico()
        entrou, liberar = threading.Event(), threading.Event()
        def criar(ip, **kwargs):
            web = WebTC420(ip, **kwargs)
            original = web.interpretar_approval
            def parser(dados):
                self.bloquear(entrou, liberar)
                return original(dados)
            web.interpretar_approval = parser
            return web
        env["WebTC420"].side_effect = criar
        with self.fluxo_http():
            tarefa = self.iniciar_thread(executar)
            try:
                self.assertTrue(entrou.wait(3))
                self.assertFalse(self.operacoes()[1]["execucao_resolvida"])
                self.negativo()
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertTrue(resultados[0])
        self._somente_a()

    def test_24_publicacao_falha_permanece_desconhecida(self):
        _, executar = self.automatico()
        with self.fluxo_http(), patch.object(self.registro, "publicar", side_effect=OSError()):
            self.assertIs(False, executar())
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])
        self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
        self.negativo()

    def test_25_campos_internos_alterados_apos_validar_nao_redirecionam(self):
        for caminho in ("automatico", "manual", "promocao"):
            with self.subTest(caminho=caminho):
                self.setUp()
                trocar, restaurar = self._trocar_depois_validacao(campos=True)
                try:
                    with patch("rede.entradas_http.criar_validador_entrada", return_value=trocar), self.fluxo_http():
                        self._executar(caminho)
                    self._somente_a()
                    self.assertEqual(self.infra._referencias_http.aplicacao_id, self.infra.aplicacao_id)
                finally:
                    restaurar()

    def test_26_troca_entre_post_get_mantem_registros_e_gate_originais(self):
        _, executar = self.automatico()
        original = self.infra._instalacao
        try:
            with self.fluxo_http() as adaptador:
                enviar = adaptador.send
                def trocar(pedido, **kwargs):
                    resposta = enviar(pedido, **kwargs)
                    if pedido.method == "POST":
                        object.__setattr__(self.infra, "_instalacao", self.outra._instalacao)
                    return resposta
                with patch.object(adaptador, "send", side_effect=trocar):
                    self.assertTrue(executar())
            self._somente_a()
        finally:
            object.__setattr__(self.infra, "_instalacao", original)

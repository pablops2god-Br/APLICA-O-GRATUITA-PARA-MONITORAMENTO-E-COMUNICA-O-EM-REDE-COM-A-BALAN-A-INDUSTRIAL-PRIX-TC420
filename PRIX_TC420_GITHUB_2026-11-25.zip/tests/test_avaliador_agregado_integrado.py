# Testes de avaliador agregado integrado: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Reexecuta os cenários do protótipo contra a consulta pública real."""
import inspect
import threading
from types import SimpleNamespace
from unittest.mock import Mock, patch

from rede import servidor
from prototipos import avaliador_encerramento as prototipo
import test_avaliador_agregado as cenarios


# Grupo de 4 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AvaliadorAgregadoIntegrado(cenarios.AvaliadorAgregado):
    def consultar(self, registro, callback):
        if callback is cenarios.AVALIAR_INDIVIDUAL_REAL:
            return servidor.avaliar_encerramento_aplicacao(registro)
        # Instrumentação externa: a API operacional mantém um único argumento.
        # Callbacks do harness usam a referência original e evitam recursão.
        with patch.object(servidor, "avaliar_encerramento_tentativa", side_effect=callback):
            return servidor.avaliar_encerramento_aplicacao(registro)

    def fontes_avaliador(self):
        nomes = ("_obter_contexto_agregado", "_obter_retrato_agregado",
                 "_validar_identidades_agregado", "_classificar_tentativa_agregada",
                 "avaliar_encerramento_aplicacao")
        return "\n\n".join(inspect.getsource(getattr(servidor, nome)) for nome in nomes)

    def test_29_sessao_http_antiga_permanece_aberta(self):
        # Recurso externo ao registro, deliberadamente sem consulta HTTP.
        sessao_antiga = SimpleNamespace(aberta=True, close=Mock())
        self.confirmada()
        self.confirmada()
        self.registro.fechar_admissao()
        resultado = servidor.avaliar_encerramento_aplicacao(self.registro)
        self.assertTrue(resultado["encerramento_confirmado"])
        self.assertTrue(sessao_antiga.aberta)
        sessao_antiga.close.assert_not_called()
        self.assertEqual(set(resultado), {
            "admissao_fechada", "total_tentativas", "confirmadas",
            "falhas_partida_confirmadas", "pendentes", "desconhecidas",
            "consistente", "encerramento_confirmado",
        })
        self.assertIn("Não comprova liberação de sessões HTTP", inspect.getdoc(
            servidor.avaliar_encerramento_aplicacao))
        self.assertIn("sem autorizar fechamento", inspect.getdoc(
            servidor.avaliar_encerramento_aplicacao))

    def test_30_fechamento_durante_avaliacao(self):
        self.confirmada()
        capturou = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        resultados = []
        def individual(contexto):
            resultado = cenarios.AVALIAR_INDIVIDUAL_REAL(contexto)
            capturou.wait()
            liberar.wait()
            return resultado
        def fechar():
            capturou.wait()
            self.registro.fechar_admissao()
            liberar.wait()
        self.threads([lambda: resultados.append(self.avaliar(individual)), fechar])
        self.assertFalse(resultados[0]["encerramento_confirmado"])
        self.assertFalse(resultados[0]["admissao_fechada"])
        self.assertFalse(resultados[0]["consistente"])
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_31_avaliacoes_simultaneas(self):
        for _ in range(3):
            self.confirmada()
        self.registro.fechar_admissao()
        barreira = threading.Barrier(4, timeout=5)
        def consultar():
            barreira.wait()
            for _ in range(80):
                self.assertTrue(self.avaliar()["encerramento_confirmado"])
        self.threads([consultar] * 4)

    def test_32_assinatura_contrato_e_callback_sem_lock(self):
        self.confirmada()
        self.registro.fechar_admissao()
        assinatura = inspect.signature(servidor.avaliar_encerramento_aplicacao)
        self.assertEqual(list(assinatura.parameters), ["registro"])
        def individual(contexto):
            for lock in (self.registro._lock, contexto._lock, self.controle.lock):
                self.assertTrue(lock.acquire(blocking=False))
                lock.release()
            return cenarios.AVALIAR_INDIVIDUAL_REAL(contexto)
        integrado = self.avaliar(individual)
        experimental = prototipo.avaliar_encerramento_aplicacao(
            self.registro, cenarios.AVALIAR_INDIVIDUAL_REAL)
        self.assertEqual(integrado, experimental)

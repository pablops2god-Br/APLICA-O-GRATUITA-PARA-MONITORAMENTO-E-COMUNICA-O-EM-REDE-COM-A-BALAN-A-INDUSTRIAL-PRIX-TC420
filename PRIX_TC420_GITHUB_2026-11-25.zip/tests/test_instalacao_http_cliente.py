# Testes de instalacao http cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Instalação passiva real; fluxos main por AST, sem rede/Tk/equipamento."""
from dataclasses import FrozenInstanceError
import threading
import unittest
from unittest.mock import Mock, patch

from rede import infraestrutura_cliente as modulo
import test_infraestrutura_cliente as fixtures_main


# Grupo de 22 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class InstalacaoHttpCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.fixture = fixtures_main.InfraestruturaCliente()
        self.fixture.setUp()

    def negativo(self, infra):
        resultado = infra.avaliar()
        self.assertFalse(resultado["encerramento_confirmado"])
        self.assertFalse(resultado["cobertura_completa"])
        self.assertEqual("incompleta", resultado["cobertura_operacional"])
        http = infra.registro_http.obter_retrato()
        self.assertFalse(http["encerramento_global_confirmado"])
        self.assertEqual("incompleta", http["cobertura_operacional"])

    def indisponivel(self, objeto):
        for nome in ("aplicacao_id", "registro_http", "registro_recursos", "registro_retentativas", "_contexto"):
            with self.assertRaises(AttributeError):
                getattr(objeto, nome)
        self.assertFalse(hasattr(objeto, "_instalacao"))

    def test_01_main_cria_http_e_registros_uma_vez(self):
        with patch.object(modulo, "RegistroOperacoesHttpCliente", wraps=modulo.RegistroOperacoesHttpCliente) as h, \
                patch.object(modulo, "RegistroRecursosCliente", wraps=modulo.RegistroRecursosCliente) as r, \
                patch.object(modulo, "GuardaRetentativasCliente", wraps=modulo.GuardaRetentativasCliente) as t:
            infra = self.fixture.iniciar_descoberto()
        h.assert_called_once_with(infra, infra.aplicacao_id)
        r.assert_called_once_with()
        t.assert_called_once_with()
        self.assertIs(infra, infra.registro_http.proprietario)
        self.assertEqual(infra.aplicacao_id, infra.registro_http.aplicacao_id)

    def test_02_aplicacoes_independentes(self):
        a, b = modulo.InfraestruturaRegistrosCliente(), modulo.InfraestruturaRegistrosCliente()
        self.assertIsNot(a.registro_http, b.registro_http)
        self.assertIs(a, a.registro_http.proprietario)
        self.assertIs(b, b.registro_http.proprietario)
        self.assertNotEqual(a.aplicacao_id, b.aplicacao_id)

    def test_03_promocao_real_preserva_identidade_e_gate(self):
        resultados = self.fixture.preparar_promocao()
        with patch.object(modulo, "RegistroOperacoesHttpCliente", wraps=modulo.RegistroOperacoesHttpCliente) as criar:
            self.fixture.env["iniciar"]()
        self.assertIsNotNone(resultados[0])
        criar.assert_called_once()
        infra = self.fixture.monitores[0].infraestrutura_cliente
        self.assertIs(infra.registro_http, self.fixture.leitores[0].infraestrutura_cliente.registro_http)
        self.assertFalse(infra.registro_http.obter_retrato()["admissao_fechada"])

    def test_04_novas_geracoes_mesmo_registro(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        http, recursos, tentativas = infra.registro_http, infra.registro_recursos, infra.registro_retentativas
        self.fixture.iniciar_cliente(infra)
        self.fixture.iniciar_cliente(infra)
        leitores = self.fixture.leitores
        self.assertNotEqual(leitores[0].recursos_cliente.geracao_id, leitores[1].recursos_cliente.geracao_id)
        self.assertTrue(all(l.infraestrutura_cliente.registro_http is http for l in leitores))
        self.assertIs(recursos, infra.registro_recursos)
        self.assertIs(tentativas, infra.registro_retentativas)

    def test_05_vazio_nao_confirma_global(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        self.assertEqual([], infra.registro_http.obter_retrato()["operacoes"])
        self.negativo(infra)

    def test_06_cobertura_incompleta_mesmo_todos_gates_fechados(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        infra.registro_http.fechar_admissao()
        infra.registro_recursos.fechar_admissao()
        infra.registro_retentativas.fechar_admissao()
        self.assertTrue(infra.registro_http.obter_retrato()["conjunto_http_resolvido"])
        self.negativo(infra)

    def test_07_consultas_nao_mutam_registros(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        def retratos():
            return (infra.registro_http.obter_retrato(), infra.registro_recursos.obter_retrato(),
                    infra.registro_retentativas.obter_retrato())
        antes = retratos()
        for _ in range(5):
            self.negativo(infra)
            self.assertIs(infra.registro_http, infra.registro_http)
        self.assertEqual(antes, retratos())

    def test_08_inicializacao_parcial_nao_publica_registros(self):
        objeto = modulo.InfraestruturaRegistrosCliente.__new__(modulo.InfraestruturaRegistrosCliente)
        def falhar(proprietario, aplicacao_id):
            self.assertIs(objeto, proprietario)
            self.indisponivel(objeto)
            raise OSError()
        with patch.object(modulo, "RegistroOperacoesHttpCliente", side_effect=falhar):
            with self.assertRaises(OSError):
                modulo.InfraestruturaRegistrosCliente.__init__(objeto)
        self.indisponivel(objeto)

    def test_09_falha_http_preserva_original_sem_recriar_antigos(self):
        original = ValueError("construcao_simulada")
        with patch.object(modulo, "RegistroOperacoesHttpCliente", side_effect=original) as h, \
                patch.object(modulo, "RegistroRecursosCliente", wraps=modulo.RegistroRecursosCliente) as r, \
                patch.object(modulo, "GuardaRetentativasCliente", wraps=modulo.GuardaRetentativasCliente) as t:
            with self.assertRaises(ValueError) as capturado:
                modulo.InfraestruturaRegistrosCliente()
        self.assertIs(original, capturado.exception)
        self.assertEqual(1, h.call_count)
        r.assert_called_once_with()
        t.assert_called_once_with()

    def test_10_registros_anteriores_mesmas_instancias(self):
        recursos, tentativas = modulo.RegistroRecursosCliente(), modulo.GuardaRetentativasCliente()
        with patch.object(modulo, "RegistroRecursosCliente", return_value=recursos), \
                patch.object(modulo, "GuardaRetentativasCliente", return_value=tentativas):
            infra = modulo.InfraestruturaRegistrosCliente()
        self.assertIs(recursos, infra.registro_recursos)
        self.assertIs(tentativas, infra.registro_retentativas)
        self.assertIs(recursos, infra._contexto.recursos)
        self.assertIs(tentativas, infra._contexto.retentativas)

    def test_11_chamada_legada_sem_novos_parametros(self):
        with patch.object(modulo, "RegistroOperacoesHttpCliente") as criar:
            self.fixture.env["iniciar_como_cliente"]("principal-simulado")
        criar.assert_not_called()
        self.assertEqual({"ip_servidor": "principal-simulado"}, self.fixture.leitores[0].argumentos)

    def test_12_passiva_sem_http_real_nem_operacao_artificial(self):
        classe = modulo.RegistroOperacoesHttpCliente
        with patch.object(classe, "admitir", side_effect=AssertionError("admissao_inesperada")) as admitir, \
                patch.object(classe, "criar_contexto", side_effect=AssertionError("contexto_inesperado")) as contexto, \
                patch.object(classe, "executar", side_effect=AssertionError("execucao_inesperada")) as executar, \
                patch("requests.api.request", side_effect=AssertionError("rede_inesperada")) as rede:
            # A instalação continua passiva. O callback de promoção já admite
            # HTTP desde L3-B1.4; aqui não se aciona esse caminho operacional.
            self.fixture.env["buscar_servidor"].return_value = "principal-simulado"
            self.fixture.env["iniciar"]()
        for chamada in (admitir, contexto, executar, rede):
            chamada.assert_not_called()
        infra = self.fixture.monitores[0].infraestrutura_cliente
        self.assertEqual([], infra.registro_http.obter_retrato()["operacoes"])

    def paralelo(self, operacoes):
        barreira = threading.Barrier(len(operacoes))
        erros = []
        def tarefa(op):
            try:
                barreira.wait(3)
                op()
            except BaseException as erro:
                erros.append(erro)
        threads = [threading.Thread(target=tarefa, args=(op,)) for op in operacoes]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(3)
            self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_13_consultas_concorrentes_preservam_referencia(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        http = infra.registro_http
        antes = http.obter_retrato()
        def consultar():
            for _ in range(20):
                self.assertIs(http, infra.registro_http)
                self.assertEqual(antes, http.obter_retrato())
                self.negativo(infra)
        self.paralelo([consultar] * 3)

    def test_14_nova_aplicacao_depois_encerramento_independente(self):
        antiga = modulo.InfraestruturaRegistrosCliente()
        antiga.registro_http.fechar_admissao()
        antiga.registro_recursos.fechar_admissao()
        antiga.registro_retentativas.fechar_admissao()
        nova = modulo.InfraestruturaRegistrosCliente()
        self.assertIsNot(antiga.registro_http, nova.registro_http)
        self.assertNotEqual(antiga.aplicacao_id, nova.aplicacao_id)
        self.assertFalse(nova.registro_http.obter_retrato()["admissao_fechada"])

    def test_15_promocao_e_consulta_sem_recriacao(self):
        observados = []
        self.fixture.env["buscar_servidor"].side_effect = ["principal-simulado", None, None]
        def promover(monitor):
            infra = monitor.infraestrutura_cliente
            antes = infra.registro_http
            self.assertIsNotNone(monitor.ao_promover_automaticamente())
            observados.extend([antes, monitor.infraestrutura_cliente.registro_http,
                              self.fixture.leitores[0].infraestrutura_cliente.registro_http])
        self.fixture.durante_monitor = promover
        self.fixture.env["iniciar"]()
        self.assertTrue(all(r is observados[0] for r in observados))

    def test_16_sem_certificado_global_da_aplicacao(self):
        infra = self.fixture.iniciar_descoberto()
        self.negativo(infra)
        self.assertEqual([], infra.registro_http.obter_retrato()["operacoes"])
        self.assertFalse(infra.registro_http.obter_retrato()["encerramento_global_confirmado"])

    def retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []
        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise AssertionError("barreira_nao_liberada")
        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_critico_A_falha_antes_publicacao_no_main(self):
        proprietarios = []
        original = OSError("montagem_simulada")
        def executar(suspender):
            def construir(proprietario, aplicacao_id):
                proprietarios.append(proprietario)
                suspender()
                raise original
            with patch.object(modulo, "RegistroOperacoesHttpCliente", side_effect=construir):
                with self.assertRaises(OSError) as capturado:
                    self.fixture.env["iniciar"]()
            self.assertIs(original, capturado.exception)
        def consultar():
            self.indisponivel(proprietarios[0])
            self.fixture.env["buscar_servidor"].assert_not_called()
            self.fixture.env["LeitorDadosServidor"].assert_not_called()
            self.fixture.env["JanelaConexao"].assert_not_called()
        self.retido(executar, consultar)
        self.indisponivel(proprietarios[0])

    def test_critico_B_componentes_durante_promocao(self):
        self.fixture.env["buscar_servidor"].side_effect = ["principal-simulado", None, None]
        self.fixture.durante_monitor = lambda monitor: monitor.ao_promover_automaticamente()
        web = self.fixture.env["WebTC420"].return_value
        def executar(suspender):
            web.login.side_effect = lambda *args: suspender()
            with patch.object(modulo, "RegistroOperacoesHttpCliente", wraps=modulo.RegistroOperacoesHttpCliente) as criar:
                self.fixture.env["iniciar"]()
            criar.assert_called_once()
        def consultar():
            monitor, leitor = self.fixture.monitores[0], self.fixture.leitores[0]
            infra = monitor.infraestrutura_cliente
            def observar():
                self.assertIs(infra.registro_http, leitor.infraestrutura_cliente.registro_http)
                self.assertIs(infra, infra.registro_http.proprietario)
                self.assertFalse(infra.registro_http.obter_retrato()["admissao_fechada"])
                self.negativo(infra)
            self.paralelo([observar] * 2)
        self.retido(executar, consultar)

    def test_critico_C_consulta_com_cobertura_incompleta(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        antes = infra.registro_http.obter_retrato()
        def consultar():
            for _ in range(25):
                self.negativo(infra)
                self.assertEqual(antes, infra.registro_http.obter_retrato())
        self.paralelo([consultar] * 4)

    def test_reinicializacao_do_mesmo_dono_recusada(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        http = infra.registro_http
        with patch.object(modulo, "RegistroOperacoesHttpCliente") as criar:
            with self.assertRaisesRegex(RuntimeError, "ja_inicializada"):
                infra.__init__()
        criar.assert_not_called()
        self.assertIs(http, infra.registro_http)

    def test_falha_montagem_depois_http_nao_publica_parcial(self):
        objeto = modulo.InfraestruturaRegistrosCliente.__new__(modulo.InfraestruturaRegistrosCliente)
        with patch.object(modulo, "_InstalacaoCliente", side_effect=ValueError("instalacao_simulada")), \
                patch.object(modulo, "RegistroOperacoesHttpCliente", wraps=modulo.RegistroOperacoesHttpCliente) as criar:
            with self.assertRaises(ValueError):
                objeto.__init__()
        criar.assert_called_once()
        self.indisponivel(objeto)

    def test_referencia_http_e_instalacao_imutaveis(self):
        infra = modulo.InfraestruturaRegistrosCliente()
        antes = infra.registro_http
        with self.assertRaises(FrozenInstanceError):
            infra.registro_http = object()
        with self.assertRaises(FrozenInstanceError):
            infra._instalacao.http = object()
        self.assertIs(antes, infra.registro_http)


if __name__ == "__main__":
    unittest.main()

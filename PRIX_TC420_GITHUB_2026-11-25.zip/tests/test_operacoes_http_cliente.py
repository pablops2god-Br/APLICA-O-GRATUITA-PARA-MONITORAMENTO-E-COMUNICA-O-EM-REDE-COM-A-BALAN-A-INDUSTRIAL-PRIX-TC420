# Testes de operacoes http cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Registro HTTP isolado: callbacks falsos e threads apenas no harness."""
from dataclasses import FrozenInstanceError
import gc
import json
import threading
import unittest
from unittest.mock import Mock, patch
import weakref

from requests import Response

from prototipos.operacoes_http_cliente import (
    ContextoHttpCliente, OperacaoHttpId, PublicacaoHttpId, RegistroOperacoesHttpCliente,
)
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from test_auditoria_http_arquivos_cliente import CorpoFalso


# Grupo de 33 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class OperacoesHttpCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.reg = RegistroOperacoesHttpCliente(self.infra, self.infra.aplicacao_id)
        self.contexto = self.reg.criar_contexto(1, 10)

    def admitir(self, contexto=None, operacao="approval"):
        return self.reg.admitir(contexto or self.contexto, operacao)

    def item(self, token):
        return next(o for o in self.reg.obter_retrato()["operacoes"] if o["operacao_id"] == token.numero)

    def pendente(self):
        self.assertFalse(self.reg.obter_retrato()["conjunto_http_resolvido"])

    def global_negativo(self):
        retrato = self.reg.obter_retrato()
        self.assertEqual("incompleta", retrato["cobertura_operacional"])
        self.assertFalse(retrato["encerramento_global_confirmado"])
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])

    def test_01_reserva_identidade_e_contexto_imutaveis(self):
        token = self.admitir()
        outro = self.admitir()
        self.assertNotEqual(token.numero, outro.numero)
        self.assertEqual(1, self.item(token)["geracao_id"])
        self.assertEqual(10, self.item(token)["atividade_id"])
        self.assertEqual("reservada", self.item(token)["estado"])
        with self.assertRaises(FrozenInstanceError):
            token.numero = 99
        with self.assertRaises(FrozenInstanceError):
            self.contexto.geracao_id = 99

    def test_02_inicio_atualiza_estado_sem_duplicar(self):
        token = self.admitir()
        self.assertTrue(self.reg.iniciar(token))
        self.assertFalse(self.reg.iniciar(token))
        self.assertEqual("em_andamento", self.item(token)["estado"])
        self.assertTrue(self.item(token)["publicacao_pendente"])

    def test_03_retorno_original_e_publicacao_definitiva(self):
        token = self.admitir()
        retorno = object()
        self.assertIs(retorno, self.reg.executar(token, lambda: retorno))
        self.assertEqual("concluida", self.item(token)["estado"])
        self.assertEqual("retorno", self.item(token)["resultado"])
        self.assertFalse(self.item(token)["publicacao_pendente"])
        self.assertIsNone(self.item(token)["erro"])
        self.reg.fechar_admissao()
        self.assertTrue(self.reg.obter_retrato()["conjunto_http_resolvido"])

    def test_04_falha_http_resolve_execucao_sem_apagar_erro(self):
        token = self.admitir()
        erro = RuntimeError("texto_privado_simulado")
        with self.assertRaises(RuntimeError) as capturado:
            self.reg.executar(token, Mock(side_effect=erro))
        self.assertIs(erro, capturado.exception)
        self.assertEqual("falha", self.item(token)["resultado"])
        self.assertEqual("falha_operacao", self.item(token)["erro"]["categoria"])
        self.assertTrue(self.item(token)["execucao_resolvida"])
        self.reg.fechar_admissao()
        self.assertTrue(self.reg.obter_retrato()["conjunto_http_resolvido"])
        self.assertNotIn("texto_privado_simulado", json.dumps(self.reg.obter_retrato()))

    def test_05_timeout_concluido_nao_e_recurso_aberto(self):
        token = self.admitir()
        original = TimeoutError()
        with self.assertRaises(TimeoutError) as capturado:
            self.reg.executar(token, Mock(side_effect=original))
        self.assertIs(original, capturado.exception)
        self.assertEqual("timeout", self.item(token)["erro"]["categoria"])
        self.assertTrue(self.item(token)["execucao_resolvida"])

    def retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []
        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise AssertionError("barreira_nao_liberada")
        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_06_operacao_bloqueada_pendente(self):
        token = self.admitir()
        def executar(suspender):
            self.reg.executar(token, suspender)
        def consultar():
            self.reg.fechar_admissao()
            self.assertEqual(1, self.item(token)["execucoes_ativas"])
            self.assertEqual("em_andamento", self.item(token)["estado"])
            self.pendente()
        self.retido(executar, consultar)
        self.assertTrue(self.reg.obter_retrato()["conjunto_http_resolvido"])

    def test_07_falha_antes_inicio_exige_prova_explicita(self):
        token = self.admitir()
        with self.assertRaises(ValueError):
            self.reg.comprovar_nao_inicio(token, nao_executada=False, erro=OSError())
        self.assertTrue(self.reg.comprovar_nao_inicio(token, nao_executada=True, erro=OSError()))
        self.assertFalse(self.reg.iniciar(token))
        chamada = Mock()
        with self.assertRaises(RuntimeError):
            self.reg.executar(token, chamada)
        chamada.assert_not_called()
        self.assertEqual("falha", self.item(token)["resultado"])
        self.assertEqual("nao_execucao_comprovada", self.item(token)["publicacao_original"]["evidencia"])
        self.assertTrue(self.item(token)["execucao_resolvida"])

    def test_08_inicio_ambiguo_sem_confirmacao(self):
        token = self.admitir()
        self.reg.marcar_desconhecida(token, motivo="inicio_ambiguo")
        self.reg.fechar_admissao()
        self.assertFalse(self.reg.iniciar(token))
        self.assertFalse(self.reg.comprovar_nao_inicio(token, nao_executada=True))
        self.assertEqual("desconhecida", self.item(token)["estado"])
        self.assertEqual("desconhecido", self.item(token)["resultado"])
        self.pendente()

    def test_09_resultado_preparado_nao_e_publicado(self):
        token = self.admitir()
        self.reg.iniciar(token)
        recibo = self.reg.preparar_publicacao(token)
        self.reg.fechar_admissao()
        self.assertTrue(self.item(token)["publicacao_pendente"])
        self.assertIsNone(self.item(token)["publicacao_original"])
        self.pendente()
        self.assertTrue(self.reg.publicar(token, recibo))
        self.assertTrue(self.reg.obter_retrato()["conjunto_http_resolvido"])

    def test_10_duplicacao_idempotente_e_conflito_preservado(self):
        token = self.admitir()
        self.reg.iniciar(token)
        recibo = self.reg.preparar_publicacao(token)
        with self.assertRaises(FrozenInstanceError):
            recibo.numero = 99
        self.assertTrue(self.reg.publicar(token, recibo))
        antes = self.reg.obter_retrato()
        self.assertTrue(self.reg.publicar(token, recibo))
        self.assertEqual(antes, self.reg.obter_retrato())
        divergente = self.reg.preparar_publicacao(token, erro=OSError())
        self.assertFalse(self.reg.publicar(token, divergente))
        self.assertFalse(self.reg.publicar(token, divergente))
        self.assertFalse(self.reg.publicar(token, recibo))
        item = self.item(token)
        self.assertEqual("retorno", item["publicacao_original"]["resultado"])
        self.assertEqual("falha", item["conflitos_publicacao"][0]["resultado"])
        self.assertEqual(1, len(item["conflitos_publicacao"]))
        self.assertEqual("desconhecida", item["estado"])

    def paralelo(self, operacoes):
        erros = []
        def executar(op):
            try:
                op()
            except BaseException as erro:
                erros.append(erro)
        threads = [threading.Thread(target=executar, args=(op,)) for op in operacoes]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(3)
            self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_11_duas_operacoes_simultaneas(self):
        barreira = threading.Barrier(2)
        tokens = [self.admitir(), self.admitir(operacao="login")]
        self.reg.fechar_admissao()
        self.paralelo([lambda t=t: self.reg.executar(t, lambda: barreira.wait(3)) for t in tokens])
        self.assertEqual(2, len({o["operacao_id"] for o in self.reg.obter_retrato()["operacoes"]}))
        self.assertTrue(self.reg.obter_retrato()["conjunto_http_resolvido"])

    def test_12_operacao_antiga_nao_desaparece(self):
        antigo = self.admitir()
        nova = self.reg.criar_contexto(2, 20)
        atual = self.admitir(nova)
        self.reg.executar(atual, lambda: None)
        self.reg.fechar_admissao()
        self.assertEqual(1, self.item(antigo)["geracao_id"])
        self.assertEqual(2, self.item(atual)["geracao_id"])
        self.assertTrue(self.item(atual)["execucao_resolvida"])
        self.pendente()

    def test_13_promocao_preserva_registro_e_proprietario(self):
        token = self.admitir()
        antes = self.reg
        self.reg.promover(1)
        self.assertIs(antes, self.reg)
        self.assertIs(self.infra, self.reg.proprietario)
        self.assertEqual(self.infra.aplicacao_id, self.reg.aplicacao_id)
        self.assertEqual(1, self.item(token)["geracao_id"])
        self.assertEqual("principal", self.item(token)["modo_atual"])
        # O contrato isolado continua independente da instância passiva agora instalada.
        self.assertIsNot(self.reg, self.infra.registro_http)
        self.assertEqual([], self.infra.registro_http.obter_retrato()["operacoes"])

    def test_14_admissao_fechada_idempotente(self):
        token = self.admitir()
        self.assertTrue(self.reg.fechar_admissao())
        self.assertFalse(self.reg.fechar_admissao())
        self.assertIsNone(self.admitir())
        self.assertIsNone(self.reg.criar_contexto(2, 20))
        self.assertEqual(token.numero, self.reg.obter_retrato()["operacoes"][0]["operacao_id"])

    def test_15_fechado_vazio_so_confirma_conjunto_vazio(self):
        self.reg.fechar_admissao()
        retrato = self.reg.obter_retrato()
        self.assertEqual([], retrato["operacoes"])
        self.assertTrue(retrato["conjunto_http_resolvido"])
        self.global_negativo()

    def test_16_cobertura_incompleta_nao_confirma_global(self):
        token = self.admitir()
        self.reg.executar(token, lambda: None)
        self.reg.fechar_admissao()
        self.assertTrue(self.reg.obter_retrato()["conjunto_http_resolvido"])
        self.global_negativo()

    def test_critico_A_reserva_antes_gate_inicio_depois(self):
        token = self.admitir()
        def executar(suspender):
            suspender()
            self.reg.executar(token, lambda: None)
        def fechar():
            self.reg.fechar_admissao()
            self.assertEqual("reservada", self.item(token)["estado"])
            self.assertIsNone(self.admitir())
            self.pendente()
        self.retido(executar, fechar)
        self.assertTrue(self.reg.obter_retrato()["conjunto_http_resolvido"])

    def test_critico_B_retorno_antes_publicacao_tardia(self):
        token = self.admitir()
        publicar = self.reg.publicar
        def executar(suspender):
            def publicar_tarde(operacao, recibo):
                suspender()
                return publicar(operacao, recibo)
            with patch.object(self.reg, "publicar", side_effect=publicar_tarde):
                self.assertEqual(42, self.reg.executar(token, lambda: 42))
        def consultar():
            self.reg.fechar_admissao()
            self.assertIsNone(self.item(token)["publicacao_original"])
            self.assertTrue(self.item(token)["publicacao_pendente"])
            self.pendente()
        self.retido(executar, consultar)
        self.assertTrue(self.reg.obter_retrato()["conjunto_http_resolvido"])

    def test_critico_C_promocao_entre_geracoes(self):
        antigo = self.admitir()
        def executar(suspender):
            self.reg.executar(antigo, suspender)
        def promover():
            self.reg.promover(1)
            nova = self.reg.criar_contexto(2, 20)
            novo = self.admitir(nova)
            self.reg.executar(novo, lambda: None)
            self.reg.fechar_admissao()
            self.assertTrue(self.item(novo)["execucao_resolvida"])
            self.assertFalse(self.item(antigo)["execucao_resolvida"])
            self.pendente()
        self.retido(executar, promover)
        self.assertEqual(1, self.item(antigo)["geracao_id"])
        self.assertEqual(10, self.item(antigo)["atividade_id"])
        self.assertTrue(self.reg.obter_retrato()["conjunto_http_resolvido"])

    def test_critico_D_publicacoes_concorrentes_incompativeis(self):
        token = self.admitir()
        self.reg.iniciar(token)
        recibos = [self.reg.preparar_publicacao(token), self.reg.preparar_publicacao(token, erro=OSError())]
        barreira = threading.Barrier(2)
        resultados = []
        def publicar(recibo):
            barreira.wait(3)
            resultados.append(self.reg.publicar(token, recibo))
        self.paralelo([lambda r=r: publicar(r) for r in recibos])
        self.assertEqual([False, True], sorted(resultados))
        self.reg.fechar_admissao()
        item = self.item(token)
        evidencias = [item["publicacao_original"], *item["conflitos_publicacao"]]
        self.assertEqual({"retorno", "falha"}, {e["resultado"] for e in evidencias})
        self.assertTrue(any(e["erro"] for e in evidencias))
        self.assertEqual("desconhecida", item["estado"])
        self.pendente()

    def test_adicional_http_resolvido_resposta_com_cleanup_pendente(self):
        # Oráculo de composição no harness; não altera o registro de recursos
        # nem disfarça uma Response como arquivo/socket.
        corpo = CorpoFalso([b"parte-1", b"parte-2"])
        resposta = Response()
        resposta.raw = corpo  # Corpo público falso, sem socket interno.
        token = self.admitir()
        self.assertIs(resposta, self.reg.executar(token, lambda: resposta))
        self.reg.fechar_admissao()
        http = self.reg.obter_retrato()["conjunto_http_resolvido"]
        self.assertTrue(http)
        self.assertEqual(0, corpo.fechamentos)  # O registro HTTP não fechou a resposta.
        self.assertFalse(http and corpo.fechamentos == 1)
        self.global_negativo()
        antes = self.reg.obter_retrato()
        resposta.close()  # Outro dono usa contrato público da resposta simulada.
        self.assertEqual(1, corpo.fechamentos)
        self.assertEqual(1, corpo.liberacoes)
        self.assertEqual(antes, self.reg.obter_retrato())
        self.global_negativo()

    def test_snapshot_e_somente_leitura_com_copias_profundas(self):
        token = self.admitir()
        with self.assertRaises(OSError):
            self.reg.executar(token, Mock(side_effect=OSError()))
        antes = self.reg.obter_retrato()
        self.assertEqual(antes, self.reg.obter_retrato())
        alterado = self.reg.obter_retrato()
        alterado["operacoes"][0]["erro"]["categoria"] = "alterado"
        alterado["operacoes"][0]["publicacao_original"]["erro"]["categoria"] = "alterado"
        alterado["operacoes"][0]["erros_execucao"][0]["categoria"] = "alterado"
        alterado["operacoes"].clear()
        self.assertEqual(antes, self.reg.obter_retrato())

    def test_tokens_cruzados_reconstruidos_e_contexto_invalido(self):
        token = self.admitir()
        outro = RegistroOperacoesHttpCliente(self.infra, self.infra.aplicacao_id)
        contexto_outro = outro.criar_contexto(1, 10)
        with self.assertRaises(ValueError):
            self.reg.admitir(contexto_outro, "approval")
        with self.assertRaises(ValueError):
            self.reg.admitir(ContextoHttpCliente(self.contexto.origem, 1, 10), "approval")
        with self.assertRaises(ValueError):
            self.reg.iniciar(OperacaoHttpId(token.origem, token.numero))
        self.reg.iniciar(token)
        recibo = self.reg.preparar_publicacao(token)
        with self.assertRaises(ValueError):
            self.reg.publicar(token, PublicacaoHttpId(recibo.origem, recibo.numero))
        segundo = self.admitir()
        self.reg.iniciar(segundo)
        with self.assertRaises(ValueError):
            self.reg.publicar(segundo, recibo)

    def test_chamada_executa_fora_lock_e_so_uma_vez(self):
        token = self.admitir()
        def chamada():
            self.assertTrue(self.reg._lock.acquire(blocking=False))
            self.reg._lock.release()
            self.assertEqual(1, self.item(token)["execucoes_ativas"])
            return 42
        self.assertEqual(42, self.reg.executar(token, chamada))
        chamada_tardia = Mock()
        with self.assertRaises(RuntimeError):
            self.reg.executar(token, chamada_tardia)
        chamada_tardia.assert_not_called()

    def test_falha_publicacao_nao_mascara_erro_e_nao_some(self):
        token = self.admitir()
        original = ValueError("texto_privado_simulado")
        with patch.object(self.reg, "preparar_publicacao", side_effect=OSError()):
            with self.assertRaises(ValueError) as capturado:
                self.reg.executar(token, Mock(side_effect=original))
        self.assertIs(original, capturado.exception)
        self.assertEqual("falha_operacao", self.item(token)["erro"]["categoria"])
        self.assertIn("falha_publicacao", self.item(token)["incertezas"])
        self.assertEqual("desconhecida", self.item(token)["estado"])
        self.assertEqual(0, self.item(token)["execucoes_ativas"])
        self.reg.fechar_admissao()
        self.pendente()

    def test_publicou_mas_ack_falhou_continua_conservador(self):
        token = self.admitir()
        publicar = self.reg.publicar
        def falhar_apos(operacao, recibo):
            publicar(operacao, recibo)
            raise OSError()
        with patch.object(self.reg, "publicar", side_effect=falhar_apos):
            with self.assertRaises(OSError):
                self.reg.executar(token, lambda: 42)
        self.assertIsNotNone(self.item(token)["publicacao_original"])
        self.assertEqual("desconhecida", self.item(token)["estado"])
        self.assertTrue(self.item(token)["publicacao_pendente"])

    def test_publicacao_externa_nao_confirma_callback_ativo(self):
        token = self.admitir()
        def executar(suspender):
            with self.assertRaises(RuntimeError):  # Callback final publicará outro recibo: conflito.
                self.reg.executar(token, suspender)
        def publicar_cedo():
            recibo = self.reg.preparar_publicacao(token)
            self.reg.publicar(token, recibo)
            self.reg.fechar_admissao()
            self.assertEqual(1, self.item(token)["execucoes_ativas"])
            self.assertTrue(self.item(token)["publicacao_pendente"])
            self.pendente()
        self.retido(executar, publicar_cedo)
        self.assertEqual("desconhecida", self.item(token)["estado"])
        self.pendente()

    def test_retorno_nao_e_retido_e_erros_nao_contem_payload(self):
        class Retorno:
            pass
        token = self.admitir()
        retorno = Retorno()
        referencia = weakref.ref(retorno)
        obtido = self.reg.executar(token, lambda: retorno)
        del retorno, obtido
        gc.collect()
        self.assertIsNone(referencia())
        self.assertEqual("retorno", self.item(token)["resultado"])

    def test_validacoes_nao_admitem_dados_arbitrarios(self):
        for numero in (True, 0, -1, "1"):
            with self.assertRaises(ValueError):
                self.reg.criar_contexto(numero, 10)
        with self.assertRaises(ValueError):
            self.admitir(operacao="rotulo_nao_autorizado")
        token = self.admitir()
        with self.assertRaises(ValueError):
            self.reg.preparar_publicacao(token)
        with self.assertRaises(ValueError):
            self.reg.marcar_desconhecida(token, motivo="texto_arbitrario")
        with self.assertRaises(AttributeError):
            self.reg.proprietario = object()
        with self.assertRaises(AttributeError):
            self.reg.aplicacao_id = "outra"

    def test_admissoes_concorrentes_identidades_unicas(self):
        barreira = threading.Barrier(2)
        tokens = []
        def executar():
            barreira.wait(3)
            token = self.admitir()
            tokens.append(token)
            self.reg.executar(token, lambda: None)
        self.paralelo([executar, executar])
        self.assertEqual(2, len({t.numero for t in tokens}))
        self.reg.fechar_admissao()
        self.assertTrue(self.reg.obter_retrato()["conjunto_http_resolvido"])

    def test_recibos_distintos_mesma_categoria_nao_sao_equivalentes(self):
        token = self.admitir()
        self.reg.iniciar(token)
        a = self.reg.preparar_publicacao(token, erro=OSError())
        b = self.reg.preparar_publicacao(token, erro=OSError())
        self.assertTrue(self.reg.publicar(token, a))
        self.assertFalse(self.reg.publicar(token, b))
        self.assertEqual("desconhecida", self.item(token)["estado"])
        self.assertEqual(1, len(self.item(token)["conflitos_publicacao"]))

    def test_interrupcao_preserva_objeto_erro_e_resolve_execucao(self):
        token = self.admitir()
        original = KeyboardInterrupt()
        with self.assertRaises(KeyboardInterrupt) as capturado:
            self.reg.executar(token, Mock(side_effect=original))
        self.assertIs(original, capturado.exception)
        self.assertEqual("falha_base", self.item(token)["erro"]["categoria"])
        self.assertTrue(self.item(token)["execucao_resolvida"])

    def test_recibo_concorrente_preparado_impede_positivo_intermediario(self):
        token = self.admitir()
        self.reg.iniciar(token)
        a = self.reg.preparar_publicacao(token)
        b = self.reg.preparar_publicacao(token, erro=OSError())
        self.reg.fechar_admissao()
        self.assertTrue(self.reg.publicar(token, a))  # Aceitação não é resolução do conjunto.
        self.assertEqual([b.numero], self.item(token)["publicacoes_pendentes"])
        self.assertTrue(self.item(token)["publicacao_pendente"])
        self.pendente()
        self.assertFalse(self.reg.publicar(token, b))
        self.assertEqual([], self.item(token)["publicacoes_pendentes"])
        self.assertEqual("desconhecida", self.item(token)["estado"])
        self.pendente()


if __name__ == "__main__":
    unittest.main()

# Testes de coordenador encerramento: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Coordenador isolado: provas em memória e callbacks sem serviços/rede reais."""
import ast
import inspect
import threading
import unittest
from unittest.mock import Mock, patch

from prototipos import coordenador_encerramento as prototipo
from rede import servidor


# Grupo de 28 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class CoordenadorEncerramento(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.registro = servidor.RegistroTentativasAplicacao()
        self.controle = servidor.ControleCicloServidor()
        remendo = patch.object(servidor, "controle_ciclo_servidor", self.controle)
        remendo.start()
        self.addCleanup(remendo.stop)
        # No ensaio, confirmado pode atestar ausência. Não é detecção automática.
        self.provas = dict.fromkeys(prototipo.RESPONSABILIDADES, "confirmado")
        self.servidores = Mock(side_effect=self.verificar_gate)
        self.cliente = Mock(side_effect=self.verificar_gate)
        self.coordenador = self.novo()

    def verificar_gate(self):
        self.assertTrue(self.registro.obter_retrato()["admissao_fechada"])

    def novo(self, **kwargs):
        return prototipo.CoordenadorEncerramentoExperimental(
            self.registro, solicitar_paradas=kwargs.pop("solicitar_paradas", {
                "servidores": self.servidores, "leitores_cliente": self.cliente}),
            consultar_responsabilidades=kwargs.pop("consultar_responsabilidades", lambda: self.provas.copy()),
            **kwargs)

    def iniciar(self):
        self.assertTrue(self.coordenador.solicitar_encerramento())
        self.assertTrue(self.coordenador.executar_parada())

    def avaliar(self):
        self.coordenador.avaliar_encerramento()
        return self.coordenador.obter_retrato()

    def tentativa(self, estado="iniciada", retornar=False, socket_pendente=False):
        contexto = servidor.ContextoCicloServidor()
        chave = self.registro.admitir(contexto)
        self.registro.marcar_iniciando(chave)
        if estado != "iniciada":
            return chave, contexto, None
        self.registro.registrar_entrada_execucao(chave)
        self.registro.marcar_iniciada(chave)
        workers = servidor.RegistroTrabalhadores()
        self.assertTrue(self.controle.tentar_iniciar(workers))
        contexto.registrar_reserva(workers.ciclo_id)
        if socket_pendente:
            workers.reservar_criacao_socket()
        if retornar:
            self.resolver(contexto, workers)
        return chave, contexto, workers

    def resolver(self, contexto, workers):
        workers.bloquear_criacao()
        self.controle.finalizar(workers)
        contexto.registrar_retorno_coordenador()

    def aguardar(self, thread):
        thread.join(5)
        self.assertFalse(thread.is_alive())

    def test_01_sem_tentativas_exige_outros(self):
        self.provas["inventario_operacional"] = "desconhecido"
        self.iniciar()
        resultado = self.avaliar()
        self.assertTrue(resultado["tentativas_confirmadas"])
        self.assertFalse(resultado["encerramento_confirmado"])

    def test_02_principal_ativo(self):
        _, contexto, workers = self.tentativa()
        self.iniciar()
        self.servidores.assert_called_once()
        self.assertFalse(self.avaliar()["encerramento_confirmado"])
        self.resolver(contexto, workers)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_03_cliente_ativo(self):
        self.provas["leitores_cliente"] = "pendente"
        self.iniciar()
        self.cliente.assert_called_once()
        self.assertFalse(self.avaliar()["encerramento_confirmado"])
        self.provas["leitores_cliente"] = "confirmado"
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def corrida_admissao(self):
        for admitir_primeiro in (False, True):
            with self.subTest(admitir_primeiro=admitir_primeiro):
                self.registro = servidor.RegistroTentativasAplicacao()
                self.coordenador = self.novo()
                pronta = threading.Barrier(2, timeout=5)
                liberar = threading.Barrier(2, timeout=5)
                contexto = servidor.ContextoCicloServidor()
                resultado = []
                def produzir():
                    if admitir_primeiro:
                        resultado.append(self.registro.admitir(contexto))
                    pronta.wait()
                    liberar.wait()
                    if not admitir_primeiro:
                        resultado.append(self.registro.admitir(contexto))
                    else:
                        self.registro.marcar_iniciando(resultado[0])
                thread = threading.Thread(target=produzir)
                thread.start()
                try:
                    pronta.wait()
                    self.coordenador.solicitar_encerramento()
                    self.assertEqual(len(self.registro.obter_retrato()["tentativas"]), int(admitir_primeiro))
                finally:
                    liberar.wait()
                    self.aguardar(thread)
                self.assertEqual(resultado[0] is not None, admitir_primeiro)
                self.coordenador.executar_parada()
                if admitir_primeiro:
                    self.assertIs(self.registro.obter_retrato()["tentativas"][0].contexto, contexto)
                    self.assertFalse(self.avaliar()["encerramento_confirmado"])

    def test_04_promocao_automatica_concorrente(self):
        self.corrida_admissao()

    def test_05_partida_manual_concorrente(self):
        self.corrida_admissao()

    def test_06_fechamento_repetido(self):
        self.iniciar()
        for _ in range(3):
            self.assertFalse(self.coordenador.solicitar_encerramento())
            self.assertFalse(self.coordenador.executar_parada())
        self.servidores.assert_called_once()
        self.cliente.assert_called_once()
        self.assertEqual(self.coordenador.obter_retrato()["sequencias_parada"], 1)

    def test_07_cancelamento_antes(self):
        self.assertTrue(self.coordenador.responder_usuario("cancelar"))
        self.assertEqual(self.coordenador.obter_retrato()["estado"], "executando")
        self.assertFalse(self.registro.obter_retrato()["admissao_fechada"])
        self.servidores.assert_not_called()

    def test_08_cancelamento_depois(self):
        self.iniciar()
        self.assertFalse(self.coordenador.cancelar_saida())
        self.assertTrue(self.registro.obter_retrato()["admissao_fechada"])

    def test_09_coordenador_retorna_primeiro(self):
        self.tentativa(retornar=True, socket_pendente=True)
        self.iniciar()
        self.assertFalse(self.avaliar()["encerramento_confirmado"])

    def test_10_handler_vivo(self):
        _, contexto, workers = self.tentativa()
        liberar = threading.Event()
        worker = threading.Thread(target=lambda: liberar.wait(3))
        try:
            workers.registrar_e_iniciar(worker)
            self.resolver(contexto, workers)
            self.iniciar()
            self.assertFalse(self.avaliar()["encerramento_confirmado"])
        finally:
            liberar.set()
            self.aguardar(worker)

    def test_11_socket_reservado(self):
        self.tentativa(retornar=True, socket_pendente=True)
        self.iniciar()
        self.assertFalse(self.avaliar()["tentativas_confirmadas"])

    def test_12_erro_fechamento(self):
        _, contexto, workers = self.tentativa()
        workers.registrar_erro_limpeza("handler.close:OSError")
        self.resolver(contexto, workers)
        self.iniciar()
        self.assertFalse(self.avaliar()["encerramento_confirmado"])

    def test_13_historico_desconhecido(self):
        chave, contexto, _ = self.tentativa("iniciando")
        self.registro.registrar_entrada_execucao(chave)
        self.registro.marcar_iniciada(chave)
        contexto.registrar_reserva(999)
        contexto.registrar_retorno_coordenador()
        self.iniciar()
        with self.assertLogs("rede.servidor", level="WARNING"):
            self.assertFalse(self.avaliar()["encerramento_confirmado"])

    def test_14_agregado_confirmado_cliente_ativo(self):
        self.tentativa(retornar=True)
        self.provas["leitores_cliente"] = "pendente"
        self.iniciar()
        resultado = self.avaliar()
        self.assertTrue(resultado["tentativas_confirmadas"])
        self.assertFalse(resultado["encerramento_confirmado"])

    def test_15_recurso_externo_desconhecido(self):
        self.provas["preparacao_inicializacoes"] = "desconhecido"
        self.iniciar()
        self.assertFalse(self.avaliar()["encerramento_confirmado"])

    def test_16_excecao_consulta(self):
        self.coordenador = self.novo(avaliar_agregado=Mock(side_effect=RuntimeError("conteudo_descartado")))
        self.iniciar()
        resultado = self.avaliar()
        self.assertFalse(resultado["encerramento_confirmado"])
        self.assertEqual(resultado["erros"][0]["etapa"], "consulta_agregada")
        self.assertNotIn("conteudo_descartado", repr(resultado))

    def test_17_parada_demorada_sem_lock_interface(self):
        entrou = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        def parar():
            self.verificar_gate()
            entrou.wait()
            liberar.wait()
        self.coordenador = self.novo(solicitar_paradas={"servidores": parar})
        self.coordenador.solicitar_encerramento()
        thread = threading.Thread(target=self.coordenador.executar_parada)
        visual = prototipo.PoliticaVisualSimulada()
        thread.start()
        try:
            entrou.wait()
            for _ in range(100):
                self.assertTrue(visual.registrar_atualizacao(0))
                self.assertFalse(self.coordenador.obter_retrato()["parada_concluida"])
            self.assertFalse(self.avaliar()["encerramento_confirmado"])
            self.assertFalse(self.coordenador.solicitar_encerramento())
        finally:
            liberar.wait()
            self.aguardar(thread)
        self.assertEqual(visual.obter_retrato()["atualizacoes"], 100)

    def duas_solicitacoes(self):
        barreira = threading.Barrier(3, timeout=5)
        resultados = []
        def solicitar():
            barreira.wait()
            aceitou = self.coordenador.solicitar_encerramento()
            resultados.append(aceitou)
            if aceitou:
                self.coordenador.executar_parada()
        threads = [threading.Thread(target=solicitar) for _ in range(2)]
        for thread in threads:
            thread.start()
        barreira.wait()
        for thread in threads:
            self.aguardar(thread)
        self.assertEqual(sorted(resultados), [False, True])
        self.servidores.assert_called_once()
        self.cliente.assert_called_once()
        self.assertEqual(self.coordenador.obter_retrato()["sequencias_parada"], 1)

    def test_18_solicitacoes_simultaneas(self):
        self.duas_solicitacoes()

    def test_19_atualizacao_apos_destruicao(self):
        visual = prototipo.PoliticaVisualSimulada()
        geracao = visual.obter_retrato()["geracao"]
        visual.marcar_destruida_no_ensaio()
        self.assertFalse(visual.registrar_atualizacao(geracao))
        self.assertEqual(self.coordenador.obter_retrato()["estado"], "executando")

    def test_20_todas_evidencias(self):
        self.tentativa(retornar=True)
        self.iniciar()
        resultado = self.avaliar()
        self.assertTrue(resultado["encerramento_confirmado"])
        self.assertEqual(resultado["fases"], ("executando", "encerramento_solicitado",
            "admissao_fechada", "aguardando_encerramento", "encerramento_confirmado"))

    def test_21_critico_a_promocao_gate(self):
        self.corrida_admissao()

    def test_22_critico_b_unica_coordenacao(self):
        self.duas_solicitacoes()

    def test_23_critico_c_cliente_ainda_vivo(self):
        self.tentativa(retornar=True)
        liberar = threading.Event()
        cliente = threading.Thread(target=lambda: liberar.wait(3))
        cliente.start()
        try:
            self.provas["leitores_cliente"] = "pendente"
            self.iniciar()
            self.assertTrue(cliente.is_alive())
            self.assertTrue(self.avaliar()["tentativas_confirmadas"])
            self.assertFalse(self.coordenador.obter_retrato()["encerramento_confirmado"])
        finally:
            liberar.set()
            self.aguardar(cliente)
        self.provas["leitores_cliente"] = "confirmado"
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_24_critico_d_parada_falha_erro_persistente(self):
        self.servidores.side_effect = OSError("conteudo_descartado")
        self.iniciar()
        self.cliente.assert_called_once()
        primeiro = self.avaliar()
        segundo = self.avaliar()
        self.assertEqual(primeiro["erros"], segundo["erros"])
        self.assertEqual(primeiro["erros"], ({"etapa": "parada", "componente": "servidores", "categoria": "falha_io"},))
        self.assertFalse(segundo["encerramento_confirmado"])
        self.assertFalse(self.coordenador.executar_parada())

    def test_25_nao_ocultacao_cancelamento_distintos(self):
        visual = prototipo.PoliticaVisualSimulada()
        self.assertFalse(self.coordenador.responder_usuario("nao"))
        self.assertFalse(visual.obter_retrato()["oculta"])
        self.assertTrue(visual.solicitar_ocultacao())
        self.assertEqual(self.coordenador.obter_retrato()["estado"], "executando")
        self.assertFalse(self.registro.obter_retrato()["admissao_fechada"])
        self.servidores.assert_not_called()

    def test_26_sem_atalhos_e_evidencias_incompletas(self):
        self.assertFalse(self.coordenador.executar_parada())
        self.assertFalse(self.coordenador.avaliar_encerramento())
        self.coordenador = self.novo(consultar_responsabilidades=lambda: {})
        self.iniciar()
        self.assertFalse(self.avaliar()["encerramento_confirmado"])
        self.assertEqual(self.coordenador.obter_retrato()["erros"][0]["etapa"], "consulta_recursos")

    def test_27_consulta_antiga_nao_confirma_enquanto_pendente(self):
        chegou = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        contador = []
        def avaliar(registro):
            contador.append(True)
            if len(contador) == 1:
                chegou.wait()
                liberar.wait()
            return servidor.avaliar_encerramento_aplicacao(registro)
        self.coordenador = self.novo(avaliar_agregado=avaliar)
        self.iniciar()
        thread = threading.Thread(target=self.coordenador.avaliar_encerramento)
        thread.start()
        try:
            chegou.wait()
            self.assertFalse(self.avaliar()["encerramento_confirmado"])
        finally:
            liberar.wait()
            self.aguardar(thread)
        self.assertTrue(self.avaliar()["encerramento_confirmado"])

    def test_28_sem_tk_rede_workers_ou_esperas(self):
        arvore = ast.parse(inspect.getsource(prototipo))
        proibidos = {"destroy", "quit", "config", "after", "wait", "join", "sleep",
                     "socket", "connect", "recv", "Thread", "start"}
        for no in ast.walk(arvore):
            if isinstance(no, ast.Call):
                nome = no.func.attr if isinstance(no.func, ast.Attribute) else no.func.id if isinstance(no.func, ast.Name) else None
                self.assertNotIn(nome, proibidos)


if __name__ == "__main__":
    unittest.main()

# Testes de finalizacao retentativas cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC2-B: alvo real/guarda e observação externa; sem rede, Tk ou cleanup integrado."""
import ast
import gc
from pathlib import Path
import threading
import traceback
import unittest
from unittest.mock import Mock, patch
import weakref

from rede.lerdadosserver import LeitorDadosServidor
from test_recursos_cliente_integrados import SocketLeituraFalso
import test_partidas_retentativas_cliente as partidas


THREAD_REAL = threading.Thread


# Grupo de 35 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class FinalizacaoRetentativasCliente(unittest.TestCase):
    setUp = partidas.PartidasRetentativasCliente.setUp
    fabricar = partidas.PartidasRetentativasCliente.fabricar
    preparar = partidas.PartidasRetentativasCliente.preparar
    partir = partidas.PartidasRetentativasCliente.partir
    retrato = partidas.PartidasRetentativasCliente.retrato
    tarefa = partidas.PartidasRetentativasCliente.tarefa
    terminar = partidas.PartidasRetentativasCliente.terminar
    bloquear = partidas.PartidasRetentativasCliente.bloquear

    def negativo(self):
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])
        self.assertFalse(self.infra.avaliar()["cobertura_completa"])

    def iniciar(self, rotina=None):
        self.leitor._aguardar_proxima_tentativa = rotina or Mock()
        self.preparar()
        self.assertTrue(self.partir())
        return self.threads[-1]

    def observar(self):
        return self.infra.observar_termino_retentativas()

    def confirmado(self, indice=0):
        self.assertTrue(self.observar()[indice]["termino_observado"])
        self.assertTrue(self.retrato()[indice]["thread_terminada"])

    def test_01_entrada_antes_da_rotina_na_identidade_original(self):
        def executar():
            estado, = self.retrato()
            self.assertTrue(estado["entrada"])
            self.assertFalse(estado["retorno"])
            self.assertEqual(self.leitor.recursos_cliente.geracao_id, estado["geracao"])
        self.iniciar(executar).target()

    def test_02_retorno_normal_registrado_sem_termino_automatico(self):
        self.iniciar().target()
        self.assertTrue(self.retrato()[0]["retorno"])
        self.assertFalse(self.retrato()[0]["thread_terminada"])
        self.negativo()

    def test_03_excecao_original_instancia_e_traceback(self):
        original = OSError("execucao_simulada")
        def espera():
            raise original
        thread = self.iniciar(espera)
        try:
            thread.target()
        except OSError as erro:
            self.assertIs(original, erro)
            self.assertIn("espera", [f.name for f in traceback.extract_tb(erro.__traceback__)])
        else:
            self.fail("erro primário ausente")
        self.assertTrue(self.retrato()[0]["erro"] and self.retrato()[0]["retorno"])
        self.confirmado()
        self.assertEqual("desconhecido", self.retrato()[0]["estado"])
        self.negativo()

    def test_04_excecao_antes_da_entrada_nao_executa_rotina(self):
        rotina = Mock()
        thread = self.iniciar(rotina)
        with patch.object(self.guarda, "_publicar_entrada", side_effect=RuntimeError("entrada_simulada")):
            with self.assertRaises(RuntimeError):
                thread.target()
        rotina.assert_not_called()
        self.assertFalse(self.observar()[0]["termino_observado"])
        thread.is_alive.assert_not_called()
        self.assertFalse(self.retrato()[0]["entrada"])

    def test_05_start_normal_nao_e_entrada(self):
        thread = self.iniciar()
        self.assertTrue(self.retrato()[0]["partida_resolvida"])
        self.assertFalse(self.retrato()[0]["entrada"])
        self.assertFalse(self.observar()[0]["termino_observado"])
        thread.is_alive.assert_not_called()

    def test_06_start_ambiguo_com_entrada_pode_ser_observado_depois(self):
        self.preparar()
        self.leitor._aguardar_proxima_tentativa = Mock()
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            def iniciar():
                thread.target()
                raise RuntimeError("start_simulado")
            thread.start = iniciar
            return thread
        self.fabrica = criar
        with self.assertRaises(RuntimeError):
            self.partir()
        self.assertTrue(self.retrato()[0]["partida_ambigua"])
        self.assertFalse(self.retrato()[0]["thread_terminada"])
        self.confirmado()
        self.assertFalse(self.retrato()[0]["ausencia_comprovada"])
        self.negativo()

    def test_07_start_ambiguo_sem_entrada_is_alive_false_nao_basta(self):
        self.preparar()
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            thread.start = Mock(side_effect=RuntimeError("start_simulado"))
            return thread
        self.fabrica = criar
        with self.assertRaises(RuntimeError):
            self.partir()
        self.assertFalse(self.observar()[0]["termino_observado"])
        self.threads[0].is_alive.assert_not_called()
        self.assertFalse(self.retrato()[0]["ausencia_comprovada"])

    def test_08_saida_antes_de_start_retornar(self):
        self.preparar()
        self.leitor._aguardar_proxima_tentativa = Mock()
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            def iniciar():
                thread.target()
                self.assertTrue(self.retrato()[0]["retorno"])
                self.assertTrue(self.retrato()[0]["partida_em_curso"])
                self.assertFalse(self.observar()[0]["termino_observado"])
            thread.start = iniciar
            return thread
        self.fabrica = criar
        self.assertTrue(self.partir())
        self.confirmado()

    def test_09_publicacao_entrada_parcial_falha_conservadora(self):
        rotina = Mock()
        thread = self.iniciar(rotina)
        publicar = self.guarda._publicar_entrada
        def falhar(chave):
            publicar(chave)
            raise RuntimeError("publicacao_entrada_simulada")
        with patch.object(self.guarda, "_publicar_entrada", side_effect=falhar):
            with self.assertRaises(RuntimeError):
                thread.target()
        rotina.assert_not_called()
        self.assertTrue(self.retrato()[0]["entrada"] and self.retrato()[0]["erro"])
        self.assertFalse(self.retrato()[0]["retorno"])
        self.assertFalse(self.observar()[0]["termino_observado"])

    def test_10_publicacao_saida_parcial_falha_invalida_evidencia(self):
        thread = self.iniciar()
        publicar = self.guarda._publicar_saida
        def falhar(chave, **kwargs):
            publicar(chave, **kwargs)
            raise RuntimeError("publicacao_saida_simulada")
        with patch.object(self.guarda, "_publicar_saida", side_effect=falhar):
            with self.assertRaises(RuntimeError):
                thread.target()
        self.assertFalse(self.retrato()[0]["retorno"])
        self.assertTrue(self.retrato()[0]["erro"])
        self.assertFalse(self.observar()[0]["termino_observado"])

    def test_11_thread_viva_nao_confirma(self):
        thread = self.iniciar()
        thread.is_alive.return_value = True
        self.assertFalse(self.observar()[0]["termino_observado"])
        self.assertFalse(self.retrato()[0]["thread_terminada"])

    def test_12_alvo_retornou_mas_thread_viva(self):
        thread = self.iniciar()
        thread.target()
        thread.is_alive.return_value = True
        self.assertTrue(self.retrato()[0]["retorno"])
        self.assertFalse(self.observar()[0]["termino_observado"])
        self.assertFalse(self.retrato()[0]["thread_terminada"])

    def test_13_termino_observado_no_objeto_retido_pela_guarda(self):
        thread = self.iniciar()
        thread.target()
        self.confirmado()
        thread.is_alive.assert_called_once_with()
        self.assertEqual("encerramento_confirmado", self.retrato()[0]["estado"])
        self.negativo()

    def test_14_promocao_preserva_origem(self):
        thread = self.iniciar()
        origem = self.retrato()[0]["geracao"]
        self.guarda.promover(self.leitor.recursos_cliente._geracao_retentativas)
        thread.target()
        self.confirmado()
        self.assertEqual(origem, self.retrato()[0]["geracao"])

    def test_15_geracao_antiga_apos_nova_criacao(self):
        thread = self.iniciar()
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        origem = self.retrato()[0]["geracao"]
        self.assertNotEqual(origem, novo.recursos_cliente.geracao_id)
        thread.target()
        self.confirmado()
        self.assertEqual(origem, self.observar()[0]["geracao_id"])

    def test_16_global_nao_confirmado_mesmo_com_retentativa_terminal(self):
        self.iniciar().target()
        self.confirmado()
        self.guarda.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        self.assertTrue(self.guarda.obter_retrato()["conjunto_encerrado"])
        self.negativo()

    def test_17_corrida_a_entrada_antes_de_start_retornar(self):
        self.preparar()
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        self.leitor._aguardar_proxima_tentativa = Mock()
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            def iniciar():
                thread.target()
                self.bloquear(entrou, liberar)
            thread.start = iniciar
            return thread
        with patch("rede.lerdadosserver.threading.Thread", side_effect=criar), patch("builtins.print"):
            trabalho = self.tarefa(self.leitor.registrar_falha_recuperacao)
            self.assertTrue(entrou.wait(3))
            self.assertTrue(self.retrato()[0]["entrada"] and self.retrato()[0]["retorno"])
            self.assertFalse(self.observar()[0]["termino_observado"])
            liberar.set()
            self.terminar(trabalho)
        self.assertEqual([], trabalho[2])
        self.confirmado()

    def test_18_corrida_b_start_lanca_e_alvo_conclui_depois(self):
        self.preparar()
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        self.leitor._aguardar_proxima_tentativa = lambda: self.bloquear(entrou, liberar)
        tarefas = []
        def criar(**kwargs):
            thread = self.fabricar(**kwargs)
            def iniciar():
                tarefa = self.tarefa(thread.target)
                tarefas.append(tarefa)
                thread.is_alive = tarefa[0].is_alive
                if not entrou.wait(3):
                    raise TimeoutError("entrada_simulada")
                raise RuntimeError("start_tardio_simulado")
            thread.start = iniciar
            return thread
        self.fabrica = criar
        with self.assertRaises(RuntimeError):
            self.partir()
        self.assertTrue(self.retrato()[0]["entrada"] and self.retrato()[0]["partida_ambigua"])
        self.assertFalse(self.observar()[0]["termino_observado"])
        liberar.set()
        self.terminar(tarefas[0])
        self.assertEqual([], tarefas[0][2])
        self.confirmado()
        self.assertTrue(self.retrato()[0]["partida_ambigua"])
        self.negativo()

    def test_19_corrida_c_retorno_contra_consulta_thread_real_viva(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        tarefas = []
        self.leitor._aguardar_proxima_tentativa = Mock()
        self.preparar()
        def criar(**kwargs):
            alvo = kwargs["target"]
            def com_cauda():
                alvo()
                self.bloquear(entrou, liberar)
            thread = THREAD_REAL(target=com_cauda, daemon=True)
            tarefas.append(thread)
            return thread
        self.fabrica = criar
        self.partir()
        self.assertTrue(entrou.wait(3))
        self.assertTrue(self.retrato()[0]["retorno"])
        for _ in range(5):
            self.assertFalse(self.observar()[0]["termino_observado"])
        liberar.set()
        tarefas[0].join(3)  # Apenas harness, nunca produção/Tk.
        self.assertFalse(tarefas[0].is_alive())
        self.confirmado()

    def test_20_corrida_d_promocao_enquanto_alvo_executa(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        thread = self.iniciar(lambda: self.bloquear(entrou, liberar))
        tarefa = self.tarefa(thread.target)
        thread.is_alive = tarefa[0].is_alive
        self.assertTrue(entrou.wait(3))
        origem = self.retrato()[0]["geracao"]
        self.guarda.promover(self.leitor.recursos_cliente._geracao_retentativas)
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.assertNotEqual(origem, novo.recursos_cliente.geracao_id)
        self.assertFalse(self.observar()[0]["termino_observado"])
        liberar.set()
        self.terminar(tarefa)
        self.confirmado()
        self.assertEqual(origem, self.retrato()[0]["geracao"])

    def test_21_corrida_e_dois_observadores_mesma_thread(self):
        thread = self.iniciar()
        thread.target()
        barreira = threading.Barrier(2)
        thread.is_alive.side_effect = lambda: (barreira.wait(3), False)[-1]
        a, b = self.tarefa(self.observar), self.tarefa(self.observar)
        self.terminar(a)
        self.terminar(b)
        self.assertEqual([], a[2] + b[2])
        self.assertTrue(a[1][0][0]["termino_observado"] and b[1][0][0]["termino_observado"])
        self.assertEqual(1, len(self.retrato()))
        self.assertTrue(self.retrato()[0]["thread_terminada"])

    def test_22_thread_terminada_socket_pendente(self):
        cliente = self.leitor.recursos_cliente.abrir_socket(lambda: SocketLeituraFalso())
        self.iniciar().target()
        self.confirmado()
        self.assertFalse(self.infra.registro_recursos.obter_retrato()["recursos"][0]["encerramento_confirmado"])
        self.negativo()
        cliente.close()

    def test_23_erro_operacional_e_publicacao_saida_preservados(self):
        original, publicacao = OSError("execucao_simulada"), RuntimeError("saida_simulada")
        def espera():
            raise original
        thread = self.iniciar(espera)
        with patch.object(self.guarda, "_publicar_saida", side_effect=publicacao):
            try:
                thread.target()
            except OSError as erro:
                self.assertIs(original, erro)
                self.assertIs(publicacao, erro.__cause__)
                self.assertIn("espera", [f.name for f in traceback.extract_tb(erro.__traceback__)])
            else:
                self.fail("erro original ausente")
        self.assertTrue(self.retrato()[0]["erro"])
        self.assertFalse(self.retrato()[0]["retorno"])
        self.assertFalse(self.observar()[0]["termino_observado"])

    def test_24_observacao_fora_de_todos_os_locks(self):
        thread = self.iniciar()
        thread.target()
        def observar():
            for lock in (self.guarda._lock, self.infra._lock_retentativas,
                         self.leitor._partidas_retentativas._lock):
                self.assertTrue(lock.acquire(blocking=False))
                lock.release()
            return False
        thread.is_alive.side_effect = observar
        self.confirmado()

    def test_25_erro_na_observacao_nao_confirma(self):
        thread = self.iniciar()
        thread.target()
        thread.is_alive.side_effect = RuntimeError("observacao_simulada")
        self.assertFalse(self.observar()[0]["termino_observado"])
        self.assertTrue(self.retrato()[0]["erro"])
        self.assertFalse(self.retrato()[0]["thread_terminada"])

    def test_26_observacao_nao_booleana_nao_confirma(self):
        thread = self.iniciar()
        thread.target()
        thread.is_alive.return_value = None
        self.assertFalse(self.observar()[0]["termino_observado"])
        self.assertTrue(self.retrato()[0]["erro"])

    def test_27_alvo_real_todos_os_retornos(self):
        for motivo in ("nao_executando", "parada_apos_busca", "estado_alterado", "tentativa_alterada",
                       "servidor", "prazo", "evento_parada", "fim_while"):
            with self.subTest(motivo=motivo):
                leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
                self.preparar(leitor)
                leitor.executando = motivo != "nao_executando"
                self.partir(leitor)
                thread = self.threads[-1]
                def buscar(**kwargs):
                    if motivo == "parada_apos_busca":
                        leitor.executando = False
                    elif motivo == "estado_alterado":
                        leitor.estado_candidatura = "cancelada"
                    elif motivo == "tentativa_alterada":
                        leitor.tentativa_recuperacao = 9
                    return "simulado" if motivo == "servidor" else None
                def esperar(tempo):
                    self.assertEqual(5, tempo)
                    if motivo == "fim_while":
                        leitor.executando = False
                        return False
                    return True
                leitor._parada = Mock()
                leitor._parada.wait.side_effect = esperar
                with patch("rede.lerdadosserver.buscar_servidor", side_effect=buscar), \
                        patch("rede.lerdadosserver.time.monotonic", side_effect=[0, 31 if motivo == "prazo" else 0]), \
                        patch("builtins.print"):
                    thread.target()
                self.assertTrue(self.retrato()[-1]["entrada"] and self.retrato()[-1]["retorno"])
                self.assertFalse(self.retrato()[-1]["thread_terminada"])
        self.assertTrue(all(r["termino_observado"] for r in self.observar()))

    def test_28_erro_no_relogio_antes_do_while_e_monitorado(self):
        self.preparar()
        self.partir()
        original = RuntimeError("relogio_simulado")
        with patch("rede.lerdadosserver.time.monotonic", side_effect=original):
            with self.assertRaises(RuntimeError) as erro:
                self.threads[0].target()
        self.assertIs(original, erro.exception)
        self.assertTrue(self.retrato()[0]["entrada"] and self.retrato()[0]["retorno"])
        self.assertTrue(self.retrato()[0]["erro"])

    def test_29_acompanhamento_alcancavel_apos_leitor_liberado(self):
        leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.preparar(leitor)
        leitor._aguardar_proxima_tentativa = Mock()
        self.partir(leitor)
        self.threads[-1].target()
        referencia = weakref.ref(leitor._partidas_retentativas)
        del leitor
        gc.collect()
        self.assertIsNotNone(referencia())
        self.assertTrue(self.observar()[0]["termino_observado"])

    def test_30_sem_join_no_caminho_operacional_de_observacao(self):
        raiz = Path(__file__).resolve().parents[1]
        for fonte in ("rede/retentativas_cliente.py", "prototipos/guarda_retentativas_cliente.py"):
            arvore = ast.parse((raiz / fonte).read_text(encoding="utf-8"))
            self.assertFalse(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                                 and n.func.attr == "join" for n in ast.walk(arvore)))
        self.assertEqual([], self.observar())

    def test_31_thread_observa_a_si_mesma_sem_confirmar(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        resultados, threads = [], []
        self.preparar()
        self.leitor._aguardar_proxima_tentativa = Mock()
        def criar(**kwargs):
            def executar():
                kwargs["target"]()
                if not liberar.wait(3):
                    raise TimeoutError("partida_simulada")
                resultados.extend(self.observar())
                entrou.set()
            thread = THREAD_REAL(target=executar, daemon=True)
            threads.append(thread)
            return thread
        self.fabrica = criar
        self.partir()
        liberar.set()
        self.assertTrue(entrou.wait(3))
        threads[0].join(3)
        self.assertFalse(resultados[0]["termino_observado"])
        self.confirmado()

    def test_32_avaliacao_global_nao_observa_termino_implicitamente(self):
        thread = self.iniciar()
        thread.target()
        self.infra.avaliar()
        thread.is_alive.assert_not_called()
        self.assertFalse(self.retrato()[0]["thread_terminada"])

    def test_33_excecao_da_descoberta_no_alvo_real(self):
        self.preparar()
        self.partir()
        original = OSError("descoberta_simulada")
        with patch("rede.lerdadosserver.buscar_servidor", side_effect=original):
            with self.assertRaises(OSError) as erro:
                self.threads[0].target()
        self.assertIs(original, erro.exception)
        self.assertTrue(self.retrato()[0]["retorno"] and self.retrato()[0]["erro"])
        self.confirmado()
        self.assertEqual("desconhecido", self.retrato()[0]["estado"])

    def test_34_baseexception_tambem_publica_saida_sem_ocultar(self):
        class InterrupcaoSimulada(BaseException):
            pass
        original = InterrupcaoSimulada()
        def interromper():
            raise original
        thread = self.iniciar(interromper)
        with self.assertRaises(InterrupcaoSimulada) as erro:
            thread.target()
        self.assertIs(original, erro.exception)
        self.assertTrue(self.retrato()[0]["retorno"] and self.retrato()[0]["erro"])
        self.negativo()

    def test_35_observacoes_repetidas_preservam_identidade_e_historico(self):
        self.iniciar().target()
        self.confirmado()
        anterior = self.retrato()
        for _ in range(3):
            self.assertTrue(self.observar()[0]["termino_observado"])
        self.assertEqual(anterior, self.retrato())
        self.assertEqual(1, len(self.retrato()))

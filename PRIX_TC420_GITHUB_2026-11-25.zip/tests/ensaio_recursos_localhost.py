"""Ensaio explícito, fora do unittest: TCP/UDP reais apenas no loopback.

python -B tests/ensaio_recursos_localhost.py --duracao 120 --saida resultado.json
HTTP substituído por espera local; não usa configuração, credenciais ou TC420.
"""
import argparse
from collections import Counter
from contextlib import ExitStack
import ctypes
from ctypes import wintypes
import gc
import json
from pathlib import Path
import platform
import socket
import sys
import threading
import time
import tracemalloc
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rede import servidor as s
from interface.saida_aplicacao import SaidaAplicacao


def memoria_processo():
    if sys.platform != 'win32':
        return {}
    class Contadores(ctypes.Structure):
        _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
            (n, ctypes.c_size_t) for n in ('PeakWorkingSetSize', 'WorkingSetSize',
            'QuotaPeakPagedPoolUsage', 'QuotaPagedPoolUsage',
            'QuotaPeakNonPagedPoolUsage', 'QuotaNonPagedPoolUsage',
            'PagefileUsage', 'PeakPagefileUsage', 'PrivateUsage')]
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    handle = kernel.GetCurrentProcess()
    contadores = Contadores()
    contadores.cb = ctypes.sizeof(contadores)
    api = ctypes.WinDLL('psapi', use_last_error=True)
    api.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
    if not api.GetProcessMemoryInfo(handle, ctypes.byref(contadores), contadores.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    quantidade = wintypes.DWORD()
    kernel.GetProcessHandleCount.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    if not kernel.GetProcessHandleCount(handle, ctypes.byref(quantidade)):
        raise ctypes.WinError(ctypes.get_last_error())
    return dict(working_set_bytes=contadores.WorkingSetSize,
                private_bytes=contadores.PrivateUsage, handles_processo=quantidade.value)


def executar(duracao, progresso=None):
    if duracao < 30:
        raise ValueError('Use pelo menos 30 segundos para incluir fase ociosa')
    portas, prontos = {}, {t: threading.Event() for t in (socket.SOCK_STREAM, socket.SOCK_DGRAM)}
    class SocketLocal(socket.socket):
        def bind(self, endereco):
            # Defesa no harness: nenhuma interface externa, portas efêmeras reais.
            super().bind(('127.0.0.1', 0))
            portas[self.type] = self.getsockname()[1]
            prontos[self.type].set()
    proxy = SimpleNamespace(**{n: getattr(socket, n) for n in dir(socket) if not n.startswith('__')})
    proxy.socket = SocketLocal
    controle = s.ControleCicloServidor()
    contexto = s.ContextoCicloServidor()
    saida = SaidaAplicacao(prazo=10)
    saida.configurar(registro=s.RegistroTentativasAplicacao())
    saida.acompanhar_contexto(contexto)
    solicitar = saida.vincular('ensaio_localhost')
    erros = []
    contagem = Counter()
    amostras = []
    def fonte_local(_web):
        with s.lock_saude:
            s.saude_tc420['saudavel'] = True
        s.evento_parada_servidor.wait()
    def servidor(ctx):
        try:
            s.iniciar_servidor(SimpleNamespace(token=object()), contexto_ciclo=ctx)
        except BaseException as erro:
            erros.append(type(erro).__name__)
    def cliente(comando):
        with socket.create_connection(('127.0.0.1', portas[socket.SOCK_STREAM]), timeout=3) as sock:
            sock.sendall(comando.encode() + b'\n')
            resposta = sock.recv(4096)
            if not resposta:
                raise RuntimeError('resposta_vazia')
            if comando == 'CHECK':
                assert resposta == b'TC420_SERVER_OK\n'
            else:
                json.loads(resposta.split(b'\n')[0])
            contagem[comando.partition('|')[0]] += 1
    def udp():
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(3)
            sock.sendto(s.MENSAGEM_DESCOBERTA, ('127.0.0.1', portas[socket.SOCK_DGRAM]))
            assert sock.recvfrom(1024)[0] == s.MENSAGEM_RESPOSTA
            contagem['UDP'] += 1
    def amostrar(fase):
        gc.collect()
        atual, pico = tracemalloc.get_traced_memory()
        r = controle.registro_atual
        with r.lock:
            estados = dict(Counter(e.estado for e in r._reservas_socket.values()))
            recursos = [e.recurso for e in r._reservas_socket.values() if e.recurso is not None]
            linha = dict(segundos=round(time.monotonic()-inicio, 3), fase=fase,
                entradas=len(r._reservas_socket), estados=estados,
                threads_retidas=len(r.threads), threads_registro_vivas=sum(t.is_alive() for t in r.threads),
                sockets_referenciados=len(recursos), sockets_abertos=sum(x.fileno() != -1 for x in recursos),
                erros_limpeza=len(r.erros_limpeza))
        linha.update(bytes_python_atual=atual, bytes_python_pico=pico,
            threads_processo=threading.active_count(), **memoria_processo())
        amostras.append(linha)
        if progresso is not None:
            with progresso.open('a', encoding='utf-8') as arquivo:
                arquivo.write(json.dumps(linha) + '\n')
    with ExitStack() as stack:
        for nome, valor in dict(socket=proxy, HOST='127.0.0.1', PORTA_TCP=0,
                PORTA_DESCOBERTA=0, controle_ciclo_servidor=controle,
                evento_parada_servidor=threading.Event(), ler_tc420=fonte_local,
                clientes_registrados={}, configuracao_atual={'ensaio': True},
                saude_tc420=dict(s.saude_tc420)).items():
            stack.enter_context(patch.object(s, nome, valor))
        worker = threading.Thread(target=servidor, args=(contexto,), daemon=True)
        inicio = time.monotonic()
        tracemalloc.start()
        saida.iniciar_thread(worker)
        try:
            for e in prontos.values():
                if not e.wait(5):
                    raise RuntimeError('servidor_nao_abriu_porta')
            cliente('CONFIG')
            # CHECK também serve como barreira de prontidão da fonte sintética.
            limite = time.monotonic() + 5
            while not s.obter_saude_tc420()['saudavel']:
                if time.monotonic() > limite:
                    raise RuntimeError('fonte_local_nao_pronta')
                time.sleep(.01)
            amostrar('inicio')
            proxima = 10
            while time.monotonic()-inicio < duracao:
                decorrido = time.monotonic()-inicio
                fase = 'carga' if decorrido % 30 < 15 else 'ocioso'
                if fase == 'carga':
                    for comando in ('CONFIG', 'REGISTER|cliente-local', 'CHECK', 'SUBSCRIBE'):
                        cliente(comando)
                    udp()
                if decorrido >= proxima:
                    amostrar(fase)
                    proxima += 10
                time.sleep(.5)
            amostrar('antes_b2')
        finally:
            inicio_saida = time.monotonic()
            solicitar()
            if saida._coordenacao is not None:
                saida._coordenacao.join(12)
            worker.join(3)
            amostrar('apos_b2')
            atual_b2 = saida.obter_situacao()
            avaliacao = s.avaliar_encerramento_tentativa(contexto)
            tracemalloc.stop()
        assert atual_b2['parada_operacional_confirmada'], atual_b2
        assert avaliacao['encerramento_confirmado'] is True, avaliacao
        assert not worker.is_alive()
        assert not erros, erros
        assert amostras[-1]['sockets_abertos'] == 0
        assert amostras[-1]['threads_registro_vivas'] == 0
        encerramento_segundos = time.monotonic()-inicio_saida
        carga_primeiro_ciclo = dict(contagem)
        # Verifica partida e parada reais de outra geração, no mesmo controle.
        contexto_novo = s.ContextoCicloServidor()
        saida_nova = SaidaAplicacao(prazo=10)
        saida_nova.configurar(registro=s.RegistroTentativasAplicacao())
        saida_nova.acompanhar_contexto(contexto_novo)
        parar_novo = saida_nova.vincular('ensaio_reabertura')
        for e in prontos.values():
            e.clear()
        worker_novo = threading.Thread(target=servidor, args=(contexto_novo,), daemon=True)
        saida_nova.iniciar_thread(worker_novo)
        try:
            for e in prontos.values():
                if not e.wait(5):
                    raise RuntimeError('novo_ciclo_nao_abriu_porta')
            cliente('CONFIG')
            cliente('CHECK')
            udp()
        finally:
            parar_novo()
            if saida_nova._coordenacao is not None:
                saida_nova._coordenacao.join(12)
            worker_novo.join(3)
        nova_b2 = saida_nova.obter_situacao()
        nova_avaliacao = s.avaliar_encerramento_tentativa(contexto_novo)
        assert nova_b2['parada_operacional_confirmada'], nova_b2
        assert nova_avaliacao['encerramento_confirmado'] is True, nova_avaliacao
        assert nova_avaliacao['ciclo_id'] != avaliacao['ciclo_id']
        assert not worker_novo.is_alive()
        assert s.avaliar_encerramento_tentativa(contexto)['encerramento_confirmado'] is True
        situacao_nova = controle.registro_atual.obter_situacao()
        assert situacao_nova['sockets_encerrados'] and not situacao_nova['threads_vivas']
        assert not erros, erros
        return dict(python=platform.python_version(), plataforma=sys.platform,
            duracao_solicitada=duracao, encerramento_segundos=encerramento_segundos,
            carga=carga_primeiro_ciclo, amostras=amostras, b2=atual_b2,
            reabertura=dict(b2=nova_b2, avaliacao=nova_avaliacao,
                           sockets_encerrados=situacao_nova['sockets_encerrados']),
            avaliacao=avaliacao, erros=erros,
            limites='Loopback real; HTTP sintetico; sem Tk, TC420, credenciais ou transporte HTTPS. '
                    'Amostras e infraestrutura do harness tambem ocupam memoria; nao e ensaio de dias.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--duracao', type=float, default=120)
    parser.add_argument('--saida', type=Path, required=True)
    parser.add_argument('--progresso', type=Path)
    parser.add_argument('--status', type=Path)
    args = parser.parse_args()
    def status(estado, **campos):
        if args.status is not None:
            args.status.write_text(json.dumps(dict(estado=estado, **campos), indent=2), encoding='utf-8')
    if args.progresso is not None and args.progresso.exists():
        raise FileExistsError('Use um arquivo de progresso novo para cada execucao')
    status('executando', duracao_segundos=args.duracao)
    try:
        resultado = executar(args.duracao, args.progresso)
        args.saida.write_text(json.dumps(resultado, indent=2, ensure_ascii=False), encoding='utf-8')
    except BaseException as erro:
        status('falhou', categoria=type(erro).__name__)
        raise
    else:
        status('concluido', resultado=str(args.saida))

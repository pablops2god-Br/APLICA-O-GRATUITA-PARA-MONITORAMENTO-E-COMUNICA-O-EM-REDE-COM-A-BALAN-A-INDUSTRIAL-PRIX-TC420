# Testes de tentativas internas cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Conector TCP real, resolução/transporte falsos; sem DNS, rede ou Tk."""
from contextlib import contextmanager
import json
import socket
import threading
import unittest
from unittest.mock import Mock, patch

from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
from test_recursos_cliente_integrados import SocketLeituraFalso


# Grupo de 27 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class TentativasInternasCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.dono = RecursosLeitorCliente(self.infra)
        self.reg = self.infra.registro_recursos
        self.destino = ("principal-simulado", 42100)

    def recursos(self):
        return self.reg.obter_retrato()["recursos"]

    def enderecos(self, quantidade):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (f"destino-{i}", 42100))
                for i in range(quantidade)]

    @contextmanager
    def transporte(self, objetos, quantidade=1):
        with patch.object(socket, "getaddrinfo", return_value=self.enderecos(quantidade)), \
                patch.object(socket, "socket", side_effect=objetos) as alocar:
            yield alocar

    def conectar(self, dono=None):
        return (dono or self.dono).conectar_tcp(self.destino, timeout=5)

    def global_negativo(self):
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])

    def test_01_sucesso_identidade_e_socket_ainda_utilizavel(self):
        objeto = SocketLeituraFalso()
        with self.transporte([objeto]):
            cliente = self.conectar()
        self.assertFalse(objeto.fechado)
        self.assertEqual(1, len(self.recursos()))
        self.assertTrue(self.recursos()[0]["publicado"])
        self.assertEqual(self.dono.geracao_id, self.recursos()[0]["geracao_id"])
        cliente.sendall(b"CHECK\n")
        objeto.sendall.assert_called_once_with(b"CHECK\n")
        cliente.close()

    def test_02_recusa_limpa_e_preserva_original(self):
        objeto = SocketLeituraFalso()
        erro = ConnectionRefusedError("recusa_simulada")
        objeto.connect.side_effect = erro
        with self.transporte([objeto]):
            with self.assertRaises(ConnectionRefusedError) as capturado:
                self.conectar()
        self.assertIs(erro, capturado.exception)
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])
        self.assertTrue(self.recursos()[0]["erros_atendimento"])

    def test_03_timeout_e_parametro_preservados(self):
        objeto = SocketLeituraFalso()
        erro = TimeoutError("timeout_simulado")
        objeto.connect.side_effect = erro
        with self.transporte([objeto]):
            with self.assertRaises(TimeoutError) as capturado:
                self.conectar()
        self.assertIs(erro, capturado.exception)
        objeto.settimeout.assert_called_once_with(5)
        self.assertTrue(objeto.fechado)

    def test_04_falha_comprovada_antes_da_alocacao(self):
        with self.transporte([]) as alocar, \
                patch.object(self.reg, "criar", side_effect=ValueError()):
            with self.assertRaises(ValueError):
                self.conectar()
        alocar.assert_not_called()
        self.reg.fechar_admissao()
        self.assertTrue(self.recursos()[0]["ausencia_comprovada"])
        self.assertTrue(self.reg.obter_retrato()["encerramento_confirmado"])

    def test_05_falha_apos_alocacao_limpa_setup(self):
        objeto = SocketLeituraFalso()
        erro = ValueError("setup_simulado")
        objeto.settimeout.side_effect = erro
        with self.transporte([objeto]):
            with self.assertRaises(ValueError) as capturado:
                self.conectar()
        self.assertIs(erro, capturado.exception)
        objeto.connect.assert_not_called()
        self.assertTrue(objeto.fechado)
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])

    def test_06_sequencia_falha_sucesso_ids_distintos(self):
        primeiro, segundo = SocketLeituraFalso(), SocketLeituraFalso()
        primeiro.connect.side_effect = ConnectionRefusedError()
        with self.transporte([primeiro, segundo], 2):
            cliente = self.conectar()
        self.assertEqual(2, len({r["recurso_id"] for r in self.recursos()}))
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])
        self.assertFalse(self.recursos()[1]["encerramento_confirmado"])
        primeiro.connect.assert_called_once_with(("destino-0", 42100))
        segundo.connect.assert_called_once_with(("destino-1", 42100))
        cliente.close()

    def paralelo(self, operacoes):
        erros = []
        def tarefa(operacao):
            try:
                operacao()
            except BaseException as erro:
                erros.append(erro)
        threads = [threading.Thread(target=tarefa, args=(op,)) for op in operacoes]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(3)
            self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_07_tentativas_simultaneas(self):
        barreira = threading.Barrier(2)
        def fabricar(*_):
            objeto = SocketLeituraFalso()
            objeto.connect.side_effect = lambda destino: barreira.wait(3)
            return objeto
        with self.transporte(fabricar):
            self.paralelo([lambda: self.conectar().close()] * 2)
        self.assertEqual(2, len({r["recurso_id"] for r in self.recursos()}))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_08_socket_registrado_externamente_sem_duplicidade(self):
        with self.transporte([SocketLeituraFalso()]):
            cliente = self.conectar()
        outro = RecursosLeitorCliente(self.infra)
        with patch.object(self.reg, "reservar", side_effect=AssertionError("reserva_duplicada")):
            self.assertIs(cliente, self.dono.abrir_socket(cliente))
            self.assertIs(cliente, outro.abrir_socket(cliente))
        self.assertEqual(1, len(self.recursos()))
        self.assertEqual(self.dono.geracao_id, self.recursos()[0]["geracao_id"])
        cliente.close()

    def test_09_transferencia_para_config_sem_novo_id_socket(self):
        objeto = SocketLeituraFalso()
        objeto.arquivo.readline = Mock(return_value='{"config":1}')
        with self.transporte([objeto]):
            cliente = self.conectar()
        token = cliente.recurso_id.numero
        resultado = self.dono.ler_configuracao(cliente, json.loads)
        self.assertEqual({"config": 1}, resultado)
        self.assertEqual(["socket_tcp", "arquivo_socket"], [r["tipo"] for r in self.recursos()])
        self.assertEqual(token, self.recursos()[1]["associado_a"])
        self.assertEqual(1, objeto.close_chamadas)
        objeto.sendall.assert_called_once_with(b"CONFIG\n")

    def test_10_publicacao_incerta_sem_confirmacao(self):
        objeto = SocketLeituraFalso()
        def falhar(token, alocar):
            alocar()
            raise ValueError()
        with self.transporte([objeto]), patch.object(self.reg, "criar", side_effect=falhar):
            with self.assertRaises(ValueError):
                self.conectar()
        self.assertTrue(self.dono.obter_publicacoes_pendentes())
        self.assertTrue(objeto.fechado)
        self.reg.fechar_admissao()
        self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])

    def test_11_falha_fechamento_evidencia_negativa(self):
        objeto = SocketLeituraFalso()
        with self.transporte([objeto]):
            cliente = self.conectar()
        objeto.erro_close = OSError()
        with self.assertRaises(OSError):
            cliente.close()
        self.reg.fechar_admissao()
        self.assertTrue(self.recursos()[0]["erros_limpeza"])
        self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])

    def test_12_erro_original_e_limpeza_abortam_no_mesmo_ponto(self):
        objeto = SocketLeituraFalso()
        original = ConnectionRefusedError("recusa_simulada")
        objeto.connect.side_effect = original
        objeto.erro_close = OSError("close_simulado")
        with self.transporte([objeto], 2) as alocar:
            with self.assertRaises(ConnectionRefusedError) as capturado:
                self.conectar()
        self.assertIs(original, capturado.exception)
        self.assertEqual(1, alocar.call_count)
        self.assertTrue(self.recursos()[0]["erros_atendimento"])
        self.assertTrue(self.recursos()[0]["erros_limpeza"])

    def test_13_promocao_na_tentativa_preserva_geracao(self):
        objeto = SocketLeituraFalso()
        objeto.connect.side_effect = lambda destino: self.reg.promover(self.dono.geracao_id)
        with self.transporte([objeto]):
            cliente = self.conectar()
        self.assertEqual(self.dono.geracao_id, self.recursos()[0]["geracao_id"])
        self.assertEqual("principal", self.recursos()[0]["modo_atual"])
        cliente.close()

    def test_14_gate_fecha_durante_fabrica(self):
        objeto = SocketLeituraFalso()
        def fabricar(*_):
            self.reg.fechar_admissao()
            return objeto
        with self.transporte(fabricar):
            with self.assertRaises(RuntimeError):
                self.conectar()
        objeto.connect.assert_not_called()
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])

    def retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []
        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise AssertionError("barreira_nao_liberada")
        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_15_consulta_durante_limpeza(self):
        objeto = SocketLeituraFalso()
        objeto.connect.side_effect = TimeoutError()
        close = objeto.close
        def executar(suspender):
            objeto.close = lambda: (suspender(), close())[-1]
            with self.transporte([objeto]):
                with self.assertRaises(TimeoutError):
                    self.conectar()
        def consultar():
            self.reg.fechar_admissao()
            self.assertTrue(self.recursos()[0]["limpeza_em_curso"])
            self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])
            self.global_negativo()
        self.retido(executar, consultar)
        self.assertTrue(self.reg.obter_retrato()["encerramento_confirmado"])

    def test_16_cobertura_global_incompleta(self):
        with self.transporte([SocketLeituraFalso()]):
            self.conectar().close()
        self.reg.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.assertTrue(self.reg.obter_retrato()["encerramento_confirmado"])
        self.global_negativo()

    def test_critico_A_alocacao_retida_apos_reserva(self):
        objeto = SocketLeituraFalso()
        def executar(suspender):
            def fabricar(*_):
                self.assertTrue(self.reg._lock.acquire(blocking=False))
                self.reg._lock.release()
                suspender()
                return objeto
            with self.transporte(fabricar):
                with self.assertRaises(RuntimeError):
                    self.conectar()
        def encerrar():
            self.reg.fechar_admissao()
            self.assertEqual(1, len(self.recursos()))
            self.assertTrue(self.recursos()[0]["criacao_em_curso"])
            self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])
            self.global_negativo()
        self.retido(executar, encerrar)
        self.assertTrue(objeto.fechado)
        self.assertTrue(self.recursos()[0]["encerramento_confirmado"])

    def test_critico_B_duas_criacoes_ativas(self):
        barreira = threading.Barrier(2)
        def fabricar(*_):
            objeto = SocketLeituraFalso()
            def conectar(destino):
                barreira.wait(3)
                self.assertEqual(2, len({r["recurso_id"] for r in self.recursos()}))
                self.assertTrue(all(r["publicado"] for r in self.recursos()))
            objeto.connect.side_effect = conectar
            return objeto
        with self.transporte(fabricar):
            self.paralelo([lambda: self.conectar().close()] * 2)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_critico_C_transferencia_sem_close_antecipado(self):
        objeto = SocketLeituraFalso()
        objeto.arquivo.readline = Mock(return_value='{"posicao":1}')
        def executar(suspender):
            with self.transporte([objeto]):
                cliente = self.conectar()
            suspender()  # Auxiliar entregou, protocolo ainda usará o mesmo token.
            self.assertEqual({"posicao": 1}, self.dono.registrar_cliente(cliente, "cliente-simulado", json.loads))
        def consultar():
            self.assertEqual(1, len(self.recursos()))
            self.assertFalse(objeto.fechado)
            self.assertFalse(self.recursos()[0]["encerramento_confirmado"])
            self.global_negativo()
        self.retido(executar, consultar)
        self.assertEqual(2, len(self.recursos()))
        self.assertEqual(self.recursos()[0]["recurso_id"], self.recursos()[1]["associado_a"])
        self.assertEqual(1, objeto.close_chamadas)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_critico_D_antiga_conectando_nova_finalizada(self):
        antigo, novo = SocketLeituraFalso(), SocketLeituraFalso()
        def executar(suspender):
            antigo.connect.side_effect = lambda destino: suspender()
            self.conectar().close()
        def promover():
            self.reg.promover(self.dono.geracao_id)
            nova = RecursosLeitorCliente(self.infra)
            self.conectar(nova).close()
            self.assertTrue(self.reg.obter_retrato(geracao_id=nova.geracao_id)["recursos"][0]["encerramento_confirmado"])
            self.assertFalse(self.recursos()[0]["encerramento_confirmado"])
            self.assertNotEqual(self.recursos()[0]["geracao_id"], self.recursos()[1]["geracao_id"])
            self.global_negativo()
        with self.transporte([antigo, novo]):
            self.retido(executar, promover)
        self.assertEqual(self.dono.geracao_id, self.recursos()[0]["geracao_id"])
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_compatibilidade_retornos_erros_ordem_timeout(self):
        for falhas in ((None,), (ConnectionRefusedError, None), (TimeoutError, ConnectionRefusedError)):
            resultados = []
            for observado in (False, True):
                objetos, eventos = [], []
                for indice, falha in enumerate(falhas):
                    objeto = SocketLeituraFalso()
                    objeto.settimeout.side_effect = lambda timeout, i=indice: eventos.append((i, "timeout", timeout))
                    def conectar(destino, i=indice, tipo=falha):
                        eventos.append((i, "connect", destino))
                        if tipo is not None:
                            raise tipo("erro_simulado")
                    objeto.connect.side_effect = conectar
                    close = objeto.close
                    objeto.close = lambda i=indice, fn=close: (eventos.append((i, "close")), fn())[-1]
                    objetos.append(objeto)
                with self.transporte(objetos, len(objetos)):
                    try:
                        cliente = self.conectar() if observado else socket.create_connection(self.destino, timeout=5)
                        bruto = cliente._objeto if observado else cliente
                        resultado = ("sucesso", objetos.index(bruto))
                        cliente.close()
                    except OSError as erro:
                        resultado = (type(erro), str(erro))
                resultados.append((resultado, eventos))
            self.assertEqual(resultados[0], resultados[1])

    def test_enderecos_vazios_e_dns_falho_preservados(self):
        for falha in (None, socket.gaierror("dns_simulado")):
            resultados = []
            for observado in (False, True):
                with patch.object(socket, "getaddrinfo", return_value=[], side_effect=falha), \
                        patch.object(socket, "socket") as alocar:
                    try:
                        self.conectar() if observado else socket.create_connection(self.destino, timeout=5)
                    except OSError as erro:
                        resultados.append((type(erro), str(erro)))
                alocar.assert_not_called()
            self.assertEqual(resultados[0], resultados[1])

    def test_transferencia_entre_geracoes_preserva_dono_original(self):
        objeto = SocketLeituraFalso()
        objeto.arquivo.readline = Mock(return_value='{}')
        with self.transporte([objeto]):
            cliente = self.conectar()
        nova = RecursosLeitorCliente(self.infra)
        nova.ler_configuracao(cliente, json.loads)
        self.assertTrue(all(r["geracao_id"] == self.dono.geracao_id for r in self.recursos()))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))
        outra_infra = InfraestruturaRegistrosCliente()
        with self.assertRaisesRegex(ValueError, "outro_registro"):
            RecursosLeitorCliente(outra_infra).abrir_socket(cliente)
        self.assertEqual([], outra_infra.registro_recursos.obter_retrato()["recursos"])

    def test_leitor_real_config_register_reconexao_timeout(self):
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente-simulado"):
            leitor = LeitorDadosServidor("principal-simulado", infraestrutura_cliente=self.infra)
        leitor.executando = True
        config, registro, sub, falho = [SocketLeituraFalso() for _ in range(4)]
        config.arquivo.readline = Mock(return_value='{}')
        registro.arquivo.readline = Mock(return_value='{"nome":"cliente-simulado","posicao":1}')
        sub.arquivo.readline = Mock(return_value='')
        falho.connect.side_effect = TimeoutError()
        def recuperar():
            if leitor._aguardar_candidatura.call_count == 2:
                leitor.parar()
            leitor.ip_servidor = "principal-simulado"
            return False
        leitor._aguardar_candidatura = Mock(side_effect=recuperar)
        leitor._parada.wait = Mock(return_value=False)
        with self.transporte([config, registro, sub, falho]), patch("builtins.print"):
            leitor._manter_atualizado()
        self.assertEqual({}, leitor.configuracao)
        self.assertEqual(1, leitor.posicao_sucessao)
        config.sendall.assert_called_once_with(b"CONFIG\n")
        registro.sendall.assert_called_once_with(b"REGISTER|cliente-simulado\n")
        sub.sendall.assert_called_once_with(b"SUBSCRIBE\n")
        self.assertEqual(2, leitor._aguardar_candidatura.call_count)
        self.assertEqual(7, len({r["recurso_id"] for r in self.recursos()}))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_mesmo_resultado_config_agora_com_tres_recursos(self):
        primeiro, segundo = SocketLeituraFalso(), SocketLeituraFalso()
        primeiro.connect.side_effect = ConnectionRefusedError()
        segundo.arquivo.readline = Mock(return_value='{"config":1}')
        with self.transporte([primeiro, segundo], 2):
            resultado = self.dono.ler_configuracao(self.conectar(), json.loads)
        self.assertEqual({"config": 1}, resultado)
        self.assertEqual(["socket_tcp", "socket_tcp", "arquivo_socket"], [r["tipo"] for r in self.recursos()])
        self.assertEqual(self.recursos()[1]["recurso_id"], self.recursos()[2]["associado_a"])
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_falha_de_comunicacao_depois_de_conectar_e_cleanup(self):
        objeto = SocketLeituraFalso()
        original = OSError("envio_simulado")
        objeto.sendall.side_effect = original
        objeto.erro_close = ValueError("close_simulado")
        with self.transporte([objeto]):
            cliente = self.conectar()
        with self.assertRaises(OSError) as capturado:
            self.dono.ler_configuracao(cliente, json.loads)
        self.assertIs(original, capturado.exception)
        self.assertEqual(1, len(self.recursos()))
        self.assertTrue(self.recursos()[0]["erros_atendimento"])
        self.assertTrue(self.recursos()[0]["erros_limpeza"])
        objeto.makefile.assert_not_called()

    def test_fabrica_opaca_falha_e_proxima_conecta_sem_apagar_pendencia(self):
        objeto = SocketLeituraFalso()
        with self.transporte([OSError("alocacao_simulada"), objeto], 2):
            cliente = self.conectar()
        cliente.close()
        self.reg.fechar_admissao()
        self.assertEqual("desconhecido", self.recursos()[0]["estado"])
        self.assertFalse(self.recursos()[0]["ausencia_comprovada"])
        self.assertTrue(self.recursos()[1]["encerramento_confirmado"])
        self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])
        self.global_negativo()


if __name__ == "__main__":
    unittest.main()

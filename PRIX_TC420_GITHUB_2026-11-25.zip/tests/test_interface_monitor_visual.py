# Testes de interface monitor visual: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Caracterização da barra operacional e da cópia segura do monitor."""
from types import SimpleNamespace
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import Mock, patch

from interface.janela import COR_FUNDO_MONITOR, JanelaTC420, _caminho_asset


# Grupo de 17 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class InterfaceMonitorVisual(unittest.TestCase):
    # Monta apenas os atributos necessários ao cálculo do status, sem criar uma janela Tk real.
    def janela(self, **mudancas):
        base = dict(
            promocao_em_andamento=False,
            modo_monitor="cliente",
            comunicacao_confirmada=True,
            estado_candidatura=lambda: "inativa",
            obter_saude_principal=None,
            servidor_encerrado=None,
        )
        base.update(mudancas)
        return SimpleNamespace(**base)

    # Reutiliza os métodos reais de consulta e cálculo de status sobre o objeto mínimo do teste.
    def retrato(self, janela):
        janela._consultar = lambda callback, padrao=None: JanelaTC420._consultar(
            janela, callback, padrao
        )
        return JanelaTC420._retrato_status(janela)

    # Exige cor verde e mensagens de principal saudável quando os callbacks confirmam a saúde.
    def test_01_ap_verde_exige_saude_confirmada(self):
        janela = self.janela(
            modo_monitor="principal",
            obter_saude_principal=lambda: {"saudavel": True},
            servidor_encerrado=lambda: False,
        )
        chave, cor, mensagens = self.retrato(janela)
        self.assertEqual(("ap_ok", "#31c94b"), (chave, cor))
        self.assertEqual(("Servidor ON", "AP OK"), mensagens)

    # Uma falha de saúde produz amarelo mesmo que o servidor ainda não tenha encerrado.
    def test_02_ap_amarelo_quando_tc420_nao_saudavel(self):
        janela = self.janela(
            modo_monitor="principal",
            obter_saude_principal=lambda: {"saudavel": False},
            servidor_encerrado=lambda: False,
        )
        chave, cor, mensagens = self.retrato(janela)
        self.assertEqual(("ap_falha", "#e6b800"), (chave, cor))
        self.assertIn("Falha de comunicação com a TC420", mensagens)

    # O sinal de encerramento tem prioridade sobre a informação anterior de saúde.
    def test_03_ap_vermelho_somente_com_encerramento_comprovado(self):
        janela = self.janela(
            modo_monitor="principal",
            obter_saude_principal=lambda: {"saudavel": True},
            servidor_encerrado=lambda: True,
        )
        chave, cor, mensagens = self.retrato(janela)
        self.assertEqual(("ap_encerrado", "#c62828"), (chave, cor))
        self.assertIn("Servidor encerrado", mensagens)

    # Comunicação atual mantém o status verde do cliente.
    def test_04_ct_verde_exige_comunicacao_atual(self):
        chave, cor, mensagens = self.retrato(self.janela())
        self.assertEqual(("ct_ok", "#31c94b"), (chave, cor))
        self.assertIn("Recebendo mensagens válidas", mensagens)

    # Sem comunicação, o cliente em recuperação mostra aviso amarelo de reconexão.
    def test_05_ct_amarelo_durante_falha_antes_da_candidatura(self):
        janela = self.janela(comunicacao_confirmada=False)
        chave, cor, mensagens = self.retrato(janela)
        self.assertEqual(("ct_falha", "#e6b800"), (chave, cor))
        self.assertIn("Tentando reconectar", mensagens)

    # Sem callback de candidatura e sem comunicação, o status indica procura do principal.
    def test_06_ct_vermelho_sem_participacao_na_sucessao(self):
        janela = self.janela(
            comunicacao_confirmada=False,
            estado_candidatura=None,
        )
        chave, cor, mensagens = self.retrato(janela)
        self.assertEqual(("ct_indisponivel", "#c62828"), (chave, cor))
        self.assertIn("Procurando servidor PRINCIPAL", mensagens)

    # Confere chaves distintas para espera, liberação e promoção, apesar da cor roxa compartilhada.
    def test_07_roxo_diferencia_espera_liberacao_e_promocao(self):
        aguardando = self.retrato(self.janela(
            comunicacao_confirmada=False,
            estado_candidatura=lambda: "aguardando",
        ))
        liberada = self.retrato(self.janela(
            comunicacao_confirmada=False,
            estado_candidatura=lambda: "liberada",
        ))
        promovendo = self.retrato(self.janela(promocao_em_andamento=True))
        self.assertEqual("ct_aguardando", aguardando[0])
        self.assertEqual("ct_liberada", liberada[0])
        self.assertEqual("promovendo", promovendo[0])
        self.assertEqual({"#7b2cbf"}, {aguardando[1], liberada[1], promovendo[1]})

    # Verifica aviso ao operador e ausência de escrita no clipboard quando a leitura está desatualizada.
    def test_08_leitura_antiga_nao_e_copiada(self):
        raiz = Mock()
        janela = self.janela(
            comunicacao_confirmada=False,
            root=raiz,
            label_peso=Mock(),
            label_tara=Mock(),
            label_unidade=Mock(),
        )
        with patch("interface.janela.messagebox.showwarning") as aviso:
            self.assertFalse(JanelaTC420.copiar_medicao(janela, "peso"))
        aviso.assert_called_once()
        raiz.clipboard_append.assert_not_called()

    # Exige que o clipboard receba exatamente o texto e a unidade dos widgets simulados.
    def test_09_copia_usa_somente_valor_ja_exibido(self):
        raiz = Mock()
        peso = Mock()
        peso.cget.return_value = "12.340"
        unidade = Mock()
        unidade.cget.return_value = "kg"
        janela = self.janela(
            root=raiz,
            label_peso=peso,
            label_tara=Mock(),
            label_unidade=unidade,
        )
        self.assertTrue(JanelaTC420.copiar_medicao(janela, "peso"))
        raiz.clipboard_clear.assert_called_once_with()
        raiz.clipboard_append.assert_called_once_with("12.340 kg")

    # Confere a existência dos arquivos de imagem resolvidos pelo caminho de assets.
    def test_10_assets_solicitados_sao_resolvidos(self):
        self.assertTrue(Path(_caminho_asset("copiar-48x48.png")).is_file())
        self.assertTrue(Path(_caminho_asset("logotc420.png")).is_file())

    # Fixa posição do popup abaixo do botão e exige liberação do grab do menu.
    def test_11_menu_abre_por_popup_explicito(self):
        menu = Mock()
        botao = Mock()
        botao.winfo_rootx.return_value = 10
        botao.winfo_rooty.return_value = 20
        botao.winfo_height.return_value = 30
        janela = SimpleNamespace(menu_opcoes=menu, botao_opcoes=botao)
        JanelaTC420.abrir_menu_opcoes(janela)
        menu.tk_popup.assert_called_once_with(10, 50)
        menu.grab_release.assert_called_once_with()

    # Cancela o seletor simulado e verifica o retorno sem gravação de log.
    def test_12_exportacao_cancelada_nao_cria_arquivo(self):
        janela = SimpleNamespace(root=Mock())
        with patch("interface.janela.filedialog.asksaveasfilename", return_value=""):
            self.assertFalse(JanelaTC420.exportar_log(janela))

    # Worker acompanhado grava o retrato retido; somente o callback Tk mostra o resultado.
    def test_13_exportacao_grava_texto_retido_do_terminal(self):
        from interface.ciclo_tk import ciclo
        from interface.saida_aplicacao import SaidaAplicacao
        from test_interface_b3 import Raiz
        janela = JanelaTC420.__new__(JanelaTC420)
        janela.root = Raiz()
        janela.saida_aplicacao = SaidaAplicacao()
        janela.saida_aplicacao.vincular('exportacao-simulada')
        with TemporaryDirectory() as pasta:
            destino = Path(pasta) / "registro.txt"
            with patch("interface.janela.filedialog.asksaveasfilename", return_value=str(destino)), \
                    patch("interface.registro_terminal.obter_exportacao_terminal", return_value={
                        'texto': "linha 1\nlinha 2\n", 'parcial': False}), \
                    patch("interface.janela.messagebox.showinfo"):
                self.assertTrue(JanelaTC420.exportar_log(janela))
                for item in janela.saida_aplicacao._threads:
                    item['thread'].join(2)
                    self.assertFalse(item['thread'].is_alive())
                ciclo(janela).consumir()
            self.assertEqual("linha 1\nlinha 2\n", destino.read_text(encoding="utf-8"))

    # Com stream em memória, exige que terminal e espelho recebam o mesmo conteúdo.
    def test_14_saida_espelhada_preserva_terminal_e_registro(self):
        from interface.registro_terminal import _RegistroTerminal, _SaidaEspelhada
        terminal = StringIO()
        registro = _RegistroTerminal()
        saida = _SaidaEspelhada(terminal, registro)
        saida.write("mensagem\n")
        self.assertEqual("mensagem\n", terminal.getvalue())
        self.assertEqual("mensagem\n", registro.obter_texto())

    # Uma resposta negativa na confirmação não deve chamar o fechamento.
    def test_15_reconfiguracao_cancelada_preserva_execucao(self):
        janela = SimpleNamespace(
            root=Mock(), ao_reconfigurar=Mock(),
            reconfiguracao_solicitada=False, fechar=Mock(),
        )
        with patch("interface.janela.messagebox.askyesno", return_value=False):
            self.assertFalse(JanelaTC420.solicitar_reconfiguracao(janela))
        janela.fechar.assert_not_called()

    # Dois pedidos confirmados devem resultar em apenas uma chamada de fechamento.
    def test_16_reconfiguracao_confirmada_solicita_parada_uma_vez(self):
        janela = SimpleNamespace(
            root=Mock(), ao_reconfigurar=Mock(),
            reconfiguracao_solicitada=False, fechar=Mock(),
        )
        with patch("interface.janela.messagebox.askyesno", return_value=True), \
                patch("builtins.print"):
            self.assertTrue(JanelaTC420.solicitar_reconfiguracao(janela))
            self.assertFalse(JanelaTC420.solicitar_reconfiguracao(janela))
        janela.fechar.assert_called_once_with()

    # Fixa o valor da constante visual pedida para as áreas de leitura do monitor.
    def test_17_cor_de_fundo_solicitada_e_estavel(self):
        self.assertEqual("#8FD33F", COR_FUNDO_MONITOR)


if __name__ == "__main__":
    unittest.main()

"""Transições visuais de disponibilidade, sem Shell ou rede reais."""
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock

from interface.notificacoes import notificar_estado


class NotificacoesVisuais(TestCase):
    def test_tcp_ignora_oscilacao_curta_e_avisa_falha_sustentada_uma_vez(self):
        from unittest.mock import patch
        monitor = self.criar()
        with patch('interface.notificacoes.monotonic', return_value=0) as relogio:
            notificar_estado(monitor, 'tcp_ok')
            notificar_estado(monitor, 'tcp_falha')
            relogio.return_value = 1
            notificar_estado(monitor, 'tcp_falha')
            notificar_estado(monitor, 'tcp_ok')
            self.assertEqual(monitor._bandeja_windows.notificar.call_count, 1)
            relogio.return_value = 3
            notificar_estado(monitor, 'tcp_falha')
            relogio.return_value = 5
            notificar_estado(monitor, 'tcp_falha')
            relogio.return_value = 6
            notificar_estado(monitor, 'tcp_falha')
            self.assertEqual(monitor._bandeja_windows.notificar.call_count, 2)
            self.assertTrue(monitor._bandeja_windows.notificar.call_args.kwargs['erro'])
            notificar_estado(monitor, 'tcp_ok')
            self.assertEqual(monitor._bandeja_windows.notificar.call_count, 3)

    def test_tolerancia_do_aviso_tcp_nao_atrasa_aviso_cliente_https(self):
        from unittest.mock import patch
        monitor = self.criar()
        with patch('interface.notificacoes.monotonic', return_value=0):
            notificar_estado(monitor, 'tcp_ok')
            notificar_estado(monitor, 'tcp_falha')
            notificar_estado(monitor, 'ct_falha')
            self.assertEqual(monitor._bandeja_windows.notificar.call_count, 2)

    def criar(self):
        return SimpleNamespace(_bandeja_windows=Mock(), _conexao_notificada=None)

    def test_inicio_sem_conexao_nao_anuncia_queda(self):
        monitor = self.criar()
        notificar_estado(monitor, 'ct_falha')
        monitor._bandeja_windows.notificar.assert_not_called()

    def test_sucesso_repetido_avisa_uma_vez(self):
        monitor = self.criar()
        for _ in range(10):
            notificar_estado(monitor, 'ct_ok')
        monitor._bandeja_windows.notificar.assert_called_once()

    def test_queda_e_retorno_avisam_uma_vez_por_transicao(self):
        monitor = self.criar()
        for estado in ('ap_ok', 'ap_falha', 'ap_falha', 'ap_encerrado', 'ct_ok', 'ct_ok'):
            notificar_estado(monitor, estado)
        avisos = monitor._bandeja_windows.notificar.call_args_list
        self.assertEqual(len(avisos), 3)
        self.assertTrue(avisos[1].kwargs['erro'])
        self.assertFalse(avisos[2].kwargs.get('erro', False))

    def test_promocao_em_andamento_nao_inventa_queda(self):
        monitor = self.criar()
        notificar_estado(monitor, 'ct_ok')
        notificar_estado(monitor, 'promovendo')
        notificar_estado(monitor, 'ap_ok')
        monitor._bandeja_windows.notificar.assert_called_once()

    def test_sem_bandeja_nao_muda_estado_operacional(self):
        monitor = SimpleNamespace(executando=True)
        notificar_estado(monitor, 'ct_ok')
        self.assertTrue(monitor.executando)

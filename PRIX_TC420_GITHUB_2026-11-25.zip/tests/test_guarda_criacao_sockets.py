# Testes de guarda criacao sockets: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Ensaio de criação/limpeza por ciclo usando apenas sockets simulados."""
import threading
import unittest
from unittest.mock import Mock, patch

from prototipos.guarda_criacao_sockets import FalhaSemAlocacao, RegistroCriacaoExperimental
from rede.servidor import RegistroTrabalhadores


class SocketSimulado:
    def __init__(self):
        self.fechado = False
        self.fechamentos = 0

    def close(self):
        self.fechamentos += 1
        self.fechado = True


# Grupo de 22 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class GuardaCriacaoSockets(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.registro = RegistroCriacaoExperimental(1)

    def fora_lock(self, registro=None):
        registro = self.registro if registro is None else registro
        self.assertTrue(registro.lock.acquire(blocking=False))
        registro.lock.release()

    def fechar(self, sock):
        self.fora_lock()
        sock.close()

    def comprovar(self, sock):
        self.fora_lock()
        return sock.fechado

    def criar(self, alocar=SocketSimulado, preparar=None, publicar=None):
        def alocacao():
            self.fora_lock()
            return alocar()
        def preparacao(sock):
            self.fora_lock()
            if preparar is not None:
                preparar(sock)
        return self.registro.criar_simulado(alocacao, preparacao, self.fechar, self.comprovar, publicar)

    def situacao(self):
        return self.registro.obter_situacao()

    def test_01_normal(self):
        reserva, sock = self.criar()
        self.assertIsInstance(self.registro, RegistroTrabalhadores)
        self.assertEqual(reserva.ciclo_id, 1)
        self.assertIsNotNone(sock)
        self.assertEqual(self.situacao()["criacoes"][0]["estado"], "publicada")
        self.assertFalse(self.registro.encerramento_confirmado())
        self.assertTrue(self.registro.limpar_simulado(self.fechar, self.comprovar))

    def test_02_apos_bloqueio(self):
        self.registro.bloquear_criacao()
        alocar = Mock()
        self.assertEqual(self.criar(alocar), (None, None))
        alocar.assert_not_called()

    def test_03_reservada_antes_bloqueio(self):
        def preparar(sock):
            self.registro.bloquear_criacao()
            self.assertEqual(self.situacao()["criacoes_pendentes"], 1)
            self.assertFalse(self.registro.encerramento_confirmado())
        reserva, resultado = self.criar(preparar=preparar)
        self.assertIsNone(resultado)
        self.assertEqual(self.situacao()["criacoes"][0]["criacao_id"], reserva.criacao_id)
        self.assertTrue(self.registro.encerramento_confirmado())

    def test_04_falha_sem_alocacao(self):
        reserva, resultado = self.criar(Mock(side_effect=FalhaSemAlocacao()))
        self.assertIsNotNone(reserva)
        self.assertIsNone(resultado)
        entrada, = self.situacao()["criacoes"]
        self.assertEqual(entrada["estado"], "sem_recurso")
        self.assertFalse(entrada["criacao_pendente"])
        self.registro.bloquear_criacao()
        self.assertTrue(self.registro.encerramento_confirmado())

    def test_05_falha_registro(self):
        for metodo in ("_anexar_alocacao", "_publicar"):
            with self.subTest(metodo=metodo):
                self.registro = RegistroCriacaoExperimental(1)
                sock = SocketSimulado()
                with patch.object(self.registro, metodo, side_effect=RuntimeError()):
                    reserva, resultado = self.criar(lambda: sock)
                self.assertIsNone(resultado)
                self.assertTrue(sock.fechado)
                entrada, = self.situacao()["criacoes"]
                self.assertEqual(entrada["criacao_id"], reserva.criacao_id)
                self.assertTrue(entrada["recurso_presente"])
                self.assertEqual(entrada["erro"], "falha_criacao_com_recurso")

    def test_06_limpeza_durante_criacao(self):
        sock = SocketSimulado()
        def preparar(recurso):
            self.assertFalse(self.registro.limpar_simulado(self.fechar, self.comprovar))
            self.assertFalse(recurso.fechado)
        self.criar(lambda: sock, preparar)
        self.assertTrue(sock.fechado)
        self.assertTrue(self.registro.encerramento_confirmado())

    def threads(self, funcoes):
        erros = []
        def executar(funcao):
            try:
                funcao()
            except BaseException as erro:
                erros.append(erro)
        threads = [threading.Thread(target=executar, args=(f,)) for f in funcoes]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(5)
            self.assertFalse(thread.is_alive())
        if erros:
            raise erros[0]

    def test_07_criacoes_simultaneas(self):
        barreira = threading.Barrier(2, timeout=5)
        def preparar(sock):
            barreira.wait()
        self.threads([lambda: self.criar(preparar=preparar)] * 2)
        entradas = self.situacao()["criacoes"]
        self.assertEqual(len({e["criacao_id"] for e in entradas}), 2)
        self.assertTrue(self.registro.limpar_simulado(self.fechar, self.comprovar))

    def test_08_ciclos_distintos(self):
        reserva_a, sock_a = self.criar()
        b = RegistroCriacaoExperimental(2)
        reserva_b, sock_b = b.criar_simulado(SocketSimulado, lambda s: None,
                                            lambda s: s.close(), lambda s: s.fechado)
        self.assertFalse(b.limpar_recurso_simulado(reserva_a, lambda s: s.close(), lambda s: s.fechado))
        self.assertFalse(self.registro.limpar_recurso_simulado(reserva_b, self.fechar, self.comprovar))
        self.registro.limpar_simulado(self.fechar, self.comprovar)
        self.assertTrue(sock_a.fechado)
        self.assertFalse(sock_b.fechado)
        self.assertEqual(b.obter_situacao()["ciclo_id"], 2)

    def test_09_a_encerrando_b_iniciando(self):
        b = RegistroCriacaoExperimental(2)
        barreira = threading.Barrier(2, timeout=5)
        resultado_b = []
        def preparar_a(sock):
            barreira.wait()
            self.assertFalse(self.registro.limpar_simulado(self.fechar, self.comprovar))
            barreira.wait()
        def criar_b():
            barreira.wait()
            resultado_b.append(b.criar_simulado(SocketSimulado, lambda s: None,
                                                lambda s: s.close(), lambda s: s.fechado))
            barreira.wait()
        self.threads([lambda: self.criar(preparar=preparar_a), criar_b])
        self.assertTrue(self.registro.encerramento_confirmado())
        self.assertFalse(resultado_b[0][1].fechado)
        self.assertFalse(b.obter_situacao()["criacao_bloqueada"])

    def test_10_erro_fechamento_preservado(self):
        reserva, sock = self.criar()
        def falhar(recurso):
            self.fora_lock()
            raise OSError("texto descartado")
        self.assertFalse(self.registro.limpar_simulado(falhar, self.comprovar))
        self.assertFalse(sock.fechado)
        self.assertEqual(self.situacao()["erros_limpeza"], ["falha_limpeza_recurso"])
        self.assertFalse(self.registro.limpar_simulado(self.fechar, self.comprovar))
        self.assertEqual(self.situacao()["erros_limpeza"], ["falha_limpeza_recurso"])

    def test_11_fechado_anteriormente(self):
        _, sock = self.criar()
        sock.close()
        self.assertTrue(self.registro.limpar_simulado(self.fechar, self.comprovar))
        self.assertEqual(sock.fechamentos, 1)

    def test_12_limpeza_repetida(self):
        _, sock = self.criar()
        for _ in range(3):
            self.assertTrue(self.registro.limpar_simulado(self.fechar, self.comprovar))
        self.assertEqual(sock.fechamentos, 1)

    def test_13_criacao_parcial(self):
        sock = SocketSimulado()
        self.criar(lambda: sock, Mock(side_effect=RuntimeError()))
        self.assertTrue(sock.fechado)
        self.assertEqual(self.situacao()["criacoes"][0]["erro"], "falha_criacao_com_recurso")

    def test_14_publicacao_tardia(self):
        sock = SocketSimulado()
        def publicar(recurso):
            self.fora_lock()
            self.registro.bloquear_criacao()
        _, resultado = self.criar(lambda: sock, publicar=publicar)
        self.assertIsNone(resultado)
        self.assertTrue(sock.fechado)

    def test_15_consulta_durante_criacao(self):
        def preparar(sock):
            situacao = self.situacao()
            self.assertEqual((situacao["criacoes_pendentes"], situacao["recursos_pendentes"]), (1, 1))
            self.assertEqual(situacao["criacoes"][0]["estado"], "alocada")
            self.assertTrue(situacao["criacoes"][0]["recurso_presente"])
        self.criar(preparar=preparar)

    def test_16_falha_apos_publicacao(self):
        reserva, sock = self.criar()
        try:
            raise RuntimeError("erro do consumidor simulado")
        except RuntimeError:
            pass
        self.assertEqual(self.situacao()["criacoes"][0]["criacao_id"], reserva.criacao_id)
        self.assertTrue(self.registro.limpar_simulado(self.fechar, self.comprovar))
        self.assertTrue(sock.fechado)
        self.registro = RegistroCriacaoExperimental(1)
        sock = SocketSimulado()
        publicar_original = self.registro._publicar
        def publicar_e_falhar(reserva):
            publicar_original(reserva)
            raise RuntimeError()
        with patch.object(self.registro, "_publicar", side_effect=publicar_e_falhar):
            self.criar(lambda: sock)
        self.assertTrue(sock.fechado)
        self.assertTrue(self.situacao()["criacoes"][0]["recurso_presente"])

    def test_17_critico_publicacao_tardia_barreiras(self):
        pronta = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        criada = threading.Barrier(2, timeout=5)
        sock = SocketSimulado()
        def preparar(recurso):
            pronta.wait()
            liberar.wait()
        def produzir():
            self.criar(lambda: sock, preparar)
            criada.wait()
        def encerrar():
            pronta.wait()
            self.assertFalse(self.registro.limpar_simulado(self.fechar, self.comprovar))
            self.assertEqual(self.situacao()["criacoes_pendentes"], 1)
            self.assertEqual(self.criar(), (None, None))
            self.assertFalse(sock.fechado)
            liberar.wait()
            criada.wait()
            self.assertTrue(sock.fechado)
            self.assertTrue(self.registro.encerramento_confirmado())
        self.threads([produzir, encerrar])

    def test_18_critico_falha_parcial(self):
        for falha_limpeza in (False, True):
            with self.subTest(falha_limpeza=falha_limpeza):
                self.registro = RegistroCriacaoExperimental(1)
                sock = SocketSimulado()
                def preparar(recurso):
                    raise RuntimeError()
                def fechar(recurso):
                    if falha_limpeza:
                        raise OSError()
                    recurso.close()
                self.registro.criar_simulado(lambda: sock, preparar, fechar, self.comprovar)
                self.registro.bloquear_criacao()
                self.assertEqual(self.registro.encerramento_confirmado(), not falha_limpeza)
                self.assertEqual(sock.fechado, not falha_limpeza)
                self.assertEqual(self.situacao()["recursos_pendentes"], int(falha_limpeza))

    def test_19_alocador_opaco_que_falha(self):
        retidos = []
        def alocar():
            retidos.append(SocketSimulado())
            raise RuntimeError()
        self.criar(alocar)
        self.registro.bloquear_criacao()
        self.assertFalse(self.registro.encerramento_confirmado())
        entrada, = self.situacao()["criacoes"]
        self.assertEqual(entrada["estado"], "criacao_incerta")
        self.assertTrue(entrada["criacao_pendente"])
        self.assertFalse(retidos[0].fechado)

    def test_20_fechar_nao_comprova_liberacao(self):
        self.criar()
        self.assertFalse(self.registro.limpar_simulado(lambda s: None, self.comprovar))
        self.assertFalse(self.registro.encerramento_confirmado())

    def test_21_limpezas_simultaneas(self):
        _, sock = self.criar()
        fechando = threading.Barrier(2, timeout=5)
        liberar = threading.Barrier(2, timeout=5)
        resultados = []
        def fechar(recurso):
            self.fora_lock()
            fechando.wait()
            liberar.wait()
            recurso.close()
        def primeira():
            resultados.append(self.registro.limpar_simulado(fechar, self.comprovar))
        def segunda():
            fechando.wait()
            self.assertFalse(self.registro.limpar_simulado(self.fechar, self.comprovar))
            self.assertFalse(self.registro.encerramento_confirmado())
            liberar.wait()
        self.threads([primeira, segunda])
        self.assertEqual(resultados, [True])
        self.assertEqual(sock.fechamentos, 1)

    def test_22_workers_e_gate_existentes_preservados(self):
        liberar = threading.Event()
        worker = threading.Thread(target=lambda: liberar.wait(3))
        try:
            self.assertTrue(self.registro.registrar_e_iniciar(worker))
            self.assertFalse(self.registro.limpar_simulado(self.fechar, self.comprovar))
            self.assertFalse(self.registro.registrar_e_iniciar(
                threading.Thread(target=lambda: None)))
        finally:
            liberar.set()
            if worker.ident is not None:
                worker.join(3)
                self.assertFalse(worker.is_alive())
        self.assertTrue(self.registro.encerramento_confirmado())


if __name__ == "__main__":
    unittest.main()

# Testes de coerencia temporal cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-D3-B1: modelo temporal isolado, interleavings e limites de cobertura."""
import ast
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
import threading
import unittest
from unittest.mock import Mock, patch

from prototipos.coerencia_temporal_cliente import (
    InventarioTemporalExperimental, RegistroTemporalExperimental,
    avaliar_coerencia_experimental,
)
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from test_descoberta_cliente_integrada import SocketDescobertaFalso


# Grupo de 41 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class CoerenciaTemporalCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.catalogo = InventarioTemporalExperimental()
        self.catalogo.nova_geracao(1)
        self.fontes = {}
        for nome in ('permanentes', 'retentativas', 'register', 'config', 'subscribe',
                     'descoberta', 'check_leitor', 'check_recuperacao', 'associacoes',
                     'recursos', 'http', 'arquivos', 'preparacoes'):
            fonte = self.nova_fonte()
            self.catalogo.incluir(nome, fonte)
            self.fontes[nome] = fonte

    def nova_fonte(self):
        return RegistroTemporalExperimental(self.catalogo.aplicacao_id, pendentes=0)

    def avaliar(self):
        r = avaliar_coerencia_experimental(self.catalogo)
        self.assertFalse(r['encerramento_cliente_confirmado'])
        self.assertFalse(r['encerramento_global_confirmado'])
        self.assertFalse(r['snapshot_atomico'])
        self.assertEqual('incompleta', r['cobertura_operacional'])
        return r

    def durante(self, acao, nome='permanentes'):
        fonte = self.fontes[nome]
        ler = fonte.ler_evidencia
        def consulta():
            dado = ler()
            acao()
            return dado
        with patch.object(fonte, 'ler_evidencia', side_effect=consulta):
            return self.avaliar()

    def aba(self, nome):
        fonte = self.fontes[nome]
        antes = fonte.ler_evidencia()['conteudo']
        fonte.publicar(pendentes=1)
        fonte.publicar(pendentes=0)
        self.assertEqual(antes, fonte.ler_evidencia()['conteudo'])

    def alterado(self, r, inventario=False):
        self.assertEqual('alterado', r['estado_temporal'])
        self.assertFalse(r['coerencia_validada'])
        self.assertIn('inventario_alterado' if inventario else 'fontes_alteradas', r['pendencias'])

    def desconhecido(self, r):
        self.assertEqual('desconhecido', r['estado_temporal'])
        self.assertFalse(r['coerencia_validada'])
        self.assertIn('revisao_ou_consulta_inconfiavel', r['pendencias'])

    def test_01_sem_alteracao(self):
        antes = {n: f.ler_evidencia() for n, f in self.fontes.items()}
        a, b = self.avaliar(), self.avaliar()
        self.assertTrue(a['coerencia_validada'])
        self.assertEqual(a, b)
        self.assertEqual(a['revisoes_antes'], a['revisoes_depois'])
        self.assertEqual(antes, {n: f.ler_evidencia() for n, f in self.fontes.items()})

    def test_02_admissao_intermediaria(self):
        self.alterado(self.durante(lambda: self.fontes['register'].publicar(pendentes=1)))

    def test_03_admissao_e_conclusao_ABA(self):
        r = self.durante(lambda: self.aba('subscribe'))
        self.alterado(r)
        ident = self.fontes['subscribe'].instancia_id
        self.assertEqual(0, r['revisoes_antes'][ident])
        self.assertEqual(2, r['revisoes_depois'][ident])

    def test_04_criacao_limpeza_recurso(self):
        self.alterado(self.durante(lambda: self.aba('recursos')))

    def test_05_thread_entra_retorna(self):
        self.alterado(self.durante(lambda: self.aba('permanentes'), nome='associacoes'))

    def test_06_observacao_explicita(self):
        fonte = self.fontes['retentativas']
        r = self.durante(lambda: fonte.publicar(termino_observado=True))
        self.alterado(r)
        self.assertEqual(1, fonte.ler_revisao()['revisao'])

    def test_07_publicacao_HTTP(self):
        self.alterado(self.durante(lambda: self.fontes['http'].publicar(publicacao_resolvida=True)))

    def test_08_retencao_AC1F1(self):
        fonte = self.fontes['arquivos']
        fonte.publicar(handle_retido=True)
        self.alterado(self.durante(lambda: fonte.publicar(handle_retido=False)))

    def test_09_preparacao_antes_UDP(self):
        self.alterado(self.durante(lambda: self.fontes['preparacoes'].publicar(pendentes=1)))
        self.assertEqual(0, self.fontes['recursos'].ler_revisao()['revisao'])

    def test_10_preparacao_inicia_termina_ABA(self):
        self.alterado(self.durante(lambda: self.aba('preparacoes')))

    def test_11_promocao_revalida_inventario(self):
        identidade = self.fontes['register'].instancia_id
        self.alterado(self.durante(lambda: self.catalogo.promover(1)), inventario=True)
        self.assertEqual(identidade, self.fontes['register'].instancia_id)
        self.assertEqual(((1, 'principal'),), self.catalogo.ler_inventario()['geracoes'])

    def test_12_nova_geracao(self):
        self.alterado(self.durante(lambda: self.catalogo.nova_geracao(2)), inventario=True)

    def test_13_geracao_antiga_muda(self):
        antiga = self.fontes['config']
        self.catalogo.nova_geracao(2)
        self.catalogo.incluir('config_B', self.nova_fonte())
        self.catalogo.promover(1)
        r = self.durante(lambda: antiga.publicar(pendentes=1))
        self.alterado(r)
        self.assertIn(antiga.instancia_id, r['revisoes_depois'])

    def test_14_publicacao_falha(self):
        fonte = self.fontes['http']
        with patch.object(fonte, '_publicar_revisao', side_effect=OSError('publicacao_simulada')):
            with self.assertRaises(OSError):
                fonte.publicar(pendentes=1)
        self.desconhecido(self.avaliar())
        self.assertEqual(1, fonte.ler_evidencia()['conteudo']['pendentes'])
        self.assertEqual(0, fonte.ler_revisao()['revisao'])

    def test_15_registro_real_sem_revisao(self):
        infra = InfraestruturaRegistrosCliente()
        fonte = SimpleNamespace(aplicacao_id=self.catalogo.aplicacao_id, instancia_id='sem-revisao',
                                ler_revisao=infra.registro_recursos.obter_retrato)
        self.catalogo.incluir('recurso_real_nao_adaptado', fonte)
        self.desconhecido(self.avaliar())

    def test_16_consulta_passiva(self):
        inventario = self.catalogo.ler_inventario()
        estados = {n: f.ler_evidencia() for n, f in self.fontes.items()}
        with ExitStack() as pilha:
            proibidos = [pilha.enter_context(patch.object(f, 'publicar', side_effect=AssertionError()))
                         for f in self.fontes.values()]
            proibidos += [pilha.enter_context(patch.object(self.catalogo, nome, side_effect=AssertionError()))
                          for nome in ('incluir', 'nova_geracao', 'promover')]
            revisoes = [pilha.enter_context(patch.object(f, 'ler_revisao', wraps=f.ler_revisao))
                        for f in self.fontes.values()]
            conteudos = [pilha.enter_context(patch.object(f, 'ler_evidencia', wraps=f.ler_evidencia))
                         for f in self.fontes.values()]
            self.assertTrue(self.avaliar()['coerencia_validada'])
            self.assertTrue(all(p.call_count == 0 for p in proibidos))
            self.assertTrue(all(p.call_count == 2 for p in revisoes))
            self.assertTrue(all(p.call_count == 1 for p in conteudos))
        self.assertEqual(inventario, self.catalogo.ler_inventario())
        self.assertEqual(estados, {n: f.ler_evidencia() for n, f in self.fontes.items()})

    def test_critica_A_ABA_admissoes_por_origem(self):
        for nome in ('register', 'config', 'subscribe', 'descoberta', 'check_leitor', 'check_recuperacao'):
            with self.subTest(nome=nome):
                self.alterado(self.durante(lambda: self.aba(nome)))

    def test_critica_B_ABA_recursos_sem_novo_ID_como_revisao(self):
        fonte = self.fontes['recursos']
        antes = fonte.instancia_id
        self.alterado(self.durante(lambda: self.aba('recursos')))
        self.assertEqual(antes, fonte.instancia_id)
        self.assertEqual(2, fonte.ler_revisao()['revisao'])

    def test_critica_C_preparacao_pendente_sem_socket(self):
        antes = self.fontes['recursos'].ler_evidencia()
        r = self.durante(lambda: self.fontes['preparacoes'].publicar(pendentes=1))
        self.alterado(r)
        self.assertEqual(antes, self.fontes['recursos'].ler_evidencia())

    def test_critica_D_nova_geracao_fonte_inventariada(self):
        fonte = self.nova_fonte()
        def mudar():
            self.catalogo.nova_geracao(2)
            self.catalogo.incluir('subscribe_B', fonte)
            fonte.publicar(pendentes=1)
        self.alterado(self.durante(mudar), inventario=True)
        seguinte = self.avaliar()
        self.assertTrue(seguinte['coerencia_validada'])
        self.assertEqual(1, seguinte['evidencias'][fonte.instancia_id]['conteudo']['pendentes'])

    def test_critica_E_estado_muda_revisao_falha(self):
        fonte = self.fontes['preparacoes']
        def falhar():
            with patch.object(fonte, '_publicar_revisao', side_effect=OSError()):
                with self.assertRaises(OSError):
                    fonte.publicar(pendentes=1)
        self.desconhecido(self.durante(falhar))
        self.assertFalse(fonte.ler_revisao()['confiavel'])
        # Uma publicacao posterior nao apaga a incerteza anterior.
        fonte.publicar(pendentes=0)
        self.desconhecido(self.avaliar())

    def test_critica_F_dois_registros_concorrentes_sem_lock_global(self):
        iniciar, a_feita, b_feita = threading.Event(), threading.Event(), threading.Event()
        erros = []
        def escritor(nome, evento, estado):
            try:
                if not iniciar.wait(3):
                    raise TimeoutError('barreira_simulada')
                self.fontes[nome].publicar(**estado)
                evento.set()
            except BaseException as erro:
                erros.append(erro)
        a = threading.Thread(target=escritor, args=('register', a_feita, {'pendentes': 1}))
        b = threading.Thread(target=escritor, args=('recursos', b_feita, {'limpeza_comprovada': True}))
        a.start()
        b.start()
        def durante():
            # O avaliador nao segura o inventario nem os locks de outros registros.
            for lock in (self.catalogo._lock, self.fontes['register']._lock, self.fontes['recursos']._lock):
                self.assertTrue(lock.acquire(blocking=False))
                lock.release()
            iniciar.set()
            self.assertTrue(a_feita.wait(3))
            self.assertTrue(b_feita.wait(3))
        try:
            r = self.durante(durante)
        finally:
            iniciar.set()
            a.join(3)
            b.join(3)
        self.assertFalse(a.is_alive() or b.is_alive())
        self.assertEqual([], erros)
        self.alterado(r)
        for nome in ('register', 'recursos'):
            ident = self.fontes[nome].instancia_id
            self.assertGreater(r['revisoes_depois'][ident], r['revisoes_antes'][ident])

    def test_critica_G_igualdade_com_caminho_fora_cobertura(self):
        fora_do_inventario = self.nova_fonte()
        fora_do_inventario.publicar(pendentes=1)
        r = self.avaliar()
        self.assertTrue(r['coerencia_validada'])
        self.assertNotIn(fora_do_inventario.instancia_id, r['evidencias'])
        self.assertIn('cobertura_nao_demonstrada', r['pendencias'])
        self.assertFalse(r['encerramento_cliente_confirmado'])

    def test_ABA_real_uso_de_recurso_continua_sem_revisao_operacional(self):
        infra = InfraestruturaRegistrosCliente()
        dono = infra.preparar_descoberta()
        cliente = dono.abrir_socket(SocketDescobertaFalso)
        self.addCleanup(cliente.close)
        registro = infra.registro_recursos
        antes = registro.obter_retrato()
        usos = []
        registro.usar(cliente.recurso_id, lambda obj: usos.append(
            registro.obter_retrato()['recursos'][0]['usos']), fechar_ao_sair=False)
        self.assertEqual([1], usos)
        self.assertEqual(antes, registro.obter_retrato())
        self.assertNotIn('revisao', antes)

    def test_geracao_real_nao_e_revisao_temporal(self):
        infra = InfraestruturaRegistrosCliente()
        antes = infra.registro_retentativas.obter_retrato()
        geracao = infra.registro_retentativas.nova_geracao_cliente()
        self.assertIsNotNone(geracao)
        self.assertEqual(antes, infra.registro_retentativas.obter_retrato())

    def test_substituicao_mesma_revisao_inicial_detectada(self):
        antigo = self.fontes['http']
        novo = self.nova_fonte()
        self.assertEqual(antigo.ler_revisao()['revisao'], novo.ler_revisao()['revisao'])
        self.alterado(self.durante(lambda: self.catalogo.incluir('http', novo, substituir=True)), inventario=True)
        r = self.avaliar()
        self.assertIn(antigo.instancia_id, r['evidencias'])
        self.assertIn(novo.instancia_id, r['evidencias'])

    def test_fonte_substituida_antiga_ainda_observada(self):
        antigo = self.fontes['http']
        self.catalogo.incluir('http', self.nova_fonte(), substituir=True)
        r = self.durante(lambda: antigo.publicar(pendentes=1))
        self.alterado(r)
        self.assertIn(antigo.instancia_id, r['revisoes_depois'])

    def test_falha_publicacao_inventario(self):
        nova = self.nova_fonte()
        with patch.object(self.catalogo, '_publicar_revisao', side_effect=OSError()):
            with self.assertRaises(OSError):
                self.catalogo.incluir('nova', nova)
        self.desconhecido(self.avaliar())

    def test_publicacao_silenciosa_sem_incremento_recusada(self):
        fonte = self.fontes['http']
        with patch.object(fonte, '_publicar_revisao', return_value=None):
            with self.assertRaisesRegex(RuntimeError, 'revisao_nao_publicada'):
                fonte.publicar(pendentes=1)
        self.desconhecido(self.avaliar())

    def test_revisao_regredida_desconhecida(self):
        fonte = self.fontes['http']
        fonte.publicar(pendentes=1)
        revisao = fonte.ler_revisao()
        antiga = revisao | {'revisao': 0}
        with patch.object(fonte, 'ler_revisao', side_effect=[revisao, antiga]):
            self.desconhecido(self.avaliar())

    def test_revisao_booleana_nao_e_inteiro_valido(self):
        fonte = self.fontes['http']
        dado = fonte.ler_revisao() | {'revisao': True}
        with patch.object(fonte, 'ler_revisao', return_value=dado):
            self.desconhecido(self.avaliar())

    def test_conteudo_e_revisao_cruzados(self):
        fonte = self.fontes['http']
        def consulta():
            dado = fonte.ler_revisao() | {'conteudo': {'pendentes': 0}}
            dado['revisao'] = 2
            return dado
        with patch.object(fonte, 'ler_evidencia', side_effect=consulta):
            self.desconhecido(self.avaliar())

    def test_falha_consulta_nao_expoe_erro(self):
        with patch.object(self.fontes['http'], 'ler_evidencia', side_effect=RuntimeError('conteudo_simulado')):
            r = self.avaliar()
        self.desconhecido(r)
        self.assertNotIn('conteudo_simulado', str(r))
        self.assertEqual({}, r['evidencias'])

    def test_sem_reset_na_promocao(self):
        fonte = self.fontes['register']
        fonte.publicar(pendentes=1)
        antes = fonte.ler_revisao()
        self.catalogo.promover(1)
        self.assertEqual(antes, fonte.ler_revisao())
        with self.assertRaises(AttributeError):
            fonte.instancia_id = 'outra'

    def test_terceiro_valor_da_revisao_evidencia_nao_ignorado(self):
        fonte = self.fontes['http']
        revisar = fonte.ler_revisao
        chamadas = []
        def primeira():
            dado = revisar()
            if not chamadas:
                fonte.publicar(pendentes=1)
            chamadas.append(True)
            return dado
        with patch.object(fonte, 'ler_revisao', side_effect=primeira):
            self.alterado(self.avaliar())

    def test_vazio_estavel_nao_comprova_cobertura(self):
        self.catalogo = InventarioTemporalExperimental()
        r = self.avaliar()
        self.assertTrue(r['coerencia_validada'])
        self.assertEqual({}, r['evidencias'])

    def test_mudanca_apos_ultimo_selo_limite_da_garantia(self):
        fonte = self.fontes['preparacoes']
        ler = fonte.ler_revisao
        chamadas = []
        def consulta():
            dado = ler()
            chamadas.append(True)
            if len(chamadas) == 2:
                fonte.publicar(pendentes=1)
            return dado
        with patch.object(fonte, 'ler_revisao', side_effect=consulta):
            r = self.avaliar()
        self.assertTrue(r['coerencia_validada'])
        self.assertEqual(0, r['evidencias'][fonte.instancia_id]['conteudo']['pendentes'])
        self.assertEqual(1, fonte.ler_evidencia()['conteudo']['pendentes'])
        self.assertFalse(r['encerramento_cliente_confirmado'])

    def test_consulta_nao_tem_espera_observacao_ou_limpeza(self):
        caminho = Path(__file__).resolve().parents[1] / 'prototipos/coerencia_temporal_cliente.py'
        arvore = ast.parse(caminho.read_text(encoding='utf-8'))
        funcao = next(n for n in arvore.body if isinstance(n, ast.FunctionDef)
                      and n.name == 'avaliar_coerencia_experimental')
        proibidos = {'sleep', 'join', 'parar', 'fechar', 'fechar_admissao', 'is_alive',
                     'observar_termino_leitores', 'observar_termino_retentativas', 'after_cancel'}
        chamadas = {n.func.attr for n in ast.walk(funcao)
                    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
        self.assertFalse(chamadas & proibidos)

    def test_mudanca_antes_primeiro_selo_fora_intervalo(self):
        ler = self.catalogo.ler_inventario
        chamadas = []
        def inventario():
            dado = ler()
            if not chamadas:
                self.aba('preparacoes')
            chamadas.append(True)
            return dado
        with patch.object(self.catalogo, 'ler_inventario', side_effect=inventario):
            r = self.avaliar()
        self.assertTrue(r['coerencia_validada'])
        ident = self.fontes['preparacoes'].instancia_id
        self.assertEqual(2, r['revisoes_antes'][ident])
        self.assertEqual(2, r['revisoes_depois'][ident])

    def test_revisao_nao_recicla_mesmo_em_inteiros_grandes(self):
        fonte = RegistroTemporalExperimental(self.catalogo.aplicacao_id, revisao=2**64)
        fonte.publicar(pendentes=1)
        fonte.publicar(pendentes=0)
        self.assertEqual(2**64 + 2, fonte.ler_revisao()['revisao'])

    def test_vetores_independentes_sem_contador_global_de_eventos(self):
        inventario = self.catalogo.ler_revisao()
        outro = self.fontes['recursos'].ler_revisao()
        self.fontes['http'].publicar(publicacao_resolvida=True)
        self.assertEqual(inventario, self.catalogo.ler_revisao())
        self.assertEqual(outro, self.fontes['recursos'].ler_revisao())
        self.assertEqual(1, self.fontes['http'].ler_revisao()['revisao'])


if __name__ == '__main__':
    unittest.main()

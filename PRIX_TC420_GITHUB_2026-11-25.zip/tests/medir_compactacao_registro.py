"""Carga sintética sem rede: memória retida e custo temporário do diagnóstico."""
import gc
import json
from pathlib import Path
import platform
import sys
import time
import tracemalloc

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rede.servidor import RegistroTrabalhadores


def medir(total=50000):
    gc.collect()
    tracemalloc.start()
    inicio = time.perf_counter()
    registro = RegistroTrabalhadores()
    for _ in range(total):
        token = registro.reservar_criacao_socket()
        registro.resolver_falha_criacao_socket(token, sem_alocacao_comprovada=True)
    del token
    gc.collect()
    atual, pico = tracemalloc.get_traced_memory()
    duracao = time.perf_counter() - inicio
    tracemalloc.reset_peak()
    inicio_consulta = time.perf_counter()
    diagnostico = registro.obter_situacao()
    consulta_segundos = time.perf_counter() - inicio_consulta
    _, pico_consulta = tracemalloc.get_traced_memory()
    resultado = dict(python=platform.python_version(), plataforma=sys.platform,
        reservas_resolvidas=total, entradas_retidas=len(registro._reservas_socket),
        referencias_threads=len(registro.threads),
        handles_retidos=sum(e.recurso is not None for e in registro._reservas_socket.values()),
        bytes_python_atual=atual, bytes_python_pico=pico, segundos=duracao,
        consulta_segundos=consulta_segundos, consulta_pico_bytes=pico_consulta,
        diagnosticos=len(diagnostico['criacoes_socket']),
        sockets_encerrados=diagnostico['sockets_encerrados'])
    tracemalloc.stop()
    return resultado


if __name__ == '__main__':
    print(json.dumps(medir(), indent=2))

# Testes de inventario recursos: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Inventário isolado e auditoria executável, sem sockets/HTTP reais ou Tk."""
import threading
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from prototipos.inventario_recursos import InventarioRecursosExperimental, PROVAS_POR_TIPO
from rede import servidor


# Grupo de 18 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class InventarioRecursos(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.inventario = InventarioRecursosExperimental()

    def recurso(self, tipo="tcp_escuta", ciclo=1, tentativa=1, dono="worker_simulado", hipotetico=False):
        chave = self.inventario.reservar(tipo, ciclo_id=ciclo, tentativa_id=tentativa,
                                         proprietario=dono, hipotetico=hipotetico)
        self.inventario.publicar_criacao(chave)
        return chave

    def entrada(self, chave):
        return next(r for r in self.inventario.obter_retrato()["recursos"] if r.recurso_id == chave)

    def confirmar(self, chave):
        tipo = self.entrada(chave).tipo
        return self.inventario.registrar_evidencias(chave, **dict.fromkeys(PROVAS_POR_TIPO[tipo], True))

    def test_01_criado_a(self):
        chave = self.recurso()
        self.assertEqual(self.entrada(chave).ciclo_id, 1)

    def test_02_criado_b(self):
        self.recurso()
        chave = self.recurso(ciclo=2, tentativa=2)
        self.assertEqual((self.entrada(chave).ciclo_id, self.entrada(chave).tentativa_id), (2, 2))

    def test_03_antigo_ativo(self):
        antigo = self.recurso()
        self.recurso(ciclo=2, tentativa=2)
        self.assertEqual(self.entrada(antigo).estado, "ativo")
        self.assertIn(antigo, self.inventario.obter_retrato()["pendencias"])

    def test_04_solicitada_nao_confirma(self):
        chave = self.recurso()
        self.inventario.registrar_limpeza_solicitada(chave)
        self.assertEqual(self.entrada(chave).estado, "limpeza_solicitada")
        self.assertFalse(self.inventario.obter_retrato()["todos_recursos_observados_encerrados"])

    def test_05_evidencia_completa(self):
        chave = self.recurso()
        self.assertTrue(self.confirmar(chave))
        self.assertEqual(self.entrada(chave).estado, "encerramento_confirmado")

    def test_06_excecao_limpeza(self):
        chave = self.recurso()
        self.inventario.registrar_erro_limpeza(chave)
        self.assertFalse(self.confirmar(chave))
        self.assertEqual(self.entrada(chave).estado, "desconhecido")

    def test_07_desconhecido(self):
        chave = self.inventario.reservar("udp_descoberta", ciclo_id=1, tentativa_id=1,
                                        proprietario="criador_simulado")
        self.assertEqual(self.entrada(chave).estado, "desconhecido")
        self.assertFalse(self.confirmar(chave))

    def test_08_mesmo_tipo_ids_distintos(self):
        a, b = self.recurso(), self.recurso()
        self.assertNotEqual(a, b)
        self.confirmar(b)
        self.assertEqual(self.entrada(a).estado, "ativo")

    def test_09_http_servidor_hipotetico(self):
        antigo = self.recurso("http_servidor", hipotetico=True)
        self.recurso(ciclo=2, tentativa=2)
        provas = dict.fromkeys(PROVAS_POR_TIPO["http_servidor"], True)
        provas["server_close_retornou"] = False
        self.assertFalse(self.inventario.registrar_evidencias(antigo, **provas))
        self.assertTrue(self.entrada(antigo).hipotetico)
        self.assertTrue(self.confirmar(antigo))

    def test_10_sessao_cliente_hipotetica_distinta(self):
        servidor_http = self.recurso("http_servidor", hipotetico=True)
        cliente_http = self.recurso("http_sessao_cliente", hipotetico=True)
        self.assertNotEqual(self.entrada(servidor_http).tipo, self.entrada(cliente_http).tipo)
        self.assertNotEqual(servidor_http, cliente_http)

    def test_11_socket_fechado_exige_operacoes(self):
        chave = self.recurso("tcp_handler_socket")
        self.assertFalse(self.inventario.registrar_evidencias(
            chave, fechamento_retornou=True, referencias_liberadas=True, operacoes_encerradas=False))
        self.assertTrue(self.confirmar(chave))

    def test_12_handler_ativo(self):
        chave = self.recurso("handler_thread")
        self.assertFalse(self.inventario.registrar_evidencias(
            chave, thread_terminou=False, recursos_filhos_resolvidos=True))
        self.assertFalse(self.inventario.registrar_evidencias(
            chave, thread_terminou=True, recursos_filhos_resolvidos=False))

    def test_13_sem_dono(self):
        for campo in ("ciclo", "tentativa", "dono"):
            with self.subTest(campo=campo):
                chave = self.recurso(**{campo: None})
                self.assertFalse(self.confirmar(chave))

    def test_14_historico_preservado(self):
        a = self.recurso()
        self.confirmar(a)
        antigo = self.entrada(a)
        self.recurso(ciclo=2, tentativa=2)
        self.assertIs(self.entrada(a), antigo)

    def threads(self, funcoes):
        erros = []
        def executar(funcao):
            try:
                funcao()
            except BaseException as erro:
                erros.append(erro)
        threads = [threading.Thread(target=executar, args=(f,)) for f in funcoes]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(5)
            self.assertFalse(thread.is_alive())
        if erros:
            raise erros[0]

    def test_15_consultas_concorrentes(self):
        barreira = threading.Barrier(2, timeout=5)
        def criar():
            barreira.wait()
            for _ in range(100):
                chave = self.recurso()
                self.confirmar(chave)
        def consultar():
            barreira.wait()
            for _ in range(500):
                retrato = self.inventario.obter_retrato()
                entradas = retrato["recursos"]
                self.assertEqual(len(entradas), len({r.recurso_id for r in entradas}))
                self.assertEqual(retrato["pendencias"], tuple(
                    r.recurso_id for r in entradas if r.estado != "encerramento_confirmado"))
                self.assertTrue(retrato["novas_criacoes_possiveis"])
        self.threads([criar, consultar])
        self.assertEqual(len(self.inventario.obter_retrato()["recursos"]), 100)

    def test_16_falha_criacao(self):
        chave = self.inventario.reservar("tcp_escuta", ciclo_id=1, tentativa_id=1,
                                        proprietario="criador_simulado")
        self.inventario.registrar_falha_criacao(chave)
        self.assertEqual(self.entrada(chave).fase, "falhou")
        self.assertFalse(self.confirmar(chave))
        self.assertFalse(self.inventario.publicar_criacao(chave))

    def ciclo_confirmado(self, registro, controle, antes_encerrar=None):
        contexto = servidor.ContextoCicloServidor()
        tentativa = registro.admitir(contexto)
        registro.marcar_iniciando(tentativa)
        registro.registrar_entrada_execucao(tentativa)
        registro.marcar_iniciada(tentativa)
        workers = servidor.RegistroTrabalhadores()
        self.assertTrue(controle.tentar_iniciar(workers))
        contexto.registrar_reserva(workers.ciclo_id)
        if antes_encerrar is not None:
            antes_encerrar(tentativa, workers.ciclo_id)
        workers.bloquear_criacao()
        controle.finalizar(workers)
        contexto.registrar_retorno_coordenador()
        return tentativa, workers.ciclo_id

    def test_17_critico_http_antigo_pendente(self):
        registro = servidor.RegistroTentativasAplicacao()
        controle = servidor.ControleCicloServidor()
        recursos_a = []
        def criar_http_e_solicitar_limpeza(tentativa, ciclo):
            chave = self.recurso("http_requisicao", ciclo=ciclo, tentativa=tentativa)
            self.inventario.registrar_limpeza_solicitada(chave)
            recursos_a.append(chave)
        a, ciclo_a = self.ciclo_confirmado(registro, controle, criar_http_e_solicitar_limpeza)
        http_a, = recursos_a
        b, ciclo_b = self.ciclo_confirmado(registro, controle)
        tcp_b = self.recurso(ciclo=ciclo_b, tentativa=b)
        self.confirmar(tcp_b)
        registro.fechar_admissao()
        with patch.object(servidor, "controle_ciclo_servidor", controle):
            self.assertTrue(servidor.avaliar_encerramento_aplicacao(registro)["encerramento_confirmado"])
        retrato = self.inventario.obter_retrato()
        self.assertIn(http_a, retrato["pendencias"])
        self.assertFalse(retrato["todos_recursos_observados_encerrados"])
        self.assertEqual(self.entrada(http_a).ciclo_id, ciclo_a)

    def test_18_critico_reserva_antes_de_operar(self):
        reservou = threading.Barrier(2, timeout=5)
        permitir_operar = threading.Barrier(2, timeout=5)
        publicou = threading.Barrier(2, timeout=5)
        def criar():
            chave = self.inventario.reservar("http_requisicao", ciclo_id=1,
                                            tentativa_id=1, proprietario="criador_simulado")
            reservou.wait()
            permitir_operar.wait()
            self.inventario.publicar_criacao(chave)
            publicou.wait()
        def consultar():
            reservou.wait()
            antes = self.inventario.obter_retrato()
            self.assertEqual(len(antes["recursos"]), 1)
            self.assertEqual(antes["recursos"][0].fase, "reservada")
            self.assertFalse(antes["todos_recursos_observados_encerrados"])
            permitir_operar.wait()
            publicou.wait()
            depois = self.inventario.obter_retrato()
            self.assertEqual(antes["recursos"][0].recurso_id, depois["recursos"][0].recurso_id)
            self.assertEqual(antes["recursos"][0].fase, "reservada")
            self.assertEqual(depois["recursos"][0].estado, "ativo")
        self.threads([criar, consultar])


# Grupo de 4 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class LacunasOperacionais(unittest.TestCase):
    def test_19_bind_tcp_udp_agora_protegido(self):
        for funcao in (servidor.servidor_tcp, servidor.servidor_descoberta):
            with self.subTest(funcao=funcao.__name__):
                sock = Mock()
                sock.fileno.return_value = 1
                sock.close.side_effect = lambda: setattr(sock.fileno, "return_value", -1)
                sock.bind.side_effect = OSError("falha simulada")
                with patch.object(servidor.socket, "socket", return_value=sock):
                    with self.assertRaises(OSError):
                        funcao()
                sock.close.assert_called_once()

    def test_20_construcao_handler_agora_protege_socket(self):
        listener, cliente = Mock(), Mock()
        listener.accept.return_value = (cliente, ("simulado", 1))
        for recurso in (listener, cliente):
            recurso.fileno.return_value = 1
            recurso.close.side_effect = lambda recurso=recurso: setattr(recurso.fileno, "return_value", -1)
        with patch.object(servidor.socket, "socket", return_value=listener), \
             patch.object(servidor, "evento_parada_servidor", threading.Event()), \
             patch.object(servidor, "threading", SimpleNamespace(
                 Lock=threading.Lock, Thread=Mock(side_effect=RuntimeError()))):
            with self.assertRaises(RuntimeError):
                servidor.servidor_tcp()
        listener.close.assert_called_once()
        cliente.close.assert_called_once()

    def test_21_requests_sessao_temporaria_em_chamada_avulsa(self):
        import requests
        from tc420.web import WebTC420
        web = WebTC420("simulado")
        web.token = object()
        resposta = SimpleNamespace(raise_for_status=Mock(), text="SUCCESS:APPROVAL:dados-simulados")
        close_original = requests.sessions.Session.close
        with patch.object(requests.sessions.Session, "request", return_value=resposta) as request, \
             patch.object(requests.sessions.Session, "close", autospec=True, side_effect=close_original) as close:
            self.assertEqual(web.approval(), "dados-simulados")
            request.side_effect = RuntimeError("falha simulada")
            with self.assertRaises(RuntimeError):
                web.approval()
            self.assertEqual(close.call_count, 2)

    def test_22_handler_morre_erro_close_nao_entra_no_historico(self):
        controle = servidor.ControleCicloServidor()
        workers = servidor.RegistroTrabalhadores()
        controle.tentar_iniciar(workers)
        registro = servidor.RegistroTentativasAplicacao()
        contexto = servidor.ContextoCicloServidor()
        tentativa = registro.admitir(contexto)
        registro.marcar_iniciando(tentativa)
        registro.registrar_entrada_execucao(tentativa)
        registro.marcar_iniciada(tentativa)
        contexto.registrar_reserva(workers.ciclo_id)
        cliente = Mock()
        cliente.recv.return_value = b"CHECK\n"
        cliente.close.side_effect = OSError("falha simulada")
        erros = []
        def atender():
            try:
                servidor.atender_cliente(cliente, ("simulado", 1))
            except OSError as erro:
                erros.append(type(erro).__name__)
        worker = threading.Thread(target=atender)
        try:
            with patch.object(servidor, "obter_saude_tc420", return_value=dict(saudavel=True)):
                workers.registrar_e_iniciar(worker)
                worker.join(3)
                self.assertFalse(worker.is_alive())
            self.assertEqual(erros, ["OSError"])
            workers.bloquear_criacao()
            controle.finalizar(workers)
            contexto.registrar_retorno_coordenador()
            registro.fechar_admissao()
            with patch.object(servidor, "controle_ciclo_servidor", controle):
                self.assertTrue(servidor.avaliar_encerramento_aplicacao(registro)["encerramento_confirmado"])
            self.assertFalse(workers.obter_situacao()["erros_limpeza"])
        finally:
            if worker.ident is not None:
                worker.join(3)


if __name__ == "__main__":
    unittest.main()

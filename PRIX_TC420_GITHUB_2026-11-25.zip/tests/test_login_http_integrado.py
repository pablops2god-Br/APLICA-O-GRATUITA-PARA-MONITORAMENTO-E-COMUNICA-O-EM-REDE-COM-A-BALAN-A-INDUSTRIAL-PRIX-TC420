# Testes de login http integrado: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.3: login real, transporte falso, main por AST; sem rede/Tk/keyring."""
from contextlib import contextmanager
from types import SimpleNamespace
import threading
import unittest
from unittest.mock import Mock, patch
from urllib.parse import parse_qs, urlsplit

import requests

from rede import infraestrutura_cliente as modulo
from tc420.web import WebTC420
from test_auditoria_http_arquivos_cliente import AdaptadorFalso, CorpoFalso
from test_registro_automatico import carregar_fluxos, ThreadFila
import test_infraestrutura_cliente as instalacao


# Grupo de 30 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class LoginHttpIntegrado(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = modulo.InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_http
        self.web = WebTC420("balanca-simulada")
        self.env = carregar_fluxos()
        self.env["WebTC420"].return_value = self.web
        self.web.obter_configuracao = Mock(return_value={})
        ThreadFila.criadas = []

    def executar(self, web=None):
        return self.infra.executar_login_automatico(web or self.web, "simulado", "simulado")

    def main(self):
        return self.env["tentar_login_automatico"](infraestrutura_cliente=self.infra)

    def operacoes(self):
        return self.registro.obter_retrato()["operacoes"]

    def negativo(self):
        retrato = self.registro.obter_retrato()
        self.assertFalse(retrato["encerramento_global_confirmado"])
        self.assertEqual("incompleta", retrato["cobertura_operacional"])
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])
        self.assertFalse(self.infra.avaliar()["cobertura_completa"])

    @contextmanager
    def transporte(self, texto=b"SUCCESS:LOGIN:simulado:simulado", **kwargs):
        adaptador = AdaptadorFalso(CorpoFalso([texto]), **kwargs)
        sessao = requests.Session()
        sessao.trust_env = False  # Apenas harness: nunca ler proxy/netrc locais.
        sessao.mount("https://", adaptador)
        with patch("requests.api.sessions.Session", return_value=sessao):
            yield adaptador

    def iniciar_thread(self, chamada):
        resultados, erros = [], []
        def alvo():
            try:
                resultados.append(chamada())
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=alvo, daemon=True)
        thread.start()
        return thread, resultados, erros

    def terminar(self, tarefa):
        tarefa[0].join(3)
        self.assertFalse(tarefa[0].is_alive())
        return tarefa[1:]

    def bloquear(self, entrou, liberar):
        entrou.set()
        if not liberar.wait(3):
            raise AssertionError("barreira_nao_liberada")

    def test_01_main_normal_protocolo_e_limite_inteiro(self):
        def antes():
            op = self.operacoes()[0]
            self.assertEqual("em_andamento", op["estado"])
            self.assertEqual(1, op["execucoes_ativas"])
        with self.transporte(antes=antes) as adaptador, patch("tc420.web.random.random", return_value=0.25):
            resultado = self.main()
        self.assertIs(self.web, resultado["web"])
        self.assertEqual("principal", resultado["modo"])
        self.assertEqual(1, len(adaptador.enviados))
        requisicao, opcoes = adaptador.enviados[0]
        self.assertEqual("POST", requisicao.method)
        self.assertEqual("https://balanca-simulada/cgi-bin/cfgcgi.cgi", requisicao.url.split('?')[0])
        self.assertEqual(dict(cmd=["login"], uname=["simulado"], pwd=["valor-simulado"], math=["0.25"]),
                         parse_qs(urlsplit(requisicao.url).query))
        self.assertIsNone(requisicao.body)
        self.assertEqual(5, opcoes["timeout"])
        self.assertFalse(opcoes["verify"])
        self.assertFalse(opcoes["stream"])
        self.assertEqual(1, adaptador.corpo.lidos)
        self.assertEqual(1, adaptador.fechamentos)
        self.assertEqual("retorno", self.operacoes()[0]["resultado"])
        self.web.obter_configuracao.assert_called_once_with()

    def test_02_http_erro_mesma_resposta_e_main_false(self):
        with self.transporte(status=503) as adaptador:
            with self.assertRaises(requests.HTTPError) as capturado:
                self.executar()
        self.assertIs(adaptador.resposta, capturado.exception.response)
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        with self.transporte(status=503):
            self.assertFalse(self.main())
        self.web.obter_configuracao.assert_not_called()
        self.assertEqual([], ThreadFila.criadas)

    def test_03_timeout_original_uma_tentativa(self):
        original = requests.Timeout("falha_simulada")
        with self.transporte(erro=original) as adaptador:
            with self.assertRaises(requests.Timeout) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertEqual(1, len(adaptador.enviados))
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_04_conexao_original(self):
        original = requests.ConnectionError("falha_simulada")
        with self.transporte(erro=original):
            with self.assertRaises(requests.ConnectionError) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertEqual("falha", self.operacoes()[0]["resultado"])

    def test_05_validacao_original_resposta(self):
        for texto in (b"invalida", b"FAILURE:LOGIN:simulado:simulado", b"SUCCESS:LOGIN:simulado:"):
            with self.subTest(texto=texto), self.transporte(texto):
                with self.assertRaises(RuntimeError):
                    self.executar()
            self.assertIsNone(self.web.token)
            self.assertEqual("falha", self.operacoes()[-1]["resultado"])
            self.assertTrue(self.operacoes()[-1]["execucao_resolvida"])

    def test_06_falha_pre_execucao_com_prova_local(self):
        original = ValueError("preparacao_simulada")
        class WebIndisponivel:
            @property
            def login(self):
                raise original
        with patch("requests.post") as enviar:
            with self.assertRaises(ValueError) as capturado:
                self.executar(WebIndisponivel())
        self.assertIs(original, capturado.exception)
        enviar.assert_not_called()
        op = self.operacoes()[0]
        self.assertFalse(op["inicio_confirmado"])
        self.assertTrue(op["execucao_resolvida"])
        self.assertEqual("nao_execucao_comprovada", op["publicacao_original"]["evidencia"])

    def test_07_admissao_recusada_sem_rede_e_diagnostico(self):
        self.registro.fechar_admissao()
        self.env["print"] = Mock()
        with patch("requests.post") as enviar:
            with self.assertRaisesRegex(RuntimeError, "admissao_contexto_http_recusada"):
                self.executar()
            self.assertFalse(self.main())
        enviar.assert_not_called()
        self.env["print"].assert_any_call("Falha no login autom\u00e1tico: RuntimeError")
        self.assertEqual([], self.operacoes())
        self.assertEqual([], ThreadFila.criadas)

    def test_08_corrida_c_publicacao_atrasada(self):
        entrou, liberar = threading.Event(), threading.Event()
        original = self.registro.publicar
        def publicar(op, recibo):
            self.bloquear(entrou, liberar)
            return original(op, recibo)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=publicar):
            tarefa = self.iniciar_thread(self.executar)
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual("simulado", self.web.token)
                op = self.operacoes()[0]
                self.assertTrue(op["publicacoes_pendentes"])
                self.assertFalse(op["execucao_resolvida"])
                self.negativo()
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertEqual(["simulado"], resultados)
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_09_falha_publicacao_sem_partida_principal(self):
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=OSError()):
            self.assertFalse(self.main())
        op = self.operacoes()[0]
        self.assertEqual("desconhecida", op["estado"])
        self.assertFalse(op["execucao_resolvida"])
        self.assertEqual([], ThreadFila.criadas)
        self.web.obter_configuracao.assert_not_called()
        self.negativo()

    def test_10_publicacao_duplicada_idempotente(self):
        original = self.registro.publicar
        def duplicar(op, recibo):
            self.assertTrue(original(op, recibo))
            return original(op, recibo)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=duplicar):
            self.assertEqual("simulado", self.executar())
        self.assertEqual([], self.operacoes()[0]["conflitos_publicacao"])
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_11_corrida_d_duas_operacoes_sucesso_e_falha(self):
        barreira = threading.Barrier(2)
        resposta = Mock(text="SUCCESS:LOGIN:simulado:simulado")
        original = requests.ConnectionError("simulada")
        def enviar(url, **kwargs):
            barreira.wait(3)
            self.assertEqual(2, len(self.operacoes()))
            self.assertTrue(all(not o["execucao_resolvida"] for o in self.operacoes()))
            barreira.wait(3)  # Ambos observaram pendência antes de concluir.
            if "segunda" in url:
                raise original
            return resposta
        with patch("tc420.web.requests.post", side_effect=enviar):
            a = self.iniciar_thread(self.executar)
            b = self.iniciar_thread(lambda: self.executar(WebTC420("segunda-simulada")))
            resultados_a, erros_a = self.terminar(a)
            resultados_b, erros_b = self.terminar(b)
        self.assertEqual(["simulado"], resultados_a)
        self.assertEqual([], erros_a)
        self.assertEqual([], resultados_b)
        self.assertEqual([original], erros_b)
        ops = self.operacoes()
        self.assertEqual(2, len({o["operacao_id"] for o in ops}))
        self.assertEqual({"retorno", "falha"}, {o["resultado"] for o in ops})
        self.assertTrue(all(o["execucao_resolvida"] for o in ops))

    def test_12_geracao_antiga_falha_depois_nova_concluir(self):
        entrou, liberar = threading.Event(), threading.Event()
        erro = requests.Timeout("simulada")
        def enviar(url, **kwargs):
            if "balanca" in url:
                self.bloquear(entrou, liberar)
                raise erro
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=enviar):
            tarefa = self.iniciar_thread(self.executar)
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.operacoes()[0]
                self.executar(WebTC420("nova-simulada"))
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        a, b = self.operacoes()
        self.assertEqual([erro], erros)
        self.assertEqual(antes["geracao_id"], a["geracao_id"])
        self.assertEqual(antes["operacao_id"], a["operacao_id"])
        self.assertNotEqual(a["geracao_id"], b["geracao_id"])
        self.assertEqual(("falha", "retorno"), (a["resultado"], b["resultado"]))

    def test_13_promocao_real_preserva_registro_durante_login(self):
        entrou, liberar = threading.Event(), threading.Event()
        fixture = instalacao.InfraestruturaCliente()
        fixture.setUp()
        fixture.env["buscar_servidor"].return_value = None
        resultados_promocao = []
        fixture.durante_monitor = lambda monitor: resultados_promocao.append(monitor.ao_promover_automaticamente())
        with self.transporte(antes=lambda: self.bloquear(entrou, liberar)):
            tarefa = self.iniciar_thread(self.main)
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.operacoes()[0]
                fixture.iniciar_cliente(self.infra)
                self.assertIsNotNone(resultados_promocao[0])
                self.assertIs(self.registro, fixture.monitores[0].infraestrutura_cliente.registro_http)
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertEqual("principal", resultados[0]["modo"])
        self.assertEqual(antes["geracao_id"], self.operacoes()[0]["geracao_id"])
        self.assertEqual(4, len(self.operacoes()))  # Dois logins e dois approval.
        self.assertEqual(2, sum(o["operacao"] == "approval" for o in self.operacoes()))
        self.assertTrue(self.operacoes()[1]["execucao_resolvida"])
        self.assertNotEqual(self.operacoes()[0]["geracao_id"], self.operacoes()[1]["geracao_id"])

    def test_14_corpo_recebido_limpeza_biblioteca_falha_sem_prova_global(self):
        original = OSError("limpeza_simulada")
        with self.transporte() as adaptador:
            adaptador.close = Mock(side_effect=original)
            with self.assertRaises(OSError) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertEqual(1, adaptador.corpo.lidos)
        adaptador.close.assert_called_once_with()
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.negativo()  # Resolução da falha não confirma liberação do transporte.

    def test_15_nenhum_http_em_curso_nao_completa_cobertura(self):
        with self.transporte():
            self.executar()
        self.assertTrue(self.registro.obter_retrato()["operacoes_resolvidas"])
        self.registro.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_16_global_negativo_todos_gates_fechados(self):
        with self.transporte():
            self.executar()
        self.registro.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.negativo()

    def test_17_corrida_a_reservada_antes_gate_fechado(self):
        reservada, partida, liberar_partida, liberar_rede = [threading.Event() for _ in range(4)]
        original = self.registro.executar
        def executar(op, chamada):
            self.bloquear(reservada, liberar_partida)
            return original(op, chamada)
        with self.transporte(antes=lambda: self.bloquear(partida, liberar_rede)), \
                patch.object(self.registro, "executar", side_effect=executar):
            tarefa = self.iniciar_thread(self.executar)
            try:
                self.assertTrue(reservada.wait(3))
                self.assertEqual("reservada", self.operacoes()[0]["estado"])
                self.registro.fechar_admissao()
                liberar_partida.set()
                self.assertTrue(partida.wait(3))
                self.assertEqual("em_andamento", self.operacoes()[0]["estado"])
                self.assertFalse(self.registro.obter_retrato()["conjunto_http_resolvido"])
            finally:
                liberar_partida.set()
                liberar_rede.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertEqual(["simulado"], resultados)
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])

    def test_18_corrida_b_promover_metadados_sem_mudar_origem(self):
        entrou, liberar = threading.Event(), threading.Event()
        geracoes = []
        nova = self.infra.registro_retentativas.nova_geracao_cliente
        def gerar():
            token = nova()
            geracoes.append(token)
            return token
        with patch.object(self.infra.registro_retentativas, "nova_geracao_cliente", side_effect=gerar), \
                self.transporte(antes=lambda: self.bloquear(entrou, liberar)):
            tarefa = self.iniciar_thread(self.executar)
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.operacoes()[0]
                self.infra.registro_retentativas.promover(geracoes[0])
                self.registro.promover(antes["geracao_id"])
                nova()  # Geração B não é dona da requisição A.
                self.assertEqual("principal", self.operacoes()[0]["modo_atual"])
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        depois = self.operacoes()[0]
        for campo in ("operacao_id", "geracao_id", "atividade_id"):
            self.assertEqual(antes[campo], depois[campo])
        self.assertEqual("retorno", depois["resultado"])

    def test_19_erro_original_prevalece_sobre_publicacao(self):
        original = requests.Timeout("simulada")
        with self.transporte(erro=original), patch.object(self.registro, "publicar", side_effect=ValueError()):
            with self.assertRaises(requests.Timeout) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])
        self.assertTrue(self.operacoes()[0]["erros_execucao"])

    def test_20_main_iniciar_usa_instancia_instalada_uma_vez(self):
        fixture = instalacao.InfraestruturaCliente()
        fixture.setUp()
        fixture.env["buscar_servidor"].return_value = None
        fixture.env["WebTC420"].return_value = self.web
        with self.transporte(), patch.object(modulo, "InfraestruturaRegistrosCliente", return_value=self.infra) as criar:
            fixture.env["iniciar"]()
        criar.assert_called_once_with()
        self.assertIs(self.infra, fixture.monitores[0].infraestrutura_cliente)
        self.assertEqual(["login", "approval"], [o["operacao"] for o in self.operacoes()])
        self.assertEqual(self.operacoes()[0]["geracao_id"], self.operacoes()[1]["geracao_id"])
        self.assertIs(self.infra, self.registro.proprietario)

    def test_21_approval_independente_nao_instrumentado(self):
        with self.transporte():
            self.executar()
        antes = self.registro.obter_retrato()
        with self.transporte(b"SUCCESS:APPROVAL:simulado") as adaptador:
            self.assertEqual("simulado", self.web.approval())
        self.assertEqual("GET", adaptador.enviados[0][0].method)
        self.assertEqual(antes, self.registro.obter_retrato())

    def test_22_retrato_sem_argumentos_resultado_ou_diagnostico_http(self):
        with self.transporte(b"SUCCESS:LOGIN:simulado:marcador-resultado"):
            self.executar()
        texto = repr(self.registro.obter_retrato())
        for proibido in ("marcador-resultado", "uname", "pwd", "https://", "balanca-simulada"):
            self.assertNotIn(proibido, texto)

    def test_23_execucao_fora_locks_registros(self):
        def antes():
            for registro in (self.registro, self.infra.registro_recursos, self.infra.registro_retentativas):
                adquirido = registro._lock.acquire(blocking=False)
                self.assertTrue(adquirido)
                if adquirido:
                    registro._lock.release()
            self.assertEqual("em_andamento", self.operacoes()[0]["estado"])
        with self.transporte(antes=antes):
            self.executar()

    def test_24_recusa_entre_contexto_e_reserva(self):
        admitir = self.registro.admitir
        def fechar(contexto, operacao):
            self.registro.fechar_admissao()
            return admitir(contexto, operacao)
        with patch.object(self.registro, "admitir", side_effect=fechar), patch("requests.post") as enviar:
            with self.assertRaisesRegex(RuntimeError, "admissao_operacao_http_recusada"):
                self.executar()
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())

    def test_25_preparacao_fechada_nao_admite_http(self):
        self.infra.registro_retentativas.fechar_admissao()
        with patch("requests.post") as enviar:
            with self.assertRaisesRegex(RuntimeError, "admissao_preparacao_http_recusada"):
                self.executar()
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())

    def test_26_recurso_pendente_nao_resolvido_por_login(self):
        recursos = self.infra.registro_recursos
        token = recursos.reservar("arquivo_comum", 100, 100)
        objeto = SimpleNamespace(closed=False, close=Mock(side_effect=OSError()))
        recursos.criar(token, lambda: objeto)
        with self.assertRaises(OSError):
            recursos.fechar(token)
        antes = recursos.obter_retrato()
        with self.transporte():
            self.executar()
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.assertEqual(antes, recursos.obter_retrato())
        self.negativo()

    def test_27_conflito_publicacao_preserva_original(self):
        publicar = self.registro.publicar
        def conflito(op, recibo):
            publicar(op, recibo)
            outro = self.registro.preparar_publicacao(op, erro=OSError())
            return publicar(op, outro)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=conflito):
            with self.assertRaisesRegex(RuntimeError, "publicacao_conflitante"):
                self.executar()
        op = self.operacoes()[0]
        self.assertEqual("retorno", op["publicacao_original"]["resultado"])
        self.assertEqual("falha", op["conflitos_publicacao"][0]["resultado"])
        self.assertFalse(op["execucao_resolvida"])

    def test_28_executor_aborta_antes_inicio_reserva_resolvida(self):
        original = OSError("antes_inicio_simulado")
        with patch.object(self.registro, "_iniciar", side_effect=original), patch("requests.post") as enviar:
            with self.assertRaises(OSError) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        enviar.assert_not_called()
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.assertFalse(self.operacoes()[0]["inicio_confirmado"])

    def test_29_inicio_observado_impede_prova_ausencia(self):
        iniciar = self.registro._iniciar
        original = OSError("inicio_ambiguo_simulado")
        def ambiguo(op, gerenciada):
            iniciar(op, gerenciada)
            raise original
        with patch.object(self.registro, "_iniciar", side_effect=ambiguo), patch("requests.post") as enviar:
            with self.assertRaises(OSError) as capturado:
                self.executar()
        self.assertIs(original, capturado.exception)
        enviar.assert_not_called()
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])
        self.assertFalse(self.operacoes()[0]["execucao_resolvida"])

    def test_30_publicacao_prova_preexecucao_falha_conservadora(self):
        original = ValueError("preparacao_simulada")
        class WebIndisponivel:
            @property
            def login(self):
                raise original
        with patch.object(self.registro, "comprovar_nao_inicio", side_effect=OSError()):
            with self.assertRaises(ValueError) as capturado:
                self.executar(WebIndisponivel())
        self.assertIs(original, capturado.exception)
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])
        self.assertFalse(self.operacoes()[0]["execucao_resolvida"])


if __name__ == "__main__":
    unittest.main()

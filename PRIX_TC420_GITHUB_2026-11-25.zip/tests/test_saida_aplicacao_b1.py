# Testes de saida aplicacao b1: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""B1: metodos/entradas reais com Tk, transporte e threads de servico falsos."""
import threading
import time
import unittest
from unittest.mock import Mock, patch

from interface.saida_aplicacao import SaidaAplicacao
import test_infraestrutura_cliente as montagem
import test_login_manual_http as manual
import test_auditoria_encerramento_interface as auditoria


# Grupo de 17 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class SaidaAplicacaoB1(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.saida = SaidaAplicacao()

    def pendente(self, saida=None):
        situacao = (saida or self.saida).obter_situacao()
        self.assertTrue(situacao['solicitada'])
        self.assertIn(situacao['estado'], ('encerramento_pendente_b2', 'parando', 'timeout', 'falha'))
        self.assertFalse(situacao['encerramento_confirmado'])

    def montagem(self):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        return fx

    def test_cliente_sim_encaminha_ao_leitor_capturado(self):
        fx = self.montagem()
        def durante(monitor):
            self.assertIs(self.saida, monitor.saida_aplicacao)
            self.assertTrue(monitor.ao_fechar())
            fx.leitores[-1].parar.assert_called_once_with()
            self.assertFalse(monitor.ao_fechar())
            fx.leitores[-1].parar.assert_called_once_with()
            self.pendente()
        fx.durante_monitor = durante
        fx.env['iniciar_como_cliente']('simulado', saida_aplicacao=self.saida)

    def test_principal_automatico_registra_sem_parada_global_insegura(self):
        fx = self.montagem()
        fx.env['buscar_servidor'].return_value = None
        evento = threading.Event()
        contexto = manual.servidor.ContextoCicloServidor()
        fx.env['tentar_login_automatico'] = Mock(return_value={
            'modo': 'principal', 'servidor_encerrado': evento,
            'web': Mock(), 'configuracao': {}, 'contexto_ciclo': contexto})
        def durante(monitor):
            monitor.saida_aplicacao._prazo = .03
            monitor.saida_aplicacao.acompanhar_contexto(contexto)
            for item in monitor.saida_aplicacao._threads:
                item['thread'].is_alive = Mock(return_value=True)
            self.assertTrue(monitor.ao_fechar())
            self.assertFalse(monitor.ao_fechar())
            self.pendente(monitor.saida_aplicacao)
            self.assertFalse(evento.is_set())
            monitor.saida_aplicacao._coordenacao.join(1)
        fx.durante_monitor = durante
        fx.env['iniciar']()
        fx.env['iniciar_servidor'].assert_not_called()

    def test_principal_manual_encaminha_uma_vez_sem_destroy(self):
        fx = manual.LoginManualHttp()
        fx.setUp()
        self.addCleanup(fx.doCleanups)
        janela = fx.janela
        janela.root.withdraw = Mock()
        janela.saida_aplicacao._prazo = .03
        janela.saida_aplicacao.acompanhar_contexto(manual.servidor.ContextoCicloServidor())
        fx.env['JanelaTC420'] = Mock(return_value=Mock())
        fx.env['obter_dados_atuais'] = Mock()
        janela.abrir_monitor()
        callback = fx.env['JanelaTC420'].call_args.kwargs['ao_fechar']
        with patch.object(janela, 'encerrar_aplicacao', wraps=janela.encerrar_aplicacao) as encaminhar:
            self.assertTrue(callback())
            self.assertFalse(callback())
            self.assertEqual(0, encaminhar.call_count)  # B2 substitui a auxiliar legada.
        janela.saida_aplicacao._coordenacao.join(1)
        janela.verificar_finalizacao()
        self.pendente(janela.saida_aplicacao)
        self.assertFalse(janela.root.destruida)
        self.assertFalse(janela.finalizacao_confirmada)
        self.assertEqual('encerramento_pendente_b2', janela.estado_encerramento)

    def test_promocao_conserva_proprietario_e_callback(self):
        fx = self.montagem()
        fx.env['buscar_servidor'].return_value = None
        fx.env['obter_credenciais_salvas'] = Mock(return_value={
            'ip': 'simulado', 'usuario': 'operador_simulado', 'senha': object()})
        def durante(monitor):
            callback = monitor.ao_fechar
            resultado = monitor.ao_promover_automaticamente()
            self.assertIsNotNone(resultado)
            self.assertIs(callback, monitor.ao_fechar)
            self.assertIs(self.saida, monitor.saida_aplicacao)
            self.saida._prazo = .03
            for item in self.saida._threads:
                item['thread'].is_alive = Mock(return_value=True)
            self.assertTrue(callback())
            self.assertFalse(callback())
            self.pendente()
            self.saida._coordenacao.join(1)
        fx.durante_monitor = durante
        fx.env['iniciar_como_cliente'](
            'simulado', saida_aplicacao=self.saida,
            infraestrutura_cliente=montagem.modulo.InfraestruturaRegistrosCliente())

    def test_manual_preserva_parada_existente_sem_confirmar_aplicacao(self):
        fx = manual.LoginManualHttp()
        fx.setUp()
        self.addCleanup(fx.doCleanups)
        janela = fx.janela
        janela.servidor_iniciado = True
        janela.servidor_inicializado.set()
        janela.saida_aplicacao._prazo = .03
        janela.saida_aplicacao.acompanhar_contexto(manual.servidor.ContextoCicloServidor())
        fx.env['time'] = time
        parada = Mock(side_effect=janela.servidor_encerrado.set)
        fx.env['solicitar_parada_servidor'] = parada
        self.assertTrue(janela.encerrar_aplicacao())
        thread = janela.thread_finalizacao
        self.assertFalse(janela.encerrar_aplicacao())
        self.assertIs(thread, janela.thread_finalizacao)
        self.assertIsNone(thread)
        janela.saida_aplicacao._coordenacao.join(1)
        parada.assert_not_called()  # Somente destino com identidade de ciclo.
        janela.verificar_finalizacao()
        self.assertFalse(janela.finalizacao_concluida.is_set())
        self.assertFalse(janela.finalizacao_confirmada)
        self.assertFalse(janela.root.destruida)
        self.pendente(janela.saida_aplicacao)

    def test_cancelar_nao_encaminha_nem_para(self):
        parada = Mock()
        callback = self.saida.vincular('cliente', parada)
        fx = auditoria.FluxoAtualAuditado()
        monitor = fx.monitor(None, callback)
        monitor.confirmar_fechamento()
        parada.assert_not_called()
        self.assertFalse(self.saida.obter_situacao()['solicitada'])
        self.assertTrue(monitor.executando)
        monitor.root.destroy.assert_not_called()

    def test_sim_real_monitor_nao_destroi(self):
        parada = Mock()
        fx = auditoria.FluxoAtualAuditado()
        monitor = fx.monitor(True, self.saida.vincular('cliente', parada))
        monitor.confirmar_fechamento()
        monitor.confirmar_fechamento()
        parada.assert_called_once_with()
        monitor.root.destroy.assert_not_called()
        self.assertTrue(monitor.executando)
        self.pendente()

    def test_nao_preserva_execucao(self):
        parada = Mock()
        fx = auditoria.FluxoAtualAuditado()
        monitor = fx.monitor(False, self.saida.vincular('cliente', parada))
        monitor.confirmar_fechamento()
        parada.assert_not_called()
        self.assertTrue(monitor.executando)
        self.assertFalse(self.saida.obter_situacao()['solicitada'])

    def test_callback_antigo_nao_controla_novo_vinculo(self):
        parar_a, parar_b = Mock(), Mock()
        antigo = self.saida.vincular('geracao_a', parar_a)
        atual = self.saida.vincular('geracao_b', parar_b)
        self.assertFalse(antigo())
        self.assertFalse(self.saida.obter_situacao()['solicitada'])
        parar_a.assert_not_called()
        parar_b.assert_not_called()
        self.assertTrue(atual())
        parar_b.assert_called_once_with()
        self.assertEqual('geracao_b', self.saida.obter_situacao()['origem'])

    def test_monitores_cliente_sucessivos_nao_compartilham_callback(self):
        fx = self.montagem()
        fx.env['iniciar_como_cliente']('a', saida_aplicacao=self.saida)
        antigo = fx.monitores[-1].ao_fechar
        def durante(monitor):
            parar_a, parar_b = fx.leitores[0].parar, fx.leitores[1].parar
            antes_a, antes_b = parar_a.call_count, parar_b.call_count
            self.assertFalse(antigo())
            self.assertEqual(antes_a, parar_a.call_count)
            self.assertEqual(antes_b, parar_b.call_count)
            self.assertTrue(monitor.ao_fechar())
            self.assertEqual(antes_b + 1, parar_b.call_count)
        fx.durante_monitor = durante
        fx.env['iniciar_como_cliente']('b', saida_aplicacao=self.saida)

    def test_callback_manual_anterior_nao_fecha_monitor_substituto(self):
        fx = manual.LoginManualHttp()
        fx.setUp()
        self.addCleanup(fx.doCleanups)
        janela = fx.janela
        janela.root.withdraw = Mock()
        antigo = janela._callback_saida
        fx.env['JanelaTC420'] = Mock(return_value=Mock())
        fx.env['obter_dados_atuais'] = Mock()
        janela.abrir_monitor()
        self.assertFalse(antigo())
        self.assertFalse(janela.saida_aplicacao.obter_situacao()['solicitada'])
        self.assertFalse(janela.root.destruida)

    def test_aplicacoes_independentes(self):
        outra = SaidaAplicacao()
        self.saida.vincular('a')()
        self.assertFalse(outra.obter_situacao()['solicitada'])
        self.assertTrue(outra.vincular('b')())

    def test_nao_substitui_dono_depois_da_solicitacao(self):
        self.saida.vincular('a')()
        with self.assertRaisesRegex(RuntimeError, 'saida_ja_solicitada'):
            self.saida.vincular('b')
        self.assertEqual('a', self.saida.obter_situacao()['origem'])

    def test_solicitacoes_concorrentes_tem_um_destino(self):
        entrou, liberar = threading.Event(), threading.Event()
        chamadas, resultados, erros = [], [], []
        def parar():
            chamadas.append(True)
            entrou.set()
            if not liberar.wait(3):
                raise RuntimeError('barreira_simulada')
        callback = self.saida.vincular('cliente', parar)
        def solicitar():
            try:
                resultados.append(callback())
            except BaseException as erro:
                erros.append(erro)
        t = threading.Thread(target=solicitar, daemon=True)
        t.start()
        try:
            self.assertTrue(entrou.wait(3))
            self.assertFalse(callback())
            self.pendente()  # Consulta durante o destino: lock nao cobre cleanup.
        finally:
            liberar.set()
            t.join(3)
        self.assertFalse(t.is_alive())
        self.assertEqual([], erros)
        self.assertEqual([True], chamadas)
        self.assertEqual([True], resultados)

    def test_falha_no_destino_mantem_pendente_sem_repeticao(self):
        destino = Mock(side_effect=OSError('erro_simulado'))
        callback = self.saida.vincular('cliente', destino)
        self.assertTrue(callback())
        self.assertFalse(callback())
        destino.assert_called_once_with()
        self.pendente()
        situacao = self.saida.obter_situacao()
        self.assertEqual('falha_io', situacao['erro_encaminhamento'])
        self.assertNotIn('erro_simulado', str(situacao))

    def test_evento_servidor_nao_autoriza_destroy(self):
        fx = auditoria.FluxoAtualAuditado()
        janela = fx.conexao(servidor_iniciado=True)
        janela.servidor_encerrado.set()
        janela.encerrar_aplicacao()
        janela.verificar_finalizacao()
        self.assertFalse(janela.concluir_encerramento_confirmado())
        janela.root.destroy.assert_not_called()
        self.pendente(janela.saida_aplicacao)

    def test_fallback_manual_main_e_cliente_usam_mesma_saida(self):
        fx = self.montagem()
        fx.env['buscar_servidor'].return_value = None
        fx.env['tentar_login_automatico'] = Mock(return_value=False)
        proprietarios = []
        def durante_conexao(conexao):
            proprietarios.append(conexao.saida_aplicacao)
            conexao.ao_encontrar_servidor('simulado')
        fx.durante_conexao = durante_conexao
        fx.durante_monitor = lambda monitor: proprietarios.append(monitor.saida_aplicacao)
        fx.env['iniciar']()
        self.assertEqual(2, len(proprietarios))
        self.assertIs(proprietarios[0], proprietarios[1])

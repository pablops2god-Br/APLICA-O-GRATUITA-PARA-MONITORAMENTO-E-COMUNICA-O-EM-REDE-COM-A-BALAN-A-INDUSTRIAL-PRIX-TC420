"""2B.7: três backends, cargas de 50 mil e lock instrumentado; sem rede."""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import platform
import random
import statistics
import sys
import threading
import time
import tracemalloc
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rede import servidor as s
from prototipos.identidades_intervalos import RegistroIntervalosExperimental
from prototipos.consultas_intervalos import RegistroConsultasExperimental


class LockMedido:
    def __init__(self):
        self.lock = threading.Lock()
        self.registros = []
        self.hook = None
    def __enter__(self):
        antes = time.perf_counter()
        self.lock.acquire()
        self.adquirido = time.perf_counter()
        self.espera = self.adquirido-antes
        if self.hook is not None:
            self.hook()
        return self
    def __exit__(self, *args):
        retencao = time.perf_counter()-self.adquirido
        self.registros.append((self.espera, retencao))
        self.lock.release()


def perfil(r, funcao, repeticoes=3):
    r.lock.registros.clear()
    total = []
    for _ in range(repeticoes):
        inicio = time.perf_counter()
        resposta = funcao()
        total.append(time.perf_counter()-inicio)
        del resposta
    registros = list(r.lock.registros)
    return dict(repeticoes=repeticoes, total_mediana_s=statistics.median(total),
        espera_mediana_s=statistics.median(x[0] for x in registros),
        retencao_mediana_s=statistics.median(x[1] for x in registros),
        retencao_maxima_s=max(x[1] for x in registros))


def contencao(r):
    # O observador segura o lock. Um segundo acesso tem de esperar por ele.
    entrou, liberar, tentando, conseguiu = (threading.Event() for _ in range(4))
    resultado = {}
    erros = []
    def hook():
        if threading.current_thread() is a:
            entrou.set()
            if not liberar.wait(10):
                raise RuntimeError('prazo do teste')
    def consulta():
        try:
            inicio = time.perf_counter()
            resultado['diagnosticos'] = len(r.obter_situacao()['criacoes_socket'])
            resultado['consulta_incluindo_sincronizacao_s'] = time.perf_counter()-inicio
        except BaseException as e:
            erros.append(type(e).__name__)
    def concorrente():
        tentando.set()
        inicio = time.perf_counter()
        with r.lock:
            resultado['espera_concorrente_s'] = time.perf_counter()-inicio
            conseguiu.set()
    a, b = threading.Thread(target=consulta), threading.Thread(target=concorrente)
    r.lock.hook = hook
    a.start()
    assert entrou.wait(10)
    b.start()
    assert tentando.wait(10)
    assert not conseguiu.is_set()
    liberar.set()
    a.join(15)
    b.join(15)
    assert not a.is_alive() and not b.is_alive() and conseguiu.is_set()
    r.lock.hook = None
    assert not erros, erros
    return resultado


def medir(versao, carga, externos, total=50000):
    gc.collect()
    tracemalloc.start()
    inicio = time.perf_counter()
    cls = {'atual': s.RegistroTrabalhadores, '2B6': RegistroIntervalosExperimental,
           '2B7': RegistroConsultasExperimental}[versao]
    r = cls()
    tokens = [r.reservar_criacao_socket() for _ in range(total)] if carga in ('reversa', 'aleatoria') else []
    preservados = []
    ordem = list(range(total))
    if carga == 'reversa':
        ordem = list(reversed(ordem[::2])) + list(reversed(ordem[1::2]))
    if carga == 'aleatoria':
        random.Random(270).shuffle(ordem)
    for i in ordem:
        t = tokens[i] if tokens else r.reservar_criacao_socket()
        uniforme = carga == 'uniforme' or i % 2 == 0
        r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=uniforme)
        if externos == 'todos' or externos == 'um' and i == 0:
            preservados.append(t)
    del t, tokens, ordem
    r.bloquear_criacao()
    gc.collect()
    retida, pico = tracemalloc.get_traced_memory()
    carga_s = time.perf_counter()-inicio
    r.lock = LockMedido()
    tracemalloc.reset_peak()
    inicio = time.perf_counter()
    diagnostico = r.obter_situacao()
    consulta_s = time.perf_counter()-inicio
    _, pico_consulta = tracemalloc.get_traced_memory()
    espera, retencao = r.lock.registros[-1]
    tracemalloc.stop()
    digest = hashlib.sha256(repr(diagnostico).encode()).hexdigest()
    confirmado_esperado = (diagnostico['criacao_bloqueada'] and not diagnostico['threads_vivas']
        and not diagnostico['erros_limpeza'] and diagnostico['sockets_encerrados'])
    assert r.encerramento_confirmado() == confirmado_esperado
    del diagnostico
    for t in preservados:
        assert r.fechar_socket(t) is (carga == 'uniforme' or t.criacao_id % 2 == 1)
    storage = r._reservas_socket
    return dict(versao=versao, carga=carga, externos=externos, reservas=total,
        fortes=len(storage.fortes) if versao != 'atual' else len(storage),
        faixas=len(storage.intervalos) if versao != 'atual' else 0,
        bytes_retidos=retida, pico_carga_bytes=pico, carga_s=carga_s,
        consulta_tracemalloc_s=consulta_s, consulta_pico_absoluto_bytes=pico_consulta,
        espera_tracemalloc_s=espera, retencao_tracemalloc_s=retencao,
        consulta_sem_tracemalloc=perfil(r, r.obter_situacao),
        agregado_sem_tracemalloc=perfil(r, r.encerramento_confirmado),
        contencao=contencao(r), digest=digest)


def contratos():
    nomes = ['test_compactacao_registro','test_guarda_sockets_integrada',
             'test_erros_fechamento_handlers','test_saida_aplicacao_b2','test_supervisao_principal']
    suite = unittest.defaultTestLoader.loadTestsFromNames(nomes)
    with patch.object(s, 'RegistroTrabalhadores', RegistroConsultasExperimental):
        return unittest.TextTestRunner(verbosity=0).run(suite).wasSuccessful()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--contratos', action='store_true')
    parser.add_argument('--saida', type=Path)
    args = parser.parse_args()
    if args.contratos:
        raise SystemExit(not contratos())
    if args.saida is None:
        parser.error('--saida obrigatorio para medicoes')
    resultados = []
    for carga, externos in [('uniforme','nenhum'), ('uniforme','um'), ('uniforme','todos'),
                            ('alternada','nenhum'), ('reversa','nenhum'), ('aleatoria','todos')]:
        grupo = []
        for versao in ('atual', '2B6', '2B7'):
            m = medir(versao, carga, externos)
            resultados.append(m)
            grupo.append(m)
            args.saida.write_text(json.dumps(dict(python=platform.python_version(), plataforma=sys.platform,
                concluido=False, medicoes=resultados), indent=2), encoding='utf-8')
        assert len({m['digest'] for m in grupo}) == 1
    args.saida.write_text(json.dumps(dict(python=platform.python_version(), plataforma=sys.platform,
        concluido=True, medicoes=resultados,
        limites='Tracemalloc nao e RSS; GC explicito; sem rede; tres repeticoes nao instrumentadas; '
                'contencao controlada inclui sincronizacao e nao e latencia real do servidor.'), indent=2), encoding='utf-8')

# Testes de entradas http vinculadas: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.13-A: montagem real por AST, rede/Tk/persistência simulados."""
from dataclasses import FrozenInstanceError, replace
from types import SimpleNamespace
import threading
import unittest
from unittest.mock import Mock, patch
from uuid import uuid4

from rede import infraestrutura_cliente as modulo
from rede.entradas_http import VinculoEntradasHttp, criar_validador_entrada
from tc420.web import WebTC420
from test_registro_automatico import carregar_fluxos
import test_auditoria_cobertura_http as auditoria
import test_approval_http_integrado as approval
import test_login_manual_http as manual


# Grupo de 23 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class EntradasHttpVinculadas(unittest.TestCase):
    fluxo_http = approval.ApprovalHttpIntegrado.fluxo_http
    transporte = approval.ApprovalHttpIntegrado.transporte
    iniciar_thread = approval.ApprovalHttpIntegrado.iniciar_thread
    terminar = approval.ApprovalHttpIntegrado.terminar
    bloquear = approval.ApprovalHttpIntegrado.bloquear
    operacoes = approval.ApprovalHttpIntegrado.operacoes
    negativo = approval.ApprovalHttpIntegrado.negativo
    fixture_main = auditoria.AuditoriaCoberturaHttp.fixture_main
    conferir_par = auditoria.AuditoriaCoberturaHttp.conferir_par

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = modulo.InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_http
        self.outra = modulo.InfraestruturaRegistrosCliente()
        self.vinculo = VinculoEntradasHttp(self.infra)

    def automatico(self, apresentada=None, vinculo=None):
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        env["print"] = Mock()
        chamada = (vinculo or self.vinculo).vincular(env["tentar_login_automatico"])
        return env, lambda: chamada(infraestrutura_cliente=self.infra if apresentada is None else apresentada)

    def manual(self, apresentada=None, **kwargs):
        fx = manual.LoginManualHttp()
        fx.setUp()
        fx.env["WebTC420"].side_effect = WebTC420
        kwargs.setdefault("vinculo_http", self.vinculo)
        janela = fx.criar_janela(self.infra if apresentada is None else apresentada, **kwargs)
        return fx, janela

    def promocao(self, apresentada=None, **kwargs):
        fx = self.fixture_main()
        fx.env["print"] = Mock()
        kwargs.setdefault("vinculo_http", self.vinculo)
        fx.env["iniciar_como_cliente"]("principal-simulado", infraestrutura_cliente=(
            self.infra if apresentada is None else apresentada), **kwargs)
        return fx, fx.monitores[0].ao_promover_automaticamente

    def main(self, caminho):
        fx = self.fixture_main()
        janelas = []
        if caminho == "manual":
            fx.env["tentar_login_automatico"] = Mock(return_value=False)
            def criar(**kwargs):
                ui, janela = self.manual(kwargs["infraestrutura_cliente"], vinculo_http=kwargs["vinculo_http"])
                janela.root.mainloop = janela.conectar
                janelas.append(janela)
                return janela
            fx.env["JanelaConexao"] = criar
        elif caminho == "promocao":
            fx.preparar_promocao()
        with self.fluxo_http() as adaptador, \
                patch.object(modulo, "InfraestruturaRegistrosCliente", return_value=self.infra), \
                patch("rede.entradas_http.criar_validador_entrada", wraps=criar_validador_entrada) as montar:
            fx.env["iniciar"]()
        self.conferir_par(adaptador)
        # O harness manual também constrói uma janela isolada auxiliar no setUp.
        vinculadas = [c for c in montar.call_args_list if c.args[0] is not False]
        self.assertTrue(vinculadas)
        for chamada in vinculadas:
            ancora = chamada.args[0]
            self.assertIs(type(ancora), VinculoEntradasHttp)
            self.assertIs(self.infra, ancora.validar(self.infra))
            with self.assertRaises(modulo.InfraestruturaHttpInvalida):
                ancora.validar(self.outra)
        if janelas:
            janelas[0]._sessao_antes_repeticao = janelas[0].web
            janelas[0].infraestrutura_cliente = self.outra
            with patch("requests.api.request") as enviar:
                janelas[0].conectar()
            enviar.assert_not_called()
            self.assertIs(janelas[0].web, janelas[0]._sessao_antes_repeticao)

    def test_01_automatico_main_vinculado_aceita_a(self):
        self.main("automatico")

    def test_02_manual_main_vinculado_aceita_a(self):
        self.main("manual")

    def test_03_promocao_main_vinculada_aceita_a(self):
        self.main("promocao")

    def test_04_automatico_a_recusa_b_antes_web(self):
        env, executar = self.automatico(self.outra)
        with self.fluxo_http() as adaptador:
            self.assertIs(False, executar())
        env["WebTC420"].assert_not_called()
        self.assertEqual([], adaptador.enviados)

    def test_05_manual_a_recusa_b_antes_web(self):
        fx, janela = self.manual(self.outra)
        with self.fluxo_http() as adaptador:
            janela.conectar()
        fx.env["WebTC420"].assert_not_called()
        self.assertEqual([], adaptador.enviados)
        self.assertEqual("normal", janela.botao_conectar.opcoes["state"])

    def test_06_promocao_a_recusa_b_antes_web(self):
        fx, executar = self.promocao(self.outra)
        with self.fluxo_http() as adaptador:
            self.assertIsNone(executar())
        fx.env["WebTC420"].assert_not_called()
        fx.leitores[0].registrar_falha_recuperacao.assert_called_once_with()
        self.assertEqual([], adaptador.enviados)

    def _testar_troca(self, recursos):
        original = self.infra._instalacao
        if recursos:
            alterada = replace(original, contexto=replace(original.contexto, recursos=self.outra.registro_recursos))
        else:
            alterada = replace(original, http=self.outra.registro_http)
        env, executar = self.automatico()
        object.__setattr__(self.infra, "_instalacao", alterada)
        try:
            with self.fluxo_http() as adaptador:
                self.assertIs(False, executar())
            self.assertEqual([], adaptador.enviados)
            env["WebTC420"].assert_not_called()
        finally:
            object.__setattr__(self.infra, "_instalacao", original)

    def test_07_http_substituido(self):
        self._testar_troca(False)

    def test_08_recursos_substituidos(self):
        self._testar_troca(True)

    def test_09_id_coerente_de_b_nao_comprova_a(self):
        with patch("prototipos.composicao_cliente.uuid4", return_value=SimpleNamespace(hex=self.infra.aplicacao_id)):
            outra = modulo.InfraestruturaRegistrosCliente()
        self.assertIs(outra, modulo.exigir_infraestrutura_http(outra))
        env, executar = self.automatico(outra)
        with self.fluxo_http() as adaptador:
            self.assertIs(False, executar())
        self.assertEqual([], adaptador.enviados)
        env["WebTC420"].assert_not_called()

    def test_10_atributos_publicos_nao_substituem_ancora(self):
        fx, janela = self.manual()
        janela.infraestrutura_cliente = self.outra
        janela.vinculo_http = VinculoEntradasHttp(self.outra)
        with self.fluxo_http() as adaptador:
            janela.conectar()
        self.assertEqual([], adaptador.enviados)
        fx.env["WebTC420"].assert_not_called()
        janela.infraestrutura_cliente = self.infra
        with self.fluxo_http() as adaptador:
            janela.conectar()
        self.conferir_par(adaptador)

    def test_11_duas_aplicacoes_independentes(self):
        for infra in (self.infra, self.outra):
            _, executar = self.automatico(infra, VinculoEntradasHttp(infra))
            with self.fluxo_http() as adaptador:
                self.assertTrue(executar())
            self.assertEqual(2, len(adaptador.enviados))
            self.assertEqual(2, len(infra.registro_http.obter_retrato()["operacoes"]))

    def test_12_isolada_legitima_preserva_contrato_sem_prova_externa(self):
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        with self.fluxo_http() as adaptador:
            self.assertTrue(env["tentar_login_automatico"](infraestrutura_cliente=self.outra))
        self.assertEqual(2, len(adaptador.enviados))
        self.assertEqual([], self.operacoes())
        with patch("requests.api.request") as enviar:
            self.assertIs(False, env["tentar_login_automatico"]())
        enviar.assert_not_called()

    def test_13_vinculada_sem_ancora_nao_vira_isolada(self):
        for invalido in (None, object(), VinculoEntradasHttp.__new__(VinculoEntradasHttp)):
            with self.subTest(tipo=type(invalido).__name__):
                env = carregar_fluxos()
                env["WebTC420"].side_effect = WebTC420
                fx, janela = self.manual(vinculo_http=invalido)
                cliente, promover = self.promocao(vinculo_http=invalido)
                with self.fluxo_http() as adaptador:
                    self.assertIs(False, env["tentar_login_automatico"](
                        infraestrutura_cliente=self.infra, vinculo_http=invalido))
                    janela.conectar()
                    self.assertIsNone(promover())
                self.assertEqual([], adaptador.enviados)
                for fabrica in (env["WebTC420"], fx.env["WebTC420"], cliente.env["WebTC420"]):
                    fabrica.assert_not_called()

    def test_14_admissao_fechada_nas_tres(self):
        _, auto = self.automatico()
        _, janela = self.manual()
        _, promover = self.promocao()
        self.registro.fechar_admissao()
        with self.fluxo_http() as adaptador:
            self.assertIs(False, auto())
            janela.conectar()
            self.assertIsNone(promover())
        self.assertEqual([], adaptador.enviados)

    def test_15_preparacao_anterior_ao_leitor(self):
        _, executar = self.automatico()
        entrou, liberar = threading.Event(), threading.Event()
        def post(*args, **kwargs):
            self.bloquear(entrou, liberar)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=post), \
                patch("tc420.web.requests.get", return_value=Mock(text=approval.APROVACAO.decode())):
            tarefa = self.iniciar_thread(executar)
            try:
                self.assertTrue(entrou.wait(3))
                origem = self.operacoes()[0]
                novo = modulo.RecursosLeitorCliente(self.infra)
                self.assertNotEqual(origem["geracao_id"], novo.geracao_id)
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertTrue(resultados[0])
        self.assertEqual({origem["geracao_id"]}, {o["geracao_id"] for o in self.operacoes()})
        self.assertEqual(2, len({o["operacao_id"] for o in self.operacoes()}))

    def test_16_encerramento_global_nao_confirmado(self):
        _, executar = self.automatico()
        with self.fluxo_http():
            self.assertTrue(executar())
        self.registro.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_17_corrida_a_troca_publica_durante_validacao(self):
        _, janela = self.manual()
        validar = janela._validar_infraestrutura_http
        entrou, liberar = threading.Event(), threading.Event()
        def validar_bloqueado(apresentada):
            resultado = validar(apresentada)
            self.bloquear(entrou, liberar)
            return resultado
        janela._validar_infraestrutura_http = validar_bloqueado
        with self.fluxo_http() as adaptador:
            tarefa = self.iniciar_thread(janela.conectar)
            try:
                self.assertTrue(entrou.wait(3))
                janela.infraestrutura_cliente = self.outra
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.conferir_par(adaptador)
        self.assertEqual([], self.outra.registro_http.obter_retrato()["operacoes"])
        self.assertIs(self.infra, janela.web.politica_http.proprietario)

    def test_18_corrida_b_promocao_e_nova_geracao(self):
        fx, promover = self.promocao()
        leitor = fx.leitores[0]
        origem = leitor.recursos_cliente
        entrou, liberar = threading.Event(), threading.Event()
        def post(*args, **kwargs):
            self.bloquear(entrou, liberar)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=post), \
                patch("tc420.web.requests.get", return_value=Mock(text=approval.APROVACAO.decode())):
            tarefa = self.iniciar_thread(promover)
            try:
                self.assertTrue(entrou.wait(3))
                leitor.recursos_cliente = modulo.RecursosLeitorCliente(self.infra)
                self.assertNotEqual(origem.geracao_id, leitor.recursos_cliente.geracao_id)
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertIs(self.infra, resultados[0]["web"].politica_http.proprietario)
        self.assertEqual({origem.geracao_id}, {o["geracao_id"] for o in self.operacoes()})
        self.assertEqual({origem.atividade_id}, {o["atividade_id"] for o in self.operacoes()})

    def test_19_corrida_c_duas_aplicacoes_simultaneas(self):
        _, a = self.automatico()
        _, b = self.automatico(self.outra, VinculoEntradasHttp(self.outra))
        barreira = threading.Barrier(2)
        def post(*args, **kwargs):
            barreira.wait(3)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=post), \
                patch("tc420.web.requests.get", return_value=Mock(text=approval.APROVACAO.decode())):
            ta, tb = self.iniciar_thread(a), self.iniciar_thread(b)
            ra, ea = self.terminar(ta)
            rb, eb = self.terminar(tb)
        self.assertEqual(([], []), (ea, eb))
        self.assertIs(self.infra, ra[0]["web"].politica_http.proprietario)
        self.assertIs(self.outra, rb[0]["web"].politica_http.proprietario)
        for infra in (self.infra, self.outra):
            ops = infra.registro_http.obter_retrato()["operacoes"]
            self.assertEqual(["login", "approval"], [o["operacao"] for o in ops])
            self.assertTrue(all(o["execucao_resolvida"] for o in ops))

    def test_20_corrida_d_gate_entre_validacao_e_reserva(self):
        _, janela = self.manual()
        validar = janela._validar_infraestrutura_http
        entrou, liberar = threading.Event(), threading.Event()
        def bloquear_validacao(apresentada):
            resultado = validar(apresentada)
            self.bloquear(entrou, liberar)
            return resultado
        janela._validar_infraestrutura_http = bloquear_validacao
        with self.fluxo_http() as adaptador:
            tarefa = self.iniciar_thread(janela.conectar)
            try:
                self.assertTrue(entrou.wait(3))
                self.registro.fechar_admissao()
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertEqual([], adaptador.enviados)
        self.assertEqual([], self.operacoes())

    def test_21_adicional_comprovacao_circular_e_recursos_nas_tres(self):
        for recursos in (False, True):
            with self.subTest(recursos=recursos):
                apresentada = self.infra if recursos else self.outra
                _, auto = self.automatico(apresentada)
                fx, janela = self.manual(apresentada)
                cliente, promover = self.promocao(apresentada)
                original = self.infra._instalacao
                if recursos:
                    object.__setattr__(self.infra, "_instalacao", replace(original,
                        contexto=replace(original.contexto, recursos=self.outra.registro_recursos)))
                try:
                    if recursos:
                        with self.assertRaises(modulo.InfraestruturaHttpInvalida):
                            modulo.exigir_infraestrutura_http(apresentada)
                    else:
                        self.assertIs(apresentada, modulo.exigir_infraestrutura_http(apresentada))
                    with self.fluxo_http() as adaptador:
                        self.assertIs(False, auto())
                        janela.conectar()
                        self.assertIsNone(promover())
                    self.assertEqual([], adaptador.enviados)
                    fx.env["WebTC420"].assert_not_called()
                    cliente.env["WebTC420"].assert_not_called()
                finally:
                    object.__setattr__(self.infra, "_instalacao", original)

    def test_22_ancora_imutavel_e_argumentos_nao_a_substituem(self):
        with self.assertRaises(FrozenInstanceError):
            self.vinculo._infraestrutura = self.outra
        with self.assertRaises(modulo.InfraestruturaHttpInvalida):
            self.vinculo.__init__(self.outra)
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        entrada = self.vinculo.vincular(env["tentar_login_automatico"])
        entrada.vinculo_http = VinculoEntradasHttp(self.outra)
        with self.fluxo_http() as adaptador:
            for falsa in (False, None, entrada.vinculo_http):
                self.assertIs(False, entrada(infraestrutura_cliente=self.outra, vinculo_http=falsa))
        self.assertEqual([], adaptador.enviados)
        env["WebTC420"].assert_not_called()

    def test_23_rejeicao_sanitizada(self):
        fx, janela = self.manual(self.outra)
        marcadores = [uuid4().hex for _ in range(3)]
        janela.campo_usuario.valor, janela.campo_senha.valor, janela.campo_ip.valor = marcadores
        with self.fluxo_http() as adaptador:
            janela.conectar()
        saidas = repr(fx.env["print"].call_args_list) + janela.label_status.opcoes["text"]
        self.assertTrue(all(m not in saidas for m in marcadores))
        self.assertEqual([], adaptador.enviados)

# Testes de limpeza subscribe cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""SUBSCRIBE real, cleanup individual e concorrência com transporte/Tk falsos."""
from contextlib import contextmanager
import threading
import unittest
from unittest.mock import Mock, patch

from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.lerdadosserver import LeitorDadosServidor
from apoio_conexoes_cliente import conexoes_tcp_simuladas
from test_recursos_cliente_integrados import SocketLeituraFalso


# Grupo de 27 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class LimpezaSubscribeCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.reg = self.infra.registro_recursos
        self.leitor = self.novo_leitor()

    def novo_leitor(self):
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente-simulado"):
            leitor = LeitorDadosServidor("principal-simulado", infraestrutura_cliente=self.infra)
        leitor.executando = True
        leitor._parada.wait = Mock(return_value=False)  # Intervalo real pertence ao aplicativo.
        leitor._aguardar_candidatura = Mock(side_effect=lambda: (setattr(leitor, "executando", False), False)[-1])
        return leitor

    def objeto(self):
        objeto = SocketLeituraFalso()
        objeto.arquivo.readline = Mock(return_value='')
        return objeto

    def recursos(self):
        return self.reg.obter_retrato()["recursos"]

    def subscribe(self, leitor=None):
        geracao = (leitor or self.leitor).recursos_cliente.geracao_id
        return [r for r in self.recursos() if r["geracao_id"] == geracao][-2:]

    def global_negativo(self):
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])

    @contextmanager
    def transporte(self, objetos, leitor=None):
        leitor = leitor or self.leitor
        config = self.objeto()
        config.arquivo.readline.return_value = '{}'
        registros = []
        for _ in objetos:
            registro = self.objeto()
            registro.arquivo.readline.return_value = '{"nome":"cliente-simulado","posicao":1}'
            registros.append(registro)
        with conexoes_tcp_simuladas(leitor.recursos_cliente, [config, *registros]), \
                patch("rede.lerdadosserver.socket.socket", side_effect=objetos), \
                patch("builtins.print") as imprimir:
            yield imprimir

    def executar(self, objeto=None, leitor=None):
        objeto = objeto or self.objeto()
        leitor = leitor or self.leitor
        with self.transporte([objeto], leitor) as imprimir:
            leitor._manter_atualizado()
        return objeto, imprimir

    def test_01_encerramento_normal(self):
        objeto = self.objeto()
        objeto.arquivo.readline.side_effect = lambda: (setattr(self.leitor, "executando", False), '')[-1]
        self.executar(objeto)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe()))
        self.assertTrue(objeto.fechado)
        self.assertTrue(objeto.arquivo.closed)
        self.assertIsNone(self.leitor.cliente)

    def test_02_desconexao_remota_preserva_candidatura(self):
        self.executar()
        self.leitor._aguardar_candidatura.assert_called_once_with()
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe()))

    def test_03_erro_leitura_preserva_diagnostico_original(self):
        objeto = self.objeto()
        original = ValueError("leitura_simulada")
        objeto.arquivo.readline.side_effect = original
        _, imprimir = self.executar(objeto)
        imprimir.assert_any_call(f"Conexão com servidor perdida: {original}")
        self.assertTrue(self.subscribe()[0]["erros_atendimento"])
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe()))

    def test_04_parsing_invalido_preserva_dados_e_fluxo(self):
        objeto = self.objeto()
        objeto.arquivo.readline.return_value = '{invalido'
        antes = self.leitor.obter_dados_atuais()
        with patch("rede.lerdadosserver.PRAZO_SILENCIO_SUBSCRIBE", 0.001):
            _, imprimir = self.executar(objeto)
        self.assertEqual(antes, self.leitor.obter_dados_atuais())
        self.leitor._aguardar_candidatura.assert_called_once_with()
        self.assertTrue(any("Silêncio do servidor detectado:" in str(c.args) for c in imprimir.call_args_list))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe()))

    def test_05_socket_close_falho_nao_omite_arquivo(self):
        objeto = self.objeto()
        objeto.erro_close = RuntimeError("socket_simulado")
        self.executar(objeto)
        pai, filho = self.subscribe()
        self.assertTrue(pai["erros_limpeza"])
        self.assertFalse(pai["encerramento_confirmado"])
        self.assertTrue(filho["encerramento_confirmado"])
        self.leitor._aguardar_candidatura.assert_called_once_with()

    def test_06_arquivo_close_falho_nao_desfaz_socket(self):
        objeto = self.objeto()
        objeto.arquivo.erro_close = OSError("arquivo_simulado")
        self.executar(objeto)
        pai, filho = self.subscribe()
        self.assertTrue(pai["encerramento_confirmado"])
        self.assertTrue(filho["erros_limpeza"])
        self.assertFalse(filho["encerramento_confirmado"])

    def test_07_duas_falhas_limpeza_registradas(self):
        objeto = self.objeto()
        objeto.erro_close = RuntimeError()
        objeto.arquivo.erro_close = OSError()
        self.executar(objeto)
        self.assertTrue(all(r["erros_limpeza"] for r in self.subscribe()))
        self.assertFalse(any(r["encerramento_confirmado"] for r in self.subscribe()))

    def par(self):
        objeto = self.objeto()
        cliente = self.leitor.recursos_cliente.abrir_socket(lambda: objeto)
        arquivo = cliente.makefile("r", encoding="utf-8")
        return cliente, arquivo, objeto

    def test_08_socket_fechado_arquivo_pendente(self):
        cliente, arquivo, _ = self.par()
        self.leitor._fechar_recurso_subscribe(cliente)
        self.assertTrue(self.subscribe()[0]["encerramento_confirmado"])
        self.assertFalse(self.subscribe()[1]["encerramento_confirmado"])
        self.global_negativo()
        arquivo.close()

    def test_09_arquivo_fechado_socket_pendente(self):
        cliente, arquivo, _ = self.par()
        self.leitor._fechar_recurso_subscribe(arquivo)
        self.assertFalse(self.subscribe()[0]["encerramento_confirmado"])
        self.assertTrue(self.subscribe()[1]["encerramento_confirmado"])
        self.global_negativo()
        cliente.close()

    def duas_conexoes(self, primeiro, segundo):
        def recuperar():
            if self.leitor._aguardar_candidatura.call_count == 2:
                self.leitor.executando = False
            self.leitor.ip_servidor = "principal-simulado"
            return False
        self.leitor._aguardar_candidatura = Mock(side_effect=recuperar)
        self.leitor._parada.wait = Mock(return_value=False)
        with self.transporte([primeiro, segundo]):
            self.leitor._manter_atualizado()

    def test_10_reconexao_identidades_independentes(self):
        primeiro, segundo = self.objeto(), self.objeto()
        self.duas_conexoes(primeiro, segundo)
        self.assertEqual(10, len({r["recurso_id"] for r in self.recursos()}))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))
        self.assertEqual(2, self.leitor._aguardar_candidatura.call_count)
        prazos = [c.args[0] for c in segundo.settimeout.call_args_list]
        self.assertEqual(5, prazos[0])
        self.assertTrue(all(0 < prazo <= 6 for prazo in prazos[1:]))
        segundo.sendall.assert_called_once_with(b"SUBSCRIBE\n")

    def test_11_reconexao_preserva_cleanup_antigo_falho(self):
        primeiro, segundo = self.objeto(), self.objeto()
        primeiro.arquivo.erro_close = OSError()
        self.duas_conexoes(primeiro, segundo)
        antigos = self.recursos()[4:6]
        atuais = self.recursos()[-2:]
        self.assertFalse(antigos[1]["encerramento_confirmado"])
        self.assertTrue(antigos[1]["erros_limpeza"])
        self.assertTrue(all(r["encerramento_confirmado"] for r in atuais))
        self.assertIsNone(self.leitor.cliente)
        self.global_negativo()

    def test_12_promocao_durante_leitura(self):
        objeto = self.objeto()
        geracao = self.leitor.recursos_cliente.geracao_id
        def receber():
            self.reg.promover(geracao)
            self.leitor.parar()
            return ''
        objeto.arquivo.readline.side_effect = receber
        self.executar(objeto)
        self.assertTrue(all(r["geracao_id"] == geracao for r in self.subscribe()))
        self.assertTrue(all(r["modo_atual"] == "principal" for r in self.subscribe()))
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe()))
        self.global_negativo()

    def test_13_close_repetido_nao_apaga_falhas(self):
        cliente, arquivo, objeto = self.par()
        objeto.erro_close = OSError()
        self.leitor._fechar_recurso_subscribe(cliente)
        erros = self.subscribe()[0]["erros_limpeza"]
        objeto.erro_close = None
        self.leitor._fechar_recurso_subscribe(cliente)
        self.leitor._fechar_recurso_subscribe(cliente)
        self.assertEqual(erros, self.subscribe()[0]["erros_limpeza"])
        self.assertFalse(self.subscribe()[0]["encerramento_confirmado"])
        self.assertEqual(2, objeto.close_chamadas)
        arquivo.close()

    def test_14_referencia_substituida_nao_fecha_socket_novo(self):
        antigo, novo = self.objeto(), self.objeto()
        novos = []
        def substituir():
            cliente = self.leitor.recursos_cliente.abrir_socket(lambda: novo)
            novos.append(cliente)
            with self.leitor._lock_assinatura:
                self.leitor.cliente = cliente
            return ''
        antigo.arquivo.readline.side_effect = substituir
        self.executar(antigo)
        self.assertTrue(antigo.fechado)
        self.assertTrue(antigo.arquivo.closed)
        self.assertFalse(novo.fechado)
        self.assertIs(novos[0], self.leitor.cliente)
        self.assertEqual(7, len(self.recursos()))
        self.assertTrue(self.recursos()[4]["encerramento_confirmado"])
        self.assertFalse(self.recursos()[6]["encerramento_confirmado"])
        novos[0].close()

    def retido(self, executar, durante):
        entrou, liberar = threading.Event(), threading.Event()
        erros = []
        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise AssertionError("barreira_nao_liberada")
        def tarefa():
            try:
                executar(suspender)
            except BaseException as erro:
                erros.append(erro)
        thread = threading.Thread(target=tarefa)
        thread.start()
        try:
            self.assertTrue(entrou.wait(3))
            durante()
        finally:
            liberar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_15_consulta_durante_cleanup(self):
        objeto = self.objeto()
        close = objeto.arquivo.close
        def executar(suspender):
            objeto.arquivo.close = lambda: (suspender(), close())[-1]
            self.executar(objeto)
        def consultar():
            pai, filho = self.subscribe()
            self.assertTrue(pai["encerramento_confirmado"])
            self.assertTrue(filho["limpeza_em_curso"])
            self.assertFalse(filho["prova_fechamento"])
            self.global_negativo()
        self.retido(executar, consultar)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe()))

    def test_16_cobertura_global_parcial(self):
        self.executar()
        self.reg.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.assertTrue(self.reg.obter_retrato()["encerramento_confirmado"])
        self.assertFalse(self.infra.avaliar()["cobertura_completa"])
        self.global_negativo()

    def test_critico_A_leitura_bloqueada_parada_sem_file_close_na_chamadora(self):
        objeto = self.objeto()
        threads_close = []
        close = objeto.arquivo.close
        objeto.arquivo.close = lambda: (threads_close.append(threading.get_ident()), close())[-1]
        def executar(suspender):
            objeto.arquivo.readline.side_effect = lambda: (suspender(), '')[-1]
            self.executar(objeto)
        def parar():
            self.leitor.parar()
            pai, filho = self.subscribe()
            self.assertEqual(1, pai["usos"])
            self.assertFalse(pai["encerramento_confirmado"])
            self.assertEqual(0, filho["usos"])
            self.assertFalse(filho["encerramento_confirmado"])
            self.assertEqual([], threads_close)
            objeto.shutdown.assert_called_once()
            self.global_negativo()
        self.retido(executar, parar)
        self.assertEqual(1, len(threads_close))
        self.assertNotEqual(threading.get_ident(), threads_close[0])
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe()))

    def test_critico_B_nova_conexao_enquanto_arquivo_antigo_fecha(self):
        antigo = self.objeto()
        close = antigo.arquivo.close
        def executar(suspender):
            antigo.arquivo.close = lambda: (suspender(), close())[-1]
            self.executar(antigo)
        def reconectar():
            nova = self.novo_leitor()
            self.executar(self.objeto(), nova)
            self.assertTrue(self.subscribe()[1]["limpeza_em_curso"])
            self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe(nova)))
            self.assertEqual(12, len({r["recurso_id"] for r in self.recursos()}))
            self.global_negativo()
        self.retido(executar, reconectar)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.recursos()))

    def test_critico_C_erro_leitura_e_file_close_falho_tardio(self):
        objeto = self.objeto()
        original = ValueError("leitura_original_simulada")
        objeto.arquivo.readline.side_effect = original
        def executar(suspender):
            def fechar():
                suspender()
                raise OSError("close_simulado")
            objeto.arquivo.close = fechar
            _, imprimir = self.executar(objeto)
            imprimir.assert_any_call(f"Conexão com servidor perdida: {original}")
        def consultar():
            self.assertTrue(self.subscribe()[0]["erros_atendimento"])
            self.assertTrue(self.subscribe()[1]["limpeza_em_curso"])
            self.global_negativo()
        self.retido(executar, consultar)
        self.assertTrue(self.subscribe()[1]["erros_limpeza"])
        self.assertFalse(self.subscribe()[1]["encerramento_confirmado"])

    def test_critico_D_promocao_antiga_pendente_nova_limpa(self):
        objeto = self.objeto()
        objeto.arquivo.erro_close = OSError()
        geracao = self.leitor.recursos_cliente.geracao_id
        def executar(suspender):
            objeto.arquivo.readline.side_effect = lambda: (suspender(), '')[-1]
            self.executar(objeto)
        def promover():
            self.reg.promover(geracao)
            self.leitor.parar()
            nova = self.novo_leitor()
            self.executar(self.objeto(), nova)
            self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe(nova)))
            self.assertFalse(self.subscribe()[1]["encerramento_confirmado"])
            self.reg.fechar_admissao()
            self.infra.registro_retentativas.fechar_admissao()
            self.assertFalse(self.reg.obter_retrato()["encerramento_confirmado"])
            self.global_negativo()
        self.retido(executar, promover)
        self.assertEqual(geracao, self.subscribe()[1]["geracao_id"])
        self.assertTrue(self.subscribe()[1]["erros_limpeza"])
        self.global_negativo()

    def test_close_real_fora_dos_locks(self):
        objeto = self.objeto()
        for recurso in (objeto, objeto.arquivo):
            close = recurso.close
            def fechar(fn=close):
                for lock in (self.reg._lock, self.leitor._lock_assinatura):
                    self.assertTrue(lock.acquire(blocking=False))
                    lock.release()
                fn()
            recurso.close = fechar
        self.executar(objeto)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe()))

    def test_close_arquivo_sem_closed_true_nao_confirma(self):
        objeto = self.objeto()
        objeto.arquivo.close = Mock()
        self.executar(objeto)
        self.assertTrue(self.subscribe()[1]["erros_evidencia"])
        self.assertEqual("desconhecido", self.subscribe()[1]["estado"])
        self.global_negativo()

    def test_parar_shutdown_falha_ainda_tenta_socket_close(self):
        cliente, arquivo, objeto = self.par()
        objeto.shutdown.side_effect = RuntimeError()
        self.leitor.cliente = cliente
        self.leitor.parar()
        self.assertTrue(objeto.fechado)
        self.assertFalse(objeto.arquivo.closed)
        self.assertIsNone(self.leitor.cliente)
        arquivo.close()

    def test_interrupcao_original_nao_mascarada_por_duplo_close(self):
        objeto = self.objeto()
        original = KeyboardInterrupt()
        objeto.arquivo.readline.side_effect = original
        objeto.erro_close = RuntimeError()
        objeto.arquivo.erro_close = OSError()
        with self.assertRaises(KeyboardInterrupt) as capturado:
            self.executar(objeto)
        self.assertIs(original, capturado.exception)
        self.assertTrue(all(r["erros_limpeza"] for r in self.subscribe()))
        self.assertTrue(self.subscribe()[0]["erros_atendimento"])

    def test_parada_concorrente_nao_duplica_close_em_curso(self):
        objeto = self.objeto()
        close = objeto.close
        def executar(suspender):
            objeto.close = lambda: (suspender(), close())[-1]
            self.executar(objeto)
        def parar():
            self.leitor.parar()
            self.assertTrue(self.subscribe()[0]["limpeza_em_curso"])
            self.assertFalse(objeto.arquivo.closed)
            self.global_negativo()
        self.retido(executar, parar)
        self.assertEqual(1, objeto.close_chamadas)
        self.assertTrue(all(r["encerramento_confirmado"] for r in self.subscribe()))

    def test_legado_sem_registro_retem_handle_falho(self):
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente-simulado"):
            leitor = LeitorDadosServidor()
        objeto = self.objeto()
        objeto.erro_close = OSError()
        leitor.cliente = objeto
        leitor.parar()
        self.assertIs(objeto, leitor._falhas_limpeza_subscribe_sem_registro[0][0])
        self.assertEqual("falha_io", leitor._falhas_limpeza_subscribe_sem_registro[0][1])
        self.assertEqual([], self.recursos())

    def test_interrupcao_no_shutdown_preserva_original_e_tenta_cleanup(self):
        cliente, arquivo, objeto = self.par()
        original = KeyboardInterrupt()
        objeto.shutdown.side_effect = original
        self.leitor.cliente = cliente
        with self.assertRaises(KeyboardInterrupt) as capturado:
            self.leitor.parar()
        self.assertIs(original, capturado.exception)
        self.assertTrue(objeto.fechado)
        self.assertFalse(objeto.arquivo.closed)
        self.assertIsNone(self.leitor.cliente)
        arquivo.close()


if __name__ == "__main__":
    unittest.main()

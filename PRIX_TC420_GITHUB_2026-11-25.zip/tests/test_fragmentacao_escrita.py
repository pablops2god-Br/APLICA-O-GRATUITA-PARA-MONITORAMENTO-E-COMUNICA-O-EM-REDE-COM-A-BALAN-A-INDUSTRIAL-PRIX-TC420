"""2B.8: adversários e predicado agregado com estados reais do registro."""
import gc
import unittest
from unittest.mock import Mock

from prototipos.consultas_intervalos import RegistroConsultasExperimental
from rede import servidor as s
from medir_fragmentacao_escrita import estatistica
from test_guarda_sockets_integrada import SocketFalso


class FragmentacaoEscrita(unittest.TestCase):
    def setUp(self):
        self.r = RegistroConsultasExperimental()

    def test_percentis_nearest_rank(self):
        valores = estatistica(range(1, 101))
        self.assertEqual(valores['p95_s'], 95)
        self.assertEqual(valores['p99_s'], 99)
        self.assertEqual(valores['mediana_s'], 50.5)

    def test_pontes_fundem_sem_revogar_tokens(self):
        tokens = [self.r.reservar_criacao_socket() for _ in range(400)]
        for t in reversed(tokens[::2]):
            self.r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True)
        self.assertEqual(len(self.r._reservas_socket.intervalos), 200)
        for t in tokens[1::2]:
            self.r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=True)
        self.assertEqual(len(self.r._reservas_socket.intervalos), 1)
        gc.collect()
        for t in tokens:
            self.assertTrue(self.r.fechar_socket(t))
        self.assertEqual(self.r.obter_situacao(), s.RegistroTrabalhadores.obter_situacao(self.r))

    def test_incerta_intercalada_impede_agregado_e_historico(self):
        c = s.ControleCicloServidor()
        c.tentar_iniciar(self.r)
        for i in range(100):
            t = self.r.reservar_criacao_socket()
            self.r.resolver_falha_criacao_socket(t, sem_alocacao_comprovada=i % 2 == 0)
        self.r.bloquear_criacao()
        c.finalizar(self.r)
        self.assertFalse(self.r.encerramento_confirmado())
        self.assertFalse(c._obter_situacao_historica(1)['encerramento_confirmado'])
        self.assertFalse(c._compactar_ciclo(1))

    def test_erro_close_nao_vira_resultado_resolvido(self):
        t = self.r.reservar_criacao_socket()
        sock = SocketFalso()
        sock.close = Mock(side_effect=OSError())
        self.r.anexar_socket(t, sock)
        self.r.publicar_socket(t)
        self.r.encerrar_uso_socket(t)
        self.assertFalse(self.r.fechar_socket(t))
        self.r.bloquear_criacao()
        self.assertFalse(self.r.encerramento_confirmado())
        self.assertIs(self.r._reservas_socket.fortes[t.criacao_id].recurso, sock)
        self.assertEqual(self.r.obter_situacao(), s.RegistroTrabalhadores.obter_situacao(self.r))


if __name__ == '__main__':
    unittest.main()

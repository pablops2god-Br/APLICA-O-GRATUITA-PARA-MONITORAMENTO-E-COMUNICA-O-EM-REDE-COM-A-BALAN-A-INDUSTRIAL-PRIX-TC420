"""Persistência optativa sem balança, cofre real ou arquivos reais."""
import unittest
import ast
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch, sentinel

from config.configuracao import guardar_login_automatico
from interface.conexao import JanelaConexao


class PersistenciaLoginCliente(unittest.TestCase):
    def test_assumir_grava_somente_com_opcao_e_resultado_positivo(self):
        arvore = ast.parse(Path('interface/janela.py').read_text(encoding='utf-8'))
        confirmar = next(n for n in ast.walk(arvore)
                         if isinstance(n, ast.FunctionDef) and n.name == 'confirmar')
        for marcado, resultado in ((False, object()), (True, None), (True, object())):
            with self.subTest(marcado=marcado, sucesso=bool(resultado)), patch(
                'config.configuracao.guardar_login_automatico', return_value=True
            ) as guardar:
                monitor = SimpleNamespace(
                    ao_promover=lambda *args: resultado, promocao_em_andamento=False,
                    _iniciar_promocao=lambda trabalho, janela: trabalho())
                ambiente = dict(self=monitor, janela=object(),
                    salvar_login_var=SimpleNamespace(get=lambda: marcado),
                    entry_ip=SimpleNamespace(get=lambda: 'localhost'),
                    entry_usuario=SimpleNamespace(get=lambda: 'operador_teste'),
                    entry_senha=SimpleNamespace(get=lambda: sentinel.segredo))
                exec(compile(ast.Module(body=[confirmar], type_ignores=[]),
                             'confirmar', 'exec'), ambiente)
                ambiente['confirmar']()
                self.assertEqual(guardar.call_count, int(marcado and bool(resultado)))

    def test_descoberta_respeita_opcao_sem_login_na_balanca(self):
        janela = JanelaConexao.__new__(JanelaConexao)
        janela.infraestrutura_cliente = None
        janela.ao_encontrar_servidor = lambda *args: None
        janela._contexto_arquivos = sentinel.contexto
        for salvar in (False, True):
            with self.subTest(salvar=salvar), patch(
                'interface.conexao.buscar_servidor', return_value='localhost'
            ), patch('config.configuracao.guardar_login_automatico') as guardar, patch(
                'interface.conexao.WebTC420'
            ) as web:
                resultado = janela._conectar_operacional(
                    'TC420', 'localhost', 42100, 'operador_teste', sentinel.segredo, salvar)
                self.assertEqual(resultado, {'servidor': 'localhost'})
                self.assertEqual(guardar.call_count, int(salvar))
                web.assert_not_called()

    def test_preserva_metadados_e_nao_envia_senha_ao_json(self):
        with patch('config.configuracao.carregar_configuracao', return_value={
            'nome_rede': 'Balança de teste', 'porta': 42123
        }), patch('config.configuracao.salvar_senha', return_value=True) as cofre, patch(
            'config.configuracao.salvar_configuracao'
        ) as salvar:
            self.assertTrue(guardar_login_automatico('localhost', 'operador_teste', sentinel.segredo))
            cofre.assert_called_once_with('operador_teste', sentinel.segredo)
            self.assertEqual(salvar.call_args.kwargs['porta'], 42123)
            self.assertEqual(salvar.call_args.kwargs['nome_rede'], 'Balança de teste')
            self.assertNotIn(sentinel.segredo, salvar.call_args.kwargs.values())

    def test_falha_do_cofre_nao_habilita_opcao(self):
        with patch('config.configuracao.carregar_configuracao', return_value={}), patch(
            'config.configuracao.salvar_senha', return_value=False
        ), patch('config.configuracao.salvar_configuracao') as salvar:
            self.assertFalse(guardar_login_automatico('localhost', 'operador_teste', sentinel.segredo))
            salvar.assert_not_called()

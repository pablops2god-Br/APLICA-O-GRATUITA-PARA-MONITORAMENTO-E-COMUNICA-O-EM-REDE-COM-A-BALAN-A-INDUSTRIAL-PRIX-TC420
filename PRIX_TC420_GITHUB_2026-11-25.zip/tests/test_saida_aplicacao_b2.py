# Testes de saida aplicacao b2: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""B2 operacional: registros reais, IO falso, eventos e threads de ensaio."""
import threading
from contextlib import ExitStack
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from interface.saida_aplicacao import SaidaAplicacao
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
from rede.retentativas_cliente import PartidasRetentativasCliente
from rede import servidor
from test_recursos_cliente_integrados import SocketLeituraFalso
import test_infraestrutura_cliente as montagem
import test_login_manual_http as manual
import test_auditoria_encerramento_interface as auditoria


# Grupo de 40 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class SaidaAplicacaoB2(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro = servidor.RegistroTentativasAplicacao()
        self.saida = SaidaAplicacao(prazo=.12, intervalo=.005)
        self.saida.configurar(self.infra, self.registro)
        self.callback = self.saida.vincular('ensaio')
        self.eventos, self.threads, self.erros = [], [], []
        self.controle = servidor.ControleCicloServidor()
        p = patch.object(servidor, 'controle_ciclo_servidor', self.controle)
        p.start()
        self.addCleanup(p.stop)
        p = patch.object(servidor, 'evento_parada_servidor', threading.Event())
        p.start()
        self.addCleanup(p.stop)
        self.addCleanup(self.limpar)

    def evento(self):
        e = threading.Event()
        self.eventos.append(e)
        return e

    def limpar(self):
        for e in self.eventos:
            e.set()
        servidor.evento_parada_servidor.set()
        for t in self.threads:
            t.join(2)
        for item in self.saida._threads:
            if isinstance(item['thread'], threading.Thread):
                item['thread'].join(2)
        if self.saida._coordenacao is not None:
            self.saida._coordenacao.join(2)
        for item in self.saida._tarefas.values():
            if item['thread'] is not None:
                item['thread'].join(2)
        self.assertEqual([], self.erros)

    def tarefa(self, funcao):
        def executar():
            try:
                funcao()
            except BaseException as erro:
                self.erros.append(erro)
        t = threading.Thread(target=executar, daemon=True)
        t.start()
        self.threads.append(t)
        return t

    def esperar(self, saida=None):
        saida = saida or self.saida
        self.assertIsNotNone(saida._coordenacao)
        saida._coordenacao.join(2)
        self.assertFalse(saida._coordenacao.is_alive())
        return saida.obter_situacao()

    def confirmado(self, saida=None):
        r = self.esperar(saida)
        self.assertTrue(r['parada_operacional_confirmada'], r)
        self.assertEqual('confirmado_operacional', r['estado'])
        self.assertFalse(r['encerramento_confirmado'])
        self.assertFalse(r['encerramento_global_confirmado'])
        return r

    def leitor(self):
        leitor = LeitorDadosServidor(ip_servidor='simulado', infraestrutura_cliente=self.infra)
        entrou = self.evento()
        def rotina():
            entrou.set()
            leitor._parada.wait(2)
        with patch.object(leitor, '_manter_atualizado', side_effect=rotina):
            leitor.iniciar()
        self.threads.append(leitor.thread)
        self.assertTrue(entrou.wait(1))
        return leitor

    def ciclo(self, contexto=None, bloqueado=False, com_socket=False):
        contexto = contexto or servidor.ContextoCicloServidor()
        self.saida.acompanhar_contexto(contexto)
        trabalhadores = servidor.RegistroTrabalhadores()
        self.assertTrue(self.controle.tentar_iniciar(trabalhadores))
        contexto.registrar_reserva(trabalhadores.ciclo_id)
        entrou, liberar, retornou = self.evento(), self.evento(), self.evento()
        reserva = None
        if com_socket:
            bruto = SocketLeituraFalso()
            bruto.fileno = lambda: -1 if bruto.fechado else 1
            bruto.shutdown.side_effect = lambda _como: liberar.set()
            reserva = trabalhadores.reservar_criacao_socket()
            trabalhadores.anexar_socket(reserva, bruto)
            trabalhadores.publicar_socket(reserva)
            self.socket_ciclo = bruto
        def handler():
            entrou.set()
            liberar.wait(2)
            if reserva is not None:
                trabalhadores.encerrar_uso_socket(reserva)
        t = threading.Thread(target=handler, daemon=True)
        trabalhadores.registrar_e_iniciar(t)
        self.threads.append(t)
        self.assertTrue(entrou.wait(1))
        def coordenador():
            servidor.evento_parada_servidor.wait(2)
            trabalhadores.bloquear_criacao()
            if not bloqueado:
                liberar.set()
                t.join(1)
            trabalhadores.limpar_sockets()
            self.controle.finalizar(trabalhadores)
            contexto.registrar_retorno_coordenador()
            retornou.set()
        self.saida.iniciar_thread(threading.Thread(target=coordenador, daemon=True))
        return contexto, trabalhadores, liberar, retornou

    def test_01_cliente_normal(self):
        leitor = self.leitor()
        self.assertTrue(self.callback())
        self.confirmado()
        self.assertFalse(leitor.thread.is_alive())
        self.assertTrue(self.infra.obter_atividades_permanentes()['atividades'][0]['thread_terminada'])

    def test_pedido_do_monitor_inicia_coordenacao_e_conclui_interface(self):
        # O pedido deve partir a limpeza real antes de o polling poder concluir a janela.
        leitor = self.leitor()
        fila, concluir, informar = [], Mock(), Mock()
        self.saida.conectar_interface(
            self.callback, lambda _prazo, acao: fila.append(acao), concluir, informar)

        self.assertTrue(self.callback())
        self.assertIsNotNone(self.saida._coordenacao.ident)
        self.confirmado()
        self.assertFalse(leitor.thread.is_alive())
        self.assertTrue(fila)
        while fila:
            fila.pop(0)()

        concluir.assert_called_once_with()
        informar.assert_not_called()

    def test_02_principal_manual_interface_so_fecha_apos_evidencia(self):
        fx = manual.LoginManualHttp()
        fx.setUp()
        self.addCleanup(fx.doCleanups)
        janela = fx.criar_janela(self.infra, saida_aplicacao=self.saida)
        janela.monitor = Mock()
        self.ciclo()
        self.assertTrue(janela.encerrar_aplicacao())
        self.assertFalse(janela.root.destruida)
        self.confirmado()
        janela.verificar_finalizacao()
        janela.monitor.concluir_fechamento.assert_called_once_with()
        self.assertTrue(janela.root.destruida)

    def test_03_principal_automatico_destino_por_ciclo(self):
        contexto, trabalhadores, _liberar, retornou = self.ciclo()
        self.callback()
        self.confirmado()
        self.assertTrue(retornou.is_set())
        self.assertTrue(trabalhadores.encerramento_confirmado())
        self.assertTrue(servidor.avaliar_encerramento_tentativa(contexto)['encerramento_confirmado'])

    def test_04_promocao_considera_leitor_antigo_e_servidor(self):
        leitor = self.leitor()
        self.infra.registro_recursos.promover(leitor.recursos_cliente.geracao_id)
        self.ciclo()
        self.callback()
        self.confirmado()
        self.assertFalse(leitor.thread.is_alive())
        self.assertIn(leitor, self.saida._leitores)

    def test_05_rebaixamento_retem_novo_leitor(self):
        contexto, _trabalhadores, liberar, _retornou = self.ciclo()
        liberar.set()
        servidor.evento_parada_servidor.set()
        for item in self.saida._threads:
            item['thread'].join(1)
        leitor = self.leitor()
        self.callback()
        self.confirmado()
        self.assertFalse(leitor.thread.is_alive())
        self.assertIs(contexto, self.saida._contextos[0])

    def test_06_inicializacao_simultanea_fica_acompanhada(self):
        entrou, liberar = self.evento(), self.evento()
        def inicializar():
            with self.saida.trabalho():
                entrou.set()
                liberar.wait(2)
        t = self.tarefa(inicializar)
        self.assertTrue(entrou.wait(1))
        self.callback()
        r = self.esperar()
        self.assertEqual('timeout', r['estado'])
        self.assertIn('inicializacoes_em_curso', r['pendencias'])
        with self.assertRaisesRegex(RuntimeError, 'encerramento_em_curso'):
            with self.saida.trabalho():
                self.fail('trabalho tardio admitido')
        liberar.set()
        t.join(1)
        self.assertTrue(self.callback())
        self.confirmado()

    def test_07_handler_bloqueado_nao_confirma_por_retorno_servidor(self):
        contexto, trabalhadores, liberar, retornou = self.ciclo(bloqueado=True)
        self.callback()
        self.assertTrue(retornou.wait(1))
        r = self.esperar()
        self.assertEqual('timeout', r['estado'])
        self.assertFalse(r['parada_operacional_confirmada'])
        self.assertFalse(trabalhadores.encerramento_confirmado())
        liberar.set()
        for t in trabalhadores.threads:
            t.join(1)
        self.assertTrue(self.callback())
        self.confirmado()

    def test_08_retentativa_ativa(self):
        recursos = RecursosLeitorCliente(self.infra)
        partidas = PartidasRetentativasCliente(self.infra, recursos._geracao_retentativas)
        token = partidas.admitir()
        entrou, liberar = self.evento(), self.evento()
        def rotina():
            entrou.set()
            liberar.wait(2)
        threads = []
        def construir(alvo):
            t = threading.Thread(target=alvo, daemon=True)
            threads.append(t)
            self.threads.append(t)
            return t
        partidas.partir(token, construir, rotina)
        self.assertTrue(entrou.wait(1))
        self.callback()
        r = self.esperar()
        self.assertIn('retentativas_pendentes', r['pendencias'])
        self.assertFalse(r['parada_operacional_confirmada'])
        liberar.set()
        threads[0].join(1)
        self.callback()
        self.confirmado()

    def test_09_http_pendente(self):
        contexto = self.infra.preparar_http_inicial()
        registro = self.infra.registro_http
        token = registro.admitir(contexto, 'login')
        entrou, liberar = self.evento(), self.evento()
        t = self.tarefa(lambda: registro.executar(token, lambda: (entrou.set(), liberar.wait(2))))
        self.assertTrue(entrou.wait(1))
        self.callback()
        r = self.esperar()
        self.assertIn('http_pendente', r['pendencias'])
        self.assertFalse(r['parada_operacional_confirmada'])
        liberar.set()
        t.join(1)
        self.callback()
        self.confirmado()

    def test_10_limpeza_falha_preserva_diagnostico(self):
        recursos = RecursosLeitorCliente(self.infra)
        bruto = SocketLeituraFalso()
        bruto.erro_close = OSError('falha_simulada')
        recursos.abrir_socket(lambda: bruto)
        self.callback()
        r = self.esperar()
        self.assertEqual('falha', r['estado'])
        self.assertFalse(r['parada_operacional_confirmada'])
        self.assertTrue(self.infra.registro_recursos.obter_retrato()['recursos'][0]['erros_limpeza'])
        self.assertNotIn('falha_simulada', str(r))
        bruto.erro_close = None
        bruto.close()

    def test_11_timeout_nao_fecha_tk(self):
        entrou, liberar = self.evento(), self.evento()
        self.tarefa(lambda: self.saida.executar(lambda: (entrou.set(), liberar.wait(2))))
        self.assertTrue(entrou.wait(1))
        fila, concluido, avisos = [], Mock(), Mock()
        self.saida.conectar_interface(self.callback, lambda ms, cb: fila.append(cb), concluido, avisos)
        self.callback()
        self.esperar()
        while fila:
            fila.pop(0)()
        concluido.assert_not_called()
        avisos.assert_called_once_with('timeout')

    def test_12_termino_posterior_timeout_reavalia_sem_duplicar_cleanup(self):
        recursos = RecursosLeitorCliente(self.infra)
        bruto = SocketLeituraFalso()
        entrou, liberar = self.evento(), self.evento()
        close = bruto.close
        def suspender():
            entrou.set()
            liberar.wait(2)
            close()
        bruto.close = Mock(side_effect=suspender)
        recursos.abrir_socket(lambda: bruto)
        self.callback()
        self.assertTrue(entrou.wait(1))
        self.assertEqual('timeout', self.esperar()['estado'])
        self.assertTrue(self.callback())
        self.assertEqual('timeout', self.esperar()['estado'])
        bruto.close.assert_called_once_with()
        liberar.set()
        for t in self.saida._tarefas.values():
            t['thread'].join(1)
        self.callback()
        self.confirmado()
        bruto.close.assert_called_once_with()

    def test_13_dois_sim_uma_coordenacao(self):
        entrou, liberar = self.evento(), self.evento()
        self.tarefa(lambda: self.saida.executar(lambda: (entrou.set(), liberar.wait(2))))
        self.assertTrue(entrou.wait(1))
        self.callback()
        coordenacao = self.saida._coordenacao
        self.assertFalse(self.callback())
        self.assertIs(coordenacao, self.saida._coordenacao)
        self.assertEqual(1, self.saida.obter_situacao()['tentativa'])
        liberar.set()
        self.confirmado()

    def test_14_cancelar_nenhuma_parada(self):
        fx = auditoria.FluxoAtualAuditado()
        monitor = fx.monitor(None, self.callback)
        monitor.confirmar_fechamento()
        self.assertFalse(self.saida.parada_solicitada)
        self.assertIsNone(self.saida._coordenacao)
        self.assertFalse(self.infra.registro_recursos.obter_retrato()['admissao_fechada'])

    def test_15_saida_normal_e_reabertura_simulada(self):
        ocupados = set()
        class SocketPorta(SocketLeituraFalso):
            def __init__(self):
                if 'porta_simulada' in ocupados:
                    raise OSError('porta_simulada_ocupada')
                super().__init__()
                ocupados.add('porta_simulada')
            def close(self):
                super().close()
                ocupados.discard('porta_simulada')
        RecursosLeitorCliente(self.infra).abrir_socket(SocketPorta)
        self.callback()
        self.confirmado()
        self.assertEqual(set(), ocupados)
        novo = SocketPorta()
        novo.close()

    def test_gate_de_partida_rejeita_thread_tardia(self):
        self.callback()
        self.confirmado()
        t = Mock()
        self.assertFalse(self.saida.iniciar_thread(t))
        t.start.assert_not_called()

    def test_partida_reservada_antes_da_saida_impede_confirmacao(self):
        entrou, liberar = self.evento(), self.evento()
        class PartidaSuspensa:
            def start(self):
                entrou.set()
                liberar.wait(2)
            def is_alive(self):
                return False
        t = self.tarefa(lambda: self.saida.iniciar_thread(PartidaSuspensa()))
        self.assertTrue(entrou.wait(1))
        self.callback()
        self.assertIn('thread_acompanhada_ativa', self.esperar()['pendencias'])
        liberar.set()
        t.join(1)
        self.callback()
        self.confirmado()

    def test_ciclo_tardio_nao_apaga_pedido_anterior(self):
        contexto = servidor.ContextoCicloServidor()
        self.saida.acompanhar_contexto(contexto)
        self.callback()
        with patch('builtins.print'):
            servidor.iniciar_servidor(SimpleNamespace(token=object()), contexto_ciclo=contexto)
        self.confirmado()
        self.assertIsNone(contexto.ciclo_id)
        self.assertTrue(contexto.coordenador_retornou.is_set())

    def test_ciclo_antigo_nao_para_novo_ciclo(self):
        antigo, trabalhadores, liberar, _ = self.ciclo()
        liberar.set()
        servidor.evento_parada_servidor.set()
        for item in self.saida._threads:
            item['thread'].join(1)
        self.assertTrue(servidor.avaliar_encerramento_tentativa(antigo)['encerramento_confirmado'])
        novo = servidor.RegistroTrabalhadores()
        self.assertTrue(self.controle.tentar_iniciar(novo))
        servidor.evento_parada_servidor.clear()
        self.assertFalse(servidor.solicitar_parada_ciclo(antigo.ciclo_id))
        self.assertFalse(servidor.evento_parada_servidor.is_set())
        novo.bloquear_criacao()
        self.controle.finalizar(novo)

    def test_tk_notificado_somente_no_executor_da_interface(self):
        principal = threading.get_ident()
        fila, chamadas = [], []
        self.saida.conectar_interface(
            self.callback, lambda ms, cb: fila.append(cb),
            lambda: chamadas.append(threading.get_ident()))
        self.callback()
        self.confirmado()
        while fila:
            fila.pop(0)()
        self.assertEqual([principal], chamadas)

    def test_cleanup_nao_ocupa_thread_tk_ou_lock_do_dono(self):
        recursos = RecursosLeitorCliente(self.infra)
        bruto = SocketLeituraFalso()
        entrou, liberar = self.evento(), self.evento()
        ids = []
        original = bruto.close
        def close():
            ids.append(threading.get_ident())
            entrou.set()
            liberar.wait(2)
            original()
        bruto.close = close
        recursos.abrir_socket(lambda: bruto)
        self.callback()
        self.assertTrue(entrou.wait(1))
        self.assertNotEqual(threading.get_ident(), ids[0])
        self.assertTrue(self.saida._lock.acquire(blocking=False))
        self.saida._lock.release()
        liberar.set()
        self.confirmado()

    def test_falha_operacional_e_cleanup_preservam_excecao_original(self):
        recursos = RecursosLeitorCliente(self.infra)
        bruto = SocketLeituraFalso()
        cliente = recursos.abrir_socket(lambda: bruto)
        original = ValueError('operacao_simulada')
        bruto.erro_close = OSError('cleanup_simulado')
        def falhar(_):
            raise original
        with self.assertRaises(ValueError) as recebido:
            self.infra.registro_recursos.usar(cliente.recurso_id, falhar)
        self.assertIs(original, recebido.exception)
        self.callback()
        self.assertFalse(self.esperar()['parada_operacional_confirmada'])
        bruto.erro_close = None
        bruto.close()

    def test_shutdown_desbloqueia_socket_de_handler_acompanhado(self):
        self.ciclo(com_socket=True)
        self.callback()
        self.confirmado()
        self.socket_ciclo.shutdown.assert_called_once()
        self.assertTrue(self.socket_ciclo.fechado)
        self.assertEqual(1, self.socket_ciclo.close_chamadas)

    def test_clear_tardio_do_servidor_nao_perde_saida(self):
        contexto = servidor.ContextoCicloServidor()
        self.saida.acompanhar_contexto(contexto)
        entrou, liberar = self.evento(), self.evento()
        evento = servidor.evento_parada_servidor
        limpar = evento.clear
        def clear():
            entrou.set()
            liberar.wait(2)
            limpar()
        with patch.object(evento, 'clear', side_effect=clear), patch('builtins.print'):
            t = threading.Thread(target=lambda: servidor.iniciar_servidor(
                SimpleNamespace(token=object()), contexto_ciclo=contexto), daemon=True)
            self.saida.iniciar_thread(t)
            self.threads.append(t)
            self.assertTrue(entrou.wait(1))
            self.callback()
            liberar.set()
            self.confirmado()
        self.assertTrue(evento.is_set())
        self.assertFalse(t.is_alive())

    def servidor_simulado(self, _web, *, contexto_ciclo=None, **_kwargs):
        trabalhadores = servidor.RegistroTrabalhadores()
        self.assertTrue(self.controle.tentar_iniciar(trabalhadores))
        contexto_ciclo.registrar_reserva(trabalhadores.ciclo_id)
        t = threading.Thread(target=lambda: servidor.evento_parada_servidor.wait(2), daemon=True)
        trabalhadores.registrar_e_iniciar(t)
        self.threads.append(t)
        servidor.evento_parada_servidor.wait(2)
        trabalhadores.bloquear_criacao()
        t.join(1)
        trabalhadores.limpar_sockets()
        self.controle.finalizar(trabalhadores)
        contexto_ciclo.registrar_retorno_coordenador()

    def test_main_principal_automatico_real_com_ciclo_simulado(self):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        fx.env['buscar_servidor'].return_value = None
        fx.env['threading'] = threading
        fx.env['iniciar_servidor'] = self.servidor_simulado
        def durante(monitor):
            saida = monitor.saida_aplicacao
            self.assertTrue(saida._contextos)
            self.assertTrue(monitor.ao_fechar())
            self.confirmado(saida)
        fx.durante_monitor = durante
        fx.env['iniciar']()
        self.assertEqual(1, len(fx.monitores))

    def test_main_promocao_real_saida_considera_ciclo_e_leitor(self):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        fx.env['buscar_servidor'].return_value = None
        fx.env['threading'] = threading
        fx.env['iniciar_servidor'] = self.servidor_simulado
        def durante(monitor):
            resultado = monitor.ao_promover_automaticamente()
            self.assertIsNotNone(resultado)
            self.assertTrue(monitor.ao_fechar())
            self.confirmado()
            self.assertEqual(1, len(self.saida._contextos))
        fx.durante_monitor = durante
        fx.env['iniciar_como_cliente']('simulado', infraestrutura_cliente=self.infra,
                                     registro_tentativas=self.registro, saida_aplicacao=self.saida)

    def test_promocao_suspensa_na_descoberta_nao_inicia_depois_da_saida(self):
        fx = montagem.InfraestruturaCliente()
        fx.setUp()
        entrou, liberar = self.evento(), self.evento()
        def descobrir(**_kwargs):
            entrou.set()
            liberar.wait(2)
            return None
        fx.env['buscar_servidor'].side_effect = descobrir
        def durante(monitor):
            t = self.tarefa(monitor.ao_promover_automaticamente)
            self.assertTrue(entrou.wait(1))
            monitor.ao_fechar()
            liberar.set()
            t.join(1)
            self.confirmado()
            fx.env['iniciar_servidor'].assert_not_called()
        fx.durante_monitor = durante
        fx.env['iniciar_como_cliente']('simulado', infraestrutura_cliente=self.infra,
                                     registro_tentativas=self.registro, saida_aplicacao=self.saida)

    def test_start_incerto_sem_entrada_nao_e_ausencia(self):
        class ThreadIncerta:
            ident = None
            def start(self):
                raise RuntimeError('start_simulado')
            def is_alive(self):
                return False
        with self.assertRaises(RuntimeError):
            self.saida.iniciar_thread(ThreadIncerta())
        self.callback()
        self.assertIn('partida_incerta', self.esperar()['pendencias'])

    def test_gates_fecham_antes_de_solicitar_cleanup(self):
        leitor = self.leitor()
        parar = leitor.parar
        def conferir():
            self.assertTrue(self.infra.registro_recursos.obter_retrato()['admissao_fechada'])
            self.assertTrue(self.infra.registro_retentativas.obter_retrato()['admissao_fechada'])
            self.assertTrue(self.registro.obter_retrato()['admissao_fechada'])
            parar()
        with patch.object(leitor, 'parar', side_effect=conferir):
            self.callback()
            self.confirmado()

    def test_poll_antigo_nao_duplica_conclusao_apos_retentativa(self):
        entrou, liberar = self.evento(), self.evento()
        t = self.tarefa(lambda: self.saida.executar(lambda: (entrou.set(), liberar.wait(2))))
        self.assertTrue(entrou.wait(1))
        fila, concluir = [], Mock()
        self.saida.conectar_interface(self.callback, lambda ms, cb: fila.append(cb), concluir)
        self.callback()
        self.esperar()
        liberar.set()
        t.join(1)
        self.callback()
        self.confirmado()
        while fila:
            fila.pop(0)()
        concluir.assert_called_once_with()

    def executar_servidor_real(self, interromper_partida=False):
        contexto = servidor.ContextoCicloServidor()
        tentativa = self.registro.admitir(contexto)
        self.registro.marcar_iniciando(tentativa)
        self.saida.acompanhar_contexto(contexto)
        iniciou, liberar = self.evento(), self.evento()
        original = servidor.RegistroTrabalhadores
        class RegistroPausado(original):
            def registrar_e_iniciar(registro, thread):
                resultado = super().registrar_e_iniciar(thread)
                if len(registro.threads) == 1:
                    iniciou.set()
                    if interromper_partida:
                        liberar.wait(2)
                return resultado
        def trabalhador(*_args, **_kwargs):
            servidor.evento_parada_servidor.wait(2)
        def rotina():
            self.registro.registrar_entrada_execucao(tentativa)
            servidor.iniciar_servidor(SimpleNamespace(token=object()), contexto_ciclo=contexto)
        with ExitStack() as stack:
            stack.enter_context(patch.object(servidor, 'RegistroTrabalhadores', RegistroPausado))
            for nome in ('servidor_tcp', 'servidor_descoberta', 'ler_tc420'):
                stack.enter_context(patch.object(servidor, nome, side_effect=trabalhador))
            stack.enter_context(patch('builtins.print'))
            t = threading.Thread(target=rotina, daemon=True)
            self.saida.iniciar_servidor_thread(t, contexto, self.registro, tentativa)
            self.threads.append(t)
            self.registro.marcar_iniciada(tentativa)
            self.assertTrue(iniciou.wait(1))
            self.callback()
            liberar.set()
            self.confirmado()
        self.assertFalse(t.is_alive())
        self.assertTrue(servidor.avaliar_encerramento_tentativa(contexto)['encerramento_confirmado'])

    def test_servidor_real_coordena_trabalhadores_tcp_udp_http_falsos(self):
        self.executar_servidor_real()

    def test_fechamento_entre_partidas_nao_faz_join_de_thread_recusada(self):
        self.executar_servidor_real(interromper_partida=True)

    def test_handle_incerto_e_limpo_sem_regularizar_associacao(self):
        dono = self.infra.preparar_descoberta()
        bruto = SocketLeituraFalso()
        def falhar(_token, alocar):
            alocar()
            raise ValueError('publicacao_simulada')
        with patch.object(self.infra.registro_recursos, 'criar', side_effect=falhar):
            with self.assertRaises(ValueError):
                dono.abrir_socket(lambda: bruto)
        self.assertTrue(dono.obter_publicacoes_pendentes())
        self.callback()
        r = self.esperar()
        self.assertEqual([], dono.obter_publicacoes_pendentes())
        self.assertTrue(bruto.fechado)
        self.assertFalse(r['parada_operacional_confirmada'])
        self.assertIn('recursos_cliente_pendentes', r['pendencias'])

    def test_shutdown_e_cleanup_falhos_preservam_primeiro_erro(self):
        contexto, trabalhadores, _liberar, _retornou = self.ciclo(com_socket=True)
        original, adicional = ValueError('interrupcao_simulada'), OSError('limpeza_simulada')
        self.socket_ciclo.shutdown.side_effect = original
        with patch.object(trabalhadores, 'limpar_sockets', side_effect=adicional):
            with self.assertRaises(ValueError) as recebido:
                servidor.solicitar_parada_ciclo(contexto.ciclo_id)
        self.assertIs(original, recebido.exception)
        self.assertIs(adicional, original.__cause__)

    def test_registro_novo_nao_pode_ser_instalado_depois_da_saida(self):
        self.callback()
        self.confirmado()
        with self.assertRaisesRegex(RuntimeError, 'encerramento_em_curso'):
            self.saida.configurar(self.infra, servidor.RegistroTentativasAplicacao())

    def test_gate_falho_nao_impede_parada_dos_outros_donos(self):
        leitor = self.leitor()
        with patch.object(self.infra.registro_http, 'fechar_admissao', side_effect=OSError('gate_simulado')):
            self.callback()
            r = self.esperar()
        self.assertEqual('falha', r['estado'])
        self.assertFalse(leitor.thread.is_alive())
        self.assertIn('falha_bloqueio_admissao', r['pendencias'])
        self.callback()
        self.confirmado()

    def test_fabrica_do_coordenador_falha_sem_simular_conclusao(self):
        with patch('interface.saida_aplicacao.Thread', side_effect=RuntimeError('fabrica_simulada')):
            self.assertTrue(self.callback())
        r = self.saida.obter_situacao()
        self.assertEqual('falha', r['estado'])
        self.assertFalse(r['parada_operacional_confirmada'])
        self.assertTrue(self.callback())
        self.confirmado()

    def test_fabrica_de_cleanup_falha_e_nova_tentativa_e_segura(self):
        RecursosLeitorCliente(self.infra).abrir_socket(SocketLeituraFalso)
        def construir(*args, **kwargs):
            if kwargs['target'].__name__ == 'executar':
                raise RuntimeError('fabrica_cleanup_simulada')
            return threading.Thread(*args, **kwargs)
        with patch('interface.saida_aplicacao.Thread', side_effect=construir):
            self.callback()
            self.assertEqual('falha', self.esperar()['estado'])
        self.callback()
        self.confirmado()

    def test_start_incerto_de_cleanup_nao_e_duplicado(self):
        RecursosLeitorCliente(self.infra).abrir_socket(SocketLeituraFalso)
        chamadas = []
        class Incerta:
            ident = None
            def start(self):
                chamadas.append(True)
                raise RuntimeError('start_cleanup_simulado')
            def is_alive(self):
                return False
            def join(self, _prazo):
                pass
        def construir(*args, **kwargs):
            if kwargs['target'].__name__ == 'executar':
                return Incerta()
            return threading.Thread(*args, **kwargs)
        with patch('interface.saida_aplicacao.Thread', side_effect=construir):
            self.callback()
            self.assertEqual('falha', self.esperar()['estado'])
            self.callback()
            self.assertEqual('falha', self.esperar()['estado'])
        self.assertEqual([True], chamadas)

    def test_leitor_com_partida_tardia_nao_reabre_execucao(self):
        leitor = LeitorDadosServidor(ip_servidor='simulado', infraestrutura_cliente=self.infra)
        entrou, liberar = self.evento(), self.evento()
        class ThreadSuspensa(threading.Thread):
            def start(self):
                entrou.set()
                liberar.wait(2)
                super().start()
        with patch('rede.lerdadosserver.threading', SimpleNamespace(Thread=ThreadSuspensa)), \
             patch('rede.lerdadosserver.buscar_servidor') as descobrir:
            t = self.tarefa(leitor.iniciar)
            self.assertTrue(entrou.wait(1))
            self.callback()
            self.assertFalse(self.esperar()['parada_operacional_confirmada'])
            liberar.set()
            t.join(1)
            self.threads.append(leitor.thread)
            leitor.thread.join(1)
            self.callback()
            self.confirmado()
            descobrir.assert_not_called()
        self.assertFalse(leitor.executando)
        self.assertTrue(leitor._parada.is_set())

# Testes de auditoria cobertura http: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.7: auditoria somente de fontes, transporte simulado e evidências.

Os testes de lacunas aprovam quando comprovam o problema; o teste visual 14
passou a exigir a correção L3-B1.10. Não há comunicação com equipamento.
"""
import ast
import json
from pathlib import Path
from types import SimpleNamespace
import threading
import unittest
from unittest.mock import Mock, patch
from uuid import uuid4

import requests

from rede import infraestrutura_cliente as modulo
from tc420.web import WebTC420
from test_registro_automatico import carregar_fluxos
import test_approval_http_integrado as approval
import test_infraestrutura_cliente as fixtures
import test_login_manual_http as manual


RAIZ = Path(__file__).resolve().parents[1]


def fontes_operacionais():
    return sorted(p for p in RAIZ.rglob("*.py")
                  if not any(x in p.relative_to(RAIZ).parts
                             for x in ("tests", "Navegador model", "__pycache__", ".git",
                                       ".venv-build", "build", "dist")))


def inventario_http():
    """Inventário estático de APIs importadas, sem ler/exibir literais sensíveis.

    Resolve aliases de importação e funções importadas; não é análise universal
    de dispatch dinâmico, dependências/OS ou código externo não disponível.
    """
    resultado = []
    modulos_http = {"requests", "urllib", "urllib3", "http", "httpx", "aiohttp", "httplib"}
    metodos = {"get", "post", "put", "patch", "delete", "head", "options", "request",
               "urlopen", "urlretrieve", "Session", "session", "ClientSession", "Client",
               "PoolManager", "HTTPConnection", "HTTPSConnection"}
    for caminho in fontes_operacionais():
        arvore = ast.parse(caminho.read_text(encoding="utf-8"))
        aliases = {}
        for n in ast.walk(arvore):
            if isinstance(n, ast.Import):
                for nome in n.names:
                    if nome.name.split('.')[0] in modulos_http:
                        aliases[nome.asname or nome.name.split('.')[0]] = nome.name if nome.asname else nome.name.split('.')[0]
            elif isinstance(n, ast.ImportFrom) and (n.module or '').split('.')[0] in modulos_http:
                for nome in n.names:
                    aliases[nome.asname or nome.name] = n.module + '.' + nome.name

        class Visitante(ast.NodeVisitor):
            def __init__(self):
                self.escopo = []

            def visit_ClassDef(self, no):
                self.escopo.append(no.name)
                self.generic_visit(no)
                self.escopo.pop()

            visit_FunctionDef = visit_ClassDef
            visit_AsyncFunctionDef = visit_ClassDef

            def visit_Call(self, no):
                partes = ast.unparse(no.func).split('.')
                if partes[0] in aliases:
                    api = '.'.join([aliases[partes[0]]] + partes[1:])
                    if api.split('.')[-1] in metodos:
                        resultado.append((caminho.relative_to(RAIZ).as_posix(),
                                          '.'.join(self.escopo), api))
                self.generic_visit(no)

        Visitante().visit(arvore)
    return sorted(resultado)


# Grupo de 24 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AuditoriaCoberturaHttp(unittest.TestCase):
    fluxo_http = approval.ApprovalHttpIntegrado.fluxo_http
    transporte = approval.ApprovalHttpIntegrado.transporte
    iniciar_thread = approval.ApprovalHttpIntegrado.iniciar_thread
    terminar = approval.ApprovalHttpIntegrado.terminar
    bloquear = approval.ApprovalHttpIntegrado.bloquear
    operacoes = approval.ApprovalHttpIntegrado.operacoes
    negativo = approval.ApprovalHttpIntegrado.negativo

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = modulo.InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_http

    def fixture_main(self):
        fixture = fixtures.InfraestruturaCliente()
        fixture.setUp()
        fixture.env["WebTC420"].side_effect = WebTC420
        fixture.env["buscar_servidor"].return_value = None
        return fixture

    def fixture_manual(self, infra):
        fixture = manual.LoginManualHttp()
        fixture.setUp()
        fixture.env["WebTC420"].side_effect = WebTC420
        return fixture, fixture.criar_janela(infra)

    def conferir_par(self, adaptador):
        self.assertEqual(["POST", "GET"], [r.method for r, _ in adaptador.enviados])
        a, b = self.operacoes()
        self.assertEqual(("login", "approval"), (a["operacao"], b["operacao"]))
        self.assertNotEqual(a["operacao_id"], b["operacao_id"])
        self.assertEqual(a["geracao_id"], b["geracao_id"])
        self.assertEqual(a["atividade_id"], b["atividade_id"])
        self.assertTrue(a["execucao_resolvida"] and b["execucao_resolvida"])

    def test_01_main_automatico_completo_dono_injetado(self):
        fixture = self.fixture_main()
        with self.fluxo_http() as adaptador, patch.object(modulo, "InfraestruturaRegistrosCliente", return_value=self.infra) as criar:
            fixture.env["iniciar"]()
        criar.assert_called_once_with()
        self.assertIs(self.infra, fixture.monitores[0].infraestrutura_cliente)
        self.conferir_par(adaptador)

    def test_02_main_manual_completo_dono_injetado(self):
        fixture = self.fixture_main()
        fixture.env["tentar_login_automatico"] = Mock(return_value=False)
        janelas = []
        def criar(**kwargs):
            _, janela = self.fixture_manual(kwargs["infraestrutura_cliente"])
            janela.root.mainloop = janela.conectar
            janelas.append(janela)
            return janela
        fixture.env["JanelaConexao"] = Mock(side_effect=criar)
        with self.fluxo_http() as adaptador, patch.object(modulo, "InfraestruturaRegistrosCliente", return_value=self.infra):
            fixture.env["iniciar"]()
        self.assertIs(self.infra, janelas[0].infraestrutura_cliente)
        self.conferir_par(adaptador)

    def test_03_main_promocao_completa_dono_do_leitor(self):
        fixture = self.fixture_main()
        resultados = fixture.preparar_promocao()
        with self.fluxo_http() as adaptador, patch.object(modulo, "InfraestruturaRegistrosCliente", return_value=self.infra):
            fixture.env["iniciar"]()
        self.assertEqual(approval.CONFIGURACAO, resultados[0]["configuracao"])
        self.assertEqual(fixture.leitores[0].recursos_cliente.geracao_id, self.operacoes()[0]["geracao_id"])
        self.conferir_par(adaptador)

    def test_04_post_falho_impede_get(self):
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        with self.transporte(status=401) as adaptador:
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        env["definir_configuracao"].assert_not_called()

    def test_05_aprovacao_falha_erro_original_e_resolucao(self):
        contexto = self.infra.preparar_http_inicial()
        web = WebTC420("balanca-simulada")
        web.token = "simulado"
        original = requests.ConnectionError("simulada")
        with self.transporte(erro=original):
            with self.assertRaises(requests.ConnectionError) as capturado:
                self.infra.executar_approval(contexto, web)
        self.assertIs(original, capturado.exception)
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_06_timeout_acompanhado_sem_excecao_serializada(self):
        original = requests.Timeout("simulada")
        with self.transporte(erro=original):
            with self.assertRaises(requests.Timeout) as capturado:
                self.infra.executar_login_automatico(WebTC420("balanca-simulada"), "simulado", "simulado")
        self.assertIs(original, capturado.exception)
        op = self.operacoes()[0]
        self.assertTrue(op["erros_execucao"])
        self.assertTrue(op["execucao_resolvida"])
        json.dumps(self.registro.obter_retrato())  # Nenhum objeto de exceção exposto.

    def test_07_auxiliar_direta_escapa_do_registro_lacuna(self):
        web = WebTC420("balanca-simulada")
        web.token = "simulado"
        with self.transporte() as adaptador:
            self.assertEqual(approval.CONFIGURACAO, web.obter_configuracao())
        self.assertEqual(1, len(adaptador.enviados))
        self.assertEqual([], self.operacoes())
        self.negativo()  # API direta não ganha cobertura por ser usada no wrapper.

    def test_08_critica_a_tres_entradas_legadas_sem_infra_lacunas(self):
        for caminho in ("automatico", "promocao", "manual"):
            with self.subTest(caminho=caminho), self.fluxo_http() as adaptador:
                if caminho == "automatico":
                    env = carregar_fluxos()
                    env["WebTC420"].side_effect = WebTC420
                    self.assertFalse(env["tentar_login_automatico"]())
                elif caminho == "promocao":
                    fixture = self.fixture_main()
                    resultado = []
                    fixture.durante_monitor = lambda m: resultado.append(m.ao_promover_automaticamente())
                    fixture.iniciar_cliente(None)
                    self.assertIsNone(resultado[0])
                else:
                    _, janela = self.fixture_manual(None)
                    janela.conectar()
                    self.assertFalse(janela.servidor_iniciado)
                # L3-B1.8 corrige esta lacuna; os contraexemplos da API crua
                # nos testes 07/09 continuam preservados para L3-B1.9.
                self.assertEqual([], adaptador.enviados)
                self.assertEqual([], self.operacoes())

    def test_09_reserva_ausente_nao_e_prova_de_cobertura(self):
        self.registro.fechar_admissao()
        web = WebTC420("balanca-simulada")
        web.token = "simulado"
        with self.transporte() as adaptador:
            web.approval()  # Gate do registro não intercepta a API pública crua.
        self.assertEqual(1, len(adaptador.enviados))
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.assertEqual([], self.operacoes())
        self.negativo()

    def test_10_publicacao_ausente_mesmo_com_retorno_funcional(self):
        contexto = self.infra.preparar_http_inicial()
        web = WebTC420("balanca-simulada")
        web.token = "simulado"
        # Falha injetada: o publicador retorna True sem publicar o recibo.
        with self.transporte(), patch.object(self.registro, "publicar", return_value=True):
            self.assertEqual(approval.CONFIGURACAO, self.infra.executar_approval(contexto, web))
        op = self.operacoes()[0]
        self.assertTrue(op["publicacoes_pendentes"])
        self.assertIsNone(op["publicacao_original"])
        self.assertFalse(op["execucao_resolvida"])
        self.negativo()

    def test_11_publicacao_duplicada_conflitante_nao_sobrescreve(self):
        contexto = self.infra.preparar_http_inicial()
        web = WebTC420("balanca-simulada")
        web.token = "simulado"
        publicar = self.registro.publicar
        def conflitar(op, recibo):
            publicar(op, recibo)
            outro = self.registro.preparar_publicacao(op, erro=OSError())
            return publicar(op, outro)
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=conflitar):
            with self.assertRaises(RuntimeError):
                self.infra.executar_approval(contexto, web)
        op = self.operacoes()[0]
        self.assertEqual("retorno", op["publicacao_original"]["resultado"])
        self.assertEqual("falha", op["conflitos_publicacao"][0]["resultado"])
        self.assertFalse(op["execucao_resolvida"])

    def test_12_critica_c_login_antigo_e_promocao_concorrentes(self):
        env = carregar_fluxos()
        env["carregar_configuracao"] = lambda **kwargs: dict(salvar_login=True, ip="antiga-simulada", usuario="simulado")
        env["WebTC420"].side_effect = WebTC420
        fixture = self.fixture_main()
        resultados_promocao = fixture.preparar_promocao()
        entrou, liberar = threading.Event(), threading.Event()
        def autenticar(url, **kwargs):
            if "antiga" in url:
                self.bloquear(entrou, liberar)
            return Mock(text="SUCCESS:LOGIN:simulado:simulado")
        with patch("tc420.web.requests.post", side_effect=autenticar), \
                patch("tc420.web.requests.get", return_value=Mock(text=approval.APROVACAO.decode())), \
                patch.object(modulo, "InfraestruturaRegistrosCliente", return_value=self.infra):
            tarefa = self.iniciar_thread(lambda: env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
            try:
                self.assertTrue(entrou.wait(3))
                antes = self.operacoes()[0]
                fixture.env["iniciar"]()
                self.assertIsNotNone(resultados_promocao[0])
                self.assertFalse(self.operacoes()[0]["execucao_resolvida"])
                self.assertTrue(all(o["execucao_resolvida"] for o in self.operacoes()[1:]))
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertEqual("principal", resultados[0]["modo"])
        self.assertEqual(4, len({o["operacao_id"] for o in self.operacoes()}))
        antigo, promo_login, promo_get, antigo_get = self.operacoes()
        self.assertEqual(antes["geracao_id"], antigo["geracao_id"])
        self.assertEqual(antigo["geracao_id"], antigo_get["geracao_id"])
        self.assertEqual(promo_login["geracao_id"], promo_get["geracao_id"])
        self.assertNotEqual(antigo["geracao_id"], promo_login["geracao_id"])

    def test_13_preparacao_antiga_nao_herda_leitor_novo(self):
        contexto = self.infra.preparar_http_inicial()
        web = WebTC420("balanca-simulada")
        web.token = "simulado"
        entrou, liberar = threading.Event(), threading.Event()
        with self.transporte(antes=lambda: self.bloquear(entrou, liberar)):
            tarefa = self.iniciar_thread(lambda: self.infra.executar_approval(contexto, web))
            try:
                self.assertTrue(entrou.wait(3))
                leitor = modulo.RecursosLeitorCliente(self.infra)
                self.assertNotEqual(contexto.geracao_id, leitor.geracao_id)
            finally:
                liberar.set()
                _, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertEqual(contexto.geracao_id, self.operacoes()[0]["geracao_id"])

    def test_14_exposicao_visual_corrigida_console_retrato_sanitizados(self):
        fixture, janela = self.fixture_manual(self.infra)
        usuario, senha = uuid4().hex, uuid4().hex
        janela.campo_usuario.valor, janela.campo_senha.valor = usuario, senha
        with self.transporte(status=401):
            janela.conectar()
        # Somente marcadores gerados no ensaio: nunca imprimir os conteúdos.
        texto_visual = janela.label_status.opcoes["text"]
        console = repr(fixture.env["print"].call_args_list)
        retrato = json.dumps(self.registro.obter_retrato())
        self.assertTrue(all(v not in texto_visual for v in (usuario, senha)))
        self.assertTrue(texto_visual.endswith("Autenticação não autorizada pela TC420."))
        self.assertTrue(all(v not in console and v not in retrato for v in (usuario, senha)))
        self.assertTrue(self.operacoes()[0]["erros_execucao"])

    def test_15_critica_b_resposta_recebida_parser_ainda_pendente(self):
        contexto = self.infra.preparar_http_inicial()
        web = WebTC420("balanca-simulada")
        web.token = "simulado"
        entrou, liberar = threading.Event(), threading.Event()
        interpretar = web.interpretar_approval
        def atrasar(dados):
            self.bloquear(entrou, liberar)
            return interpretar(dados)
        with self.transporte() as adaptador, patch.object(web, "interpretar_approval", side_effect=atrasar):
            tarefa = self.iniciar_thread(lambda: self.infra.executar_approval(contexto, web))
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual(1, adaptador.corpo.lidos)
                op = self.operacoes()[0]
                self.assertEqual("em_andamento", op["estado"])
                self.assertIsNone(op["publicacao_original"])
                self.assertFalse(op["execucao_resolvida"])
                self.negativo()
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual(([approval.CONFIGURACAO], []), (resultados, erros))
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_16_global_negativo_mesmo_conjunto_http_resolvido(self):
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        with self.fluxo_http():
            self.assertTrue(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        self.registro.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_17_inventario_estatico_apis_importadas(self):
        self.assertEqual([
            ("tc420/web.py", "WebTC420.approval", "requests.get"),
            ("tc420/web.py", "WebTC420.login", "requests.post"),
            ("tc420/web.py", "WebTC420.refresh", "requests.get"),
        ], inventario_http())

    def test_18_critica_d_falha_publicacao_approval_operacional(self):
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        publicar = self.registro.publicar
        def publicar_ou_falhar(op, recibo):
            if self.operacoes()[-1]["operacao"] == "approval":
                raise OSError("publicacao_simulada")
            return publicar(op, recibo)
        with self.fluxo_http() as adaptador, patch.object(self.registro, "publicar", side_effect=publicar_ou_falhar):
            self.assertFalse(env["tentar_login_automatico"](infraestrutura_cliente=self.infra))
        self.assertEqual(2, len(adaptador.enviados))
        self.assertEqual("desconhecida", self.operacoes()[1]["estado"])
        self.assertFalse(self.operacoes()[1]["execucao_resolvida"])
        env["definir_configuracao"].assert_not_called()
        self.negativo()

    def test_19_limite_recursos_corpo_consumido_close_falho(self):
        contexto = self.infra.preparar_http_inicial()
        web = WebTC420("balanca-simulada")
        web.token = "simulado"
        original = OSError("limpeza_simulada")
        with self.transporte() as adaptador:
            adaptador.close = Mock(side_effect=original)
            with self.assertRaises(OSError) as capturado:
                self.infra.executar_approval(contexto, web)
        self.assertIs(original, capturado.exception)
        self.assertEqual(1, adaptador.corpo.lidos)
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        self.assertEqual([], self.infra.registro_recursos.obter_retrato()["recursos"])
        self.negativo()  # Não houve prova de limpeza física.

    def test_20_validacao_e_descoberta_nao_inventam_http(self):
        fixture, janela = self.fixture_manual(self.infra)
        janela.campo_nome.valor = ""
        with patch("requests.api.request") as enviar:
            janela.conectar()
            janela.campo_nome.valor = "simulado"
            fixture.env["buscar_servidor"].return_value = "principal-simulado"
            janela.ao_encontrar_servidor = Mock()
            janela.conectar()
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())

    def test_21_aborto_pre_execucao_provado_e_inicio_ambiguo(self):
        web = WebTC420("balanca-simulada")
        original = OSError("simulada")
        with patch.object(self.registro, "_iniciar", side_effect=original), patch("requests.post") as enviar:
            with self.assertRaises(OSError):
                self.infra.executar_login_manual(web, "simulado", "simulado")
        enviar.assert_not_called()
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        iniciar = self.registro._iniciar
        def ambiguo(op, gerenciada):
            iniciar(op, gerenciada)
            raise original
        with patch.object(self.registro, "_iniciar", side_effect=ambiguo), patch("requests.post") as enviar:
            with self.assertRaises(OSError):
                self.infra.executar_login_manual(web, "simulado", "simulado")
        enviar.assert_not_called()
        self.assertFalse(self.operacoes()[1]["execucao_resolvida"])
        self.assertEqual("desconhecida", self.operacoes()[1]["estado"])

    def test_22_json_nao_serializa_excecao_ou_cabecalho_sensivel(self):
        token = uuid4().hex
        resposta = requests.Response()
        resposta.status_code = 401
        resposta.headers["Authorization"] = token
        original = requests.HTTPError(token, response=resposta)
        contexto = self.infra.preparar_http_inicial()
        web = WebTC420("balanca-simulada")
        web.token = token
        with self.transporte(erro=original):
            with self.assertRaises(requests.HTTPError) as capturado:
                self.infra.executar_approval(contexto, web)
        self.assertIs(original, capturado.exception)
        serializado = json.dumps(self.registro.obter_retrato())
        self.assertTrue(token not in serializado)
        self.assertNotIn("Authorization", serializado)
        self.assertTrue(self.operacoes()[0]["erros_execucao"])

    def test_23_diagnostico_separado_sem_execucao_e_exposicao_estatica(self):
        arvore = ast.parse((RAIZ / "teste_approval.py").read_text(encoding="utf-8"))
        chamadas = [n for n in ast.walk(arvore) if isinstance(n, ast.Call)]
        self.assertTrue(any(isinstance(n.func, ast.Attribute) and n.func.attr == "approval" for n in chamadas))
        # A revisão removeu a exposição da sessão no ensaio manual.
        self.assertFalse(any(isinstance(n.func, ast.Name) and n.func.id == "print"
                            and any(isinstance(a, ast.Name) and a.id == "token" for a in n.args)
                            for n in chamadas))
        # Não importar script: a inspeção não executa HTTP nem exibe literais.
        for fonte in ("main.py", "interface/conexao.py"):
            self.assertNotIn("teste_approval", (RAIZ / fonte).read_text(encoding="utf-8"))

    def test_24_consultas_readonly_nao_criam_evidencia(self):
        contexto = self.infra.preparar_http_inicial()
        op = self.registro.admitir(contexto, "approval")
        self.assertIsNotNone(op)
        antes = self.registro.obter_retrato()
        for _ in range(5):
            self.negativo()
            self.assertEqual(antes, self.registro.obter_retrato())
        self.assertEqual("reservada", self.operacoes()[0]["estado"])
        self.assertFalse(self.operacoes()[0]["execucao_resolvida"])


if __name__ == "__main__":
    unittest.main()

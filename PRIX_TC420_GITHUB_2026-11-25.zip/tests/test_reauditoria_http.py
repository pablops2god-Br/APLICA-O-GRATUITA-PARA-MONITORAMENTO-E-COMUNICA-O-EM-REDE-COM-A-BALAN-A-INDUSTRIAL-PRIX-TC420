# Testes de reauditoria http: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.11: auditoria sem alterações operacionais, rede, Tk ou credenciais reais.

Ensaios de achados exigem que a limitação seja observável; aprovação desses
ensaios não significa correção da exposição ou aprovação integral da fronteira.
"""
import ast
from contextvars import copy_context
from dataclasses import replace
import json
from pathlib import Path
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
from uuid import uuid4

import requests

from rede import infraestrutura_cliente as modulo, servidor
from tc420.web import WebTC420
from test_registro_automatico import carregar_fluxos
import test_auditoria_cobertura_http as auditoria
import test_approval_http_integrado as approval


RAIZ = Path(__file__).resolve().parents[1]


# Grupo de 29 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class ReauditoriaHttp(unittest.TestCase):
    fluxo_http = approval.ApprovalHttpIntegrado.fluxo_http
    transporte = approval.ApprovalHttpIntegrado.transporte
    iniciar_thread = approval.ApprovalHttpIntegrado.iniciar_thread
    terminar = approval.ApprovalHttpIntegrado.terminar
    bloquear = approval.ApprovalHttpIntegrado.bloquear
    operacoes = approval.ApprovalHttpIntegrado.operacoes
    negativo = approval.ApprovalHttpIntegrado.negativo
    fixture_main = auditoria.AuditoriaCoberturaHttp.fixture_main
    fixture_manual = auditoria.AuditoriaCoberturaHttp.fixture_manual
    conferir_par = auditoria.AuditoriaCoberturaHttp.conferir_par

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = modulo.InfraestruturaRegistrosCliente()
        self.registro = self.infra.registro_http
        self.web = WebTC420("balanca-simulada", politica_http=self.infra.criar_politica_http())
        self.web.token = "simulado"

    def entradas(self, infra):
        auto = carregar_fluxos()
        auto["WebTC420"].side_effect = WebTC420
        auto["print"] = Mock()
        cliente = self.fixture_main()
        cliente.env["print"] = Mock()
        cliente.iniciar_cliente(infra)
        ui, janela = self.fixture_manual(infra)
        return auto, cliente, ui, janela

    def recusar_entradas(self, infra):
        auto, cliente, ui, janela = self.entradas(infra)
        with self.fluxo_http() as adaptador:
            self.assertIs(False, auto["tentar_login_automatico"](infraestrutura_cliente=infra))
            self.assertIsNone(cliente.monitores[0].ao_promover_automaticamente())
            self.assertIsNone(janela.conectar())
        self.assertEqual([], adaptador.enviados)
        self.assertEqual("normal", janela.botao_conectar.opcoes["state"])
        self.assertFalse(janela.servidor_iniciado)

    def main_real(self, caminho):
        fixture = self.fixture_main()
        janelas, webs = [], []
        def construir(ip, **kwargs):
            web = WebTC420(ip, **kwargs)
            webs.append(web)
            return web
        fixture.env["WebTC420"].side_effect = construir
        if caminho == "manual":
            fixture.env["tentar_login_automatico"] = Mock(return_value=False)
            def criar(**kwargs):
                ui, janela = self.fixture_manual(kwargs["infraestrutura_cliente"])
                ui.env["WebTC420"].side_effect = construir
                janela.root.mainloop = janela.conectar
                janelas.append(janela)
                return janela
            fixture.env["JanelaConexao"].side_effect = criar
        elif caminho == "promocao":
            fixture.preparar_promocao()
        with self.fluxo_http() as adaptador, \
                patch.object(modulo, "InfraestruturaRegistrosCliente", return_value=self.infra) as fabrica:
            fixture.env["iniciar"]()
        fabrica.assert_called_once_with()
        self.conferir_par(adaptador)
        dono_visual = janelas[0] if janelas else fixture.monitores[0]
        self.assertIs(self.infra, dono_visual.infraestrutura_cliente)
        self.assertIs(self.registro, dono_visual.infraestrutura_cliente.registro_http)
        self.assertIs(self.infra, self.registro.proprietario)
        self.assertIs(self.infra, webs[0].politica_http.proprietario)
        self.assertEqual(self.infra.aplicacao_id, self.registro.aplicacao_id)
        return fixture

    def test_01_automatico_main_post_get_mesmo_dono(self):
        self.main_real("automatico")

    def test_02_manual_main_post_get_mesmo_dono(self):
        self.main_real("manual")

    def test_03_promocao_main_post_get_origem_do_leitor(self):
        fx = self.main_real("promocao")
        origem = fx.leitores[0].recursos_cliente
        self.assertEqual({origem.geracao_id}, {o["geracao_id"] for o in self.operacoes()})
        self.assertEqual({origem.atividade_id}, {o["atividade_id"] for o in self.operacoes()})

    def test_04_ausencia_infraestrutura_tres_entradas(self):
        self.recusar_entradas(None)
        self.assertEqual([], self.operacoes())

    def test_05_registro_estrangeiro_em_infraestrutura_recusado(self):
        outra = modulo.InfraestruturaRegistrosCliente()
        original = self.infra._instalacao
        # Corrupção controlada da instalação, exclusivamente no ensaio.
        object.__setattr__(self.infra, "_instalacao", replace(original, http=outra.registro_http))
        try:
            self.recusar_entradas(self.infra)
        finally:
            object.__setattr__(self.infra, "_instalacao", original)
        self.assertEqual([], self.operacoes())
        self.assertEqual([], outra.registro_http.obter_retrato()["operacoes"])

    def test_06_admissao_fechada_tres_entradas(self):
        # Montar o leitor antes do gate também cobre promoção já disponível.
        auto, cliente, _, janela = self.entradas(self.infra)
        self.registro.fechar_admissao()
        with self.fluxo_http() as adaptador:
            self.assertIs(False, auto["tentar_login_automatico"](infraestrutura_cliente=self.infra))
            self.assertIsNone(cliente.monitores[0].ao_promover_automaticamente())
            janela.conectar()
        self.assertEqual([], adaptador.enviados)
        self.assertEqual([], self.operacoes())

    def test_07_acompanhado_direto_sem_autorizacao(self):
        with self.fluxo_http() as adaptador:
            for chamada in (lambda: self.web.login("simulado", "simulado"), self.web.approval,
                            self.web.obter_configuracao):
                with self.assertRaisesRegex(RuntimeError, "http_fora_do_executor"):
                    chamada()
        self.assertEqual([], adaptador.enviados)
        self.assertEqual([], self.operacoes())

    def desviar(self, modo):
        contexto = self.infra.preparar_http_inicial()
        original = self.web.obter_configuracao
        outra = WebTC420("outra-simulada", politica_http=self.web.politica_http)
        outra.token = "simulado"
        def callback():
            if modo == "objeto":
                chamada = outra.approval
            elif modo == "operacao":
                chamada = lambda: self.web.login("simulado", "simulado")
            else:
                copia = copy_context()
                tarefa = self.iniciar_thread(lambda: copia.run(self.web.approval))
                _, erros = self.terminar(tarefa)
                self.assertEqual(1, len(erros))
                self.assertEqual("autorizacao_http_invalida", str(erros[0]))
                return original()
            with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                chamada()
            return original()
        with self.transporte() as adaptador, patch.object(self.web, "obter_configuracao", side_effect=callback):
            self.infra.executar_approval(contexto, self.web)
        self.assertEqual(["GET"], [r.method for r, _ in adaptador.enviados])

    def test_08_autorizacao_outro_objeto(self):
        self.desviar("objeto")

    def test_09_autorizacao_outra_thread_contexto_copiado(self):
        self.desviar("thread")

    def test_10_autorizacao_outra_operacao(self):
        self.desviar("operacao")

    def test_11_autorizacao_uso_unico(self):
        contexto = self.infra.preparar_http_inicial()
        original = self.web.obter_configuracao
        def duplicar():
            retorno = original()
            with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                original()
            return retorno
        with self.transporte() as adaptador, patch.object(self.web, "obter_configuracao", side_effect=duplicar):
            self.assertEqual(approval.CONFIGURACAO, self.infra.executar_approval(contexto, self.web))
        self.assertEqual(1, len(adaptador.enviados))

    def test_12_independente_envia_fora_do_registro_fechado(self):
        self.registro.fechar_admissao()
        independente = WebTC420("independente-simulada")
        with self.fluxo_http() as adaptador:
            self.assertEqual("simulado", independente.login("simulado", "simulado"))
            self.assertEqual(approval.CONFIGURACAO, independente.obter_configuracao())
        self.assertEqual(["POST", "GET"], [r.method for r, _ in adaptador.enviados])
        self.assertIsNone(independente.politica_http)
        self.assertEqual([], self.operacoes())
        self.negativo()

    def verificar_visual(self, tipo):
        ui, janela = self.fixture_manual(self.infra)
        marcadores = [uuid4().hex for _ in range(4)]
        usuario, senha, token, extra = marcadores
        janela.campo_usuario.valor, janela.campo_senha.valor = usuario, senha
        texto = f"https://{usuario}:{senha}@simulado.invalid/?token={token} Authorization: {extra}"
        original = tipo(texto)
        with self.transporte(erro=original):
            janela.conectar()
        self.assertEqual("falha", self.operacoes()[0]["resultado"])
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])
        self.assertIsNone(janela.web)
        self.assertEqual("normal", janela.botao_conectar.opcoes["state"])
        saidas = [janela.label_status.opcoes["text"], repr(ui.env["print"].call_args_list),
                  json.dumps(self.registro.obter_retrato()), json.dumps(self.infra.avaliar())]
        self.assertTrue(all(m not in s for s in saidas for m in marcadores))
        self.assertEqual((texto,), original.args)
        return original

    def test_13_timeout_url_sensivel_label_console_retrato(self):
        self.verificar_visual(requests.Timeout)

    def test_14_excecao_token_label_console_retrato(self):
        self.verificar_visual(requests.ConnectionError)

    def consultar_pendente(self):
        retrato = self.registro.obter_retrato()
        self.assertFalse(retrato["conjunto_http_resolvido"])
        self.assertTrue(any(not o["execucao_resolvida"] for o in retrato["operacoes"]))
        self.negativo()

    def test_15_parser_bloqueado_pendente(self):
        contexto = self.infra.preparar_http_inicial()
        entrou, liberar = threading.Event(), threading.Event()
        original = self.web.interpretar_approval
        def interpretar(dados):
            self.bloquear(entrou, liberar)
            return original(dados)
        with self.transporte() as adaptador, patch.object(self.web, "interpretar_approval", side_effect=interpretar):
            tarefa = self.iniciar_thread(lambda: self.infra.executar_approval(contexto, self.web))
            try:
                self.assertTrue(entrou.wait(3))
                self.assertEqual(1, adaptador.corpo.lidos)
                self.registro.fechar_admissao()
                self.consultar_pendente()
                self.assertIsNone(self.operacoes()[0]["publicacao_original"])
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual(([approval.CONFIGURACAO], []), (resultados, erros))
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_16_publicacao_falha_desconhecida(self):
        contexto = self.infra.preparar_http_inicial()
        with self.transporte(), patch.object(self.registro, "publicar", side_effect=OSError()):
            with self.assertRaises(OSError):
                self.infra.executar_approval(contexto, self.web)
        self.registro.fechar_admissao()
        self.assertEqual("desconhecida", self.operacoes()[0]["estado"])
        self.assertTrue(self.operacoes()[0]["publicacoes_pendentes"])
        self.consultar_pendente()

    def test_17_critico_a_sem_bypass_apos_gate(self):
        auto, cliente, _, janela = self.entradas(self.infra)
        self.registro.fechar_admissao()
        with patch("requests.api.request") as enviar:
            self.assertIs(False, auto["tentar_login_automatico"](infraestrutura_cliente=self.infra))
            self.assertIsNone(cliente.monitores[0].ao_promover_automaticamente())
            janela.conectar()
            for chamada in (lambda: self.web.login("simulado", "simulado"), self.web.obter_configuracao):
                with self.assertRaises(RuntimeError):
                    chamada()
        enviar.assert_not_called()
        self.assertEqual([], self.operacoes())

    def test_18_critico_b_permissao_ativa_desvios_concorrentes(self):
        contexto = self.infra.preparar_http_inicial()
        obter = self.web.obter_configuracao
        outra = WebTC420("outra-simulada", politica_http=self.web.politica_http)
        outra.token = "simulado"
        def callback():
            self.assertEqual(1, self.operacoes()[0]["execucoes_ativas"])
            copia = copy_context()
            tarefa = self.iniciar_thread(lambda: copia.run(self.web.approval))
            _, erros = self.terminar(tarefa)
            self.assertEqual(1, len(erros))
            self.assertEqual("autorizacao_http_invalida", str(erros[0]))
            for chamada in (outra.approval, lambda: self.web.login("simulado", "simulado")):
                with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                    chamada()
            return obter()
        with self.transporte() as adaptador, patch.object(self.web, "obter_configuracao", side_effect=callback):
            self.infra.executar_approval(contexto, self.web)
        self.assertEqual(1, len(adaptador.enviados))
        self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

    def test_19_critico_c_resultado_original_e_visual_seguro(self):
        original = self.verificar_visual(requests.HTTPError)
        contexto = self.infra.preparar_http_inicial()
        with self.transporte(erro=original):
            with self.assertRaises(requests.HTTPError) as capturado:
                self.infra.executar_approval(contexto, self.web)
        self.assertIs(original, capturado.exception)
        self.assertTrue(all(o["resultado"] == "falha" for o in self.operacoes()))

    def test_20_critico_d_publicacao_tardia_sem_confirmacao_nem_reuso(self):
        contexto = self.infra.preparar_http_inicial()
        entrou, liberar = threading.Event(), threading.Event()
        copias = []
        obter, publicar = self.web.obter_configuracao, self.registro.publicar
        def copiar():
            copias.append(copy_context())
            return obter()
        def atrasar(op, recibo):
            # Mesma thread que executou a operação: comprova expiração,
            # independentemente da guarda adicional de identidade de thread.
            with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                copias[0].run(self.web.approval)
            self.bloquear(entrou, liberar)
            return publicar(op, recibo)
        with self.transporte() as adaptador, patch.object(self.web, "obter_configuracao", side_effect=copiar), \
                patch.object(self.registro, "publicar", side_effect=atrasar):
            tarefa = self.iniciar_thread(lambda: self.infra.executar_approval(contexto, self.web))
            try:
                self.assertTrue(entrou.wait(3))
                self.registro.fechar_admissao()
                self.consultar_pendente()
                self.assertTrue(self.operacoes()[0]["publicacoes_pendentes"])
                # A thread de consulta também não pode utilizar a cópia.
                with self.assertRaisesRegex(RuntimeError, "autorizacao_http_invalida"):
                    copias[0].run(self.web.approval)
                self.assertEqual(1, len(adaptador.enviados))
            finally:
                liberar.set()
                resultados, erros = self.terminar(tarefa)
        self.assertEqual(([approval.CONFIGURACAO], []), (resultados, erros))
        self.assertTrue(self.registro.obter_retrato()["conjunto_http_resolvido"])
        self.negativo()

    def test_21_identidades_estrangeiras_e_id_isolado_sem_permissao(self):
        outra = modulo.InfraestruturaRegistrosCliente()
        contexto_outro = outra.preparar_http_inicial()
        identidade = outra.registro_http.admitir(contexto_outro, "approval")
        with self.transporte() as adaptador:
            with self.assertRaisesRegex(ValueError, "operacao_invalida"):
                self.registro.executar(identidade, self.web.obter_configuracao)
            with self.assertRaisesRegex(ValueError, "contexto_invalido"):
                self.infra.executar_approval(contexto_outro, self.web)
            with self.assertRaisesRegex(ValueError, "politica_http_de_outro_proprietario"):
                outra.executar_approval(contexto_outro, self.web)
            contexto = self.infra.preparar_http_inicial()
            identidade_local = self.registro.admitir(contexto, "approval")
            with self.assertRaisesRegex(RuntimeError, "http_fora_do_executor"):
                self.registro.executar(identidade_local, self.web.obter_configuracao)
        self.assertEqual([], adaptador.enviados)

    def test_22_preparacao_anterior_ao_leitor_mantem_origem_post_get(self):
        auto, _, _, _ = self.entradas(self.infra)
        entrou, liberar = threading.Event(), threading.Event()
        with self.fluxo_http() as adaptador:
            enviar = adaptador.send
            def bloquear_post(pedido, **kwargs):
                if pedido.method == "POST":
                    self.bloquear(entrou, liberar)
                return enviar(pedido, **kwargs)
            with patch.object(adaptador, "send", side_effect=bloquear_post):
                tarefa = self.iniciar_thread(lambda: auto["tentar_login_automatico"](infraestrutura_cliente=self.infra))
                try:
                    self.assertTrue(entrou.wait(3))
                    antes = self.operacoes()[0]
                    novo = modulo.RecursosLeitorCliente(self.infra)
                    self.assertNotEqual(novo.geracao_id, antes["geracao_id"])
                finally:
                    liberar.set()
                    resultados, erros = self.terminar(tarefa)
        self.assertEqual([], erros)
        self.assertEqual("principal", resultados[0]["modo"])
        self.conferir_par(adaptador)
        self.assertEqual({antes["geracao_id"]}, {o["geracao_id"] for o in self.operacoes()})

    def test_23_promocao_nao_apaga_origem_nem_operacoes_antigas(self):
        preparacao = self.infra.preparar_http_inicial()
        leitor = modulo.RecursosLeitorCliente(self.infra)
        contexto = self.infra.preparar_http_promocao(leitor)
        with self.fluxo_http():
            self.infra.executar_login_automatico(self.web, "simulado", "simulado", contexto_http=preparacao)
            antiga = self.operacoes()[0]
            self.infra.executar_login_promocao(leitor, self.web, "simulado", "simulado", contexto_http=contexto)
            self.infra.executar_approval(contexto, self.web)
        anteriores = self.operacoes()
        self.registro.promover(leitor.geracao_id)
        modulo.RecursosLeitorCliente(self.infra)
        posteriores = self.operacoes()
        self.assertEqual(3, len(posteriores))
        self.assertEqual(antiga, posteriores[0])
        for antes, depois in zip(anteriores, posteriores):
            for campo in ("operacao_id", "geracao_id", "atividade_id", "resultado", "publicacao_original"):
                self.assertEqual(antes[campo], depois[campo])
        self.assertEqual({leitor.geracao_id}, {o["geracao_id"] for o in posteriores[1:]})
        self.assertTrue(all(o["modo_atual"] == "principal" for o in posteriores[1:]))

    def test_24_recusa_approval_distinta_de_falha_limpeza(self):
        contexto = self.infra.preparar_http_inicial()
        with self.transporte(b"FAILURE:APPROVAL:simulado") as recusado:
            with self.assertRaisesRegex(RuntimeError, "Approval recusado pela TC420"):
                self.infra.executar_approval(contexto, self.web)
        self.assertEqual(1, recusado.fechamentos)
        self.assertEqual("falha_operacao", self.operacoes()[0]["erro"]["categoria"])
        original = OSError("limpeza_simulada")
        with self.transporte() as limpeza:
            limpeza.close = Mock(side_effect=original)
            with self.assertRaises(OSError) as capturado:
                self.infra.executar_approval(contexto, self.web)
        self.assertIs(original, capturado.exception)
        self.assertEqual("falha_io", self.operacoes()[1]["erro"]["categoria"])
        self.assertTrue(all(o["execucao_resolvida"] for o in self.operacoes()))
        self.assertEqual([], self.infra.registro_recursos.obter_retrato()["recursos"])
        self.negativo()

    def test_25_worker_refresh_sanitizado_console_e_saude(self):
        marcador = uuid4().hex
        web = WebTC420("simulado.invalid", politica_http=self.infra.criar_politica_http())
        web.token = marcador
        parada = Mock()
        parada.is_set.return_value = False
        parada.wait.return_value = True  # Uma iteração real, sem sleep/rede.
        with self.transporte(status=401), patch.object(servidor, "evento_parada_servidor", parada), \
                patch.object(servidor, "saude_tc420", dict(saudavel=False, falhas_consecutivas=0,
                            ultimo_sucesso=None, ultimo_erro=None, inicio_indisponibilidade=None)), \
                patch("builtins.print") as console:
            servidor.ler_tc420(web)
            saude = servidor.obter_saude_tc420()
        # L3-B1.12: o antigo contraexemplo agora exige a correção nos dois destinos.
        self.assertNotIn(marcador, saude["ultimo_erro"])
        self.assertNotIn(marcador, repr(console.call_args_list))
        self.assertEqual("Autenticação não autorizada pela TC420.", saude["ultimo_erro"])
        self.assertEqual([], self.operacoes())  # Refresh é do PRINCIPAL.
        self.assertNotIn(marcador, json.dumps(self.registro.obter_retrato()))

    def test_26_achado_callback_monitor_expoe_erro_sem_dialogo(self):
        arvore = ast.parse((RAIZ / "interface/janela.py").read_text(encoding="utf-8"))
        metodo = next(n for n in ast.walk(arvore) if isinstance(n, ast.FunctionDef) and n.name == "atualizar_refresh_web")
        env = {"print": Mock(), "datetime": __import__('datetime').datetime}
        exec(compile(ast.Module(body=[metodo], type_ignores=[]), "interface/janela.py", "exec"), env)
        marcador = uuid4().hex
        fonte = Mock(side_effect=requests.HTTPError(marcador))
        objeto = SimpleNamespace(executando=True, fonte_dados=fonte, root=Mock(), atualizar_refresh_web=Mock())
        objeto._agendar = objeto.root.after
        env[metodo.name](objeto)
        self.assertNotIn(marcador, repr(env["print"].call_args_list))
        objeto.root.after.assert_called_once()
        # Em main normal a fonte é obter_dados_atuais, não web.obter_estado.
        # Portanto este é um callback injetável, não outro envio HTTP normal.
        # O aviso operacional B2 e independente deste callback de refresh.
        dialogs = [n for n in ast.walk(metodo) if isinstance(n, ast.Call)
                   and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
                   and n.func.value.id == "messagebox"]
        self.assertEqual([], dialogs)

    def test_27_limite_infra_completa_estrangeira_aceita_em_chamadas_isoladas(self):
        outra = modulo.InfraestruturaRegistrosCliente()
        auto, cliente, _, janela = self.entradas(outra)
        with self.fluxo_http() as adaptador:
            self.assertTrue(auto["tentar_login_automatico"](infraestrutura_cliente=outra))
            janela.conectar()
            self.assertIsNotNone(cliente.monitores[0].ao_promover_automaticamente())
        # Não existe parâmetro de dono esperado nessas entradas. Uma instalação
        # completa diferente é válida por si mesma e registra no outro dono.
        self.assertEqual(6, len(adaptador.enviados))
        self.assertEqual([], self.operacoes())
        ops = outra.registro_http.obter_retrato()["operacoes"]
        self.assertEqual(6, len(ops))
        self.assertTrue(all(o["execucao_resolvida"] for o in ops))
        self.assertIs(outra, janela.infraestrutura_cliente)

    def test_28_inventario_http_e_diagnostico_independente_estatico(self):
        self.assertEqual([
            ("tc420/web.py", "WebTC420.approval", "requests.get"),
            ("tc420/web.py", "WebTC420.login", "requests.post"),
            ("tc420/web.py", "WebTC420.refresh", "requests.get"),
        ], auditoria.inventario_http())
        script = ast.parse((RAIZ / "teste_approval.py").read_text(encoding="utf-8"))
        # O diagnóstico independente continua existindo, agora sem imprimir o token.
        self.assertFalse(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "print"
                            and any(isinstance(a, ast.Name) and a.id == "token" for a in n.args)
                            for n in ast.walk(script)))
        persistentes = []
        for arquivo in auditoria.fontes_operacionais():
            arvore = ast.parse(arquivo.read_text(encoding="utf-8"))
            for n in ast.walk(arvore):
                if isinstance(n, ast.Call):
                    nome = n.func.attr if isinstance(n.func, ast.Attribute) else getattr(n.func, "id", "")
                    if nome in ("FileHandler", "RotatingFileHandler", "TimedRotatingFileHandler", "basicConfig", "print_exc"):
                        persistentes.append((arquivo.name, n.lineno))
        self.assertEqual([], persistentes)

    def test_29_cada_get_exige_reserva_apos_post_nas_tres_entradas(self):
        for caminho in ("automatico", "manual", "promocao"):
            with self.subTest(caminho=caminho):
                # Isolamento dos gates entre subcasos.
                self.setUp()
                auto, cliente, _, janela = self.entradas(self.infra)
                with self.fluxo_http() as adaptador:
                    enviar = adaptador.send
                    def fechar_apos_post(pedido, **kwargs):
                        resposta = enviar(pedido, **kwargs)
                        if pedido.method == "POST":
                            self.registro.fechar_admissao()
                        return resposta
                    with patch.object(adaptador, "send", side_effect=fechar_apos_post):
                        if caminho == "automatico":
                            self.assertIs(False, auto["tentar_login_automatico"](infraestrutura_cliente=self.infra))
                        elif caminho == "manual":
                            janela.conectar()
                            self.assertIsNone(janela.web)
                            self.assertFalse(janela.servidor_iniciado)
                        else:
                            self.assertIsNone(cliente.monitores[0].ao_promover_automaticamente())
                self.assertEqual(["POST"], [r.method for r, _ in adaptador.enviados])
                self.assertEqual(["login"], [o["operacao"] for o in self.operacoes()])
                self.assertTrue(self.operacoes()[0]["execucao_resolvida"])

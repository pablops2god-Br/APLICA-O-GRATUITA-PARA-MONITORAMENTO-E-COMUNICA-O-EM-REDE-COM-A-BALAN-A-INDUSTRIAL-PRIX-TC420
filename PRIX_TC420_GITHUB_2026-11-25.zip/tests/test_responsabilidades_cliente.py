# Testes de responsabilidades cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""CLIENTE: 18 cenários, quatro corridas e limites operacionais sem rede/Tk."""
import ast
from pathlib import Path
from types import SimpleNamespace
import threading
import socket
import unittest
from unittest.mock import MagicMock, Mock, patch

from prototipos.responsabilidades_cliente import PROVAS, ResponsabilidadesClienteExperimental
from rede.servidor import RegistroTentativasAplicacao
from rede import servidor
from rede.lerdadosserver import LeitorDadosServidor


# Grupo de 26 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class ResponsabilidadesCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.registro = RegistroTentativasAplicacao()
        self.modelo = ResponsabilidadesClienteExperimental(self.registro)

    def iniciar(self, tipo="leitor", dono=1, daemon=False):
        chave = self.modelo.reservar(tipo, dono, daemon=daemon)
        self.assertTrue(self.modelo.ativar(chave))
        self.modelo.resolver_preparacao(chave)
        return chave

    def terminar(self, chave):
        item = next(i for i in self.retrato()["responsabilidades"] if i["id"] == chave)
        self.modelo.comprovar(chave, **dict.fromkeys(PROVAS[item["tipo"]], True))

    def retrato(self):
        return self.modelo.obter_retrato()

    def estado(self, chave):
        return next(i["estado"] for i in self.retrato()["responsabilidades"] if i["id"] == chave)

    def pendente(self):
        self.assertFalse(self.retrato()["encerramento_confirmado"])

    def test_01_sem_atividades(self):
        self.assertEqual([], self.retrato()["responsabilidades"])
        self.pendente()  # Sem fechar admissão ainda pode surgir trabalho.
        self.modelo.solicitar_parada()
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_02_recebendo_peso(self):
        chave = self.iniciar("recepcao_peso")
        self.assertEqual("ativo", self.estado(chave))

    def test_03_descoberta_ativa(self):
        self.iniciar("descoberta")
        self.modelo.solicitar_parada()
        self.pendente()

    def test_04_stop_nao_e_termino(self):
        chave = self.iniciar()
        self.modelo.solicitar_parada()
        self.assertEqual("parada_solicitada", self.estado(chave))
        self.pendente()

    def test_05_thread_terminada(self):
        chave = self.iniciar()
        thread = threading.Thread(target=lambda: None)
        thread.start()
        thread.join(3)
        self.assertFalse(thread.is_alive())
        self.modelo.solicitar_parada()
        self.modelo.comprovar(chave, thread_terminada=not thread.is_alive())
        self.assertEqual("encerramento_confirmado", self.estado(chave))
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_06_socket_aberto(self):
        chave = self.iniciar("recepcao_peso")
        self.modelo.solicitar_parada()
        self.modelo.comprovar(chave, chamada_retornada=True, arquivo_liberado=True,
                              socket_liberado=False)
        self.pendente()

    def test_07_falha_close_nao_desaparece(self):
        chave = self.iniciar("recepcao_peso")
        self.modelo.solicitar_parada()
        self.modelo.registrar_falha(chave)
        self.terminar(chave)
        self.assertEqual("desconhecido", self.estado(chave))
        self.pendente()

    def test_08_reconexao_recusada(self):
        self.modelo.solicitar_parada()
        self.assertIsNone(self.modelo.reservar("recepcao_peso", 1))

    def test_09_promocao_recusada(self):
        self.modelo.solicitar_parada()
        self.assertIsNone(self.modelo.reservar_promocao(1))
        self.assertEqual((), self.registro.obter_retrato()["tentativas"])

    def test_10_promocao_preserva_antigas(self):
        antigo = self.iniciar("descoberta")
        promocao = self.modelo.reservar_promocao(1)
        self.modelo.ativar(promocao)
        self.modelo.promover(promocao)
        self.assertEqual("principal", self.retrato()["modo"])
        self.assertEqual("ativo", self.estado(antigo))

    def test_11_promocoes_independentes(self):
        a, b = self.modelo.reservar_promocao(1), self.modelo.reservar_promocao(2)
        itens = self.retrato()["responsabilidades"]
        self.assertNotEqual(a, b)
        self.assertNotEqual(itens[0]["tentativa_id"], itens[1]["tentativa_id"])
        self.assertEqual([1, 2], [i["proprietario"] for i in itens])

    def test_12_callback_pendente_invalidado(self):
        chave = self.iniciar("callback")
        self.modelo.destruir_janela_simulada()
        self.assertFalse(self.modelo.executar_callback_simulado(chave))
        self.assertEqual(0, self.retrato()["atualizacoes"])

    def test_13_daemon_nao_prova_fim(self):
        chave = self.iniciar(daemon=True)
        self.modelo.solicitar_parada()
        self.assertNotEqual("encerramento_confirmado", self.estado(chave))
        self.pendente()

    def test_14_desconhecido_conservador(self):
        chave = self.modelo.reservar("leitor", 1)
        self.assertEqual("desconhecido", self.estado(chave))
        self.modelo.solicitar_parada()
        self.pendente()

    def test_15_parada_idempotente(self):
        self.iniciar()
        self.assertTrue(self.modelo.solicitar_parada())
        antes = self.retrato()
        self.assertFalse(self.modelo.solicitar_parada())
        self.assertEqual(antes, self.retrato())

    def test_16_registro_falha_apos_admitir(self):
        admitir = self.registro.admitir

        def falhar(contexto):
            admitir(contexto)
            raise OSError("nao_publicar_esta_mensagem")

        with patch.object(self.registro, "admitir", side_effect=falhar):
            chave = self.modelo.reservar_promocao(1)
        self.assertEqual("desconhecido", self.estado(chave))
        self.assertFalse(self.modelo.ativar(chave))
        self.modelo.solicitar_parada()
        self.pendente()
        self.assertNotIn("nao_publicar", str(self.retrato()))
        self.assertEqual(1, len(self.registro.obter_retrato()["tentativas"]))

    def test_17_avaliacao_concorrente_coerente(self):
        chaves = [self.iniciar("recepcao_peso") for _ in range(20)]
        self.modelo.solicitar_parada()
        barreira = threading.Barrier(2)
        erros = []

        def concluir():
            try:
                barreira.wait(3)
                for chave in chaves:
                    self.terminar(chave)
            except BaseException as erro:
                erros.append(erro)

        thread = threading.Thread(target=concluir)
        thread.start()
        barreira.wait(3)
        for _ in range(100):
            retrato = self.retrato()
            esperado = all(i["estado"] == "encerramento_confirmado"
                           for i in retrato["responsabilidades"])
            self.assertEqual(esperado, retrato["encerramento_confirmado"])
        thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)

    def test_18_todas_encerradas(self):
        for tipo in PROVAS:
            chave = self.iniciar(tipo)
            self.terminar(chave)
        self.modelo.solicitar_parada()
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def corrida_reserva(self, reservar):
        reservada, continuar = threading.Event(), threading.Event()
        resultado, erros = [], []

        def preparar():
            try:
                chave = reservar()
                resultado.append(chave)
                reservada.set()
                if not continuar.wait(3):
                    raise TimeoutError()
                resultado.append(self.modelo.ativar(chave))
            except BaseException as erro:
                erros.append(erro)

        thread = threading.Thread(target=preparar)
        thread.start()
        try:
            self.assertTrue(reservada.wait(3))
            self.modelo.solicitar_parada()
            self.pendente()  # Ainda há preparação capaz de publicar resultado tardio.
        finally:
            continuar.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(False, resultado[1])
        self.assertEqual(resultado[0], self.retrato()["responsabilidades"][0]["id"])
        self.modelo.resolver_preparacao(resultado[0], nao_iniciada=True)
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_critico_A_reconexao_contra_parada(self):
        self.corrida_reserva(lambda: self.modelo.reservar("recepcao_peso", 1))

    def test_critico_B_promocao_contra_parada(self):
        self.corrida_reserva(lambda: self.modelo.reservar_promocao(1))
        self.assertTrue(self.registro.obter_retrato()["admissao_fechada"])
        self.assertIsNone(self.modelo.reservar_promocao(2))
        # O conjunto CLIENTE confirmado não resolve a tentativa do servidor.
        self.assertEqual(1, len(self.registro.obter_retrato()["tentativas"]))

    def test_critico_C_callback_contra_destruicao(self):
        chave = self.iniciar("callback")
        liberar = threading.Event()
        resultados = []

        def callback():
            if liberar.wait(3):
                resultados.append(self.modelo.executar_callback_simulado(chave))

        thread = threading.Thread(target=callback)
        thread.start()
        self.modelo.destruir_janela_simulada()
        liberar.set()
        thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([False], resultados)
        self.assertEqual(0, self.retrato()["atualizacoes"])

    def test_critico_D_descoberta_sobrevive_servidor(self):
        descoberta = self.iniciar("descoberta")
        promocao = self.modelo.reservar_promocao(1)
        self.modelo.ativar(promocao)
        self.modelo.resolver_preparacao(promocao)
        self.modelo.promover(promocao)
        self.terminar(promocao)
        tentativa = self.registro.obter_retrato()["tentativas"][0]
        self.registro.marcar_iniciando(tentativa.tentativa_id)
        self.registro.registrar_entrada_execucao(tentativa.tentativa_id)
        self.registro.marcar_iniciada(tentativa.tentativa_id)
        workers = servidor.RegistroTrabalhadores()
        controle = servidor.ControleCicloServidor()
        self.assertTrue(controle.tentar_iniciar(workers))
        tentativa.contexto.registrar_reserva(workers.ciclo_id)
        workers.bloquear_criacao()
        controle.finalizar(workers)
        tentativa.contexto.registrar_retorno_coordenador()
        self.modelo.solicitar_parada()
        with patch.object(servidor, "controle_ciclo_servidor", controle):
            agregado = servidor.avaliar_encerramento_aplicacao(self.registro)
        self.assertTrue(agregado["encerramento_confirmado"])
        self.pendente()
        self.terminar(descoberta)
        self.assertTrue(self.retrato()["encerramento_confirmado"])

    def test_preparacao_pendente_bloqueia_mesmo_com_provas(self):
        chave = self.modelo.reservar("leitor", 1)
        self.terminar(chave)
        self.modelo.solicitar_parada()
        self.pendente()

    def test_copia_nao_altera_evidencias(self):
        chave = self.iniciar()
        self.retrato()["responsabilidades"][0]["provas"]["thread_terminada"] = True
        self.assertEqual("ativo", self.estado(chave))

    def test_gate_compartilhado_fechado_externamente(self):
        self.registro.fechar_admissao()
        self.assertIsNone(self.modelo.reservar("retentativa", 1))
        self.assertIsNone(self.modelo.reservar_promocao(1))

    def test_provas_invalidas_e_conflitantes(self):
        chave = self.iniciar()
        with self.assertRaises(ValueError):
            self.modelo.comprovar(chave, thread_terminada=1)
        self.terminar(chave)
        self.modelo.comprovar(chave, thread_terminada=False)
        self.assertEqual("desconhecido", self.estado(chave))


# Grupo de 4 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class LacunasClienteOperacional(unittest.TestCase):
    def leitor(self):
        with patch("rede.lerdadosserver.socket.gethostname", return_value="cliente_simulado"):
            return LeitorDadosServidor("principal_simulado")

    def test_parar_nao_aguarda_thread_e_ignora_close(self):
        leitor = self.leitor()
        leitor.thread = Mock()
        leitor.thread.is_alive.return_value = True
        sock = Mock()
        sock.shutdown.side_effect = OSError()
        sock.close.side_effect = OSError()
        leitor.cliente = sock
        leitor.parar()
        leitor.thread.join.assert_not_called()
        self.assertTrue(leitor.thread.is_alive())
        self.assertIsNone(leitor.cliente)
        self.assertTrue(leitor._parada.is_set())

    def test_retentativa_sem_proprietario_nao_inicia(self):
        leitor = self.leitor()
        leitor.estado_candidatura = "liberada"
        leitor.tentativa_recuperacao = 1
        with patch("rede.lerdadosserver.threading.Thread") as thread:
            self.assertFalse(leitor.registrar_falha_recuperacao())
            thread.assert_not_called()

    def test_callback_peso_atual_atinge_widget_sem_guard(self):
        caminho = Path(__file__).resolve().parents[1] / "interface" / "janela.py"
        arvore = ast.parse(caminho.read_text(encoding="utf-8"))
        classe = next(n for n in arvore.body if isinstance(n, ast.ClassDef))
        metodo = next(n for n in classe.body if isinstance(n, ast.FunctionDef)
                      and n.name == "atualizar_peso")
        namespace = {}
        exec(compile(ast.Module(body=[metodo], type_ignores=[]), str(caminho), "exec"), namespace)
        janela = SimpleNamespace(executando=False, label_peso=Mock())
        namespace["atualizar_peso"](janela, "42")
        janela.label_peso.config.assert_not_called()

    def test_socket_pode_ser_criado_depois_de_parar(self):
        leitor = self.leitor()
        leitor.executando = True
        config, registro, assinatura = MagicMock(), MagicMock(), MagicMock()
        config.__enter__.return_value = config
        registro.__enter__.return_value = registro
        config.makefile.return_value.__enter__.return_value.readline.return_value = '{}'
        config.makefile.return_value.readline.return_value = '{}'
        registro.makefile.return_value.__enter__.return_value.readline.return_value = (
            '{"nome":"cliente_simulado","posicao":1}')
        estados_ao_conectar = []
        assinatura.connect.side_effect = lambda destino: estados_ao_conectar.append(leitor.executando)

        alocacoes = []
        def alocar(*args):
            alocacoes.append(True)
            if len(alocacoes) == 1:
                return config  # CONFIG agora expõe cada endereço TCP.
            leitor.parar()  # Intercalação após if executando, antes da publicação.
            return assinatura

        with patch("rede.lerdadosserver.socket.create_connection", return_value=registro), \
                patch('socket.getaddrinfo', return_value=[
                    (socket.AF_INET, socket.SOCK_STREAM, 6, '', ('simulado', 42100))]), \
                patch("rede.lerdadosserver.socket.socket", side_effect=alocar):
            leitor._manter_atualizado()
        self.assertEqual([False], estados_ao_conectar)
        assinatura.close.assert_called_once()


if __name__ == "__main__":
    unittest.main()

"""Verificação Tk real oculta, sem rede, TC420, credenciais ou main.py.

Executar da raiz: python -B tests/ensaio_recuperacao_manual_tk.py
"""
import sys
from pathlib import Path
from threading import Event
from types import SimpleNamespace
import tkinter as tk

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from interface.janela import JanelaTC420
from interface.saida_aplicacao import SaidaAplicacao
from rede.servidor import RegistroTentativasAplicacao


def executar():
    raiz = tk.Tk()
    raiz.withdraw()
    try:
        janela = JanelaTC420(master=raiz, fonte_dados=lambda: {},
                            comunicacao_atual=lambda: False)
        janela.root.withdraw()
        saida = SaidaAplicacao()
        saida.configurar(registro=RegistroTentativasAplicacao())
        janela.saida_aplicacao = saida
        janela.iniciar_observacao_candidatura()
        agendados = len(raiz.tk.call('after', 'info'))
        janela.iniciar_observacao_candidatura()
        assert len(raiz.tk.call('after', 'info')) == agendados
        abriu = []
        janela.abrir_janela_promocao = lambda: abriu.append(True)
        pronto = Event()
        pronto.set()
        leitor = SimpleNamespace(comunicacao_esta_atual=lambda: False)
        janela._supervisao_principal = SimpleNamespace(
            vigente=lambda: True, pronto=pronto, obter_leitor=lambda: leitor)
        janela.menu_opcoes.invoke('Assumir manualmente')
        assert abriu == [True]
        assert callable(janela.ao_promover)
        leitor.comunicacao_esta_atual = lambda: True
        janela.menu_opcoes.invoke('Assumir manualmente')
        assert abriu == [True]
        config = {'W1.1': {'max': '80000 kg', 'min': '200 kg', 'divisao': '10 kg'},
                  'W1.2': {'max': '140000 kg', 'min': '400 kg', 'divisao': '20 kg'}}
        janela.atualizar_configuracao(config)
        assert '80000 kg' in janela.labels_configuracao['W1.1']['max'].cget('text')
        assert '20 kg' in janela.labels_configuracao['W1.2']['divisao'].cget('text')
        raiz.update_idletasks()
        print('Tk oculto: observador único, menu manual, bloqueio conectado e faixas OK; sem rede.')
    finally:
        raiz.destroy()


if __name__ == '__main__':
    executar()

# Testes de associacoes retentativas cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC2-C: propriedade explícita; protocolos reais com transporte falso, sem global positivo."""
import ast
from dataclasses import replace
from pathlib import Path
import socket
import threading
import unittest
from unittest.mock import Mock, patch

from prototipos.composicao_cliente import CoberturaCliente, VinculoRecurso, avaliar_cliente
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from rede.lerdadosserver import LeitorDadosServidor
from rede.associacoes_retentativas import RecursosRetentativaCliente
from test_descoberta_cliente_integrada import SocketDescobertaFalso
from test_recursos_cliente_integrados import SocketLeituraFalso
import test_partidas_retentativas_cliente as partidas


# Grupo de 35 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AssociacoesRetentativasCliente(unittest.TestCase):
    setUp = partidas.PartidasRetentativasCliente.setUp
    fabricar = partidas.PartidasRetentativasCliente.fabricar
    preparar = partidas.PartidasRetentativasCliente.preparar
    partir = partidas.PartidasRetentativasCliente.partir
    retrato = partidas.PartidasRetentativasCliente.retrato
    tarefa = partidas.PartidasRetentativasCliente.tarefa
    terminar = partidas.PartidasRetentativasCliente.terminar
    bloquear = partidas.PartidasRetentativasCliente.bloquear

    def associacoes(self):
        return self.infra.obter_associacoes_retentativas()

    def recursos(self):
        return self.infra.registro_recursos.obter_retrato()["recursos"]

    def negativo(self):
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])
        self.assertFalse(self.infra.avaliar()["cobertura_completa"])

    def confirmar_thread(self):
        self.assertTrue(self.infra.observar_termino_retentativas()[-1]["termino_observado"])

    def par_leitor(self):
        bruto = SocketLeituraFalso()
        cliente = self.leitor.recursos_cliente.abrir_socket(lambda: bruto)
        arquivo = cliente.makefile("r", encoding="utf-8")
        return cliente, arquivo, bruto

    def executar_descoberta(self, *, resposta=True, udp=None, tcp=None):
        udp, tcp = udp or SocketDescobertaFalso(), tcp or SocketDescobertaFalso()
        if resposta:
            udp.recvfrom.side_effect = [(b"TC420_SERVER_HERE", ("simulado", 42101))]
        self.preparar()
        self.partir()
        self.leitor._parada = Mock()
        self.leitor._parada.wait.return_value = True
        with patch("rede.buscarservidor.socket.socket", side_effect=lambda familia, tipo:
                   udp if tipo == socket.SOCK_DGRAM else tcp), \
                patch("rede.lerdadosserver.time.monotonic", side_effect=[0, 0]), patch("builtins.print"):
            self.threads[-1].target()
        return udp, tcp

    def executar_sem_busca(self):
        self.leitor.executando = False
        self.preparar()
        self.partir()
        self.threads[-1].target()

    def proprio_pendente(self):
        criados = []
        def executar():
            dono = self.leitor._partidas_retentativas.recursos_da_execucao(self.leitor.recursos_cliente)
            bruto = SocketLeituraFalso()
            criados.extend((dono.abrir_socket(lambda: bruto), bruto))
        self.leitor._aguardar_proxima_tentativa = executar
        self.preparar()
        self.partir()
        self.threads[-1].target()
        self.addCleanup(criados[0].close)
        return criados

    def vinculos(self, independentes=()):
        proprietarios = {r["recurso_id"]: item for item in self.associacoes() for r in item["recursos"]}
        vinculos = []
        for recurso in self.recursos():
            dono = proprietarios.get(recurso["recurso_id"])
            if dono is None and recurso["recurso_id"] not in independentes:
                raise AssertionError("propriedade não demonstrada pelo harness")
            vinculos.append(VinculoRecurso(recurso["recurso_id"], recurso["geracao_id"], recurso["retentativa_id"],
                                           None if dono is None else dono["retentativa_id"]))
        return tuple(vinculos)

    def compor(self, *, completa=True, vinculos=None, independentes=()):
        # Cobertura declarada somente do recorte controlado do harness. Nunca
        # instala cobertura completa em infraestrutura.avaliar ou no aplicativo.
        geracoes = {r["geracao_id"] for r in self.recursos()} | {t["geracao"] for t in self.retrato()}
        cobertura = CoberturaCliente(self.infra._contexto, tuple(sorted(geracoes)),
                                     tuple((t["geracao"], t["id"]) for t in self.retrato()),
                                     self.vinculos(independentes) if vinculos is None else vinculos, completa)
        return avaliar_cliente(self.infra._contexto, cobertura)

    def test_01_sem_recurso_proprio_associacao_vazia_justificada(self):
        self.executar_sem_busca()
        item, = self.associacoes()
        self.assertTrue(item["cobertura_recursos_completa"])
        self.assertEqual([], item["recursos"])
        self.assertEqual([], self.recursos())
        self.negativo()

    def test_02_descoberta_real_cria_udp_tcp_com_vinculos_explicitos(self):
        self.executar_descoberta()
        item, = self.associacoes()
        self.assertEqual(self.infra.aplicacao_id, item["aplicacao_id"])
        self.assertEqual(["socket_udp", "socket_tcp"], [r["tipo"] for r in item["recursos"]])
        self.assertEqual(2, len({r["recurso_id"] for r in item["recursos"]}))
        self.assertTrue(item["cobertura_recursos_completa"])
        self.assertTrue(all(r["retentativa_id"] == item["retentativa_id"] for r in self.recursos()))
        self.assertTrue(all(r["responsabilidade"] == "proprio" for r in item["recursos"]))

    def test_03_recurso_leitor_permanente_nao_associado(self):
        cliente, arquivo, _ = self.par_leitor()
        antes = self.recursos()
        self.executar_descoberta()
        ids = {r["recurso_id"] for r in self.associacoes()[0]["recursos"]}
        self.assertTrue(ids.isdisjoint(r["recurso_id"] for r in antes))
        self.assertEqual(antes, self.recursos()[:2])
        arquivo.close()
        cliente.close()

    def test_04_mesma_geracao_nao_transfere_propriedade(self):
        cliente, arquivo, _ = self.par_leitor()
        self.executar_descoberta()
        self.assertEqual(self.recursos()[0]["geracao_id"], self.recursos()[-1]["geracao_id"])
        self.assertNotEqual(self.recursos()[0]["retentativa_id"], self.retrato()[0]["id"])
        self.assertEqual(2, len(self.associacoes()[0]["recursos"]))
        arquivo.close()
        cliente.close()

    def test_05_criacao_por_outra_thread_com_adaptador_leitor(self):
        criados = []
        tarefa = self.tarefa(lambda: criados.extend(self.par_leitor()))
        self.terminar(tarefa)
        self.assertEqual([], tarefa[2])
        self.executar_sem_busca()
        self.assertEqual([], self.associacoes()[0]["recursos"])
        self.assertEqual(self.leitor.recursos_cliente.atividade_id, self.recursos()[0]["retentativa_id"])
        criados[1].close()
        criados[0].close()

    def test_06_thread_terminal_recurso_independente_permanece(self):
        cliente, arquivo, _ = self.par_leitor()
        self.executar_sem_busca()
        self.confirmar_thread()
        independentes = [r["recurso_id"] for r in self.recursos()]
        resultado = self.compor(independentes=independentes)
        self.assertEqual(independentes, resultado["recursos_sem_retentativa"])
        self.assertFalse(resultado["encerramento_confirmado"])
        arquivo.close()
        cliente.close()

    def test_07_proprio_pendente_impede_composicao(self):
        self.proprio_pendente()
        self.confirmar_thread()
        self.guarda.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        resultado = self.compor()
        self.assertTrue(resultado["retentativas"][0]["execucao_confirmada"])
        self.assertFalse(resultado["retentativas"][0]["encerramento_confirmado"])
        self.assertFalse(resultado["encerramento_confirmado"])
        self.negativo()

    def test_08_proprio_fechado_evidencia_considerada(self):
        self.executar_descoberta()
        self.confirmar_thread()
        self.assertTrue(all(r["limpeza_confirmada"] for r in self.associacoes()[0]["recursos"]))
        resultado = self.compor()
        self.assertTrue(resultado["cobertura_completa"])
        self.assertEqual(2, len(resultado["retentativas"][0]["recursos"]))
        self.assertFalse(resultado["encerramento_confirmado"])

    def test_09_recurso_sem_retry_continua_agregado(self):
        cliente, arquivo, _ = self.par_leitor()
        self.executar_sem_busca()
        independentes = [r["recurso_id"] for r in self.recursos()]
        vinculos = self.vinculos(independentes)
        self.assertTrue(all(v.retentativa_id is None for v in vinculos))
        self.assertEqual(independentes, self.compor(independentes=independentes)["recursos_sem_retentativa"])
        arquivo.close()
        cliente.close()

    def test_10_associacao_duplicada_idempotente_incompativel_recusada(self):
        self.executar_descoberta()
        adaptador = next(iter(self.leitor._partidas_retentativas._escopos.values()))["recursos"]
        token = adaptador._emitidos[0]
        antes = self.associacoes()
        adaptador._associar_reserva(token, "socket_udp")
        self.assertEqual(antes, self.associacoes())
        with self.assertRaises(ValueError):
            adaptador._associar_reserva(token, "socket_tcp")
        self.assertEqual(antes, self.associacoes())

    def test_11_identidade_retry_invalida_recusada(self):
        acompanhamento = self.leitor._partidas_retentativas
        with self.assertRaises(ValueError):
            acompanhamento.recursos_da_retentativa(999, self.leitor.recursos_cliente)
        self.executar_descoberta()
        outro = InfraestruturaRegistrosCliente()
        geracao = outro.registro_retentativas.nova_geracao_cliente()
        estrangeira = outro.registro_retentativas.reservar_retentativa(geracao)
        with self.assertRaises(ValueError):
            acompanhamento.recursos_da_retentativa(estrangeira, self.leitor.recursos_cliente)

    def test_12_origem_de_geracao_estrangeira_recusada(self):
        outra = RecursosLeitorCliente(self.infra)
        acompanhamento = self.leitor._partidas_retentativas
        self.preparar()
        self.partir()
        identidade = acompanhamento._identidades[0]
        with self.assertRaises(ValueError):
            acompanhamento.recursos_da_retentativa(identidade, outra)

    def test_13_promocao_preserva_associacoes_antigas(self):
        self.executar_descoberta()
        antes = self.associacoes()
        self.guarda.promover(self.leitor.recursos_cliente._geracao_retentativas)
        self.assertEqual(antes, self.associacoes())

    def test_14_nova_geracao_preserva_vinculos(self):
        self.executar_descoberta()
        antes = self.associacoes()
        LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.assertEqual(antes, self.associacoes())

    def test_15_observador_terminal_nao_fecha_socket_proprio(self):
        cliente, bruto = self.proprio_pendente()
        self.confirmar_thread()
        self.assertFalse(bruto.fechado)
        self.assertEqual(0, bruto.close_chamadas)
        self.assertFalse(self.associacoes()[0]["recursos"][0]["limpeza_confirmada"])
        cliente.close()

    def test_16_global_permanece_negativo(self):
        self.executar_descoberta()
        self.confirmar_thread()
        self.guarda.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        self.negativo()

    def test_17_critica_a_falsa_associacao_por_geracao(self):
        cliente, arquivo, _ = self.par_leitor()
        self.executar_descoberta()
        adaptador = next(iter(self.leitor._partidas_retentativas._escopos.values()))["recursos"]
        with self.assertRaises(ValueError):
            adaptador._associar_reserva(cliente.recurso_id, "socket_tcp")
        self.assertEqual(2, len(self.associacoes()[0]["recursos"]))
        arquivo.close()
        cliente.close()

    def test_18_critica_b_thread_termina_com_recurso_proprio_aberto(self):
        self.proprio_pendente()
        self.confirmar_thread()
        self.assertTrue(self.retrato()[0]["thread_terminada"])
        self.assertFalse(self.associacoes()[0]["cobertura_recursos_completa"])  # Callback fora do caminho auditado.
        self.assertFalse(self.associacoes()[0]["recursos"][0]["limpeza_confirmada"])
        self.assertFalse(self.compor()["encerramento_confirmado"])

    def test_19_critica_c_promocao_responsabilidades_independentes(self):
        cliente, arquivo, _ = self.par_leitor()
        self.executar_sem_busca()
        self.confirmar_thread()
        origem = self.recursos()[0]["geracao_id"]
        self.guarda.promover(self.leitor.recursos_cliente._geracao_retentativas)
        LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.assertEqual([], self.associacoes()[0]["recursos"])
        self.assertEqual(origem, self.recursos()[0]["geracao_id"])
        self.assertFalse(self.recursos()[0]["encerramento_confirmado"])
        self.negativo()
        arquivo.close()
        cliente.close()

    def test_20_critica_d_consulta_durante_alocacao(self):
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        udp = SocketDescobertaFalso()
        def alocar(*args):
            self.bloquear(entrou, liberar)
            return udp
        self.preparar()
        self.partir()
        self.leitor._parada = Mock()
        self.leitor._parada.wait.return_value = True
        with patch("rede.buscarservidor.socket.socket", side_effect=alocar), \
                patch("rede.lerdadosserver.time.monotonic", side_effect=[0, 0]), patch("builtins.print"):
            tarefa = self.tarefa(self.threads[0].target)
            self.assertTrue(entrou.wait(3))
            item, = self.associacoes()
            self.assertTrue(item["execucao_em_curso"])
            self.assertFalse(item["cobertura_recursos_completa"])
            self.assertEqual(1, len(item["recursos"]))
            self.assertFalse(item["recursos"][0]["criacao_resolvida"])
            self.negativo()
            liberar.set()
            self.terminar(tarefa)
        self.assertEqual([], tarefa[2])

    def test_21_critica_e_termino_antes_da_avaliacao_de_recursos(self):
        self.proprio_pendente()
        self.confirmar_thread()
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])
        self.assertFalse(self.associacoes()[0]["recursos"][0]["limpeza_confirmada"])

    def test_22_cobertura_desconhecida_nao_confirma_vazio(self):
        self.leitor._aguardar_proxima_tentativa = Mock()
        self.preparar()
        self.partir()
        self.threads[0].target()
        self.confirmar_thread()
        item, = self.associacoes()
        self.assertEqual([], item["recursos"])
        self.assertFalse(item["cobertura_recursos_completa"])
        self.guarda.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()
        resultado = self.compor(completa=False)
        self.assertFalse(resultado["cobertura_completa"])
        self.assertFalse(resultado["encerramento_confirmado"])

    def test_23_falha_associacao_antes_fabrica_e_conservadora(self):
        self.preparar()
        self.partir()
        with patch.object(RecursosRetentativaCliente, "_associar_reserva", side_effect=RuntimeError("vinculo_simulado")), \
                patch("rede.buscarservidor.socket.socket") as abrir:
            with self.assertRaises(RuntimeError):
                self.threads[0].target()
        abrir.assert_not_called()
        self.assertTrue(self.recursos()[0]["ausencia_comprovada"])
        self.assertTrue(self.associacoes()[0]["erro_associacao"])
        self.assertFalse(self.associacoes()[0]["cobertura_recursos_completa"])
        self.negativo()

    def test_24_close_falho_preserva_vinculo_e_recurso(self):
        udp = SocketDescobertaFalso()
        udp.erro_close = OSError("limpeza_simulada")
        with self.assertRaises(OSError):
            self.executar_descoberta(udp=udp)
        item, = self.associacoes()
        self.assertTrue(item["recursos"])
        self.assertFalse(item["recursos"][0]["limpeza_confirmada"])
        self.assertTrue(self.recursos()[0]["erros_limpeza"])
        udp.erro_close = None
        udp.close()  # Cleanup apenas do fake, sem alterar a evidência histórica.
        self.negativo()

    def test_25_mapeamento_invalido_ou_duplicado_recusado_pela_composicao(self):
        self.executar_descoberta()
        self.confirmar_thread()
        validos = self.vinculos()
        for invalidos in (validos + (validos[0],),
                          (replace(validos[0], recurso_id=999),) + validos[1:],
                          (replace(validos[0], geracao_id=999),) + validos[1:],
                          (replace(validos[0], retentativa_id=999),) + validos[1:]):
            resultado = self.compor(vinculos=invalidos)
            self.assertFalse(resultado["cobertura_completa"])
            self.assertFalse(resultado["encerramento_confirmado"])

    def test_26_auditoria_alvo_sem_arquivo_http_ou_thread_nova(self):
        raiz = Path(__file__).resolve().parents[1]
        arvore = ast.parse((raiz / "rede/lerdadosserver.py").read_text(encoding="utf-8"))
        alvo = next(n for n in ast.walk(arvore) if isinstance(n, ast.FunctionDef) and n.name == "_aguardar_proxima_tentativa")
        chamadas = [ast.unparse(n.func) for n in ast.walk(alvo) if isinstance(n, ast.Call)]
        self.assertEqual(1, chamadas.count("buscar_servidor"))
        self.assertFalse({"open", "socket.socket", "threading.Thread", "requests.get", "requests.post"} & set(chamadas))

    def test_27_adaptador_nao_pode_ser_usado_fora_da_execucao(self):
        self.executar_descoberta()
        adaptador = next(iter(self.leitor._partidas_retentativas._escopos.values()))["recursos"]
        fabrica = Mock()
        with self.assertRaises(RuntimeError):
            adaptador.abrir_socket(fabrica)
        fabrica.assert_not_called()

    def test_28_outra_thread_nao_herda_propriedade_por_geracao(self):
        resultados = []
        def executar():
            adaptador = self.leitor._partidas_retentativas.recursos_da_execucao(self.leitor.recursos_cliente)
            tarefa = self.tarefa(lambda: adaptador.abrir_socket(lambda: SocketLeituraFalso()))
            self.terminar(tarefa)
            resultados.extend(tarefa[2])
        self.leitor._aguardar_proxima_tentativa = executar
        self.preparar()
        self.partir()
        self.threads[0].target()
        self.assertIsInstance(resultados[0], RuntimeError)
        self.assertEqual([], self.recursos())
        self.negativo()

    def test_29_duas_retentativas_mesma_geracao_vinculos_distintos(self):
        self.executar_descoberta()
        anterior = self.associacoes()[0]
        self.executar_descoberta()
        self.assertEqual(anterior, self.associacoes()[0])
        self.assertNotEqual(anterior["retentativa_id"], self.associacoes()[1]["retentativa_id"])
        ids_a = {r["recurso_id"] for r in anterior["recursos"]}
        self.assertTrue(ids_a.isdisjoint(r["recurso_id"] for r in self.associacoes()[1]["recursos"]))

    def test_30_query_associacoes_nao_observa_thread_nem_fecha_recursos(self):
        cliente, bruto = self.proprio_pendente()
        self.associacoes()
        self.threads[0].is_alive.assert_not_called()
        self.assertEqual(0, bruto.close_chamadas)
        self.assertFalse(self.retrato()[0]["thread_terminada"])
        cliente.close()

    def test_31_wrapper_do_leitor_nao_e_transferencia_automatica(self):
        cliente, arquivo, _ = self.par_leitor()
        def executar():
            dono = self.leitor._partidas_retentativas.recursos_da_execucao(self.leitor.recursos_cliente)
            self.assertIs(cliente, dono.abrir_socket(cliente))
        self.leitor._aguardar_proxima_tentativa = executar
        self.preparar()
        self.partir()
        self.threads[0].target()
        self.assertEqual([], self.associacoes()[0]["recursos"])
        self.assertEqual(self.leitor.recursos_cliente.atividade_id, self.recursos()[0]["retentativa_id"])
        arquivo.close()
        cliente.close()

    def test_32_arquivo_aplicacao_e_preparacao_http_independentes(self):
        from config import configuracao
        from config.arquivos import ContextoArquivosConfiguracao
        from test_delimitacao_arquivos_locais import ArquivoMemoria
        contexto = ContextoArquivosConfiguracao(self.infra)
        http = self.infra.preparar_http_inicial()
        arquivo = ArquivoMemoria("{}")
        with patch.object(configuracao, "existe_configuracao", return_value=True), \
                patch.object(configuracao, "obter_caminho_configuracao", return_value="virtual-ac2c.json"), \
                patch("builtins.open", return_value=arquivo):
            self.assertEqual({}, configuracao.carregar_configuracao(contexto_arquivos=contexto))
        self.executar_sem_busca()
        self.assertEqual([], self.associacoes()[0]["recursos"])
        self.assertEqual("arquivo_comum", self.recursos()[0]["tipo"])
        self.assertNotEqual(http.geracao_id, self.retrato()[0]["geracao"])
        self.assertEqual([], self.infra.registro_http.obter_retrato()["operacoes"])
        self.negativo()

    def test_33_reserva_e_associacao_antes_fabrica_sem_locks(self):
        udp = SocketDescobertaFalso()
        def alocar(*args):
            item, = self.associacoes()
            self.assertEqual(1, len(item["recursos"]))
            self.assertFalse(item["recursos"][0]["criacao_resolvida"])
            acompanhamento = self.leitor._partidas_retentativas
            dono = next(iter(acompanhamento._escopos.values()))["recursos"]
            for lock in (self.guarda._lock, acompanhamento._lock, dono._lock_vinculos,
                         self.infra.registro_recursos._lock):
                self.assertTrue(lock.acquire(blocking=False))
                lock.release()
            return udp
        self.preparar()
        self.partir()
        self.leitor._parada = Mock()
        self.leitor._parada.wait.return_value = True
        with patch("rede.buscarservidor.socket.socket", side_effect=alocar), \
                patch("rede.lerdadosserver.time.monotonic", side_effect=[0, 0]), patch("builtins.print"):
            self.threads[0].target()

    def test_34_publicacao_do_handle_falha_vinculo_e_responsabilidade_permanecem(self):
        udp = SocketDescobertaFalso()
        def falhar(token, fabrica):
            fabrica()
            raise RuntimeError("publicacao_simulada")
        self.preparar()
        self.partir()
        with patch("rede.buscarservidor.socket.socket", return_value=udp), \
                patch.object(self.infra.registro_recursos, "criar", side_effect=falhar):
            with self.assertRaises(RuntimeError):
                self.threads[0].target()
        item, = self.associacoes()
        self.assertEqual(1, len(item["recursos"]))
        self.assertFalse(item["recursos"][0]["limpeza_confirmada"])
        dono = next(iter(self.leitor._partidas_retentativas._escopos.values()))["recursos"]
        self.assertTrue(dono.obter_publicacoes_pendentes())
        self.assertEqual(item["recursos"][0]["recurso_id"], self.recursos()[0]["recurso_id"])
        self.negativo()

    def test_35_uso_parcial_do_adaptador_nao_comprova_cobertura(self):
        criados = []
        def executar():
            dono = self.leitor._partidas_retentativas.recursos_da_execucao(self.leitor.recursos_cliente)
            criados.append(dono.abrir_socket(lambda: SocketLeituraFalso()))
            criados.append(self.leitor.recursos_cliente.abrir_socket(lambda: SocketLeituraFalso()))
        self.leitor._aguardar_proxima_tentativa = executar
        self.preparar()
        self.partir()
        self.threads[0].target()
        self.confirmar_thread()
        item, = self.associacoes()
        self.assertEqual(1, len(item["recursos"]))
        self.assertEqual(2, len(self.recursos()))
        self.assertFalse(item["cobertura_recursos_completa"])
        self.assertIsNone(item["evidencia_cobertura"])
        self.assertFalse(self.compor(completa=False, vinculos=())["encerramento_confirmado"])
        self.negativo()
        for cliente in criados:
            cliente.close()

# Testes de diagnostico refresh seguro: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.12: worker real, transporte/tempo/parada falsos; nenhum Tk ou rede."""
import ast
from contextlib import contextmanager
from pathlib import Path
import sys
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
from urllib.parse import parse_qs, urlsplit
from uuid import uuid4

import requests

from mensagens_seguras import classificar_erro_http, mensagem_erro_http
from interface.mensagens_seguras import mensagem_erro_login
from rede import servidor
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from tc420.web import WebTC420
import test_login_http_integrado as login


ESTADO = dict(estado="00", peso_bruto="10", tara="1", peso_liquido="9", unidade="kg", multirange="1")
REFRESH = b"SUCCESS:REFRESH:00;00;data;hora;id;balanca;10;1;9;kg;modo;1"


# Grupo de 20 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class DiagnosticoRefreshSeguro(unittest.TestCase):
    transporte = login.LoginHttpIntegrado.transporte

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.registro_antes = self.infra.registro_http.obter_retrato()
        self.marcadores = [uuid4().hex for _ in range(4)]
        u, s, t, h = self.marcadores
        self.sensivel = f"https://{u}:{s}@simulado.invalid/?token={t} Authorization: {h}"

    @contextmanager
    def ambiente(self, quantidade=1, saude=None):
        estado = dict(saudavel=True, falhas_consecutivas=0, ultimo_sucesso=42,
                      ultimo_erro=None, inicio_indisponibilidade=None)
        estado.update(saude or {})
        retratos = []
        parada = Mock()
        parada.is_set.return_value = False
        def esperar(intervalo):
            retratos.append(servidor.obter_saude_tc420())
            return len(retratos) >= quantidade
        parada.wait.side_effect = esperar
        relogio = SimpleNamespace(time=Mock(return_value=100), monotonic=Mock(return_value=200))
        with patch.object(servidor, "saude_tc420", estado), \
                patch.object(servidor, "dados_atuais", {}), \
                patch.object(servidor, "evento_parada_servidor", parada), \
                patch.object(servidor, "lock_saude", threading.Lock()), \
                patch.object(servidor, "time", relogio), patch("builtins.print") as console:
            yield SimpleNamespace(saude=estado, retratos=retratos, parada=parada, console=console, tempo=relogio)

    def seguro(self, ambiente):
        saidas = (repr(ambiente.console.call_args_list), str(ambiente.saude["ultimo_erro"]))
        self.assertTrue(all(m not in s for m in self.marcadores for s in saidas))
        self.assertEqual(self.registro_antes, self.infra.registro_http.obter_retrato())

    def falhar(self, erro):
        web = Mock(obter_estado=Mock(side_effect=erro))
        with self.ambiente() as a:
            servidor.ler_tc420(web)
            self.seguro(a)
            self.assertEqual(mensagem_erro_http(erro), a.saude["ultimo_erro"])
            self.assertEqual(1, a.saude["falhas_consecutivas"])
            self.assertTrue(a.saude["saudavel"])
            self.assertEqual(42, a.saude["ultimo_sucesso"])
            self.assertIsNone(a.saude["inicio_indisponibilidade"])
            a.parada.wait.assert_called_once_with(servidor.INTERVALO_LEITURA)
        web.obter_estado.assert_called_once_with()
        return a

    def test_01_http_error_token_console(self):
        self.falhar(requests.HTTPError(self.sensivel))

    def test_02_url_sensivel_diagnostico(self):
        a = self.falhar(requests.HTTPError(self.sensivel))
        self.assertNotIn("https://", a.saude["ultimo_erro"])

    def test_03_query_token_http_real(self):
        web = WebTC420("simulado.invalid")
        web.token = self.marcadores[2]
        with self.ambiente() as a, self.transporte(status=503):
            servidor.ler_tc420(web)
            self.seguro(a)

    def test_04_credenciais_incorporadas_url_http_real(self):
        u, s, _, _ = self.marcadores
        web = WebTC420(f"{u}:{s}@simulado.invalid")
        web.token = self.marcadores[2]
        with self.ambiente() as a, self.transporte(status=401):
            servidor.ler_tc420(web)
            self.seguro(a)

    def test_05_timeout(self):
        self.falhar(requests.Timeout(self.sensivel))

    def test_06_conexao(self):
        self.falhar(requests.ConnectionError(self.sensivel))

    def status_real(self, status):
        web = WebTC420("simulado.invalid")
        web.token = self.marcadores[2]
        with self.ambiente(3) as a, self.transporte(status=status) as adaptador:
            servidor.ler_tc420(web)
            self.seguro(a)
            self.assertEqual(3, len(adaptador.enviados))
            self.assertEqual([1, 2, 3], [r["falhas_consecutivas"] for r in a.retratos])
            self.assertEqual([True, True, False], [r["saudavel"] for r in a.retratos])
            self.assertEqual(200, a.saude["inicio_indisponibilidade"])
            self.assertEqual(42, a.saude["ultimo_sucesso"])
            self.assertFalse(a.parada.set.called)
            self.assertEqual(3, a.parada.wait.call_count)

    def test_07_http_4xx_preserva_saude(self):
        self.status_real(401)

    def test_08_http_5xx_preserva_saude(self):
        self.status_real(503)

    def test_09_inesperada(self):
        self.falhar(ValueError(self.sensivel))

    def test_10_ultimo_erro_copia_sanitizada(self):
        a = self.falhar(requests.Timeout(self.sensivel))
        with patch.object(servidor, "saude_tc420", a.saude):
            copia = servidor.obter_saude_tc420()
        self.assertIsNot(copia, a.saude)
        self.assertEqual(a.saude, copia)

    def test_11_novo_erro_atualiza_diagnostico(self):
        erros = [requests.Timeout(self.sensivel), requests.ConnectionError(self.sensivel)]
        with self.ambiente(2) as a:
            servidor.ler_tc420(Mock(obter_estado=Mock(side_effect=erros)))
            self.seguro(a)
            self.assertEqual([mensagem_erro_http(e) for e in erros], [r["ultimo_erro"] for r in a.retratos])
            self.assertEqual(2, a.saude["falhas_consecutivas"])

    def test_12_sucesso_protocolo_dados_frequencia(self):
        web = WebTC420("simulado.invalid")
        web.token = self.marcadores[2]
        with self.ambiente(saude=dict(ultimo_erro="falha_anterior", saudavel=False,
                                    falhas_consecutivas=4, inicio_indisponibilidade=1)) as a, \
                self.transporte(REFRESH) as adaptador, patch("tc420.web.random.random", return_value=0.25):
            servidor.ler_tc420(web)
            self.assertEqual(ESTADO, servidor.obter_dados_atuais())
            self.assertTrue(a.saude["saudavel"])
            self.assertEqual(0, a.saude["falhas_consecutivas"])
            self.assertEqual(100, a.saude["ultimo_sucesso"])
            self.assertIsNone(a.saude["ultimo_erro"])
            self.assertIsNone(a.saude["inicio_indisponibilidade"])
            pedido, opcoes = adaptador.enviados[0]
            self.assertEqual("GET", pedido.method)
            self.assertEqual(web.url, pedido.url.split("?")[0])
            self.assertEqual(dict(cmd=["refresh"], scale=["1"], token=[web.token], math=["0.25"]),
                             parse_qs(urlsplit(pedido.url).query))
            self.assertEqual(5, opcoes["timeout"])
            self.assertFalse(opcoes["verify"])
            a.parada.wait.assert_called_once_with(servidor.INTERVALO_LEITURA)
            self.seguro(a)
        self.assertEqual(self.marcadores[2], web.token)

    def test_13_excecao_original_durante_tratamento(self):
        erro = requests.HTTPError(self.sensivel)
        erro.response = requests.Response()
        erro.response.status_code = 403
        erro.request = requests.Request("GET", "https://simulado.invalid").prepare()
        args, resposta, pedido = erro.args, erro.response, erro.request
        observados = []
        def diagnosticar(recebido):
            self.assertIs(erro, recebido)
            self.assertIs(erro, sys.exception())
            observados.append(recebido)
            return mensagem_erro_http(recebido)
        with patch.object(servidor, "mensagem_erro_http", side_effect=diagnosticar):
            self.falhar(erro)
        self.assertEqual(1, len(observados))
        self.assertEqual(args, erro.args)
        self.assertIs(resposta, erro.response)
        self.assertIs(pedido, erro.request)

    def test_14_login_cliente_contrato_e_dependencias(self):
        casos = [(requests.Timeout(self.sensivel), "Tempo de conexão com a TC420 esgotado. Tente novamente."),
                 (RuntimeError("Login recusado pela TC420: " + self.sensivel),
                  "Login recusado pela TC420. Verifique usuário e senha."),
                 (RuntimeError("Approval recusado pela TC420: " + self.sensivel), "Approval recusado pela TC420."),
                 (RuntimeError("infraestrutura_http_ausente_ou_invalida"), "infraestrutura_http_ausente_ou_invalida"),
                 (RuntimeError("admissao_contexto_http_recusada"), "admissao_contexto_http_recusada")]
        for erro, esperado in casos:
            self.assertEqual(esperado, mensagem_erro_login(erro))
        raiz = Path(__file__).resolve().parents[1]
        neutro = ast.parse((raiz / "mensagens_seguras.py").read_text(encoding="utf-8"))
        imports = [n for n in ast.walk(neutro) if isinstance(n, (ast.Import, ast.ImportFrom))]
        self.assertEqual(1, len(imports))
        self.assertEqual("requests", imports[0].names[0].name)
        # Servidor usa o módulo neutro e não importa a camada gráfica.
        arvore = ast.parse((raiz / "rede/servidor.py").read_text(encoding="utf-8"))
        self.assertFalse(any(isinstance(n, ast.ImportFrom) and (n.module or "").startswith("interface") for n in ast.walk(arvore)))

    def test_15_abandono_principal_politica_preservada(self):
        with self.ambiente(10, dict(falhas_consecutivas=2)) as a:
            # Terceira falha inicia indisponibilidade em 200; consulta seguinte
            # atinge exatamente o limite de abandono já existente.
            a.tempo.monotonic.side_effect = [200, 200, 200 + servidor.TEMPO_ABANDONO_PRINCIPAL]
            web = Mock(obter_estado=Mock(side_effect=requests.ConnectionError(self.sensivel)))
            servidor.ler_tc420(web)
            self.assertEqual(2, web.obter_estado.call_count)
            self.assertEqual(4, a.saude["falhas_consecutivas"])
            self.assertFalse(a.saude["saudavel"])
            a.parada.set.assert_called_once_with()
            a.parada.wait.assert_called_once_with(servidor.INTERVALO_LEITURA)
            self.seguro(a)

    def test_16_encerramento_global_continua_negativo(self):
        self.falhar(requests.Timeout(self.sensivel))
        self.infra.registro_http.fechar_admissao()
        self.assertTrue(self.infra.registro_http.obter_retrato()["conjunto_http_resolvido"])
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])
        self.assertFalse(self.infra.avaliar()["cobertura_completa"])

    def test_17_critico_a_dois_destinos_http_error_real(self):
        web = WebTC420("simulado.invalid")
        web.token = self.marcadores[2]
        with self.ambiente() as a, self.transporte(status=401) as adaptador:
            servidor.ler_tc420(web)
            self.assertIn(web.token, adaptador.resposta.url)  # O erro fonte tem dado sensível.
            self.seguro(a)
            self.assertEqual("Autenticação não autorizada pela TC420.", a.saude["ultimo_erro"])
            self.assertTrue(any(a.saude["ultimo_erro"] in str(c) for c in a.console.call_args_list))

    def test_18_critico_b_formato_arbitrario_sem_str_repr(self):
        class ErroHostil(Exception):
            def __str__(self):
                raise AssertionError("str_nao_permitido")

            def __repr__(self):
                raise AssertionError("repr_nao_permitido")
        erro = ErroHostil({"headers": self.sensivel}, self.marcadores)
        self.falhar(erro)
        self.assertEqual("inesperada", classificar_erro_http(erro))

    def test_19_critico_c_falha_e_recuperacao(self):
        resultados = [requests.Timeout(self.sensivel)] * 3 + [ESTADO]
        with self.ambiente(4) as a:
            servidor.ler_tc420(Mock(obter_estado=Mock(side_effect=resultados)))
            self.assertEqual([True, True, False, True], [r["saudavel"] for r in a.retratos])
            self.assertEqual([1, 2, 3, 0], [r["falhas_consecutivas"] for r in a.retratos])
            self.assertIsNone(a.saude["ultimo_erro"])
            self.assertIsNone(a.saude["inicio_indisponibilidade"])
            self.assertEqual(100, a.saude["ultimo_sucesso"])
            self.seguro(a)

    def test_20_critico_d_falhas_concorrentes_mensagens_locais(self):
        barreira = threading.Barrier(2)
        erros = [requests.Timeout(self.sensivel), requests.ConnectionError(self.sensivel)]
        problemas = []
        def diagnosticar(erro):
            mensagem = mensagem_erro_http(erro)
            barreira.wait(3)
            return mensagem
        def executar(erro):
            try:
                servidor.ler_tc420(Mock(obter_estado=Mock(side_effect=erro)))
            except BaseException as problema:
                problemas.append(problema)
        with self.ambiente(1) as a, patch.object(servidor, "mensagem_erro_http", side_effect=diagnosticar):
            # Cada atividade executa uma iteração; nenhum worker real adicional
            # é introduzido na aplicação por este ensaio.
            a.parada.wait.side_effect = None
            a.parada.wait.return_value = True
            threads = [threading.Thread(target=executar, args=(e,), daemon=True) for e in erros]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join(3)
                self.assertFalse(thread.is_alive())
            self.assertEqual([], problemas)
            self.assertEqual(2, a.saude["falhas_consecutivas"])
            self.assertTrue(a.saude["saudavel"])
            mensagens = [c.args[0] for c in a.console.call_args_list if c.args and
                         isinstance(c.args[0], str) and c.args[0].startswith("Erro na leitura HTTP")]
            self.assertEqual(2, len(mensagens))
            for erro in erros:
                self.assertEqual(1, sum(m.endswith(mensagem_erro_http(erro)) for m in mensagens))
            self.assertIn(a.saude["ultimo_erro"], [mensagem_erro_http(e) for e in erros])
            self.seguro(a)

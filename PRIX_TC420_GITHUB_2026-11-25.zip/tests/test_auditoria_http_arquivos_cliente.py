# Testes de auditoria http arquivos cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-A somente análise: Requests real com adapter falso e arquivos em memória.

Não acessa sockets internos, rede, configuração real, keyring ou Tk.
As simulações de streaming são contratos da biblioteca, ausentes no aplicativo.
"""
import ast
from contextlib import contextmanager
import io
from pathlib import Path
import threading
import unittest
from unittest.mock import patch

import requests
from requests.adapters import BaseAdapter

from config import configuracao
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from tc420.web import WebTC420
from test_recursos_cliente_integrados import SocketLeituraFalso


RAIZ = Path(__file__).resolve().parents[1]


def arvore(caminho):
    return ast.parse((RAIZ / caminho).read_text(encoding="utf-8"))


def chamadas(caminho):
    return [n for n in ast.walk(arvore(caminho)) if isinstance(n, ast.Call)]


class CorpoFalso:
    """Interface de corpo público para Response, sem socket ou descritor real."""
    def __init__(self, partes):
        self.partes = partes
        self.lidos = 0
        self.fechamentos = 0
        self.liberacoes = 0

    def stream(self, tamanho, decode_content=True):
        for parte in self.partes:
            self.lidos += 1
            yield parte

    def close(self):
        self.fechamentos += 1

    def release_conn(self):
        self.liberacoes += 1


class AdaptadorFalso(BaseAdapter):
    def __init__(self, corpo, status=200, erro=None, antes=None):
        self.corpo, self.status, self.erro, self.antes = corpo, status, erro, antes
        self.fechamentos = 0
        self.enviados = []
        self.resposta = None

    def send(self, request, **kwargs):
        self.enviados.append((request, kwargs))
        if self.antes:
            self.antes()
        if self.erro:
            raise self.erro
        resposta = requests.Response()
        resposta.status_code = self.status
        resposta.url = request.url
        resposta.request = request
        resposta.encoding = "utf-8"
        resposta.raw = self.corpo  # API pública de corpo; nenhum socket privado.
        self.resposta = resposta
        return resposta

    def close(self):
        self.fechamentos += 1


class ArquivoMemoria(io.StringIO):
    def __init__(self, texto='', erro_leitura=None, erro_close=None):
        super().__init__(texto)
        self.erro_leitura, self.erro_close = erro_leitura, erro_close
        self.fechamentos = 0
        self.conteudo_ao_fechar = None

    def read(self, *args):
        if self.erro_leitura:
            raise self.erro_leitura
        return super().read(*args)

    def close(self):
        self.fechamentos += 1
        if self.erro_close:
            raise self.erro_close
        if not self.closed:
            self.conteudo_ao_fechar = self.getvalue()
        super().close()


# Grupo de 23 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AuditoriaHttpArquivosCliente(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.dono = RecursosLeitorCliente(self.infra)
        self.web = WebTC420("balanca-simulada")
        self.web.token = object()  # Marcador de estado; nenhuma credencial real.

    def global_negativo(self):
        self.assertFalse(self.infra.avaliar()["encerramento_confirmado"])
        self.assertFalse(self.infra.avaliar()["cobertura_completa"])

    @contextmanager
    def transporte(self, corpo=None, **kwargs):
        corpo = corpo or CorpoFalso([b"SUCCESS:APPROVAL:simulado"])
        adaptador = AdaptadorFalso(corpo, **kwargs)
        sessao = requests.Session()
        sessao.trust_env = False  # Não consultar proxy/netrc/credenciais locais.
        sessao.mount("https://", adaptador)
        with patch("requests.api.sessions.Session", return_value=sessao) as fabrica:
            yield adaptador, fabrica

    @contextmanager
    def arquivo(self, arquivo):
        with patch.object(configuracao, "existe_configuracao", return_value=True), \
                patch.object(configuracao, "obter_caminho_configuracao", return_value="virtual-simulado.json"), \
                patch("builtins.open", return_value=arquivo) as abrir:
            yield abrir

    def test_01_http_simples_proprietario_biblioteca_e_resposta_local(self):
        with self.transporte() as (adaptador, fabrica):
            self.assertEqual("simulado", self.web.approval())
        requisicao, opcoes = adaptador.enviados[0]
        self.assertEqual("GET", requisicao.method)
        self.assertTrue(requisicao.url.startswith(self.web.url + '?'))
        self.assertEqual(5, opcoes["timeout"])
        self.assertFalse(opcoes["verify"])
        self.assertEqual(1, fabrica.call_count)
        self.assertEqual(1, adaptador.fechamentos)
        self.assertEqual(1, adaptador.corpo.lidos)
        self.assertEqual([], self.infra.registro_recursos.obter_retrato()["recursos"])

    def test_02_timeout_sem_resposta_fecha_sessao_efemera(self):
        original = requests.Timeout("timeout_simulado")
        with self.transporte(erro=original) as (adaptador, _):
            with self.assertRaises(requests.Timeout) as capturado:
                self.web.approval()
        self.assertIs(original, capturado.exception)
        self.assertIsNone(adaptador.resposta)
        self.assertEqual(1, adaptador.fechamentos)
        self.global_negativo()

    def test_03_http_error_apos_corpo_consumido_sem_close_explicito_app(self):
        with self.transporte(status=500) as (adaptador, _):
            with self.assertRaises(requests.HTTPError) as capturado:
                self.web.approval()
        self.assertIs(adaptador.resposta, capturado.exception.response)
        self.assertEqual(1, adaptador.corpo.lidos)
        self.assertEqual(1, adaptador.fechamentos)
        self.assertEqual(0, adaptador.corpo.fechamentos)
        self.global_negativo()

    def test_04_streaming_sintetico_exige_close_publico(self):
        corpo = CorpoFalso([b"parte-1", b"parte-2"])
        with self.transporte(corpo) as (adaptador, _):
            with requests.get(self.web.url, stream=True, timeout=5) as resposta:
                iterador = resposta.iter_content(chunk_size=1)
                self.assertEqual(b"parte-1", next(iterador))
                self.assertEqual(1, corpo.lidos)
                self.assertEqual(0, corpo.fechamentos)
        self.assertEqual(1, corpo.fechamentos)
        self.assertEqual(1, corpo.liberacoes)
        self.assertEqual(1, adaptador.fechamentos)

    def test_05_sem_streaming_requests_consumiu_antes_de_retornar(self):
        corpo = CorpoFalso([b"SUCCESS:", b"APPROVAL:", b"simulado"])
        with self.transporte(corpo) as (adaptador, _):
            self.assertEqual("simulado", self.web.approval())
        self.assertFalse(adaptador.enviados[0][1]["stream"])
        self.assertEqual(3, corpo.lidos)
        self.assertEqual(1, adaptador.fechamentos)

    def test_06_ausencia_session_persistente_no_codigo(self):
        for caminho in ("tc420/web.py", "main.py", "interface/conexao.py", "rede/lerdadosserver.py"):
            self.assertFalse(any(isinstance(n.func, ast.Attribute) and n.func.attr == "Session"
                                 for n in chamadas(caminho)))
        self.assertEqual({"ip", "url", "token"}, set(vars(self.web)))

    def test_07_arquivo_with_fecha_apos_leitura(self):
        arquivo = ArquivoMemoria('{"salvar_login":false}')
        with self.arquivo(arquivo) as abrir:
            self.assertEqual({"salvar_login": False}, configuracao.carregar_configuracao())
        abrir.assert_called_once_with("virtual-simulado.json", "r", encoding="utf-8")
        self.assertTrue(arquivo.closed)
        self.assertEqual(1, arquivo.fechamentos)

    def test_08_aberturas_auxiliares_delimitadas_por_executor_de_arquivo(self):
        raiz = arvore("config/configuracao.py")
        aberturas = [n for n in ast.walk(raiz) if isinstance(n, ast.Call) and ast.unparse(n.func) == "open"]
        self.assertEqual(2, len(aberturas))
        self.assertEqual(2, sum(isinstance(n, ast.Call) and ast.unparse(n.func) == "executar_arquivo"
                                for n in ast.walk(raiz)))
        self.assertFalse(any(ast.unparse(n.func) == "open" for n in chamadas("tc420/web.py")))

    def test_09_excecao_apos_abertura_ainda_fecha(self):
        arquivo = ArquivoMemoria('{invalido')
        with self.arquivo(arquivo):
            self.assertIsNone(configuracao.carregar_configuracao())
        self.assertTrue(arquivo.closed)
        self.assertEqual(1, arquivo.fechamentos)
        self.global_negativo()

    def test_10_web_antigo_nao_recebe_geracao_nova_automaticamente(self):
        original = self.web
        self.infra.registro_recursos.promover(self.dono.geracao_id)
        nova = RecursosLeitorCliente(self.infra)
        with self.transporte():
            self.assertEqual("simulado", original.approval())
        self.assertIs(original, self.web)
        self.assertNotEqual(self.dono.geracao_id, nova.geracao_id)
        self.assertFalse(hasattr(original, "geracao_id"))  # Lacuna de evidência, não propriedade certificada.
        self.global_negativo()

    def test_11_http_promocao_no_callback_examinado_sem_tag_de_recurso(self):
        raiz = arvore("main.py")
        funcao = next(n for n in ast.walk(raiz) if isinstance(n, ast.FunctionDef) and n.name == "promover_para_principal")
        nomes = [ast.unparse(n.func) for n in ast.walk(funcao) if isinstance(n, ast.Call)]
        self.assertIn("validar_infraestrutura", nomes)
        self.assertIn("infraestrutura.executar_login_promocao", nomes)
        self.assertIn("infraestrutura.executar_approval", nomes)
        self.assertNotIn("web.login", nomes)
        self.assertNotIn("web.obter_configuracao", nomes)
        self.assertIn("leitor.parar", nomes)
        # L3-B1.8 elimina o escape legado; WebTC420 não recebe tag de recurso.
        criacao = next(n for n in ast.walk(funcao) if isinstance(n, ast.Call) and ast.unparse(n.func) == "WebTC420")
        self.assertEqual(1, len(criacao.args))
        self.assertEqual(["politica_http"], [k.arg for k in criacao.keywords])
        self.assertEqual("infraestrutura.criar_politica_http()", ast.unparse(criacao.keywords[0].value))
        self.global_negativo()

    def test_12_sockets_internos_nao_inspecionados(self):
        with self.transporte() as (adaptador, _):
            self.web.approval()
        self.assertEqual(1, adaptador.fechamentos)
        self.assertEqual([], self.infra.registro_recursos.obter_retrato()["recursos"])
        atributos = {n.attr for n in ast.walk(arvore("tc420/web.py")) if isinstance(n, ast.Attribute)}
        self.assertFalse(atributos & {"raw", "_connection", "_sock", "poolmanager"})

    def test_13_tipo_desconhecido_nao_vira_socket_ficticio(self):
        reg = self.infra.registro_recursos
        with self.assertRaises(ValueError):
            reg.reservar("resposta_http", self.dono.geracao_id, self.dono.atividade_id)
        self.assertEqual([], reg.obter_retrato()["recursos"])
        self.global_negativo()

    def test_14_cliente_principal_sem_dupla_atribuicao(self):
        fontes_cliente = ("rede/lerdadosserver.py", "rede/buscarservidor.py")
        for caminho in fontes_cliente:
            self.assertFalse(any(ast.unparse(n.func).startswith("requests.") for n in chamadas(caminho)))
        raiz = arvore("rede/servidor.py")
        funcao = next(n for n in raiz.body if isinstance(n, ast.FunctionDef) and n.name == "ler_tc420")
        self.assertIn("web.obter_estado", [ast.unparse(n.func) for n in ast.walk(funcao) if isinstance(n, ast.Call)])
        estado = next(n for n in ast.walk(arvore("tc420/web.py")) if isinstance(n, ast.FunctionDef) and n.name == "obter_estado")
        self.assertIn("self.refresh", [ast.unparse(n.func) for n in ast.walk(estado) if isinstance(n, ast.Call)])

    def test_15_sem_recurso_http_persistente_ficticio(self):
        corpo = CorpoFalso([b"SUCCESS:APPROVAL:simulado"])
        with self.transporte(corpo) as (adaptador, _):
            self.web.approval()
        self.assertEqual(1, adaptador.fechamentos)
        self.assertNotIn("resposta", vars(self.web))
        self.assertNotIn("sessao", vars(self.web))
        self.assertEqual([], self.infra.registro_recursos.obter_retrato()["recursos"])

    def test_16_avaliacao_global_permanece_negativa(self):
        self.infra.registro_recursos.fechar_admissao()
        self.infra.registro_retentativas.fechar_admissao()
        self.global_negativo()

    def test_critico_A_consumo_parcial_ausente_no_app_contrato_stream_publico(self):
        requisicoes = [n for n in chamadas("tc420/web.py") if ast.unparse(n.func) in ("requests.get", "requests.post")]
        self.assertEqual(3, len(requisicoes))
        self.assertTrue(all(not any(k.arg == "stream" for k in n.keywords) for n in requisicoes))
        self.assertFalse(any(isinstance(n.func, ast.Attribute) and n.func.attr in ("iter_content", "iter_lines")
                             for n in chamadas("tc420/web.py")))
        corpo = CorpoFalso([b"parte-1", b"parte-2"])
        with self.transporte(corpo):
            with self.assertRaises(ValueError):
                with requests.get(self.web.url, stream=True, timeout=5) as resposta:
                    next(resposta.iter_content(chunk_size=1))
                    raise ValueError("corpo_simulado")
        self.assertEqual(1, corpo.fechamentos)

    def test_critico_B_falha_durante_leitura_arquivo(self):
        arquivo = ArquivoMemoria(erro_leitura=OSError("leitura_simulada"))
        with self.arquivo(arquivo):
            self.assertIsNone(configuracao.carregar_configuracao())
        self.assertTrue(arquivo.closed)
        self.assertEqual(1, arquivo.fechamentos)
        self.assertEqual([], self.infra.registro_recursos.obter_retrato()["recursos"])

    def test_critico_C_http_retido_promocao_preserva_objeto_mas_nao_certifica_geracao(self):
        entrou, liberar = threading.Event(), threading.Event()
        erros, resultados = [], []
        original = self.web
        def suspender():
            entrou.set()
            if not liberar.wait(3):
                raise AssertionError("barreira_nao_liberada")
        def tarefa():
            try:
                resultados.append(original.approval())
            except BaseException as erro:
                erros.append(erro)
        with self.transporte(antes=suspender) as (adaptador, _):
            thread = threading.Thread(target=tarefa)
            thread.start()
            try:
                self.assertTrue(entrou.wait(3))
                self.infra.registro_recursos.promover(self.dono.geracao_id)
                nova = RecursosLeitorCliente(self.infra)
                cliente = nova.abrir_socket(SocketLeituraFalso)
                cliente.close()
                self.assertIs(original, self.web)
                self.assertEqual(0, adaptador.fechamentos)
                self.assertFalse(hasattr(original, "geracao_id"))
                self.global_negativo()
            finally:
                liberar.set()
                thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(["simulado"], resultados)
        self.assertEqual(1, adaptador.fechamentos)

    def test_critico_D_contrato_publico_adapter_close_sem_ids_internos(self):
        with self.transporte() as (adaptador, fabrica):
            self.web.approval()
        fabrica.assert_called_once_with()
        self.assertEqual(1, adaptador.fechamentos)
        self.assertEqual([], self.infra.registro_recursos.obter_retrato()["recursos"])
        self.global_negativo()

    def test_escrita_configuracao_with_fecha_sem_arquivo_real(self):
        arquivo = ArquivoMemoria()
        with self.arquivo(arquivo) as abrir:
            resultado = configuracao.salvar_configuracao("rede-simulada", "balanca-simulada", 9800, "", False)
        self.assertTrue(arquivo.closed)
        self.assertEqual(9800, resultado["porta"])
        self.assertIn('"salvar_login": false', arquivo.conteudo_ao_fechar)
        abrir.assert_called_once_with("virtual-simulado.json", "w", encoding="utf-8")

    def test_falha_close_arquivo_nao_equivale_a_prova(self):
        arquivo = ArquivoMemoria('{}', erro_close=OSError("close_simulado"))
        try:
            with self.arquivo(arquivo):
                self.assertIsNone(configuracao.carregar_configuracao())
            self.assertFalse(arquivo.closed)
            self.global_negativo()
        finally:
            arquivo.erro_close = None
            arquivo.close()

    def test_parse_http_invalido_nao_prova_vazamento(self):
        corpo = CorpoFalso([b"formato-invalido"])
        with self.transporte(corpo) as (adaptador, _):
            with self.assertRaises(RuntimeError):
                self.web.approval()
        self.assertEqual(1, corpo.lidos)
        self.assertEqual(1, adaptador.fechamentos)
        self.global_negativo()


if __name__ == "__main__":
    unittest.main()

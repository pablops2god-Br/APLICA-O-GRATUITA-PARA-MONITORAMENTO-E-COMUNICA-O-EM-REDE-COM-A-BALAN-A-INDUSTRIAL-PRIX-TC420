# Testes de composicao operacional cliente: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-A: transportes/threads falsos, registros e caminhos operacionais reais."""
from copy import deepcopy
import ast
from pathlib import Path
import threading
import unittest
from unittest.mock import Mock, patch

from config.arquivos import ContextoArquivosConfiguracao
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.lerdadosserver import LeitorDadosServidor
import test_associacoes_retentativas_cliente as anteriores


# Grupo de 33 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class ComposicaoOperacionalCliente(unittest.TestCase):
    setUp = anteriores.AssociacoesRetentativasCliente.setUp
    fabricar = anteriores.AssociacoesRetentativasCliente.fabricar
    preparar = anteriores.AssociacoesRetentativasCliente.preparar
    partir = anteriores.AssociacoesRetentativasCliente.partir
    executar_descoberta = anteriores.AssociacoesRetentativasCliente.executar_descoberta
    executar_sem_busca = anteriores.AssociacoesRetentativasCliente.executar_sem_busca
    par_leitor = anteriores.AssociacoesRetentativasCliente.par_leitor
    tarefa = anteriores.AssociacoesRetentativasCliente.tarefa
    terminar = anteriores.AssociacoesRetentativasCliente.terminar

    def avaliar(self):
        resultado = self.infra.avaliar_responsabilidades_cliente()
        self.assertFalse(resultado['encerramento_cliente_confirmado'])
        self.assertFalse(resultado['encerramento_global_confirmado'])
        self.assertFalse(resultado['snapshot_atomico'])
        self.assertEqual('incompleta', resultado['cobertura_operacional'])
        return resultado

    def fechar_gates(self):
        self.guarda.fechar_admissao()
        self.infra.registro_recursos.fechar_admissao()

    def observar(self):
        self.assertTrue(self.infra.observar_termino_retentativas()[-1]['termino_observado'])

    def individual(self):
        return self.avaliar()['retentativas'][-1]

    def operacao_http(self):
        return self.infra.registro_http.admitir(self.infra.preparar_http_inicial(), 'login')

    def terminal(self):
        self.executar_descoberta()
        self.observar()
        self.fechar_gates()

    def recurso_pendente(self, tipo):
        registro = self.infra.registro_recursos
        fechar = registro.fechar
        tokens = []
        def reter(token):
            recurso = next(r for r in registro.obter_retrato()['recursos']
                           if r['recurso_id'] == token.numero)
            if recurso['tipo'] == tipo:
                tokens.append(token)
                return False
            return fechar(token)
        with patch.object(registro, 'fechar', side_effect=reter):
            self.executar_descoberta()
        for token in tokens:
            self.addCleanup(fechar, token)
        self.observar()
        self.fechar_gates()
        return tokens

    def test_01_ativa_nao_confirmada(self):
        self.preparar()
        self.partir()
        self.assertFalse(self.individual()['execucao_confirmada'])

    def test_02_retorno_sem_observacao(self):
        self.executar_descoberta()
        self.fechar_gates()
        self.assertFalse(self.individual()['encerramento_confirmado'])
        self.threads[0].is_alive.assert_not_called()

    def test_03_A_udp_pendente(self):
        tokens = self.recurso_pendente('socket_udp')
        item = self.individual()
        self.assertTrue(item['execucao_confirmada'])
        self.assertTrue(item['cobertura_recursos_completa'])
        self.assertFalse(item['encerramento_confirmado'])
        self.assertIn(tokens[0].numero, self.avaliar()['recursos_pendentes'])

    def test_04_thread_e_recursos_proprios_resolvidos(self):
        self.terminal()
        self.assertTrue(self.individual()['encerramento_confirmado'])
        self.assertEqual(2, len(self.individual()['recursos']))

    def test_05_associacao_incompleta(self):
        self.leitor._aguardar_proxima_tentativa = Mock()
        self.preparar()
        self.partir()
        self.threads[0].target()
        self.observar()
        self.fechar_gates()
        self.assertFalse(self.individual()['cobertura_recursos_completa'])
        self.assertFalse(self.individual()['encerramento_confirmado'])

    def test_06_vazio_com_cobertura_explicita(self):
        self.executar_sem_busca()
        self.observar()
        self.fechar_gates()
        item = self.individual()
        self.assertEqual([], item['recursos'])
        self.assertTrue(item['cobertura_recursos_completa'])
        self.assertTrue(item['encerramento_confirmado'])

    def test_07_B_subscribe_independente_aberto(self):
        cliente, arquivo, _ = self.par_leitor()
        self.addCleanup(cliente.close)
        self.addCleanup(arquivo.close)
        self.terminal()
        resultado = self.avaliar()
        self.assertTrue(resultado['retentativas'][0]['encerramento_confirmado'])
        self.assertEqual({cliente.recurso_id.numero, arquivo.recurso_id.numero},
                         set(resultado['recursos_sem_associacao_comprovada']))
        self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])

    def test_08_C_geracao_antiga_pendente(self):
        self.preparar()
        self.partir()
        antiga = self.leitor.recursos_cliente._geracao_retentativas
        self.guarda.promover(antiga)
        self.leitor = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.executar_sem_busca()
        self.observar()
        self.fechar_gates()
        a, b = self.avaliar()['retentativas']
        self.assertEqual(antiga.numero, a['geracao_id'])
        self.assertFalse(a['encerramento_confirmado'])
        self.assertTrue(b['encerramento_confirmado'])

    def test_09_http_em_andamento(self):
        op = self.operacao_http()
        entrou, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        def chamada():
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
        trabalho = self.tarefa(lambda: self.infra.registro_http.executar(op, chamada))
        try:
            self.assertTrue(entrou.wait(3))
            item, = self.avaliar()['http']
            self.assertEqual('em_andamento', item['estado'])
            self.assertFalse(item['execucao_resolvida'])
        finally:
            liberar.set()
            self.terminar(trabalho)
        self.assertEqual([], trabalho[2])

    def test_10_http_publicacao_desconhecida(self):
        op = self.operacao_http()
        self.infra.registro_http.executar(op, lambda: None)
        self.infra.registro_http.marcar_desconhecida(op, motivo='falha_publicacao')
        item, = self.avaliar()['http']
        self.assertEqual('desconhecida', item['estado'])
        self.assertFalse(item['execucao_resolvida'])

    def test_11_http_erro_funcional_resolvido(self):
        op = self.operacao_http()
        erro = OSError('conteudo_nao_publicavel_simulado')
        with self.assertRaises(OSError) as recebido:
            self.infra.registro_http.executar(op, Mock(side_effect=erro))
        self.assertIs(erro, recebido.exception)
        item, = self.avaliar()['http']
        self.assertTrue(item['execucao_resolvida'])
        self.assertEqual('falha', item['resultado'])
        self.assertEqual({'etapa': 'operacao', 'categoria': 'falha_io'}, item['erro'])
        self.assertNotIn(str(erro), str(self.avaliar()))

    def test_12_arquivo_retido(self):
        contexto = ContextoArquivosConfiguracao(self.infra)
        arquivo = Mock(closed=False)
        contexto.executar(lambda: arquivo, lambda f: None)
        item, = self.avaliar()['arquivos']
        self.assertTrue(item['handle_retido'])
        self.assertEqual([item['recurso_id']], self.avaliar()['retencoes_pendentes'])
        arquivo.closed = True
        self.infra.tentar_limpeza_arquivo(item['recurso_id'])

    def test_13_D_limpeza_retencao_nao_resolve_identidade(self):
        contexto = ContextoArquivosConfiguracao(self.infra)
        arquivo = Mock(closed=False)
        arquivo.close.side_effect = OSError('limpeza_simulada')
        def falhar(token, fabrica):
            fabrica()
            raise RuntimeError('associacao_simulada')
        with patch.object(self.infra.registro_recursos, 'criar', side_effect=falhar):
            with self.assertRaises(RuntimeError):
                contexto.executar(lambda: arquivo, lambda f: None)
        numero = self.avaliar()['retencoes_pendentes'][0]
        arquivo.close.side_effect = lambda: setattr(arquivo, 'closed', True)
        self.assertTrue(self.infra.tentar_limpeza_arquivo(numero))
        resultado = self.avaliar()
        self.assertEqual([], resultado['retencoes_pendentes'])
        self.assertTrue(resultado['arquivos'][0]['limpeza_comprovada'])
        self.assertIn(numero, resultado['recursos_pendentes'])
        self.assertFalse(resultado['responsabilidades_conhecidas_resolvidas'])

    def test_14_registros_vazios_nao_provam_cobertura(self):
        self.infra = InfraestruturaRegistrosCliente()
        resultado = self.avaliar()
        self.assertTrue(resultado['leituras_revalidadas'])
        self.assertEqual([], resultado['retentativas'])

    def test_15_consulta_incoerente(self):
        self.terminal()
        registro = self.infra.registro_recursos
        primeiro = registro.obter_retrato()
        segundo = deepcopy(primeiro)
        segundo['admissao_fechada'] = False
        with patch.object(registro, 'obter_retrato', side_effect=[primeiro, primeiro, segundo, segundo]):
            resultado = self.avaliar()
        self.assertFalse(resultado['leituras_revalidadas'])
        self.assertEqual([], resultado['retentativas'])

    def test_16_global_sempre_fora_do_escopo(self):
        self.terminal()
        self.assertTrue(self.avaliar()['responsabilidades_conhecidas_resolvidas'])
        self.assertIn('aplicacao_fora_do_escopo', self.avaliar()['pendencias'])

    def test_17_tcp_proprio_pendente(self):
        self.recurso_pendente('socket_tcp')
        self.assertFalse(self.individual()['recursos_resolvidos'])

    def test_18_E_http_e_recurso_mudam_entre_leituras(self):
        cliente, arquivo, _ = self.par_leitor()
        self.addCleanup(cliente.close)
        self.addCleanup(arquivo.close)
        op = self.operacao_http()
        obter = self.infra.registro_http.obter_retrato
        chamadas = []
        def durante():
            retrato = obter()
            if not chamadas:
                self.infra.registro_http.executar(op, lambda: None)
                arquivo.close()
                cliente.close()
            chamadas.append(True)
            return retrato
        with patch.object(self.infra.registro_http, 'obter_retrato', side_effect=durante):
            resultado = self.avaliar()
        self.assertFalse(resultado['leituras_revalidadas'])
        self.assertIn('consulta_incoerente', resultado['pendencias'])
        self.assertTrue(self.avaliar()['leituras_revalidadas'])

    def test_19_F_consulta_nao_observa_termino(self):
        self.executar_descoberta()
        self.fechar_gates()
        antes = deepcopy(self.guarda.obter_retrato())
        with patch.object(InfraestruturaRegistrosCliente, 'observar_termino_retentativas',
                          side_effect=AssertionError('observacao_implicita')) as observar:
            resultado = self.avaliar()
        observar.assert_not_called()
        self.assertEqual(antes, self.guarda.obter_retrato())
        self.assertFalse(resultado['retentativas'][0]['encerramento_confirmado'])
        self.threads[0].is_alive.assert_not_called()

    def test_20_cobertura_atividades_incompleta_mesmo_com_todos_positivos(self):
        op = self.operacao_http()
        self.infra.registro_http.executar(op, lambda: None)
        self.terminal()
        self.infra.registro_http.fechar_admissao()
        resultado = self.avaliar()
        self.assertTrue(resultado['responsabilidades_conhecidas_resolvidas'])
        self.assertIn('cobertura_atividades_cliente_incompleta', resultado['pendencias'])

    def test_21_gates_abertos_impedem_individual(self):
        self.executar_descoberta()
        self.observar()
        self.assertFalse(self.individual()['encerramento_confirmado'])

    def test_22_associacao_duplicada_recusada(self):
        self.terminal()
        itens = self.infra.obter_associacoes_retentativas()
        itens.append(deepcopy(itens[0]))
        with patch.object(InfraestruturaRegistrosCliente, 'obter_associacoes_retentativas', return_value=itens):
            self.assertFalse(self.avaliar()['leituras_revalidadas'])

    def test_23_associacao_estrangeira_recusada(self):
        self.terminal()
        itens = self.infra.obter_associacoes_retentativas()
        itens[0]['aplicacao_id'] = 'outra_aplicacao_simulada'
        with patch.object(InfraestruturaRegistrosCliente, 'obter_associacoes_retentativas', return_value=itens):
            self.assertEqual([], self.avaliar()['retentativas'])

    def test_24_erro_consulta_sanitizado(self):
        with patch.object(self.infra.registro_http, 'obter_retrato', side_effect=OSError('dado_privado_simulado')):
            resultado = self.avaliar()
        self.assertIn('falha_consulta_ou_contrato', resultado['pendencias'])
        self.assertNotIn('dado_privado_simulado', str(resultado))

    def test_25_http_reservado_antes_do_leitor(self):
        self.infra = InfraestruturaRegistrosCliente()
        self.operacao_http()
        item, = self.avaliar()['http']
        self.assertEqual('reservada', item['estado'])
        self.assertFalse(item['execucao_resolvida'])

    def test_26_consulta_nao_limpa_nem_fecha_admissoes(self):
        cliente, arquivo, bruto = self.par_leitor()
        self.addCleanup(cliente.close)
        self.addCleanup(arquivo.close)
        antes = self.infra.registro_recursos.obter_retrato()
        with patch.object(self.infra.registro_recursos, 'fechar', side_effect=AssertionError('cleanup_implicito')) as fechar:
            self.avaliar()
        fechar.assert_not_called()
        self.assertEqual(antes, self.infra.registro_recursos.obter_retrato())

    def test_27_http_timeout_resolvido(self):
        op = self.operacao_http()
        with self.assertRaises(TimeoutError):
            self.infra.registro_http.executar(op, Mock(side_effect=TimeoutError('simulado')))
        item, = self.avaliar()['http']
        self.assertTrue(item['execucao_resolvida'])
        self.assertEqual('timeout', item['erro']['categoria'])

    def test_28_arquivo_fechado_normal(self):
        contexto = ContextoArquivosConfiguracao(self.infra)
        arquivo = Mock(closed=False)
        arquivo.close.side_effect = lambda: setattr(arquivo, 'closed', True)
        contexto.executar(lambda: arquivo, lambda f: None)
        resultado = self.avaliar()
        self.assertEqual([], resultado['retencoes_pendentes'])
        self.assertEqual([], resultado['recursos_pendentes'])
        self.assertTrue(resultado['arquivos'][0]['limpeza_comprovada'])

    def test_29_http_geracao_antiga_preservada(self):
        self.operacao_http()
        op = self.operacao_http()
        self.infra.registro_http.executar(op, lambda: None)
        a, b = self.avaliar()['http']
        self.assertNotEqual(a['geracao_id'], b['geracao_id'])
        self.assertFalse(a['execucao_resolvida'])
        self.assertTrue(b['execucao_resolvida'])

    def test_30_falha_em_retencoes_descarta_candidato_positivo(self):
        contexto = ContextoArquivosConfiguracao(self.infra)
        self.terminal()
        with patch.object(ContextoArquivosConfiguracao, 'obter_historico', side_effect=RuntimeError('simulado')):
            resultado = self.avaliar()
        self.assertEqual([], resultado['retentativas'])
        self.assertFalse(resultado['leituras_revalidadas'])

    def test_31_consulta_concorrente_com_http_e_cleanup(self):
        cliente, arquivo, _ = self.par_leitor()
        self.addCleanup(cliente.close)
        self.addCleanup(arquivo.close)
        op = self.operacao_http()
        capturado, liberar = threading.Event(), threading.Event()
        self.addCleanup(liberar.set)
        original = self.infra.registro_http.obter_retrato
        leituras = []
        def consultar():
            retrato = original()
            if not leituras:
                leituras.append(True)
                capturado.set()
                if not liberar.wait(3):
                    raise TimeoutError('barreira_simulada')
            return retrato
        with patch.object(self.infra.registro_http, 'obter_retrato', side_effect=consultar):
            trabalho = self.tarefa(self.infra.avaliar_responsabilidades_cliente)
            try:
                self.assertTrue(capturado.wait(3))
                self.infra.registro_http.executar(op, lambda: None)
                arquivo.close()
                cliente.close()
            finally:
                liberar.set()
                self.terminar(trabalho)
        self.assertEqual([], trabalho[2])
        resultado, = trabalho[1]
        self.assertFalse(resultado['leituras_revalidadas'])
        self.assertFalse(resultado['encerramento_cliente_confirmado'])

    def test_32_ast_sem_acoes_ou_threads(self):
        from rede import composicao_operacional_cliente as modulo
        arvore = ast.parse(Path(modulo.__file__).read_text(encoding='utf-8'))
        chamadas = {no.func.attr for no in ast.walk(arvore)
                    if isinstance(no, ast.Call) and isinstance(no.func, ast.Attribute)}
        self.assertFalse(chamadas & {'observar_termino_retentativas', 'observar_termino_thread',
                                    'is_alive', 'join', 'close', 'shutdown', 'fechar',
                                    'fechar_admissao', 'tentar_limpeza_arquivo', 'start'})

    def test_33_recurso_independente_tem_identidade_de_atividade(self):
        cliente, arquivo, _ = self.par_leitor()
        self.addCleanup(cliente.close)
        self.addCleanup(arquivo.close)
        self.terminal()
        recursos = self.avaliar()['recursos']
        item = next(r for r in recursos if r['recurso_id'] == cliente.recurso_id.numero)
        self.assertEqual(self.leitor.recursos_cliente.atividade_id, item['atividade_id'])
        self.assertFalse(item['associacao_retentativa_comprovada'])
        self.assertTrue(self.individual()['encerramento_confirmado'])

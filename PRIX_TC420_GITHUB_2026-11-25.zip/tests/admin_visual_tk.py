"""Protótipo administrativo do ensaio. Não protege a aplicação operacional."""
from dataclasses import dataclass
import hashlib
import hmac
import secrets
import tkinter as tk
from tkinter import messagebox

from interface.formularios import PRETO, CARD, TEXTO, SUAVE, VERDE, centralizar
from interface.ciclo_tk import ciclo


@dataclass(frozen=True)
class CredencialTemporaria:
    sal: bytes
    resumo: bytes

    @classmethod
    def criar(cls, senha):
        sal = secrets.token_bytes(16)
        return cls(sal, hashlib.pbkdf2_hmac('sha256', senha.encode(), sal, 200_000))

    def verificar(self, senha):
        resumo = hashlib.pbkdf2_hmac('sha256', senha.encode(), self.sal, 200_000)
        return hmac.compare_digest(resumo, self.resumo)


class AdministradorEnsaio:
    """Cada acesso exige cadastro/login; senha só nesta sessão e nunca no log."""
    def __init__(self, dono):
        self.dono = dono
        self.credencial = None
        self.tela = None
        self.autorizado = False

    def iniciar_aplicacao(self, metodo='HTTPS', automatico=True):
        """Simula nova abertura, preservando apenas o cadastro em memória."""
        self.autorizado = False
        if self.credencial is None:
            return self.pedir('Primeira configuração', self.dono.mostrar_conexao)
        if metodo == 'HTTPS' and automatico:
            self.dono.registrar('INÍCIO: HTTP automático simulado, sem login administrativo.')
            return self.dono.abrir_monitor()
        return self.pedir('Início TCP / configuração manual', self.dono.mostrar_conexao)

    def pedir(self, origem, continuar):
        if self.tela is not None and self.tela.root.winfo_exists():
            return False
        self.tela = TelaAdministrador(self, origem, continuar)
        return True


class TelaAdministrador:
    def __init__(self, controle, origem, continuar):
        self.controle, self.continuar = controle, continuar
        self.saida_aplicacao = controle.dono.saida
        self.root = tk.Toplevel(controle.dono.conexao.root)
        self.root.title('PRIX TC420 — Administrador (ensaio)')
        self.root.configure(bg=PRETO)
        centralizar(self.root, 540, 475)
        self.root.resizable(False, False)
        self.root.protocol('WM_DELETE_WINDOW', self.cancelar)
        self.root.bind('<Escape>', lambda _evento: self.cancelar())
        self.root.grab_set()
        self.area = tk.Frame(self.root, bg=PRETO)
        self.area.pack(fill='both', expand=True, padx=24, pady=20)
        self.cadastro = controle.credencial is None
        self.label('Cadastro de administrador' if self.cadastro else 'Login de administrador',
                   18, TEXTO).pack(anchor='w')
        self.label(origem, 14, VERDE).pack(anchor='w', pady=(4, 12))
        self.label('Protótipo offline. Use uma senha de teste, sem relação com a TC420.\n'
                   'O cadastro existe apenas nesta execução.', 12, SUAVE).pack(anchor='w', pady=(0, 12))
        self.cadastro = controle.credencial is None
        self.label('Cadastre uma senha (mínimo 8 caracteres)' if self.cadastro else
                   'Senha de administrador', 14, TEXTO).pack(anchor='w')
        self.senha = self.entrada()
        self.repeticao = None
        if self.cadastro:
            self.label('Confirme a senha', 14, TEXTO).pack(anchor='w', pady=(12, 0))
            self.repeticao = self.entrada()
        self.status = self.label('', 12, SUAVE)
        self.status.pack(anchor='w', pady=12)
        self.botao = tk.Button(self.area, text='CADASTRAR' if self.cadastro else 'ENTRAR',
                               command=self.confirmar, font=('Segoe UI', 18, 'bold'),
                               bg=VERDE, fg=PRETO, relief='flat', pady=8)
        self.botao.pack(fill='x')
        self.esqueci = None
        if not self.cadastro:
            self.esqueci = tk.Button(self.area, text='Esqueci a senha', command=self.restaurar,
                                     bg=PRETO, fg=VERDE, relief='flat', font=('Segoe UI', 14))
            self.esqueci.pack(pady=(10, 0))
        self.senha.bind('<Return>', lambda _e: self.confirmar())
        if self.repeticao is not None:
            self.repeticao.bind('<Return>', lambda _e: self.confirmar())
        self.senha.focus_set()

    def label(self, texto, tamanho, cor):
        return tk.Label(self.area, text=texto, font=('Segoe UI', tamanho), bg=PRETO,
                        fg=cor, justify='left', wraplength=490)

    def entrada(self):
        campo = tk.Entry(self.area, show='•', font=('Segoe UI', 14), bg=CARD, fg=TEXTO,
                         insertbackground=VERDE, relief='flat')
        campo.pack(fill='x', ipady=5, pady=(4, 0))
        return campo

    def confirmar(self):
        if 'autenticar' in ciclo(self).operacoes:
            return
        senha = self.senha.get()
        if self.cadastro and (len(senha) < 8 or senha != self.repeticao.get()):
            self.status.config(text='Use pelo menos 8 caracteres e repita a mesma senha.', fg='#ff938b')
            return
        self.senha.delete(0, 'end')
        if self.repeticao is not None:
            self.repeticao.delete(0, 'end')
        self.botao.config(state='disabled')
        self.status.config(text='Verificando...', fg=SUAVE)
        credencial = self.controle.credencial
        ciclo(self).iniciar('autenticar', lambda: CredencialTemporaria.criar(senha)
                           if self.cadastro else credencial.verificar(senha), self.aplicar)

    def restaurar(self):
        if 'autenticar' in ciclo(self).operacoes:
            return
        if not messagebox.askyesno('Restaurar senha de administrador',
                'Deseja restaurar a senha? Todos os dados salvos da conexão e a senha '
                'de administrador serão apagados. No ensaio, somente dados simulados '
                'serão limpos. Esta ação não pode ser desfeita.', parent=self.root):
            return
        dono = self.controle.dono
        self.controle.credencial = None
        self.controle.autorizado = False
        self.fechar()
        dono.limpar_configuracao_simulada()
        dono.conexao.root.withdraw()
        dono.transicionar_configuracao(lambda: self.controle.pedir(
            'Novo cadastro após restauração', dono.mostrar_conexao))

    def aplicar(self, resultado, erro):
        if erro or not resultado:
            self.botao.config(state='normal')
            self.status.config(text='Acesso não autorizado. Confira a senha.', fg='#ff938b')
            return
        if self.cadastro:
            self.controle.credencial = resultado
            self.controle.autorizado = False
            continuar = self.continuar
            self.fechar()
            self.controle.dono.registrar('ADMIN: cadastro concluído; aguardando login administrativo.')
            self.controle.pedir('Entre com a senha recém-cadastrada', continuar)
            return
        self.controle.autorizado = True
        self.controle.dono.registrar('ADMIN: acesso autorizado no protótipo; nenhuma credencial persistida.')
        continuar = self.continuar
        self.fechar()
        continuar()

    def fechar(self):
        ciclo(self).fechar()
        self.root.grab_release()
        self.controle.tela = None
        self.root.destroy()

    def cancelar(self):
        dono = self.controle.dono
        self.fechar()
        # Cancelar o cadastro inicial não deve deixar a conexão oculta e inacessível.
        if not dono.configuracao_autorizada:
            dono.encerrar_harness()

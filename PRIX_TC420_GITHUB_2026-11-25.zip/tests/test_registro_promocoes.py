# Testes de registro promocoes: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""Promoções com fontes reais por AST, sem Tk, HTTP ou sockets."""
import ast
import threading
import unittest
from types import MethodType, SimpleNamespace
from unittest.mock import ANY, Mock, patch

from rede import servidor
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente, RecursosLeitorCliente
from test_registro_automatico import RAIZ, ThreadFila, carregar_fluxos


# Grupo de 24 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class IntegracaoPromocoes(unittest.TestCase):
    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        ThreadFila.criadas = []
        self.env = carregar_fluxos()
        arvore = ast.parse((RAIZ / "main.py").read_text(encoding="utf-8"))
        funcoes = [n for n in arvore.body if isinstance(n, ast.FunctionDef)
                   and n.name in ("iniciar_como_cliente", "obter_credenciais_salvas")]
        exec(compile(ast.Module(body=funcoes, type_ignores=[]), "main.py", "exec"), self.env)
        self.registro = servidor.RegistroTentativasAplicacao()
        self.infra = InfraestruturaRegistrosCliente()
        self.leitor = Mock()
        self.leitor.recursos_cliente = RecursosLeitorCliente(self.infra)
        self.leitor.aguardar_configuracao.return_value = None
        self.env["LeitorDadosServidor"] = Mock(return_value=self.leitor)
        self.env["obter_dados_atuais"] = Mock()
        self.monitor = SimpleNamespace(
            executar=Mock(), root=SimpleNamespace(after=Mock(), bind=Mock(), winfo_exists=lambda: True),
            executando=True, contextos_promocao=[], contexto_promocao_atual=None,
            ciclo_servidor_id=None, web=None, configuracao=None, fonte_dados=object(),
            candidatura_liberada=lambda: True, candidatura_detectada=False,
            estado_candidatura=lambda: "liberada", promocao_em_andamento=False,
            abrir_janela_promocao=Mock(), fechar_janela_promocao=Mock())
        janela_ast = ast.parse((RAIZ / "interface/janela.py").read_text(encoding="utf-8"))
        nomes = ("associar_contexto_promocao", "observar_contexto_promocao",
                 "concluir_promocao", "verificar_candidatura")
        metodos = [n for n in ast.walk(janela_ast)
                   if isinstance(n, ast.FunctionDef) and n.name in nomes]
        ui_env = dict(print=lambda *args: None)
        exec(compile(ast.Module(body=metodos, type_ignores=[]), "interface/janela.py", "exec"), ui_env)
        for nome in nomes:
            setattr(self.monitor, nome, MethodType(ui_env[nome], self.monitor))
        self.monitor._agendar = self.monitor.root.after
        def iniciar_promocao(trabalho, janela=None):
            resultado = trabalho()
            if resultado:
                self.monitor.concluir_promocao(resultado)
                if janela is not None:
                    self.monitor.fechar_janela_promocao(janela)
        self.monitor._iniciar_promocao = iniciar_promocao
        self.confirmar_ast = next(n for n in ast.walk(janela_ast)
                                  if isinstance(n, ast.FunctionDef) and n.name == "confirmar")
        def criar_monitor(**kwargs):
            self.monitor.ao_promover = kwargs["ao_promover"]
            self.monitor.ao_promover_automaticamente = kwargs["ao_promover_automaticamente"]
            self.monitor.ao_fechar = kwargs["ao_fechar"]
            return self.monitor
        self.env["JanelaTC420"] = criar_monitor
        self.abrir_cliente()

    def abrir_cliente(self, sem_registro=False):
        kwargs = dict(infraestrutura_cliente=self.infra)
        if not sem_registro:
            kwargs["registro_tentativas"] = self.registro
        self.env["iniciar_como_cliente"]("principal-simulado", **kwargs)
        self.leitor.reset_mock()

    def promover(self, automatica=False):
        if automatica:
            resultado = self.monitor.ao_promover_automaticamente()
        else:
            resultado = self.monitor.ao_promover("simulado", "simulado", "valor-simulado")
        if resultado and threading.current_thread() is threading.main_thread():
            self.monitor.concluir_promocao(resultado)
        return resultado

    def manual_ui(self):
        ambiente = dict(self=self.monitor, print=lambda *args: None, janela=object())
        ambiente['salvar_login_var'] = SimpleNamespace(get=lambda: False)
        for campo in ("entry_ip", "entry_usuario", "entry_senha"):
            ambiente[campo] = SimpleNamespace(get=lambda: "valor-simulado")
        exec(compile(ast.Module(body=[self.confirmar_ast], type_ignores=[]),
                     "interface/janela.py", "exec"), ambiente)
        ambiente["confirmar"]()

    def tentativas(self):
        return self.registro.obter_retrato()["tentativas"]

    def test_01_manual_normal(self):
        self.manual_ui()
        tentativa, = self.tentativas()
        self.assertEqual(tentativa.estado_partida, "iniciada")
        ThreadFila.criadas[0].target()
        self.assertTrue(self.tentativas()[0].execucao_observada)
        self.assertIs(self.monitor.web, self.env["WebTC420"].return_value)
        self.monitor.fechar_janela_promocao.assert_called_once()

    def test_02_automatica_normal(self):
        self.monitor.verificar_candidatura()
        tentativa, = self.tentativas()
        self.assertEqual(tentativa.estado_partida, "iniciada")
        ThreadFila.criadas[0].target()
        self.assertIs(self.monitor.web, self.env["WebTC420"].return_value)
        self.assertIsNone(self.monitor.candidatura_liberada)

    def test_03_caminho_compartilhado(self):
        self.promover()
        self.promover(True)
        self.assertEqual([t.estado_partida for t in self.tentativas()], ["iniciada"] * 2)
        self.assertEqual(self.env["buscar_servidor"].call_count, 4)
        self.assertEqual(self.monitor.contextos_promocao,
                         [t.contexto for t in self.tentativas()])

    def test_04_promocoes_sucessivas(self):
        for automatico in (True, False, True):
            anterior = self.tentativas()
            self.promover(automatico)
            self.assertEqual(self.tentativas()[:-1], anterior)
        self.assertEqual(len({id(t.contexto) for t in self.tentativas()}), 3)

    def inicio_manual(self):
        arvore = ast.parse((RAIZ / "interface/conexao.py").read_text(encoding="utf-8"))
        bloco = next(n for n in ast.walk(arvore) if isinstance(n, ast.If)
                     and ast.unparse(n.test) == "not self.servidor_iniciado")
        janela = SimpleNamespace(
            servidor_iniciado=False, registro_tentativas=self.registro, web=object(),
            servidor_inicializado=threading.Event(), servidor_encerrado=threading.Event(),
            observar_contexto_ciclo=Mock(), supervisionar_inicializacao=Mock(), observar_servidor=Mock())
        ambiente = dict(self.env, self=janela)
        exec(compile(ast.Module(body=[bloco], type_ignores=[]), "interface/conexao.py", "exec"), ambiente)
        return janela

    def test_05_apos_manual_sequencia_a_b_c_d(self):
        janela = self.inicio_manual()
        for automatica in (True, False, True):
            self.promover(automatica)
        tentativas = self.tentativas()
        self.assertEqual(len({t.tentativa_id for t in tentativas}), 4)
        self.assertEqual(len({id(t.contexto) for t in tentativas}), 4)
        self.assertIs(tentativas[0].contexto, janela.contexto_ciclo_servidor)

    def test_06_apos_automatico(self):
        resultado = self.env["tentar_login_automatico"](self.registro, infraestrutura_cliente=self.infra)
        self.promover(True)
        self.assertEqual(len(self.tentativas()), 2)
        self.assertIs(self.tentativas()[0].contexto, resultado["contexto_ciclo"])

    def test_07_admissao_recusada(self):
        self.registro.fechar_admissao()
        self.assertIsNone(self.promover())
        self.assertIsNone(self.promover(True))
        self.assertFalse(ThreadFila.criadas)
        self.env["buscar_servidor"].assert_not_called()
        self.env["WebTC420"].assert_not_called()
        self.leitor.registrar_falha_recuperacao.assert_not_called()
        self.assertFalse(self.monitor.contextos_promocao)

    def test_08_fecha_durante_partida(self):
        caso = self
        class Fecha(ThreadFila):
            def start(self):
                caso.registro.fechar_admissao()
                self.target()
        self.env["threading"].Thread = Fecha
        self.assertTrue(self.promover())
        self.assertTrue(self.tentativas()[0].execucao_observada)
        self.assertEqual(self.tentativas()[0].estado_partida, "iniciada")

    def test_09_entrada_antes_start_retornar(self):
        caso = self
        associar = self.monitor.associar_contexto_promocao
        def associar_sem_lock(contexto):
            self.assertTrue(self.registro._lock.acquire(blocking=False))
            self.registro._lock.release()
            associar(contexto)
        self.monitor.associar_contexto_promocao = associar_sem_lock
        class Imediata(ThreadFila):
            def start(self):
                caso.assertTrue(caso.registro._lock.acquire(blocking=False))
                caso.registro._lock.release()
                self.target()
                caso.assertEqual(caso.tentativas()[0].estado_partida, "iniciando")
                caso.assertTrue(caso.tentativas()[0].execucao_observada)
        self.env["threading"].Thread = Imediata
        self.assertTrue(self.promover())

    def test_10_falha_criacao(self):
        self.env["threading"].Thread = Mock(side_effect=RuntimeError())
        self.assertIsNone(self.promover())
        tentativa, = self.tentativas()
        self.assertEqual(tentativa.estado_partida, "falha_partida")
        self.assertEqual(tentativa.erro_partida, "falha_criacao_thread")
        self.assertEqual(tentativa.contexto.erro, "falha_antes_reserva")
        self.env["iniciar_servidor"].assert_not_called()

    def test_11_start_ambiguo_tardio(self):
        class Ambigua(ThreadFila):
            def start(self):
                raise RuntimeError()
        self.env["threading"].Thread = Ambigua
        self.assertIsNone(self.promover())
        tentativa, = self.tentativas()
        self.assertEqual(tentativa.estado_partida, "iniciando")
        self.assertFalse(tentativa.contexto.resolvido.is_set())
        ThreadFila.criadas[0].target()
        self.assertTrue(self.tentativas()[0].execucao_observada)
        self.env["iniciar_servidor"].assert_called_once()

    def test_12_falha_apos_entrada(self):
        class ExecutaELanca(ThreadFila):
            def start(self):
                self.target()
                raise RuntimeError()
        self.env["threading"].Thread = ExecutaELanca
        self.assertIsNone(self.promover())
        self.assertTrue(self.tentativas()[0].execucao_observada)
        self.assertIsNone(self.tentativas()[0].erro_partida)

    def test_13_reserva_recusada_coordenador_real(self):
        self.env["iniciar_servidor"] = servidor.iniciar_servidor
        self.promover()
        with patch.object(servidor, "controle_ciclo_servidor") as controle:
            controle.tentar_iniciar.return_value = False
            with self.assertRaises(RuntimeError):
                ThreadFila.criadas[0].target()
        tentativa, = self.tentativas()
        self.assertEqual(tentativa.contexto.erro, "reserva_recusada")
        self.assertTrue(tentativa.contexto.coordenador_retornou.is_set())
        self.assertEqual(tentativa.estado_partida, "iniciada")
        self.assertTrue(tentativa.execucao_observada)

    def test_14_falha_apos_reserva_coordenador_real(self):
        self.env["iniciar_servidor"] = servidor.iniciar_servidor
        self.promover()
        with patch.object(servidor, "controle_ciclo_servidor", servidor.ControleCicloServidor()), \
             patch.object(servidor, "threading", SimpleNamespace(
                 Lock=threading.Lock, current_thread=threading.current_thread,
                 Thread=Mock(side_effect=RuntimeError()))), \
             patch.object(servidor, "evento_parada_servidor", threading.Event()):
            with self.assertRaises(RuntimeError):
                ThreadFila.criadas[0].target()
        tentativa, = self.tentativas()
        situacao = tentativa.contexto.obter_situacao()
        self.assertIs(type(situacao["ciclo_id"]), int)
        self.assertEqual(situacao["erro_coordenador"], "falha_execucao")
        self.assertTrue(situacao["coordenador_retornou"])
        self.assertIsNone(tentativa.erro_partida)

    def test_15_contexto_antigo_pendente(self):
        primeiro = self.promover(True)
        controle = servidor.ControleCicloServidor()
        trabalhadores = servidor.RegistroTrabalhadores()
        liberar = threading.Event()
        worker = threading.Thread(target=lambda: liberar.wait(3))
        try:
            self.assertTrue(controle.tentar_iniciar(trabalhadores))
            self.assertTrue(trabalhadores.registrar_e_iniciar(worker))
            primeiro["contexto_ciclo"].registrar_reserva(trabalhadores.ciclo_id)
            trabalhadores.bloquear_criacao()
            controle.finalizar(trabalhadores)
            primeiro["contexto_ciclo"].registrar_retorno_coordenador()
            antigo = self.tentativas()[0]
            self.env["iniciar_servidor"] = servidor.iniciar_servidor
            self.promover()
            with patch.object(servidor, "controle_ciclo_servidor", controle):
                with self.assertRaises(RuntimeError):
                    ThreadFila.criadas[-1].target()
            self.assertTrue(worker.is_alive())
            self.assertEqual(controle.estado, "pendente")
            self.assertEqual(self.tentativas()[0], antigo)
            self.assertEqual(self.tentativas()[0].contexto.ciclo_id, trabalhadores.ciclo_id)
            self.assertEqual(self.tentativas()[1].contexto.erro, "reserva_recusada")
            self.assertIsNot(self.monitor.contexto_promocao_atual, antigo.contexto)
            self.assertIn(antigo.contexto, self.monitor.saida_aplicacao._contextos)
        finally:
            liberar.set()
            if worker.ident is not None:
                worker.join(3)
                self.assertFalse(worker.is_alive())

    def test_16_sem_registro(self):
        self.abrir_cliente(sem_registro=True)
        self.env["RegistroTentativasAplicacao"] = Mock(side_effect=AssertionError())
        self.assertTrue(self.promover())
        self.assertTrue(self.promover(True))
        for thread in ThreadFila.criadas:
            thread.target()
        self.assertFalse(self.tentativas())
        self.assertEqual(self.env["iniciar_servidor"].call_count, 2)

    def threads(self, funcoes):
        erros = []
        def executar(funcao):
            try:
                funcao()
            except BaseException as erro:
                erros.append(erro)
        threads = [threading.Thread(target=executar, args=(f,)) for f in funcoes]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(3)
            self.assertFalse(thread.is_alive())
        if erros:
            raise erros[0]

    def test_17_promocoes_concorrentes(self):
        barreira = threading.Barrier(2, timeout=3)
        def promover(automatica):
            barreira.wait()
            self.assertTrue(self.promover(automatica))
        self.threads([lambda: promover(False), lambda: promover(True)])
        self.assertEqual(len({t.tentativa_id for t in self.tentativas()}), 2)
        self.assertEqual(len({id(t.contexto) for t in self.tentativas()}), 2)

    def test_18_consulta_durante_promocao(self):
        pronta = threading.Barrier(2, timeout=3)
        liberar = threading.Barrier(2, timeout=3)
        caso = self
        class Pausa(ThreadFila):
            def start(self):
                self.target()
                pronta.wait()
                liberar.wait()
        self.env["threading"].Thread = Pausa
        def consultar():
            pronta.wait()
            try:
                caso.antigo = caso.registro.obter_retrato()
                tentativa, = caso.antigo["tentativas"]
                caso.assertEqual(tentativa.estado_partida, "iniciando")
                caso.assertTrue(tentativa.execucao_observada)
            finally:
                liberar.wait()
        self.threads([self.promover, consultar])
        self.assertEqual(self.tentativas()[0].estado_partida, "iniciada")
        self.assertEqual(self.antigo["tentativas"][0].estado_partida, "iniciando")

    def test_19_recusa_sem_sucesso_ui(self):
        contexto_anterior = object()
        self.monitor.contexto_promocao_atual = contexto_anterior
        self.monitor.ciclo_servidor_id = 19
        self.monitor.web = object()
        anterior = (self.monitor.web, self.monitor.fonte_dados)
        self.registro.fechar_admissao()
        self.manual_ui()
        self.monitor.verificar_candidatura()
        self.assertEqual((self.monitor.web, self.monitor.fonte_dados), anterior)
        self.assertIs(self.monitor.contexto_promocao_atual, contexto_anterior)
        self.assertEqual(self.monitor.ciclo_servidor_id, 19)
        self.assertFalse(self.monitor.promocao_em_andamento)
        self.assertIsNotNone(self.monitor.candidatura_liberada)
        self.monitor.fechar_janela_promocao.assert_not_called()
        self.leitor.parar.assert_not_called()
        self.leitor.registrar_falha_recuperacao.assert_not_called()
        self.assertFalse(ThreadFila.criadas)

    def test_20_eleicao_e_preflight(self):
        self.env["buscar_servidor"].return_value = "outro-principal"
        self.assertIsNone(self.promover())
        self.assertFalse(ThreadFila.criadas)
        self.env["WebTC420"].assert_not_called()
        self.assertEqual(self.tentativas()[0].contexto.erro, "falha_antes_reserva")
        self.assertEqual(self.tentativas()[0].estado_partida, "falha_partida")
        self.env["buscar_servidor"].return_value = None
        self.env["WebTC420"].return_value.login.side_effect = RuntimeError()
        self.assertIsNone(self.promover())
        self.assertEqual(self.tentativas()[1].erro_partida, "falha_partida")
        self.assertFalse(ThreadFila.criadas)
        self.env["carregar_configuracao"] = lambda **kwargs: None
        self.assertFalse(self.promover(True))
        self.assertEqual(len(self.tentativas()), 2)

    def test_21_critico_duas_ordens_duas_modalidades(self):
        for automatica in (False, True):
            for aceita in (False, True):
                with self.subTest(automatica=automatica, aceita=aceita):
                    pronta = threading.Barrier(2, timeout=3)
                    liberar = threading.Barrier(2, timeout=3)
                    class RegistroPausado(servidor.RegistroTentativasAplicacao):
                        def admitir(registro, contexto):
                            if aceita:
                                tentativa_id = super().admitir(contexto)
                            pronta.wait()
                            liberar.wait()
                            return tentativa_id if aceita else super().admitir(contexto)
                    self.registro = RegistroPausado()
                    self.abrir_cliente()
                    ThreadFila.criadas = []
                    resultados = []
                    def promover():
                        resultados.append(self.promover(automatica))
                    def fechar():
                        pronta.wait()
                        self.registro.fechar_admissao()
                        self.retrato_fechado = self.registro.obter_retrato()
                        liberar.wait()
                    self.threads([promover, fechar])
                    self.assertEqual(bool(resultados[0]), aceita)
                    self.assertEqual(len(ThreadFila.criadas), int(aceita))
                    self.assertEqual(len(self.retrato_fechado["tentativas"]), int(aceita))
                    for thread in ThreadFila.criadas:
                        thread.target()
                    atuais = self.tentativas()
                    self.assertEqual([t.contexto for t in atuais],
                                     [t.contexto for t in self.retrato_fechado["tentativas"]])
                    if aceita:
                        self.assertTrue(atuais[0].execucao_observada)
                        self.assertEqual(atuais[0].estado_partida, "iniciada")

    def test_22_injecao_todos_caminhos_cliente(self):
        for caminho in ("descoberta", "automatico", "manual"):
            with self.subTest(caminho=caminho):
                env = carregar_fluxos()
                registro = servidor.RegistroTentativasAplicacao()
                env["RegistroTentativasAplicacao"] = Mock(return_value=registro)
                cliente = Mock()
                env["iniciar_como_cliente"] = cliente
                env["buscar_servidor"].return_value = "principal" if caminho == "descoberta" else None
                env["tentar_login_automatico"] = Mock(return_value=(
                    dict(modo="cliente", servidor="principal") if caminho == "automatico" else False))
                def criar_conexao(**kwargs):
                    self.assertIs(kwargs["registro_tentativas"], registro)
                    return SimpleNamespace(executar=lambda: kwargs["ao_encontrar_servidor"]("principal"))
                env["JanelaConexao"] = criar_conexao
                env["iniciar"]()
                cliente.assert_called_once_with(
                    "principal", registro_tentativas=registro, infraestrutura_cliente=ANY, vinculo_http=ANY,
                    contexto_arquivos=ANY, saida_aplicacao=ANY)
                vinculo = cliente.call_args.kwargs["vinculo_http"]
                self.assertIs(cliente.call_args.kwargs["infraestrutura_cliente"],
                              vinculo.validar(cliente.call_args.kwargs["infraestrutura_cliente"]))
                env["RegistroTentativasAplicacao"].assert_called_once_with()

    def test_23_target_real_antes_retorno_start(self):
        for lanca in (False, True):
            with self.subTest(lanca=lanca):
                self.registro = servidor.RegistroTentativasAplicacao()
                self.abrir_cliente()
                entrou = threading.Event()
                liberar = threading.Event()
                caso = self
                self.env["iniciar_servidor"] = lambda *args, **kwargs: (
                    entrou.set(), liberar.wait(3))
                criadas = []
                class Retida(threading.Thread):
                    def start(thread):
                        super().start()
                        caso.assertTrue(entrou.wait(3))
                        caso.registro.fechar_admissao()
                        tentativa, = caso.tentativas()
                        caso.assertEqual(tentativa.estado_partida, "iniciando")
                        caso.assertTrue(tentativa.execucao_observada)
                        if lanca:
                            raise RuntimeError()
                def fabrica(**kwargs):
                    thread = Retida(**kwargs)
                    criadas.append(thread)
                    return thread
                self.env["threading"].Thread = fabrica
                try:
                    resultado = self.promover()
                    self.assertEqual(bool(resultado), not lanca)
                    tentativa, = self.tentativas()
                    self.assertIsNone(tentativa.erro_partida)
                    self.assertTrue(tentativa.execucao_observada)
                    self.assertEqual(tentativa.estado_partida, "iniciando" if lanca else "iniciada")
                finally:
                    liberar.set()
                    for thread in criadas:
                        thread.join(3)
                        self.assertFalse(thread.is_alive())

    def test_24_guarda_e_callbacks(self):
        self.promover()
        with patch.object(self.registro, "registrar_entrada_execucao", return_value=False):
            ThreadFila.criadas[0].target()
        self.env["iniciar_servidor"].assert_not_called()
        self.env["iniciar_servidor"].side_effect = RuntimeError()
        with self.assertRaises(RuntimeError):
            ThreadFila.criadas[0].target()
        self.assertTrue(self.tentativas()[0].execucao_observada)
        self.assertIsNone(self.tentativas()[0].erro_partida)
        self.env["threading"].Thread = Mock(side_effect=RuntimeError())
        with patch.object(self.registro, "registrar_falha_partida", side_effect=RuntimeError()):
            self.assertIsNone(self.promover())
        self.assertEqual(self.tentativas()[1].estado_partida, "iniciando")


if __name__ == "__main__":
    unittest.main()

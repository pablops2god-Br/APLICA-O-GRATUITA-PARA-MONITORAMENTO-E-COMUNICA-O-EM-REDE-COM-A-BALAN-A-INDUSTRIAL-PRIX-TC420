# Testes de viabilidade ancora http: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""L3-B1.13-A: caracterização isolada preservada e rejeição no modo vinculado.

Transporte, GUI, persistência e threads operacionais são falsos.
"""
from dataclasses import replace
import unittest
from unittest.mock import Mock

from rede import infraestrutura_cliente as modulo, servidor
from rede.entradas_http import VinculoEntradasHttp
from tc420.web import WebTC420
from test_registro_automatico import carregar_fluxos
import test_auditoria_cobertura_http as auditoria
import test_approval_http_integrado as approval


# Grupo de 6 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class ViabilidadeAncoraHttp(unittest.TestCase):
    fluxo_http = approval.ApprovalHttpIntegrado.fluxo_http
    fixture_main = auditoria.AuditoriaCoberturaHttp.fixture_main
    fixture_manual = auditoria.AuditoriaCoberturaHttp.fixture_manual

    # Prepara o isolamento e as dependências usados pelos casos deste grupo.
    def setUp(self):
        self.a = modulo.InfraestruturaRegistrosCliente()
        self.b = modulo.InfraestruturaRegistrosCliente()
        # Objeto preexistente da composição, ainda sem vínculo de propriedade
        # com os registros CLIENTE. Associá-lo a A é a intenção do chamador.
        self.tentativas_a = servidor.RegistroTentativasAplicacao()
        self.vinculo_a = VinculoEntradasHttp(self.a)

    def somente_b(self, adaptador):
        self.assertEqual(["POST", "GET"], [r.method for r, _ in adaptador.enviados])
        self.assertEqual([], self.a.registro_http.obter_retrato()["operacoes"])
        ops = self.b.registro_http.obter_retrato()["operacoes"]
        self.assertEqual(["login", "approval"], [op["operacao"] for op in ops])
        self.assertTrue(all(op["execucao_resolvida"] for op in ops))

    def test_01_comprovacao_circular_aceita_segunda_instalacao_completa(self):
        self.assertIsNot(self.a, self.b)
        self.assertNotEqual(self.a.aplicacao_id, self.b.aplicacao_id)
        self.assertIs(self.a, modulo.exigir_infraestrutura_http(self.a))
        self.assertIs(self.b, modulo.exigir_infraestrutura_http(self.b))
        self.assertIs(self.b, self.b.registro_http.proprietario)
        self.assertEqual(self.b.aplicacao_id, self.b.registro_http.aplicacao_id)
        with self.assertRaises(modulo.InfraestruturaHttpInvalida):
            self.vinculo_a.validar(self.b)
        # A identidade existente é adequada para nomear cada aplicação; o que
        # falta é uma referência externa esperada, não mais um UUID.

    def test_02_automatico_registro_tentativas_nao_e_ancora(self):
        env = carregar_fluxos()
        env["WebTC420"].side_effect = WebTC420
        env["print"] = Mock()
        with self.fluxo_http() as adaptador:
            resultado = env["tentar_login_automatico"](
                registro_tentativas=self.tentativas_a, infraestrutura_cliente=self.b)
        self.assertEqual("principal", resultado["modo"])
        self.assertIs(self.b, resultado["web"].politica_http.proprietario)
        self.assertEqual(1, len(self.tentativas_a.obter_retrato()["tentativas"]))
        self.somente_b(adaptador)
        env["WebTC420"].reset_mock()
        with self.fluxo_http() as adaptador:
            self.assertIs(False, self.vinculo_a.vincular(env["tentar_login_automatico"])(
                registro_tentativas=self.tentativas_a, infraestrutura_cliente=self.b))
        env["WebTC420"].assert_not_called()
        self.assertEqual([], adaptador.enviados)

    def test_03_janela_troca_referencia_apresentada_sem_ancora_estavel(self):
        _, janela = self.fixture_manual(self.a)
        janela.registro_tentativas = self.tentativas_a
        janela.infraestrutura_cliente = self.b
        with self.fluxo_http() as adaptador:
            janela.conectar()
        self.assertTrue(janela.servidor_iniciado)
        self.assertIs(self.b, janela.web.politica_http.proprietario)
        self.assertEqual("normal", janela.botao_conectar.opcoes["state"])
        self.somente_b(adaptador)
        fx, _ = self.fixture_manual(self.a)
        ligada = fx.criar_janela(self.a, vinculo_http=self.vinculo_a)
        ligada.infraestrutura_cliente = self.b
        fx.env["WebTC420"].reset_mock()
        with self.fluxo_http() as adaptador:
            ligada.conectar()
        fx.env["WebTC420"].assert_not_called()
        self.assertEqual([], adaptador.enviados)

    def test_04_promocao_captura_dono_recebido_sem_prova_externa(self):
        fx = self.fixture_main()
        fx.env["print"] = Mock()
        fx.env["iniciar_como_cliente"](
            "principal-simulado", registro_tentativas=self.tentativas_a,
            infraestrutura_cliente=self.b)
        with self.fluxo_http() as adaptador:
            resultado = fx.monitores[0].ao_promover_automaticamente()
        self.assertIsNotNone(resultado)
        self.assertIs(self.b, resultado["web"].politica_http.proprietario)
        self.assertIs(self.b.registro_recursos, fx.leitores[0].recursos_cliente.registro)
        self.somente_b(adaptador)
        fx.env["WebTC420"].reset_mock()
        self.vinculo_a.vincular(fx.env["iniciar_como_cliente"])(
            "principal-simulado", registro_tentativas=self.tentativas_a, infraestrutura_cliente=self.b)
        with self.fluxo_http() as adaptador:
            self.assertIsNone(fx.monitores[-1].ao_promover_automaticamente())
        fx.env["WebTC420"].assert_not_called()
        self.assertEqual([], adaptador.enviados)

    def test_05_registro_recursos_trocado_detectado_pelo_validador_http(self):
        original = self.a._instalacao
        contexto_adulterado = replace(original.contexto, recursos=self.b.registro_recursos)
        # Violação controlada de atributos privados só para examinar quais
        # relações o validador atual verifica; não é uma operação suportada.
        object.__setattr__(self.a, "_instalacao", replace(original, contexto=contexto_adulterado))
        try:
            with self.assertRaises(modulo.InfraestruturaHttpInvalida):
                modulo.exigir_infraestrutura_http(self.a)
            self.assertIs(original.contexto.recursos, self.a.registro_recursos)
            self.assertIs(self.a, self.a.registro_http.proprietario)
            with self.assertRaises(modulo.InfraestruturaHttpInvalida):
                self.vinculo_a.validar(self.a)
        finally:
            object.__setattr__(self.a, "_instalacao", original)

    def test_06_registro_http_estrangeiro_ja_e_recusado(self):
        original = self.a._instalacao
        object.__setattr__(self.a, "_instalacao", replace(original, http=self.b.registro_http))
        try:
            with self.assertRaises(modulo.InfraestruturaHttpInvalida):
                modulo.exigir_infraestrutura_http(self.a)
            with self.assertRaises(modulo.InfraestruturaHttpInvalida):
                self.vinculo_a.validar(self.a)
        finally:
            object.__setattr__(self.a, "_instalacao", original)

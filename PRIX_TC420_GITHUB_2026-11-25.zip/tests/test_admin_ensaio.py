"""Verificação da credencial temporária do protótipo, sem segredos versionados."""
import secrets
import unittest
from admin_visual_tk import CredencialTemporaria


class CredencialAdministradorEnsaio(unittest.TestCase):
    def test_senha_correta_confere_e_incorreta_nao(self):
        senha = secrets.token_urlsafe(16)
        credencial = CredencialTemporaria.criar(senha)
        self.assertTrue(credencial.verificar(senha))
        self.assertFalse(credencial.verificar(secrets.token_urlsafe(16)))
        self.assertNotIn(senha.encode(), credencial.resumo)

    def test_cadastros_usam_sais_distintos(self):
        senha = secrets.token_urlsafe(16)
        a, b = CredencialTemporaria.criar(senha), CredencialTemporaria.criar(senha)
        self.assertNotEqual(a.sal, b.sal)
        self.assertNotEqual(a.resumo, b.resumo)

# Testes de auditoria suficiencia cliente ac3d2: consulte os métodos test_* para as condições e os contratos verificados.
# Leitura dos cenários: preparação cria o estado; patch/dublês controlam dependências; assert verifica o contrato.
# O alcance de cada caso depende das substituições abaixo; aprovação da suíte não comprova ensaio físico da TC420.
"""AC3-D2: suficiencia e limites reais; IO e threads de leitor simulados."""
import gc
import threading
import unittest
import weakref
from unittest.mock import Mock, patch

from config.arquivos import ContextoArquivosConfiguracao
from rede.infraestrutura_cliente import InfraestruturaRegistrosCliente
from rede.lerdadosserver import LeitorDadosServidor
from rede import composicao_operacional_cliente as composicao
from rede import buscarservidor
from test_recursos_cliente_integrados import SocketLeituraFalso
from test_descoberta_cliente_integrada import SocketDescobertaFalso
import test_composicao_admissoes_cliente as d1
import test_composicao_operacional_cliente as anterior
import test_auditoria_atividades_cliente_ac3b as atividades
import test_admissao_config_cliente as config


# Grupo de 32 cenários: cada método test_* prepara sua condição e verifica o resultado esperado.
class AuditoriaSuficienciaCliente(unittest.TestCase):
    # Apenas helpers: nao herdar nem redescobrir os testes anteriores.
    setUp = d1.ComposicaoAdmissoesCliente.setUp
    fabricar = d1.ComposicaoAdmissoesCliente.fabricar
    preparar = d1.ComposicaoAdmissoesCliente.preparar
    partir = d1.ComposicaoAdmissoesCliente.partir
    executar_descoberta = d1.ComposicaoAdmissoesCliente.executar_descoberta
    observar = d1.ComposicaoAdmissoesCliente.observar
    fechar_gates = d1.ComposicaoAdmissoesCliente.fechar_gates
    terminal = d1.ComposicaoAdmissoesCliente.terminal
    thread_retornada = d1.ComposicaoAdmissoesCliente.thread_retornada
    operacao_http = d1.ComposicaoAdmissoesCliente.operacao_http
    avaliar = d1.ComposicaoAdmissoesCliente.avaliar
    valido = d1.ComposicaoAdmissoesCliente.valido
    itens = d1.ComposicaoAdmissoesCliente.itens

    def fechar_todos(self):
        self.leitor.parar()
        self.fechar_gates()
        self.infra.registro_atividades_permanentes.fechar_admissao()
        self.infra.registro_http.fechar_admissao()

    def conhecido_terminal(self):
        self.thread_retornada(observar=True)
        self.fechar_todos()
        self.assertTrue(self.valido()['responsabilidades_conhecidas_resolvidas'])

    def test_01_admissoes_abertas(self):
        r = self.valido()
        self.assertFalse(r['admissoes_operacionais_fechadas'])
        self.assertTrue(all(not c['admissao_fechada'] for c in r['controles_admissao']))
        self.assertEqual('incompleta', r['cobertura_operacional'])

    def test_02_fechadas_operacao_pendente(self):
        self.leitor._admissao_register.admitir()
        self.fechar_todos()
        r = self.valido()
        self.assertTrue(r['admissoes_operacionais_fechadas'])
        self.assertFalse(r['responsabilidades_conhecidas_resolvidas'])
        self.assertFalse(self.itens('register')[0]['execucao_concluida'])

    def test_03_operacao_concluida_socket_aberto(self):
        c = self.leitor._admissao_register
        with c.executar(c.admitir()) as dono:
            socket = dono.abrir_socket(SocketLeituraFalso)
        self.addCleanup(socket.close)
        item, = self.itens('register')
        self.assertTrue(item['execucao_concluida'])
        self.assertFalse(item['recursos_resolvidos'])
        self.assertIn(socket.recurso_id.numero, self.valido()['recursos_pendentes'])

    def test_04_retorno_sem_observacao(self):
        self.thread_retornada()
        self.fechar_todos()
        item, = self.valido()['atividades_permanentes']
        self.assertTrue(item['retorno'])
        self.assertFalse(item['thread_terminada'])
        self.assertFalse(item['termino_confirmado'])
        self.threads[-1].is_alive.assert_not_called()

    def test_05_terminada_autorizacao_pendente(self):
        self.leitor._admissao_subscribe.admitir()
        self.thread_retornada(observar=True)
        self.assertTrue(self.valido()['atividades_permanentes'][0]['termino_confirmado'])
        self.assertFalse(self.valido()['responsabilidades_conhecidas_resolvidas'])

    def test_06_CHECK_sem_TCP(self):
        self.leitor._admissao_descoberta_inicial._admissao_checks.admitir(self.leitor.recursos_cliente)
        self.fechar_todos()
        item, = self.itens('check_tcp')
        self.assertEqual([], item['recursos'])
        self.assertFalse(item['responsabilidade_resolvida'])

    def test_07_CONFIG_tentativa_desconhecida(self):
        fx = config.AdmissaoConfigCliente()
        fx.setUp()
        with fx.transporte([fx.objeto()]), patch.object(fx.controle, '_publicar_saida', side_effect=ValueError()):
            with self.assertRaises(ValueError):
                fx.configurar()
        r = fx.infra.avaliar_responsabilidades_cliente()
        self.assertTrue(r['leituras_revalidadas'])
        self.assertTrue(any('publicacao_incompleta' in a['pendencias'] for a in r['admissoes']))
        tentativa, = [a for a in r['admissoes'] if a['familia'] == 'tentativa_config']
        self.assertFalse(tentativa['publicacoes_resolvidas'])
        self.assertFalse(r['responsabilidades_conhecidas_resolvidas'])

    def test_08_SUBSCRIBE_antigo_pendente(self):
        self.leitor._admissao_subscribe.admitir()
        geracao = self.leitor.recursos_cliente._geracao_retentativas
        self.guarda.promover(geracao)
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.thread_retornada(observar=True, leitor=novo)
        self.assertEqual(geracao.numero, self.itens('subscribe')[0]['geracao_id'])
        self.assertFalse(self.valido()['responsabilidades_conhecidas_resolvidas'])

    def test_09_REGISTER_antigo_apos_promocao(self):
        d1.ComposicaoAdmissoesCliente.test_critica_D_REGISTER_antigo_B_terminada(self)

    def test_10_HTTP_publicacao_desconhecida(self):
        op = self.operacao_http()
        self.infra.registro_http.executar(op, lambda: None)
        self.infra.registro_http.marcar_desconhecida(op, motivo='falha_publicacao')
        self.assertFalse(self.valido()['http'][0]['execucao_resolvida'])
        self.assertFalse(self.valido()['responsabilidades_conhecidas_resolvidas'])

    def test_11_AC1F1_handle_limpo_identidade_desconhecida(self):
        anterior.ComposicaoOperacionalCliente.test_13_D_limpeza_retencao_nao_resolve_identidade(self)

    def test_12_vazio_nao_certifica_cobertura(self):
        self.infra = InfraestruturaRegistrosCliente()
        r = self.valido()
        for nome in ('retentativas', 'recursos', 'admissoes', 'http', 'arquivos', 'atividades_permanentes'):
            self.assertEqual([], r[nome])
        self.assertTrue(r['responsabilidades_conhecidas_resolvidas'])
        self.assertEqual('incompleta', r['cobertura_operacional'])

    def test_13_ABA_uso_entre_ciclos_iguais_nao_detectado(self):
        socket = self.leitor.recursos_cliente.abrir_socket(SocketLeituraFalso)
        self.addCleanup(socket.close)
        registro = self.infra.registro_recursos
        obter = self.infra.obter_tentativas_subscribe
        estados, chamadas = [], []
        def consulta():
            retrato = obter()
            if not chamadas:
                antes = registro.obter_retrato()
                registro.usar(socket.recurso_id, lambda obj: estados.append(
                    registro.obter_retrato()['recursos'][0]['usos']), fechar_ao_sair=False)
                self.assertEqual(antes, registro.obter_retrato())
            chamadas.append(True)
            return retrato
        with patch.object(InfraestruturaRegistrosCliente, 'obter_tentativas_subscribe', side_effect=consulta):
            r = self.valido()
        self.assertEqual([1], estados)
        self.assertEqual(2, len(chamadas))
        self.assertNotIn('consulta_incoerente', r['pendencias'])
        self.assertFalse(r['snapshot_atomico'])

    def test_14_geracao_antiga_limpeza_desconhecida(self):
        c = self.leitor._admissao_subscribe
        identidade = c.admitir()
        dono = c.iniciar(identidade)
        objeto = SocketLeituraFalso()
        objeto.erro_close = OSError('limpeza_simulada')
        socket = dono.abrir_socket(lambda: objeto)
        with self.assertRaises(OSError):
            socket.close()
        c.finalizar(identidade)
        self.guarda.promover(self.leitor.recursos_cliente._geracao_retentativas)
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.thread_retornada(observar=True, leitor=novo)
        self.assertFalse(self.itens('subscribe')[0]['recursos_resolvidos'])
        self.assertIn(socket.recurso_id.numero, self.valido()['recursos_pendentes'])

    def test_15_conhecido_resolvido_Tk_pendente(self):
        root = atividades.TkSimulado()
        callback = Mock()
        root.after(0, callback)
        self.conhecido_terminal()
        self.assertEqual(1, len(root.pendentes))
        callback.assert_not_called()
        self.assertTrue(self.valido()['responsabilidades_conhecidas_resolvidas'])

    def test_16_global_nao_confirmado(self):
        self.conhecido_terminal()
        r = self.valido()
        self.assertTrue(r['admissoes_operacionais_fechadas'])
        self.assertIn('aplicacao_fora_do_escopo', r['pendencias'])
        self.assertFalse(r['encerramento_global_confirmado'])

    def test_critica_A_aceita_antes_gate_pode_executar_depois(self):
        c = self.leitor._admissao_subscribe
        identidade = c.admitir()
        self.fechar_todos()
        self.assertIsNone(c.admitir())
        self.assertFalse(self.itens('subscribe')[0]['responsabilidade_resolvida'])
        c.iniciar(identidade)
        self.assertFalse(self.itens('subscribe')[0]['execucao_concluida'])
        c.finalizar(identidade)
        self.assertTrue(self.itens('subscribe')[0]['responsabilidade_resolvida'])

    def test_critica_B_thread_terminada_recurso_antigo(self):
        c = self.leitor._admissao_register
        with c.executar(c.admitir()) as dono:
            socket = dono.abrir_socket(SocketLeituraFalso)
        self.addCleanup(socket.close)
        self.thread_retornada(observar=True)
        self.guarda.promover(self.leitor.recursos_cliente._geracao_retentativas)
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.thread_retornada(observar=True, leitor=novo)
        r = self.valido()
        self.assertTrue(all(a['termino_confirmado'] for a in r['atividades_permanentes']))
        self.assertIn(socket.recurso_id.numero, r['recursos_pendentes'])
        self.assertFalse(r['responsabilidades_conhecidas_resolvidas'])

    def test_critica_C_CHECK_recuperacao_sem_socket(self):
        d1.ComposicaoAdmissoesCliente.test_critica_C_retry_terminada_CHECK_pendente(self)

    def test_critica_D_ciclo_A_multiplas_operacoes_B_resolvida(self):
        antigo = self.leitor
        geracao = antigo.recursos_cliente._geracao_retentativas
        # A inicia quatro familias e CHECK, todos sem rede fisica.
        c = antigo._admissao_subscribe
        identidade = c.admitir()
        c.iniciar(identidade)
        with patch.object(c, '_publicar_saida', side_effect=ValueError('publicacao_simulada')):
            with self.assertRaises(ValueError):
                c.finalizar(identidade)
        cfg = antigo._admissao_config
        with cfg.executar(cfg.admitir()) as dono:
            cfg.admitir_tentativa(dono._operacao)
        descoberta = antigo._admissao_descoberta_inicial
        with descoberta.executar(descoberta.admitir()):
            descoberta._admissao_checks.admitir(antigo.recursos_cliente)
        register = antigo._admissao_register
        with register.executar(register.admitir()):
            pass
        self.guarda.promover(geracao)
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        # B resolve cada familia e sua thread; A permanece retida sem leitor externo.
        for controle in (novo._admissao_register, novo._admissao_config, novo._admissao_descoberta_inicial):
            with controle.executar(controle.admitir()):
                pass
        sub = novo._admissao_subscribe
        token = sub.admitir()
        sub.iniciar(token)
        sub.finalizar(token)
        self.thread_retornada(observar=True, leitor=novo)
        referencia = weakref.ref(antigo._admissao_subscribe)
        self.leitor = novo
        del antigo, c, cfg, descoberta, register, dono
        gc.collect()
        self.assertIsNotNone(referencia())
        r = self.valido()
        a = [i for i in r['admissoes'] if i['geracao_id'] == geracao.numero]
        b = [i for i in r['admissoes'] if i['geracao_id'] == novo.recursos_cliente.geracao_id]
        self.assertEqual({'register', 'config', 'tentativa_config', 'descoberta_inicial', 'check_tcp', 'subscribe'},
                         {i['familia'] for i in a})
        self.assertTrue(all(i['responsabilidade_resolvida'] for i in b))
        self.assertTrue(any('publicacao_incompleta' in i['pendencias'] for i in a))
        self.assertFalse(r['responsabilidades_conhecidas_resolvidas'])

    def test_critica_E_HTTP_contrato_nao_atesta_sockets_Requests(self):
        contexto = self.infra.preparar_http_inicial()
        resposta = Mock()
        for tipo in ('login', 'approval'):
            op = self.infra.registro_http.admitir(contexto, tipo)
            self.assertIs(resposta, self.infra.registro_http.executar(op, lambda: resposta))
        self.infra.registro_http.fechar_admissao()
        r = self.valido()
        self.assertEqual(2, len(r['http']))
        self.assertTrue(all(i['execucao_resolvida'] for i in r['http']))
        self.assertEqual([], r['recursos'])
        resposta.close.assert_not_called()
        # O executor nao recebeu inventario de sockets internos; nao simula Requests real.
        self.assertEqual('incompleta', r['cobertura_operacional'])

    def test_critica_F_mudanca_apos_captura_segunda_rodada(self):
        obter = self.infra.obter_tentativas_subscribe
        chamadas = []
        def consultar():
            retrato = obter()
            chamadas.append(True)
            if len(chamadas) == 2:
                self.leitor._admissao_subscribe.admitir()
            return retrato
        with patch.object(InfraestruturaRegistrosCliente, 'obter_tentativas_subscribe', side_effect=consultar):
            r = self.valido()
        self.assertEqual([], r['admissoes'])
        self.assertTrue(r['responsabilidades_conhecidas_resolvidas'])
        self.assertFalse(r['admissoes_operacionais_fechadas'])
        self.assertFalse(self.valido()['responsabilidades_conhecidas_resolvidas'])

    def test_critica_G_CLIENTE_individual_PRINCIPAL_interface(self):
        root = atividades.TkSimulado()
        root.after(0, Mock())
        self.terminal()
        principal = Mock(recurso_aberto=True, coordenador_ativo=True, modo_atual='PRINCIPAL')
        r = self.valido()
        self.assertTrue(r['retentativas'][0]['encerramento_confirmado'])
        self.assertTrue(principal.recurso_aberto)
        self.assertTrue(principal.coordenador_ativo)
        self.assertEqual(1, len(root.pendentes))
        self.assertFalse(r['encerramento_global_confirmado'])

    def test_24_mudanca_persistente_entre_ciclos_detectada(self):
        obter = self.infra.obter_tentativas_subscribe
        chamadas = []
        def consulta():
            retrato = obter()
            if not chamadas:
                self.leitor._admissao_subscribe.admitir()
            chamadas.append(True)
            return retrato
        with patch.object(InfraestruturaRegistrosCliente, 'obter_tentativas_subscribe', side_effect=consulta):
            r = self.avaliar()
        self.assertFalse(r['leituras_revalidadas'])
        self.assertIn('consulta_incoerente', r['pendencias'])

    def test_25_publicacao_entre_registros_detectada(self):
        d1.ComposicaoAdmissoesCliente.test_critica_E_publicacao_e_limpeza_entre_leituras(self)

    def test_26_origem_preparada_invisivel_ao_vetor_de_leitura(self):
        antes = composicao._ler(self.infra)
        dono = self.infra.preparar_descoberta()
        self.assertIsNotNone(dono)
        self.assertEqual(antes, composicao._ler(self.infra))
        self.assertTrue(self.valido()['responsabilidades_conhecidas_resolvidas'])

    def test_27_preparacao_em_curso_antes_da_reserva_invisivel(self):
        entrou, liberar = threading.Event(), threading.Event()
        reservar = self.infra.registro_recursos.reservar
        erros = []
        def pausa(*args, **kwargs):
            entrou.set()
            if not liberar.wait(3):
                raise TimeoutError('barreira_simulada')
            return reservar(*args, **kwargs)
        def trabalho():
            try:
                buscarservidor.buscar_servidor(infraestrutura_cliente=self.infra)
            except BaseException as erro:
                erros.append(erro)
        with patch.object(self.infra.registro_recursos, 'reservar', side_effect=pausa), \
                patch('socket.socket', return_value=SocketDescobertaFalso()):
            thread = threading.Thread(target=trabalho)
            thread.start()
            try:
                self.assertTrue(entrou.wait(3))
                r = self.valido()
                self.assertEqual([], r['recursos'])
                self.assertTrue(r['responsabilidades_conhecidas_resolvidas'])
                self.assertTrue(thread.is_alive())
            finally:
                liberar.set()
                thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual([], erros)
        self.assertEqual(1, len(self.valido()['recursos']))

    def test_28_gates_locais_nao_fecham_novas_geracoes(self):
        self.leitor.parar()
        self.assertTrue(all(c['admissao_fechada'] for c in self.valido()['controles_admissao']))
        novo = LeitorDadosServidor(infraestrutura_cliente=self.infra)
        self.assertIsNotNone(novo._admissao_subscribe.admitir())
        self.assertFalse(self.valido()['admissoes_operacionais_fechadas'])

    def test_29_passividade_e_observacoes_explicitas(self):
        d1.ComposicaoAdmissoesCliente.test_critica_F_passividade_das_consultas(self)

    def test_30_partida_ambigua_permanece_pendente(self):
        d1.ComposicaoAdmissoesCliente.test_04_partida_ambigua(self)

    def test_31_gates_fechados_recusam_novas_responsabilidades_cobertas(self):
        contexto_http = self.infra.preparar_http_inicial()
        arquivos = ContextoArquivosConfiguracao(self.infra)
        self.fechar_todos()
        self.assertTrue(self.valido()['admissoes_operacionais_fechadas'])
        for controle in (self.leitor._admissao_register, self.leitor._admissao_config,
                         self.leitor._admissao_descoberta_inicial, self.leitor._admissao_subscribe):
            self.assertIsNone(controle.admitir())
        checks = self.leitor._admissao_descoberta_inicial._admissao_checks
        self.assertIsNone(checks.admitir(self.leitor.recursos_cliente))
        self.assertIsNone(self.infra.registro_http.admitir(contexto_http, 'approval'))
        self.assertIsNone(self.guarda.reservar_retentativa(self.leitor.recursos_cliente._geracao_retentativas))
        fabrica = Mock()
        with self.assertRaises(RuntimeError):
            arquivos.executar(fabrica, Mock())
        with self.assertRaises(RuntimeError):
            LeitorDadosServidor(infraestrutura_cliente=self.infra)
        fabrica.assert_not_called()
        self.assertEqual([], self.valido()['admissoes'])

    def test_32_GET_POST_simulados_publicam_contrato_sem_prova_fisica(self):
        from tc420.web import WebTC420
        web = WebTC420(ip='dispositivo-simulado', politica_http=self.infra.criar_politica_http())
        contexto = self.infra.preparar_http_inicial()
        # Campos sinteticos de protocolo, sem credenciais reais ou valores de acesso.
        post = Mock(text='SUCCESS:LOGIN:SIMULADO:SEM_VALOR_DE_ACESSO')
        get = Mock(text='SUCCESS:APPROVAL:<00W1.1;e=d=1;Min0;Max10>')
        with patch('tc420.web.requests.post', return_value=post) as enviar, \
                patch('tc420.web.requests.get', return_value=get) as consultar:
            self.infra.executar_login_manual(web, None, None, contexto_http=contexto)
            self.infra.executar_approval(contexto, web)
        self.assertEqual(1, enviar.call_count)
        self.assertEqual(1, consultar.call_count)
        r = self.valido()
        self.assertTrue(all(o['execucao_resolvida'] for o in r['http']))
        self.assertEqual({'login', 'approval'}, {o['operacao'] for o in r['http']})
        self.assertEqual([], r['recursos'])
        post.close.assert_not_called()
        get.close.assert_not_called()


if __name__ == '__main__':
    unittest.main()

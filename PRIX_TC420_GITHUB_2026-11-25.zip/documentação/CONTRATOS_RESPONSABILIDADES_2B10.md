# Etapa 2B.10 — contratos e associação de responsabilidades

13/11/2026. Auditoria e desenho, sem alteração operacional, compactação,
shutdown, substituição de Thread ou política automática.

## Acessos a registro.threads

Busca textual em rede/servidor.py, interface, main, testes e protótipos; excluída
a pasta de referência. Ocorrências homônimas self.threads de fixtures de cliente
não são referências ao RegistroTrabalhadores e não devem ampliar o contrato dele.

| Consumidor | Dependência |
| --- | --- |
| RegistroTrabalhadores.__init__/registrar_e_iniciar | Lista mutável; append antes de start, ordem e referência forte originais |
| obter_situacao | Iteração, is_alive e name; não expõe mortos no retrato |
| ControleCicloServidor.finalizar | is_alive de cada objeto; erros e sockets são provas separadas |
| _situacao_historica_sob_lock | name/is_alive e mesma prova de sockets; não exige objeto no resumo de ciclo confirmado |
| iniciar_servidor, recuperação parcial | Snapshot list(registro.threads), identidade contra current_thread e join fora do lock |
| Lista local principais_iniciados | Retém os três originais independentemente de registro.threads; join normal e de parada |
| test_guarda_sockets_integrada | Iteração/join, lista vazia e comprimento após start ambíguo |
| test_compactacao_registro:162 | assertIs do objeto original após start ambíguo |
| test_saida_aplicacao_b2:235,614 | Iteração/join e comprimento durante partida parcial |
| test_recursos_resolvidos_prototipo | Identidade preservada no ambíguo e diferença explícita do resumo resolvido |
| Harnesses de memória/localhost | len, is_alive, tipo e snapshot externo dos originais |
| protótipos de guarda/intervalos | Iteração/name/is_alive; 2B.9 substitui posições somente experimentalmente |

Não foi encontrado consumidor operacional atribuindo nome/daemon ou removendo
posições externamente. Isso não revoga a mutabilidade da lista exposta nem da
Thread. Testes não exercitarem uma possibilidade não autoriza mudar seu contrato.
SaidaAplicacao._threads é outra coleção: conserva thread, partida_pendente e
start_falhou. Supervisão conserva contexto; nenhuma dessas estruturas deve ser
confundida com a lista de trabalhadores do servidor.

## Resposta às duas questões

**Liberar originais mantendo a lista original e os mesmos elementos: não.** Uma
lista forte continua raiz de cada Thread. Retirar uma segunda referência interna
não muda isso. Visão de compatibilidade que conserva todos os originais tem o
mesmo limite. Proxy/weakref/resumo altera identidade, tipo, mutabilidade ou
disponibilidade após GC e precisa de decisão contratual. Não se propõe mexer
nos campos privados internos de threading.Thread para obter economia.

**Separar comprovação do objeto Thread: é possível como desenho**, mantendo o
objeto enquanto a prova não estiver completa. A memória não será liberada enquanto
a lista de compatibilidade ou chamadores continuarem mantendo o original. Logo,
prova separada e economia são decisões diferentes. A 2B.9 mostrou esse efeito:
referências externas impediram liberação e os resumos inicialmente aumentaram custo.

## Modelo proposto, ainda não integrado

Registro de trabalhador com identidade própria monotônica por ciclo, referência
forte à Thread enquanto necessário, resultado de start (pendente, observado,
incerto ou ausência comprovada), término observado, join confirmado, conjunto de
reservas originais e responsabilidades de handler, pendências/erros publicados.

Admissão deve criar trabalhador e vínculos antes de start. Retorno normal de start
publica evidência; exceção mantém incerteza mesmo com ident conhecido. O worker
publica resultados de suas responsabilidades antes do retorno; observador confirma
término/join fora dos locks. Revalidação final sob lock exige nenhuma partida,
operação, handler ou limpeza pendente. Falha de observação mantém incerteza.
is_alive False ou fileno -1 sozinhos nunca bastam.

Associação precisa ser completa e estabelecida no produtor: reserva de accept
antecede alocação; cliente aceito recebe vínculo ao handler antes da partida.
Os trabalhadores TCP/UDP/HTTP têm responsabilidades diferentes e durações próprias;
não assumir que todos possuem exatamente uma reserva. Operações de limpeza
executadas por outro trabalhador precisam ter responsabilidade transferida
explicitamente, sem intervalo sem dono. Não inferir propriedade pelos args da
Thread depois de terminar.

Publicação tardia só pode resolver a identidade original; erro não é convertido
em sucesso por GC/timeout. Comprovante histórico contém identidade de ciclo e
trabalhador, evidências e resultado, não socket/Thread por obrigação. O comprovante
só pode substituir a participação do objeto na avaliação depois de uma transição
formalmente definida e testada; não basta incrementar contador de concluídos.

Para B2/supervisão, a confirmação conserva também coordenador retornado,
publicação de limpeza concluída, gate fechado e provas de todas as reservas.
O desenho não muda essa fórmula nem a ordem controle→registro. Sem acionar
compactação, o modelo pode ser observado em paralelo e comparado com a avaliação
atual; discordância deve impedir confirmação, nunca antecipá-la.

## Estratégias comparadas

| Estratégia | Compatibilidade | Memória |
| --- | --- | --- |
| Metadados em paralelo, lista original intacta | Pode preservar API existente; exige provar novos vínculos | Acrescenta custo; não libera Thread |
| Registro interno + visão forte dos originais | Mantém acesso/identidade enquanto visão retiver tudo | Não resolve crescimento de originais |
| Visão fraca ou resumos após prova | Pode liberar objetos sem referência externa | Exige evolução explícita de identidade/disponibilidade/mutabilidade |
| Comprovantes por trabalhador/ciclo com consulta formal | Separa diagnóstico de execução | Necessita definir contrato e medir referências externas |

Nenhuma opção com mudança pública foi escolhida. Shutdown tardio permanece
inalterado; o contraexemplo RuntimeError da 2B.9 continua válido.

## Medição limitada de associação durante admissões contínuas

Experimento isolado reutilizou registrar_com_responsabilidades da 2B.9, sem chamar
resumir_threads_resolvidas. Mil admissões sequenciais com threads realmente
start/join, cada qual vinculada à sua reserva sem alocação; outra reserva ficou
pendente durante todo o experimento. Lista/originais preservados e nenhuma
confirmação indevida. Não é servidor ativo nem ensaio prolongado.

[CUSTO_ASSOCIACOES_2B10.json](CUSTO_ASSOCIACOES_2B10.json), tracemalloc com GC:
atual 2.384.117 bytes; associação 2.756.304 bytes, acréscimo de 372.187 bytes
(cerca de 372 bytes por trabalhador nesta amostra). Inclui provas de partida,
weakmaps e tuplas de vínculo, não apenas um campo. Picos: 2.395.325/2.767.464 bytes.
Tempos instrumentados 0,581/0,475 s, uma execução por variante: não demonstra
aceleração ou custo estatístico de desempenho. Não é RSS. Reprodução: criar
registro atual/RegistroThreadsExperimental; reservar uma pendência, executar mil
reservas + Thread start/join + resolução sem alocação; registrar vínculo antes
de start no candidato; GC e leitura de tracemalloc, sem resumir a lista.

## Conclusão e verificações

Auditoria 2B.10 concluída no escopo de desenho, com medição exploratória limitada.
Não foi implementado novo modelo nem alegada sua validação completa com B2.
A prova de associação e a política de exposição da lista devem ser especificadas
separadamente antes de qualquer economia por liberação dos originais.

Verificações: busca dos acessos e classificação dos consumidores; execução das
mil admissões de cada variante, lista com mil originais encerrados e reserva
pendente preservada. Sem nova regressão completa nesta solicitação; 2.083 é a
referência da execução anterior. Sem alteração de shutdown ou teste físico.

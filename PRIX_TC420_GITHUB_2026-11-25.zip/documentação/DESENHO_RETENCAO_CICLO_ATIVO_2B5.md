# Etapa 2B.5 — desenho e protótipos de retenção no ciclo ativo

12/11/2026. Estudo isolado: nenhum módulo operacional alterado. Protótipos não
são importados pelo servidor, pela B2 ou pela supervisão. Nenhuma política de
retenção foi ativada. Não houve TC420 ou socket real nesta etapa.

## Separação conceitual e regra de segurança

| Categoria | Tratamento exigido |
| --- | --- |
| Responsabilidade operacional | Registro integral de recurso/uso, thread, criação incerta, fechamento em andamento, erro ou limpeza pendente |
| Resultado resolvido | Só reduzir representação após prova explícita de ausência de recurso ou fechamento concluído; não inferir resolução pela ausência de entrada |
| Identidade e diagnóstico | Token original reconhecido por identidade, dono/ciclo preservados, ordem/conteúdo das consultas e retornos repetidos conservados |

Uma otimização nunca pode transformar pendência em confirmação. Start ambíguo
não é término comprovado. O protótipo não remove qualquer thread. A presença de
token externo válido é retenção legítima do contrato, não prova de vazamento.

## Caminho 1 — representação individual menor (protótipo A)

`SemRecursoMinimo` guarda por instância apenas o token e o resultado variável
de publicação do handler. Estado sem_recurso, recurso None e flags invariantes
ficam compartilhados na classe. O produtor real é substituído por patch somente
no processo experimental. A elegibilidade continua definida pelo método
operacional: ausência comprovada, nenhum recurso, erro ou pendência.

Preserva atributos usados pelas consultas, identidade original, ordem, fechamento
repetido e recusas de publicação sem responsabilidade. Não reduz referências a
tokens, dono ou dicionário. Não conserva introspecção privada dos oito campos
como campos de dataclass; replace com constantes como argumentos deixa de ser
equivalente. Os caminhos públicos atuais não fazem essa substituição sobre uma
entrada sem_recurso terminal; essa restrição deve permanecer explícita antes
de uma integração futura. Não é uma troca operacional aprovada nesta etapa.

## Caminho 2 — separar recurso de resultado (protótipo B)

`RegistroSeparacaoExperimental.separar_recursos_resolvidos()` retira apenas a
referência ao objeto de recurso de entradas **fechada**, sem uso, erro, pendência
ou erro de handler. Mantém entrada, token, metadados e todas as threads. É uma
operação experimental explícita, idempotente, serializada pelo lock existente,
sem close/join sob lock. `fechando` e `aguarda_limpeza` nunca são elegíveis.

Uma weakref no teste comprovou coleta do objeto fechado, enquanto token original
continuou válido e diagnóstico individual permaneceu igual. Publicação tardia
bem-sucedida seguida de fechamento permite separação; publicação com erro conserva
o recurso e impede confirmação. Durante close bloqueado, nada é separado.

Isso reduz o grafo alcançado pelo token, mas **não rompe token.dono→registro**.
Entradas, tokens e threads continuam retidos. Não ajuda a carga sem_recurso, que
já não contém objetos de recurso. O ganho com sockets simulados não estima o
tamanho de sockets reais ou seus buffers nativos.

Há compatibilidade ainda não demonstrada integralmente: solicitar_parada_ciclo
percorre recursos conhecidos, inclusive fechados, e pode invocar shutdown.
Retirar a referência elimina essa chamada sobre objetos já fechados. Com sockets
usuais isso tende a evitar OSError tolerado, mas dublês/wrappers podem ter outros
efeitos ou falhas. Não tratar o protótipo como integração segura só porque a
amostra de testes passou. A decisão de não reter objetos fechados exige definir
esse contrato e validar consumidores/concor­rência antes de alterar produção.

### Separação adicional de identidade — desenho ainda não prototipado

Trocar simplesmente dono por weakref/proxy quebra a verificação `token.dono is
registro` e não foi adotado. Existe uma possibilidade menos invasiva a investigar:
conservar dono, usar índice fraco dos tokens originais ainda alcançáveis e guardar
resultados uniformes sem recurso em intervalos de IDs. Uma consulta poderia
reconstruir os mesmos diagnósticos em ordem, sem guardar uma entrada completa
por reserva uniforme. Token fabricado teria de falhar por identidade exata no
índice, nunca ser aceito apenas porque seu número pertence a um intervalo.

Esse desenho não foi medido nem validado. Precisa resolver publicação atômica
entre tabela operacional/índice fraco/intervalos, callbacks concorrentes do GC,
tokens ainda mantidos por chamadores e estados heterogêneos. Responsabilidades
ativas devem continuar fortes; coletar um token jamais pode apagar pendência.
Não prometer memória constante: tokens externos, intervalos fragmentados e
consulta completa ainda podem custar O(n). Compressão de resultados uniformes
é possível em princípio sem concluir que todo histórico heterogêneo seja
compressível. É candidato a próximo protótipo, não justificativa para descarte.

## Caminho 3 — evolução explícita do histórico (somente proposta)

Se for necessário limitar definitivamente diagnósticos individuais, definir
contrato antes de implementar: quais estados podem virar resumo, período ou
quantidade retida, resposta para consulta de ID resumido, validade dos tokens
originais, tratamento de publicações repetidas/tardias e representação de cortes.
Erros e pendências jamais entram na janela de descarte. B2/supervisão precisam
continuar obtendo prova positiva por identidade do ciclo, independentemente de
uma política de diagnóstico individual.

Não foram escolhidos limites arbitrários nem implementadas revogação de token,
remoção de IDs, truncamento de diagnóstico ou compactação automática. Qualquer
mudança de contrato público depende de aprovação explícita sobre proposta concreta.

## Medições de 50 mil reservas

Fonte: [MEDICOES_RETENCAO_ATIVA_2B5.json](MEDICOES_RETENCAO_ATIVA_2B5.json).
Python 3.13.15, win32, GC explícito e tracemalloc. Cada carga é isolada, com
50.000 entradas mantidas e nenhuma thread iniciada. Uma execução por cenário.

| Carga / estratégia | Bytes retidos | Referências de recursos / abertos |
| --- | ---: | ---: |
| sem_recurso, atual | 13.817.088 | 0 / 0 |
| sem_recurso, A | 11.413.936 | 0 / 0 |
| sem_recurso, B | 13.813.944 | 0 / 0 |
| sockets simulados fechados, atual | 20.217.512 | 50.000 / 0 |
| sockets simulados fechados, B | 16.213.968 | 0 / 0 |

A reduziu cerca de **17,4%** contra a representação atual nesta carga, mantendo
crescimento linear. B reduziu cerca de **4,00 MB (19,8%)** na carga separada de
objetos de socket simulados fechados; não teve ganho significativo em sem_recurso.
Diferenças pequenas entre cenários incluem aquecimento e instrumentação.

No próprio cenário B de sockets fechados, antes de separar havia 20.213.880 bytes,
e depois 16.213.968: aproximadamente 4 MB liberados. As 50 mil identidades e
diagnósticos permaneceram presentes. Nenhuma dessas medições prova memória total
estável ou estima diretamente os 36 MB do ensaio real de uma hora.

Picos e tempos de carga/consulta estão no JSON. Consultas completas continuam
alocando todos os dicionários: pico absoluto de aproximadamente 27,89 MB na
representação atual sem_recurso e 25,49 MB em A. Sem promessa de throughput com
base numa única medição instrumentada.

## Arquivos, reprodução e verificação

- `prototipos/retencao_ciclo_ativo.py`: A e B, sem importação operacional.
- `tests/investigar_retencao_ativa.py`: medições; opção `--contratos` para executar
  baterias existentes sob substituição temporária, restaurada ao final.
- `tests/test_retencao_ativa_prototipo.py`: seis novos testes locais de diagnóstico,
  identidade, liberação, repetição, close concorrente, incerteza e handler tardio.

Executado: seis testes novos aprovados; **116 testes existentes aprovados em
3,004 s com A**, incluindo guarda, handlers, B2, supervisão e compactação individual;
**104 testes existentes aprovados em 3,100 s com B** via adaptador experimental
que aciona separação antes de obter_situacao. São baterias sobrepostas, não 220
testes novos ou únicos. Não comprovam todos os cenários de integração futura.

Regressão sem substituição global: **2.049 testes aprovados em 21,348 s**.
**129 arquivos Python compilados em memória**. Nenhum teste físico, nova carga
localhost ou ensaio prolongado nesta etapa.

## Resultado e decisão recomendada

Estudo 2B.5 concluído no escopo aplicado: há reduções incrementais possíveis com
identidade/diagnóstico preservados nos testes, mas nenhum protótipo elimina o
crescimento histórico ou está ativado no servidor. Manter produção como está.
Priorizar a prova de um índice de identidades com resultados uniformes compactos
antes de decidir pela perda de diagnóstico. Em paralelo, dimensionar a parcela
de threads encerradas em carga real, sem removê-las por is_alive isoladamente.
Qualquer integração exige etapa própria e validação dos limites apontados acima.

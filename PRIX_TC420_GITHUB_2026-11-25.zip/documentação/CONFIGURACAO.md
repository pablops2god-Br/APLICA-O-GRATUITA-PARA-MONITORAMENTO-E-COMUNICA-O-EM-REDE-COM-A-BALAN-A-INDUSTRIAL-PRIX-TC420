# Configuração persistente e credenciais

Preparação para instalador em 19/11: em execução empacotada (`sys.frozen`),
configuração e cadastro ficam em `%LOCALAPPDATA%\PRIX TC420`; em desenvolvimento,
permanecem na raiz do projeto. `config/caminhos.py` também fornece a pasta `logs`.
Não houve migração automática de arquivos reais. Ver [roteiro Windows](ROTEIRO_INSTALACAO_WINDOWS.md).

## Administrador da aplicação — 19/11/2026

O novo `administrador.json` é separado da configuração e da senha da TC420.
Guarda sal/verificador PBKDF2 e método de conexão; nunca a senha administrativa
em texto aberto. Cadastro seguido de login ocorre antes da comunicação inicial.
TCP salvo pede login em cada abertura; HTTPS automático permanece dispensado
quando já existe cadastro. Esqueci a senha pode limpar dados de conexão,
credencial associada e cadastro, com confirmação e parada B2 antes de reabrir.
Detalhes, escopo e falhas parciais em [ADMINISTRADOR_OPERACIONAL.md](ADMINISTRADOR_OPERACIONAL.md).

## Separação de responsabilidades

Há duas configurações distintas: parâmetros locais de acesso à balança, salvos
em JSON, e limites metrológicos W1.1/W1.2 obtidos por approval e distribuídos
por CONFIG. O JSON não guarda os limites de pesagem e não modifica a rede.

`config/configuracao.py` usa `__file__` para encontrar a raiz do projeto;
o caminho independe do diretório corrente. O arquivo fica em
`<raiz>/configuracao.json`, não dentro do pacote `config`.

```json
{
    "nome_rede": "Balança Teste",
    "ip": "192.0.2.21",
    "porta": 9800,
    "usuario": "admin",
    "salvar_login": true
}
```

| Função | Retorno e comportamento |
| --- | --- |
| `obter_caminho_configuracao()` | Caminho absoluto como string |
| `existe_configuracao()` | Resultado de isfile |
| `salvar_configuracao(...)` | Dicionário salvo; porta convertida para int e opção para bool |
| `carregar_configuracao()` | Objeto JSON decodificado ou None se ausente/ilegível/inválido ou com raiz de outro tipo; não valida um esquema completo dos campos |
| `salvar_senha(usuario, senha)` | True em sucesso; False com campos vazios/erro |
| `carregar_senha(usuario)` | Senha ou None; usuário vazio/erro retorna None |
| `remover_senha(usuario)` | True em sucesso; False em usuário vazio/erro |

JSON usa UTF-8, indentação de quatro espaços e `ensure_ascii=False`. Escrita
sobrescreve arquivo diretamente; não é atômica e não tem lock. Erros de escrita
ou conversão propagam. Leitura não valida schema: qualquer JSON válido pode ser
retornado. `bool` segue semântica Python; a string `"false"` seria True.
Não há validação de faixa de porta/IP ou múltiplas configurações por balança.

## Windows Credential Manager

`keyring` opera com serviço **PRIX_TC420** e chave de usuário igual ao argumento
`usuario`. O backend confirmado neste ambiente foi
`keyring.backends.Windows.WinVaultKeyring`. Credencial não é salva no JSON.
Erros imprimem somente tipo da exceção. Senha retornada não deve ser logada.

O serviço e usuário não incluem IP/nome da balança; duas balanças com o mesmo
usuário compartilham chave e uma gravação substitui a anterior. O cofre pertence
ao contexto do usuário Windows; copiar o projeto para outro PC não transfere a
senha. Keyring seleciona backend pelo ambiente: antes de uso em outro sistema,
verificar backend adequado. Remover credencial ausente pode retornar False.

As funções JSON não operam credenciais automaticamente. A tela de conexão
coordena a integração: carrega parâmetros e recupera senha se salvar_login
estiver marcado. Após login e approval grava parâmetros; marcado salva senha,
desmarcado remove a do usuário atual. Falha do cofre não impede o login;
falha de escrita JSON cai no tratamento de erro da conexão. Trocar usuário
não remove a credencial anterior. Porta é apenas salva, sem alterar HTTPS.
Há login automático na abertura por main: requer salvar_login, IP, usuário e
senha no cofre e faz nova descoberta antes de HTTP. Falha abre tela manual sem
apagar credencial. A candidatura também usa credenciais salvas por callback
de main, sem leitura do cofre pela GUI. Sem credencial preserva ASSUMIR manual.

## Teste isolado seguro

Usar usuário temporário exclusivo, sem sobrescrever `admin` existente:

```python
import uuid
from config.configuracao import salvar_senha, carregar_senha, remover_senha

usuario_teste = "teste_tc420_" + uuid.uuid4().hex
try:
    assert salvar_senha(usuario_teste, "senha_ficticia")
    assert carregar_senha(usuario_teste) == "senha_ficticia"
finally:
    remover_senha(usuario_teste)
assert carregar_senha(usuario_teste) is None
```

Verificar que JSON permaneceu idêntico e não contém o valor fictício.
Credenciais reais não entram no Git nem na documentação. O JSON atual é exemplo
de teste; revisar endereços e dados locais antes de compartilhar ou versionar
uma futura configuração de produção.

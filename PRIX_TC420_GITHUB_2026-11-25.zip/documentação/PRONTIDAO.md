# Marco de entrega — prontidão para o primeiro teste físico

23/11: EXE Windows x64 gerado e diagnóstico offline aprovado. Regressão de
2.169 testes aprovada; validação em máquina limpa/rede real, instalador,
desinstalador, firewall e log automático permanecem pendentes.
Ver [executável](EXECUTAVEL_WINDOWS.md).

19/11/2026: administrador integrado com backup anterior e testes isolados.
Cadastro persistente, login, acesso protegido ao ensaio e restauração após B2
estão implementados. Validação física desta integração e EXE/instalador continuam
pendentes. Não confundir o autoteste Tk com aceite em equipamento real.
Ver [ADMINISTRADOR_OPERACIONAL.md](ADMINISTRADOR_OPERACIONAL.md).

Retorno mais recente de 18/11: responsável confirmou TCP estável na sessão
apresentada após tolerância 10 s. Frames válidos a até 6,307 s, sem rejeições
ou indisponibilidade no trecho; encerramento operacional confirmado. Evidência
do usuário aprova esse cenário observado, não ensaio prolongado ou escala de
peso. Registros anteriores abaixo são marcos históricos, anteriores a esse retorno.

Revisão posterior de 18/11: leitura TCP física foi relatada funcionando, porém
oscilando no limite de frescor. Tolerância 10 s e confirmação de aviso 2 s
testadas; 2.152 testes e ensaio localhost aprovados. Leitura física inicial e
saída B2 são evidências do usuário, sem medir cadência/compatibilidade completa.
Estabilidade física com a nova tolerância continua pendente; coletar intervalos
válidos/rejeitados adicionados ao diagnóstico.

Estado de 18/11/2026: usuário relatou TCP sem funcionar com ConnectionError.
Diagnóstico melhorado, 2.147 testes e ensaio Tk localhost aprovados. **Não
classificar TCP físico como aprovado**: nova tentativa com contadores TCP LOCAL
é necessária para identificar fase e compatibilidade do protocolo.

Marco posterior: [TCP local funcional](TCP_LOCAL.md), confirmado pelo responsável
como modo sem servidor. 2.145 testes, 155 compilações e ensaio Tk real com
localhost aprovados. Falta validação do frame/unidade/periodicidade na TC420
real. HTTPS e sucessão distribuída mantêm contratos; TCP não participa deles.

Marco mais recente: [integração visual 0.0.1](INTEGRACAO_VISUAL_001.md), autorizada
em 13/11/2026 e precedida de backup verificado. 2.137 testes, 152 compilações,
ensaios Tk reais e diff aprovados. Conexão/ASSUMIR integrados; monitor conserva
aparência. Avisos/bandeja da versão integrada e ciclo A/B completo ainda pedem
conferência no desktop/equipamento, sem interpretar ensaio offline como físico.

Último ajuste de 13/11: corrigido cancelamento de ASSUMIR causado pela parada do
próprio leitor durante a promoção. 2.126 testes, 146 compilações e whitespace
aprovados. Repetição física da terceira alternância na versão atualizada pendente;
esse resultado não aprova instalação nem encerramento global fora do escopo B2.

Resultado mais recente de 13/11/2026: [sucessão recorrente A/B implementada](SUCESSAO_RECORRENTE_AB.md).
Rearmamento só após prova anterior, REGISTER e amostra de outro PRINCIPAL;
monitor manual observa a candidatura. Manual/automático seguem configuração.
2.124 testes, 146 compilações em memória, Tk oculto e whitespace aprovados.
As notas abaixo sobre candidatura sempre desabilitada são anteriores à nova
instrução de alternância recorrente. Aprovação física desta correção pendente.

Estado mais recente, 13/11/2026: [recuperação manual A/B integrada localmente](INTEGRACAO_RECUPERACAO_MANUAL_AB.md).
Opções → Assumir manualmente após rebaixamento, com provas anteriores e prontidão
TCP/UDP/leitura antes de anunciar promoção. Automático segue proibido nesse leitor.
Regressão de 2.116 testes, 145 compilações em memória, Tk oculto e whitespace
aprovados. Validação física desta integração, empacotamento e instalação pendentes.
As notas seguintes conservam os estados anteriores, não substituem este resultado.

Nova etapa de 13/11: [auditoria e protótipo isolado de recuperação manual](RECUPERACAO_MANUAL_APOS_REBAIXAMENTO.md)
concluídos. Modelo separa manual/automático, exige provas e retém partidas incertas;
15 testes específicos e regressão de 2.099 aprovados. Produção não integrada:
A/B rebaixados ainda dependem do procedimento de reconfiguração/reinício de um PC.

Atualização física de 13/11, segundo ensaio: logs agora demonstram a segunda
perda e abandono do B promovido, com encerramento HTTP/TCP/UDP e trabalhadores
restantes vazios. A e B passam a procurar outro servidor. Limitação confirmada:
os leitores de recuperação não oferecem candidatura, inclusive promoção manual
dependente dessa sinalização. Recuperação de B com leitura de outro PRINCIPAL
após essa perda e confirmação final B2 de B não aparecem no trecho enviado.
Registros anteriores abaixo descrevem o estado das evidências antes deste envio.

Decisão de **13/11/2026**: investigação de memória encerrada por enquanto e
fechamento documental 2B.12 aprovado. Implementação das Fases 1 e 2 não autorizada.
Prioridade vigente: [roteiro físico da supervisão](ROTEIRO_FISICO_SUPERVISAO_PRINCIPAL.md),
segunda perda após promoção e saída/reabertura, em janela sem pesagem real.
Complemento de 13/11: nova captura e logs do responsável confirmam faixas
preenchidas na recuperação de A como CLIENTE de B após correção de CONFIG.
Segunda falha do próprio B promovido continua pendente; essa confirmação visual
não aprova integralmente o roteiro de supervisão.
Logs físicos recebidos em 13/11 demonstram promoção, comunicação e saída/reabertura
manual. A segunda falha produziu erros HTTP e recuperação da fonte, sem evidência
de abandono e rebaixamento supervisionado. Esse cenário permanece inconclusivo;
a saída do promovido não trouxe confirmação B2 no trecho enviado. Ver
[registro de execução](REGISTRO_EXECUCAO_FISICA_SUPERVISAO.md).

Atualização de **09/11/2026, etapa 1**: supervisão comum implementada nos caminhos
manual, automático e promovido, com prova B2 antes de rebaixar e troca no Tk após
amostra válida. Regressão de 2.002 testes e Tk offline aprovados. Os testes físicos
1, 2, 3A, 3B e 4 aprovados em 30/10 continuam registrados abaixo; não foram repetidos
nesta revisão. Repetir segunda falha no principal promovido e saída/reabertura.
Não se declara aprovação do Teste físico 5 pelas verificações offline.

Revisão de 28/10/2026. Este é o plano vigente de entrega e substitui a sequência
automática de instrumentação temporal proposta nas etapas anteriores. As seções
antigas de VALIDACAO e HISTORICO conservam o contexto de cada implementação.

## Decisão de escopo

A expansão das revisões temporais fica suspensa após REGISTER. Permanecem as
quatro fontes integradas: preparação, guarda de retentativas, registro de
atividades permanentes dos leitores e controle REGISTER. Isso não representa
cobertura temporal completa dos leitores, recursos ou da aplicação.

CONFIG, SUBSCRIBE, descoberta/CHECKs, recursos/HTTP/arquivos, inventário versionado
e composição temporal não são condições automáticas para o primeiro teste
físico. Os contratos atuais continuam conservadores: pendente ou desconhecido
não pode ser apresentado como sucesso, nem estabilidade de revisão como prova
de liberação global. O executável Windows permanece para depois da validação
física. Esta revisão não declara prontidão de produção.

## Bloqueadores e situação após B3

São três grupos de correção dentro de um único marco de entrega. B1, B2 e B3
estão implementadas no escopo acompanhado e verificadas por testes simulados.
O ensaio visual real do Tk foi aprovado em 30/10/2026; o próximo passo é a
validação física, ainda não realizada. Solicitar saída não
equivale a concluir a parada: timeout, falha ou responsabilidade ativa conservam
a janela. Certificação global continua desconhecida.

| ID | Evidência no código atual | Consequência | Critério finito de aceite |
| --- | --- | --- | --- |
| B1 — encaminhamento disponível em todos os modos; concluída | main cria um SaidaAplicacao por execução e o passa aos caminhos cliente/manual. Todos os monitores recebem callback desse proprietário; promoção mantém o mesmo vínculo. Vínculos substituídos deixam de aceitar pedidos. | SIM encaminha à coordenação B2 nos caminhos montados da aplicação; CANCELAR não solicita parada. | Vínculo antigo não controla outra janela/geração; pedidos durante a mesma tentativa não duplicam a coordenação. Após timeout/falha é permitida nova tentativa explícita. |
| B2 — coordenação real de parada e conclusão; concluída no escopo acompanhado | Proprietário retém leitores, registros de tentativas, contextos de ciclos, partidas e inicializações. Gates são fechados antes da limpeza; workers solicitam parada por ciclo, shutdown/close e observação de término. Retorno isolado da rotina servidor não basta. | Resultado distingue confirmado_operacional, timeout e falha. Somente confirmação operacional permite ao observador Tk concluir a interface; o certificado global permanece falso/desconhecido. | 15 cenários obrigatórios, corridas e falhas cobertos em 40 testes novos. Limpeza pendente não é duplicada por retry; trabalho tardio é recusado ou permanece acompanhado. No servidor, joins abrangem somente trabalhadores iniciados. |
| B3 — interface responsiva e callbacks válidos; concluída no escopo delimitado | CONECTAR e promoções manual/automática executam rede em workers registrados em B2. CicloTk consome fila no Tk, valida janela, geração, operação e vínculo B1. Toda partida passa pela admissão de B2, que também recusa operações invalidadas. | Demora de rede não ocupa o callback Tk; SIM impede novas admissões e retornos antigos não reativam o monitor. Callbacks normais param durante a saída; o observador B2 continua permitindo diagnóstico/retry. | Os 16 cenários solicitados e 10 casos adicionais passaram com eventos controlados, widgets e transporte simulados. Agendamentos são cancelados/invalidados ao destruir; peso verifica root/label; erros Tcl de programação continuam diagnosticáveis. Falta comprovar o comportamento visual no Tk real. |

O caminho TCP direto legado não é iniciado pelo main ou pelo executar do monitor
auditados. Não deve ser ativado no ensaio inicial. Se for incluído no escopo do
produto, sua thread bloqueada em receber e o socket exigem integração adicional
de parada: a B3 retirou o after do worker legado e registra sua thread, mas não
comprova que close isolado resolveu a leitura. Ele permanece fora do ensaio inicial.

Evidências em tests/test_auditoria_encerramento_interface.py: test_20 preserva o
comportamento seguro de um monitor isolado sem callback; test_21 preserva as
respostas SIM/NÃO/CANCELAR; test_25 agora exige ausência de acesso após a parada.
Na B1, test_22 mantém a lacuna de admissão, mas impede destroy; test_23 passa a
recusar conclusão pelo evento legado; test_24 passa a impedir alcançar destroy
sem B2. As expectativas destes três foram adaptadas pela mudança funcional.
Os testes antigos do coordenador experimental conservam seu escopo de protótipo;
B2 e B3 possuem testes separados da integração operacional real com IO simulado.

## Importantes, mas não bloqueadores do ensaio inicial delimitado

| Pendência | Classificação e limite operacional |
| --- | --- |
| Convergência visual após promoção/rebaixamento | Rótulos atualizados e configuração ausente/parcial como `—`. A etapa 1 de 09/11 também integra a supervisão após promoção, com confirmação B2 e amostra válida antes da troca. Testes e Tk offline aprovados; repetir cenários físicos impactados. |
| Informação sobre conexão e dados antigos | Correção em 09/11/2026: principal respeita callback de saúde; cliente conserva callback de frescor. Falha da fonte ou saúde falsa revoga cópia e sinaliza última leitura. Segue os limiares do servidor e não comprova medição física instantânea. No ensaio, comparar perda/retorno com o terminal. |
| Transporte interno HTTP/Requests | Importante: registros comprovam o contrato das operações instrumentadas, sem inventário de todos os sockets internos. Timeout de 5 s por chamada não é prazo global da operação nem certificado de fechamento. B2 acompanha operações e trata pendência; o detalhe formal do transporte não exige instrumentação temporal prévia. Vazamento ou bloqueio reproduzido passa a correção funcional dentro do marco. |
| Arquivos AC1-F1 com associação desconhecida | Importante em falhas: conservar identidade/handle e diagnóstico conforme contrato atual. Close local não regulariza a associação no registro. Não tentar reparação fictícia; falha real de cleanup exige tratamento por B2, enquanto associação formal desconhecida permanece explícita. |
| Ocultação ao escolher NÃO | Importante para uso em segundo plano: atualmente não há withdraw nessa opção. O processo continua executando com a janela visível. Não bloqueia o ensaio com a janela aberta; não anunciar ocultação como implementada. |
| Ausência de eleição por consenso/posse distribuída exclusiva | Limitação de implantação: primeiro ensaio com um principal explicitamente designado, sem partidas simultâneas concorrentes. Recuperação/promoção controlada entra no roteiro; garantia para múltiplos principais concorrentes permanece fora desse ensaio. |
| Compatibilidade física e configuração da TC420 | Ainda não verificada nesta fase: é o objetivo do teste físico, não uma evidência obtida dos testes simulados. Login, approval, dados, W1.1/W1.2 e comportamento de rede precisam de observação no equipamento. |

## Aprimoramentos futuros

| Proposta | Motivo para não bloquear o primeiro ensaio |
| --- | --- |
| Revisões temporais dos demais controles e recursos | Aumentam a detecção de mudanças entre leituras; não substituem parada operacional e cleanup. Os caminhos atuais conservam seus controles e registros. |
| Inventário versionado e composição temporal completa | Necessários para uma futura confirmação consolidada com cobertura demonstrada; o avaliador atual pode continuar desconhecido/negativo sem impedir comunicação física controlada. |
| Certificação formal de todos os transportes, otimização de projeções e compactação de históricos | Fortalecem comprovação e manutenção, sem defeito essencial reproduzido nesta revisão que imponha realizá-los antes do ensaio. |
| Empacotamento .exe e prontidão de produção | Posteriores à validação física; não integram este marco de correções. |

## Critério de passagem para o teste físico

O estado atual é **B1/B2/B3 e ensaio visual concluídos no escopo descrito;
validação física pendente**.
A quantidade de testes aprovados
não altera essa classificação. Encerrar o marco quando os três grupos tiverem
implementação integrada e evidência simulada dos critérios acima, a interface
tiver um ensaio visual de abertura/saída sem o equipamento e as regressões
continuarem aprovadas ou tiverem adaptações funcionais justificadas.

Separar duas afirmações: conclusão operacional dos donos acompanhados e
certificação global da aplicação. A primeira exige parada efetiva no escopo
acompanhado; a segunda continua desconhecida quando faltar cobertura. O novo
fluxo não deve esperar indefinidamente um True que o avaliador atual não emite,
nem contornar uma operação ativa ou um erro de cleanup para fechar normalmente.

Roteiro físico proposto, ainda não executado:

| Caso | Aceite observado no equipamento |
| --- | --- |
| Principal manual e automático | Login/approval reais e leitura consistente com o terminal; conexão e saída responsivas. |
| Um cliente na mesma rede | Descoberta, CONFIG, REGISTER e SUBSCRIBE; peso, tara, estado, unidade e faixa comparados com o principal/terminal. |
| Perda e retorno de comunicação | Remover/restaurar conectividade em ambiente controlado; observar indisponibilidade e recuperação, sem interpretar valor antigo como nova leitura. |
| Promoção/rebaixamento controlados | Uma transição por vez; origem dos dados e configuração corretas; nenhum serviço tardio depois de solicitar saída. |
| Saída durante espera, leitura e promoção | SIM inicia parada; janela responde; responsabilidades acompanhadas concluem ou mostram timeout/falha explícitos. CANCELAR não solicita parada. |
| Reabrir após saída normal | Processo anterior efetivamente terminado e portas locais liberadas, sem processo antigo interferindo na nova execução. |

Registrar resultado, duração, topologia e sintoma por caso, sem credenciais.
Uma falha funcional reproduzida pode reabrir o item correspondente; ausência de
certificação formal sozinha não cria outra etapa obrigatória. O ensaio físico
depende de acesso ao equipamento e acompanhamento do responsável. Nenhuma
conexão à balança, instalação, commit, push ou geração de executável ocorreu
nesta revisão.

## Verificações da revisão original, anteriores a B1/B2

Leitura do código das entradas main/JanelaConexao, monitor Tk, controles de
leitor, descoberta, HTTP, servidor, composição e coordenador experimental;
comparação com pendências documentadas e testes de caracterização. AST confirma
que as duas construções de JanelaTC420 em main não passam ao_fechar, enquanto
o monitor manual passa o callback de JanelaConexao. Busca de referências não
encontrou integração do coordenador experimental em main/interface/rede.

python -B -m unittest discover -s tests -q: **1871 testes simulados aprovados em
11,319 s** nesta revisão. Nenhum teste novo, adaptação de expectativa ou alteração
de código operacional. A revisão não executou Tk real nem equipamento físico.

## Implementação B1 — 28/10/2026

interface/saida_aplicacao.py implementa SaidaAplicacao, sem Tk, threads novas,
revisionamento temporal ou avaliação global. vincular(origem, solicitar_parada)
retorna callback capturando o destino daquele vínculo. Substituir vínculo antes
do pedido revoga o anterior; depois do pedido não se instala um substituto.
Decisão protegida por lock, destino executado fora dele e uma única vez, mesmo
com pedidos concorrentes. Falha do destino conserva intenção e categoria
sanitizada, sem repetir o cleanup automaticamente ou anunciar sucesso.

main.iniciar compartilha um proprietário entre descoberta, fallback manual e
cliente; entradas isoladas aceitam injeção ou criam seu próprio proprietário.
O monitor cliente preserva esse proprietário após promoção; seu callback não
passa a solicitar parada de um servidor novo por consultar uma variável global.
A coordenação do servidor promovido, do leitor rebaixado e demais donos é B2.

No manual, encerrar_aplicacao continua sendo o destino legado, deduplicado pelo
proprietário. verificar_finalizacao interrompe o polling como pendente da B2 e
concluir_encerramento_confirmado recusa destroy para as instâncias construídas
com o proprietário. O evento de retorno da rotina servidor não confirma a
aplicação, nem finalizacao_confirmada fica True neste fluxo. A janela permanece
aberta. B1 não fecha todos os gates nem impede sozinha novas operações de rede;
essa responsabilidade permanece B2, e responsividade/retornos tardios permanecem B3.

Verificação B1: **17 testes novos**, incluindo entradas reais por AST com
transportes/widgets falsos, promoção, CANCELAR/NÃO, concorrência, substituição,
parada manual existente e evento legado. Completa: **1888 testes simulados
aprovados em 14,350 s**; 1871 casos anteriores mantidos, com adaptações
justificadas nos três casos da auditoria, na assinatura opcional e na injeção do
proprietário. Sem Tk real, ensaio visual ou físico, commit, push ou executável.

## Implementação B2 — 28/10/2026 (registro anterior à B3)

SaidaAplicacao passa a coordenar os caminhos montados de main e JanelaConexao.
A infraestrutura fixa o proprietário da execução e conserva as mesmas origens
de recursos. Leitores são retidos no construtor completo; trabalhos síncronos
de inicialização/login/promoção possuem admissão e contagem até o retorno;
partidas de servidor, supervisores e observadores são acompanhadas antes de
start. Nenhuma decisão de propriedade usa modo_atual. Instâncias antigas e o
servidor promovido continuam considerados; o leitor rebaixado entra no mesmo dono.

SIM fecha a admissão de tentativas, retentativas, recursos, HTTP, leitores e
controles existentes. A coordenação e cada tarefa de parada/cleanup usam workers,
sem IO ou join no Tk e sem manter o lock do proprietário durante o destino.
O prazo padrão é 10 s por tentativa, com reavaliação a cada 50 ms no worker.
Close bloqueado continua acompanhado depois do timeout; não é cancelado nem
duplicado. Falhas encerram a tentativa como falha; uma nova solicitação explícita
reavalia as fontes e só repete tarefas falhas comprovadamente terminadas.
Uma partida incerta sem evidência de entrada/término continua pendente.

O sinal de saída da execução é ligado ao contexto do servidor, independente
do clear global. solicitar_parada_ciclo verifica a identidade antes de sinalizar,
interrompe sockets fora dos locks e preserva o registro dos handlers. Um ciclo
antigo não para um novo. Fechamento entre partidas também não provoca join de
uma thread que o gate recusou. O leitor com entrada tardia não reabre seu loop.

Para concluir, a B2 exige término dos donos/partidas acompanhados, ausência de
trabalhos admitidos ativos, retorno e histórico de trabalhadores dos ciclos,
operações HTTP resolvidas, retries observadas, recursos fechados e retenções
conhecidas resolvidas. O evento servidor_encerrado isolado não basta. Associação
formal ausente de um recurso já comprovadamente fechado não exige expandir a
composição; recurso desconhecido, em uso ou com cleanup falho continua pendente.
Handles incertos são limpos depois dos produtores e das limpezas normais, sem
inventar recibo de associação ou ausência no registro.

parada_operacional_confirmada=True permite apenas a conclusão operacional do
escopo acompanhado. encerramento_confirmado e encerramento_global_confirmado
continuam False no proprietário; o avaliador consolidado não foi alterado.
O coordenador experimental exige cobertura global/inventário ainda não obtidos;
sua conclusão não foi conectada artificialmente ao botão. Foram reutilizados
os gates, observadores, provas de recursos e avaliação individual de ciclo já
existentes, com executor operacional próprio no proprietário B1.

O Tk consulta o resultado por after; só a thread da interface chama conclusão
ou aviso. Timeout/falha conserva janela, diagnóstico sanitizado e novo SIM.
Um polling de tentativa antiga não conclui a janela após um retry novo.
Entradas isoladas sem montagem operacional mantêm a compatibilidade B1 e não
ganham confirmação por ausência de registros. Caminho TCP direto legado continua
fora do ensaio inicial. IO de conexão/login/promoção ainda roda no Tk: é B3;
esta etapa moveu somente coordenação, espera e limpeza para fora do loop.

Baseline desta intervenção: **1888 testes simulados aprovados em 13,259 s**.
Nova bateria: **40 aprovados em 2,632 s**. Completa final: **1928 aprovados em
15,058 s**. Casos B1 adaptados ao executor assíncrono/resultado operacional;
uma caracterização de refresh mantém seu escopo sem proibir o novo aviso de
encerramento. Detalhes em VALIDACAO. B3 é o único bloqueador planejado restante,
seguido de ensaio visual, TC420 física e, posteriormente, executável.

## Implementação B3 — 28/10/2026

Conexão e promoções executam rede em workers acompanhados por B2. O Tk coleta
campos, consome resultados pela fila e aplica widgets. Geração, identidade da
operação, proprietário e vínculo B1 protegem a entrega; a admissão de serviço
verifica o mesmo vínculo/token sob o lock de B2 antes da partida. Uma operação
admitida antes de SIM permanece responsabilidade da execução até terminar.

O scheduler centraliza callbacks de atualização, candidatura, contexto,
rebaixamento, resultados e saída. Fechamento cancela IDs e invalida entregas
capturadas; a observação de B2 permanece permitida durante a parada. Peso e
refresh verificam widgets; erros Tcl de programação continuam diagnosticáveis.
Descoberta positiva fecha a conexão e faz a passagem ao cliente depois do
retorno do loop antigo. Contextos de promoção são entregues ao monitor no Tk,
enquanto B2 conserva inclusive os contextos das operações que falharam.

Verificação: baseline **1928 aprovados em 18,995 s**; **26 novos testes** com
eventos controlados, incluindo os 16 cenários solicitados e dez casos adicionais.
Os 1928 casos anteriores permanecem com as adaptações funcionais detalhadas em
VALIDACAO. Não houve expansão das revisões temporais nem mudança dos 10 s de B2.
Regressão completa: **1954 testes simulados aprovados em 15,889 s**, com código
de saída zero do unittest. AST, whitespace, diff e escopo SHA-256 conferidos.

B1/B2/B3 estão concluídas no escopo descrito, sem certificação global. A próxima
atividade é o ensaio visual real do Tk, ainda não realizado; se aprovado, segue
o roteiro físico acima. Nenhum teste físico, commit, push ou .exe nesta correção.
O TCP direto legado continua fora do ensaio inicial; a abertura inicial de main
ainda pode aguardar descoberta/login antes de existir janela.

## Preparação do ensaio visual — 29/10/2026

Foi criado `tests/ensaio_visual_tk.py`, harness offline que usa as classes reais
das duas janelas com rede, HTTP, credenciais, configuração persistente, servidor
e portas substituídos antes da construção da interface. O painel conduz os dez
itens do roteiro, registra ações e copia o checklist. O processo interativo foi
aberto no Windows em 29/10/2026.

Naquele momento, a preparação ainda não alterava a classificação observacional:
o ensaio ficou **em execução, aguardando o checklist humano**. A abertura isolada
não declarava janela responsiva,
resultado visual aprovado ou reabertura comprovada apenas pela inicialização do
processo. A regressão automatizada anterior à abertura permaneceu aprovada com
1954 testes simulados em 27,203 s. Validação física e `.exe` continuam posteriores.

### Resultado parcial e correção do harness — 29/10/2026

O responsável marcou os dez itens, e o log sustenta abertura, responsividade,
atualização, timeout, promoções, CANCELAR/NÃO, invalidação tardia e retry B2.
Porém, o anexo terminou com `RuntimeError: saida_ja_solicitada` ao pedir outra
abertura usando o proprietário já encerrado. Portanto, o item 10 não foi aceito
na primeira coleta e o ensaio visual ainda não libera a validação física.

O defeito estava no condutor do ensaio, não no fluxo operacional: o botão de
abertura ainda chamava `SaidaAplicacao.vincular()` na execução parada. O harness
agora recusa essa reutilização e “Reabrir execução” encerra o conjunto anterior,
retorna do mainloop e constrói novo proprietário, registro e janelas. A versão
corrigida foi aberta para repetir somente fechamento/reabertura. Estado atual:
**9 itens sustentados; item 10 aguardando confirmação sem traceback**.

### Aprovação final do ensaio visual — 30/10/2026

Após corrigir a reabertura e tornar a operação longa determinística, o responsável
repetiu o cenário e informou **“passou”**. O timeout B2 foi observado com o
monitor aberto; o worker controlado terminou três segundos depois; o segundo
pedido explícito pelo X permitiu escolher SIM e concluir; “Reabrir execução”
criou novo proprietário e novas janelas sem traceback ou `TclError`.

A enumeração posterior do Windows encontrou novamente `PRIX TC420 - Conexão` e
`Controle — ensaio visual offline`, coerente com a nova execução ativa. Combinada
ao checklist anterior, a evidência encerra o roteiro em **10 de 10 itens visuais
aprovados no harness offline**. As duas falhas anteriores pertenciam ao condutor:
reutilização indevida do proprietário encerrado e duração de 12 s insuficiente
para garantir timeout após a interação humana. Ambas foram corrigidas antes da
aprovação e não exigiram alteração no código operacional B1/B2/B3.

Estado do marco: **B1, B2, B3 e ensaio visual concluídos no escopo descrito**.
O próximo passo é a validação física com a TC420 e computadores na rede, ainda
não executada. Certificação global e prontidão de produção continuam desconhecidas;
o `.exe` permanece posterior ao teste físico.

## Preparação do Teste físico 1 — PRINCIPAL — 30/10/2026

O ensaio offline foi encerrado e o Windows confirmou ausência de processos
`python`/`pythonw` remanescentes. A configuração local existe e contém IP,
usuário e porta válida; nenhum valor foi exibido ou registrado. `salvar_login`
está desativado, portanto a execução pode exigir autenticação interativa.

Checklist atual: **1 de 8 verificado** — janelas/processos do ensaio offline
encerrados. Permanecem pendentes autorização/disponibilidade da TC420,
conectividade, execução do principal, login/approval, comparação dos dados,
mudança controlada de peso e saída por SIM. `main.py` ainda não foi executado e
nenhum pacote foi enviado à rede nesta preparação.

### Teste físico 1 iniciado — 30/10/2026

O responsável confirmou autorização, disponibilidade e condição não crítica da
TC420. O teste TCP à porta configurada retornou acessível, sem exibir endereço ou
porta. `python -B main.py` foi iniciado pela raiz, PID 11064. Após a descoberta
síncrona inicial, o Windows confirmou a janela real `PRIX TC420 - Conexão`.

Checklist: **4 de 8 verificados** — ensaio offline encerrado, autorização,
conectividade e execução do principal. A etapa está aguardando o responsável
digitar a senha diretamente na janela e clicar CONECTAR. Login, approval, dados
físicos, mudança de peso e saída ainda não foram confirmados.

### Monitor PRINCIPAL aberto — 30/10/2026

O responsável informou que o monitor real abriu com peso e configuração após a
autenticação. Essa observação confirma, no escopo desta execução, que o fluxo de
login/approval chegou ao monitor PRINCIPAL. A enumeração automática disponível
na sessão do Codex não localizou a janela Tk, por isso a evidência registrada é
a observação visual direta do responsável, sem inferir valores não conferidos.

Checklist: **5 de 8 verificados** — limpeza, autorização, conectividade,
execução e abertura autenticada do monitor. Ainda faltam comparar peso, tara,
unidade, estabilidade e faixas W1.1/W1.2 com o terminal físico; observar uma
mudança controlada de peso; e concluir a saída por SIM. A abertura do monitor,
isoladamente, não aprova a coerência metrológica nem o encerramento operacional.

Após esse relato, uma verificação não encontrou o PID inicial nem qualquer
processo `python`/`pythonw`, e a enumeração de janelas também não encontrou o
monitor. Isso não desfaz a abertura observada, mas deixa a continuidade da
execução **não confirmada**. Antes da comparação física, é necessário confirmar
se o monitor ainda está visível; se não estiver, registrar como ele fechou e
repetir a execução sem presumir uma saída normal.

#### Esclarecimento do encerramento

O responsável esclareceu em seguida que havia fechado pessoalmente o monitor.
Portanto, a ausência posterior da janela e dos processos não caracteriza queda
espontânea nem defeito observado. Como não foram registrados nessa execução a
comparação completa com o terminal, a mudança controlada de peso e o contrato da
saída por SIM, esses três itens continuam pendentes e deverão ser repetidos em
uma nova execução do PRINCIPAL.

### Teste físico 1 aprovado — PRINCIPAL — 30/10/2026

O responsável esclareceu posteriormente que já havia executado também os três
itens finais e que todos passaram: os dados do monitor foram comparados com o
terminal físico, uma mudança controlada de peso foi acompanhada e a saída por SIM
concluiu corretamente. Com essa evidência observacional, o checklist do primeiro
ensaio real fica **8 de 8 aprovado**.

O resultado vale para um computador PRINCIPAL, para a TC420 e para as condições
controladas deste ensaio. Ele não comprova ainda descoberta/assinatura em um
segundo computador CLIENTE, recuperação após perda de rede, promoção/rebaixamento,
empacotamento ou prontidão de produção. Próximo marco previsto: Teste físico 2,
adicionando um CLIENTE enquanto o PRINCIPAL estiver em funcionamento.

## Teste físico 2 iniciado — preparação do PC A — 30/10/2026

O roteiro do segundo ensaio foi aceito com dez verificações, limitado à relação
PRINCIPAL/CLIENTE e sem provocar queda de rede ou promoção. Antes da execução,
o PC A não possuía processos `python`/`pythonw` e não havia ocupação local das
portas TCP 42100/42101 nem UDP 42101.

`python -B main.py` foi iniciado pela raiz do projeto, PID 22712. A enumeração
do Windows confirmou a janela real `PRIX TC420 - Conexão`. O checklist permanece
formalmente em **0/10**, pois a preparação conjunta dos dois computadores ainda
não foi confirmada e o item 2 exige que o monitor PRINCIPAL esteja autenticado,
aberto e mostrando leituras reais estáveis. A senha deve ser digitada diretamente
pelo responsável; nenhum dado de autenticação foi coletado.

### Repetição após congelamento na primeira coleta — 30/10/2026

O responsável relatou que, após conectar no modo manual, a primeira execução
começou a receber dados da TC420 e iniciou o servidor, mas congelou durante a
primeira coleta. Quando a reinicialização foi solicitada, o PID 22712 já não
existia e não havia ocupação local nas portas 42100/42101; portanto, nenhum
processo precisou ser terminado à força.

Uma nova execução limpa foi aberta, PID 22708. Após cinco segundos, o processo
estava ativo e responsivo segundo o Windows, e a janela `PRIX TC420 - Monitor`
foi confirmada. A reprodução está **em observação**: ainda é necessário verificar
se a primeira coleta e as atualizações seguintes terminam sem congelamento. O
Teste 2 permanece em **0/10** e o PC B não deve ser iniciado antes dessa confirmação.

### Terceira execução do PC A — 30/10/2026

O responsável confirmou que a segunda execução não travou e solicitou nova
repetição. Quando o reinício foi processado, o PID 22708 já estava encerrado e
as portas operacionais estavam livres, sem necessidade de término forçado.

A terceira execução foi iniciada, PID 22008. Após cinco segundos, o processo
constava ativo e responsivo e o Windows confirmou `PRIX TC420 - Conexão`.
Permanece pendente conectar manualmente e observar se a primeira coleta volta a
congelar. O evento inicial não se repetiu na segunda execução, mas ainda não há
causa determinada. O PC B permanece fora do ensaio e o checklist continua 0/10.

#### Terceira coleta em andamento

Após a entrada direta da credencial, a terceira execução alcançou o monitor. O
console confirmou login bem-sucedido, configuração W1.1/W1.2, leitura HTTP
saudável e atualizações contínuas, sem repetir o congelamento durante a janela
observada. O processo permaneceu responsivo.

O mesmo console registrou a inicialização dos servidores de descoberta e dados,
seguida por conexão, REGISTER e SUBSCRIBE de um cliente. Nenhum endereço foi
copiado para a documentação. O item 2, PRINCIPAL com leitura real estável, fica
sustentado e o checklist avança para **1/10**. Para pontuar os itens do CLIENTE,
falta o responsável confirmar que esse registro pertence ao PC B do ensaio, que
o PC B entrou sem login independente e que ambos os monitores exibem leituras
estáveis. A consulta
local anterior que não encontrou portas abertas fica superada como diagnóstico
do servidor por esta evidência operacional direta, mas sua divergência permanece
registrada.

### Suspensão do PRINCIPAL e CLIENTE sem recuperação — 30/10/2026

O responsável observou que o PC A aparentemente suspendeu após inatividade. Ao
retornar, o PRINCIPAL entrou no fluxo de servidor com saúde ruim; o CLIENTE,
porém, ficou sem atualizar, sem iniciar busca por servidor e sem mostrar a janela
ASSUMIR. O plano de energia local confirma que a suspensão está desativada quando
ligado à tomada, mas configurada para 900 segundos (15 minutos) quando alimentado
por bateria. Nenhuma configuração de energia foi alterada.

A candidatura **não foi desativada para o teste**. No código, um CLIENTE iniciado
normalmente usa `permitir_candidatura=True`. O valor `False` é aplicado apenas ao
leitor criado quando um antigo PRINCIPAL abandona seu papel, para impedir que ele
tente reassumir imediatamente. Assim, a mensagem “Candidatura desabilitada” é
esperada no PC A rebaixado; se aparecer no PC B iniciado como CLIENTE normal,
será um defeito distinto e exigirá o console daquele computador.

Há uma causa compatível no caminho do PC B: após conectar o SUBSCRIBE, o leitor
remove o timeout do socket e bloqueia em `readline()`. Uma suspensão que preserve
a conexão TCP sem entregar dados pode, portanto, impedir que o leitor detecte a
perda, chegue à busca de outro servidor e libere a candidatura. A ocorrência fica
classificada como **bloqueadora do Teste físico 2**, ainda pendente de confirmação
pelo console do PC B. Não foi aplicada correção nesta análise.

#### Causa confirmada no contrato de saúde

O responsável reproduziu fisicamente o defeito: ao suspender o PRINCIPAL com a
aplicação aberta, o CLIENTE repete indefinidamente o último peso e não inicia a
sucessão. A inspeção do fluxo confirma que a validação existente não é uma prova
fim a fim de vitalidade do servidor:

- `ler_tc420()` mede somente a saúde HTTP entre PRINCIPAL e TC420;
- CHECK e descoberta consultam essa saúde apenas quando uma nova busca acontece;
- o handler SUBSCRIBE do PRINCIPAL encerra a conexão se ele próprio observar
  saúde ruim;
- o CLIENTE, depois de inscrito, remove o timeout e bloqueia em `readline()`;
- o pacote contém apenas os dados da medição, sem timestamp, sequência ou prazo;
- a interface consulta continuamente a cópia local, sem invalidá-la por idade.

Durante a suspensão, nenhum código do PRINCIPAL executa para marcar falha ou
fechar SUBSCRIBE. O TCP pode continuar aparentemente estabelecido, portanto o
CLIENTE não recebe EOF/exceção e nunca alcança “Procurando outro servidor” nem
`_aguardar_candidatura()`. No modo manual, ASSUMIR só é aberto depois que essa
candidatura é liberada; logo, a ausência da janela é consequência do mesmo ponto.

Diagnóstico: **ausência de detecção de silêncio/frescor no CLIENTE SUBSCRIBE**.
Os testes simulados existentes cobrem dados, EOF e exceções explícitas, mas não
um servidor que permanece silencioso sem fechar o transporte. O Teste físico 2
permanece bloqueado em 1/10 até uma correção específica e sua repetição física.

### Correção do silêncio SUBSCRIBE implementada — 30/10/2026

O CLIENTE passou a receber por `recv()` com acumulador e prazo monotônico
experimental de seis segundos por mensagem completa e válida. Peso constante com
pacotes regulares continua saudável; silêncio, linha parcial sem conclusão, EOF
ou erro invalidam a comunicação e conduzem ao cleanup, redescoberta e candidatura
existentes. A janela de sucessão de 30 segundos não foi antecipada.

O último peso é conservado apenas como histórico. Enquanto não há pacote válido,
o monitor mostra `SEM COM.`, altera o título para `ÚLTIMA LEITURA` e usa cor de
alerta. Uma nova conexão não restaura saúde antes de receber JSON válido; dados
tardios da conexão abandonada não são consumidos.

Verificações: 101 testes direcionados aprovados; regressão completa com **1.963
testes simulados aprovados em 21,684 s**; `py_compile` e `git diff --check`
aprovados. O Teste físico 2 continua em **1/10**, agora aguardando ensaio específico
PC A → PC B → suspensão controlada → silêncio em até seis segundos → busca e
candidatura. Não realizar promoção efetiva concorrente enquanto A puder despertar.

### Primeira repetição física após a correção — versão do PC B não confirmada

O PRINCIPAL detectou três falhas HTTP, marcou a TC420 não saudável, abandonou o
papel após 25 segundos, encerrou TCP/UDP e iniciou corretamente seu leitor
rebaixado sem candidatura. O CLIENTE continuou exibindo o último estado, mas seu
console não apresentou nenhuma das mensagens obrigatórias da correção: detecção
de silêncio, perda da conexão, busca por servidor ou contagem de candidatura.

Como o PC B é outro computador e os arquivos locais não são distribuídos
automaticamente, o resultado ainda não comprova falha da implementação nova. A
hipótese principal é execução de processo ou cópia anterior de
`lerdadosserver.py`. Antes de nova mudança no algoritmo, é obrigatório comparar
os arquivos do PC B, encerrar todos os processos Python naquele computador e
iniciar novamente pela raiz atualizada. O Teste 2 permanece bloqueado em 1/10.

### Silêncio SUBSCRIBE validado fisicamente — 30/10/2026

Após sincronizar os arquivos do PC B com a versão atual e reiniciar a aplicação,
o responsável repetiu o cenário físico e confirmou que a correção funcionou. A
detecção de silêncio, a distinção visual da última leitura e a entrada no fluxo
de recuperação ocorreram conforme esperado. O comportamento anterior foi
atribuído à divergência de versões entre os computadores, não a uma nova falha da
implementação corrigida.

O bloqueador específico do silêncio SUBSCRIBE fica **aprovado fisicamente no
cenário reproduzido**. Isso não conclui todo o Teste 2 nem certifica promoção
distribuída exclusiva. O checklist formal de PRINCIPAL + CLIENTE será retomado em
uma execução normal com dez itens, começando em 0/10 para produzir um relatório
coeso. Não é necessário suspender novamente o PC A nessa execução; o item de
perda já possui evidência física separada e poderá ser referenciado no fechamento.

### Teste físico 2 aprovado — PRINCIPAL + CLIENTE — 30/10/2026

O responsável concluiu a execução normal com a mesma versão nos dois computadores
e informou aprovação de todos os nove passos executados: PRINCIPAL com peso
estável; descoberta automática do PC B como CLIENTE; CONFIG, REGISTER e SUBSCRIBE;
coerência de peso, tara, unidade, estabilidade e faixas; mudança controlada de
peso; encerramento do CLIENTE por SIM sem afetar o PRINCIPAL; e encerramento final
do PRINCIPAL por SIM.

Somada à evidência física separada da perda de comunicação, `SEM COM.`, `ÚLTIMA
LEITURA` e entrada no fluxo de recuperação/candidatura, a consolidação encerra o
Teste físico 2 em **10/10 aprovado**. Não houve confirmação de promoção efetiva
concorrente nem prova de exclusividade distribuída. Próximo marco planejado:
Teste físico 3, perda e recuperação de comunicação em roteiro próprio, sem
repetir desnecessariamente o defeito já validado.

## Teste físico 3A iniciado — perda de rede somente no CLIENTE — 30/10/2026

O ensaio foi delimitado para interromper apenas a rede do PC B, mantendo PC A e
TC420 ativos. Antes da abertura no PC A, não havia processos Python nem ocupação
local detectada das portas 42100/42101. `python -B main.py` foi iniciado, PID
17300; o Windows confirmou `PRIX TC420 - Monitor` e, cinco segundos depois, o
processo permanecia ativo e responsivo.

O checklist formal está em **0/8** até o responsável confirmar leitura real
estável no PC A e SUBSCRIBE equivalente no PC B. A desconexão da rede do PC B
deve ser manual e autorizada. Não clicar em ASSUMIR; a rede deverá ser restaurada,
se possível, antes da liberação da candidatura. Nenhuma rede ou configuração foi
alterada pelo Codex.

O responsável confirmou em seguida que PC A e PC B estavam conectados. Os itens
1 e 2 ficam registrados como atendidos no limite dessa confirmação: PRINCIPAL e
CLIENTE em execução antes da falha. Checklist: **2/8**. A comparação final dos
campos continua pertencendo ao item 8, após a recuperação.

### Teste físico 3A aprovado — 8/8 — 30/10/2026

O responsável executou a interrupção exclusiva da rede do PC B e informou que
todos os itens passaram. O CLIENTE detectou a perda, apresentou `SEM COM.` e
`ÚLTIMA LEITURA`, iniciou busca e participou da sucessão sem promoção efetiva. Ao
restabelecer a rede, reencontrou o mesmo PRINCIPAL, cancelou a candidatura,
restabeleceu a recepção e voltou a apresentar valores coerentes na mesma janela.

Resultado: **Teste 3A aprovado em 8/8**. PC A e TC420 permaneceram ativos e não
houve clique em ASSUMIR. O Teste físico 3 completo ainda não está encerrado: falta
o cenário separado de perda de comunicação entre PC A e TC420, sem misturá-lo com
a perda de rede do CLIENTE.

## Teste físico 3B iniciado — PRINCIPAL ↔ TC420 — 30/10/2026

A execução anterior do PC A já estava encerrada. A preparação confirmou zero
processos Python e nenhuma ocupação local das portas 42100/42101. Uma execução
limpa de `python -B main.py` foi iniciada, PID 24516, e o Windows confirmou a
janela `PRIX TC420 - Conexão`.

Checklist: **0/8**, aguardando autenticação direta, monitor PRINCIPAL saudável e
conexão do PC B como CLIENTE. A interrupção posterior deve atingir somente o
acesso do PC A à TC420, por método manual autorizado e reversível. O Codex não
alterará rede ou firewall e não confirmará ASSUMIR.

### Teste físico 3B aprovado — 8/8 — 30/10/2026

O responsável marcou como aprovadas as oito verificações: início saudável do PC
A; PC B como CLIENTE; interrupção exclusiva do acesso A/TC420; três falhas HTTP e
saúde ruim; reação do CLIENTE com leitura antiga; abandono do PRINCIPAL após o
prazo; sucessão observada sem confirmar promoção; e restauração segura do cenário.

Resultado: **Teste 3B aprovado em 8/8**. Com o Teste 3A também aprovado, a etapa
física 3 — perda e recuperação — está concluída nos dois cenários separados. A
consulta posterior encontrou o PID 24516 ainda ativo e responsivo; o ensaio foi
encerrado em estado restaurado, não com comprovação de processo fechado. O Teste
4 de promoção/rebaixamento permanece pendente e não foi iniciado automaticamente.

### Teste físico 4 aprovado — promoção e rebaixamento — 30/10/2026

O responsável informou aprovação das dez verificações da transição controlada.
O PC A iniciou como PRINCIPAL e o PC B como CLIENTE; o acesso do PC A à TC420
foi interrompido isoladamente; o servidor antigo abandonou o papel; e a
candidatura do PC B foi liberada antes da promoção. O PC B assumiu como novo
PRINCIPAL, passou a fornecer a leitura real e o PC A encontrou esse servidor e
permaneceu rebaixado como CLIENTE, sem iniciar outro servidor.

Os dois monitores apresentaram valores coerentes após a troca e o encerramento
foi solicitado de forma controlada. A verificação local posterior confirmou que
o PID 24516 terminou, não havia processos `python`/`pythonw` ativos nem janela
PRIX TC420 aberta. Resultado: **Teste físico 4 aprovado em 10/10**.

Essa aprovação comprova a transição observada neste ensaio autorizado; não cria
uma garantia geral de exclusividade distribuída diante de partições ou promoções
concorrentes. O próximo marco é o Teste físico 5, encerramento e reabertura entre
os computadores. Nenhuma mudança de código foi realizada nesta etapa.

## Teste físico 5 iniciado — encerramento e reabertura — 30/10/2026

O estado inicial local do PC A foi conferido antes da reabertura: não havia
processos `python`/`pythonw`, listener TCP na porta 42100 nem endpoint UDP na
porta 42101. Uma nova execução de `python -B main.py` foi iniciada com PID 18220
e o Windows confirmou a janela real `PRIX TC420 - Monitor`.

O checklist formal permanece em **0/10** até o responsável confirmar a rede dos
três participantes, o estado equivalente do PC B e a leitura real autenticada no
novo monitor do PC A. Nenhuma configuração de rede foi alterada pelo Codex.

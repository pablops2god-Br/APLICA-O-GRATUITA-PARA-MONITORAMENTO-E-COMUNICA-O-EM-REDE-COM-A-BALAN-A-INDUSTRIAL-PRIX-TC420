# Etapa 2B.7 — consultas e predicados agregados experimentais

Continuidade em [2B.8 — fragmentação e escrita](FRAGMENTACAO_ESCRITA_2B8.md):
caudas de escrita, capacidade auxiliar após fusão e ganho misto pareado medidos.
As versões experimentais desta etapa foram preservadas para comparação.

12/11/2026. Sem alterações no código operacional, B2, supervisão, protocolos,
credenciais ou Tk. Nenhum protótipo integrado. Nenhuma rede real/TC420 nesta etapa.

## Implementação isolada

`prototipos/consultas_intervalos.py` deriva do protótipo 2B.6 e conserva o escritor,
índice fraco, validação de identidade e tabela forte. Muda somente consultas:

1. Mescla em ordem as entradas fortes e as faixas já ordenadas. Cada faixa é
   percorrida em lote, construindo diretamente os dicionários públicos. Não há
   busca binária, weak lookup ou objeto de entrada virtual por ID do histórico.
2. Avalia sockets encerrados sobre as entradas fortes e a prova de cobertura dos
   IDs. Faixas representam somente sem_recurso comprovado, sem erro ou pendência.
3. `encerramento_confirmado` consulta gate, threads, erros e predicado de sockets,
   sem materializar os diagnósticos. O formato completo de obter_situacao continua
   o mesmo, incluindo ordem e falhas de handler.

O escritor admite IDs contíguos crescentes, substitui entradas fortes no mesmo
lugar e nunca reinsere uma entrada terminal compactada. Assim, a ordem de
inserção das entradas fortes e a ordem das faixas permitem a mescla sequencial,
mesmo quando a resolução ocorre fora de ordem.

## Equivalência da prova de encerramento

Por construção, os IDs são uma partição disjunta: entradas fortes F e faixas R.
Toda entrada de R satisfaz o predicado operacional de sockets encerrados. Logo,
avaliar esse predicado sobre todos os IDs equivale a avaliá-lo sobre F, desde que
a cobertura seja íntegra. O protótipo verifica ainda:

`len(F) + soma(tamanho das faixas) == total de IDs admitidos`.

Uma lacuna interna induzida no teste retorna False, nunca confirmação por
ausência. Disjunção e validade dos estados das faixas continuam sendo invariantes
do escritor, não deduções da coleta de lixo. GC só remove identidades fracas.
Sem publicação de resolução, a entrada e seu token continuam fortes.

A fórmula final permanece gate fechado, nenhuma thread viva, nenhum erro de
limpeza e sockets resolvidos. O ControleCicloServidor continua acrescentando suas
provas de coordenador/publicação/identidade; esses critérios não foram alterados.
Não há contador de sucesso que substitua responsabilidades nem remoção de threads.

## Medição de memória, espera e retenção do lock

Harness: `python -B tests/medir_consultas_intervalos.py --saida resultado.json`.
Compara implementação atual, 2B.6 e 2B.7 no mesmo ambiente e com 50.000 reservas
por execução. São 18 cenários: uniforme sem tokens, um token, todos os tokens;
alternada sem_recurso/incerta; resolução inversa adversarial; resolução aleatória
com tokens externos preservados. Alternadas/adversariais mantêm 25 mil incertezas.

As cargas inversa/aleatória reservam tudo antes de resolver. A inversa resolve
primeiro IDs alternados em ordem decrescente, depois os restantes; a aleatória
usa semente fixa 270. Esses padrões pressionam inserção/fusão em lista de faixas;
o caso final fragmentado conserva 25 mil faixas e 25 mil entradas fortes.

Tracemalloc mede retenção após GC, pico de carga e pico absoluto da consulta.
O lock instrumentado separa tempo para acquire e tempo de posse. Instrumentação
do lock é instalada somente após construir/medir a carga, evitando guardar
dezenas de milhares de registros de timing na memória atribuída ao histórico.

Depois de desligar tracemalloc, três repetições de consulta completa e três de
predicado agregado registram mediana total, mediana de espera, mediana e máximo
de retenção. Sem concorrência intencional nesses perfis; espera quase nula não
representa tempo de aquisição sob carga operacional. Tempos de liberação/registro
de timing e destruição dos resultados também afetam duração total.

Um ensaio adicional de contenção usa dois threads: uma consulta pública completa
e um acesso concorrente ao mesmo lock. Eventos garantem que a consulta possui o
lock antes de liberar a materialização. A espera observada inclui sincronização
e escalonamento; não representa latência garantida do servidor. A mesma consulta
pública é utilizada nos três backends. Não existe I/O externo durante a medição.

Cada cenário tem uma execução instrumentada e três repetições não instrumentadas;
não é experimento estatístico amplo. Tracemalloc não é RSS. Digests de retratos
completos têm de coincidir entre os três backends para cada carga. A serialização
do digest é posterior à captura do pico de consulta.

## Resultados finais — 18 medições concluídas

Fonte: [MEDICOES_CONSULTAS_INTERVALOS_2B7.json](MEDICOES_CONSULTAS_INTERVALOS_2B7.json),
concluido=True, CPython 3.13.15/win32. Os digests de cada trio de backends
coincidiram nas seis cargas. MB decimais; ms para posse do lock sem tracemalloc.

| Carga / tokens externos | Bytes retidos atual | 2B.6 | 2B.7 |
| --- | ---: | ---: | ---: |
| Uniforme / nenhum | 13.817.088 | 2.464 | 2.448 |
| Uniforme / um | 13.813.968 | 2.640 | 2.624 |
| Uniforme / todos | 14.258.248 | 13.859.784 | 13.859.760 |
| Alternada / nenhum | 15.013.920 | 10.923.584 | 10.923.568 |
| Inversa / nenhum | 15.013.880 | 13.544.816 | 13.544.800 |
| Aleatória / todos | 15.458.224 | 18.589.128 | 18.589.112 |

O escritor não foi alterado: a otimização conserva essencialmente a memória da
2B.6. Agora os casos com tokens externos são comparados mantendo as mesmas
referências também na atual. No caso aleatório/todos, os intervalos retiveram
cerca de 20,3% mais memória que a atual. Ordem de alocação e capacidade remanescente
de dicionários também podem influir; não atribuir tudo apenas às tuplas de faixa.

| Consulta completa: retenção mediana do lock | Atual | 2B.6 | 2B.7 |
| --- | ---: | ---: | ---: |
| Uniforme / nenhum | 38,779 ms | 720,418 ms | 29,629 ms |
| Uniforme / um | 33,185 ms | 638,494 ms | 24,537 ms |
| Uniforme / todos | 40,527 ms | 483,990 ms | 25,092 ms |
| Alternada / nenhum | 29,182 ms | 331,749 ms | 48,266 ms |
| Inversa / nenhum | 30,942 ms | 325,473 ms | 55,968 ms |
| Aleatória / todos | 36,768 ms | 466,122 ms | 64,575 ms |

Medianas de três repetições sem tracing. Espera mediana de acquire da consulta
entre cerca de 1,3 e 3,5 microssegundos nos 18 cenários, sem concorrência nesses
perfis; não representa latência sob tráfego. A 2B.7 melhora muito contra 2B.6,
mas a consulta fragmentada ainda fica pior que a atual.

| Predicado agregado: retenção mediana do lock | Atual | 2B.6 | 2B.7 |
| --- | ---: | ---: | ---: |
| Uniforme / nenhum | 41,280 ms | 709,006 ms | 0,0037 ms |
| Alternada / nenhum | 35,178 ms | 327,116 ms | 1,919 ms |
| Inversa / nenhum | 34,238 ms | 300,708 ms | 3,232 ms |
| Aleatória / todos | 34,941 ms | 320,286 ms | 5,688 ms |

O agregado elimina materialização sem mudar a resposta. Valores muito pequenos
são sensíveis a ruído; não são garantias operacionais. Fragmentação mantém O(r).
Os casos incertos retornam False, nunca encerramento aprovado.

| Consulta com tracing / pico absoluto | Atual | 2B.6 | 2B.7 |
| --- | --- | --- | --- |
| Uniforme / nenhum | 0,115 s / 27,89 MB | 3,141 s / 15,67 MB | 0,200 s / 15,67 MB |
| Alternada / nenhum | 0,105 s / 29,09 MB | 1,373 s / 25,80 MB | 0,264 s / 25,80 MB |
| Aleatória / todos | 0,115 s / 29,53 MB | 1,371 s / 32,67 MB | 0,283 s / 33,46 MB |

Tracemalloc muda o custo relativo: uniforme otimizada foi mais rápida que a atual
nas medianas sem tracing, mas mais lenta na execução instrumentada. Não misturar
colunas para calcular ganho universal. O pico também não melhora em todos os
casos; com tokens preservados, materializar novos inteiros dos IDs pode elevar
alocações temporárias apesar de o diagnóstico ser igual em conteúdo.

Na contenção controlada, espera do concorrente, atual/2B.6/2B.7: uniforme sem
tokens **44,604 / 677,287 / 30,531 ms**; alternada **41,362 / 321,481 / 56,908 ms**;
aleatória/todos **41,737 / 309,264 / 62,938 ms**. Uma execução sincronizada por
cenário, não percentis nem máximos em produção.

Carga instrumentada aleatória/todos: 3,67 s atual, 6,29 s 2B.6 e 5,44 s 2B.7.
Como o escritor é o mesmo nos protótipos, essa diferença entre eles não comprova
otimização de escrita. Não foi estabelecido percentual mínimo de ganho.

## Verificações de segurança e compatibilidade

`tests/test_consultas_intervalos.py` reaplica oito propriedades da 2B.6 no novo
backend e acrescenta quatro casos: predicado sem histórico; lacuna induzida;
mistura fora de ordem com erro de handler; fragmentação inversa e fusão final.
Continuam testados tokens fabricados, GC sem perda de pendência, publicação tardia,
close bloqueado/concor­rente e observação de diagnóstico durante produtores/GC.

`python -B tests/medir_consultas_intervalos.py --contratos` aplica 116 testes
existentes com substituição temporária do registro: identidade, sockets, handlers,
B2 e supervisão. O patch é removido ao fim do processo. Nenhuma integração é
feita na montagem operacional.

Resultados: 12 cenários do backend aprovados (oito propriedades reaplicadas e
quatro casos adicionais). Bateria experimental: **116 testes em 3,431 s, OK**.
Regressão normal: **2.069 testes em 29,274 s, OK**. **135 arquivos Python
compilados em memória**. Sem teste físico, localhost ou execução prolongada.

## Limitações e decisão

O diagnóstico completo continua O(n), retorna todos os dicionários e segura o
lock enquanto os constrói. Avaliação agregada é O(threads + fortes + faixas),
com saída antecipada quando encontra pendência; não é O(1) no caso fragmentado.
Inserções no escritor 2B.6 permanecem O(r) em listas adversariais. A otimização
da leitura não resolve custo de escrita nem retenção de todos os tokens externos.

Sockets fechados e threads encerradas continuam na tabela forte/lista original.
O ganho uniforme não pode ser extrapolado para o perfil real da hora, que continha
muitos desses objetos. Não foram alteradas a compactação de ciclos ou sua
incompatibilidade de parada tardia. Introspecção do armazenamento privado continua
diferente de um dict, como na 2B.6.

Nenhuma supressão de diagnóstico, revogação de token, prazo ou limite arbitrário
foi introduzido. Qualquer integração ainda exige avaliação dos resultados,
fragmentação/escrita e cenário misto representativo; regressão física permanece
pendente. Melhor desempenho em microbenchmark não equivale a aprovação operacional.

2B.7 concluída no escopo experimental. Não integrar automaticamente: o cenário
aleatório/todos perdeu em memória e consulta contra a atual; o ensaio real misto
de sockets/threads não foi repetido com essa arquitetura. Próxima investigação:
escritor/fragmentação e seleção de representação em distribuições adversariais,
sem revogar tokens ou reduzir diagnósticos. Nenhuma política adaptativa foi ativada.

# Etapa 2B.3 — observação de duração e recursos

## Estado atualizado: ensaio de uma hora concluído

Consolidação de 12/11/2026 em
[RESULTADO_2B3_UMA_HORA.md](RESULTADO_2B3_UMA_HORA.md): comunicação, B2 e partida/
parada do segundo ciclo aprovadas no escopo local. Memória cresceu com histórico;
não há conclusão de estabilidade prolongada. Os registros de execução em
andamento abaixo são históricos e foram superados pelo status final concluido.
Nenhuma nova execução de várias horas ou regressão física foi iniciada.

## Ensaio de uma hora iniciado — 12/11/2026

Conferência intermediária posterior ao lançamento: PID 17416 ainda ativo,
status executando, resultado final ausente e stderr vazio. Última amostra
consultada em 930,419 s: 4.028 entradas, 460 sem_recurso, 3.568 threads retidas
(4 vivas), 3.567 sockets referenciados (3 abertos), zero erros de limpeza,
9.420.417 bytes Python rastreados, working set 59.904.000 bytes e private bytes
53.747.712. Valores parciais, sem inferência de estabilidade ou aprovação.

Análise final pendente: comparar início, meio e fim; distinguir fases de carga
e ociosidade ao calcular taxas; conferir B2, recursos pendentes e reabertura.
Working set é a métrica residente fornecida pela API Windows usada no harness;
não confundir com alocações rastreadas ou memória privada. Nenhuma intervenção
no processo foi realizada durante esta conferência.

Pedido: ampliar inicialmente para uma hora, com as mesmas medições, sem nova
compactação e sem TC420. Iniciado em processo separado às 17:35:44 -03:00,
PID 17416, duração programada 3.600 s, término previsto próximo de 18:36.
**Situação na última verificação desta solicitação: executando**, amostras
iniciais presentes, processo vivo e stderr vazio. Não é resultado aprovado.

Artefatos desta execução:

- `ENSAIO_LOCALHOST_2B3_1H_PROCESSO.json`: PID, início e caminhos dos logs locais.
- `ENSAIO_LOCALHOST_2B3_1H_STATUS.json`: executando, concluido ou falhou.
- `ENSAIO_LOCALHOST_2B3_1H.jsonl`: fotografias incrementais, aproximadamente 10 s.
- `ENSAIO_LOCALHOST_2B3_1H.json`: resultado final, criado somente após sucesso.

O status é atualizado pelo harness; um processo morto externamente pode deixar
status executando desatualizado, devendo ser conferido contra PID/progresso.
Conclusões de memória, B2 e reabertura da hora inteira dependem de analisar o
artefato final. Arquivos em atualização não são uma medição final consolidada.

Mudanças exclusivamente no harness: progresso JSONL, status explícito e tentativa
real de novo ciclo no mesmo ControleCicloServidor após a B2. Verifica CONFIG,
CHECK e UDP no segundo ciclo, nova parada B2, identidade de ciclo distinta e
confirmação histórica do ciclo original. O tempo de parada do primeiro ciclo é
capturado antes da reabertura; as contagens originais de carga não incluem o
tráfego adicional. Coletas principais mantêm os campos e cadência do piloto.
O próprio buffer de amostras cresce e contribui para as alocações rastreadas.

Antes do lançamento, execução de 30 s aprovou o harness ampliado:
`ENSAIO_2B3_PREPARACAO_1H.json`, JSONL e STATUS correspondentes. B2 e reabertura
confirmadas, segundo ciclo ID 2 e sockets encerrados. Sintaxe do harness
verificada. Não foi repetida a suíte completa nesta solicitação; os 2.043 testes
descritos no piloto abaixo pertencem à execução anterior.

Não foi iniciado automaticamente ensaio adicional de várias horas: depende do
resultado da primeira hora e da definição da próxima janela controlada.
Regressão física e nova compactação continuam pendentes/não iniciadas.

## Escopo de 12/11/2026

Primeiro ensaio controlado de dois minutos, com servidor TCP/UDP operacional e
sockets reais exclusivamente em 127.0.0.1, portas efêmeras. Nenhum arquivo de
código operacional foi alterado. Não acessa configuração local, credenciais ou
TC420. `ler_tc420` é substituído somente no processo de ensaio por espera local,
com saúde sintética; não há HTTP/HTTPS. Coordenador `iniciar_servidor`, registro,
handlers, controle de ciclo e SaidaAplicacao são os módulos reais.

Harness explícito, não incluído na descoberta unittest:

```
python -B tests/ensaio_recursos_localhost.py --duracao 120 --saida resultado.json
```

Alterna 15 s com CONFIG, REGISTER, CHECK, SUBSCRIBE e UDP e 15 s sem novas
conexões. Clientes validam respostas e desconectam após uma leitura. REGISTER
reutiliza um nome, evitando confundir crescimento do cadastro de nomes com o
histórico operacional. SUBSCRIBE recebe só uma amostra, não simula cliente lento
de longa duração. Não é o LeitorDadosServidor completo nem uma eleição real.

A cada aproximadamente dez segundos, coleta GC, tracemalloc, quantidade de
entradas por estado, threads retidas/vivas e sockets referenciados/abertos pelo
registro. No Windows também mede working set, private bytes e handles do processo
pelas APIs do sistema. Referência a socket fechado não é socket aberto; quantidade
de handles do processo não é contagem de sockets. Sockets abertos são os recursos
conhecidos pelo registro com fileno diferente de -1, não um inventário global.

As próprias amostras, contadores e infraestrutura do harness ocupam memória.
Consulta fileno dos sockets locais é feita durante a fotografia do registro.
Não há comparação antes/depois de uma nova otimização, nem extrapolação linear
segura para semanas. A regressão automatizada foi executada em processo separado
durante parte do ensaio, podendo influenciar tempos e carga do computador.

## Resultado do piloto executado

Python 3.13.15, win32. Dados brutos:
[ENSAIO_LOCALHOST_2B3_2026-11-12.json](ENSAIO_LOCALHOST_2B3_2026-11-12.json).
Duração de carga/ociosidade: aproximadamente 120,5 s; fim da coleta após B2:
121,1 s. 461 conexões TCP (116 CONFIG, 115 REGISTER, 115 CHECK, 115 SUBSCRIBE)
e 115 consultas UDP com respostas validadas. Nenhum erro de limpeza.

| Indicador | Primeira amostra | Antes da B2 | Após B2 |
| --- | ---: | ---: | ---: |
| Entradas | 4 | 524 | 524 |
| Reservas sem_recurso | 0 | 60 | 61 |
| Threads retidas no registro | 4 | 464 | 464 |
| Threads vivas no registro | 4 | 3 | 0 |
| Sockets referenciados | 3 | 463 | 463 |
| Sockets abertos no registro | 3 | 2 | 0 |
| Threads do processo | 6 | 5 | 1 |
| Alocações Python rastreadas, bytes | 49.159 | 1.292.973 | 1.293.854 |
| Working set, bytes | 39.014.400 | 41.656.320 | 41.934.848 |
| Private bytes | 32.358.400 | 35.065.856 | 35.012.608 |
| Handles do processo | 138 | 137 | 125 |

Fotos são instantâneas concorrentes; a primeira ainda captura o handler CONFIG
de prontidão. Na fase ociosa de 110,472 s a 120,497 s, sem novas conexões,
entradas passaram de 514 para 524 e sem_recurso de 50 para 60; threads retidas
permaneceram 464 e sockets abertos 2. Isso demonstra acúmulo de reservas mesmo
sem conexões novas. Não demonstra vazamento de sockets.

B2 concluiu em aproximadamente 0,636 s com estado confirmado_operacional,
pendências/erros vazios e avaliação do ciclo confirmado. Certificação global
permaneceu False conforme contrato. Os 463 sockets referenciados após B2 estavam
fechados; as 464 threads retidas estavam encerradas. O crescimento observado
inclui objetos de thread e sockets fechados, não só reservas sem recurso.

Regressão executada: **2.043 testes aprovados em 21,188 s**. Compilação em memória
de **125 arquivos Python** e `git diff --check` aprovados. Nenhum teste novo foi
adicionado à descoberta automática; o novo arquivo é um harness explícito.

## Continuidade e limites de conclusão

Este ensaio curto inaugura a 2B.3 e verifica o instrumento; não conclui validação
prolongada. Ensaio de horas/dias, clientes persistentes/lentos e múltiplos ciclos
continuam necessários para avaliar relevância operacional do crescimento.
Não introduzir nova compactação com base apenas neste piloto.

Regressão física continua pendente: segunda perda após promoção e encerramento/
reabertura com TC420. O relato de encerramento aprovado em 11/11 é uma evidência
anterior distinta, não execução desses cenários nesta etapa.

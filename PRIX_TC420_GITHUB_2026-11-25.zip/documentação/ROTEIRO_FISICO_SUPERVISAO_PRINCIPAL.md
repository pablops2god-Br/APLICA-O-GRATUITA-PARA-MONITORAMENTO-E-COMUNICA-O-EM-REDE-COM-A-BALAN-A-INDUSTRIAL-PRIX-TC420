# Validação física da supervisão comum — roteiro controlado

13/11/2026. Roteiro preparado, **ainda não executado/aprovado**. Investigações de
memória encerradas por decisão do responsável; Fases 1 e 2 não autorizadas.
Objetivo: segunda perda após promoção e saída/reabertura, sem operação de pesagem
em andamento. Nenhuma alteração operacional proposta neste roteiro.

## Preparação e evidências

Usar janela de teste e equipamento disponíveis ao responsável. Identificar PCs
como A (principal inicial), B (cliente que será promovido) e demais CLIENTES.
Registrar versão/commit e existência de alterações locais, horário, papéis e
tipo exato de falha aplicada. Não registrar credenciais/tokens. Não modificar
vários enlaces ao mesmo tempo: distinguir perda do PC principal de falha HTTPS
da TC420. Registrar logs de A/B e de pelo menos um outro cliente, quando houver.

## Sequência de execução manual

| Passo | Ação controlada | Critério observável |
| --- | --- | --- |
| 1 | Iniciar A como PRINCIPAL e conectar B e os demais clientes | Peso/estado/tara coerentes; dados recentes; identificar fonte e papéis |
| 2 | Tornar A indisponível, anotando o método; preferir fechamento controlado fora de operação real | B perde comunicação, leitura antiga não aparece como recente; registrar candidatura e promoção de B |
| 3 | Confirmar B como PRINCIPAL com nova leitura válida antes de outra intervenção | Clientes recebem dados de B; promoção não é apenas botão/etiqueta de papel |
| 4 | Provocar segunda falha no PRINCIPAL promovido, distinguindo-a da primeira | Para exercitar supervisão local, manter B/aplicação em execução e interromper de forma controlada sua fonte HTTPS; não matar o processo B |
| 5 | Aguardar abandono e encerramento do ciclo de B | Registrar fim HTTP/TCP/UDP, retorno do coordenador e confirmação positiva do ciclo; pendência/erro não pode ser tratado como encerramento |
| 6 | Depois da confirmação, restabelecer fonte e disponibilizar outro PRINCIPAL pelo fluxo normal, sem forçar duplicidade | Monitor de B permanece o mesmo, reconecta como CLIENTE e só apresenta leitura recente após nova amostra válida |
| 7 | Solicitar saída de B pelo monitor; repetir nos demais PCs de teste | B2 confirma parada operacional, sem pendências/erros; janela encerra; não considerar apenas sumiço da janela como prova |
| 8 | Reabrir pelo fluxo normal e encerrar novamente | Descoberta/papel corretos, leitura recente, sem erro de porta ocupada atribuível ao ensaio; nova confirmação de saída |

Para o passo 4, escolher manualmente um método que afete apenas a fonte pretendida
e preserve observação da aplicação. Este documento não autoriza alterar firewall,
rede industrial ou interromper pesagem real automaticamente. Reverter exatamente
a intervenção aplicada ao terminar ou interromper o ensaio.

## Interpretação correta da recuperação

O leitor criado pela supervisão após encerramento é iniciado **sem candidatura**.
Não exigir que B se promova novamente automaticamente nesse caminho; verificar
o comportamento efetivamente implementado. Outros clientes podem disputar
candidatura pelo mecanismo existente. Retorno do coordenador isolado não autoriza
nova leitura/recuperação local: precisa de confirmação do contexto original.

Se não existir outro principal após a falha, B pode continuar aguardando como
leitor; isso não é falha de supervisão por si só. Restaurar uma fonte disponível
é necessário para verificar reconexão e amostra nova. Falha ao criar o leitor
não tem retry automático na implementação atual e deve ser registrada como tal.

Não existe garantia implementada de exclusividade distribuída por consenso.
O ensaio não pode certificar essa propriedade. Interromper e diagnosticar se
houver duplicidade inesperada de principal, sem continuar aplicando falhas.

## Registro de aprovação

Para cada passo, preencher: executado/não executado; horário; esperado/observado;
PC e ciclo, se disponíveis; log correspondente; aprovado/reprovado/inconclusivo.
Guardar a última amostra válida e evidência de frescor antes/depois das perdas.
Uma pendência sem prova deixa o passo inconclusivo ou reprovado conforme observado,
nunca aprovado por timeout ou por não haver thread visível na interface.

Separar log de encerramento operacional da inspeção externa do processo/recursos.
Mensagem de cobertura global desconhecida continua sendo limitação do certificado,
não erro automático. Alegar ausência global de threads/sockets exige inspeção
adicional; B2 comprova apenas o escopo acompanhado. Reabertura bem-sucedida é
evidência complementar, não inventário completo de sockets.

O relato aprovado de fechamento em 11/11 permanece válido para seu cenário,
mas não substitui a segunda perda após promoção. Os resultados antigos de
PRONTIDAO não são reexecuções das alterações recentes.

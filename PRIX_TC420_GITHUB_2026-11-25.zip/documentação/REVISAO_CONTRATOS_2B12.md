# Etapa 2B.12 — contrato proposto para aprovação

13/11/2026. Revisão documental da alternativa B. **Texto fechado para revisão,
não aprovado para implementação.** Fase 1 e Fase 2 são autorizações distintas;
nenhuma foi concedida nesta etapa. Esta revisão detalha a 2B.11; não muda código.

## 1. Consultas e tipos definidos na proposta

Contrato lógico `historico_trabalhadores/1`. IDs de trabalhador e reserva são
inteiros positivos, monotônicos e não reutilizados dentro do ciclo. ID de ciclo
é o original do controle, válido no escopo da execução do processo. Não equivale
a ident/native_id do SO nem identifica registros de outra execução.

Todas as consultas são somente leitura, sem compactação ou observação que faça
join/close. Retratos de metadados são cópias imutáveis, sem exceção, traceback,
socket ou Thread. Ordenação por admissão/ID crescente, nunca ordem de conclusão.
Nenhuma consulta expira diagnósticos ou fabrica sucesso para ID desconhecido.

| Consulta proposta | Resposta |
| --- | --- |
| obter_trabalhadores_operacionais() | Tupla de vínculos (ciclo_id, trabalhador_id, thread original), ordem de admissão. Contêiner imutável; Thread continua mutável e pode ser retido pelo chamador |
| consultar_trabalhador(ciclo_id, trabalhador_id) | Envelope com versao, ciclo_id, trabalhador_id, encontrado: bool, trabalhador: retrato ou None |
| obter_historico_trabalhadores(ciclo_id) | Envelope com versao, ciclo_id, ciclo_conhecido: bool e trabalhadores: tupla de retratos. Inclui pendentes; ciclo desconhecido não equivale a ciclo vazio confirmado |
| avaliar_responsabilidades(ciclo_id) | versao, ciclo_id, estado: desconhecido/pendente/confirmado, encerramento_confirmado: None/False/True, pendencias e erros: tuplas de categorias |

Retrato de trabalhador, com todos os campos presentes:

| Campo | Tipo / domínio |
| --- | --- |
| ciclo_id, trabalhador_id | int positivo |
| nome | str copiada, último nome publicado pelo protocolo; não promessa de acompanhar mutações do Thread externo após resolução |
| partida | admitida/start_pendente/start_observado/start_incerto/execucao_comprovada/nao_executada_comprovada |
| execucao | nao_observada/em_curso/termino_observado/nao_executada |
| join | nao_aplicavel/pendente/confirmado |
| admissoes_abertas, publicadores_pendentes | int não negativo |
| responsabilidades | tupla de retratos, por ID de admissão |
| pendencias, erros | tuplas de categorias sanitizadas; sem mensagem arbitrária de exceção |
| comprovante | None ou retrato selado descrito abaixo |

Responsabilidade contém responsabilidade_id: int positivo, reserva_id: int ou None,
tipo: socket/handler/operacao, estado: pendente/em_uso/limpeza_pendente/resolvida/erro,
resultado: None/sucesso/ausencia_comprovada, e erros: tupla. Reserva_id None não
dispensa evidência de resolução de uma operação sem socket. Esses estados novos
não substituem nem renomeiam estados/diagnósticos existentes de criação de socket.

Comprovante contém ciclo_id, trabalhador_id, partida_final, execucao_final,
join_final, responsabilidades_resolvidas: tupla dos IDs, publicacao_fechada: True
e revisao: int positivo. Sem referência obrigatória ao objeto Thread. Não há
comprovante positivo com erro impeditivo. Histórico preserva erros mesmo se não
houver elegibilidade para liberação. Campos adicionais exigem revisão de schema;
não interpretar omissão ou valor inválido como resolução.

## 2. Regra de selagem, incluindo ambiguidade

Selagem é uma transição atômica, não efeito de consulta/GC. Exige simultaneamente:

1. Partida definitivamente conhecida. Retorno normal de start é evidência de
   partida; uma exceção continua incerta, independentemente de ident/is_alive.
2. Se houve execução: entrada autenticada do worker vinculada à admissão original,
   retorno observado e join efetivamente confirmado fora dos locks. Join com
   timeout seguido de worker vivo não é confirmação.
3. Se não houve execução: prova do produtor de que start não foi invocado e a
   invocação futura foi impedida atomicamente. ident None não fornece essa prova.
4. Todas as responsabilidades admitidas resolvidas, sem socket/handler/operação
   ou limpeza pendente, sem erro impeditivo e sem transferência em curso.
5. Admissão de novas responsabilidades encerrada e todos os produtores de resultado
   reconhecidos concluídos ou transferidos. Coordenador retornar não basta.

Start incerto pode evoluir para execucao_comprovada quando a entrada do worker
original é positivamente comprovada; ainda exige término/join e itens 4–5. Se
start já foi invocado e seu efeito não pode ser determinado, não autorizar ausência
por silêncio/timeout: permanece retido. Não existe resolução administrativa
automática de ambiguidade nesta proposta.

Comprovante selado é imutável. Repetição do mesmo resultado pelo mesmo produtor,
ID e revisão é idempotente. Antes da selagem, publicação tardia válida é incorporada
e pode manter a pendência. Após selagem, publicação conflitante é violação de
invariante: registrar conflito, suspender novas admissões/recuperações automáticas
e exigir diagnóstico; nunca suprimir erro para preservar um certificado favorável.
Isso não desfaz recuperação já executada. O protocolo deve impedir a selagem
enquanto qualquer produtor legítimo ainda puder publicar um resultado novo.

## 3. Conservação das garantias de ciclo

Um trabalhador selado não confirma sozinho o ciclo. A B2/supervisão continuam
exigindo contexto original consistente, retorno do coordenador, publicação de
limpeza, gate fechado e resolução positiva de todas as responsabilidades.
Erro/identidade desconhecida produz pendente/desconhecido conforme API vigente.
Não reclassificar ciclo antigo por troca de representação. Tokens originais de
socket e retornos repetidos permanecem vigentes; shutdown tardio fica inalterado.

Manter ordem controle→registro. Registrar vínculos antes de start; transferência
sem intervalo sem dono; join/close/shutdown fora de locks. Falha de alocação ou
revalidação durante selagem conserva registro operacional forte. Snapshot obtido
antes da transição continua válido e pode legitimamente impedir liberação.

## 4. Versionamento e fases independentes

**Fase 1, somente após autorização própria:** introduzir schema /1 e acompanhar
em paralelo, sem reduzir/modificar registro.threads. Migrar consumidores internos
para consultas propostas apenas com comparação de diagnósticos e de provas.
Qualquer divergência bloqueia avanço para liberação. APIs atuais, lista, identidade,
ordem e mutabilidade dos objetos continuam iguais. Não anunciar economia: haverá
coexistência e possível acréscimo de memória.

**Fase 2, exige nova autorização explícita:** proposta de contrato público /2 para
registro.threads: conter apenas Thread originais ainda operacionalmente retidos,
em ordem de admissão; nunca resumos ou proxies misturados. Snapshot de trabalhadores
operacionais passa a ser a interface suportada para consumidores migrados.
Não prometer índices estáveis ou comprimento histórico. Isso é mudança pública
incompatível, mesmo com API histórica disponível; não ativar por configuração
silenciosa nem como consequência da autorização da Fase 1.

Recomendação para /2: acesso por snapshot; alteração externa da coleção operacional
não suportada. A mutabilidade do próprio Thread entregue não é revogada. Forma
final do atributo, janela de depreciação e distribuição da versão /2 requerem
aprovação pública específica. Não se escolhe calendário nesta especificação.

O schema histórico /1 e o contrato público /2 da lista têm números distintos
porque versionam superfícies diferentes, não versões já lançadas do aplicativo.
Não alterar semântica das consultas históricas existentes de ciclo ou socket.

## 5. Migração interna e critérios objetivos de aceitação

| Marco | Condição para autorizar avanço |
| --- | --- |
| Autorizar desenvolvimento da Fase 1 | Aprovação explícita deste schema, selagem e escopo sem retirada de originais |
| Validar Fase 1 | Todos os testes novos e regressão vigente passam; nenhum assert de identidade/lista vigente é relaxado; zero divergências explicadas como sucesso por ausência |
| Validar protocolo | Cobrir start que lança antes/depois de executar, worker vivo, join incompleto, reserva incerta, erro de close/handler, publicação/transferência concorrente, callback tardio, repetição/conflito e falhas de observação |
| Migrar consumidores | Admissão/servidor_tcp publica vínculos; recuperação parcial usa snapshot de originais para join/current_thread; controle usa responsabilidades+comprovantes; B2 mantém seus próprios donos/tarefas; supervisão conserva prova por contexto |
| Propor Fase 2 | Inventário de consumidores internos concluído, contrato público /2 e depreciação aprovados; não basta remover referências encontradas por busca textual |
| Validar Fase 2 em isolamento | Mesmos diagnósticos/retornos e confirmação do baseline; originais ativos/incertos preservados; memória inclui comprovantes e índices; testes com nenhum/um/todos os originais externos |
| Autorizar integração operacional | Relatório de carga mista e duração, escrita/consulta/lock/p95/p99/máximo, pico/retida/RSS separados, comparação de B2 e ciclo anterior/novo, aprovação explícita dos limites observados |
| Validar fisicamente | Segunda perda após promoção e saída/reabertura com autorização e TC420; não substituir por simulação |

Não definir percentual mínimo ou teto arbitrário antes das medições. Para Fase 2,
deve existir benefício líquido demonstrável na carga mista sem raízes externas,
nenhuma perda de segurança e decisão explícita sobre regressões de latência.
Memória pode continuar linear em comprovantes; não é promessa de processo constante.
Manter todos os originais externamente pode anular o ganho sem caracterizar falha.

Reversão da Fase 1 pode desligar observação paralela preservando o contrato atual.
Depois da liberação da Fase 2, não se pode reconstruir a identidade de originais
coletados. Rollback exige nova execução em contrato antigo, não fabricação de
Thread para ciclos históricos; planejar isso antes de ativar a liberação.

## 6. Estado da revisão

As decisões acima tornam a proposta revisável/implementável, mas não constituem
aprovação do responsável. Nenhuma Fase 1/Fase 2 foi autorizada ou implementada.
Escopo futuro de desenvolvimento precisa citar a fase aprovada e suas restrições.
Não foram criadas estruturas, protótipos ou testes. Revisão documental confrontada
com a 2B.11 e garantias vigentes. Última regressão completa continua sendo a 2B.9
(2.083 testes), não executada nesta etapa. Regressão física permanece pendente.

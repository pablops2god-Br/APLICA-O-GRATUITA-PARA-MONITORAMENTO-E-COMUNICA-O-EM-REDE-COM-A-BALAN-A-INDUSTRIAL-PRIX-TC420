# Administrador integrado — 19/11/2026

Integração autorizada pelo responsável após os ensaios visuais. O ponto de
entrada `python main.py` agora prepara o controle administrativo antes de
descoberta, login da balança ou comunicação com equipamento.

## Fluxo efetivo

| Situação | Comportamento |
|---|---|
| Nenhum administrador cadastrado | Cadastro (mínimo 8 caracteres e confirmação), depois Login, depois fluxo da aplicação |
| Cadastro existente e método HTTPS | Inicialização automática anterior continua sem login administrativo |
| Método TCP salvo | Login administrativo em cada abertura; abre conexão TCP sem passar por descoberta/HTTP automático |
| Conexão manual após falha do automático | Pede login se ainda não autorizado nesta execução |
| TCP após login nesta execução | Não pede login duplicado na conexão |
| ASSUMIR manual | Pede login antes de mostrar o formulário |
| Promoção automática | Conserva o caminho automático e as provas operacionais existentes |
| Monitor → Reconfigurar | Login, parada B2, fechamento do monitor/raiz e nova execução na conexão |
| Atalho de ensaio na conexão/ASSUMIR | Login antes de lançar o laboratório |

Reconfigurar cria novos donos operacionais no mesmo processo depois que o
mainloop anterior retorna com B2 confirmada. Preserva a autorização obtida
nesse pedido, evitando pedir a mesma senha duas vezes antes da conexão.
Não foi criado token persistente ou argumento para pular autenticação.

As mudanças estão ligadas no ponto de entrada do aplicativo; chamadas internas
de módulos em testes não ativam automaticamente o controlador global. Isto é
controle da interface, não uma barreira contra quem altera código/arquivos ou
possui acesso ao mesmo usuário do Windows.

## Persistência e credenciais

`config/administrador.py` guarda `administrador.json` ao lado do JSON da conexão.
Na preparação do instalador, o caminho do EXE passou a LocalAppData por usuário;
em desenvolvimento continua na raiz. Ver [roteiro Windows](ROTEIRO_INSTALACAO_WINDOWS.md).
Contém versão 1, sal aleatório de 16 bytes, verificador PBKDF2-HMAC-SHA256 de
200.000 iterações e método HTTPS/TCP. Não contém senha em texto aberto. A escrita
usa arquivo temporário, flush/fsync e substituição do destino. Arquivo inválido
não é interpretado como ausência de cadastro. O verificador e temporários foram
incluídos no `.gitignore`.

O cálculo e o acesso ao disco/cofre ocorrem em trabalhadores acompanhados pela
SaidaAplicacao. O Tk aplica resultados pelo CicloTk; senha errada mantém bloqueio.
A senha administrativa é independente da credencial da balança no keyring.
Não há senha padrão nem cadastro administrativo criado por esta integração.

O modo TCP também salva IP/porta/nome para nova abertura, mantendo referência
ao usuário configurado para permitir sua limpeza posterior, mas desabilita o
login automático HTTPS. TCP continua sem usuário/senha da balança, servidor,
distribuição ou sucessão. O parser, os 10 s de frescor e a notificação de 2 s
não foram modificados.

## Esqueci a senha e restauração

NÃO conserva tudo. SIM autoriza limpar configuração da conexão, credencial
associada ao usuário configurado no serviço PRIX_TC420 e cadastro administrativo.
Não apaga histórico de estudos, logs exportados, backups, código ou outras
credenciais do Windows. O botão de restauração é intencionalmente acessível sem
conhecer a senha antiga, conforme o fluxo solicitado.

Quando solicitado no monitor ou conexão de uma execução ativa, o pedido marca
a intenção de restaurar e fecha pela B2. Se houver pendência, não inicia nova
execução nem limpa os arquivos. Após confirmação, a nova execução operacional
faz a limpeza antes de qualquer comunicação
com equipamento. Assim, tarefas antigas não podem regravar dados após a limpeza.
O fluxo administrativo integrado reinicia no mesmo processo com registros e
interfaces novos; argumentos de restauração também são aceitos no ponto de
entrada. Na preparação inicial, sem recursos operacionais ativos, a limpeza é direta
em trabalhador. Em seguida abre Cadastro → Login → Conexão.

Credencial associada é excluída antes do JSON; cadastro administrativo é removido
por último. Falha de arquivo/cofre não anuncia sucesso. A limpeza pode ter sido
parcial e pode ser repetida; não é transação entre disco e keyring. Um JSON
ilegível requer correção/restauração assistida para identificar com segurança
qual credencial remover. Registros antigos do cofre que não estejam associados
à configuração atual não são enumerados ou apagados.

## Backup e validação

Backup anterior: `backups/antes_administrador_operacional_2026-11-19/originais.zip`
e `SHA256.json`, com oito arquivos de origem. ZIP e hashes conferidos antes das
alterações. Configuração e credenciais reais não foram incluídas.

- Oito testes novos, com persistência em diretório temporário: cadastro, senha
  incorreta, método, corrupção, restauração delimitada, falha de cofre e falha
  de substituição atômica (alguns casos combinados no mesmo teste). Dois casos
  executam o loop real de reconfiguração com inicializadores simulados: não
  duplicar login normal e não iniciar rede após cancelar o novo cadastro.
- `python -B tests/ensaio_admin_operacional_tk.py`: telas de produção com Tk
  real, disco temporário, cofre falso e sockets proibidos. Verifica bootstrap,
  cadastro/login, HTTPS, TCP, restauração, monitor ligado à raiz de conexão,
  B2, callback único e limpeza adiada até nova execução simulada.
- `python -B tests/ensaio_visual_tk.py --autoteste`: laboratório anterior
  continua aprovado e separado da persistência real.
- Compilação em memória de 163 arquivos Python aprovada.
- Regressão completa final: **2.162 testes aprovados em 42,643 s**.
- Links documentais e verificação de whitespace aprovados.

Não houve contato com TC420, login/cofre real, alteração dos dados operacionais
existentes ou validação física. EXE/instalador permanecem pendentes. O cadastro
deve ser feito pelo responsável ao abrir a aplicação atualizada.

## Limites da entrega

Sem bloqueio por número de tentativas, contas múltiplas, política de recuperação
por identidade ou coordenação entre dois processos escrevendo no mesmo cadastro.
PBKDF2 e arquivo ignorado pelo Git não substituem permissões do sistema e
proteção contra cópia/edição do diretório. O caminho gravável para um futuro
instalador segue o roteiro Windows; em desenvolvimento permanece na pasta do projeto.
As investigações de memória 2B continuam encerradas, sem novas integrações.

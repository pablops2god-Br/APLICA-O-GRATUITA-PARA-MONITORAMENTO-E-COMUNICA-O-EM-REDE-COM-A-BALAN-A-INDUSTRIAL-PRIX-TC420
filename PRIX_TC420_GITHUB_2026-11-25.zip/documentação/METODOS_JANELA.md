# Métodos atuais de JanelaTC420

Contrato vigente atualizado em 28/10/2026. Os recortes de código mais abaixo são
históricos, anteriores à B3; consultar interface/janela.py para a implementação.

## Integração operacional B2 — 28/10/2026

Os monitores montados pelo main/conexão recebem callback do SaidaAplicacao.
confirmar_fechamento e fechar mantêm a decisão SIM/NÃO/CANCELAR; o proprietário
coordena a parada em workers e observa resultado via after. Só chama a conclusão
da janela na thread Tk quando parada_operacional_confirmada=True. Timeout/falha
mantém o monitor aberto e permite nova solicitação explícita.

Novo método informar_encerramento_pendente(estado) usa messagebox.showwarning
com estado estático e orientação para novo SIM; não recebe texto da exceção.
JanelaConexao também atualiza label_status e encaminha o aviso ao monitor.
Nenhum worker chama esses métodos. JanelaConexao.verificar_finalizacao e
concluir_encerramento_confirmado passam a aceitar a prova operacional B2,
sem aceitar somente servidor_encerrado ou produzir certificação global.

## Interface e agendamentos B3 — 28/10/2026

- `_iniciar_promocao(trabalho, janela=None)` deduplica promoções e envia a rede
  ao worker registrado em B2. O resultado é aplicado no Tk; a janela ASSUMIR
  precisa continuar sendo a origem válida. Fechar o popup durante uma promoção
  ativa não o substitui; cancelamento de candidatura invalida a operação.
- `verificar_candidatura()` apenas observa o estado e solicita promoção
  assíncrona. `concluir_promocao()` associa contexto e troca sessão/configuração/
  fonte somente no Tk, com janela e proprietário ativos.
- `_agendar()` centraliza callbacks normais de peso, candidatura, contexto e
  rebaixamento. `agendar_saida()` mantém somente a observação de B2 durante a
  parada. CicloTk valida geração/root/owner e cancela IDs no fechamento.
- `atualizar_peso()` recusa parada, root ou label destruído. Refresh verifica
  os labels antes de aplicar dados e registra só a classe de falhas da fonte.
  TclError de programação continua propagando nos callbacks gráficos.
- `concluir_fechamento()` exige prova B2 quando há proprietário, invalida e
  cancela agendamentos e destrói a janela. Avisos pendentes verificam a janela.
- O leitor TCP direto legado publica pela fila, sem after de worker; a sua
  thread é acompanhada, mas o caminho continua fora do ensaio inicial delimitado.

Na JanelaConexao, `conectar()` valida campos e dispara `_conectar_operacional()`
fora do Tk; `_aplicar_conexao()` trata resultado/erro sanitizado no Tk. Um login
ativo ou um principal já iniciado impede outro CONECTAR. Quando descobre cliente,
o callback que cria a janela seguinte é invocado após o mainloop antigo retornar.
O botão de fechar da conexão solicita confirmação e usa o mesmo proprietário.

## Recortes históricos anteriores à B3

## __init__

```python
def __init__(
        self,
        web=None,
        configuracao=None,
        fonte_dados: Optional[Callable[[], Mapping[str, Any]]] = None,
        candidatura_liberada=None,
        estado_candidatura=None,
        ao_promover=None,
        ao_promover_automaticamente=None,
        master=None,
        ao_fechar=None,
    ):
        self.web = web
        self.configuracao = configuracao
        self.fonte_dados = fonte_dados
        self.candidatura_liberada = candidatura_liberada
        self.estado_candidatura = estado_candidatura
        self.ao_promover = ao_promover
        self.ao_promover_automaticamente = ao_promover_automaticamente
        self.promocao_em_andamento = False
        self.candidatura_detectada = False
        self.janela_promocao = None

        # Sem master, a janela é a principal (modo CLIENTE):
        # ela cria e passa a ser dona do próprio Tk.
        # Com master, ela é embutida (modo PRINCIPAL) e vira
        # uma Toplevel da JanelaConexao.
        self.master = master
        self.dona_root = master is None
        self.ao_fechar = ao_fechar

        if self.dona_root:
            self.root = tk.Tk()
        else:
            self.root = tk.Toplevel(master)

        self.root.title("PRIX TC420 - Monitor")
        self.root.geometry("620x230")
        self.root.resizable(False, False)
        self.root.configure(bg="#B6B6B6")

        self.balanca = ConexaoTC420()
        self.executando = True

        if self.configuracao:
            w11 = self.configuracao["W1.1"]
            w12 = self.configuracao["W1.2"]

            w11_divisao = w11["divisao"]
            w11_min = w11["min"]
            w11_max = w11["max"]

            w12_divisao = w12["divisao"]
            w12_min = w12["min"]
            w12_max = w12["max"]
        else:
            # Fallback caso o monitor seja aberto sem a tela de conexão
            w11_divisao = "10 kg"
            w11_min = "200 kg"
            w11_max = "80000 kg"

            w12_divisao = "20 kg"
            w12_min = "400 kg"
            w12_max = "140000 kg"

        # =====================================================
        # CABEÇALHO PRETO
        # =====================================================

        self.frame_cabecalho = tk.Frame(
            self.root,
            bg="black",
            width=600,
            height=50,
        )
        self.frame_cabecalho.place(x=10, y=10)

        # W1.1
        tk.Label(
            self.frame_cabecalho,
            text="W1.1",
            font=("Verdana", 11),
            fg="white",
            bg="black",
        ).place(x=10, y=3)

        # Linha 1
        tk.Label(
            self.frame_cabecalho,
            text=f"Max {w11_max}",
            font=("Verdana", 11),
            fg="white",
            bg="black",
        ).place(x=100, y=3)

        tk.Label(
            self.frame_cabecalho,
            text=f"Min {w11_min}",
            font=("Verdana", 11),
            fg="white",
            bg="black",
        ).place(x=245, y=3)

        tk.Label(
            self.frame_cabecalho,
            text=f"e=d={w11_divisao}",
            font=("Verdana", 11),
            fg="white",
            bg="black",
        ).place(x=400, y=3)

        # W1.2
        tk.Label(
            self.frame_cabecalho,
            text="W1.2",
            font=("Verdana", 11),
            fg="white",
            bg="black",
        ).place(x=10, y=27)

        # Linha 2
        tk.Label(
            self.frame_cabecalho,
            text=f"Max {w12_max}",
            font=("Verdana", 11),
            fg="white",
            bg="black",
        ).place(x=100, y=27)

        tk.Label(
            self.frame_cabecalho,
            text=f"Min {w12_min}",
            font=("Verdana", 11),
            fg="white",
            bg="black",
        ).place(x=245, y=27)

        tk.Label(
            self.frame_cabecalho,
            text=f"e=d={w12_divisao}",
            font=("Verdana", 11),
            fg="white",
            bg="black",
        ).place(x=400, y=27)

        # =====================================================
        # DISPLAY PRINCIPAL
        # =====================================================

        self.frame_peso = tk.Frame(
            self.root,
            bg="yellow",
            width=600,
            height=100,
            highlightbackground="black",
            highlightthickness=2,
        )
        self.frame_peso.place(x=10, y=60)

        # W1.1 atual
        self.label_faixa = tk.Label(
            self.frame_peso,
            text="W1.1",
            font=("Verdana", 26),
            fg="black",
            bg="yellow",
        )
        self.label_faixa.place(x=10, y=8)

        # =====================================================
        # INDICADOR DE ESTADO / ESTABILIDADE
        # =====================================================

        self.img_zero_original = tk.PhotoImage(
            file="assets/null_cursor.png"
        )
        self.img_estavel_original = tk.PhotoImage(
            file="assets/settled.png"
        )

        # Reduz as imagens
        self.img_zero = self.img_zero_original.subsample(8, 13)
        self.img_estavel = self.img_estavel_original.subsample(13, 10)

        self.label_estado = tk.Label(
            self.frame_peso,
            image=self.img_zero,
            bg="yellow",
            borderwidth=0,
        )
        self.label_estado.place(
            x=16,
            y=65,
            width=40,
            height=15,
        )

        # Peso
        self.label_peso = tk.Label(
            self.frame_peso,
            text="0",
            font=("Verdana", 54, "bold"),
            fg="black",
            bg="yellow",
            anchor="e",
        )
        self.label_peso.place(
            x=100,
            y=2,
            width=400,
            height=80,
        )

        # Unidade
        self.label_unidade = tk.Label(
            self.frame_peso,
            text="kg",
            font=("Verdana", 28),
            fg="black",
            bg="yellow",
        )
        self.label_unidade.place(x=515, y=48)

        # =====================================================
        # TARA
        # =====================================================

        self.frame_tara = tk.Frame(
            self.root,
            bg="yellow",
            width=600,
            height=50,
            highlightbackground="black",
            highlightthickness=2,
        )
        self.frame_tara.place(x=10, y=160)

        tk.Label(
            self.frame_tara,
            text="TARE",
            font=("Verdana", 16),
            fg="black",
            bg="yellow",
        ).place(x=10, y=10)

        self.label_tara = tk.Label(
            self.frame_tara,
            text="0",
            font=("Verdana", 24),
            fg="black",
            bg="yellow",
            anchor="e",
        )
        self.label_tara.place(
            x=100,
            y=3,
            width=400,
            height=40,
        )

        tk.Label(
            self.frame_tara,
            text="kg",
            font=("Verdana", 16),
            fg="black",
            bg="yellow",
        ).place(x=515, y=10)

        # =====================================================
        # FECHAMENTO
        # =====================================================

        self.root.protocol(
            "WM_DELETE_WINDOW",
            self.confirmar_fechamento,
        )
```

## verificar_candidatura

```python
def verificar_candidatura(self):
        if not self.executando:
            return

        if self.candidatura_liberada is not None:
            try:
                liberada = self.candidatura_liberada()
                if liberada and not self.candidatura_detectada:
                    self.candidatura_detectada = True
                    print("")
                    print("Candidatura detectada pela interface.")
                    resultado = None
                    if self.ao_promover_automaticamente is not None:
                        if not self.promocao_em_andamento:
                            self.promocao_em_andamento = True
                            try:
                                resultado = self.ao_promover_automaticamente()
                            finally:
                                self.promocao_em_andamento = False

                    if resultado is not None and resultado is not False:
                        self.concluir_promocao(resultado)
                    else:
                        estado = None
                        if self.estado_candidatura is not None:
                            try:
                                estado = self.estado_candidatura()
                            except Exception as erro:
                                print(
                                    "Erro ao consultar estado "
                                    f"da candidatura: {erro}"
                                )
                        if estado == "liberada":
                            self.abrir_janela_promocao()
                elif not liberada:
                    self.candidatura_detectada = False
                    estado = None
                    if self.estado_candidatura is not None:
                        try:
                            estado = self.estado_candidatura()
                        except Exception as erro:
                            print(
                                "Erro ao consultar estado "
                                f"da candidatura: {erro}"
                            )
                    if estado in ("cancelada", "inativa"):
                        if (
                            self.janela_promocao is not None
                            and self.janela_promocao.winfo_exists()
                        ):
                            print(
                                "Candidatura cancelada. "
                                "Fechando janela ASSUMIR."
                            )
                            self.janela_promocao.destroy()
                            self.janela_promocao = None
            except Exception as erro:
                print(f"Erro ao verificar candidatura: {erro}")

        if self.executando:
            self.root.after(500, self.verificar_candidatura)
```

## concluir_promocao

```python
def concluir_promocao(self, resultado):
        self.web = resultado["web"]
        self.configuracao = resultado["configuracao"]
        self.fonte_dados = resultado["fonte_dados"]
        self.candidatura_liberada = None
        self.candidatura_detectada = False
        print("")
        print("PROMOÇÃO CONCLUÍDA.")
        print("Esta máquina agora é o PRINCIPAL.")
```

## abrir_janela_promocao

```python
def abrir_janela_promocao(self):
        if (
            self.janela_promocao is not None
            and self.janela_promocao.winfo_exists()
        ):
            self.janela_promocao.lift()
            self.janela_promocao.focus_force()
            return

        janela = tk.Toplevel(self.root)
        self.janela_promocao = janela
        janela.title("Assumir TC420")
        janela.geometry("340x230")
        janela.resizable(False, False)

        tk.Label(
            janela,
            text="Servidor principal indisponível",
            font=("Verdana", 11, "bold"),
        ).pack(pady=(15, 10))

        frame = tk.Frame(janela)
        frame.pack(padx=20, fill="x")

        tk.Label(frame, text="IP da TC420:").grid(
            row=0, column=0, sticky="w", pady=5
        )
        entry_ip = tk.Entry(frame, width=22)
        entry_ip.grid(row=0, column=1, pady=5)
        entry_ip.insert(0, "192.0.2.21")

        tk.Label(frame, text="Usuário:").grid(
            row=1, column=0, sticky="w", pady=5
        )
        entry_usuario = tk.Entry(frame, width=22)
        entry_usuario.grid(row=1, column=1, pady=5)
        entry_usuario.insert(0, "admin")

        tk.Label(frame, text="Senha:").grid(
            row=2, column=0, sticky="w", pady=5
        )
        entry_senha = tk.Entry(frame, width=22, show="*")
        entry_senha.grid(row=2, column=1, pady=5)

        def confirmar():
            ip = entry_ip.get().strip()
            usuario = entry_usuario.get().strip()
            senha = entry_senha.get()
            if not ip or not usuario or not senha:
                print(
                    "Preencha IP, usuário e senha "
                    "para assumir a TC420."
                )
                return

            if self.ao_promover is None:
                print("Promoção não configurada.")
                return
            if self.promocao_em_andamento:
                return

            self.promocao_em_andamento = True
            print("")
            print("Solicitando promoção para PRINCIPAL...")
            try:
                resultado = self.ao_promover(ip, usuario, senha)
                if resultado is None:
                    print("Promoção não realizada.")
                    return

                self.concluir_promocao(resultado)
                self.fechar_janela_promocao(janela)
            finally:
                self.promocao_em_andamento = False

        tk.Button(
            janela,
            text="ASSUMIR",
            width=15,
            command=confirmar,
        ).pack(pady=15)
        entry_senha.bind("<Return>", lambda event: confirmar())
        janela.protocol(
            "WM_DELETE_WINDOW",
            lambda: self.fechar_janela_promocao(janela),
        )
        entry_senha.focus_set()
```

## definir_fonte_dados

```python
def definir_fonte_dados(
    self, fonte_dados: Callable[[], Mapping[str, Any]]
) -> None:
    if not callable(fonte_dados):
        raise ValueError(
            "A fonte de dados deve ser uma função."
        )
    self.fonte_dados = fonte_dados
    print("Fonte de dados do monitor atualizada.")
```

Aceita qualquer callable, sem executá-lo ou validar os dados retornados.
Entrada inválida preserva a fonte anterior. Não há chamadas novas a este
método nesta etapa. A transição para cliente e o leitor sem candidatura
continuam propostas; futura integração deve trocar a fonte na thread da interface.

A fonte está tipada como Callable sem argumentos que retorna Mapping[str, Any].
O construtor também aceita None. Os tipos vêm de typing; as anotações não
validam o conteúdo retornado em execução. Isso evita inferência de object
no retorno após a verificação callable e permite indexação no refresh.

## observar_rebaixamento

```python
def observar_rebaixamento(self, evento, obter_leitor):
    def verificar():
        if not self.executando:
            return
        if evento.is_set():
            leitor = obter_leitor()
            if (
                leitor is not None
                and leitor.servidor_esta_respondendo()
            ):
                self.definir_fonte_dados(
                    leitor.obter_dados_atuais
                )
                print(
                    "MONITOR: fonte de dados alterada "
                    "para o novo PRINCIPAL."
                )
                return
        self.root.after(1000, verificar)

    self.root.after(1000, verificar)

```

Método disponível, sem chamadas nesta etapa. Deve ser iniciado na thread da interface com mainloop ativo. Agenda verificação a cada 1000 ms; sem evento, leitor ou conexão continua aguardando. Após conexão sinalizada troca a fonte e encerra a observação. Se executando=False, o callback retorna sem reagendar. Não valida recebimento do primeiro pacote, não cancela callback já agendado e não gerencia encerramento do leitor.

## fechar — callback opcional

fechar retorna se executando=False. Com ao_fechar, chama callback e retorna mantendo monitor ativo; sem callback delega a concluir_fechamento. O callback pode ser chamado novamente enquanto executando=True; sua rotina externa deve tratar solicitações repetidas. Exceção do callback propaga e não destrói monitor. concluir_fechamento marca executando=False, tenta desconectar balanca ignorando exceções e destrói root; chamadas repetidas não repetem limpeza. No login manual, confirmação externa para concluir ainda pendente.

## confirmar_fechamento

WM_DELETE_WINDOW chama confirmar_fechamento. messagebox.askyesnocancel usa root como parent e apresenta Sim, Não e Cancelar. Sim imprime a escolha e, com ao_fechar configurado, chama fechar; sem callback informa indisponibilidade e mantém o monitor aberto. Não e Cancelar apenas imprimem a escolha. Bandeja e coordenação completa de encerramento ainda pendentes.

## concluir_fechamento

Método explícito para concluir na thread da interface após a coordenação externa. Desativa atualizações, tenta desconectar e destrói apenas root do monitor. Não destrói Tk pai automaticamente nem aguarda servidor/leitor. Interface de conexão ainda não chama este método.

## JanelaConexao.observar_contexto_ciclo(contexto)

Executa na thread principal: verifica se contexto é o associado à tentativa
atual. Se resolvido, copia seu ID para ciclo_servidor_id; se pendente, reagenda
em 100 ms via root.after. Contexto antigo não altera ID de nova tentativa.
Não aguarda Event, não consulta controle global nem altera fechamento/monitor.
Inicialização do monitor não espera esse método. Campo None distingue ausência
de ID; detalhes da falha estão no contexto sanitizado.

## JanelaTC420 — composição visual e estado operacional

`_montar_barra_superior` cria o menu `Opções`. O botão chama
`abrir_menu_opcoes`, que usa `tk_popup` e libera o grab em `finally`, evitando a
falha de abertura observada com `Menubutton`. `Info`, `Exportar log` e
`Reconfigurar` estão habilitados. Terminal e desativação do login automático
continuam desabilitados por falta de contrato uniforme nos modos existentes.

`exportar_log` solicita um destino `.txt` e grava o retrato completo acumulado
por `interface.registro_terminal`. O registro espelha stdout e stderr sem ocultar
o console. Cancelar o diálogo não cria arquivo; erro de escrita é sanitizado.

`solicitar_reconfiguracao` confirma a intenção, marca uma única solicitação e
encaminha a mesma parada B2 usada pelo fechamento. Somente
`concluir_fechamento`, após `parada_operacional_confirmada`, chama o callback que
inicia nova execução com `--reconfigurar`. Essa execução pula descoberta e login
automático e abre diretamente `JanelaConexao`.

`_retrato_status` usa somente callbacks operacionais: saúde HTTP e encerramento
confirmado no PRINCIPAL; frescor SUBSCRIBE, candidatura e promoção no CLIENTE.
`_sincronizar_status` invalida a sequência anterior quando o retrato muda;
`_alternar_status` troca mensagens a cada três segundos pelo `CicloTk`. Os
agendamentos são cancelados junto com os demais `after` no fechamento.

`copiar_medicao` copia exclusivamente o texto já exibido e sua unidade pelo
clipboard do Tk. Quando `comunicacao_confirmada` é falsa, os botões permanecem
desabilitados e o método recusa a cópia. `_caminho_asset` resolve a raiz do
projeto ou `sys._MEIPASS`; as referências `PhotoImage` são mantidas na instância.

O modo visual muda para CLIENTE somente quando o leitor rebaixado está realmente
respondendo, e muda para PRINCIPAL na conclusão válida da promoção. A barra não
analisa strings de console. O contador apresenta `Clientes: —`, pois não existe
getter de SUBSCRIBEs ativos e `clientes_registrados` não representa conexões.

`COR_FUNDO_MONITOR` centraliza a cor `#8FD33F` usada nos frames, rótulos e botões
de peso e tara. A mesma constante restaura o fundo da faixa depois que uma leitura
válida substitui `SEM COM.`. Cabeçalho, menu e cores semânticas da barra inferior
permanecem independentes.

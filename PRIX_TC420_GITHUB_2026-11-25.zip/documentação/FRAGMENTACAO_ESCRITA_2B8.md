# Etapa 2B.8 — fragmentação, escrita e carga mista

Continuidade isolada: [2B.9 — recursos resolvidos](RETENCAO_RECURSOS_RESOLVIDOS_2B9.md)
audita threads/sockets e mede candidatos separados, sem alterar estes resultados.

12/11/2026. Investigação exclusivamente experimental: implementação atual, 2B.6
e 2B.7 comparadas sem alterar servidor, protótipos existentes, B2, supervisão ou
contratos públicos. Nenhuma política automática ou teste físico foi iniciado.

## Método

Harness: `python -B tests/medir_fragmentacao_escrita.py --saida resultado.json`.
Cinco cargas por backend, 15 cenários. Quatro cargas têm 50.000 reservas:

- Uniforme sem recurso: criação/resolução sequencial, sem tokens externos.
- Inversa fragmentada: todas as reservas criadas primeiro; índices alternados
  resolvidos em ordem decrescente; restantes viram criações incertas.
- Ponte/fusão: mesma fragmentação inicial, depois resolução dos espaços em ordem
  crescente, exigindo fusão de faixas; resultado final uniforme sem recurso.
- Aleatória com tokens: ordem fixa por semente 280, alternando resolução comprovada
  e incerteza, com todos os tokens preservados externamente.

A quinta carga reproduz **quantidades e proporções**, não a rede nem a duração
da hora: 15.502 reservas, 1.779 sem recurso distribuídas pelo ciclo, 13.723 objetos
de socket simulado fechados, 13.724 objetos Thread realmente iniciados/joinados.
São três trabalhadores auxiliares e uma thread por socket após os dois primeiros.
Os corpos das threads são vazios; não executam HTTP/TCP/handlers reais. As marcas
de handler/uso/fechamento são exercitadas pelos métodos do registro. Nenhum socket
de sistema é aberto. Resultado é um grafo sintético de retenção, não uma repetição
do ensaio de uma hora ou prova sobre memória total/RSS.

## Latências e memória separadas

Primeira construção sem tracemalloc: cronometra cada reserva, resolução, atualização
de socket/handler, fechamento e registro/start de thread. O lock registra espera
de acquire e tempo de posse. A latência de registrar/start inclui partida real;
join acontece fora do lock e fora desse timing. O custo da instrumentação afeta
operações curtas e não deve ser interpretado como latência pura em produção.

Percentis nearest-rank: posição ceil(p*n), com n, mediana, p95, p99 e máximo no JSON.
Um pico raro pode aparecer só no máximo; p99 não é limite superior nem garantia.
As operações do mesmo cenário são correlacionadas, não amostras independentes de
produção. Não houve repetição estatística ampla de cada cenário.

Após construir, mede três consultas e três avaliações agregadas com lock, além de
concorrência entre cinco consultas completas e 200 pares de criação/resolução.
O harness reabre o gate do registro sintético antes dos dois threads, sem dono B2
ou ciclo finalizado associado; isso não altera a política operacional de gates.
Instrumenta todas as aquisições, incluindo leitores/produtores. Escalonamento pode
limitar sobreposição, logo não extrapolar p95/p99 para a rede real.

Segunda construção independente, com GC e tracemalloc, sem arrays de latência ou
registros de lock. Mede retenção, pico de carga, bytes por reserva e pico absoluto
de consulta. Confere o digest do retrato com a primeira construção. Só depois
compara digests entre os três backends. Preserva a mesma política de tokens por
carga. Não soma porcentagens entre cargas distintas.

## Segurança e cobertura

## Resultados de escrita e fragmentação

Fonte: [MEDICOES_FRAGMENTACAO_ESCRITA_2B8.json](MEDICOES_FRAGMENTACAO_ESCRITA_2B8.json),
15 cenários concluídos, Python 3.13.15/win32. Digests dos três backends iguais
em cada carga, inclusive na reconstrução separada de memória.

Latência total das operações, **p95 / p99 em microssegundos**, sem tracemalloc:

| Operação / carga | Atual | 2B.6 | 2B.7 |
| --- | ---: | ---: | ---: |
| Resolver uniforme | 25,7 / 47,9 | 35,9 / 63,3 | 34,8 / 56,2 |
| Fragmentar em ordem inversa | 20,4 / 27,0 | 38,8 / 58,0 | 35,7 / 49,7 |
| Fundir pontes | 24,0 / 31,1 | 56,8 / 136,6 | 51,6 / 105,5 |
| Resolver sem recurso, aleatória/tokens | 23,3 / 28,0 | 51,8 / 91,5 | 51,5 / 86,3 |

50 mil amostras na resolução uniforme; 25 mil por categoria nas demais linhas.
Máximo de fusão nesta execução: atual 0,943 ms; 2B.6 35,344 ms; 2B.7 5,569 ms.
Máximos incluem efeitos de escalonamento/GC; não atribuir toda cauda ao algoritmo.
As escritas da 2B.6 e 2B.7 usam o mesmo código: diferenças entre elas não são
evidência de melhoria de escrita. O ganho da 2B.7 continua concentrado na leitura.

Inserção de reserva e estados de socket/handler/start de thread também têm
mediana/p95/p99/máximo, espera e posse de lock no JSON. Por exemplo, na mista,
p99 de reservar foi 17,0 / 16,7 / 16,5 us e de fechar foi 49,8 / 53,1 / 51,2 us
para atual/2B.6/2B.7. A maior penalidade apareceu na resolução/manutenção das faixas,
não em uma superioridade geral de todas as operações.

| Carga | Faixas finais / pico nos protótipos | Retenção atual | 2B.6 | 2B.7 |
| --- | ---: | ---: | ---: | ---: |
| Uniforme | 1 / 1 | 13,814 MB | 0,002 MB | 0,002 MB |
| Inversa fragmentada | 25.000 / 25.000 | 15,014 MB | 13,545 MB | 13,545 MB |
| Ponte/fusão | 1 / 25.000 | 13,814 MB | 5,245 MB | 5,245 MB |
| Aleatória/tokens | 25.000 / 25.000 | 15,458 MB | 18,589 MB | 18,589 MB |
| Mista sintética | 1.779 / 1.779 | 34,315 MB | 35,166 MB | 34,117 MB |

Faixas fragmentadas finais são unitárias; na ponte, a faixa final tem 50 mil IDs.
Picos de carga: ponte 16,669 MB atual e 19,117 MB nos protótipos; aleatória
18,662 MB atual e 21,108 MB nos protótipos. Uniformidade final não apaga todo
custo de um pico de fragmentação anterior.

Uma verificação adicional, [CAPACIDADES_APOS_FUSAO_2B8.json](CAPACIDADES_APOS_FUSAO_2B8.json),
reconstruiu ponte/fusão sem tracing: tabela forte e índice fraco ficaram vazios,
mas cada dicionário interno conservou **2.621.528 bytes superficiais** em ambos
os protótipos (sys.getsizeof). Isso explica grande parte dos 5,245 MB mesmo após
fundir tudo em uma faixa; não são responsabilidades ativas. Reprodução: chamar
`montar(versao, 'ponte_fusao', False)` e inspecionar fortes/identidades.data com
sys.getsizeof após GC. Não foi implementada redução automática dessas capacidades.

## Consulta e agregado na carga mista

Posse mediana do lock, três repetições sem tracing:

| Carga | Consulta atual / 2B.6 / 2B.7 | Agregado atual / 2B.6 / 2B.7 |
| --- | --- | --- |
| Uniforme | 67,97 / 822,95 / 62,75 ms | 64,529 / 613,486 / 0,008 ms |
| Inversa | 67,71 / 527,72 / 96,06 ms | 62,242 / 346,438 / 5,305 ms |
| Ponte | 72,84 / 1.168,43 / 54,49 ms | 65,833 / 1.067,324 / 0,109 ms |
| Aleatória/tokens | 66,76 / 520,37 / 101,34 ms | 65,647 / 520,801 / 6,948 ms |
| Mista | 22,04 / 59,62 / 69,81 ms | 17,890 / 56,139 / 28,608 ms |

A vantagem agregada uniforme/fragmentada não implica vantagem na mista: nessa
execução a atual foi melhor também no agregado misto. Todas as threads encerradas
e entradas de sockets fechados continuam percorridas; não foram compactadas.
Tempos variam entre execuções; não comparar diretamente com as medianas da 2B.7
anterior como se fossem amostras simultâneas.

## Memória mista pareada: mesmos objetos antes/depois

Os valores mistos independentes acima incluem variações do runtime e alocações
globais das threads; a leitura otimizada não muda a representação de escrita.
Para isolar o benefício, executado:

`python -B tests/medir_fragmentacao_escrita.py --pareada --saida resultado.json`.

[MEMORIA_PAREADA_MISTA_2B8.json](MEMORIA_PAREADA_MISTA_2B8.json) mantém os mesmos
13.724 objetos Thread encerrados e 13.723 sockets simulados fechados. Troca apenas
o dicionário do registro sintético pelo armazenamento experimental, após confirmar
todos os estados e com GC antes/depois; nenhum servidor está em execução.

**34.853.847 → 34.729.335 bytes**, economia de **124.512 bytes, aproximadamente
0,36%**. Diagnóstico idêntico e confirmação positiva preservados. As 13.723 entradas
fechadas continuam fortes; apenas 1.779 sem recurso viram faixas. Pico de conversão
36.053.887 bytes; pico anterior inclui construção/serialização do digest e não
é comparável como pico de carga pura. Não é medição de RSS.

Essa é evidência de benefício pequeno para esse grafo misto, não prova de memória
global estável nem estimativa exata da rede real. Reduções uniformes não podem ser
aplicadas aos 36 MB observados na hora: os objetos dominantes permanecem retidos.

## Concorrência: p99 não substitui máximo

A primeira rodada do JSON principal teve pouca sobreposição em vários casos.
Por isso foi executada rodada adicional em
[CONTENCAO_CONTROLADA_2B8.json](CONTENCAO_CONTROLADA_2B8.json), 15 cenários, mesma
carga construída sem tracing e latência do par criação/resolução de 200 operações.

Reprodução: `python -B tests/medir_fragmentacao_escrita.py --concorrencia --saida resultado.json`.
No primeiro acquire do leitor, sincronização garante que produtor começou a
tentar escrever antes de prosseguir com o diagnóstico. A espera inclui essa
sincronização/escalonamento, não representa distribuição de tráfego de produção.

| Carga / versão | Produtor p95 / p99 / máximo | Máximo esperando acquire |
| --- | --- | ---: |
| Uniforme atual | 0,036 / 0,110 / 53,795 ms | 53,713 ms |
| Uniforme 2B.6 | 0,044 / 0,077 / 587,141 ms | 587,058 ms |
| Uniforme 2B.7 | 0,031 / 0,051 / 30,951 ms | 30,872 ms |
| Aleatória atual | 0,012 / 0,017 / 75,954 ms | 75,892 ms |
| Aleatória 2B.7 | 0,022 / 0,028 / 68,192 ms | 68,105 ms |
| Mista atual | 0,020 / 0,024 / 57,654 ms | 57,597 ms |
| Mista 2B.7 | 0,030 / 0,060 / 71,252 ms | 71,168 ms |

Um único bloqueio em 200 operações pode ficar fora do p99. Por isso n/máximo e
contexto da aquisição são indispensáveis. Não concluir ausência de esperas longas
apenas por p95/p99 pequenos. As diferenças entre rodadas não justificam prometer
latência máxima; nenhuma operação pendente foi apagada para melhorar os números.

## Segurança e cobertura

O predicado agregado não muda critérios: incerteza, erro de limpeza, handler
pendente e operação fechando continuam impedindo confirmação. Threads não são
removidas. O índice fraco e a validação por identidade continuam como na 2B.6.

Quatro novos testes: percentis; fusão de pontes conservando tokens originais;
incerteza intercalada impedindo confirmação histórica/compactação; erro de close
mantendo recurso forte e impedindo agregado. São complementados pelos testes
existentes de close concorrente, publicação tardia, falsificação e GC.

Nenhuma alternativa de retenção com descarte de diagnóstico foi escolhida. Uma
proposta desse tipo exigiria escopo, respostas e validade dos tokens explicitados
antes de aprovação. Esta etapa mede custos; não autoriza integração.

## Verificações executadas e decisão

Quatro novos testes aprovados. Bateria existente com substituição pela 2B.7:
**116 testes em 3,414 s, OK**, incluindo B2, supervisão, publicação tardia e
close concorrente. Regressão normal atual: **2.073 testes em 20,312 s, OK**.
**137 arquivos Python compilados em memória**. Comparações de digest concluídas
em todas as cargas; estados incertos continuam retornando confirmação False,
cargas totalmente resolvidas True. Nenhum desses resultados é teste físico.

Etapa 2B.8 concluída no escopo experimental. As faixas favorecem uniformidade,
mas resolução/fusão fragmentadas custam mais, a capacidade auxiliar pode continuar
grande após fusão, e tokens externos podem tornar memória pior que a atual.
Na carga mista pareada, ganho de cerca de 0,36% não sustenta atribuir à compactação
sem_recurso uma solução geral para crescimento histórico.

Manter produção intacta. Próximo desenho deve priorizar as categorias dominantes
retidas (threads encerradas e sockets fechados) ou comparar propostas explícitas
de retenção, preservando provas operacionais. A alternativa contratual não foi
escolhida: validade dos tokens, diagnóstico e eventual resumo/descarte precisam
de proposta concreta e aprovação antes de implementação. Não foi definido teto
arbitrário de memória nem prometida superioridade geral dos intervalos.

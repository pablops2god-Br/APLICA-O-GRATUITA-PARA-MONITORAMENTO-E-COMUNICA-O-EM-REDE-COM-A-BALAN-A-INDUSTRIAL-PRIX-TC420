# Protocolos e contratos de dados

## Endereços e tempos

| Canal | Destino padrão | Tempo |
| --- | --- | --- |
| HTTPS TC420 | `https://192.0.2.21/cgi-bin/cfgcgi.cgi` | Timeout por requisição: 5 s |
| TCP do projeto | PC principal, porta 42100 | Comando inicial: 5 s; stream sem timeout |
| UDP descoberta | Broadcast `255.255.255.255:42101` | Timeout de recepção: 2 s |
| Confirmação TCP | IP descoberto, porta 42100 | Timeout: 2 s |
| TCP direto legado | TC420, porta 9800 | Conexão: 5 s; leitura sem timeout |
| Consulta HTTP principal | TC420 | Pausa de 1 s após cada tentativa |
| SUBSCRIBE | Cliente | Envio a cada 1 s |

A consulta HTTP leva seu próprio tempo além da pausa; não é garantido um
refresh exato por segundo. O servidor escuta em `0.0.0.0` e configura
`SO_REUSEADDR`. As constantes de porta existem em mais de um módulo e precisam
permanecer coerentes quando forem alteradas.

## Descoberta UDP

Pedido: `TC420_SERVER_DISCOVERY`. Resposta: `TC420_SERVER_HERE`.
O cliente verifica depois `CHECK` no IP de origem; não usa somente a resposta
UDP como confirmação. Retorna o primeiro servidor confirmado. Broadcast não
fornece descoberta entre sub-redes por padrão.

## TCP do projeto

Comandos enviados em UTF-8 com `\n`. Cada conexão tem uma operação.
As respostas JSON são objetos serializados em uma linha, terminada por `\n`.
Não há autenticação, criptografia, identificação de grupo ou versão de protocolo.

| Comando | Resposta | Encerramento |
| --- | --- | --- |
| `CHECK\n` | `TC420_SERVER_OK\n` | Servidor fecha |
| `CONFIG\n` | JSON de `configuracao_atual` | Servidor fecha |
| `REGISTER\|hostname\n` | `{"nome": "hostname", "posicao": 1}` | Servidor fecha |
| `SUBSCRIBE\n` | Uma linha JSON por envio | Permanece aberto |

O separador de REGISTER é um único caractere `|` (a barra de escape na tabela
serve apenas à formatação Markdown). Nome vazio fecha a conexão sem resposta.
Nome repetido conserva posição; novo nome recebe `len(registros) + 1` sob lock.
Registros não são removidos ao desconectar; desaparecem com o processo servidor.
Hostnames iguais compartilham posição. Alterar hostname cria outra identidade.

O servidor lê o comando com um único `recv(1024)`: ainda não acumula fragmentos
até a quebra de linha. TCP pode fragmentar comandos, portanto este é um limite
da implementação atual. Cliente usa `makefile/readline` para respostas completas.
Comando desconhecido é registrado e a conexão é fechada.

## Estado de peso

```json
{
  "estado": "00",
  "peso_bruto": "81360",
  "tara": "0",
  "peso_liquido": "81360",
  "unidade": "kg",
  "multirange": "1"
}
```

| Campo | Uso |
| --- | --- |
| `estado` | `Z0/Z1`: zero; `00`: estabilizado; demais: indicador oculto |
| `peso_bruto` | Campo bruto retornado pela balança |
| `tara` | Mostrado no painel TARE |
| `peso_liquido` | Peso principal mostrado pela GUI |
| `unidade` | Texto da unidade |
| `multirange` | `1/2` selecionam W1.1/W1.2 |

O parser HTTP retorna strings. O estado inicial do servidor usa números zero
para pesos; o leitor começa com strings `"0"`. Consumidores não devem assumir
um tipo numérico homogêneo. Não há timestamp, idade do dado ou indicador de
falha HTTP no pacote; o último estado permanece disponível em erro.

## CONFIG W1.1/W1.2

```json
{
  "W1.1": {"divisao": "10 kg", "min": "200 kg", "max": "80000 kg"},
  "W1.2": {"divisao": "20 kg", "min": "400 kg", "max": "140000 kg"}
}
```

Valores acima são exemplos, não configuração fixa do servidor. O principal
obtém os reais via `approval`. `{}` é resposta válida quando ainda não foi
publicada configuração. CONFIG é lido apenas no início da thread cliente;
reconexão obtém REGISTER e SUBSCRIBE, sem atualizar W1.1/W1.2 por enquanto.

## HTTPS TC420

`WebTC420` usa `requests`; token fica na instância. Não utiliza `requests.Session`:
“uma sessão” na arquitetura refere-se à autenticação/token e à rotina HTTP
única, não a uma conexão HTTP persistente. Cada comando inclui `math` aleatório.
TLS é usado com `verify=False` por causa do certificado próprio; avisos de
certificado são desabilitados. Não existe logout implementado.

| Método | Requisição e validação |
| --- | --- |
| `login` | POST com parâmetros `cmd=login`, `uname`, `pwd`, `math`; exige `SUCCESS:LOGIN` e token no quarto campo |
| `approval` | GET com `cmd=approval`, `scale=1`, `token`, `math`; exige `SUCCESS:APPROVAL` |
| `refresh` | GET com `cmd=refresh`, `scale=1`, `token`, `math`; exige `SUCCESS:REFRESH` |

HTTP não bem-sucedido gera erro por `raise_for_status`. Approval/refresh exigem
token prévio. `interpretar_approval` remove `< >`, separa por `;`, reconhece
`00W...`/`W...`, `e=d=`, `Min` e `Max`. Campos não encontrados permanecem `None`.

`interpretar_refresh` exige pelo menos 12 campos: erro, estado, data, hora, id,
balança, bruto, tara, líquido, unidade, modo_tara e multirange. Um 13º campo vira
`extra`. O servidor redistribui somente os seis campos descritos anteriormente.

## TCP direto legado

`ConexaoTC420` acumula bytes e entrega frames fixos de 18 bytes. EOF gera
`ConnectionError`. `extrair_peso_kg` lê `dados[3:10]`, decodifica ASCII e converte
para inteiro; campo vazio resulta em zero. Frame de tamanho diferente ou campo
inválido gera `ValueError`. Conversão para toneladas divide por 1000.
O script raiz `tc420.py` não usa esse buffer: presume limites do `recv` e divide
por 1000, mas imprime unidade `kg`; conservar como utilitário histórico, sem
usá-lo como referência de unidade para o monitor atual.

## Descoberta condicionada à saúde

CHECK só devolve TC420_SERVER_OK quando saudável; caso contrário fecha sem resposta. UDP só envia TC420_SERVER_HERE quando saudável. Antes do primeiro sucesso e após três falhas, nenhuma confirmação. Sucesso reativa ambos. SUBSCRIBE não muda.

## Encerramento de SUBSCRIBE por saúde

Antes de cada envio, SUBSCRIBE consulta saúde. Quando False, registra encerramento e retorna; finally fecha socket e cliente recebe EOF. Clientes existentes entram na busca/candidatura normal. CHECK e UDP continuam condicionados à saúde. A rotina HTTP antiga permanece ativa nesta etapa. Teste real deve terminar ao iniciar contagem de candidatura, antes da promoção, para não disputar a TC420. Desligamento/rebaixamento do antigo principal ainda pendente.

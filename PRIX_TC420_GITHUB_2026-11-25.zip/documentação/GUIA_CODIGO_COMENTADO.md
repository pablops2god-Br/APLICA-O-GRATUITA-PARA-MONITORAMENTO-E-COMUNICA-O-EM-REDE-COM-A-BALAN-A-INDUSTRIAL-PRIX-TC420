# Guia de leitura do código comentado

Atualização: **04/11/2026**. Esta etapa acrescenta explicações ao código existente;
não implementa funcionalidades nem altera os contratos da aplicação.

Nota posterior, **09/11/2026**: a preservação integral da lógica descrita neste
guia refere-se à etapa de comentários de 04/11. Houve depois correções funcionais
na partida do coordenador de saída e na chamada de promoção manual, registradas
em [HISTORICO.md](HISTORICO.md) e [VALIDACAO.md](VALIDACAO.md). A comparação de
integridade daquela etapa não descreve essas alterações posteriores.

## Como começar

Leia primeiro `main.py`: ele cria a infraestrutura compartilhada, procura um
principal e decide entre iniciar como cliente, tentar login automático ou abrir
o formulário manual. As funções internas são callbacks que conservam referências
da mesma execução, como leitor, registros e dono da saída.

Depois, acompanhe o caminho de interesse:

| Arquivos | O que observar nos comentários |
| --- | --- |
| `rede/buscarservidor.py` | Broadcast UDP e confirmação CHECK por TCP; confirmação de protocolo não autentica a identidade do outro computador. |
| `rede/servidor.py` | Leitura HTTPS centralizada, saúde, comandos TCP, trabalhadores, sockets e identificação dos ciclos. |
| `rede/lerdadosserver.py` | CONFIG inicial, posição de sucessão por REGISTER, recepção SUBSCRIBE, frescor, reconexão e candidatura. |
| `tc420/web.py` | Login, token, approval, refresh e interpretação dos campos textuais da TC420. |
| `interface/conexao.py` | Coleta dos campos no Tk, trabalho de rede no worker e aplicação do retorno na interface. |
| `interface/janela.py` | Apresentação das medições, saúde, última leitura, cópia, menu, promoção e troca de fonte. |
| `interface/ciclo_tk.py` | Fila de resultados, identidade da janela, geração de callbacks e cancelamento lógico. |
| `interface/saida_aplicacao.py` | Pedido de parada, trabalhos em curso, limpeza, prazo e confirmação operacional. |
| `rede/infraestrutura_cliente.py`, `rede/entradas_http.py` | Donos, identidade da instalação, autorização HTTP e adaptadores que acompanham criação, uso e fechamento dos recursos. |
| `config/configuracao.py`, `config/arquivos.py` | JSON, keyring, abertura acompanhada, retenção de arquivos e erros de limpeza. |
| `interface/registro_terminal.py`, módulos de mensagens seguras | Espelho do terminal e tratamento de diagnósticos. |
| Demais módulos operacionais em `rede/` | Cabeçalhos apresentam o papel dos controles de admissão, preparações, atividades permanentes, retentativas e composição de evidências. |
| `tc420/conexao.py`, `tc420/protocolo.py`, `tc420.py` | Transporte e interpretação TCP direta legados, separados do caminho HTTPS principal. |
| `teste_approval.py` | Ensaio manual que pede credenciais e consulta o equipamento; não integra a descoberta automática de testes em `tests/`. |

## Convenções úteis

- `self` é a instância que conserva o estado entre chamadas. Funções externas à
  classe recebem explicitamente suas dependências.
- Um callback é uma função entregue a outro componente para execução posterior.
  Por exemplo, `fonte_dados` permite ao monitor observar dados sem decidir como
  eles foram recebidos.
- `Lock` protege decisões e dados compartilhados entre threads. `Event` comunica
  uma condição, como parada solicitada ou configuração recebida.
- `try/finally` mantém a etapa de finalização mesmo quando ocorre uma exceção.
  Tentar fechar e comprovar fechamento são etapas distintas nos registros.
- `root.after` agenda trabalho na interface. Os workers publicam resultados na
  fila; cancelar uma operação logicamente não força a thread a terminar.
- Identidades de aplicação, geração, tentativa, ciclo e recurso têm escopos
  diferentes. Elas impedem associar uma evidência à execução errada.
- Um retrato é uma consulta de estado. Retorno do coordenador, thread terminada,
  recurso fechado e confirmação operacional são evidências diferentes.

## Como ler os testes

Os 71 arquivos Python de `tests/` receberam comentários de orientação. Nas suítes,
os cabeçalhos explicam a leitura por preparação, substituição de dependências e
asserções. Grupos de casos e métodos `setUp`/`tearDown`, quando presentes, têm
indicações de organização e isolamento.

`test_silencio_subscribe_cliente.py` e `test_interface_monitor_visual.py` também
receberam explicações individuais dos cenários: prazo de silêncio, linhas
parciais, candidatura, leitura antiga, cores operacionais, clipboard, popup,
exportação e reconfiguração. Os comentários não substituem as asserções: elas
definem o resultado efetivamente exigido por cada caso.

`ensaio_visual_tk.py` é um harness de inspeção manual com widgets Tk reais e
dependências controladas. Ele não é uma homologação física da balança.

## Escopo implementado e limites

Foram acrescentadas **746 linhas de comentários `#` em 101 arquivos Python**:
30 arquivos operacionais/auxiliares e 71 arquivos em `tests/`. Os módulos centrais
receberam explicações de classes, funções e métodos; módulos de apoio também
receberam cabeçalhos de responsabilidade. Não se trata de anotação linha a linha
de todos os testes ou de todos os módulos experimentais.

As docstrings anteriores foram preservadas. Os novos comentários esclarecem
detalhes efetivos, como o uso de `params` no POST de login, valores de refresh
mantidos como texto, backend de keyring definido pelo ambiente e ausência de
chamada a `_autorizar_http` dentro de `refresh`.

A confirmação operacional da saída não certifica encerramento global. A suíte
simulada não comprova comunicação com a TC420, comportamento de firmware ou
funcionamento em vários computadores físicos. Nenhuma nova proposta funcional
foi implementada nesta etapa.

## Preservação e verificações

O commit local **`638ab73`**, criado antes desta edição, preserva o estado
encontrado, inclusive as docstrings que já estavam modificadas em quatro arquivos.
Os comentários desta etapa ficaram disponíveis no diretório de trabalho para revisão.

Em relação a esse commit, os 101 arquivos Python alterados passaram por:

- Comparação da árvore sintática (AST), sem posições de linhas: idêntica.
- Comparação de tokens, desconsiderando comentários e quebras não executáveis:
  idêntica, incluindo strings, docstrings, assinaturas e instruções.
- Comparação textual: somente inserções de linhas de comentário; nenhuma linha
  anterior removida ou substituída.
- Compilação em memória, sem gerar caches Python.
- `python -B -m unittest discover -s tests -q`: **1.980 testes simulados
  aprovados em 27,878 s**.

A verificação de integridade ignora números de linha: comentários deslocam a
posição mostrada por editores e tracebacks, mas não alteram a lógica executável.
Não houve teste físico, login real, execução dos ensaios manuais ou push.

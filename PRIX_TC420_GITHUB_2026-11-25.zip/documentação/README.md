# Documentação técnica PRIX TC420

Consulte o [README principal](../README.md) para instalação e limites atuais.
Esta é uma cópia de publicação, com dados operacionais substituídos por exemplos.

- [Arquitetura](ARQUITETURA.md) e [módulos](MODULOS.md).
- [Protocolos](PROTOCOLOS.md) e [API](API.md).
- [Administrador](ADMINISTRADOR_OPERACIONAL.md).
- [TCP local](TCP_LOCAL.md).
- [Sucessão recorrente](SUCESSAO_RECORRENTE_AB.md).
- [Supervisão](SUPERVISAO_PRINCIPAL.md).
- [Executável](EXECUTAVEL_WINDOWS.md) e [firewall](FIREWALL_WINDOWS.md).
- [Validação](VALIDACAO.md) e [ensaio de uma hora](RESULTADO_2B3_UMA_HORA.md).
- [Publicação](PUBLICACAO_GITHUB.md) e [histórico](HISTORICO.md).

Documentos de investigação e entradas antigas registram o estado de sua época;
não substituem os contratos posteriores. TCC, conversas e capturas de trabalho
ficam fora desta cópia. Nenhum resultado anterior foi reexecutado pela simples exportação.

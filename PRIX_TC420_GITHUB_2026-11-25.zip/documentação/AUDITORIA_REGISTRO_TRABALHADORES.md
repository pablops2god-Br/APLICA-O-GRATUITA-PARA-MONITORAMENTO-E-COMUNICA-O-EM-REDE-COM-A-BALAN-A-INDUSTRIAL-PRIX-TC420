# Etapa 2B.1 — auditoria dos contratos de RegistroTrabalhadores

Investigação posterior 2B.4 em [INVESTIGACAO_RETENCAO_POR_CICLO.md](INVESTIGACAO_RETENCAO_POR_CICLO.md):
medição de raízes externas e incompatibilidade reproduzida de parada tardia
quando registro_atual é substituído por resumo. Nenhuma ativação automática.

Atualização de 12/11/2026: a etapa 2B.2 implementou representação compacta apenas
para reservas sem recurso comprovado e sem erro/pendência. Tokens e diagnósticos
continuam integrais. Decisão, resultados e limitações em
[COMPACTACAO_REGISTRO_TRABALHADORES.md](COMPACTACAO_REGISTRO_TRABALHADORES.md).
As descrições de implementação pendente abaixo registram a situação da auditoria
original de 09/11; não significam que a nova representação apague entradas.

Data: 09/11/2026. Escopo: leitura dos produtores, consumidores, estados e testes
do registro operacional. **Compactação interna não implementada nesta etapa.**
Servidor, supervisão, B2/B3 e terminal mantêm o comportamento anterior.

## Referências retidas e origem do crescimento

`rede/servidor.py:634–874` contém as identidades, entradas e o registro.

| Referência | Retenção atual | Consequência para a compactação |
| --- | --- | --- |
| `threads` | Lista de objetos Thread admitidos, inclusive encerrados e com start que lançou exceção | Não remover por `is_alive() == False` isoladamente; uma partida pode ser ambígua e o socket continuar pendente |
| `_reservas_socket` | Uma `_CriacaoSocket` por ID, com token, estado, recurso e resultado de limpeza | Entradas resolvidas permanecem no dicionário; sockets fechados ainda têm referência Python |
| `_ReservaCriacaoSocket.dono` | Referência de volta ao registro; a entrada retém o mesmo token | Há um ciclo de referências e tokens externos podem manter o registro alcançável; coleta de lixo não remove entradas de um registro ainda utilizado |
| `erros_limpeza` | Lista de textos/categorias, sem política de descarte | Erros impedem confirmação e não são candidatos ao descarte nesta intervenção |
| `ControleCicloServidor._historico` | Entrada por ciclo, retendo o registro completo até compactação explícita | Otimizar o registro não equivale a limitar a quantidade de ciclos históricos |
| `registro_atual` | Registro do ciclo corrente ou resumo após compactação explícita | Evitar substituir um registro ainda necessário para parada/limpeza |

Threads reais normalmente liberam seus argumentos de execução ao terminar,
mas o registro ainda conserva o objeto Thread. Não se presume que todo objeto
aceito pela API ou usado nos testes tenha essa mesma liberação interna.

Em `servidor_tcp` (`rede/servidor.py:540`), a reserva antecede `accept()`.
Cada `socket.timeout` publica `sem_alocacao_comprovada=True`, gerando uma entrada
`sem_recurso` que continua retida. Portanto, existe crescimento mesmo sem novas
conexões aceitas. O timeout configurado é de um segundo; isso não constitui uma
medição de taxa real ou de consumo em operação prolongada.

## Consumidores diretos e indiretos

| Consumidor | Dados consultados / contrato que depende deles |
| --- | --- |
| Métodos de `RegistroTrabalhadores` | Validação por tipo, dono e identidade exata do token; transições, retornos repetidos, fechamento e resultado do handler |
| `_criar_socket_do_ciclo`, `servidor_tcp`, `servidor_descoberta` | Reserva antes de alocação; associação, publicação e resolução conservadora de falhas |
| `_atender_cliente_do_ciclo`, `_finalizar_cliente_handler`, `_encerrar_socket_do_ciclo` (`servidor.py:470–537`) | Publicação da limpeza do handler, fim de uso e fechamento; callbacks tardios ainda precisam reconhecer o token |
| `solicitar_parada_ciclo` (`servidor.py:75`) | Acessa diretamente recursos de `_reservas_socket` sob lock e faz shutdown fora dele |
| `limpar_sockets` | Captura tokens sob lock e chama fechamento depois; remover entradas entre essas operações não pode invalidar o contrato |
| `obter_situacao` / `encerramento_confirmado` | Threads vivas, erros, prova de sockets encerrados e diagnóstico individual por criação |
| `iniciar_servidor` (`servidor.py:1392`) | Admissão, limpeza normal/parcial, cópia de `threads` para join e publicação dos erros antes da finalização |
| `ControleCicloServidor.finalizar`, `_situacao_historica_sob_lock`, `tentar_iniciar` | Consultam diretamente threads/erros/gate e prova de sockets; pendência impede outro ciclo |
| `consultar_historico_ciclo_servidor` → `avaliar_encerramento_tentativa` | Conserva prova de encerramento pela identidade original, mesmo após novo ciclo |
| Avaliação agregada das tentativas (`servidor.py:1233`) e `interface/saida_aplicacao.py:304–316` | B2 depende da confirmação de cada tentativa, não apenas do retorno do coordenador |
| `rede/supervisao_principal.py:63–67` | A recuperação exige retorno do coordenador e avaliação confirmada; memória reduzida não pode antecipá-la |
| `consultar_estado_ciclo_servidor` (`servidor.py:107`) | Consulta compatível do ciclo atual; seu campo `trabalhadores_encerrados` considera gate, threads e erros, sem incluir prova de sockets |
| `prototipos/guarda_criacao_sockets.py:31` | Subclasse experimental usa lock/gates/threads herdados e mantém `_criacoes` separado; não confundir com o dicionário operacional |
| Testes de guarda integrada, handlers, B2, avaliadores e supervisão | Verificam estados, tamanho/ordem de diagnósticos, acesso a `threads`, tokens e impedimento de compactação com pendências |

O campo `trabalhadores_encerrados` da consulta atual **não substitui**
`avaliar_encerramento_tentativa()['encerramento_confirmado']`. Essa diferença
preexistente foi registrada; a auditoria não altera os critérios públicos.
Registros de recursos de cliente em outros módulos são estruturas distintas.

## Critérios de resolução

| Estado da criação | Elegibilidade operacional para redução de referências |
| --- | --- |
| `reservada`, `alocada`, `publicada` | Preservar integralmente: criação ou uso ainda podem estar ativos |
| `aguarda_limpeza` | Preservar: fim de uso não comprova fechamento |
| `fechando` | Preservar: chamada a fileno/close ocorre fora do lock e ainda publicará resultado |
| `criacao_incerta` | Preservar: ausência de handle conhecido não comprova ausência de alocação |
| `erro_limpeza` | Preservar, incluindo erro e recurso; não há confirmação de liberação |
| `sem_recurso` | Candidato somente após prova explícita de ausência de alocação, sem responsabilidade de handler pendente ou erro |
| `fechada` | Candidato somente após fechamento comprovado, sem uso, pendência ou erro de handler e sem publicação em andamento |

Esses são critérios de elegibilidade, **não autorização para apagar a entrada**.
O predicado atual de sockets exige todos em `fechada`/`sem_recurso`, nenhuma
limpeza de handler pendente e nenhum erro de fechamento de handler. A etapa
seguinte deve conservar esse resultado, sem tornar ausência de entrada uma
prova artificial de resolução.

Para threads, verificar término comprovado e partida resolvida, preservando
responsabilidades associadas independentemente do estado da thread. A API atual
não possui um campo próprio de confirmação do resultado de start nem uma
associação explícita thread→reserva. Essa lacuna exige desenho conservador;
remover threads inativas indiscriminadamente não satisfaz o contrato pedido.

## Por que apagar entradas resolvidas quebra compatibilidade

`_buscar_socket_sob_lock` exige `entrada.reserva is reserva`. Depois de um `del`:

- `fechar_socket(token)` deixaria de retornar True em repetição após resolução;
- `publicar_limpeza_handler(token)` perderia o retorno True de publicação repetida;
- `obter_situacao()['criacoes_socket']` perderia IDs e resultados que hoje expõe;
- um token fabricado com os mesmos campos não pode passar a ser aceito;
- uma publicação de fechamento em andamento poderia tentar atualizar entrada ausente.

Guardar apenas contadores não resolve todos esses casos. Guardar um objeto de
substituição por reserva pode continuar crescendo proporcionalmente ao histórico.
Reconstruir todo o diagnóstico sob consulta também tem custo temporário de memória.
O desenho da 2B.2 precisa explicitar esses compromissos antes de prometer limite.

## Compactação de ciclo já existente

`ControleCicloServidor._compactar_ciclo` (`servidor.py:1371`) troca uma entrada
confirmada por `_ResumoHistoricoCiclo`. Exige coordenador finalizado, publicação
concluída, criação bloqueada, nenhuma thread viva, nenhum erro e sockets resolvidos.
O resumo preserva a confirmação por ID, sem preservar detalhes individuais.

A busca nos módulos operacionais encontrou a definição, mas **nenhuma chamada
operacional a esse método**; há chamadas nos testes. Não existe compactação
automática de ciclos demonstrada pelo fluxo atual. Além disso, o resumo histórico
não revoga referências ao registro que já estejam em tokens ou outros consumidores.
Usar esse mecanismo automaticamente seria uma mudança adicional de ciclo de vida,
fora da implementação desta auditoria.

## Invariantes obrigatórios para a 2B.2

1. Nunca perder thread viva, socket ativo, reserva incerta, erro ou limpeza pendente.
2. Preservar reconhecimento exato de tokens, separação de ciclos e retornos repetidos.
3. Preservar assinatura, tipos e semântica dos diagnósticos existentes; qualquer
   redução de detalhe exige decisão explícita, não mudança silenciosa de API.
4. Manter os predicados de encerramento e a publicação tardia de pendências/erros.
5. Serializar a compactação com transições pelo lock do registro. Respeitar a ordem
   existente controle→registro; não adquirir o controle enquanto segura o registro.
6. Não executar close/join ou trabalho custoso de reconstrução sob lock global/Tk.
7. Não adicionar caminho alternativo de supervisão, recuperação ou encerramento.
8. Comparar estados/retornos antes e depois da compactação, inclusive após o
   retorno do coordenador e após o início de outro ciclo.

## Plano de implementação e validação — ainda proposto

Começar pelo caso frequente `sem_recurso`, desde que a representação compacta
preserve a identidade e as consultas acima. Avaliar separadamente a liberação
de referências a recursos comprovadamente fechados e a retenção de threads.
Não converter erros ou incertezas em contadores de sucesso.

Testes necessários: tokens alheios/fabricados; idempotência; timeout sem alocação;
close bloqueado e publicação concorrente; handler pendente/erro tardio;
start ambíguo; consulta antiga após novo ciclo; compactação repetida; diagnósticos
equivalentes; B2 e recuperação recusadas enquanto qualquer responsabilidade existir.
Acrescentar teste de memória do histórico e consumo temporário da consulta.

Referência anterior, não repetida nesta auditoria:
[MEDICOES_RETENCAO_2026-11-09.json](MEDICOES_RETENCAO_2026-11-09.json):
50.000 reservas resolvidas sem alocação, 50.000 entradas, zero threads/handles,
16.218.200 bytes Python rastreados. A comparação futura deve usar o mesmo método,
carga e ambiente. Não são 50.000 conexões reais, RSS ou memória total do processo.

## Verificações desta auditoria

Leitura dos contratos e busca textual dos consumidores nos módulos operacionais,
protótipos relacionados e testes. Regressão executada nesta etapa:
`python -B -m unittest discover -s tests -q` — **2.031 testes aprovados em 18,844 s**.
Não foram adicionados testes nem alterado código Python nesta solicitação.
Não houve nova medição de memória, teste prolongado ou validação física.

Resultado: 2B.1 documentada; 2B.2 continua pendente. A compatibilidade de tokens
e do diagnóstico individual é a principal restrição para escolher a representação.

# Integração da recuperação manual A/B — 13/11/2026

Atualização posterior: o responsável solicitou [sucessão recorrente A/B](SUCESSAO_RECORRENTE_AB.md).
A restrição automática permanente descrita neste relatório é histórica: agora
há rearmamento condicionado após REGISTER/amostra/prova, com observador também
no monitor manual. Este documento conserva a entrega anterior.

Implementada no código local, por autorização textual do responsável para a
entrega prevista em 14/11/2026. Não instalada nem validada fisicamente nos PCs
nesta etapa. Sem commit, push, reinício de aplicação/PC ou acesso à TC420.
Investigações de memória e Fases 1/2 não foram modificadas.

## Causa e correção

O leitor de recuperação tem `permitir_candidatura=False`, cujo evento também
alimentava a oferta manual. Depois de ambos os PCs serem rebaixados, nenhum
oferecia ASSUMIR. Além disso, o monitor de login manual não recebia callback
de promoção, e a promoção existente era anunciada após start, sem prontidão.

O menu **Opções → Assumir manualmente** usa ação explícita após recuperação.
Não altera o evento de candidatura, não chama o callback automático e funciona
também no monitor originado pelo login manual. Antes de abrir o formulário,
recusa supervisão não vigente, leitor ainda não publicado, CLIENTE com comunicação
atual, ciclo anterior pendente ou promoção já em andamento. O formulário recebe
um callback vinculado à supervisão e ao seu leitor atual, não ao leitor inicial.
O item permanece visível; invocação sem elegibilidade é recusada com diagnóstico.

No worker acompanhado pelo CicloTk/SaidaAplicacao, a recuperação manual:

1. Serializa tentativas por aplicação e avalia positivamente os contextos e
   registros de partidas anteriores. Pendências e resultados desconhecidos bloqueiam.
2. Para os leitores conhecidos, espera seu término por até oito segundos no
   worker e observa as provas de término nos registros existentes. Exige composição
   revalidada de responsabilidades CLIENTE conhecidas, sem recursos/limpezas pendentes.
3. Descobre outro PRINCIPAL com modo estrito: erro de descoberta, recusa de CHECK
   ou resposta UDP esperada sem CHECK válido não equivalem a ausência de servidor.
4. Executa login/approval acompanhados, consulta a fonte TC420 e revalida os
   ciclos e responsabilidades. Faz uma segunda descoberta imediatamente antes
   de preparar a partida, além da checagem de vigência da operação.
5. Retém contexto antes de start e registra a tentativa pelos gates existentes.
   Exceção de start continua ambígua; não é convertida em não execução por
   ausência de thread viva.
6. Espera prontidão e só então entrega resultado ao Tk para anunciar PRINCIPAL.

Se a tentativa falhar, a supervisão recebe solicitação de retomar a descoberta
com nova geração de leitor, sempre sem candidatura automática. A retomada só
ocorre depois da resolução dos ciclos e responsabilidades CLIENTE conhecidos.
Falha de limpeza ou partida incerta pode exigir intervenção/reconfiguração;
não se cria outro leitor para ocultar a pendência. O monitor continua acompanhando
a fonte para aplicar uma nova geração somente após medição válida, com CONFIG.

## Prontidão e cancelamento

O contexto de cada ciclo tem eventos próprios de listener TCP, bind UDP e
primeira amostra HTTP interpretada, além da referência aos três trabalhadores.
A espera de promoção exige os três sinais, trabalhadores vivos, saúde positiva,
amostra do contexto com idade de até seis segundos e ausência de parada/retorno
do coordenador. O prazo padrão é 15 segundos, no worker, sem bloquear o Tk.

O caminho de promoção original em main também revalida a descoberta depois do
login/approval e aguarda essa prontidão. Não anuncia mais sucesso apenas porque
thread.start retornou. A saúde é reinicializada a cada ciclo para não herdar
uma leitura saudável antiga. Login e approval são acesso positivo à fonte; o
refresh efetivo do novo ciclo é obrigatório antes de anunciar promoção.

Timeout ou cancelamento sinaliza um evento persistente no contexto e solicita
parada pelo ID original quando disponível. O evento impede partida tardia que
ainda não reservou ciclo, sem depender do clear do evento global. Contexto,
tentativa e thread continuam retidos pela B2, mesmo com resultado incerto.
Retorno do worker de promoção sem sucesso não prova encerramento do servidor.

## Arquivos de código desta integração

| Arquivo | Mudança |
| --- | --- |
| `rede/promocao_manual.py` | Worker recuperado, provas CLIENTE e espera de prontidão |
| `rede/servidor.py` | Sinais de prontidão/cancelamento por contexto e reset da saúde |
| `rede/supervisao_principal.py` | Retomada controlada do leitor após tentativa manual recusada |
| `rede/buscarservidor.py` | Modo estrito opcional, mantendo compatibilidade padrão e protocolo |
| `interface/saida_aplicacao.py` | Gate local de promoção e avaliação de ciclos/tentativas anteriores |
| `interface/janela.py` | Ação manual independente e acompanhamento das gerações recuperadas |
| `main.py` | Segunda descoberta e prontidão no fluxo de promoção existente |

Testes novos: `test_recuperacao_manual_operacional.py` (15 casos) e
`ensaio_recuperacao_manual_tk.py`. Ampliado `test_supervisao_principal.py` com
oferta manual sem automático e exclusão entre retomada de leitor e promoção.
Fixtures de promoção foram adaptadas à segunda
descoberta e à prontidão simulada; inventário AST inclui o novo consumidor Web.
Os testes de HTTP que simulam só a partida usam prontidão explicitamente falsa
ou positiva no dublê; não são evidência de prontidão real da balança.

## Resultados

- Regressão final: **2.116 testes aprovados em 36,647 s**. Houve falhas intermediárias
  de expectativas/fixtures de descoberta e de auditoria, corrigidas antes desse resultado.
- **145 arquivos Python compilados em memória**, excluídos Navegador model,
  ambientes virtuais, caches e Git. Não gerados pyc para esta verificação.
- `git diff --check` aprovado.
- Ensaio Tk real oculto: menu, callback manual, recusa enquanto conectado e
  atualização das faixas aprovados; sem rede/credenciais.
- Ensaios com servidor, B2, registros e sockets reais em localhost; fonte TC420
  e descoberta LAN simuladas. Cliente de produção recebeu CONFIG e SUBSCRIBE.
- Cobertos nova promoção após encerramento de ciclo anterior no mesmo dono,
  outro PRINCIPAL, descoberta incerta, fonte inacessível, operação HTTP pendente,
  partida ambígua, cliques concorrentes, prontidão parcial e saída B2.
- Testes existentes de reconfiguração, reabertura, B2 e supervisão passaram na
  regressão. A sequência de dois PCs é representada pela composição desses
  ensaios; não houve dois computadores físicos nem troca de papel real na LAN.

## Limitações

Descoberta negativa, mesmo repetida, não é exclusividade distribuída. Partição
de rede ou cliques em PCs diferentes podem produzir tentativas concorrentes.
Nenhum lease, consenso ou novo protocolo foi introduzido. Prontidão é uma
observação local, não promessa de disponibilidade futura. Cobertura global B2
continua desconhecida; positivos se referem às responsabilidades acompanhadas.

O modo estrito foi aplicado à nova recuperação manual; as chamadas antigas de
descoberta preservam o comportamento padrão. Responsabilidade conhecida incerta
continua motivo de recusa. CONFIG após descoberta inicialmente vazia permanece
corrigido; não foi criada atualização contínua de configuração já publicada.
`PasswordDeleteError` permanece uma ocorrência separada e não foi corrigido aqui.

## Validação física objetiva antes da entrega

Usar janela sem pesagem operacional. Instalar a mesma revisão com estas mudanças
em A e B e registrar versão, horários e método das interrupções. Não misturar
um PC com código antigo e outro com código atualizado.

1. Iniciar A como PRINCIPAL e B como CLIENTE; conferir peso/tara, estado e faixas.
2. Interromper controladamente o acesso de A à TC420, mantendo seu aplicativo
   aberto. Aguardar abandono e encerramento acompanhado; promover B pelo fluxo
   manual normal. Confirmar leitura nova e A recebendo B como CLIENTE.
3. Interromper o acesso de B à TC420, mantendo B aberto. Aguardar abandono e
   encerramento dos trabalhadores de B; ambos devem procurar outro PRINCIPAL.
4. Restaurar o acesso à TC420. Em apenas A, selecionar **Opções → Assumir
   manualmente**, informar os dados de conexão e confirmar. Não esperar candidatura
   automática. Só considerar promoção concluída após anúncio de prontidão e
   leitura atual. Registrar recusas se houver pendência, sem forçar outra partida.
5. Confirmar B conectado a A, com leitura atual, tara e W1.1/W1.2 preenchidas.
   Repetir, se a janela permitir, a alternância seguinte B→A→B pela mesma regra.
6. Com CLIENTE conectado, confirmar que a ação manual é recusada. Sem acesso à
   TC420, confirmar que a ação não anuncia PRINCIPAL ativo. Não tentar os dois
   botões simultaneamente como teste de exclusividade, pois não há essa garantia.
7. Encerrar com SIM; guardar confirmações B2 e eventuais pendências. Reabrir e
   confirmar descoberta, leituras/faixas e novo encerramento seguro. Restaurar
   todas as intervenções de rede.

Depois da aprovação física: empacotar executável e testar instalação em etapa
própria. Nenhum executável ou aprovação de produção é declarado por estes ensaios.

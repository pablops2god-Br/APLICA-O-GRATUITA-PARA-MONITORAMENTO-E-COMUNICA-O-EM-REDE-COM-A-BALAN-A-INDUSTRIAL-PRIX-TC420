# Etapa 2B.9 — auditoria e protótipos de recursos resolvidos

12/11/2026. Nenhum código operacional alterado. Sem integração automática,
revogação de tokens, nova política de histórico ou acesso à TC420.

## 1. Mapa das referências e consumidores

| Raiz / consumidor | Referência e uso após resolução |
| --- | --- |
| `RegistroTrabalhadores.threads` | Mantém objetos Thread admitidos, inclusive mortos e starts ambíguos; diagnóstico filtra vivos, encerramento consulta is_alive |
| `iniciar_servidor`: `principais_iniciados` | Lista local das três threads principais; joins normais e na parada; pode manter originais mesmo se outra lista mudar |
| Limpeza parcial de `iniciar_servidor` | Copia registro.threads sob lock e faz join fora dele; snapshot deve continuar válido |
| `ControleCicloServidor` | Retém registro atual/histórico; consulta diretamente threads, erros e prova de sockets, sem depender somente do coordenador |
| `_CriacaoSocket.recurso` | Mantém listener, UDP e clientes mesmo em estado fechada; tokens continuam apontando ao dono/registro |
| `solicitar_parada_ciclo` | Captura recursos sob lock e chama shutdown fora dele, inclusive nos objetos já fechados |
| `fechar_socket` / `limpar_sockets` | Fechamento repetido em fechada/sem_recurso retorna True; demais estados exigem prova/limpeza e podem manter pendência |
| Handler e finalizador | Cliente/token nas variáveis de execução; close e publicação do resultado antes do fim do worker; callbacks tardios ainda reconhecem a reserva |
| `SaidaAplicacao` | Mantém suas próprias threads/contextos/tarefas; pede parada pelo ciclo e avalia prova histórica; lista própria não é registro.threads |
| `SupervisaoPrincipal` | Conserva contexto original e exige retorno do coordenador + confirmação positiva; não usa identidade dos objetos Thread de registro.threads |
| Chamadores e snapshots externos | Podem manter Thread, socket, token ou registro original; coleta depende dessas raízes, não só da alteração do registro |

Fontes: rede/servidor.py, em especial solicitar_parada_ciclo, finalizadores de
handler, RegistroTrabalhadores, ControleCicloServidor e iniciar_servidor;
interface/saida_aplicacao.py e rede/supervisao_principal.py. Referências a target/
args costumam ser retiradas pela Thread padrão após run, mas atributos extras,
tracebacks ou listas externas não são presumidos inexistentes.

## 2. Critérios de elegibilidade

### Threads — protótipo T

Não usa is_alive isolado. Exige Thread padrão, retorno normal de start registrado
pelo próprio protótipo, ident conhecido, join(0) fora dos locks e is_alive False.
Revalida sob lock e exige responsabilidades resolvidas sem erros de limpeza.
Exceção de start, mesmo após executar e deixar ident conhecido, não produz prova
de partida e mantém o objeto. Subclasses/dublês não ganham prova automaticamente.
Ausência definitiva de execução sem ident não tem protocolo próprio neste
protótipo: continua retida, em vez de inferir segurança.

O registro operacional **não contém associação explícita Thread→reservas**. Sem
associação, o protótipo exige todos os sockets conhecidos resolvidos. Durante um
ciclo ativo, listener TCP/UDP publicados impedem essa redução global mesmo com
handlers encerrados. Portanto, ganho após resolver a carga não demonstra ganho
durante operação contínua.

Uma API nova exclusivamente experimental, registrar_com_responsabilidades,
permite declarar reservas originais pertencentes ao mesmo registro. Ela demonstra
liberação de worker terminado com sua reserva resolvida mesmo com listener ativo.
Isso depende de declaração completa/confiável do produtor; não é descoberta
automática de toda responsabilidade do worker. Integrar exigiria desenhar esse
contrato e alterar os produtores conscientemente, não inspecionar args privados
da Thread. Prova do registro não é certificação de recursos HTTP ou atributos
dinâmicos desconhecidos fora do escopo acompanhado.

O resumo conserva nome, ident, native_id, daemon, is_alive False, join repetido
e recusa de start. Mantém tamanho/ordem da lista e resultados dos diagnósticos.
**Não conserva identidade/tipo/API completa de threading.Thread.** O atributo
exposto registro.threads passa a conter ThreadResolvida; mutações posteriores de
nome do original externo não se propagam ao resumo. Essa diferença impede afirmar
compatibilidade pública integral ou integrar sem decisão contratual.

### Sockets — protótipo S

Elegível somente em fechada, sem uso, erro, limpeza de handler pendente ou erro
de fechamento do handler. O estado fechada vem do caminho que comprovou liberação,
não de ler fileno isoladamente. Não faz close/fileno/shutdown sob o lock de
compactação. Retira apenas recurso, preservando a entrada, token e metadados.
Estado publicada com fileno -1 não é elegível; erro de handler conserva o objeto.
Fechamento bloqueado/concor­rente mantém recurso e pendência.

## 3. shutdown tardio: contrato observável

Teste com recurso instrumentado fechado cujo shutdown lança RuntimeError:

- antes da separação, solicitar_parada_ciclo executa a chamada e propaga o erro;
- depois, não encontra o recurso, não chama shutdown e retorna True.

Logo, a retirada altera comportamento observável permitido pela interface atual
de recursos. A bateria existente passar não apaga esse contraexemplo.
Outro teste usa socket nativo criado/fechado sem bind/connect/tráfego: shutdown
no fechado gera OSError tolerado e o retorno público foi True nos dois caminhos.
Nesse caso testado a chamada era redundante para o resultado; não generalizar
para wrappers/subclasses. Uma política de pular shutdown após fechamento exige
escopo e semântica explícitos antes de integração.

Um consumidor que já capturou recurso ou thread mantém sua referência válida;
o protótipo não a revoga. Isso preserva uso do snapshot original e pode impedir
a economia de memória enquanto o snapshot continuar alcançável.

## 4. Protótipos e medições representativas

`prototipos/recursos_resolvidos.py` contém T, S e combinação, sem importação
operacional. `tests/medir_recursos_resolvidos.py --saida resultado.json` reproduz
o grafo da 2B.8: 15.502 reservas, 1.779 sem recurso, 13.723 sockets simulados
fechados e 13.724 threads reais start/join. Sem servidor ou tráfego de rede.
Threads/socket separados e combinados são medidos; nenhuma compressão por faixas.

Fonte: [MEDICOES_RECURSOS_RESOLVIDOS_2B9.json](MEDICOES_RECURSOS_RESOLVIDOS_2B9.json),
Python 3.13.15/win32. Memória em reconstrução separada, GC explícito e tracemalloc;
timings sem tracing. Uma execução por candidato, três consultas/agregados.
Testes em processos separados ocorreram durante parte do ensaio e podem influir
nos tempos; não interpretar pequenas diferenças como ganho estatístico.

| Candidato | Antes da redução | Depois | Originais Thread / referências de socket após |
| --- | ---: | ---: | ---: |
| Atual | 34,316 MB | 34,316 MB | 13.724 / 13.723 |
| T | 36,005 MB | 8,887 MB | 0 / 13.723 |
| S | 34,315 MB | 33,217 MB | 13.724 / 0 |
| T+S | 36,005 MB | 7,788 MB | 0 / 0 |

Todos mantêm 15.502 entradas e 13.724 posições em threads, zero threads vivas,
mesmo diagnóstico completo e confirmação positiva. T substitui objetos por
resumos, não elimina as posições. Antes de reduzir, T já custa aproximadamente
1,69 MB adicionais para registrar provas de partida; esse custo não foi escondido.
No próprio candidato, T libera cerca de 27,12 MB; S libera aproximadamente
1,10 MB de objetos simulados. Não somar porcentagens nem inferir RSS/liberação
de buffers nativos; o grafo simulado não mede tamanho de sockets reais.

Pico de carga T: 36,206 MB; durante redução: 37,530 MB; consulta após: 13,228 MB.
No combinado: 36,205 / 36,442 / 12,130 MB respectivamente. Redução temporariamente
precisa de candidatos/provas e não garante queda imediata do working set.

### Referências externas e custo de manutenção

Mantendo externamente os 13.724 Thread originais, T passou de 36,115 MB para
36,993 MB após resumir: não houve liberação e os resumos acrescentaram custo.
Após soltar essas referências e GC, caiu a 8,886 MB. Não é vazamento: a validade
da referência externa conservou os objetos legitimamente.

| Candidato | Redução total | Posse total / maior trecho de lock | Consulta: posse mediana |
| --- | ---: | ---: | ---: |
| T | 126,850 ms | 60,996 / 53,263 ms | 15,676 ms |
| S | 70,114 ms | 70,102 / 70,102 ms | 19,110 ms |
| T+S | 204,419 ms | 157,720 / 95,233 ms | 19,954 ms |
| Atual, sem redução | — | — | 20,958 ms |

As esperas totais sem concorrência nessas reduções foram da ordem de poucos
microssegundos. Isso não é limite de latência sob carga. Join(0) ocorre fora do
lock, mas preparar/revalidar/substituir milhares de entradas ainda bloqueia o
registro por dezenas de ms. Não foi criada política de frequência/lotes.

Escrita p99 (reserva / registro-start / fechamento), em us: atual
17,5 / 1.354,4 / 49,3; T 18,1 / 852,3 / 49,4; S 16,2 / 625,6 / 46,0;
combinado 17,3 / 823,3 / 50,8. Registro-start inclui partida real do SO e é
sensível ao escalonamento; não há evidência de aceleração de start por resumir
objetos depois. Estatísticas completas n/p95/p99/máximo/lock constam do JSON.

## 5. Encerramento e verificações

Nos quatro modos, B2 real avaliou contexto **já finalizado e resolvido**, retornando
confirmado_operacional; a prova por ciclo permaneceu positiva. Isso não mede
parada de servidor ativo nem segunda falha após promoção. Certificação global
não foi ampliada. Casos pendentes/erros continuam negativos nos testes.

Dez testes novos aprovados: coleta/idempotência, join fora de lock, start ambíguo,
worker vivo, incerteza, vínculo explícito, listener ativo, fileno insuficiente,
erro de handler, fechamento concorrente e diferenças de shutdown/identidade.
Alguns métodos agrupam mais de uma propriedade.

`python -B tests/medir_recursos_resolvidos.py --contratos` executou três baterias
sobrepostas de **116 testes**, usando adaptadores que reduzem referências antes
de obter_situacao: T em **3,017 s**, S em **3,204 s**, combinação em **3,092 s**.
Incluem sockets/handlers/B2/supervisão; não são 348 testes únicos nem novos.

Regressão normal: **2.083 testes em 22,053 s, OK**; **140 arquivos Python
compilados em memória**. Um teste alocou socket nativo sem tráfego para conferir
OSError; os sockets das medições são dublês. Sem TC420 ou novo ensaio físico.

## 6. Conclusão e propostas antes de integração

Auditoria e protótipos 2B.9 concluídos no escopo. Há ganho potencial relevante
em referências de Thread encerrados; nenhum dos candidatos foi demonstrado como
substituto integralmente compatível. Produção permanece intacta.

Antes de integrar seria necessário decidir explicitamente:

1. Se registro.threads deve continuar expondo os objetos Thread originais ou pode
   conter resumos, com quais atributos/operações e semântica de identidade.
2. Como o produtor publica associação completa de responsabilidades para liberar
   handlers enquanto listener/UDP continuam ativos. Sem isso, o modo conservador
   só ajuda depois de todos os sockets conhecidos estarem resolvidos.
3. Se recursos comprovadamente fechados deixam de receber shutdown tardio e se
   tipos/wrappers admitidos precisam de contrato mais restrito. Não esconder erro
   observável para obter economia.
4. Quando executar manutenção, em quais lotes e como tratar referências externas
   para não pagar resumos sem liberar originais.

Nenhuma dessas mudanças foi aprovada/implementada no servidor. Redução pós-parada
não comprova redução durante funcionamento contínuo. Regressão física específica
e validação em rede/carga real permanecem pendentes para qualquer futura integração.

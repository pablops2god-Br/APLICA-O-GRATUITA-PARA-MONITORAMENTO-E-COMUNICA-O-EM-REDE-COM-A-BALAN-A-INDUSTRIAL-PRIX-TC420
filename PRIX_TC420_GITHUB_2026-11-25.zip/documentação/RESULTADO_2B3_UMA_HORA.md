# Etapa 2B.3 — resultado observacional de uma hora

Consolidação de 12/11/2026. Fonte:
[ENSAIO_LOCALHOST_2B3_1H.json](ENSAIO_LOCALHOST_2B3_1H.json), status concluido e
362 fotografias. PID 17416 já não estava ativo na conferência final; stderr vazio.
Nenhum código operacional, parâmetro ou harness foi modificado durante o ensaio.

## Carga e alcance

Servidor operacional TCP/UDP em loopback, portas efêmeras, fonte HTTP sintética,
sem TC420, credenciais, Tk ou comunicação HTTPS. Alternância nominal de 15 s
de tráfego e 15 s de ociosidade, duração de carga 3.600,345 s. Python 3.13.15,
Windows. Foram verificadas 13.721 conexões TCP: 3.431 CONFIG, 3.430 REGISTER,
3.430 CHECK e 3.430 SUBSCRIBE, além de 3.430 consultas UDP. Esses totais não
incluem a verificação adicional do segundo ciclo.

## Início, meio e fim

MB abaixo são decimais. Fotografia final de parada corresponde a 3.601,046 s;
a primeira amostra, a 0,031 s. O meio foi fotografado em 1.800,144 s.

| Indicador | Início | Meio | Fim antes B2 | Após B2 |
| --- | ---: | ---: | ---: | ---: |
| Entradas | 4 | 7.779 | 15.502 | 15.502 |
| sem_recurso | 0 | 887 | 1.778 | 1.779 |
| Threads retidas / vivas | 4 / 3 | 6.892 / 4 | 13.724 / 3 | 13.724 / 0 |
| Sockets referenciados / abertos | 3 / 2 | 6.891 / 3 | 13.723 / 2 | 13.723 / 0 |
| Memória Python rastreada, MB | 0,048 | 18,413 | 36,094 | 36,095 |
| Working set, MB | 39,387 | 78,467 | 115,888 | 120,656 |
| Memória privada, MB | 32,592 | 72,036 | 110,981 | 115,687 |
| Handles do processo | 138 | 143 | 137 | 125 |

Working set é a memória residente coletada pela API Windows; private bytes é
outra métrica, não a diferença entre working set e tracemalloc. Nenhuma delas
identifica isoladamente o consumo do histórico. As fotografias são concorrentes
e refletem diferentes momentos dos handlers.

Nas amostras de carga, threads vivas do registro ficaram entre 4 e 7 e sockets
abertos entre 3 e 6. Nas amostras ociosas, ficaram em 3 e 2, respectivamente.
São faixas **amostradas**, não máximos contínuos. Nenhuma amostra registrou erro
de limpeza. O baixo número ativo não impediu crescimento das referências retidas.

## Memória por entrada e crescimento histórico

| Momento aproximado | Entradas | Python rastreado / entradas, bytes |
| --- | ---: | ---: |
| 15 min | 3.897 | 2.342 |
| 30 min | 7.779 | 2.367 |
| 45 min | 11.653 | 2.352 |
| 60 min, antes B2 | 15.502 | 2.328 |

A razão bruta ficou próxima entre os pontos após aquecimento, compatível com
retenção proporcional ao histórico nesta carga. **Não é tamanho isolado da
reserva**: inclui threads, objetos de socket fechado, amostras do harness,
buffers e outras alocações. Não cabe extrapolar estes valores para dias.
Memória do processo e memória rastreada cresceram; estabilidade de memória não
foi demonstrada. Nenhuma política de descarte foi introduzida.

Entre início e fim antes da B2, acréscimo médio foi de aproximadamente 4,305
entradas/s e 0,494 reservas sem_recurso/s, médias de carga e ociosidade juntas.
No intervalo ocioso final, de 3.590,236 s a 3.600,345 s, entraram 10 reservas
sem_recurso em 10,109 s (cerca de 0,989/s), sem mudança de 13.721 sockets
fechados, 13.724 threads retidas ou 2 sockets abertos. A distinção da ociosidade
é observável sem atribuir a ela as conexões realizadas nas fases de carga.

Não foi coletado um evento por transição/fase: não é possível reconstruir uma
taxa exata exclusiva de todas as fases de tráfego sem suposições entre amostras.
Histórico fechado ao final contém 13.723 entradas de sockets e 1.779 sem recurso.

## Encerramento e reabertura

B2 do primeiro ciclo: **confirmado_operacional em 0,768 s**, sem pendências nem
erros. Avaliação do contexto: ciclo 1 confirmado. Após B2, zero sockets abertos
e zero trabalhadores vivos no registro; apenas uma thread do processo na foto.
O pico Python chegou a 40.444.818 bytes durante a fase de saída, acima da retenção
final de 36.094.594 bytes, coerente com alocações temporárias de diagnóstico e
limpeza; não se atribui todo o pico a uma operação específica.

O harness iniciou realmente um segundo ciclo no mesmo ControleCicloServidor,
validou CONFIG/CHECK/UDP e solicitou nova parada pela B2. Resultado: ciclo 2
confirmado, B2 confirmado_operacional, pendências/erros vazios e sockets encerrados.
Também verificou que o contexto do ciclo 1 continuava confirmado. O resultado
final só foi gravado após essas verificações. Não é uma reabertura da interface.

Certificação global permaneceu False, conforme contrato. Esta aprovação cobre
os recursos acompanhados no ensaio, não todo recurso possível da aplicação.

## Conclusão delimitada e próximos passos

Ensaio de uma hora concluído com comunicação, encerramento operacional e novo
ciclo aprovados no escopo aplicado. Evidenciou crescimento de memória associado
à retenção, sem crescimento equivalente de recursos ativos nas amostras e sem
socket acompanhado aberto após a parada. Não comprova ausência universal de
vazamentos, estabilidade por várias horas ou funcionamento físico da supervisão.

Manter implementação atual por enquanto. Ampliação para várias horas pode ser
planejada usando este mesmo perfil e medições, com janela controlada definida,
sem estabelecer teto arbitrário de memória. Não foi iniciada automaticamente.
Revisão de política histórica exige decisão contratual antes de descartar IDs
ou diagnósticos. Regressão física de segunda perda após promoção e saída/reabertura
permanece pendente de autorização/equipamento.

Verificação desta consolidação: leitura dos artefatos/status/processo e validação
programática das 362 amostras, B2, reabertura e ausência de erros registrados.
Não houve alteração de código ou nova execução de regressão automatizada.

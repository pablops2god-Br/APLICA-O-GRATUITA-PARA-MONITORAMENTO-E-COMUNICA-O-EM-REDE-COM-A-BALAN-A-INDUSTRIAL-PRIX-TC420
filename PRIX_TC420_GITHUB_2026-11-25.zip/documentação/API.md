# Inventário da API Python

## Frescor TCP local — 18/11/2026

`LeitorTCPLocal(..., tolerancia=TOLERANCIA_LEITURA_TCP)` usa 10 s por padrão.
`diagnostico()` inclui frames válidos, intervalo último/máximo e idade;
`registrar_diagnostico(atual)` emite por transição ou 30 s sem histórico de
payload. `notificar_estado` confirma falha TCP por 2 s, sem alterar avisos HTTPS.

## Diagnóstico TCP — 18/11/2026

`rede.tcp_local.ErroTCPLocal` transporta códigos controlados; adaptador de
mensagens da interface retorna somente literais desse catálogo. `LeitorTCPLocal`
expõe `diagnostico()` com contadores/estado, sem payload, e `erro_leitura()`
distingue fase da falha. Não são alterados framing, unidade ou prova B2.

## TCP local — atualização funcional de 13/11/2026

`rede.tcp_local.LeitorTCPLocal(ip, porta)` fornece iniciar(saida), parar(),
obter_dados_atuais() e comunicacao_esta_atual(). `conectar_local` executa admissão,
espera de frame válido e troca de leitores no worker. Não autentica ou cria
servidor. `JanelaTC420.configurar_tcp_local` aplica a fonte; `_iniciar_tcp_local`
é o callback assíncrono de ASSUMIR. Seletor agora despacha TCP ou HTTPS na tela.
Interfaces existentes de promoção HTTPS e certificados B2 permanecem iguais.

## Apresentação integrada 0.0.1

`interface.formularios.montar_formulario(janela, assumir, confirmar)` retorna
entradas, variáveis de salvar/método, botão, checkbox e label de status para os
callbacks existentes. Não autentica ou persiste. `centralizar` calcula posição
inicial. `Dica` mostra texto estático/dinâmico sem capturar foco.
`interface.notificacoes.preparar_monitor(monitor)` vincula recurso opcional ao
Tk; `notificar_estado(monitor, chave)` acompanha disponibilidade sem repetir.
Não modifica APIs de rede, B2 ou protocolo. Método HTTPS/TCP permanece visual.

## Sucessão recorrente — atualização posterior de 13/11/2026

`LeitorDadosServidor.preparar_sucessao_recuperada(autorizar)` instala autorização
local, sem liberar candidatura imediatamente. `_publicar_mensagem_valida` a
rearma após posição positiva e prova positiva; `_aguardar_candidatura` revalida.
`JanelaTC420.iniciar_observacao_candidatura()` inicia um observador por monitor,
inclusive na supervisão de login manual. `tentar_recuperacao_automatica(supervisao)`
usa configuração/cofre apenas depois da fila; sem credenciais habilitadas retorna
False para o formulário manual. Provas, gates e prontidão do promotor permanecem.
Ver [comportamento vigente](SUCESSAO_RECORRENTE_AB.md).

## Acréscimos de recuperação manual — 13/11/2026

- `JanelaTC420.solicitar_promocao_manual()`: oferta explícita no menu após
  rebaixamento; valida contexto vigente e conecta formulário ao leitor atual.
- `SaidaAplicacao.ciclos_aptos_promocao()`: exige avaliação positiva de tentativas
  e contextos retidos; não declara cobertura global.
- `SaidaAplicacao.promocao()`: context manager de exclusão local e trabalho B2.
- `SupervisaoPrincipal.solicitar_retomada()`: sinaliza retomada de leitor sem
  candidatura automática, condicionada à resolução conhecida.
- `rede.promocao_manual.promover_recuperado(supervisao, ip, usuario, senha)`:
  worker operacional, sem Tk; conserva partidas ambíguas e só retorna resultado
  positivo após prontidão.
- `aguardar_prontidao(contexto, saida, prazo=15)`, `interromper_tentativa(contexto)`
  e `cliente_resolvido(infra)`: espera, cancelamento por contexto e prova CLIENTE.
- `buscar_servidor(..., estrito=False)`: nova opção keyword; padrão compatível.
  Nova recuperação usa True para propagar falhas/incerteza de CHECK.
- `ler_tc420(web, contexto_ciclo=None)`: publica amostra no contexto quando informado.
  `ContextoCicloServidor` conserva seu retrato existente; sinais novos são
  `tcp_pronto`, `udp_pronto`, `dados_prontos`, `ultimo_dado_monotonico`,
  `trabalhadores_prontidao` e `cancelar_partida`.

Detalhes e limites: [integração A/B](INTEGRACAO_RECUPERACAO_MANUAL_AB.md).

Inventário extraído do código em 2026-10-07. Os contratos e efeitos
estão em [MODULOS.md](MODULOS.md) e nos documentos temáticos.
Atualizar este inventário quando assinaturas ou arquivos mudarem.

## main.py

Terminal: `instalar_registro_terminal()` e `obter_texto_terminal()` conservam
assinaturas. `obter_exportacao_terminal()` retorna `texto`, `parcial`, limites,
linhas/caracteres retidos/descartados e quantidade de blocos do mesmo retrato.
O retorno de `JanelaTC420.exportar_log()` indica admissão do worker, não término
da gravação; sucesso/erro são apresentados pelo callback Tk.

Supervisão compartilhada: `rede.supervisao_principal.SupervisaoPrincipal(contexto,
saida, infraestrutura=None, *, intervalo=0.1)` expõe `iniciar()`, `cancelar()`,
`obter_leitor()` e `vigente()`. Os eventos `pronto`, `cancelada` e `terminou` têm
escopos distintos: prontidão não comprova medição nem encerramento global.

[Arquivo fonte](../main.py)

- `iniciar_como_cliente(servidor, registro_tentativas=None, infraestrutura_cliente=None, *, vinculo_http=False, contexto_arquivos=None, saida_aplicacao=None)`

- `obter_credenciais_salvas()`

- `iniciar_como_cliente.tentar_promocao_automatica()`

- `iniciar_como_cliente.promover_para_principal(ip, usuario, senha)`

- `iniciar()`

- `tentar_login_automatico()`

## interface/ciclo_tk.py — interface assíncrona B3

- `CicloTk(root, obter_saida)` — fila e geração da janela, thread dona do Tk.
- `iniciar(chave, trabalho, aplicar)` — worker admitido/retido por B2;
  aplicação no Tk com resultado e mensagem segura, sem traceback da requisição.
- `agendar(prazo, callback, *args, encerramento=False)` / `agendar_saida(...)` —
  callbacks protegidos, inclusive observação de saída enquanto B2 está parando.
- `consumir()` — aplica somente resultados da operação/vínculo atual.
- `publicar(callback, *args)` — publicação de dados sem acesso ao Tk.
- `cancelar(chave)` / `fechar()` — invalida operação ou geração, sem afirmar
  fim do worker; fechar também cancela IDs agendados.
- `ciclo(janela)` / `ativa(janela)` — acesso ao controlador e guarda de janela.
- `OperacaoInterface(saida)` — token cancelável do proprietário/vínculo;
  consultado na admissão de trabalho/threads, sem criar revisão temporal nova.

JanelaConexao: `conectar()` coleta campos; `_conectar_operacional(...)` executa
IO no worker; `_aplicar_conexao(resultado, erro)` altera widgets pelo loop Tk.
JanelaTC420: `_iniciar_promocao(trabalho, janela=None)` deduplica e envia a rede
ao worker; `_agendar(...)` e `agendar_saida(...)` usam o scheduler de CicloTk.

## interface/saida_aplicacao.py — proprietário e coordenação B1/B2

- `SaidaAplicacao(*, prazo=10, intervalo=0.05)` — proprietário por execução,
  com prazo por tentativa operacional e intervalo de observação no worker.
- `configurar(infraestrutura=None, registro=None)` — associa a montagem e retém
  registros de tentativas; não admite outro proprietário na mesma infraestrutura.
- `identidade_interface` — identidade opaca do vínculo B1 atual, para validar
  resultados e admissões de operações B3 sem consultar o papel atual do PC.
- `trabalho()` / `executar(funcao, *args, **kwargs)` — admissão e contagem de
  inicialização/login/promoção; novas entradas recusadas após SIM.
- `acompanhar_leitor(leitor)` / `acompanhar_contexto(contexto)` — retenção por
  instância; o contexto recebe o sinal de parada da execução.
- `iniciar_thread(thread)` — acompanha a partida antes de start, sem lock
  durante start; retorna False quando a admissão já fechou. Start incerto não
  comprova ausência.
- `iniciar_servidor_thread(thread, contexto, registro, tentativa)` — mesma
  partida com resolução explícita da recusa antes de iniciar o servidor.
- `vincular(origem, solicitar_parada=None)` — callback revogável por substituição;
  recusa novo vínculo depois do pedido. Destino capturado, invocado fora do lock.
- `conectar_interface(callback, agendar, concluir, informar=None)` — configura
  observação via after, feita somente pela thread Tk; worker não chama widgets.
- `obter_situacao()` — estado, origem, solicitada, tentativa, pendencias, erros
  sanitizados, erro_encaminhamento e parada_operacional_confirmada. Estados B2:
  parando, confirmado_operacional, timeout e falha. Certificados
  encerramento_confirmado/encerramento_global_confirmado permanecem False.

Nova solicitação durante a coordenação ativa retorna False. Após timeout/falha,
o mesmo callback permite reavaliar sem duplicar uma tarefa de cleanup ainda
ativa. Entrada isolada sem montagem conserva estado encerramento_pendente_b2.

APIs operacionais auxiliares B2:

- InfraestruturaRegistrosCliente: propriedade saida_aplicacao,
  instalar_saida(saida), bloquear_novos_trabalhos(),
  tarefas_encerramento(leitores=(), *, limpar_retidos=False) e
  pendencias_encerramento(). Limpeza é devolvida em tarefas, não executada no Tk.
- RegistroRecursosCliente: identidades_para_encerramento() e
  interromper_e_fechar(identidade), com shutdown/close fora do lock.
- rede.servidor: solicitar_parada_ciclo(ciclo_id), protegida contra identidade
  divergente; iniciar_servidor consulta o sinal ligado ao contexto, sem alterar
  sua assinatura nem os formatos dos retratos.
- JanelaTC420/JanelaConexao: informar_encerramento_pendente(estado), aviso com
  estado estático, sem texto de exceção ou credenciais.

JanelaConexao.__init__ aceita o novo keyword opcional saida_aplicacao=None após
contexto_arquivos; os demais parâmetros permanecem. encerrar_aplicacao recebe
o keyword privado _encaminhada=False para delegação sem recursão do callback.
O callback público dos monitores é fechado sobre o vínculo emitido; não é uma
busca dinâmica pelo monitor ou geração atual. Contrato e limites em PRONTIDAO.

## tc420.py

[Arquivo fonte](../tc420.py)

Sem classes ou funções declaradas neste arquivo.

## teste_approval.py

[Arquivo fonte](../teste_approval.py)

Sem classes ou funções declaradas neste arquivo.

## config/__init__.py

[Arquivo fonte](../config/__init__.py)

Sem classes ou funções declaradas neste arquivo.

## config/configuracao.py

[Arquivo fonte](../config/configuracao.py)

- `obter_caminho_configuracao()`

- `existe_configuracao()`

- `salvar_configuracao(nome_rede, ip, porta, usuario, salvar_login)`

- `carregar_configuracao()`

- `salvar_senha(usuario, senha)`

- `carregar_senha(usuario)`

- `remover_senha(usuario)`

## interface/__init__.py

[Arquivo fonte](../interface/__init__.py)

Sem classes ou funções declaradas neste arquivo.

## interface/conexao.py

[Arquivo fonte](../interface/conexao.py)

### JanelaConexao

- `JanelaConexao.__init__(self, ao_encontrar_servidor=None, registro_tentativas=None, infraestrutura_cliente=None, *, vinculo_http=False, contexto_arquivos=None, saida_aplicacao=None)`

- `JanelaConexao.conectar(self)`

- `JanelaConexao.carregar_dados_salvos(self)`

- `JanelaConexao.abrir_monitor(self)`

- `JanelaConexao.executar(self)`

## interface/janela.py

[Arquivo fonte](../interface/janela.py)

### JanelaTC420

- `JanelaTC420.atualizar_configuracao(self, configuracao)` — atualiza os rótulos
  de máximo, mínimo e divisão das duas faixas; campos ausentes mostram `—`.

- `JanelaTC420.__init__(self, web=None, configuracao=None, fonte_dados=None, comunicacao_atual=None, candidatura_liberada=None, estado_candidatura=None, ao_promover=None, ao_promover_automaticamente=None, obter_saude_principal=None, servidor_encerrado=None, ao_reconfigurar=None, master=None, ao_fechar=None)`

- `JanelaTC420.abrir_menu_opcoes(self)`

- `JanelaTC420.exportar_log(self)`

- `JanelaTC420.solicitar_reconfiguracao(self)`

- `JanelaTC420.mostrar_info(self)`

- `JanelaTC420.copiar_medicao(self, campo)`

- `JanelaTC420.atualizar_refresh_web(self, reagendar=True)` — `False` aplica
  imediatamente uma troca de fonte sem criar outro loop periódico.

- `JanelaTC420.supervisionar_principal(self, contexto)` — associa/reutiliza a
  supervisão atual; contexto antigo já acompanhado não substitui o novo.

- `JanelaTC420.verificar_candidatura(self)`

- `JanelaTC420.concluir_promocao(self, resultado)`

- `JanelaTC420.abrir_janela_promocao(self)`

- `JanelaTC420.abrir_janela_promocao.confirmar()`


- `JanelaTC420.fechar_janela_promocao(self, janela)`

- `JanelaTC420.iniciar_leitura(self)`

- `JanelaTC420.ler_balanca(self)`

- `JanelaTC420.atualizar_peso(self, peso)`

- `JanelaTC420.fechar(self)`

- `JanelaTC420.executar(self)`

## rede/__init__.py

[Arquivo fonte](../rede/__init__.py)

Sem classes ou funções declaradas neste arquivo.

## rede/buscarservidor.py

[Arquivo fonte](../rede/buscarservidor.py)

- `confirmar_servidor(ip)`

- `buscar_servidor()`
  Procura automaticamente um servidor TC420

## rede/lerdadosserver.py

[Arquivo fonte](../rede/lerdadosserver.py)

### LeitorDadosServidor

- `LeitorDadosServidor.__init__(self, ip_servidor=None, permitir_candidatura=True)`

- `LeitorDadosServidor.obter_dados_atuais(self)`
  Retorna uma cópia do último estado recebido.

- `LeitorDadosServidor.obter_configuracao(self)`

- `LeitorDadosServidor.servidor_esta_respondendo(self)`

- `LeitorDadosServidor.candidatura_esta_liberada(self)`

- `LeitorDadosServidor.definir_estado_candidatura(self, estado)`

- `LeitorDadosServidor.obter_estado_candidatura(self)`

- `LeitorDadosServidor.obter_tentativa_recuperacao(self)`

- `LeitorDadosServidor.obter_max_tentativas_recuperacao(self)`

- `LeitorDadosServidor.registrar_falha_recuperacao(self)`

- `LeitorDadosServidor._aguardar_proxima_tentativa(self)`

- `LeitorDadosServidor.obter_posicao_sucessao(self)`

- `LeitorDadosServidor.aguardar_configuracao(self, timeout=5)`
  Aguarda a configuração ou retorna None ao atingir o timeout.

- `LeitorDadosServidor.iniciar(self)`
  Sobe a thread que mantém o estado atualizado.

- `LeitorDadosServidor.parar(self)`

- `LeitorDadosServidor._aguardar_candidatura(self)`

- `LeitorDadosServidor._manter_atualizado(self)`
  Recebe CONFIG inicialmente e mantém a fonte de peso conectada. Se a descoberta
  inicial não encontrar servidor ou CONFIG falhar antes de sua publicação, repete
  a consulta admitida ao encontrar servidor no loop, antes de REGISTER/SUBSCRIBE.
  Não atualiza continuamente uma configuração já publicada.

## rede/servidor.py

[Arquivo fonte](../rede/servidor.py)

- `definir_configuracao(configuracao)`

- `obter_dados_atuais()`

- `obter_saude_tc420()`

- `solicitar_parada_servidor()`

- `servidor_deve_parar()`
  Retorna uma cópia do último estado conhecido da TC420.

- `ler_tc420(web)`
  Atualiza 'dados_atuais' continuamente a partir da TC420.

- `atender_cliente(cliente, endereco)`

- `servidor_tcp()`

- `servidor_descoberta()`

- `iniciar_servidor(web, evento_inicializacao=None)`
  Inicia o servidor usando uma sessão WebTC420 JÁ autenticada.

## tc420/__init__.py

[Arquivo fonte](../tc420/__init__.py)

Sem classes ou funções declaradas neste arquivo.

## tc420/conexao.py

[Arquivo fonte](../tc420/conexao.py)

### ConexaoTC420

- `ConexaoTC420.__init__(self, ip='192.0.2.21', porta=9800)`

- `ConexaoTC420.conectar(self)`

- `ConexaoTC420.receber(self)`

- `ConexaoTC420.desconectar(self)`

## tc420/protocolo.py

[Arquivo fonte](../tc420/protocolo.py)

- `extrair_peso_kg(dados: bytes)`
  Extrai do frame o peso bruto em quilogramas.

- `extrair_peso_toneladas(dados: bytes)`
  Extrai do frame o peso convertido para toneladas.

- `interpretar_peso(dados: bytes)`
  Mantém compatibilidade retornando o peso bruto em quilogramas.

## tc420/web.py

[Arquivo fonte](../tc420/web.py)

### WebTC420

- `WebTC420.__init__(self, ip='192.0.2.21')`

- `WebTC420.login(self, usuario, senha)`

- `WebTC420.approval(self, escala=1)`

- `WebTC420.interpretar_approval(self, dados)`

- `WebTC420.refresh(self, escala=1)`

- `WebTC420.interpretar_refresh(self, dados)`

- `WebTC420.obter_configuracao(self, escala=1)`

- `WebTC420.obter_estado(self, escala=1)`

## Prazo de abandono

TEMPO_ABANDONO_PRINCIPAL = 25. Saúde inclui inicio_indisponibilidade (tempo monotônico ou None). Após a terceira falha HTTP consecutiva, inicio_indisponibilidade registra time.monotonic(). Uma nova falha concluída após 25 s solicita parada e encerra a leitura. Sucesso limpa o prazo. HTTP em andamento pode atrasar o encerramento. main.py ainda não converte o principal em cliente.

## Detecção do encerramento em main.py

No caminho de login automático de main.py, tentar_login_automatico() cria servidor_encerrado (threading.Event) e devolve esse evento no resultado principal. A thread executa iniciar_servidor(web), registra MAIN: servidor PRINCIPAL foi encerrado. e sinaliza o evento após retorno normal. iniciar() cria observador daemon que aguarda o evento, registra a detecção e inicia LeitorDadosServidor(permitir_candidatura=False) em background. O observador não acessa Tkinter; a descoberta é executada pelo leitor. Monitor permanece aberto e troca a fonte pelo leitor conectado através do callback da interface. Caminhos de login manual e promoção não receberam esse mecanismo. O sinal representa retorno normal, sem distinguir abandono por saúde de parada voluntária; exceção não tratada no servidor não sinaliza o evento.

## JanelaTC420.definir_fonte_dados(self, fonte_dados)

Valida callable, atribui self.fonte_dados e imprime confirmação. Entrada inválida gera ValueError e mantém a fonte anterior. Não executa a fonte, não valida o retorno e não inicia atualização ou troca de modo. Método ainda sem chamadas nesta etapa.

Tipagem da fonte do monitor: construtor aceita Optional[Callable[[], Mapping[str, Any]]]; definir_fonte_dados aceita Callable[[], Mapping[str, Any]] e retorna None. Anotações não acrescentam validação de conteúdo em execução.

## Leitor sem candidatura

LeitorDadosServidor aceita permitir_candidatura=True por padrão. Com False, _aguardar_candidatura retorna False antes de iniciar contagem ou liberar candidatura. Após perda da conexão, o ciclo continua buscando servidores com intervalo de reconexão. CONFIG, REGISTER e SUBSCRIBE permanecem iguais; a posição de sucessão continua registrada. Clientes existentes preservam o padrão True. main.py usa esse modo no observador de encerramento do servidor iniciado por login automático. O parâmetro é definido na criação; não implementa cancelamento de candidatura já ativa nem guarda adicional na rotina de próxima tentativa. A troca da fonte e a parada do leitor ao sair do monitor estão integradas para o login automático.


O evento de encerramento representa retorno normal do servidor, sem distinguir motivo de parada. A integração atual do monitor e cleanup está descrita abaixo.

## JanelaTC420.observar_rebaixamento(self, evento, obter_leitor)

Agenda root.after(1000, verificar). Com evento sinalizado e leitor retornado pelo callback conectado, usa definir_fonte_dados(leitor.obter_dados_atuais) e encerra a observação. Enquanto aguarda, reagenda; com executando=False retorna. Iniciar na thread da interface. Disponível sem chamadas nesta etapa; não encerra o leitor nem verifica primeiro pacote recebido.

## Troca de fonte e encerramento do leitor rebaixado

No principal iniciado por login automático, main.py compartilha leitor_rebaixado e leitor_pronto com o monitor. O observador publica o leitor sem candidatura e sinaliza pronto após iniciar(). Antes de executar(), chama observar_rebaixamento; o callback da interface troca a fonte somente quando servidor_esta_respondendo sinaliza conexão. A mesma janela é mantida. Um finally sinaliza monitor_encerrado e chama parar no leitor existente. Lock serializa criação/início e cleanup; observador verifica fechamento enquanto espera o servidor e não cria leitor após cleanup. A espera usa timeout de 0,1 s, e o cleanup acompanha observador com join de até 1 s. Também cobre erro na construção/agendamento do monitor. Login manual possui integração controlada própria; promoção ainda não possui integração. O sinal de conexão não garante que o primeiro pacote já chegou; main não zera web/configuração nem atualiza cabeçalho. Parar usa o ciclo de vida existente do leitor, sem join adicional da thread TCP.

A referência compartilhada leitor_rebaixado em main.py é anotada como Dict[str, Optional[LeitorDadosServidor]], aceitando None antes da criação e a instância após publicação. Sem mudança de comportamento.

## Encerramento do servidor no login manual

JanelaConexao cria servidor_encerrado (threading.Event) após servidor_iniciado=False. No login manual, thread daemon executa wrapper que chama iniciar_servidor(self.web) com a mesma sessão autenticada; finally registra CONEXAO: servidor PRINCIPAL foi encerrado. e sinaliza evento tanto no retorno normal quanto em exceção. Exceções continuam propagando na thread. Evento não distingue abandono de outro motivo e indica fim da rotina, sem garantir fim de toda thread interna. A detecção recebeu integração posterior com leitor e monitor; veja a seção de integração manual.

## Integração manual do leitor e monitor

No login manual, JanelaConexao mantém leitor_rebaixado e leitor_pronto. Ao iniciar o servidor, inicia também observador daemon; após servidor_encerrado, cria LeitorDadosServidor(permitir_candidatura=False), publica instância, inicia leitor e sinaliza pronto. abrir_monitor conecta observar_rebaixamento ao evento/callback e mantém atualizar_refresh_web. Troca da fonte acontece no callback Tk, quando leitor sinaliza conexão, na mesma Toplevel. Qualquer término da rotina servidor dispara esse fluxo, sem distinguir causa. Nesta etapa não há encerramento do leitor junto com a janela nem cancelamento do observador; integração controlada, não recuperação final para uso contínuo. Login por promoção permanece sem essa integração.

## Callback de fechamento do monitor

JanelaTC420.__init__ aceita ao_fechar=None após master, preservando posições dos parâmetros anteriores. fechar() ignora chamadas repetidas; chama callback sem argumentos após tentativa de desconexão e garante tentativa de root.destroy em finally. Exceção do callback propaga. Nenhuma ligação nova ao callback nesta etapa.

## JanelaTC420.confirmar_fechamento(self)

Chamado pelo X do monitor. Usa messagebox.askyesnocancel com parent=self.root; True registra encerramento, False segundo plano e None cancelamento. Todas as opções mantêm monitor e rotinas ativos. Não chama fechar nem ao_fechar. Sem integração de bandeja nesta etapa.

## Proteção do rebaixamento no encerramento voluntário

JanelaConexao possui encerramento_solicitado (Event). Após aguardar servidor_encerrado, observar_servidor consulta esse evento: se sinalizado, registra encerramento voluntário e retorna sem criar leitor ou sinalizar leitor_pronto; caso contrário preserva rebaixamento. Nenhum botão sinaliza o evento nesta etapa. Esta verificação isolada não resolve ainda corrida entre início e parada do servidor nem sinalização tardia após a consulta; coordenação final de threads, parada e limpeza permanece pendente.

## Rotina isolada de encerramento manual

JanelaConexao.encerrar_aplicacao retorna se encerramento_solicitado já estiver sinalizado; senão sinaliza antes de parar leitor existente e solicitar_parada_servidor quando servidor foi iniciado e evento encerrado ainda não foi sinalizado. Depois destrói root e imprime confirmação. abrir_monitor passa ao_fechar=self.encerrar_aplicacao. Sim do dialog continua apenas registrando escolha; método ainda não acionado pelo X. Criação concorrente do leitor agora é protegida por lock; ainda não aguarda threads nem resolve limpeza de parada na inicialização. root.destroy e log aplicação encerrada indicam fechamento da GUI, sem comprovar encerramento de todas as conexões. Exceção na limpeza pode interromper etapas seguintes; callback ao destruir Tk principal também exige validar destruição posterior da Toplevel pelo finally de fechar antes de ativação.

## Sim condicionado ao callback

confirmar_fechamento agora chama fechar apenas quando resposta=True e ao_fechar não é None. Sem callback informa encerramento não configurado e retorna. Não/Cancelar permanecem apenas logs. O login manual fornece callback; main.py ainda não o fornece para cliente/principal automático. A rotina manual ainda requer coordenação de threads antes de ensaio físico.

## Coordenação do observador e cleanup manual

lock_encerramento protege a consulta de encerramento_solicitado, criação/publicação/início do leitor e sinalização de leitor_pronto no observador. encerrar_aplicacao usa o mesmo lock para sinalizar encerramento e capturar leitor, liberando antes de parar leitor, solicitar parada e destruir Tk. Encerramento primeiro impede criação; observador primeiro publica/inicia leitor antes da captura para limpeza. Não há ainda espera do fim das threads do servidor nem proteção da limpeza do evento global durante inicialização. Log de leitor iniciado pode aparecer após cleanup, pois fica fora do lock; isso não indica leitor reiniciado.

## Sinalização da preparação do servidor

iniciar_servidor aceita evento_inicializacao opcional. Após validar sessão e limpar evento_parada_servidor, chama set no evento fornecido, antes de iniciar threads. Indica somente conclusão do clear, sem garantia de portas TCP/UDP, leitura HTTP ou saúde. Chamada com apenas web preservada; sessão inválida retorna antes de limpar/sinalizar. Não integrado à interface nesta etapa.

## Evento de preparação no login manual

JanelaConexao cria servidor_inicializado (Event) e o wrapper do login manual passa evento_inicializacao=self.servidor_inicializado para iniciar_servidor. O finally de servidor_encerrado permanece igual. Inicializado indica somente clear concluído, não prontidão TCP/UDP/HTTP. Retorno por sessão inválida ou falha anterior à confirmação pode sinalizar encerrado sem inicializado. encerrar_aplicacao ainda não aguarda esse evento; thread dedicada e espera pelo término continuam propostas. Não fazer ensaio físico com Sim até coordenação final.

## Finalização assíncrona manual — etapa atual

finalizar_servidor executa em thread daemon: aguarda inicializado ou encerrado, consultando encerrado a cada 0,1 s; se clear confirmado e rotina ainda ativa solicita parada; aguarda encerrado até 10 s e registra confirmação ou aviso, sem afirmar conclusão no timeout. A espera inicial agora tem prazo monotônico de 10 s. encerrar_aplicacao mantém lock/evento e captura leitor, para leitor fora do lock e inicia auxiliar apenas quando servidor_iniciado. Sem servidor imprime ausência. Não solicita parada diretamente nem destrói Tk. Resultado agora publicado para callback periódico da interface; veja integração final abaixo. JanelaTC420.fechar foi atualizado: com callback apenas solicita parada e preserva monitor; conclusão explícita ocorre no callback periódico após confirmação. Evento encerrado indica término da rotina iniciar_servidor, cujos joins limitados não comprovam término de todas as threads internas.

## Solicitação e conclusão separadas no monitor — comportamento atual

fechar com callback chama ao_fechar e retorna preservando executando e janela. Sem callback chama concluir_fechamento. concluir_fechamento desativa execução, tenta desconectar e destrói root; idempotente. Callback não é limitado a uma chamada enquanto monitor ativo; cleanup externo deve ser idempotente. Exceção do callback mantém monitor aberto. confirmar_fechamento preservado; Sim sem callback continua apenas aviso. Não há ligação nova à confirmação assíncrona nesta etapa.

## Resultado da finalização no loop Tk — integração atual

JanelaConexao.finalizacao_concluida e finalizacao_confirmada comunicam resultado da auxiliar ao Tk. finalizar_servidor confirma resultado True ao receber servidor_encerrado; timeout de 10 s mantém False; finally sempre sinaliza conclusão, inclusive em exceção. encerrar_aplicacao agenda verificar_finalizacao via root.after(100); sem servidor local confirma diretamente. O callback reagenda enquanto pendente, mantém interface aberta se não confirmado e, no sucesso, chama monitor.concluir_fechamento antes de destruir Tk pai. Operações Tk somente no callback da thread principal. A espera inicial agora tem limite de 10 s; timeout mantém encerramento_solicitado sinalizado, sem nova tentativa implementada. Confirmação representa retorno da rotina servidor, sem comprovar threads internas/handlers bloqueados devido aos joins limitados existentes.

## Timeout de inicialização na finalização manual

finalizar_servidor calcula limite_inicializacao com time.monotonic()+10. Enquanto nenhum evento de preparação/término estiver sinalizado, verifica prazo e aguarda encerrado em passos de 0,1 s. No timeout registra aviso, mantém confirmação False e retorna; finally sinaliza conclusão. Interface permanece aberta, sem confirmação de segurança ou nova tentativa. Prazo de término após solicitar parada continua separado (10 s). Timeout inicial não cancela inicialização e servidor pode iniciar depois; proteção para início tardio permanece pendente.

## Supervisão da preparação tardia — etapa atual

JanelaConexao.supervisionar_inicializacao inicia em thread daemon junto ao servidor manual. Aguarda preparação ou término em passos de 0,1 s; se terminado retorna; após preparação, solicita parada quando encerramento_solicitado já sinalizado. Continua aguardando mesmo após timeout da finalização, cobrindo início tardio após clear. Se preparação nunca ocorrer nem rotina terminar, supervisão permanece esperando. Encerramento após consulta da supervisão é coberto pela finalização usual. Supervisão e finalização agora usam solicitar_parada_local para deduplicar solicitações no ciclo atual. Supervisão não altera finalizacao_confirmada/concluida após timeout, logo interface não fecha automaticamente com confirmação tardia.

## Solicitação única da parada local

JanelaConexao.parada_servidor_solicitada inicia False. solicitar_parada_local protege decisão pelo lock_encerramento: repetida retorna False; primeira marca True, libera lock, registra solicitação única, chama solicitar_parada_servidor e retorna True. Supervisão e finalização usam esse método. Controle pertence somente ao ciclo manual atual; não é redefinido para restart/promoção. Flag indica reserva da solicitação, não confirmação da chamada ou parada: se função externa levantar exceção, a flag é restaurada para False; não há retry automático. Deduplicação não evita clear de uma futura inicialização; revisão da ordem de inicialização ainda pendente.

## Guarda da solicitação antes da preparação

solicitar_parada_local agora verifica servidor_inicializado sob lock antes de marcar parada_servidor_solicitada. Antes da confirmação retorna False com aviso, sem chamada global ou alteração da flag. Após clear/set, supervisão pode solicitar normalmente; deduplicação permanece. Garantia restrita ao ciclo atual: evento inicializado deve ser posterior ao clear e não pode ser reutilizado com novo clear global. Agora restaura flag após exceção externa, sem retry automático; chamadores e servidor preservados.

## Falha na solicitação local — comportamento atual

solicitar_parada_local reserva flag sob lock e executa chamada externa fora dele dentro de try. Exceção restaura flag=False sob lock, imprime erro e retorna False; sucesso retorna True e mantém flag=True. Guarda anterior à preparação e deduplicação preservadas. Permite nova tentativa explícita, sem agendamento automático ou novas threads. Pressupõe ausência de efeitos parciais relevantes na exceção. Retorno False também ocorre para solicitação já registrada ou preparação pendente; não distingue esses motivos. finalizar_servidor preservado: ignora retorno e aguarda confirmação por até 10 s, sem garantir que chamada de parada tenha sucedido. Recuperação de resultado não confirmado continua pendente.

## Significado da flag após falha parcial

Em solicitar_parada_local, exceção restaura flag=False inclusive quando a função externa já sinalizou parada. Portanto flag não espelha evento global. Nova tentativa pode repetir Event.set, mantendo True no mesmo ciclo; isso não sinaliza servidor_encerrado. servidor_deve_parar é API pública de consulta, ainda não utilizada para essa decisão. Consultar evento não coordena atomicamente eventual clear de outro ciclo.

## Estados e reconhecimento tardio — comportamento atual

JanelaConexao mantém estado_encerramento aberto/finalizando/falha/encerrado. encerrar_aplicacao marca finalizando sob lock após guarda de repetição, mantendo intenção sinalizada. verificar_finalizacao prioriza servidor_encerrado, ou ausência de servidor local, e conclui janelas na thread Tk; enquanto tentativa pendente reagenda a cada 100 ms; ao fim sem confirmação marca falha, imprime uma vez e continua observando. Término tardio muda falha para encerrado, fecha monitor antes do Tk pai e não exige reinício. concluir_encerramento_confirmado protege repetição por estado; sem servidor imprime mensagem própria sem alegar confirmação de servidor. finalizacao_confirmada continua sendo resultado da auxiliar, não atualização automática para confirmação tardia. Nova tentativa explícita disponível em falha após término da auxiliar; recusada em finalizando/encerrado; encerramento_solicitado nunca é limpo. Estado encerrado usa confirmação disponível do retorno de iniciar_servidor, sem garantir todas as threads internas por causa de joins limitados.

## Recuperação explícita da finalização — comportamento atual

iniciar_tentativa_encerramento decide sob lock: aberto permite; finalizando/encerrado recusam; falha exige finalizacao_concluida e ausência de thread_finalizacao viva. Guarda referência anotada Thread ou None e publica/inicia auxiliar sob lock para evitar janela entre publicação e start; execução longa ocorre fora do lock. Reseta apenas controle de tentativa, preservando intenção de encerramento e flag da parada do ciclo. verificacao_finalizacao_ativa inicia uma única cadeia after de 100 ms, mantida em finalizando/falha e desativada na conclusão. Polling avalia estados/evento sob lock, sem manipular Tk dentro dele. encerrar_aplicacao captura leitor e remove referência sob lock, chama parar fora: tentativas posteriores não repetem cleanup do mesmo leitor. Falha da parada do leitor não possui recuperação própria; remover referência não prova término da thread TCP. Métodos de entrada e polling devem rodar na thread da interface; testes de concorrência na recuperação usaram observador já ativo sem novas chamadas Tk secundárias. Nova tentativa explícita via Sim disponível no modo manual; nenhuma tentativa automática ou restart implementados. Confirmação ainda é retorno da rotina, não comprovação de todas as threads internas.

## Prioridade da confirmação na recuperação

iniciar_tentativa_encerramento agora prioriza servidor_encerrado após rejeitar estados finalizando/encerrado, antes de validar auxiliar anterior ou mudar estado. Evento já sinalizado impede nova auxiliar. Foi reproduzido primeiro pedido em aberto com servidor terminado e sem observador: guarda isolada recusava sem agendamento. encerrar_aplicacao trata essa recusa quando servidor terminou e estado ainda não encerrado: sinaliza intenção, captura/remove leitor sob lock, para fora e garante observador único. Sem conclusão sob lock ou chamada Tk secundária. Se evento sinaliza após consulta, auxiliar pode começar, mas reconhece término e não pede nova parada; polling conclui uma vez. Demais limites dos joins internos e identidade do ciclo permanecem.

## RegistroTrabalhadores — estrutura implementada sem integração

RegistroTrabalhadores implementado em rede/servidor.py. Cada iniciar_servidor cria instância local independente; agora registra apenas os três trabalhadores principais, sem handlers. registrar_e_iniciar protege registro/start com lock, recusa se criação bloqueada e remove referência/propaga exceção de start. bloquear_criacao impede novos registros. obter_situacao retorna gate, nomes das threads vivas por is_alive e cópia de erros; encerramento_confirmado exige gate fechado, nenhuma thread viva e nenhum erro de limpeza. Erros são registrados explicitamente, sem captura automática de trabalhadores; falha de start é propagada, não adicionada a erros_limpeza. Destinado a objetos Thread distintos com uma chamada de início por objeto; não implementa deduplicação de referências repetidas. Os starts principais agora usam registrar_e_iniciar, joins existentes preservados; registro não é exposto externamente nem passado aos handlers. Logo confirmação da classe ainda não abrange todos os trabalhadores do servidor real; passagem por ciclo e integração futura pendentes.

## Registro dos três trabalhadores principais — etapa atual

iniciar_servidor agora inicia os mesmos objetos thread_tcp, thread_udp e thread_dados via registro_trabalhadores.registrar_e_iniciar. Depois do loop/KeyboardInterrupt bloqueia criação antes dos três joins timeout=2 existentes. Após joins imprime nomes de trabalhadores principais vivos consultando obter_situacao; diagnóstico não autoriza fechamento. Handlers ainda iniciam diretamente e não participam do registro. Se segundo/terceiro start falha, referência falha é removida e exceção propaga antes do try do loop: threads anteriores podem permanecer vivas, evento de parada não é sinalizado por esse erro e gate não é bloqueado. Inicialização parcial ainda sem cleanup; corrigir antes de teste físico. Registro continua local sem API externa ou sinal de trabalhadores encerrados.

## ControleCicloServidor — disponível, sem integração operacional

Classe após RegistroTrabalhadores e única instância de módulo
controle_ciclo_servidor. Mantém lock, registro_atual (inicialmente None) e
estado livre/executando/pendente. tentar_iniciar(registro) retorna bool: recusa
executando; em pendente exige encerramento_confirmado do anterior; consulta
e reserva ocorrem sob o mesmo lock. Reserva aceita substitui registro_atual e
marca executando. finalizar(registro) recusa identidade diferente (comparação
is) ou estado diferente de executando; caso aceito, marca livre se confirmado,
senão pendente, retornando True. Retém referência até a próxima reserva.

Cada ciclo deve usar registro novo: diferentemente do protótipo anterior com
token exclusivo, esta implementação usa o registro como identidade e não
protege contra sua reutilização em ciclos distintos. Gate fechado, ausência
de vivos e ausência de erros são requisitos da confirmação. Não espera threads,
não remove erros e não altera o evento de parada. iniciar_servidor ainda não
consulta nem finaliza esse controle; clear, starts, joins e handlers preservados.
Logo não há proteção operacional nova contra sobreposição. Passagem do registro
aos handlers precederá integração do controle; confirmação completa permanece
indisponível enquanto handlers reais estiverem fora do registro.

## Parâmetro de registro no servidor TCP — preparação sem rastreamento

servidor_tcp(registro_trabalhadores=None) preserva chamadas sem argumentos.
Não havia parâmetros anteriores. iniciar_servidor passa seu registro local em
kwargs da thread_tcp, mantendo target e daemon=True. O parâmetro ainda não é
usado no corpo: handlers continuam criados com cliente/endereco e start direto.
Accept, fechamento dos sockets, joins e evento global não foram alterados.
ControleCicloServidor permanece sem chamada operacional. Esta etapa estabelece
apenas o repasse; não confirma término de handlers nem protege reinício.

## Handlers TCP registrados — comportamento atual

Com registro, servidor_tcp inicia handlers por registrar_e_iniciar; None mantém
start direto. Target atender_cliente, args cliente/endereco e daemon preservados.
Recusa fecha cliente sem start. Exceção de start fecha cliente e propaga; finally
externo fecha listener. O loop captura apenas timeout de accept: start falho já
propagava antes. Referência falha é removida, sem registro em erros_limpeza.
Handlers iniciados permanecem no registro; ativos são calculados por is_alive.
Gate e start usam o mesmo lock. Nenhum timeout, corpo de atender_cliente ou
fechamento externo de clientes ativos foi alterado. Joins continuam apenas dos
principais; handler bloqueado pode sobreviver ao listener. Controle global ainda
desconectado; recuperação parcial, reinício seguro e confirmação na GUI pendentes.

## Exclusividade e recuperação parcial — integração operacional atual

iniciar_servidor valida web/token antes de tentar_iniciar no controle compartilhado.
Recusa lança RuntimeError antes de clear, evento de inicialização ou starts, sem
finalizar registro recusado. Reserva aceita entra em try/finally abrangendo clear,
confirmação de inicialização imediatamente seguinte, criação/start, loop e limpeza.
Finally bloqueia criação e chama finalizar com registro do próprio ciclo, inclusive
se o bloqueio falhar. Todo ciclo deve continuar usando registro local novo.

Em Exception, bloqueia criação e solicita parada; erros dessas operações são
registrados separadamente. Copia referências iniciadas sob registro.lock e faz
joins fora dele, com orçamento total de dois segundos por recuperação. Exclui
thread atual com erro registrado; diagnóstico informa gate/vivos/erros. Erro
original propaga por raise; falha de start não vira erro permanente de limpeza.
Erro durante a fase de limpeza normal também é registrado antes da recuperação,
impedindo liberação indevida se um segundo join tiver sucesso.

Joins normais timeout=2 dos três principais, loop e handlers preservados. Gate
fechado impede novos handlers; recuperação acompanha também handlers registrados.
Timeout com sobreviventes mantém pendente sem registrar erro permanente; nova
reserva reavalia referência anterior preservada. Erro relevante de limpeza mantém
bloqueio mesmo sem vivos, sem mecanismo automático para remover erros.

Controle agora protege o clear contra ciclos ativos ou pendentes no mesmo processo.
Não é exclusividade distribuída nem encerramento forçado de sockets. Retorno do
coordenador pode ocorrer com sobreviventes; servidor_encerrado na interface ainda
representa esse retorno. Consumo do resultado efetivo dos trabalhadores na GUI
permanece pendente e não deve ser inferido do log de encerramento existente.

## consultar_estado_ciclo_servidor — leitura do ciclo atual

Consulta pública sem argumentos, junto às funções públicas de controle. Sob
controle_ciclo_servidor.lock captura estado/registro e consulta obter_situacao,
na ordem controle.lock → registro.lock. Sem registro retorna somente estado=livre
e trabalhadores_encerrados=True. Com registro retorna estado,
trabalhadores_encerrados, threads_vivas e erros_limpeza. Confirmação exige gate
fechado, nenhuma thread registrada viva e nenhum erro de limpeza registrado.
As listas retornadas são cópias, não referências às coleções internas.

Consulta não solicita parada, limpa evento, bloqueia criação, finaliza ou libera
ciclo. Pendente/True é válido após término tardio: apenas próxima reserva reavalia
controle. Snapshot descreve o momento da consulta, não garantia permanente.
Resultado refere-se ao ciclo atual do módulo, sem identidade pública ou vínculo
com JanelaConexao; ciclo novo pode substituir anterior entre consultas.
Interface ainda não usa esta função; servidor_encerrado continua significando
retorno do coordenador. Associação ao ciclo correto permanece próxima etapa.

## Identidade numérica integrada — contrato atual

ControleCicloServidor mantém ultimo_ciclo_id=0 e ciclo_id=None inicialmente.
Reserva aceita incrementa contador e associa registro.ciclo_id sob o mesmo lock;
tentar_iniciar permanece bool e recusa não consome ID. finalizar permanece
validando identidade do registro. Registro novo por ciclo; ID retido em pendente.
Sequência local à instância compartilhada, sem persistência ou identidade distribuída.

consultar_estado_ciclo_servidor(ciclo_id=None) captura ID/estado/registro sob mesmo
lock. Sem filtro preserva campos anteriores e acrescenta ciclo_id/correspondencia.
Sem registro: ausente, ID None, estado livre, confirmação True sem argumento ou
None com ID solicitado. ID correto/consulta atual: correspondente, estado,
confirmação e cópias das listas. ID diferente: somente ID atual, divergente e
trabalhadores_encerrados=None, sem estado/listas atribuídos ao antigo. None não
confirma encerramento; sem histórico. Janela ainda não recebe ID nem consome
consulta para fechar. Próxima etapa: analisar caminhos main/conexao antes da
associação. servidor_encerrado e fluxo operacional intactos.

## ContextoCicloServidor — entrega direta por tentativa

Nova classe com _lock, resolvido (Event), ciclo_id=None e erro=None. Chamador cria
um contexto novo por tentativa; nunca reutilizar entre execuções. registrar_reserva
publica ID e sinaliza evento sob lock; registrar_falha publica classificação e
sinaliza. Ambos retornam bool e recusam qualquer alteração após resolução.
Falhas aceitas: sessao_invalida, reserva_recusada, falha_antes_reserva. Qualquer
outra string ou objeto, inclusive exceção, vira falha, sem armazenar detalhes,
URLs ou traceback. Campos são públicos por compatibilidade do desenho: chamador
não deve modificá-los nem limpar evento; aguarda resolvido antes de ler resultado.

iniciar_servidor(web, evento_inicializacao=None, contexto_ciclo=None) mantém
chamadas anteriores. Sessão inválida resolve contexto e retorna; recusa resolve
sem ID e lança RuntimeError. Exceção pré-reserva resolve com falha_antes_reserva
e propaga original, incluindo BaseException. Reserva aceita entrega registro.ciclo_id
no try protegido antes de clear, fora do lock do controle, sem consulta global.
Falha posterior mantém ID entregue, sem transformá-la em falha da reserva.
Evento de preparo permanece imediatamente após clear, separado de resolvido.

Resolução só comprova resultado da reserva, não prontidão ou encerramento.
main/interface ainda não criam contexto: associação manual será próxima etapa,
seguida das vias automática e promoção. Thread do chamador que falha antes de
entrar em iniciar_servidor não pode ser resolvida pelo servidor; futura integração
precisa tratar falha de thread.start do coordenador no próprio chamador.

## Associação de identidade no caminho manual — somente armazenamento

JanelaConexao inicia contexto_ciclo_servidor=None e ciclo_servidor_id=None.
Ao iniciar servidor manual, cria ContextoCicloServidor novo antes da thread,
associa à instância e limpa ID armazenado. Wrapper existente passa contexto local
capturado junto do evento inicializacao, preservando finally/log/servidor_encerrado.
Falha de thread.start resolve contexto como falha_antes_reserva e propaga para
tratamento existente, sem alterar semântica do evento de retorno.

observar_contexto_ciclo(contexto), na thread da interface, recusa contexto que
não é mais o associado. Resolvido permite copiar contexto.ciclo_id (incluindo None
na recusa/falha); caso contrário agenda reconsulta em 100 ms por root.after.
Não faz wait nem consulta global. Monitor continua agendado em 500 ms e fonte
local preservada. ID apenas armazenado: fechar/timeout/retry/estados intactos.
Identidade guarda tentativa própria mesmo após substituição do ciclo global;
callback antigo não sobrescreve novo contexto. Servidor automático/promoção
continuam sem associação e serão tratados depois. Retorno do coordenador não
prova término de trabalhadores; contexto não autoriza encerramento de janelas.

## Contexto no login automático — associação sem mudança de encerramento

tentar_login_automatico cria ContextoCicloServidor após login/configuração, antes
da thread. Wrapper preservado chama iniciar_servidor(web, contexto_ciclo=contexto).
Resultado principal mantém modo/web/configuracao/servidor_encerrado e acrescenta
contexto_ciclo. Não copia ID por consulta global; contexto pode ainda estar pendente
quando retorna. iniciar mantém resultado local durante execução do monitor,
preservando referência. Nenhum novo evento de preparo, espera ou uso para fechamento.

Falha síncrona de thread.start resolve contexto como falha_antes_reserva e segue
tratamento existente, retornando False. Falha assíncrona no servidor resolve seu
contexto, mas wrapper automático continua sem finally: servidor_encerrado ainda
só sinaliza retorno normal. Resultado principal/log de thread iniciada não comprova
reserva ou prontidão. Manual intacto e promoção ainda sem contexto. Unificação
de acompanhamento e consumo da confirmação efetiva permanecem pendentes.
## Controle administrativo integrado — 19/11/2026

`config.administrador` expõe carregar/cadastrar/verificar/salvar_metodo/salvar_tcp
e restaurar. Cadastro persistente é separado da senha da balança. Arquivo inválido
gera erro e não habilita recadastro silencioso. `interface.administrador` fornece
o controlador de telas e `preparar_inicio`, chamado pelo ponto de entrada antes
da rede. Ver [fluxos, armazenamento e limitações](ADMINISTRADOR_OPERACIONAL.md).
Assinaturas existentes de registro do terminal, servidor e supervisão preservadas.

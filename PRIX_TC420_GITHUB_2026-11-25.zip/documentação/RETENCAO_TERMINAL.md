# Etapa 2A — terminal com retenção limitada — 09/11/2026

Esta intervenção trata somente o terminal e sua exportação. O ciclo do servidor,
`RegistroTrabalhadores`, supervisão do PRINCIPAL e garantias B2/B3 não foram
alterados. A compactação de responsabilidades fica para a etapa 2B.

## Política escolhida pelo responsável

- Memória: no máximo **5.000 linhas e 1.000.000 de caracteres**, simultaneamente.
- Remover o prefixo mais antigo quando qualquer limite for excedido.
- Exportar somente o retrato ainda retido, com aviso explícito de cortes.
- Conservar contadores de linhas/caracteres descartados, não o conteúdo removido.
- Nenhuma gravação automática, rotação ou leitura de logs em disco.
- Exportação fora da thread Tk, acompanhada pelo proprietário B2.

Os limites são constantes padrão do módulo; instâncias de `_RegistroTerminal`
aceitam limites menores por argumentos nomeados para ensaios. Não foi criada
opção no formulário nem alteração de `configuracao.json`.

## Contagem e armazenamento

`interface/registro_terminal.py` substitui `StringIO` por uma deque de blocos de
até 4.096 caracteres. Writes pequenos são coalescidos: uma escrita por caractere
não cria um objeto permanente para cada caractere. A retenção é aplicada durante
a admissão dos blocos, inclusive numa chamada maior que o limite.

Linha é um trecho encerrado por LF (`\n`) ou uma última linha parcial não vazia.
Um LF final não cria outra linha vazia. CRLF é preservado no texto comum; a
contagem usa LF. Caracteres são unidades de `str` Python, não bytes UTF-8.

O limite de caracteres pode cortar o começo de uma linha muito longa. Nesse caso
o corte soma caracteres, e uma linha só entra em `linhas_descartadas` quando seu
LF é removido. A exportação explica essa convenção, evitando inventar quantidade
de mensagens: um `print` pode conter várias linhas e vários writes.

Contadores medem o texto **após a sanitização** e somente exclusões por retenção.
Não contabilizam o conteúdo ocultado pelo filtro como corte do histórico. O
contexto de sanitização também é limitado e não conserva o texto já expulso da
janela de retenção.

`obter_texto_terminal()` continua sem argumentos e retorna uma string: agora é
somente o texto sanitizado ainda retido. `instalar_registro_terminal()` conserva
assinatura e retorno, instala uma única vez sob lock e preserva os streams
originais. Não há novos trabalhadores permanentes nem handles de arquivo abertos
pelo registro.

`obter_exportacao_terminal()` acrescenta uma consulta com texto e contadores do
mesmo instante. O aviso é incluído no texto exportável apenas quando houve cortes,
sem ocupar espaço no histórico em memória. Consultas não limpam contadores.

## Segurança e concorrência

Locks protegem admissão, cortes, contadores e retratos. O filtro adicional do
histórico oculta valores rotulados como senha/password/pwd, token, authorization,
API key e cookie até LF, inclusive com rótulo/valor divididos entre writes. Um
separador como `&` dentro do valor não encerra a ocultação. Só contexto já
sanitizado é conservado; não há armazenamento paralelo do valor removido.

Esse filtro não identifica senhas arbitrárias sem rótulo e não substitui a
sanitização na origem, que permanece vigente. O stream original mantém seu
comportamento: o filtro do histórico não apaga retroativamente texto indevido
emitido por uma origem externa no console original. Não se promete captura ou
remoção universal de qualquer informação sensível.

O botão Exportar log mantém seletor e notificações no Tk. Captura do retrato e
gravação UTF-8 executam em um worker pelo `CicloTk`, acompanhado por
`SaidaAplicacao`. Clique duplicado enquanto a exportação está ativa não cria outra
operação. Falhas exibem mensagem controlada. Ao fechar, B2 espera o worker; um
retorno tardio não exibe diálogo numa janela inválida.

Somente texto/contadores do início do trabalho de exportação entram no arquivo;
mensagens posteriores não são acrescentadas. A fila do Tk recebe metadados, não
outra cópia do texto. O retrato e a gravação podem exigir memória temporária
adicional, também proporcional ao limite. Monitores isolados sem proprietário
operacional recusam a exportação com aviso, em vez de criar worker sem dono.

## Medição inicial e comparação

Valores brutos e método: [MEDICOES_RETENCAO_2026-11-09.json](MEDICOES_RETENCAO_2026-11-09.json).
A medição inicial foi registrada **antes da alteração do código do terminal**.
Mesma carga acumulada: mensagens sintéticas ASCII de 62 caracteres, em instâncias
novas, com `tracemalloc`, sem rede, Tk ou credenciais. Python 3.13.15, Windows.

| Mensagens acumuladas | Bytes Python atuais antes | Bytes Python atuais depois | Blocos retidos depois |
| ---: | ---: | ---: | ---: |
| 1.000 | 93.177 | 77.431 | 16 |
| 10.000 | 930.617 | 330.201 | 77 |
| 100.000 | 9.301.025 | 330.912 | 77 |
| 250.000 | 23.251.433 | 331.576 | 77 |
| 500.000 | 46.501.841 | 332.240 | 77 |

Com 500 mil mensagens, antes havia 500 mil linhas/31 milhões de caracteres;
depois ficaram 5.000 linhas/310 mil caracteres. Foram contados 495 mil LF e
30.690.000 caracteres descartados. Nesta carga, o limite de linhas é o primeiro
a atuar. O limite padrão de um milhão também é exercitado em teste com uma linha
de 1,1 milhão de caracteres.

Pico rastreado: 77.502.162 bytes antes e 643.617 depois. Tempos instrumentados
acumulados: 4,174 s antes e 65,233 s depois. Há custo adicional de sanitização,
contagem e retenção; essa execução com tracing e carga local não é promessa de
throughput ou latência de produção. Reproduzir a medição atual com
`python -B tests/medir_retencao_terminal.py`.

Também foi registrada referência inicial para etapa 2B: 50 mil reservas resolvidas
sem alocação conservaram 50 mil entradas, zero referências de threads e zero
handles associados, com 16.218.200 bytes rastreados. Não foram conexões TCP reais
nem prova de vazamento de sockets. Nenhum desses registros foi compactado aqui.

## Verificações e limites

Foram acrescentados 23 testes de retenção/sanitização/concorrência e seis de
exportação assíncrona. O teste anterior do botão foi adaptado para aguardar o
worker e consumir seu retorno no Tk, preservando a verificação do arquivo UTF-8.
Regressão completa: **2.031 testes aprovados em 27,980 s**. Compilação em memória
de 122 arquivos Python e `git diff --check` aprovados.

Um ensaio com Tk real, raiz oculta e arquivo temporário executou cinco callbacks
enquanto a gravação estava bloqueada no worker. Depois exportou o trecho com
aviso de cortes e concluiu a saída B2 com workers encerrados. Sem TC420, transporte
real ou clique humano.

Esses limites controlam o **histórico retido**, não comprovam memória total do
processo constante. Tracemalloc não mede RSS, buffers do console original, todas
as alocações nativas ou referências retidas pelos demais registros. Os contadores
e o próprio harness de medição também ocupam memória. Não houve ensaio de dias
ou semanas, análise estática ou regressão física nesta intervenção. Ensaios
prolongados e compactação segura da etapa 2B permanecem pendentes.

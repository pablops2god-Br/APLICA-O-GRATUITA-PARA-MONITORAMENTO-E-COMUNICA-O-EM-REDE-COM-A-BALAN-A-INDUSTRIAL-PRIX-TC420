# Instalação, execução e diagnóstico

## TCP local oscilando — tolerâncias revisadas em 18/11/2026

Frescor passou de 3 para 10 s desde o último frame válido; socket encerrado é
indisponível imediatamente. Aviso TCP exige falha contínua de 2 s, cancelado se
recuperar antes, sem alterar avisos HTTPS. Monitor continua identificando última
leitura quando a tolerância vence. A mensagem agora menciona TCP local.
Para medir a cadência real, registrar TCP LOCAL: amostra por pelo menos 1 minuto:
intervalos, frames válidos/rejeitados e idade. São metadados, sem payload.
Ver [TCP_LOCAL.md](TCP_LOCAL.md); teste físico após ajuste ainda pendente.

## Falha TCP sem leitura — diagnóstico de 18/11/2026

Modo TCP agora informa causa controlada na interface e imprime fases/contadores
`TCP LOCAL:` no terminal. Conectar o socket não significa receber peso válido.
Se a operação falhar, registrar essas linhas para distinguir zero dados,
formato/incompletude, recusa ou timeout. Relato anterior com ConnectionError
isolado não determina causa física. Não inserir credenciais em logs.

## TCP local implementado — atualização posterior de 13/11/2026

Escolher **TCP** em conexão/ASSUMIR agora usa IP/porta (9800 inicial), sem
usuário ou senha. Campos de credenciais ficam desabilitados. Abre monitor local,
sem servidor, distribuição ou sucessão; não recorre a HTTPS se falhar. Tara e
faixas indisponíveis aparecem como —. HTTPS mantém o comportamento anterior.
Escolha TCP não é salva para início automático; bootstrap do main permanece.
Ver [TCP_LOCAL.md](TCP_LOCAL.md) para limites, B2 e teste localhost.

A descrição de seletor somente visual na entrega anterior registra o estado
da integração visual, agora superado por esta correção funcional.

## Telas integradas 0.0.1 — 13/11/2026

Conexão e ASSUMIR usam o tema preto aprovado, logo suavizada, fontes 14/18,
rodapé e abertura centralizada. Monitor conserva visual, com centro e bandeja
opcional para restaurar quando minimizado. Avisos de sucesso/perda acompanham
transições de disponibilidade sem repetir por amostra. Podem ser suprimidos
pelo Windows. Não substituem o estado mostrado na janela.

**Seletor HTTPS/TCP ainda visual:** HTTPS é o caminho já existente; selecionar
TCP não muda o transporte. Porta 9800 em ASSUMIR é informativa nesta entrega.
Callbacks, fila e provas B2 continuam iguais. Não foram alteradas portas do
servidor ou descoberta. Atalho do rodapé abre ensaio offline separado.

Backup anterior e limites de validação em [INTEGRACAO_VISUAL_001.md](INTEGRACAO_VISUAL_001.md).
Ensaio integrado sem equipamento: `python -B tests/ensaio_integracao_visual_tk.py`.

## Salvar login na conexão e em ASSUMIR — 13/11/2026

ASSUMIR oferece a caixa **Salvar senha e ativar login automático**, inicialmente
desmarcada. Marcada, guarda a credencial no cofre após promoção bem-sucedida e
habilita `salvar_login` no JSON, preservando nome e porta existentes. Desmarcada,
essa tela não altera preferências já guardadas. O menu existente permite
desativar o login automático. A opção não modifica a fila nem dispensa provas
de encerramento e prontidão.

Na tela de conexão, se outro PRINCIPAL surgir enquanto o formulário estiver
aberto, clicar Conectar com a opção marcada agora guarda os dados preenchidos
antes de entrar como CLIENTE. Não autentica na TC420 nesse caminho; portanto,
armazenar a senha não comprova sua validade. IP, usuário e senha precisam estar
preenchidos. A configuração pertence a cada computador/usuário do sistema,
sem distribuição da senha aos outros PCs.

Persistência ocorre no worker. Falha do cofre impede habilitar a opção por esse
novo caminho; falhas são informadas por categoria, sem imprimir credenciais.
Falha ao guardar não desfaz conexão CLIENTE nem promoção concluída. Se o cofre
for gravado e a gravação JSON falhar, poderá permanecer credencial no cofre
sem a nova preferência habilitada; consulte o aviso e tente novamente.

Complemento de ASSUMIR: após tentativa manual sem sucesso, o formulário permanece
aberto para nova tentativa ou fechamento explícito, mesmo com leitor inativo.
Isso não significa promoção autorizada: cada clique revalida as mesmas provas.
Consultar as mensagens `PROMOCAO:` para a etapa/motivo; não inferir erro de senha
apenas de candidatura cancelada. A versão atual imprime
`PROMOCAO: recuperação solicitada; verificando ciclos e admissão.` no início do
worker recuperado. Essa mensagem ajuda a localizar a entrada nesse fluxo, sem
substituir a identificação da revisão instalada nos dois PCs.

Correção de ASSUMIR em 13/11: durante uma promoção em andamento, o leitor CLIENTE
é parado como parte normal do procedimento. O estado inativa dessa parada não
fecha mais o formulário nem cancela o login admitido. Saída explícita e recusas
operacionais continuam valendo. Após atualizar ambos os PCs em janela controlada,
repetir a terceira alternância e guardar o log entre o clique ASSUMIR e o resultado.
Uma falha de autenticação/rede ainda pode recusar a promoção; não confundir com
o cancelamento indevido da própria interface corrigido nesta etapa.

## Sucessão recorrente — regra vigente de 13/11/2026

O PC rebaixado começa sem candidatura e volta à fila após conectar a outro
PRINCIPAL, receber posição por REGISTER e uma leitura válida, com encerramento
anterior comprovado. O log informa candidatura rearmada. Perdendo esse servidor,
aguarda posição × 30 s e tenta promoção automática somente se salvar_login estiver
habilitado e houver credencial no cofre; caso contrário abre ASSUMIR manualmente.
Login automático desativado não impede candidatura manual. Monitor de login manual
agora inicia o mesmo observador, sem duplicá-lo. Ver [roteiro A/B](SUCESSAO_RECORRENTE_AB.md).
A restrição automática permanente descrita abaixo é histórica e foi substituída
por esse rearmamento condicionado, conforme nova instrução do responsável.

## Recuperação manual A/B — integrada em 13/11/2026

Após rebaixamento e encerramento comprovado, usar **Opções → Assumir manualmente**
em apenas um PC quando não houver comunicação atual com outro PRINCIPAL. O
formulário exige entrada manual; candidatura automática continua desabilitada.
A ação pode ser recusada por ciclo/CLIENTE pendente, descoberta incerta, outro
PRINCIPAL, fonte inacessível ou prontidão incompleta. Não forçar partida por
desaparecimento de uma janela. Somente o anúncio de promoção após prontidão e
uma leitura atual sustenta o sucesso nesse fluxo.

A promoção espera até 15 s pela prontidão após start; antes pode esperar até
oito segundos pelos leitores e executar descoberta/login. Essas esperas são no
worker, não um prazo total fixo. Falha solicita parada e mantém o acompanhamento;
busca CLIENTE só retoma com prova de resolução das responsabilidades conhecidas.
Veja [integração e roteiro físico](INTEGRACAO_RECUPERACAO_MANUAL_AB.md).
Esta versão ainda exige validação física em ambos os PCs antes de entrega.

## Terminal recente e exportação — etapa 2A, 09/11/2026

O terminal retém no máximo 5.000 linhas e 1.000.000 de caracteres, descartando o
conteúdo mais antigo quando qualquer limite é ultrapassado. Exportar log continua
gerando `.txt` UTF-8 por escolha do operador, mas contém somente o retrato ainda
retido. Se houve cortes, o arquivo e a notificação informam os contadores. Linha
parcial cortada é contabilizada em caracteres; LF removido conta linha descartada.
Não há gravação automática nem arquivos rotativos. Sem exportação, fechar a
aplicação perde o histórico em memória.

Seletor e notificações ficam no Tk; captura e gravação rodam em worker acompanhado
pela B2. Enquanto ele estiver ativo, outro clique não duplica a exportação. A
saída espera sua conclusão e não apresenta resultados numa janela já invalidada.
Limites, sanitização, desempenho instrumentado e evidências estão em
[RETENCAO_TERMINAL.md](RETENCAO_TERMINAL.md).

## Recuperação após promoção — etapa 1, 09/11/2026

Os caminhos manual, automático e promovido usam agora a mesma supervisão por
contexto. Ao terminar operacionalmente o servidor, aguarda-se prova de término
dos trabalhadores/sockets antes de iniciar leitor sem candidatura. Até uma amostra
válida de outro principal, o monitor preserva a última leitura como antiga.
A janela é reutilizada e a troca é aplicada no Tk. Pedido voluntário de saída
impede recuperação e continua sendo tratado pela B2. Pendência de limpeza não
é ignorada para reconectar. Detalhes em [SUPERVISAO_PRINCIPAL.md](SUPERVISAO_PRINCIPAL.md).

## Prioridade vigente para entrega — 28/10/2026

Consultar [PRONTIDAO.md](PRONTIDAO.md) para a classificação atual de pendências
e os critérios finitos do primeiro teste físico. A expansão temporal está
suspensa após REGISTER. B1 conecta a saída dos monitores a um proprietário por
execução. B2 integra a coordenação: SIM fecha novas admissões e inicia parada,
cleanup e observação fora do Tk. O prazo padrão é 10 s por tentativa. Somente
parada operacional comprovada no escopo acompanhado permite fechar a interface.
Timeout/falha mantém a janela, exibe aviso sanitizado e permite novo SIM; tarefas
ainda ativas não são duplicadas. Certificação global continua desconhecida.
B3 executa a rede de CONECTAR/promoção em workers acompanhados e aplica resultados
pela fila no Tk. Repetir CONECTAR/ASSUMIR durante a operação não cria outro worker.
SIM invalida aplicações tardias; CANCELAR mantém a execução. Ao fechar, os
agendamentos são cancelados e invalidados. A tela de conexão também confirma
saída pelo botão de fechar. Ao encontrar principal, a nova janela cliente abre
depois de encerrar o loop da conexão anterior.
As descrições incrementais abaixo conservam seu contexto histórico; o total de
testes simulados não substitui a verificação visual e física.

O teste com a TC420 ainda não foi realizado nesta fase. Composição sem cobertura
permanece desconhecida, sem declaração artificial de sucesso. O ensaio visual
real do Tk foi aprovado em 30/10/2026; a validação física é o próximo passo ainda
não realizado, e a geração de .exe continua posterior. A abertura inicial de main pode aguardar
descoberta/login antes de criar a primeira janela; a B3 protege os loops ativos.

## Harness do ensaio visual offline — 29/10/2026

Executar na raiz do projeto:

```powershell
python -B tests/ensaio_visual_tk.py
```

O harness constrói `JanelaConexao` e `JanelaTC420` reais e adiciona um painel de
controle com cenários, log e checklist de dez itens. Ele não importa `main.py`.
Antes de construir a tela de conexão, substitui leitura/gravação de configuração,
Credential Manager, descoberta, WebTC420, servidor e parada global por funções
locais. Um desvio que tente usar rede/servidor falha imediatamente. Não são
abertos sockets nem as portas 42100/42101, e nenhum valor é persistido.

Os campos usam apenas valores reservados ao ensaio e a opção de salvar login
permanece desmarcada. Atrasos de conexão e promoção ocorrem nos workers reais de
B3. A fonte de peso é um dicionário protegido por lock. O painel permite sucesso,
timeout, descoberta, atualização de peso, promoção manual/automática, falha de
promoção e uma operação de 12 s para observar o timeout real de 10 s de B2.

Fechar o monitor pelo X apresenta o diálogo real SIM/NÃO/CANCELAR. O checklist
é observacional: o usuário marca cada item e pode copiar checklist e log. A ação
“Reabrir execução” reapresenta o monitor enquanto a execução continua ativa; se
SIM já foi escolhido, encerrar o harness e executá-lo novamente cria uma nova
execução simulada. O resultado só pode ser registrado como aprovado depois da
observação humana; abrir o processo não constitui aprovação visual.

No cenário de operação longa, o harness mantém um worker bloqueado até observar
o estado `timeout` de B2. Isso elimina a dependência da velocidade do usuário para
clicar no X. Três segundos após o timeout, o harness libera o worker. A segunda
tentativa não surge automaticamente: fechar o aviso, aguardar a mensagem de
liberação no log e clicar novamente no X do monitor. O novo diálogo
SIM/NÃO/CANCELAR é aberto por esse segundo pedido; escolher SIM reavalia a parada.
Ausência de diálogo automático é o contrato atual, não uma falha de B2.

O roteiro visual foi aprovado em 30/10/2026, com 10/10 itens após a repetição do
timeout determinístico e da reabertura. O harness permanece útil para regressões
visuais offline, mas sua aprovação não substitui o próximo teste com a TC420 real.

## Ambiente

Uso atual: Windows, Python com Tkinter, rede local com acesso à TC420 e aos PCs.
O ambiente de validação de credenciais usa Python 3.13 e keyring 25.7.0.
O projeto não declara versão mínima de Python nem possui manifesto de dependências
ou empacotamento nesta base. Não há garantia de compatibilidade em todas as versões.

Dependências externas identificadas nos imports: `requests`, `urllib3` e
`keyring`. Keyring instala suas próprias dependências. Preparação manual:

```powershell
python --version
python -m pip install requests urllib3 keyring
python -m pip show keyring
python -c "import tkinter, requests, urllib3, keyring; print('Imports OK')"
```

Executar pela raiz: as imagens são resolvidas por caminhos relativos `assets/...`.
Apenas o JSON resolve caminho absoluto independente do diretório corrente.
Liberação de firewall/rede precisa permitir TCP 42100 e UDP 42101 no principal;
acesso à TC420 usa HTTPS. A porta 9800 é do caminho TCP direto legado, não do
servidor do projeto. Não alterar firewall automaticamente como parte de teste.

## Operação normal

Com salvar_login marcado e senha disponível no cofre, sem servidor, main faz
uma segunda descoberta e tenta login automático. Sucesso abre monitor direto;
falha/desativado/credencial ausente abre tela manual. Servidor na primeira busca
entra cliente sem sequer tentar automático; aparecendo na segunda busca cancela
automático e entra cliente. Não há retry automático do login inicial.

1. No PC desejado como principal, executar `python main.py` sem outro servidor.
2. Informar nome da balança, IP, porta, usuário e senha. Os campos são
   carregados da configuração salva. Marcar salvar login persiste a senha no
   cofre após login e approval; desmarcar remove a senha do usuário atual e
   mantém parâmetros no JSON. A porta não altera a conexão HTTPS.
3. Confirmar obtenção de W1.1/W1.2 e início TCP/UDP/HTTP no console.
4. Em cada cliente, executar `python main.py`; deverá descobrir o principal.
5. Conferir configuração, posição e peso comum aos monitores.

Não iniciar os três PCs sem principal ao mesmo tempo para validar exclusividade:
todos sem servidor na descoberta inicial abrem a tela de login. O fluxo ainda
depende de operação coordenada.

## Recuperação controlada

Com salvar_login e credencial no cofre do cliente, ao liberar candidatura a GUI
reaproveita a promoção automaticamente. Sucesso mantém monitor e não abre
ASSUMIR. Sem credencial, estado liberada permite diálogo manual. Falha agenda
próxima oportunidade e não abre novo diálogo enquanto aguardando. Login segue
síncrono na thread GUI; ainda não há posse exclusiva distribuída.

Para testar a busca no botão, abrir B sem A, manter a tela em B, iniciar A e
clicar CONECTAR em B com campos válidos. B deve registrar login direto cancelado
e entrar cliente sem LOGIN TC420. O fluxo é CONFIG → REGISTER → SUBSCRIBE.
Sem A, permanece login principal. A troca destrói Tk antigo antes do novo.

Encerrar o processo principal, mantendo clientes abertos. Esperar EOF/reset e
busca contínua. O último peso permanece no painel. Cliente registrado recebe
oportunidade após `posição × 30 s`. ASSUMIR solicita credenciais; um clique faz
uma descoberta final e uma tentativa de login/configuração. Sucesso inicia
servidor e troca a fonte no mesmo monitor. Reabrir antigo principal: deve achar
novo servidor e entrar como cliente.

Senha incorreta gera registro da falha e espera de 30 s para próxima oportunidade.
O diálogo permanece aberto em `aguardando`; se encontrar servidor, fecha em
`cancelada/inativa`. Não há envio automático da senha nas oportunidades seguintes.
Realizar os testes sob controle e manter credenciais fora dos logs compartilhados.

## Ferramentas manuais

```powershell
python -m rede.buscarservidor
python -m rede.lerdadosserver
python teste_approval.py
```

Os dois primeiros operam com o servidor do projeto. O terceiro acessa a TC420
diretamente, pede credenciais e imprime token: usar isoladamente. Executar
`python rede/servidor.py` não inicia servidor; requer `iniciar_servidor(web)`
com instância autenticada.

## Diagnóstico

Saúde informativa do principal: primeiro sucesso imprime comunicação HTTP
estabelecida. Erros mostram contador N/3; após terceiro erro seguido imprime
ATENÇÃO uma vez, preservando último peso e listeners TCP/UDP. CHECK não confirma e UDP não anuncia enquanto não saudável; SUBSCRIBE encerra quando não saudável. Falhas 4/3, 5/3
continuam contando sem repetir aviso. Sucesso após não saudável zera contador
e imprime recuperação. Não provocar invalidação real de token em uso normal;
o teste Action not permitted deve ser coordenado com o responsável.

| Sintoma | Interpretação e verificação |
| --- | --- |
| Nenhum servidor encontrado | Verificar processo, sub-rede, UDP 42101 e confirmação TCP 42100 |
| WinError 10054 / conexão perdida | Reset remoto; leitor preserva peso e passa à busca |
| Peso antigo apesar de conexão ativa | Ler console do principal: falha HTTP pode manter SUBSCRIBE ativo |
| Peso zero logo após promoção | Estado inicial do servidor; observar primeira leitura HTTP |
| CONFIG ausente | Configuração inicial vazia, timeout ou erro; GUI usa fallback |
| Campos W1 não mudaram ao trocar servidor | CONFIG não é renovado na reconexão; cabeçalho não é reconstruído na promoção |
| Logs de W1 misturados a peso | Threads imprimem simultaneamente; por si só não é erro |
| ASSUMIR permaneceu após falha | Espera de próxima oportunidade; fechamento depende do estado, não só do Event |
| Interface pausa ao clicar ASSUMIR | Descoberta/login/configuração executam sincronamente na thread GUI |
| Erro ao salvar credencial | Conferir backend, usuário Windows e acesso ao cofre; funções retornam False/None |
| Imagem não encontrada | Executar na raiz e conferir assets |
| Porta ocupada | Verificar processo anterior; start da thread não confirma bind |
| Fechar monitor principal não derruba serviço | Root de conexão oculto ainda vivo; encerrar processo |

## Limitações operacionais atuais

Sem autenticação no protocolo entre PCs; sem grupo por `nome_rede`; sem mecanismo
de posse distribuída; sem renovação de token/logout; sem persistência da ordem;
sem heartbeat de frescor do equipamento; parada voluntária disponível, sem rebaixamento automático.
Somente o fluxo coordenado evita múltiplos acessos HTTP. Mudanças nesses pontos
devem ocorrer em etapas, com atualização dos documentos e testes pertinentes.

## Encerramento de SUBSCRIBE por saúde

Antes de cada envio, SUBSCRIBE consulta saúde. Quando False, registra encerramento e retorna; finally fecha socket e cliente recebe EOF. Clientes existentes entram na busca/candidatura normal. CHECK e UDP continuam condicionados à saúde. A rotina HTTP antiga permanece ativa nesta etapa. Teste real deve terminar ao iniciar contagem de candidatura, antes da promoção, para não disputar a TC420. Desligamento após 25 s implementado; rebaixamento para cliente ainda pendente.

## Parada voluntária do servidor

Evento global evento_parada_servidor e APIs solicitar_parada_servidor()/servidor_deve_parar(). Leitura e SUBSCRIBE verificam evento e usam Event.wait para interromper pausas. TCP accept e UDP recvfrom têm timeout de 1 s para conferir parada; finally fecha sockets. iniciar_servidor limpa evento após validar token, acompanha threads e faz joins de até 2 s por thread. Ctrl+C solicita parada. Chamar em outro processo não afeta o servidor original. Após a terceira falha HTTP consecutiva, inicio_indisponibilidade registra time.monotonic(). Uma nova falha concluída após 25 s solicita parada e encerra a leitura. Sucesso limpa o prazo. HTTP em andamento pode atrasar o encerramento. main.py ainda não converte o principal em cliente.

HTTP em andamento não é cancelado: aguarda retorno/timeout. Joins limitados não garantem fim de toda operação bloqueada; handlers com recv/send bloqueados não são acompanhados individualmente. Reiniciar somente após confirmar que as threads anteriores terminaram; não iniciar servidores concorrentes com o mesmo evento. Saúde, dados, configuração e registros não são zerados automaticamente no restart.

## Detecção do encerramento em main.py

No caminho de login automático de main.py, tentar_login_automatico() cria servidor_encerrado (threading.Event) e devolve esse evento no resultado principal. A thread executa iniciar_servidor(web), registra MAIN: servidor PRINCIPAL foi encerrado. e sinaliza o evento após retorno normal. iniciar() cria observador daemon que aguarda o evento, registra a detecção e inicia LeitorDadosServidor(permitir_candidatura=False) em background. O observador não acessa Tkinter; a descoberta é executada pelo leitor. Monitor permanece aberto e troca a fonte pelo leitor conectado através do callback da interface. Caminhos de login manual e promoção não receberam esse mecanismo. O sinal representa retorno normal, sem distinguir abandono por saúde de parada voluntária; exceção não tratada no servidor não sinaliza o evento.

## Imports no IDE

Em 2026-10-08, requests, urllib3 e keyring importaram no Python C:\Program Files\python.exe, com pacotes no site-packages do usuário. Se Pylance indicar imports ausentes, selecionar esse executável em Python: Select Interpreter no VS Code. O ambiente selecionado pelo IDE não foi inspecionado nesta sessão.

## Leitor sem candidatura

LeitorDadosServidor aceita permitir_candidatura=True por padrão. Com False, _aguardar_candidatura retorna False antes de iniciar contagem ou liberar candidatura. Após perda da conexão, o ciclo continua buscando servidores com intervalo de reconexão. CONFIG, REGISTER e SUBSCRIBE permanecem iguais; a posição de sucessão continua registrada. Clientes existentes preservam o padrão True. main.py usa esse modo no observador de encerramento do servidor iniciado por login automático. O parâmetro é definido na criação; não implementa cancelamento de candidatura já ativa nem guarda adicional na rotina de próxima tentativa. A troca da fonte e a parada do leitor ao sair do monitor estão integradas para o login automático.


O evento de encerramento representa retorno normal do servidor, sem distinguir motivo de parada. A integração atual do monitor e cleanup está descrita abaixo.

## Troca de fonte e encerramento do leitor rebaixado

No principal iniciado por login automático, main.py compartilha leitor_rebaixado e leitor_pronto com o monitor. O observador publica o leitor sem candidatura e sinaliza pronto após iniciar(). Antes de executar(), chama observar_rebaixamento; o callback da interface troca a fonte somente quando servidor_esta_respondendo sinaliza conexão. A mesma janela é mantida. Um finally sinaliza monitor_encerrado e chama parar no leitor existente. Lock serializa criação/início e cleanup; observador verifica fechamento enquanto espera o servidor e não cria leitor após cleanup. A espera usa timeout de 0,1 s, e o cleanup acompanha observador com join de até 1 s. Também cobre erro na construção/agendamento do monitor. Login manual possui integração controlada própria; promoção ainda não possui integração. O sinal de conexão não garante que o primeiro pacote já chegou; main não zera web/configuração nem atualiza cabeçalho. Parar usa o ciclo de vida existente do leitor, sem join adicional da thread TCP.

## Integração manual do leitor e monitor

No login manual, JanelaConexao mantém leitor_rebaixado e leitor_pronto. Ao iniciar o servidor, inicia também observador daemon; após servidor_encerrado, cria LeitorDadosServidor(permitir_candidatura=False), publica instância, inicia leitor e sinaliza pronto. abrir_monitor conecta observar_rebaixamento ao evento/callback e mantém atualizar_refresh_web. Troca da fonte acontece no callback Tk, quando leitor sinaliza conexão, na mesma Toplevel. Qualquer término da rotina servidor dispara esse fluxo, sem distinguir causa. Nesta etapa não há encerramento do leitor junto com a janela nem cancelamento do observador; integração controlada, não recuperação final para uso contínuo. Login por promoção permanece sem essa integração.

## Proteção do rebaixamento no encerramento voluntário

JanelaConexao possui encerramento_solicitado (Event). Após aguardar servidor_encerrado, observar_servidor consulta esse evento: se sinalizado, registra encerramento voluntário e retorna sem criar leitor ou sinalizar leitor_pronto; caso contrário preserva rebaixamento. Nenhum botão sinaliza o evento nesta etapa. Esta verificação isolada não resolve ainda corrida entre início e parada do servidor nem sinalização tardia após a consulta; coordenação final de threads, parada e limpeza permanece pendente.

## Rotina isolada de encerramento manual

JanelaConexao.encerrar_aplicacao retorna se encerramento_solicitado já estiver sinalizado; senão sinaliza antes de parar leitor existente e solicitar_parada_servidor quando servidor foi iniciado e evento encerrado ainda não foi sinalizado. Depois destrói root e imprime confirmação. abrir_monitor passa ao_fechar=self.encerrar_aplicacao. Sim do dialog continua apenas registrando escolha; método ainda não acionado pelo X. Criação concorrente do leitor agora é protegida por lock; ainda não aguarda threads nem resolve limpeza de parada na inicialização. root.destroy e log aplicação encerrada indicam fechamento da GUI, sem comprovar encerramento de todas as conexões. Exceção na limpeza pode interromper etapas seguintes; callback ao destruir Tk principal também exige validar destruição posterior da Toplevel pelo finally de fechar antes de ativação.

## Coordenação do observador e cleanup manual

lock_encerramento protege a consulta de encerramento_solicitado, criação/publicação/início do leitor e sinalização de leitor_pronto no observador. encerrar_aplicacao usa o mesmo lock para sinalizar encerramento e capturar leitor, liberando antes de parar leitor, solicitar parada e destruir Tk. Encerramento primeiro impede criação; observador primeiro publica/inicia leitor antes da captura para limpeza. Não há ainda espera do fim das threads do servidor nem proteção da limpeza do evento global durante inicialização. Log de leitor iniciado pode aparecer após cleanup, pois fica fora do lock; isso não indica leitor reiniciado.

## Abertura do monitor no login manual

Após iniciar thread do servidor, conectar agenda abrir_monitor via root.after(500, ...), sem confirmação de TCP/UDP ativos. O callback executa quando o loop Tk puder atendê-lo após esse atraso; não é uma verificação de prontidão. Inicialização confirmada e espera de finalização na parada continuam pendentes. Um evento futuro deverá sinalizar a transição efetiva do servidor (inclusive tratamento de falhas), pois sinalizar apenas antes da chamada não protege o clear interno da parada, e apenas depois da chamada indica encerramento.

## Evento de preparação no login manual

JanelaConexao cria servidor_inicializado (Event) e o wrapper do login manual passa evento_inicializacao=self.servidor_inicializado para iniciar_servidor. O finally de servidor_encerrado permanece igual. Inicializado indica somente clear concluído, não prontidão TCP/UDP/HTTP. Retorno por sessão inválida ou falha anterior à confirmação pode sinalizar encerrado sem inicializado. encerrar_aplicacao ainda não aguarda esse evento; thread dedicada e espera pelo término continuam propostas. Não fazer ensaio físico com Sim até coordenação final.

## Finalização assíncrona manual — etapa atual

finalizar_servidor executa em thread daemon: aguarda inicializado ou encerrado, consultando encerrado a cada 0,1 s; se clear confirmado e rotina ainda ativa solicita parada; aguarda encerrado até 10 s e registra confirmação ou aviso, sem afirmar conclusão no timeout. A espera inicial agora tem prazo monotônico de 10 s. encerrar_aplicacao mantém lock/evento e captura leitor, para leitor fora do lock e inicia auxiliar apenas quando servidor_iniciado. Sem servidor imprime ausência. Não solicita parada diretamente nem destrói Tk. Resultado agora publicado para callback periódico da interface; veja integração final abaixo. JanelaTC420.fechar foi atualizado: com callback apenas solicita parada e preserva monitor; conclusão explícita ocorre no callback periódico após confirmação. Evento encerrado indica término da rotina iniciar_servidor, cujos joins limitados não comprovam término de todas as threads internas.

## Resultado da finalização no loop Tk — integração atual

JanelaConexao.finalizacao_concluida e finalizacao_confirmada comunicam resultado da auxiliar ao Tk. finalizar_servidor confirma resultado True ao receber servidor_encerrado; timeout de 10 s mantém False; finally sempre sinaliza conclusão, inclusive em exceção. encerrar_aplicacao agenda verificar_finalizacao via root.after(100); sem servidor local confirma diretamente. O callback reagenda enquanto pendente, mantém interface aberta se não confirmado e, no sucesso, chama monitor.concluir_fechamento antes de destruir Tk pai. Operações Tk somente no callback da thread principal. A espera inicial agora tem limite de 10 s; timeout mantém encerramento_solicitado sinalizado, sem nova tentativa implementada. Confirmação representa retorno da rotina servidor, sem comprovar threads internas/handlers bloqueados devido aos joins limitados existentes.

## Timeout de inicialização na finalização manual

finalizar_servidor calcula limite_inicializacao com time.monotonic()+10. Enquanto nenhum evento de preparação/término estiver sinalizado, verifica prazo e aguarda encerrado em passos de 0,1 s. No timeout registra aviso, mantém confirmação False e retorna; finally sinaliza conclusão. Interface permanece aberta, sem confirmação de segurança ou nova tentativa. Prazo de término após solicitar parada continua separado (10 s). Timeout inicial não cancela inicialização e servidor pode iniciar depois; proteção para início tardio permanece pendente.

## Supervisão da preparação tardia — etapa atual

JanelaConexao.supervisionar_inicializacao inicia em thread daemon junto ao servidor manual. Aguarda preparação ou término em passos de 0,1 s; se terminado retorna; após preparação, solicita parada quando encerramento_solicitado já sinalizado. Continua aguardando mesmo após timeout da finalização, cobrindo início tardio após clear. Se preparação nunca ocorrer nem rotina terminar, supervisão permanece esperando. Encerramento após consulta da supervisão é coberto pela finalização usual. Supervisão e finalização agora usam solicitar_parada_local para deduplicar solicitações no ciclo atual. Supervisão não altera finalizacao_confirmada/concluida após timeout, logo interface não fecha automaticamente com confirmação tardia.

## Solicitação única da parada local

JanelaConexao.parada_servidor_solicitada inicia False. solicitar_parada_local protege decisão pelo lock_encerramento: repetida retorna False; primeira marca True, libera lock, registra solicitação única, chama solicitar_parada_servidor e retorna True. Supervisão e finalização usam esse método. Controle pertence somente ao ciclo manual atual; não é redefinido para restart/promoção. Flag indica reserva da solicitação, não confirmação da chamada ou parada: se função externa levantar exceção, a flag é restaurada para False; não há retry automático. Deduplicação não evita clear de uma futura inicialização; revisão da ordem de inicialização ainda pendente.

## Guarda da solicitação antes da preparação

solicitar_parada_local agora verifica servidor_inicializado sob lock antes de marcar parada_servidor_solicitada. Antes da confirmação retorna False com aviso, sem chamada global ou alteração da flag. Após clear/set, supervisão pode solicitar normalmente; deduplicação permanece. Garantia restrita ao ciclo atual: evento inicializado deve ser posterior ao clear e não pode ser reutilizado com novo clear global. Agora restaura flag após exceção externa, sem retry automático; chamadores e servidor preservados.

## Falha na solicitação local — comportamento atual

solicitar_parada_local reserva flag sob lock e executa chamada externa fora dele dentro de try. Exceção restaura flag=False sob lock, imprime erro e retorna False; sucesso retorna True e mantém flag=True. Guarda anterior à preparação e deduplicação preservadas. Permite nova tentativa explícita, sem agendamento automático ou novas threads. Pressupõe ausência de efeitos parciais relevantes na exceção. Retorno False também ocorre para solicitação já registrada ou preparação pendente; não distingue esses motivos. finalizar_servidor preservado: ignora retorno e aguarda confirmação por até 10 s, sem garantir que chamada de parada tenha sucedido. Recuperação de resultado não confirmado continua pendente.

## Estados e reconhecimento tardio — comportamento atual

JanelaConexao mantém estado_encerramento aberto/finalizando/falha/encerrado. encerrar_aplicacao marca finalizando sob lock após guarda de repetição, mantendo intenção sinalizada. verificar_finalizacao prioriza servidor_encerrado, ou ausência de servidor local, e conclui janelas na thread Tk; enquanto tentativa pendente reagenda a cada 100 ms; ao fim sem confirmação marca falha, imprime uma vez e continua observando. Término tardio muda falha para encerrado, fecha monitor antes do Tk pai e não exige reinício. concluir_encerramento_confirmado protege repetição por estado; sem servidor imprime mensagem própria sem alegar confirmação de servidor. finalizacao_confirmada continua sendo resultado da auxiliar, não atualização automática para confirmação tardia. Nova tentativa explícita disponível em falha após término da auxiliar; recusada em finalizando/encerrado; encerramento_solicitado nunca é limpo. Estado encerrado usa confirmação disponível do retorno de iniciar_servidor, sem garantir todas as threads internas por causa de joins limitados.

## Recuperação explícita da finalização — comportamento atual

iniciar_tentativa_encerramento decide sob lock: aberto permite; finalizando/encerrado recusam; falha exige finalizacao_concluida e ausência de thread_finalizacao viva. Guarda referência anotada Thread ou None e publica/inicia auxiliar sob lock para evitar janela entre publicação e start; execução longa ocorre fora do lock. Reseta apenas controle de tentativa, preservando intenção de encerramento e flag da parada do ciclo. verificacao_finalizacao_ativa inicia uma única cadeia after de 100 ms, mantida em finalizando/falha e desativada na conclusão. Polling avalia estados/evento sob lock, sem manipular Tk dentro dele. encerrar_aplicacao captura leitor e remove referência sob lock, chama parar fora: tentativas posteriores não repetem cleanup do mesmo leitor. Falha da parada do leitor não possui recuperação própria; remover referência não prova término da thread TCP. Métodos de entrada e polling devem rodar na thread da interface; testes de concorrência na recuperação usaram observador já ativo sem novas chamadas Tk secundárias. Nova tentativa explícita via Sim disponível no modo manual; nenhuma tentativa automática ou restart implementados. Confirmação ainda é retorno da rotina, não comprovação de todas as threads internas.

## Prioridade da confirmação na recuperação

iniciar_tentativa_encerramento agora prioriza servidor_encerrado após rejeitar estados finalizando/encerrado, antes de validar auxiliar anterior ou mudar estado. Evento já sinalizado impede nova auxiliar. Foi reproduzido primeiro pedido em aberto com servidor terminado e sem observador: guarda isolada recusava sem agendamento. encerrar_aplicacao trata essa recusa quando servidor terminou e estado ainda não encerrado: sinaliza intenção, captura/remove leitor sob lock, para fora e garante observador único. Sem conclusão sob lock ou chamada Tk secundária. Se evento sinaliza após consulta, auxiliar pode começar, mas reconhece término e não pede nova parada; polling conclui uma vez. Demais limites dos joins internos e identidade do ciclo permanecem.

## Silêncio do SUBSCRIBE — comportamento atual

O prazo experimental é `PRAZO_SILENCIO_SUBSCRIBE = 6` segundos. Cada pacote
válido do servidor chega normalmente a cada segundo e renova o prazo mesmo quando
o peso não muda. Linha parcial, bytes sem quebra de linha ou ausência completa de
dados não renovam a validade. Ao vencer o prazo, o CLIENTE registra mensagem fixa,
marca a comunicação indisponível, fecha recursos pelo `finally` existente e entra
na redescoberta/candidatura normal. A posição 1 continua aguardando 30 segundos a
partir da detecção; o modo manual apenas determina que ASSUMIR exige ação humana.

Enquanto indisponível, o monitor conserva o número para diagnóstico, muda o
título para `ÚLTIMA LEITURA`, exibe `SEM COM.` e usa cor de alerta. Esse valor não
deve ser interpretado como peso atual. Nova conexão permanece indisponível até o
primeiro JSON completo e válido. O prazo é experimental e exige repetição física
com suspensão controlada antes de uso operacional contínuo.

## Barra operacional do monitor

O monitor mede 620 × 300 e reserva áreas próprias para menu, configuração,
pesagem, tara e estado. Verde representa AP saudável ou CT recebendo mensagens
válidas. Amarelo representa AP ativo sem saúde HTTP ou CT sem leitura atual antes
da sucessão. Vermelho exige encerramento comprovado do AP ou CLIENTE sem
participação disponível na sucessão/procurando servidor. Roxo diferencia
candidatura aguardando, candidatura liberada e promoção em andamento.

As mensagens alternam a cada três segundos e uma mudança de estado invalida a
sequência anterior. O botão de copiar não consulta a balança; usa apenas o valor
da tela. Em `ÚLTIMA LEITURA`, peso e tara não podem ser copiados. No PRINCIPAL,
`Clientes: —` é intencional até existir contagem confiável de SUBSCRIBEs ativos.

Menu nesta versão: `Info`, `Exportar log` e `Reconfigurar` habilitados. O primeiro
informa a versão provisória `1.0.0-beta`, autoria provisória `Pablo`, ausência de
URL configurada e que o software não é oficial da Toledo/PRIX. O segundo salva em
UTF-8 o histórico recente ainda retido de stdout/stderr, com aviso e contadores
quando houver cortes. O terceiro aguarda a parada operacional comprovada e abre uma execução
nova diretamente na tela de conexão; timeout/falha mantém a janela e não inicia
outra instância.

`Abrir terminal` e `Desativar login automático` permanecem desabilitados. Não há
controlador de visibilidade do console nem callback uniforme de configuração e
credencial para todos os modos. Nenhum comando fictício é executado. A URL exata
do GitHub ainda deve ser fornecida pelo responsável.

As superfícies de leitura de peso e tara usam o fundo verde `#8FD33F`. Alertas de
comunicação continuam sobrepondo a faixa com sua cor própria; ao receber nova
mensagem válida, a interface restaura o verde configurado.

### Correção do fechamento — 09/11/2026

Ao escolher **SIM** no fechamento do monitor, a aplicação deve iniciar o worker
de saída, bloquear novas admissões e acompanhar a limpeza até obter confirmação
operacional. Só então a interface conclui o fechamento. Foi corrigido um defeito
que apagava a referência local desse worker antes de `start()`, deixando o estado
preso em `parando` sem executar a limpeza. Reinicie uma instância que ainda esteja
executando a versão anterior para carregar a correção.

Timeout ou falha real de limpeza continuam mantendo a janela aberta para nova
avaliação; a correção não força encerramento de recursos pendentes. O formulário
de promoção também passou a encaminhar uma única chamada por confirmação no
botão ASSUMIR, removendo uma invocação duplicada.

### Ajustes da revisão geral — 09/11/2026

Faixas não recebidas deixam de mostrar limites fixos: máximo, mínimo e divisão
ausentes aparecem como `—`, inclusive em configuração parcial. Os rótulos são
atualizados após promoção e troca para leitor rebaixado quando essa troca ocorre.
Posteriormente, a etapa 1 descrita no início deste documento integrou a supervisão
após promoção, conservando os requisitos de prova B2 e amostra válida.

O monitor inicia com cópia bloqueada. No principal, saúde falsa da TC420 ou falha
da fonte revoga a confirmação e mostra última leitura; no cliente continua sendo
usado o callback de frescor. A cópia volta após refresh válido. A promoção também
aguarda esse refresh antes de liberar a cópia. A saúde segue os limiares do
servidor; não é uma medição física independente da amostra exibida.

O ensaio manual `teste_approval.py` mantém comunicação real quando executado pelo
operador, mas não imprime mais o token nem o corpo bruto das exceções. O resultado
e as limitações da revisão estão no [relatório geral](REVISAO_GERAL_2026-11-09.md).

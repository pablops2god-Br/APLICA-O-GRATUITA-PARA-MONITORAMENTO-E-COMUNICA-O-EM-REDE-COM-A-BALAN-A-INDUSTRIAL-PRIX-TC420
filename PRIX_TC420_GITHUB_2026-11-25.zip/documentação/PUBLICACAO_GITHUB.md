# Seleção para publicação no GitHub

Preparação de 25/11/2026. Não foi solicitado commit ou push nesta etapa.

## Cópia de publicação

A pasta `publicacao_github/PRIX_TC420_2026-11-25` contém a seleção preparada
para um repositório de código: aplicativo, assets necessários, testes,
componentes importados de prototipos, documentação técnica e fontes de build.
README e arquivos de dependências orientam a instalação.

TCC, apresentação, conversas, backups, ambientes virtuais, executáveis,
cadastro administrativo, configuração local, logs e coletas brutas não são
incluídos. O material acadêmico continua preservado no projeto de trabalho.
O autor confirmou publicar somente aplicativo, testes e documentação técnica;
TCC e apresentação permanecem fora da seleção.

Os endereços operacionais identificados foram substituídos por exemplos da
faixa 192.0.2.0/24 apenas na cópia. Identificadores de estações e caminhos
de usuário identificados também recebem representações genéricas. Links
para arquivos locais não incluídos tornam-se texto explicativo. Os originais
continuam intactos. O manifesto externo lista caminhos, tamanhos, SHA-256 e
arquivos ajustados, sem conteúdo de credenciais.

## Histórico Git local

`configuracao.json`, conversas e parte do material acadêmico já estavam
rastreados pelo Git local antes desta preparação.
Acrescentar a regra ao .gitignore não o remove do índice nem dos commits
anteriores. Por isso a seleção não copia .git e não deve ser confundida com
uma auditoria ou limpeza de todo o histórico existente.

Publicar a cópia como histórico novo evita transportar os commits locais.
Reutilizar o repositório antigo exige revisão específica de seu histórico
antes do envio. Nenhum histórico foi reescrito e nenhum remoto foi alterado.

## Verificações da cópia

Foram selecionados 251 arquivos, com 169 arquivos Python compilados em memória.
A regressão executada dentro da cópia aprovou 2.169 testes em 52,064 segundos,
com dependências externas controladas e cenários de localhost; sem TC420 real.
O manifesto SHA-256 conferiu os bytes selecionados. A busca por padrões
conhecidos de credenciais não encontrou ocorrências; arquivos locais proibidos
e o diretório .git estão ausentes. Essa conferência não audita o histórico antigo.

O ZIP PRIX_TC420_GITHUB_2026-11-25.zip fica em publicacao_github, fora da
árvore de código. Contém apenas os arquivos selecionados, sem o log bruto
da regressão ou o histórico do repositório original. Manifesto e relatório
de verificação são arquivos auxiliares externos à árvore de publicação.

## Reproduzir e verificar

```powershell
python ferramentas/preparar_github.py --destino publicacao_github/PRIX_TC420_2026-11-25 --data 2026-11-25
```

O destino deve ser novo e ficar dentro de publicacao_github. O script usa
lista de permissões, não sobrescreve uma cópia existente e não publica nada.
Não contém senhas de exemplo operacionais. A configuração será criada pela
interface da aplicação. A pasta prototipos precisa acompanhar a suíte e os
módulos que a importam.

Uma busca automatizada por padrões e a conferência dos arquivos selecionados
reduzem exposições conhecidas, mas não são garantia absoluta de ausência de
segredos. O código conserva marcadores sintéticos usados pelos testes de
sanitização; eles não são credenciais operacionais.

## Direitos e distribuição

Nenhuma licença MIT/GPL foi atribuída sem autorização. Imagens e marcas
do fabricante conservam sua titularidade. Binários futuros devem ser
publicados separadamente do código, após validação e decisão do autor.

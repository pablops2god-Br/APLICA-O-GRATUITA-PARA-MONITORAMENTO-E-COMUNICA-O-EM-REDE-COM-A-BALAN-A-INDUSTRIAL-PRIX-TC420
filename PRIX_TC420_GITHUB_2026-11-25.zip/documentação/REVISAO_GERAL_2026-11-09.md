# Revisão geral — 09/11/2026

## Escopo e método

Revisão dos fluxos de inicialização, cliente/principal, configuração, comunicação,
interface, saída e testes. As alterações anteriores foram preservadas. Não houve
commit ou push. A revisão não equivale a certificação de produção ou auditoria
exaustiva de todas as combinações de concorrência.

Foram inspecionados os caminhos centrais de `main.py`, `config/`, `rede/`,
`interface/` e `tc420/`, os contratos experimentais associados e testes relevantes.
Uma análise por AST procurou definições duplicadas em 43 módulos operacionais e
experimentais, sem encontrar duplicação de definições. Sintaxe e compilação em
memória foram verificadas em 117 arquivos Python, incluindo testes e scripts
auxiliares, sem executá-los para essa verificação.

## Inconsistências corrigidas

| Problema reproduzido | Comportamento corrigido | Arquivos |
| --- | --- | --- |
| JSON válido podia ser lista, booleano, número ou texto, chegando aos consumidores que chamam `.get()`. | A carga aceita somente objeto JSON; outras raízes retornam `None`. Não foi implantado um esquema completo de validação de campos. | `config/configuracao.py` |
| O principal conservava a última amostra, mas o refresh a tratava como atual mesmo com saúde da TC420 falsa. | Quando há callback de saúde, a comunicação respeita `saudavel`; perda mostra `SEM COM.` e bloqueia a cópia. Os limiares de saúde do servidor foram preservados. | `interface/janela.py` |
| Exceção da fonte deixava a confirmação anterior e a cópia habilitadas. A cópia também começava permitida antes da primeira amostra. | Falha da fonte revoga confirmação/cópia e indica última leitura. O monitor começa sem cópia e só habilita após refresh válido. Após promoção, aguarda o refresh da nova fonte. | `interface/janela.py` |
| Cabeçalho usava limites fixos sem configuração; configuração parcial podia quebrar a montagem. Promoção não atualizava os rótulos. | Widgets são conservados e atualizados; campos ausentes mostram `—`. Promoção e troca para leitor rebaixado atualizam os rótulos quando esse fluxo se completa. | `interface/janela.py` |
| O wrapper automático sinalizava retorno do servidor somente no caminho normal. | Evento sinalizado em `finally`, inclusive após erro ou recusa de entrada. Exceções continuam propagando; retorno não comprova término de todos os trabalhadores. | `main.py` |
| Ensaio manual imprimia token de sessão e mensagem bruta de exceção. | Token não é impresso; diagnóstico usa mensagens controladas. Protocolo de login e consultas foi preservado. | `teste_approval.py` |

## Evidências

`tests/test_revisao_geral.py` acrescenta nove testes de regressão. Os oito primeiros
reproduziram problemas antes das correções, inclusive nos subcasos de raiz JSON.
O caso adicional verifica o bloqueio de cópia antes da primeira amostra.

Os testes usam dependências controladas. O ensaio manual é executado com
`WebTC420`, entrada e senha substituídos, usando somente marcadores sintéticos.
Nenhuma credencial real foi usada. Casos antigos de inspeção estática passaram a
exigir ausência de impressão do token; expectativas do evento automático foram
atualizadas para retorno em `finally`. As asserções de propagação de erro e de
acompanhamento da tentativa continuam presentes.

Resultado final: **1.990 testes simulados aprovados em 24,896 s**, por
`python -B -m unittest discover -s tests -q`. Compilação em memória de 117 arquivos
e `git diff --check` aprovados.

Também foi verificado um monitor Tk real com raiz oculta, sem rede: cópia inicial
bloqueada, configuração ausente/parcial, atualização de rótulos, perda de saúde,
`SEM COM.` e retorno da saúde com reabilitação dos botões. Uma primeira asserção
do harness foi afetada pela codificação do travessão no pipeline do shell; a
comparação foi corrigida para usar o ponto Unicode e a execução passou. Não foi
um ensaio de clique humano nem inspeção estética da janela.

## Limitações verificadas e mantidas

| Limitação | Evidência e consequência |
| --- | --- |
| Recuperação após promoção: lacuna identificada nesta revisão e tratada posteriormente na etapa 1. | A supervisão passou a ser comum aos três caminhos, com prova B2 e amostra válida antes de trocar a fonte. Implementação e limites em [SUPERVISAO_PRINCIPAL.md](SUPERVISAO_PRINCIPAL.md); nova validação física permanece pendente. |
| NÃO não oculta a janela. | `confirmar_fechamento` só informa que continuará executando. “Segundo plano” não corresponde hoje a bandeja ou janela oculta. |
| Crescimento do terminal: tratado posteriormente na etapa 2A. | Retenção limitada em memória, contadores e exportação assíncrona somente do trecho disponível; [medição antes/depois](RETENCAO_TERMINAL.md). Não há logs automáticos nem prova de memória total constante ou ensaio prolongado. |
| Histórico de trabalhadores/reservas retido durante o ciclo. | `RegistroTrabalhadores` conserva referências e entradas de sockets, inclusive reservas de `accept()` resolvidas sem recurso. Não há limite por duração; retenção de metadados não comprova vazamento de socket aberto. |
| Porta do formulário não determina HTTPS. | A porta é persistida, mas `WebTC420` monta URL HTTPS sem esse argumento. TCP direto legado tem contrato separado. Protocolo do firmware não foi alterado. |
| Descoberta/sucessão não constituem consenso. | Broadcast, CHECK e espera por posição não garantem exclusividade entre máquinas iniciando simultaneamente. Não foi introduzido protocolo de posse distribuída. |
| Cobertura física e análise de tipos continuam delimitadas. | Não houve teste com TC420, firmware ou vários PCs. Pylance/Pyright não foram executados; compilação e testes não equivalem à aprovação do analisador do editor. Certificação global permanece conservadora. |

## Propostas, sem implementação nesta revisão

Avaliar retenção limitada ou rotação do terminal com regra explícita de exportação,
compactação dos registros preservando evidências de saída e integração do
observador de rebaixamento após promoção. Ensaios físicos ainda precisam cobrir
perda/retorno da rede, promoção e fechamento antes de declarar esses comportamentos
validados no equipamento.

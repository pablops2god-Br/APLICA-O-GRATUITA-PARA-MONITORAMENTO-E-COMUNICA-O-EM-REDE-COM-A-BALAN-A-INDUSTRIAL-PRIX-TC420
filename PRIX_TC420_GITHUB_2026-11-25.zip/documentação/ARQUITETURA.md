# Arquitetura e ciclo de vida

## Representação de reservas resolvidas — 12/11/2026

RegistroTrabalhadores mantém token e entrada por reserva. Na resolução comprovada
sem alocação, sem erro e sem pendência de handler, utiliza dataclass privada com
slots e campos equivalentes. Isso reduz custo por entrada sem descarte, mudança
de diagnóstico ou alteração de B2/supervisão. Responsabilidades incertas, recursos,
threads e erros conservam acompanhamento anterior. Não foi ativada compactação
automática dos ciclos. O histórico continua linear; decisão e medição em
[COMPACTACAO_REGISTRO_TRABALHADORES.md](COMPACTACAO_REGISTRO_TRABALHADORES.md).

## Supervisão comum do PRINCIPAL — 09/11/2026

Login manual, automático e promoção usam `rede.supervisao_principal.SupervisaoPrincipal`,
associada ao contexto original e ao mesmo proprietário B2. Retorno do servidor
inicia avaliação; só prova positiva por contexto autoriza criar leitor acompanhado
sem candidatura. A interface conserva última leitura até amostra válida, aplica
troca no Tk e rejeita callbacks antigos. Descrições de observadores separados são
históricas; contrato e evidências em [SUPERVISAO_PRINCIPAL.md](SUPERVISAO_PRINCIPAL.md).

## Encerramento operacional vigente — B2, 28/10/2026

Uma execução de main cria SaidaAplicacao e compartilha a instância entre os
caminhos CLIENTE, PRINCIPAL manual/automático e promoção. A infraestrutura fixa
esse proprietário. A propriedade deriva das referências retidas a leitores,
registros, contextos de ciclos e threads; não deriva do papel atual do PC.

SIM registra intenção, fecha os gates existentes e dispara o executor. Parada
dos leitores, shutdown/close e esperas ocorrem em workers, fora dos locks do
proprietário e do loop Tk. Cada tarefa é retida por identidade e só pode ser
repetida depois de terminar com falha, em nova tentativa explícita. Timeout
não abandona uma tarefa bloqueada nem autoriza outro close concorrente.

O servidor é parado pelo ID do ciclo conhecido; o evento da execução ligado ao
contexto evita perder o pedido durante clear. As provas do histórico de ciclo
incluem trabalhadores e handlers, não somente retorno da rotina coordenadora.
Admissão/contagem de inicializações e registro anterior a start impedem que uma
partida tardia desapareça da avaliação. Gerações antigas permanecem retidas.

O resultado operacional é confirmado_operacional, timeout ou falha. Apenas o
primeiro permite que o observador after conclua a interface no Tk. O certificado
global permanece desconhecido/False, pois não cobre toda a aplicação nem o
transporte interno HTTP. Recursos em uso, operações ativas e cleanup falho são
pendências operacionais reais, independentemente dessa limitação formal.

## Interface assíncrona vigente — B3, 28/10/2026

CONECTAR coleta e valida campos no Tk; descoberta UDP, login, approval,
persistência e partida acompanhada ocorrem no worker. Promoção manual e automática
usam o mesmo mecanismo. CicloTk publica resultados por SimpleQueue; só o loop Tk
consome a fila e aplica alterações. Workers não chamam after nem widgets. A
associação de contexto da promoção ao monitor passa a acontecer ao aplicar o
resultado; falhas e contextos antigos continuam retidos pelo proprietário B2.

Cada operação retém identidade, janela/controlador, vínculo B1 e proprietário.
O token cancelável é propagado somente no contexto do worker. A admissão de
threads/serviços verifica esse token e o vínculo sob o mesmo lock do pedido de
saída. Partidas admitidas antes da parada permanecem acompanhadas por B2; a fila
não constitui prova de término da thread. Duplos cliques não duplicam trabalho.

O scheduler guarda IDs e geração, valida root e intenção de parada ao executar,
cancela agendamentos antes de destroy e invalida entregas já capturadas. A
observação B2 tem agendamento próprio permitido durante a parada; demais tarefas
não atualizam o monitor nessa fase. Timeout/falha conserva a janela e o retry,
com os mesmos 10 s por tentativa. Erros Tcl de programação não são suprimidos
genericamente. O consumidor de peso verifica também a existência do label.

A passagem de conexão para cliente ocorre depois do retorno do mainloop antigo;
a espera de CONFIG não ocupa um loop Tk ativo. A descoberta/login inicial de
main, antes de existir janela, continua síncrona. O TCP direto legado publica
peso pela fila e registra a thread, mas permanece fora do ensaio inicial: sua
parada bloqueada em receber não ganhou certificação operacional nesta etapa.

As descrições incrementais anteriores abaixo conservam contexto histórico;
o contrato vigente está em PRONTIDAO.md. O ensaio visual real é o próximo passo,
ainda não realizado; a validação física e o executável vêm depois.

## Fluxo de dados

```mermaid
flowchart TD
    T[TC420] -->|HTTPS: login, approval, refresh| P[PC principal: WebTC420]
    P --> S[Servidor: dados_atuais e configuracao_atual]
    S -->|fonte local| M[Monitor principal]
    S -->|TCP 42100: CONFIG, REGISTER, SUBSCRIBE| C[LeitorDadosServidor]
    C -->|fonte TCP em memória| J[Monitor cliente]
    S -->|UDP 42101: descoberta| C
```

`fonte_dados` é uma função sem argumentos que retorna o último dicionário de
peso conhecido. A janela chama essa função independentemente do papel do PC.
O principal usa `rede.servidor.obter_dados_atuais`; o cliente usa o método do
leitor. As cópias de dicionários são superficiais, incluindo as de configuração.

## Inicialização

`main.iniciar()` procura servidor. Se encontrar, chama `iniciar_como_cliente(servidor)`,
que cria e inicia o leitor, aguarda
`CONFIG` por até cinco segundos e constrói o monitor com a configuração recebida
ou `None`. O fluxo inicial do leitor é `CONFIG → REGISTER → SUBSCRIBE`, em três
conexões distintas. Se não encontrar servidor na inicialização do programa,
tenta login automático com JSON e Credential Manager. Opção desativada,
parâmetros/credencial ausentes ou falha HTTP abrem `JanelaConexao` com callback
cliente. Antes do automático faz segunda descoberta; servidor encontrado
redireciona ao cliente sem HTTP. Sucesso publica approval, inicia servidor
com a mesma instância web e abre monitor diretamente como Tk. Não altera
candidatura ou ASSUMIR. Essa decisão não constitui eleição.
Após validar campos, CONECTAR faz nova descoberta. Encontrando servidor, destrói
o root e chama iniciar_como_cliente, que cria outro Tk; retorna sem login ou
persistência, inclusive quando o monitor cliente fechar. Sem callback,
mantém tela com erro e não acessa HTTP. Sem servidor mantém login principal.

O principal faz login e `approval`, publica a configuração antes de iniciar
o servidor e passa a mesma instância autenticada de `WebTC420` às rotinas locais.
O monitor é aberto após um callback de 500 ms. A obtenção de dados periódicos
fica exclusivamente em `ler_tc420`; a janela não dispara `refresh` HTTP.

## Threads e sincronização

| Contexto | Responsabilidade |
| --- | --- |
| Thread principal/Tkinter | Campos, botões, criação e fechamento de janelas |
| Thread do leitor | CONFIG inicial, registro, SUBSCRIBE, descoberta e candidatura |
| Thread de próxima oportunidade | Espera após falha e descoberta durante o prazo |
| Thread TCP do servidor | Aceita conexões; cria uma thread por cliente |
| Thread UDP do servidor | Responde à descoberta |
| Thread HTTP do servidor | Consulta e substitui `dados_atuais` |
| Thread orquestradora do servidor | Inicia as três rotinas e acompanha seus joins |

As threads de serviço são daemon. `lock_clientes` protege a atribuição das
posições; `lock_candidatura` protege estado e contador. Esse lock não é
reentrante: não chamar um método que o adquire de dentro de um bloco que já o
detém. Nem todos os campos compartilhados são protegidos por lock.

| Evento do leitor | Significado |
| --- | --- |
| `configuracao_pronta` | JSON inicial foi armazenado; `{}` também sinaliza, mas getter retorna `None` |
| `servidor_respondendo` | SUBSCRIBE foi enviado pela conexão estabelecida |
| `candidatura_liberada` | GUI pode detectar uma oportunidade de promoção |
| `_parada` | Interrompe esperas quando o leitor é parado |

`servidor_respondendo` não garante que a TC420 esteja atualizando: o servidor
agora mantém saude_tc420 separada, consultável localmente pelo getter,
com tolerância de três falhas consecutivas e lock próprio. Não é enviada aos
clientes. CHECK e UDP respondem somente quando saudável; listeners e SUBSCRIBE permanecem ativos. O horário é epoch time.time;
não há decisão por idade do último sucesso nesta etapa. O servidor
pode continuar retransmitindo o último valor mesmo após falha HTTP. Também não
há timeout de leitura do SUBSCRIBE após a conexão; EOF/reset são detectados,
mas uma interrupção silenciosa de rede pode demorar a ser percebida.

## Candidatura e recuperação

```mermaid
stateDiagram-v2
    [*] --> inativa
    inativa --> aguardando: queda e posição conhecida
    aguardando --> liberada: prazo termina
    liberada --> aguardando: falha / contador mantido
    aguardando --> cancelada: servidor encontrado
    cancelada --> inativa: SUBSCRIBE estabelecido
    liberada --> inativa: promoção chama parar
```

A primeira espera é `posição × 30 s`, medida com `time.monotonic()` e buscas
durante o prazo. Posições 1–4 correspondem a 30, 60, 90 e 120 segundos.
Ela começa depois de a perda ser detectada, não em um instante comum a todos
os PCs. Ao liberar, o contador passa de 0 para 1 e o evento fica `True`.

Uma falha registrada em `liberada` muda para `aguardando`, limpa o evento e
inicia uma thread de espera de 30 segundos. No vencimento, o contador é
incrementado e o evento volta a `True`. Encontrar servidor cancela e zera o
contador; estabelecer SUBSCRIBE retorna a `inativa/0`. No limite 10, o método
registra a falha e retorna `False`, sem agendar nova oportunidade e sem limpar
o estado liberado. Isso ainda não impede novas ações manuais do usuário.

A rotina principal de descoberta e a de próxima oportunidade coexistem.
O worker verifica estado e tentativa anterior para não substituir uma
candidatura já encerrada. Ainda não existe reserva exclusiva da recuperação
entre máquinas: os prazos e a última descoberta reduzem conflitos, mas não
garantem ausência de dois principais, especialmente em partições de rede.

## GUI e promoção

O monitor atualiza o peso a cada 1000 ms e consulta candidatura a cada 500 ms,
com callbacks independentes de `after()`. Um `True` abre ASSUMIR uma vez.
`False` rearma a detecção; fecha a janela apenas em `cancelada` ou `inativa`.
Em `aguardando`, ela permanece aberta. O botão não verifica o evento novamente;
o usuário ainda pode acioná-lo enquanto aguarda a próxima oportunidade.

O callback definido em `main.py` faz uma última descoberta, autentica, obtém
configuração usando credenciais manuais ou salvas. Ao detectar um novo pulso,
a GUI tenta o callback automático uma vez sob promocao_em_andamento. Sucesso
aplica concluir_promocao sem abrir ASSUMIR; False/None abre manual apenas se
o estado ainda for liberada. Falha registrada leva a aguardando e não abre
novo diálogo durante a espera. Não há nova chamada a cada 500 ms enquanto
o mesmo pulso permanece True. False rearma a detecção.

Esse callback obtém
configuração, publica-a e inicia o servidor. Só então para o leitor e retorna
a fonte local. A mesma janela troca `web`, `configuracao` e `fonte_dados`, sem
recriação. Os textos W1.1/W1.2 são construídos no início e não são reconstruídos
ao substituir apenas `self.configuracao` durante a promoção.

Busca e login da promoção são síncronos na thread Tkinter e podem pausar a GUI.
O sucesso de `thread.start()` não confirma bind TCP/UDP nem saúde da rotina HTTP.
A configuração é publicada antes do start, mas não há confirmação de prontidão.

## Encerramento

`leitor.parar()` limpa eventos e contador, sinaliza `_parada` e usa `shutdown`
para destravar a leitura persistente. Não há join interno; o chamador pode
aguardar `leitor.thread`. Conexões curtas e descoberta podem aguardar seus
timeouts. `main` usa `finally` ao redor de `monitor.executar()`.

O monitor destrói sua janela e tenta desconectar a conexão TCP direta legada.
No principal, a janela de login é o `Tk` oculto e o monitor é `Toplevel`:
fechar apenas o monitor não destrói automaticamente esse root nem interrompe
o servidor. Para garantir a queda no teste, encerrar o processo principal.
O servidor possui API de parada voluntária; veja o detalhamento abaixo.

## Encerramento de SUBSCRIBE por saúde

Antes de cada envio, SUBSCRIBE consulta saúde. Quando False, registra encerramento e retorna; finally fecha socket e cliente recebe EOF. Clientes existentes entram na busca/candidatura normal. CHECK e UDP continuam condicionados à saúde. A rotina HTTP antiga permanece ativa nesta etapa. Teste real deve terminar ao iniciar contagem de candidatura, antes da promoção, para não disputar a TC420. Desligamento após 25 s implementado; rebaixamento para cliente ainda pendente.

## Parada voluntária do servidor

Evento global evento_parada_servidor e APIs solicitar_parada_servidor()/servidor_deve_parar(). Leitura e SUBSCRIBE verificam evento e usam Event.wait para interromper pausas. TCP accept e UDP recvfrom têm timeout de 1 s para conferir parada; finally fecha sockets. iniciar_servidor limpa evento após validar token, acompanha threads e faz joins de até 2 s por thread. Ctrl+C solicita parada. Chamar em outro processo não afeta o servidor original. Após a terceira falha HTTP consecutiva, inicio_indisponibilidade registra time.monotonic(). Uma nova falha concluída após 25 s solicita parada e encerra a leitura. Sucesso limpa o prazo. HTTP em andamento pode atrasar o encerramento. main.py ainda não converte o principal em cliente.

HTTP em andamento não é cancelado: aguarda retorno/timeout. Joins limitados não garantem fim de toda operação bloqueada; handlers com recv/send bloqueados não são acompanhados individualmente. Reiniciar somente após confirmar que as threads anteriores terminaram; não iniciar servidores concorrentes com o mesmo evento. Saúde, dados, configuração e registros não são zerados automaticamente no restart.

## Detecção do encerramento em main.py

No caminho de login automático de main.py, tentar_login_automatico() cria servidor_encerrado (threading.Event) e devolve esse evento no resultado principal. A thread executa iniciar_servidor(web), registra MAIN: servidor PRINCIPAL foi encerrado. e sinaliza o evento após retorno normal. iniciar() cria observador daemon que aguarda o evento, registra a detecção e inicia LeitorDadosServidor(permitir_candidatura=False) em background. O observador não acessa Tkinter; a descoberta é executada pelo leitor. Monitor permanece aberto e troca a fonte pelo leitor conectado através do callback da interface. Caminhos de login manual e promoção não receberam esse mecanismo. O sinal representa retorno normal, sem distinguir abandono por saúde de parada voluntária; exceção não tratada no servidor não sinaliza o evento.

## Leitor sem candidatura

LeitorDadosServidor aceita permitir_candidatura=True por padrão. Com False, _aguardar_candidatura retorna False antes de iniciar contagem ou liberar candidatura. Após perda da conexão, o ciclo continua buscando servidores com intervalo de reconexão. CONFIG, REGISTER e SUBSCRIBE permanecem iguais; a posição de sucessão continua registrada. Clientes existentes preservam o padrão True. main.py usa esse modo no observador de encerramento do servidor iniciado por login automático. O parâmetro é definido na criação; não implementa cancelamento de candidatura já ativa nem guarda adicional na rotina de próxima tentativa. A troca da fonte e a parada do leitor ao sair do monitor estão integradas para o login automático.


O evento de encerramento representa retorno normal do servidor, sem distinguir motivo de parada. A integração atual do monitor e cleanup está descrita abaixo.

## Troca de fonte e encerramento do leitor rebaixado

No principal iniciado por login automático, main.py compartilha leitor_rebaixado e leitor_pronto com o monitor. O observador publica o leitor sem candidatura e sinaliza pronto após iniciar(). Antes de executar(), chama observar_rebaixamento; o callback da interface troca a fonte somente quando servidor_esta_respondendo sinaliza conexão. A mesma janela é mantida. Um finally sinaliza monitor_encerrado e chama parar no leitor existente. Lock serializa criação/início e cleanup; observador verifica fechamento enquanto espera o servidor e não cria leitor após cleanup. A espera usa timeout de 0,1 s, e o cleanup acompanha observador com join de até 1 s. Também cobre erro na construção/agendamento do monitor. Login manual possui integração controlada própria; promoção ainda não possui integração. O sinal de conexão não garante que o primeiro pacote já chegou; main não zera web/configuração nem atualiza cabeçalho. Parar usa o ciclo de vida existente do leitor, sem join adicional da thread TCP.

## Encerramento do servidor no login manual

JanelaConexao cria servidor_encerrado (threading.Event) após servidor_iniciado=False. No login manual, thread daemon executa wrapper que chama iniciar_servidor(self.web) com a mesma sessão autenticada; finally registra CONEXAO: servidor PRINCIPAL foi encerrado. e sinaliza evento tanto no retorno normal quanto em exceção. Exceções continuam propagando na thread. Evento não distingue abandono de outro motivo e indica fim da rotina, sem garantir fim de toda thread interna. A detecção recebeu integração posterior com leitor e monitor; veja a seção de integração manual.

## Integração manual do leitor e monitor

No login manual, JanelaConexao mantém leitor_rebaixado e leitor_pronto. Ao iniciar o servidor, inicia também observador daemon; após servidor_encerrado, cria LeitorDadosServidor(permitir_candidatura=False), publica instância, inicia leitor e sinaliza pronto. abrir_monitor conecta observar_rebaixamento ao evento/callback e mantém atualizar_refresh_web. Troca da fonte acontece no callback Tk, quando leitor sinaliza conexão, na mesma Toplevel. Qualquer término da rotina servidor dispara esse fluxo, sem distinguir causa. Nesta etapa não há encerramento do leitor junto com a janela nem cancelamento do observador; integração controlada, não recuperação final para uso contínuo. Login por promoção permanece sem essa integração.

## Frescor local do SUBSCRIBE

O CLIENTE não usa mais `makefile().readline()` como mecanismo de recepção. O
socket SUBSCRIBE opera com `recv()` e acumulador de bytes; somente uma linha JSON
completa, decodificada e contendo os campos obrigatórios renova o prazo monotônico
de seis segundos. Fragmentos não renovam o prazo. EOF e erros continuam seguindo
o fluxo de recuperação existente. O objeto de stream ainda é criado e fechado
para preservar o acompanhamento de recursos já estabelecido, mas não realiza a
leitura operacional.

LeitorDadosServidor conserva a última medição separadamente do booleano local de
frescor. `comunicacao_esta_atual()` só retorna True depois de pacote válido da
conexão corrente; conexão, silêncio, erro, EOF e parada limpam o sinal. O monitor
recebe esse callback sem alterar o protocolo TCP. Mensagem antiga de uma conexão
já abandonada não é consumida pela nova geração serial do leitor.

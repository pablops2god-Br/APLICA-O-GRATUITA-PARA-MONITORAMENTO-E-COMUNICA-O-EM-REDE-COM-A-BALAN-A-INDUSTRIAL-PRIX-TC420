# Etapa 2B.6 — protótipo isolado de identidades e intervalos

Continuidade experimental: [2B.7 — consultas em lote e agregado](OTIMIZACAO_CONSULTAS_INTERVALOS_2B7.md)
reduziu a reconstrução repetida e mediu lock/fragmentação. A 2B.6 original foi
preservada para comparação; nenhuma das versões foi integrada ao servidor.

12/11/2026. Nenhum código operacional alterado. Sem ativação automática,
revogação de tokens, descarte de diagnósticos, rede real ou TC420.

## Representação e responsabilidades

`RegistroIntervalosExperimental` herda os métodos operacionais do registro, mas
usa `ArmazenamentoIntervalos` no lugar do dicionário privado. É substituição
temporária apenas no harness de testes; nenhum módulo operacional importa isso.

- Tabela forte: entradas completas para reservada, alocada, publicada,
  aguarda_limpeza, fechando, fechada, criacao_incerta e erro_limpeza. Recursos,
  tokens, erros e pendências continuam fortes. Todas as threads são mantidas.
- Intervalos: somente sem_recurso comprovado, sem recurso, uso, erro ou pendência
  de handler. Cada faixa guarda início/fim, ciclo e resultado de publicação.
- Índice fraco: chave inteira → token original ainda existente, sem usar igualdade
  de tokens ou WeakSet. A validação herdada exige tipo exato, dono e `is`.

Uma referência externa ainda encontra o mesmo token e o mesmo dono. Quando esse
token é coletado, o índice perde apenas sua identidade; a faixa histórica continua
existindo. A perda da weakref não resolve nada e não remove responsabilidade.
Tokens pendentes não são coletáveis, pois permanecem na tabela forte.

Quando não há token original vivo, a reconstrução usa `_IdentidadeDiagnostico`,
com ID/ciclo e tipo distinto do token operacional. **Não cunha token substituto**
nem cadastra essa identidade para autenticação. Uma cópia fabricada com os mesmos
campos é recusada tanto antes como depois do GC. Números pertencentes a uma faixa
não constituem autorização para operar.

O resultado de fechar_socket de um token original vivo continua True quando
resolvido; publicação sem responsabilidade continua False. Publicação de handler
e fechamento real continuam na tabela forte, inclusive depois de erro ou sucesso.
O protótipo não comprime sockets fechados e não muda shutdown sobre eles.

## Atomicidade e concorrência

As transições públicas continuam sob o lock do registro. O argumento da entrada
mantém o token forte enquanto índice e intervalo são preparados; a entrada forte
só é retirada depois de publicar a faixa. Vizinhos são substituídos por uma única
operação de fatia, preparando a nova tupla antes de remover intervalos antigos.
IDs contíguos e monotônicos vêm do registro; iteração conserva ordem de criação.

Callbacks internos de WeakValueDictionary só retiram identidades fracas. Não
alteram faixas, tabela forte, contadores de responsabilidade ou critérios B2.
Não há callback de GC que chama close/join, bloqueia o lock ou confirma parada.
Acessos experimentais ao armazenamento privado exigem o lock, como antes.

Teste concorrente: quatro produtores, 1.200 reservas no total, mais um observador
de diagnósticos com GC, preservando ordem e identidades. Testes separados mantêm
close bloqueado, recusa de close concorrente e publicação tardia. Isso não é prova
de todas as intercalações, falta de memória ou Python sem GIL; o ambiente foi
CPython 3.13.15 convencional no Windows.

## Medição reproduzível — 50 mil reservas por cenário

Executar `python -B tests/investigar_identidades_intervalos.py`.
Dados completos: [MEDICOES_IDENTIDADES_INTERVALOS_2B6.json](MEDICOES_IDENTIDADES_INTERVALOS_2B6.json).
GC explícito e tracemalloc; uma execução final por cenário. Nenhuma thread de
serviço ou socket foi criado na medição. Valores não representam RSS.

| Carga / estratégia | Bytes retidos | Fortes / faixas / tokens fracos |
| --- | ---: | ---: |
| Uniforme, atual | 13.817.088 | 50.000 / 0 / 0 |
| Uniforme, protótipo, sem tokens externos | 2.464 | 0 / 1 / 0 |
| Uniforme, protótipo, um token externo | 2.656 | 0 / 1 / 1 |
| Uniforme, protótipo, todos os tokens externos | 13.859.816 | 0 / 1 / 50.000 |
| Alternada sem_recurso/incerta, atual | 15.013.936 | 50.000 / 0 / 0 |
| Alternada sem_recurso/incerta, protótipo | 10.923.648 | 25.000 / 25.000 / 0 |

Os seis cenários mantêm 50.000 diagnósticos, zero referências de recursos e zero
threads. Na carga alternada, 25 mil criações incertas continuam fortes e impedem
encerramento; ausência de handle não prova ausência de alocação. Não são 50 mil
responsabilidades resolvidas. A heterogeneidade examinada é específica; não
cobre todas as distribuições de estados ou resoluções adversariais.

Uniformidade sem referências externas dá compressão muito grande nesta amostra;
um token já não mantém 50 mil entradas completas. Preservar todos os tokens
externamente mantém crescimento linear do índice e dos próprios tokens. O caso
atual da tabela acima não preserva externamente esses 50 mil tokens; não usar
essa comparação para afirmar ganho ou regressão percentual do caso todos.
Fragmentação mantém custo proporcional ao número de faixas e pendências.

## Diagnóstico completo e custo temporário

| Carga | Consulta atual | Consulta protótipo | Pico absoluto atual / protótipo |
| --- | ---: | ---: | ---: |
| Uniforme, sem tokens externos | 0,164 s | 3,058 s | 27,89 / 15,67 MB |
| Alternada | 0,163 s | 2,327 s | 29,09 / 25,80 MB |

No protótipo uniforme com todos os tokens preservados, consulta levou 5,409 s e
pico absoluto foi 27,94 MB; com um token, 3,891 s e 15,67 MB. Uma única execução
instrumentada por cenário, sem conclusão estatística de desempenho. A medição
de pico de consulta é capturada antes do cálculo do digest; serialização para
comparar digests também aloca memória e não foi contada como consulta.

Os digests SHA-256 dos retratos completos coincidiram entre atual/protótipo em
cada carga comparável. Há ainda teste com igualdade direta de conteúdo/ordem e
200 resoluções fora de ordem, que terminaram fundidas em uma faixa.

A consulta continua retornando todos os dicionários e custa O(n). Na implementação
experimental, lookup em faixas é O(log r); inserção em lista fragmentada pode
custar O(r). Métodos herdados percorrem valores mais de uma vez e reconstroem
objetos transitórios; consultas longas mantêm o lock como no método atual.
Esses tempos maiores são uma restrição relevante para B2/servidor e **não foram
aceitos como custo operacional suficiente para integração**.

## Limites de compatibilidade

Diagnósticos públicos, tokens originais vivos e retornos foram equivalentes nos
cenários avaliados. A implementação privada deixa de ser dict; entradas uniformes
passam a ser reconstruídas e a identidade de diagnóstico sem token vivo não é
token operacional. `limpar_sockets` pode capturar esses marcadores e fechar_socket
recusá-los, sem efeito sobre resultado já comprovado; o retorno público de
limpar_sockets continua None. Dependências futuras de identidade de entradas ou
de tokens obtidos por introspecção privada exigiriam revisão específica.

Nenhum token externo original foi revogado. A validação de fabricar objeto com
mesmo ID/ciclo/dono falha por identidade, não por ausência de histórico. Não foi
introduzida resposta pública de diagnóstico expirado ou resumido.

O caso real de uma hora continha sobretudo sockets fechados e threads encerradas;
este protótipo não libera esses objetos. O benefício uniforme não deve ser
extrapolado para os 36 MB daquela carga mista. Compactação de ciclo atual e sua
incompatibilidade de parada tardia também não foram alteradas.

## Verificações e arquivos

- `prototipos/identidades_intervalos.py`: mapa, índice fraco e registro experimental.
- `tests/test_identidades_intervalos.py`: oito novos testes de identidade/GC,
  igualdade, fusão fora de ordem, fragmentação, pendências, close e concorrência.
- `tests/investigar_identidades_intervalos.py`: medições e `--contratos`.

Oito testes novos aprovados na regressão normal. Bateria existente sob substituição
experimental: **116 testes aprovados em 2,999 s**, incluindo compactação individual,
sockets, handlers, B2 e supervisão. São testes simulados, não equipamento físico.
Regressão normal: **2.057 testes aprovados em 26,369 s**. **132 arquivos Python
compilados em memória**. Nenhum módulo operacional modificado.

## Decisão

Prototipagem 2B.6 concluída no escopo descrito. O estudo demonstrou compressão de
resultados uniformes com diagnósticos e identidade preservados nos testes, mas
**integração não recomendada nesta versão**: reconstrução sob lock é bem mais
lenta, fragmentação/tokens externos podem continuar lineares e a carga mista real
não foi medida com essa arquitetura.

Próxima investigação: iterar faixas em lote sem lookup/reconstrução repetidos,
separar custo de comprovar encerramento do custo de materializar todo diagnóstico
sem mudar respostas públicas, testar fragmentação adversarial e medir carga mista
com sockets reais somente em etapa autorizada. Não alterar validade dos tokens
ou suprimir diagnósticos para atingir a meta. Qualquer evolução de contrato
continua dependendo de proposta concreta e aprovação explícita.

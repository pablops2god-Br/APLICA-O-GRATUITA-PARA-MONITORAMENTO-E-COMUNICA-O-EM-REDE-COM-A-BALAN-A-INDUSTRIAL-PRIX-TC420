# Sucessão recorrente A/B — 13/11/2026

Complemento posterior aos novos logs: rearmamento de B, posição 1, contagem e
candidatura detectada foram observados pelo responsável. O novo bloqueio está
após a oferta manual. Formulário já usado numa tentativa sem sucesso não é mais
fechado por inatividade do leitor que o promotor parou; permanece para nova
tentativa ou fechamento explícito. Recusas de segurança continuam valendo.
Diagnósticos `PROMOCAO:` agora identificam início, etapa de acesso à fonte,
revalidação e partida/prontidão, inclusive retornos anteriormente silenciosos.
Os logs recebidos não determinam a razão operacional do retorno sem sucesso.

Correção posterior de ASSUMIR: a parada do próprio leitor durante a promoção
muda candidatura para inativa. O observador não pode interpretar isso como
cancelamento do worker admitido nem destruir seu formulário. Esse fechamento
inferido agora é suspenso durante a promoção; cancelamento explícito/saída e
verificações operacionais permanecem válidos. Reprodução com leitor real,
worker controlado e Tk simulado falhou antes e passou depois. Regressão posterior:
2.126 testes em 42,014 s, 146 compilações em memória e whitespace aprovados.
Ainda falta repetição física da terceira alternância com esta correção.

Solicitação vigente: repetir PRINCIPAL → CLIENTE → candidatura → PRINCIPAL,
respeitando a fila, com tentativa automática se houver login salvo habilitado,
ou formulário manual caso contrário. Essa solicitação substitui a regra anterior
de manter a candidatura permanentemente desabilitada após rebaixamento.

## Causas confirmadas

Nos logs recebidos, A conectou a B, recebeu posição 1 e medições. Quando B perdeu
a TC420, A registrou `Candidatura desabilitada. Aguardando outro servidor TC420.`.
Não houve tentativa de candidatura rejeitada pela TC420: ela não foi iniciada.
O código anterior mantinha o leitor recuperado com permitir_candidatura=False e
o monitor removia o callback do evento. O botão manual anterior era uma ação
explícita adicional, não restaurava a oferta pela fila nem a tentativa automática.

Outro bloqueio existia no monitor de login manual: `abrir_monitor` compartilha o
mainloop da conexão e não chama `JanelaTC420.executar`, onde o observador de
candidatura era iniciado. Assim, apenas rearmar o leitor também seria insuficiente.

## Comportamento implementado

1. Ao abandonar PRINCIPAL, a supervisão continua exigindo retorno do coordenador
   e confirmação positiva de encerramento antes de criar o leitor recuperado.
2. Esse leitor começa sem candidatura. A supervisão fornece um autorizador
   vinculado ao contexto e à SaidaAplicacao. Não existe promoção imediata só
   porque o próprio servidor deixou de funcionar.
3. O leitor encontra outro PRINCIPAL, executa REGISTER, recebe posição inteira
   positiva e recebe uma medição válida. Somente então, com ciclos anteriores
   aptos e supervisão vigente, rearma sua candidatura. Emite diagnóstico
   `SUCESSAO: CLIENTE registrado e com leitura válida; candidatura rearmada.`.
4. Perdendo esse novo PRINCIPAL, reaplica a mesma fila existente: posição × 30 s,
   procurando outro servidor durante a espera. Servidor encontrado cancela a
   candidatura. Prova anterior ausente/incerta ou saída solicitada bloqueiam.
5. O monitor observa o evento também quando nasceu de login manual. A inicialização
   do observador é única por janela, evitando callbacks duplicados.
6. A candidatura liberada tenta promoção acompanhada com credenciais salvas
   apenas se salvar_login estiver habilitado e houver senha no cofre. Sem essa
   opção/credencial, o fluxo existente abre o formulário manual ASSUMIR. Não são
   copiadas senhas para logs ou documentos. A leitura da configuração permanece
   acompanhada pelo contexto de arquivos da infraestrutura.
7. A promoção reutiliza o gate operacional, a avaliação dos ciclos anteriores,
   a resolução CLIENTE, as duas descobertas e a prontidão TCP/UDP/amostra recente.
   Exceções de start e resultados incertos permanecem acompanhados pela B2.
8. No próximo abandono, uma nova geração começa bloqueada e repete REGISTER +
   amostra + prova antes de voltar à fila. A posição vem do PRINCIPAL conectado,
   não de uma prioridade permanente associada ao nome A ou B.

O menu Opções → Assumir manualmente continua sendo uma ação explícita sujeita
às verificações de segurança. A oferta normal pela fila deixa de depender desse
menu. Sem novo PRINCIPAL e sem REGISTER/amostra, o recém-rebaixado não é rearmado
automaticamente; esse bloqueio evita disputar de imediato com seu sucessor.

## Arquivos alterados

- `rede/lerdadosserver.py`: rearmamento condicional após REGISTER/amostra e
  revalidação da autorização durante a espera da fila.
- `rede/supervisao_principal.py`: associa autorização à geração recuperada.
- `rede/promocao_manual.py`: tentativa automática configurada pelo mesmo worker
  operacional de recuperação, sem retornar ao callback do leitor original.
- `interface/janela.py`: liga o evento de candidatura e os callbacks à geração
  vigente; inicia um único observador também no monitor de login manual;
  conserva oferta manual após falha automática quando a segurança permite.
- `tests/test_sucessao_recorrente.py`: sete testes novos de fila A/B, provas,
  posições, cancelamento por servidor e escolha manual/automática.
- `tests/test_supervisao_principal.py`: caso adicional ligando prova real do
  ciclo, leitor rearmado, evento e observador da interface sem duplicação.
- `tests/ensaio_recuperacao_manual_tk.py`: observador único no Tk real oculto.

## Validação e limites

Regressão final: **2.124 testes aprovados em 43,683 s**, **146 arquivos Python
compilados em memória**, `git diff --check` e ensaio Tk real oculto aprovados.

Os testes de sucessão usam leitores/eventos reais, com transporte e credenciais
simulados; a sequência A/B é repetida por gerações. O prazo foi reduzido a zero
somente nesses ensaios; em produção continua posição × 30 s. O caso posição 2
verifica espera de 60 s e cancelamento ao detectar outro PRINCIPAL. Testes
operacionais de localhost, prontidão, CONFIG/SUBSCRIBE, B2 e reabertura permanecem
na regressão. Nenhum ensaio com TC420/PC remoto foi executado pelo agente.

Descoberta não garante exclusividade distribuída. Pendências conhecidas continuam
causando recusa conservadora. Login salvo é opção local de cada PC; login automático
desativado não desativa sua candidatura manual. PasswordDeleteError é ocorrência
separada, não corrigida nesta etapa. Estudos de memória não foram alterados.

## Repetição física

Usar a mesma versão atualizada em A e B, sem pesagem operacional. Anotar versão,
horários, método de falha e restauração. Não encerrar o aplicativo para simular
a perda da fonte durante o ensaio de supervisão.

1. A lê TC420 e B registra como CLIENTE, posição 1.
2. A perde a fonte, encerra seu ciclo e procura servidor. B assume após a fila,
   manualmente ou com login salvo, com prontidão comprovada.
3. A conecta a B. Confirmar REGISTER/posição e a nova mensagem de candidatura
   rearmada, além de peso, tara e faixas atualizados.
4. B perde a fonte e encerra seu ciclo. A deve mostrar posição 1, contagem de
   30 s e candidatura detectada. Com login salvo desativado deve abrir ASSUMIR;
   com login salvo habilitado deve tentar o worker de promoção automática.
5. Restaurar disponibilidade da TC420 para A conseguir autenticar e iniciar
   o serviço. B conecta a A e rearma sua própria candidatura após nova amostra.
6. Repetir a troca seguinte para confirmar B→A→B, sem reiniciar os aplicativos.
   Guardar anúncios de prontidão, estados, leituras e confirmações B2 de saída.

Restauração da fonte deve ser controlada: TC420 ainda inacessível não permite
anunciar promoção bem-sucedida. Aprovação física desta correção continua pendente.

# Recuperação manual após rebaixamentos sucessivos

Auditoria e protótipo isolado — 13/11/2026. Este documento conserva o escopo
experimental original. A autorização posterior e a implementação operacional
estão em [integração A/B](INTEGRACAO_RECUPERACAO_MANUAL_AB.md), com validação física
pendente. Investigação de memória permanece
encerrada; Fases 1/2 do histórico lógico continuam não autorizadas.

## Comportamento auditado

- `rede/supervisao_principal.py`, `_executar`: aguarda retorno do coordenador e
  `avaliar_encerramento_tentativa(...)[encerramento_confirmado] is True`; cria
  leitor acompanhado por SaidaAplicacao com `permitir_candidatura=False`.
- `rede/lerdadosserver.py`, `_aguardar_candidatura`: retorna sem sinalizar evento
  quando a candidatura está desabilitada. Não distingue oferta manual de automática.
- `interface/janela.py`, `verificar_candidatura`: o evento libera tanto a tentativa
  automática quanto o formulário manual. `supervisionar_principal` remove o
  callback de candidatura ao instalar o leitor recuperado.
- `interface/conexao.py`, `abrir_monitor`: o monitor do PRINCIPAL de login manual
  não recebe `ao_promover`; apenas liberar um botão nesse monitor não resolve.
- `main.py`, callback `promover_para_principal`: fecha sobre o leitor inicial,
  faz descoberta, login e approval, admite a tentativa, inicia thread e para esse
  leitor. Não é um serviço reutilizável ligado explicitamente ao leitor atual.
- `JanelaTC420.concluir_promocao`: anuncia promoção após retorno do callback.
  O callback não aguarda confirmação conjunta de listeners e primeira leitura
  HTTP válida. Login/approval e thread iniciada não provam prontidão do serviço.

Consequência: A e B já rebaixados podem buscar indefinidamente sem oferecer
ASSUMIR. A limitação não autoriza simplesmente reativar a candidatura automática.

## Protótipo executável

`prototipos/recuperacao_manual.py` é modelo síncrono, sem Tk, threads próprias,
credenciais, descoberta LAN ou partida do servidor operacional. Não é importado
pela aplicação. Callbacks de IO/partida são injetados pelos ensaios.

`RecuperacaoManual` mantém a candidatura automática permanentemente desabilitada.
`oferta_manual()` permite apenas apresentar a ação se todos os contextos retidos
têm prova positiva e o monitor está vigente; não faz IO, não inicia promoção.
`solicitar_manual()` é uma ação explícita que:

1. Recusa operação local concorrente, monitor inválido ou contexto pendente.
2. Exige descoberta com resultado explicitamente negativo; incerteza bloqueia.
3. Exige acesso à fonte confirmado pelo adaptador de autenticação/configuração.
4. Reavalia provas, vigência e descoberta depois desse acesso.
5. Prepara e retém um novo contexto antes de solicitar sua partida.
6. Só retorna `promovida` após prontidão positiva e vigência atual.

O adaptador `ciclo_resolvido` usa o avaliador real de encerramento e exige retorno
do coordenador. Todos os contextos informados são conservados. Partida que lança
exceção ou retorna sem prontidão não libera outra tentativa por inferência: seu
contexto retido precisa obter prova positiva. `observar_rebaixamento` apenas
reabre a oferta depois da resolução de todos os contextos conhecidos.

Contratos injetados: `buscar` retorna False/True/None para ausência/presença/incerto;
`fonte` só retorna True após acesso atual válido; `preparar` é criação pura de
contexto sem IO/start; `iniciar` recebe contexto já retido; `pronto` exige listeners
ativos e primeira leitura atual. Os dublês que retornam True não comprovam esses
fatos em produção. Nenhuma credencial é armazenada no modelo ou nos testes.

## Verificação dos cenários

| Cenário exigido | Evidência experimental |
| --- | --- |
| A perde a fonte e B assume manualmente | Modelo de transições com prova anterior e ação manual explícita |
| B perde a fonte e encerra responsabilidades | Modelo mantém B bloqueado até resolução positiva; adaptador usa registros reais |
| Ambos procuram outro PRINCIPAL | Ausência simulada permite oferta manual nos dois; automático segue proibido |
| Nova solicitação manual | Revalida provas e descoberta; testes de clique concorrente e mudança durante login |
| Pendência, incerteza ou outro PRINCIPAL | Recusa explícita; socket real aberto e erro de limpeza bloqueiam o adaptador real |
| Outro computador recebe configuração e peso | Leitor de produção recebe CONFIG/REGISTER/SUBSCRIBE por sockets reais em localhost, com serviço sintético |
| TC420 inacessível ou serviço sem primeira leitura | Não anuncia sucesso; partida incerta continua retida |

Teste localhost não acessa TC420 nem inicia o servidor operacional. A sequência
A/B é simulada; não representa dois PCs físicos. A recepção pelo leitor demonstra
compatibilidade do protocolo no ensaio, não eleição distribuída ou validação Tk.

## Trabalho necessário antes de integração

Separar o serviço de promoção dos callbacks fechados sobre leitores antigos e
fornecê-lo também ao monitor criado por login manual. Oferta manual não pode
invocar o callback automático, mesmo com credenciais salvas. Contexto/geração do
monitor devem invalidar resultados antigos. Rede e espera por prontidão devem
usar workers acompanhados e aplicar resultado apenas no Tk vigente.

A produção deve reter e avaliar todas as tentativas relevantes, não somente o
último ciclo. SaidaAplicacao e RegistroTentativasAplicacao precisam admitir a
operação e a partida de forma coordenada com saída/cancelamento. O modelo verifica
vigência entre etapas, mas não torna atômica a janela entre a última consulta e
start: essa garantia depende dos gates operacionais existentes. Preparar contexto
não pode alocar recursos antes de publicá-los; falhas de start continuam ambíguas.

Criar sinal de prontidão do novo contexto: listeners TCP/UDP confirmados, fonte
atual e primeira amostra válida, com prazo de espera e limpeza acompanhada em
falha/timeout. Nenhuma interface deve anunciar promoção só porque thread.start
retornou. Manter critérios B2 e supervisão; não usar ausência de thread viva como
substituto de prova de encerramento.

Duas descobertas negativas não garantem exclusividade entre máquinas. Os dois
usuários ainda podem tentar simultaneamente e a rede pode estar particionada.
Não há consenso, lease ou trava distribuída neste protótipo; nenhuma garantia
nova contra dois PRINCIPAIS é declarada.

Critérios para eventual implementação: testes com os gates reais de saída,
partida ambígua, erros de limpeza, callbacks antigos, cancelamento durante IO,
listeners indisponíveis, fonte perdida entre login e prontidão, ausência de
automação de candidatura e preservação de ciclos/tokens anteriores; regressão
completa e Tk offline. Depois, repetir A→B→A e B→A→B fisicamente, com revisões e
horários registrados, sem pesagem operacional. Integração exige nova etapa.

## Operação atual

Validação experimental: **15 testes específicos aprovados**; regressão final
de **2.099 testes aprovados em 20,018 s**. Uma execução anterior, antes do último
teste de socket/erro de limpeza, aprovou 2.098 testes. Não houve ensaio físico,
login real ou interação Tk nesta etapa.

Enquanto não houver integração, reconfigurar ou encerrar com SIM e reabrir apenas
um PC, concluir a parada comprovada e iniciar pelo fluxo normal com TC420
acessível. O outro aguarda como CLIENTE. O protótipo não altera esse procedimento.

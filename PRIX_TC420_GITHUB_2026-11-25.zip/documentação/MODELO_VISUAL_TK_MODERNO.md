# Modelo visual Tk — 13/11/2026

**Integração aprovada e realizada posteriormente nesta data:** telas reais usam
agora `interface/formularios.py`; monitor preserva aparência, com avisos/bandeja
opcionais. Seções abaixo registram evolução do protótipo e suas limitações na
época. Estado operacional e backup em [INTEGRACAO_VISUAL_001.md](INTEGRACAO_VISUAL_001.md).

## Seletor de método de conexão

Abaixo do campo senha, conexão e ASSUMIR oferecem **Método de conexão**:
HTTPS (padrão) e TCP. Controles de seleção única impedem marcar ambos.
Botão circular **i** à direita mostra dica do método selecionado no hover,
também acessível por clique. HTTPS explica comunicação web com TLS;
TCP explica socket, porta informada (9800 inicial) e ausência de criptografia
inerente ao TCP. Ambas as dicas indicam tratar-se de demonstração.

Seleção não altera protocolo operacional, não habilita HTTPS, não salva
configuração e não abre rede. Integração de protocolos exige etapa específica.
Dimensões atuais: conexão **560×600**, ASSUMIR **560×550**, para acomodar a
linha adicional sem cortar ação ou rodapé. Fontes e monitor preservados.
Autoteste Tk real cobre HTTPS padrão, seleção alternada, texto e janela da
dica e as verificações de layout anteriores.

## Logo suavizada com Lanczos

Revisão atual mantém **90×90 pixels**, conforme tamanho escolhido pelo
responsável, com filtro Lanczos e transparência RGBA. Original intacto.
Sem Pillow instalado, usa assets/logotc420-90-lanczos.png pré-processado;
não precisa instalar pacote para abrir o modelo padrão. Com Pillow, gera a
miniatura na abertura com o mesmo filtro. Ambos os caminhos passaram no
autoteste Tk real. Espaçamento reduzido para manter o botão sem recorte.

Para mudar tamanho, altere `janela.tamanho_logo = 90` no formulário e instale
a dependência opcional com `python -m pip install -r tests/requirements-visual.txt`.
O caminho sem Pillow tem apenas o asset de 90; para outro tamanho, informa
necessidade do pacote em vez de voltar à redução serrilhada. Autoteste acompanha
o alvo configurado. Detalhes muito pequenos continuam limitados pela resolução
final; Lanczos suaviza bordas, sem tornar legível todo texto da foto original.

## Logo e botão do ensaio

Conexão e ASSUMIR mostram logo existente à direita do título, reduzida
proporcionalmente para aproximadamente 74 pixels (ampliada após avaliação do responsável).
Marca e título agrupados à esquerda preservam o espaço dos campos sem aumentar
as janelas. Ao lado de `v0.0.1 · Pablops2god`, botão
quadrado 34×34 com símbolo de grade. Passe o mouse por 450 ms para ler
**Abrir ensaio visual Tk**; a dica não captura foco e desaparece ao sair/clicar.

Correção posterior: imagem que ficava transparente por combinação de zoom e
subsample agora usa redução inteira simples. Autoteste exige pixels não
transparentes e tamanho entre 64 e 80, além de widget mapeado. Validação apenas
de tamanho/presença do widget, usada antes, não comprovava conteúdo visível.
Clique abre **o ensaio original**, `tests/ensaio_visual_tk.py`, sem --moderno,
em outro processo. Feche esse ensaio pela sua própria janela de controle;
o modelo moderno permanece aberto. Caminho absoluto e Python atual dispensam
dependência do diretório de execução; nenhuma chamada a main.py.

Autoteste verifica presença e dimensões, exibição/remoção da dica e callback
de lançamento com subprocesso simulado. A abertura efetiva por clique fica
para conferência manual. Mudança continua somente no modelo.

## Revisão compacta e versão 0.0.1

Versão informada pelo responsável: **0.0.1**. Rodapé inferior direito em conexão
e ASSUMIR: **v0.0.1 · Pablops2god**. Identificação deste modelo; não cria mecanismo
de versionamento/release operacional. Textos, campos, caixa e rodapé em fonte
14; títulos e ações principais em 18. Painel auxiliar mantém sua tipografia.

Rótulos ao lado dos campos reduzem altura: conexão **560×560**, ASSUMIR
**560×510**, em vez de 470×710 e 470×640. A largura aumentou para acomodar as
fontes solicitadas; altura e área total diminuíram. Rodapé reservado em região
separada do botão. Centralização e monitor original preservados. Autoteste
verifica fontes, versão/autor, visibilidade do rodapé e ausência de sobreposição
do botão. Escalas DPI diferentes ainda dependem da inspeção no desktop real.

## Revisão após avaliação do responsável

Responsável aprovou aparência da conexão e informou que as notificações
funcionaram no seu teste. Esse relato valida o aviso no ambiente dele, sem
representar uma execução independente pelo agente ou prova de aviso ligado a
falha real do servidor. Não foi informada confirmação de clique na bandeja.

Solicitado preservar visual do monitor: o modelo agora abre `JanelaTC420`
original com dados locais, sem redesenhar seus widgets. Centralização inicial
e minimização continuam disponíveis no ensaio. Tema preto restrito à conexão
e ASSUMIR. Botões principais receberam duas linhas de altura e espaçamento
vertical maior; janelas ampliadas para evitar compressão/corte dos botões.
Ambos os formulários mostram **Porta TCP**, inicialmente **9800**. Campo ainda
é visual: não altera porta de serviço, descoberta ou configuração operacional.

Autoteste Tk real aprovado para ambos os formulários: porta presente, botão
com pelo menos 60 pixels e integralmente dentro da janela, centralização e
minimização/restauração do monitor original. Visual final ainda sujeito à
conferência do responsável em sua escala de tela. Nenhum arquivo operacional
alterado nesta revisão.

Solicitação: padronizar conexão e ASSUMIR com fundo preto, centralizar essas
janelas e monitor, manter arraste/minimização e experimentar bandeja e avisos.
Implementação exclusivamente no ensaio; arquivos operacionais não alterados
nesta solicitação. Não integra as fases de memória nem modifica B2/sucessão.

## Abrir e comparar

Na raiz do projeto:

```powershell
python -B tests/ensaio_visual_tk.py --moderno
```

Abre painel de ações e formulário de conexão. Use o painel para abrir ASSUMIR e
monitor, simular conexão e queda e minimizar monitor. Todas as telas nascem no
centro, portanto podem se sobrepor; arraste pela barra de título nativa.
O painel fecha todo o modelo e remove seu ícone da bandeja. Fechar os formulários
ou o monitor afeta somente aquela janela, permitindo reabri-la pelo painel.
O ensaio antigo continua disponível sem `--moderno`.

## Aparência e comportamento implementados no modelo

Fundo quase preto, campos cinza escuro, tipografia Segoe UI, textos claros e
ação verde. Formulários compartilham espaçamentos e caixa de login automático.
Essa caixa é somente visual: o modelo não lê os campos, autentica, grava senha,
configuração ou acessa a TC420. Não informar credenciais reais.

Monitor utiliza a classe operacional original com fonte simulada e conserva
seu visual. O ensaio não executa `main.py` ou serviços operacionais.
Janelas conservam molduras Windows, ícone da aplicação, movimentação e
minimização; não utilizam `overrideredirect`. Centralização usa tela primária,
na abertura, sem forçar posição durante arraste. Multimonitor/DPI ainda precisam
de conferência visual no desktop do responsável.

Bandeja experimental usa `Shell_NotifyIconW`, sem dependências adicionais.
Ícone da bandeja é o símbolo padrão do Windows, provisório, com tooltip TC420;
as janelas usam o logo existente. Clique esquerdo/direito no ícone restaura o
monitor. Minimizar conserva sua entrada normal na barra de tarefas. O ícone
da bandeja existe enquanto o modelo está aberto e pode ficar na área de ícones
ocultos conforme configuração do Windows. Não altera preferências do sistema.

Botões de conexão/queda solicitam balões nativos e atualizam status no painel
e monitor. Estes eventos são simulados, não notificações operacionais reais.
Windows pode suprimir balões; não há garantia de aviso visível no modo Não
Perturbe. Não há integração com central moderna de notificações persistentes.

## Verificações e limitações

```powershell
python -B tests/ensaio_visual_tk.py --moderno --autoteste
```

Tk real confirmou construção, centro das janelas verificadas, molduras e
minimização/restauração. 17 testes existentes do monitor visual aprovados;
ensaio de recuperação manual Tk oculto aprovado. Diff sem erros de whitespace.

Este desktop de execução não expôs `Shell_TrayWnd`: registro do ícone retornou
False. O autoteste registra essa pendência explicitamente, sem aprovar bandeja
ou notificações. Captura por Computer Use indisponível (native pipe ausente),
inclusive após recuperação do serviço cliente. Não foi possível conferir
captura visual, arraste manual, clique real na bandeja ou balão no desktop.

Antes de integrar, conferir no Windows do usuário: tamanho/recorte dos campos,
contraste e escala, arraste, minimizar pelo botão da moldura, restaurar pela
bandeja e avisos simulados com janela minimizada. Nenhum teste físico da TC420
foi realizado. Integração nos arquivos principais fica para etapa posterior
à avaliação deste modelo.

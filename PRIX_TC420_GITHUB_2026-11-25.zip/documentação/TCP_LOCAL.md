# TCP local — 13/11/2026

## Evidência física positiva após ajuste — 18/11/2026

Responsável confirmou “ficou estável agora” e forneceu sessão sem alternância
de frescor: 90 bytes/5 frames válidos, zero rejeitados/pendentes, sem erro;
intervalo último **6,306 s**, máximo **6,307 s**, idade na amostra **5,776 s**.
Intervalos medidos no leitor excedem os 3 s antigos e cabem nos 10 s atuais.
Isso sustenta o diagnóstico de tolerância curta nessa sessão, sem demonstrar
a origem da cadência de envio. Não houve mudança adicional de tolerância.

Encerramento reportado confirmou parada operacional no escopo acompanhado,
com cobertura global desconhecida. Log e confirmação são do responsável,
não teste executado pelo agente. Estabilidade prolongada e validação de peso
diferente de zero/unidade continuam fora do que essa evidência comprova.

## Tolerância revisada após alternância relatada — 18/11/2026

Registro recebido mostra uma conexão e leituras alternando frescor, sem erros
de socket/reconexão. O código não reconecta automaticamente; os avisos eram
acionados pela idade maior que 3 s do último frame válido. Isso não comprova
queda física. Sem timestamps/contadores, a causa dos intervalos entre frames
válidos (envio, rede ou rejeição de formato) continua não determinada.

Regra atual de frescor TCP: **10 s**, definida por TOLERANCIA_LEITURA_TCP em
rede/tcp_local.py e opcionalmente pelo parâmetro tolerancia do leitor.
Não é tempo do socket: connect continua 5 s, recv 0,5 s e espera inicial 8 s.
recv timeout não encerra conexão nem renova peso. Leitura do dicionário/refresh
também não renova idade; somente frame válido o faz, mesmo com peso igual.
Socket encerrado ou parada torna a fonte indisponível sem esperar a tolerância.
Acima de 10 s sem frame, a interface sinaliza última leitura. É tolerância
fixa escolhida para reduzir falsas oscilações, não cadência medida/garantida.

Aviso de falha TCP exige estado indisponível contínuo por **2 s** nas consultas
da interface; o monitor mostra indisponibilidade antes do aviso. Breve oscilação
recuperada nesse prazo não emite queda nem novo sucesso. Falha confirmada avisa
uma vez, e retorno posterior avisa uma vez. Falhas/avisos HTTPS preservados.
Latência inclui intervalo de atualização do Tk; notificação não é prova B2.

Linhas TCP LOCAL: amostra atual/indisponível agora trazem **validos**,
**intervalo_ultimo_s**, **intervalo_maximo_s**, **idade_leitura_s**, tolerância e
contadores anteriores. Máximo é desde a criação do leitor, sem guardar histórico
de intervalos. Uma linha por transição ou 30 s; conteúdo dos frames não é salvo.
Comparar contadores em execução real permitirá diferenciar intervalos de
recepção válida e rejeição do formato. Permanecem pendentes medição física e
compatibilidade definitiva; aumentar tolerância não corrige protocolo incorreto.

## Diagnóstico após falha relatada em 18/11/2026

Log físico enviado continha somente ConnectionError genérico. Não permite
afirmar porta errada, serviço recusado, falta de transmissão ou formato diferente.
Corrigida a apresentação: erro TCP específico chega sanitizado à interface.

Em nova tentativa, procurar:

- `abrindo conexão`: worker tentou abrir o destino configurado.
- `socket conectado`: connect retornou, ainda não comprova leitura de peso.
- `diagnóstico`: abriu, bytes, rejeitados, pendentes, falha e erro_sistema.
- `leitura válida`: primeiro frame interpretável e atual, com admissão concluída.

Socket aberto com zero bytes gera “nenhum dado recebido”; bytes insuficientes
geram frame incompleto; frames de 18 rejeitados geram formato incompatível.
Recusa, timeout de conexão e encerramento remoto têm categorias próprias.
Contadores não guardam conteúdo, não comprovam protocolo da balança e não
substituem validação física. O parser permanece legado, sem detecção automática
de outros layouts. Mensagens também se aplicam ao formulário ASSUMIR via worker.

Testes são localhost/simulados. Nova tentativa no equipamento e suas linhas
TCP LOCAL são necessárias para concluir a causa do incidente relatado.

Responsável identificou que selecionar TCP ainda entrava em HTTPS e exigia
credenciais. Confirmou explicitamente: TCP é **local apenas**, sem servidor.
O transporte legado ainda existe em tc420/conexao.py e seu interpretador de
frames é reaproveitado; a integração nova usa um leitor próprio com ciclo de
vida acompanhado, sem ativar o leitor legado bloqueante da janela.

## Comportamento implementado

Na conexão e em ASSUMIR, escolher TCP desabilita usuário, senha e salvar login.
Só IP e porta válidos são necessários; nome também é opcional nesse modo.
Porta inicial 9800. Botão passa a CONECTAR TCP. Escolher HTTPS reabilita campos
e preserva o fluxo anterior com autenticação e eventual promoção/distribuição.

O ramo TCP não consulta servidor, não faz login/approval/refresh HTTPS, não usa
cofre, não salva credenciais, não cria TCP/UDP de distribuição e não participa
da fila. Uma falha TCP permanece falha TCP, sem fallback silencioso para HTTPS.
No bootstrap geral, main.py ainda realiza sua descoberta/login automático
anteriores antes de abrir a tela; esta alteração governa a escolha feita no
formulário e não cria uma preferência de inicialização persistente.

`rede/tcp_local.py` abre socket no worker, recebe frames de 18 bytes e reutiliza
tc420.protocolo.interpretar_peso. Primeiro frame válido e comunicação recente
são exigidos antes de trocar para o monitor local. Acumula fragmentos e extrai
frames completos; buffer permanece limitado pelo tamanho da leitura.

O peso mantém a interpretação em kg do leitor gráfico legado; isso não aprova
escala física ou interpretação de outros layouts. Não se inventam tara, faixa,
limites, zero ou estabilidade: tara/faixas mostram —, indicador do modo mostra
TCP, cópia de tara fica desabilitada. O campo interno peso_liquido é apenas a
interface histórica do monitor; valor vem do campo de peso do frame, sem
comprovar líquido versus bruto no equipamento. Não se deduzem dados ausentes.

Leitura passa a indisponível se socket encerrar ou amostra exceder 10 segundos.
Último peso fica identificado como leitura anterior; não há reconexão TCP
automática ou candidatura. Para outra conexão use reconfiguração/manual.
O monitor conserva a aparência, com status específico TCP local e notificações.

## Segurança do ciclo

Não inicia se houver ciclo local de servidor pendente. A troca a partir de
ASSUMIR só desliga leitores anteriores após obter frame TCP válido; exige fim
das threads e prova das responsabilidades CLIENTE antes de publicar a fonte.
Cancela a supervisão anterior apenas após troca admitida. Conexão falha antes
do primeiro frame mantém leitor anterior; pendência posterior é recusada e
pode exigir nova avaliação/reconfiguração. Provas existentes não são relaxadas.

Thread e leitor são retidos pela SaidaAplicacao antes do start; B2 chama parar,
fecha o socket e espera a thread. Socket permanece referenciado se close falhar;
parada não confirma enquanto limpeza falhar. Timeout de recv é 0,5 segundo e
connect 5 segundos; espera de primeiro frame é limitada e ocorre fora do Tk.
Nenhuma alteração nas certificações globais ou política de memória 2B.

## Backup e verificação

Antes da correção, preservados os quatro arquivos de interface em
backups/antes_tcp_local_2026-11-13_6c816025/originais.zip, com manifesto SHA-256.
Backup da integração anterior permanece disponível.

Oito testes específicos: fragmentação, ausência de metadados inventados, B2,
frame inválido, amostra antiga, close falho retido e não confirmado pela B2,
ciclo anterior pendente e parada/start duplicado. Inventário estático inclui
socket do novo leitor como transporte local fora do leitor CLIENTE distribuído.

`python -B tests/ensaio_tcp_local_tk.py` exercita telas reais de conexão e
ASSUMIR com servidor sintético em localhost e campos vazios: nenhuma chamada
HTTPS/UDP/cofre, peso recebido, troca local e encerramento B2. Não cria servidor
da aplicação; socket de escuta existe somente na balança sintética do teste.
Ensaio visual integrado e compilação em memória também aprovados.

Regressão final: **2.145 testes aprovados em 43,204 s**, **155 arquivos Python
compilados em memória** e `git diff --check` aprovado. Backup de quatro arquivos
também teve integridade e hashes verificados.

Não houve acesso à TC420 real, interrupção física ou aprovação de layout TCP
real. Compatibilidade dos frames, unidade e periodicidade precisam ser
conferidas no equipamento em janela controlada. Essa validação é distinta do
sucesso dos testes simulados.

# Integração visual 0.0.1 — 13/11/2026

**Atualização funcional posterior:** [TCP_LOCAL.md](TCP_LOCAL.md). Seletor agora
despacha TCP local real sem credenciais; descrições abaixo de opção apenas
visual registram o escopo da integração inicial, anterior à correção.

Responsável aprovou integrar o modelo e solicitou backup antes das alterações.
Implementação aplicada às telas reais de conexão e ASSUMIR, preservando os
callbacks de login, descoberta, promoção, supervisão e encerramento.

## Backup

originais.zip (material local não incluído)
foi criado antes das mudanças operacionais: 41 arquivos, com hashes SHA-256
no manifesto interno e integridade verificada. Inclui main.py, os módulos
anteriores de interface/config/rede/tc420, imagens e ensaios visuais. Não contém
configuração local, cofre, caches ou credenciais de execução. Preserva o estado
local anterior, não apenas o último commit. Não é backup integral do projeto.
Instruções em LEIA_ME.md junto do ZIP. Nenhum commit ou push realizado.

## Comportamento integrado

`interface/formularios.py` monta as duas telas com fundo preto, campos escuros,
fonte comum 14, títulos/ação 18, logo suavizada 90×90, versão 0.0.1 e autor
Pablops2god. Alturas 600/550, largura 560, molduras nativas e centro inicial.
As janelas continuam arrastáveis/minimizáveis. Centralização usa tela primária.

Botão quadrado do rodapé tem dica e abre tests/ensaio_visual_tk.py original
em processo separado. Não abre main.py. Quando o script não está distribuído
ou em aplicação congelada, informa indisponibilidade em vez de relançar o exe.
Seu processo precisa ser encerrado pelo próprio painel do ensaio.

Conexão mantém campos/preenchimento/configuração originais e opção de salvar.
ASSUMIR mantém o trabalho assíncrono, gravação optativa após promoção positiva
e proteções contra cancelamento indevido. A porta mostrada em ASSUMIR é 9800,
informativa nesta integração; não modifica os callbacks de promoção existentes.
Porta da conexão mantém comportamento anterior. Não foram alteradas as portas
42100/42101 de distribuição/descoberta nem a política HTTP/HTTPS.

Seletor HTTPS/TCP é visual, HTTPS padrão; não altera protocolo ou persistência.
WebTC420 já usa HTTPS no fluxo existente. Escolher TCP não muda esse caminho;
a dica informa explicitamente. Não é uma nova implementação de transporte TCP
direto, negociação TLS ou validação de certificados. Requer etapa específica.

## Monitor e notificações

Monitor conserva cores, widgets, faixas e disposição anteriores. Apenas
centralização inicial e integração opcional de bandeja/avisos são acrescentadas.
`interface/notificacoes.py` usa Shell_NotifyIconW no Tk, sem novas threads.
Ícone padrão Windows com tooltip PRIX TC420; pode aparecer na área de ícones
ocultos. Clique restaura o monitor, e a minimização mantém entrada normal na
barra de tarefas. Não oculta o processo ou altera política de encerramento.

Avisos ocorrem em transições para leitura atual disponível e após perda dessa
disponibilidade. Não repetem a cada amostra; início sem conexão não é anunciado
como queda. Promoção em andamento não produz aviso intermediário de queda.
Aviso de perda indica indisponibilidade de comunicação, não comprova morte
do processo remoto. Estado na janela continua sendo a referência operacional.

Timer e ícone são removidos ao destruir a janela; WndProc original restaurado.
Falha/ausência do serviço de bandeja não bloqueia conexão ou B2. Balões podem
ser suprimidos pelo Windows/Não Perturbe. Não há registro persistente na central
de notificações nem recuperação garantida do ícone se Explorer reiniciar.
Não foi ampliado o escopo global dos certificados B2.

## Verificações

- Regressão: **2.137 testes aprovados em 38,113 s**.
- **152 arquivos Python compilados em memória**, excluindo referência/caches.
- Tk real integrado: ambas as telas, fontes/layout, logo, rodapé, seletor/dicas,
  cores originais do monitor, minimizar/restaurar e limpeza de bandeja no Destroy.
- Ensaio de recuperação manual Tk oculto e modelo moderno aprovados.
- Cinco testes novos de avisos: startup, repetição, queda/retorno, promoção e
  ausência de bandeja. Inventário revisado inclui novo recurso PhotoImage Tk.
- Dublês do formulário em testes HTTP atualizados para isolar apresentação;
  callbacks e provas continuam testados. `git diff --check` aprovado.

Nenhuma comunicação física com a TC420, cofre real ou reinício de aplicativo
operacional foi executado. Desktop do agente não expõe Shell_TrayWnd: clique
real no ícone e balões integrados permanecem pendentes no desktop do usuário.
Confirmação anterior de notificações refere-se ao modelo, não a esta integração.
Multimonitor/DPI e comportamento físico A/B precisam de conferência controlada.

Ensaio sem rede: `python -B tests/ensaio_integracao_visual_tk.py`.
Aplicação normal mantém entrada `python main.py`; não foi iniciada pelo agente.

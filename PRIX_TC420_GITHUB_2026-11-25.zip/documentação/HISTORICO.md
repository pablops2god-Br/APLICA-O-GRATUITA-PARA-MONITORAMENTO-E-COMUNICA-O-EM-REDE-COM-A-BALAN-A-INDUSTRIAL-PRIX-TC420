# Histórico de evolução e decisões

## Adaptação do TCC aos modelos e galeria visual — 23/11/2026

Solicitação: revisar os dois DOCX fornecidos, adequar às diretrizes, incluir
interfaces e terminal e citar o manual oficial TC420. RA informado: 5186625.
Identificado formato de artigo com seis seções, até 15 páginas e 25 incluindo
apêndices/anexos. A versão extensa de 43 páginas foi preservada em backup ZIP
e em DOCX/PDF separados antes da substituição dos entregáveis vigentes.

Artigo reescrito e gerado a partir de cópia verificada do modelo PI, com Arial,
geometria de página/margens do modelo, resumo de 224 palavras, legendas e tabela
quantitativa com linhas horizontais. Referencial integrado às seções. Capa,
aprovação e sumário da monografia não pertencem ao artigo; permanecem no anterior.
Guia de Engenharia de Software tratado como orientação, sem mudar o curso do
autor ou copiar exemplos. Uso de IA declarado com necessidade de revisão humana.

Capturados widgets reais em ensaio offline: cadastro, login, conexão, ASSUMIR,
monitor, opções, laboratório e registro. Sem credenciais reais, rede ou cofre.
O botão Abrir terminal está desabilitado; registro do laboratório não foi
apresentado como console operacional. Imagem do TC420 extraída do manual do
fabricante. Arquivo oficial consultado tem 118 páginas e capa Rev. 04-04-20,
código 3474436; essa revisão prevaleceu sobre o trecho de busca divergente.
Manual incluído nas citações e referências, sem atribuir-lhe o protocolo do app.

Conferidos hashes dos dois originais, propriedades do modelo, captura offline,
campos e PDF exportado pelo Word. A renderização somente leitura dos modelos
não concluiu no ambiente; a estrutura e os estilos foram auditados em OOXML,
e o documento final foi renderizado para revisão visual. Métricas, procedência
e verificações em APRESENTACAO_TCC/TCC/06_verificacao. Não houve nova regressão
completa, teste físico, alteração operacional, commit ou push.

Resultado da conferência: artigo/referências em 12 páginas e total de 20,
10 figuras, 1 tabela, 17 referências, resumo de 224 palavras. Hashes dos dois
originais confirmados, geometria e mídias opacas do modelo preservadas, sem
marcadores de geração ou links locais ausentes. Galeria e PDF final revisados.

## Redação integral do TCC e pesquisa bibliográfica — 23/11/2026

Solicitação: produzir TCC com estrutura acadêmica, resumo/abstract, objetivos,
metodologia, referencial, desenvolvimento, resultados, conclusão, sumário,
tabelas, imagens, fluxogramas e referências reais, usando o histórico de Chats.
Dados informados: UNISA campus Parauapebas, Engenharia da Computação, Pablo
Henrique Santos de Sousa e orientadora Prof.ª Ma. Amanda da Silva Ferreira.
Adotada grafia Santos da folha de rosto, pendente confirmação da variante Santo.

Criado APRESENTACAO_TCC/TCC, separando texto Markdown, figuras autorais, pesquisa,
scripts de geração, entregáveis e verificação. Redação com oito seções, cinco
figuras, cinco quadros, uma tabela quantitativa e três apêndices. Referencial
verificado em livro, artigos, relatórios técnicos, RFCs e documentação oficial;
paráfrases sem páginas ou experimentos inventados. Consulta de Chats dirigida,
não auditoria integral. Métricas de testes e campo mantidas como resultados
anteriores registrados/relatados, não novas execuções.

Apresentação baseada nas edições conferidas NBR 14724:2024, 10520:2023 e
6023:2025, sem manual específico UNISA fornecido. Word atualizou os campos e
exportou PDF; revisão de paginação inclui correção da contagem desde a folha
de rosto, sumário e quebras de tabelas. Renderizador LibreOffice indisponível
no ambiente; utilizado Word instalado, com rasterização Poppler do PDF.
Índices documentais e registro da pesquisa atualizados.

Uso de IA declarado; não houve ferramenta de similaridade, aprovação acadêmica,
nova execução de testes/TC420, alteração operacional, firewall, commit ou push.
Epígrafe atribuída a Sutherland omitida sem fonte original verificável. Ficha,
data da banca e examinadores dependem da instituição. Conferência final no
diretório TCC/06_verificacao.

Conferência concluída: PDF com 43 páginas, fonte com 8.627 palavras por contagem
simples, 16 referências externas, 5 figuras, 5 quadros, 1 tabela e 3 apêndices.
Sem links locais ausentes nos novos Markdown; scripts de geração compilados
sem execução operacional. Bordas automáticas dos títulos removidas e imagens
renderizadas revisadas; métricas e manifesto SHA-256 gravados.

## Commit documental do TCC — 23/11/2026

Solicitação: criar commit apenas do necessário. Escopo separado para o dossiê
APRESENTACAO_TCC, guia do TCC escrito, manifestos documentais e trechos relacionados
do índice/histórico. Alterações anteriores de código, testes, empacotamento,
configuração local, executáveis e backups permaneceram fora da seleção.
Verificação documental e revisão da seleção do Git, sem reexecutar suíte ou
equipamento. Commit local autorizado; sem push.

## Retorno físico positivo da tolerância TCP — 18/11/2026

Responsável informou estabilidade melhor e enviou log físico após ajuste para
10 s. Segunda amostra diagnóstica: 90 bytes, 5 frames válidos, zero rejeitados
ou pendentes, sem falha/erro de sistema; intervalo último 6,306 s e máximo
6,307 s, idade 5,776 s. Demonstra recepção válida em cadência superior ao limite
anterior de 3 s, compatível com os falsos avisos observados anteriormente.
Não identifica sozinho por que o equipamento transmite nessa cadência.

Trecho não mostra indisponibilidade ou novas reconexões. Responsável confirmou
melhora e saída solicitada terminou com parada operacional comprovada no escopo
acompanhado, cobertura global desconhecida. Evidência fornecida pelo usuário,
não execução independente do agente. Aprovação restrita à sessão apresentada:
não comprova estabilidade prolongada, peso não zero, unidade/escala ou todas
as configurações de protocolo. Sem nova alteração de código/testes/commit/push.

## Tolerância e avisos do TCP local — 18/11/2026

Responsável enviou leitura TCP válida seguida de alternância repetida entre
atual/última leitura e notificações de queda/retorno. Log mostra uma abertura
de socket, sem reconexão (não existe reconexão automática no leitor). Código
marcava amostra antiga após apenas 3 s desde o último frame válido; o retorno
de frescor podia disparar novo aviso. Linhas Estado eram refresh do monitor,
não prova de novas recepções. Não há timestamps/contadores para distinguir
cadência do equipamento, atrasos da rede ou frames rejeitados neste registro.

Backup anterior em backups/antes_tolerancia_tcp_2026-11-18_72f319a9/originais.zip
com três arquivos e manifesto. Tolerância local passou a 10 s, independente de
timeout de recv 0,5 s e connect 5 s. Socket encerrado/parado invalida imediatamente,
sem esperar 10 s; ausência prolongada continua indicando última leitura.
Somente aviso TCP exige falha contínua por 2 s; retorno breve antes disso
cancela o aviso e não gera nova notificação de sucesso. HTTPS não recebe atraso.

Diagnóstico ganhou quantidade de frames válidos, intervalo último/máximo e
idade da leitura. Emitido na transição de frescor e a cada 30 s, sem payload.
Mudança não é adaptação automática nem prova de estabilidade física. Corrigida
mensagem que mencionava servidor no modo TCP local. Parser/unidade/B2 e modo
sem servidor preservados. Cinco testes novos com relógio controlado cobrem
intervalos de 6 s, expiração real, parada, logs e avisos transitórios/sustentados.
Ensaio Tk localhost aprovado; teste físico atualizado depende do responsável.

Verificação desta revisão: **2.152 testes aprovados em 39,199 s**, **155 arquivos
compilados em memória**, ensaio TCP Tk localhost e diff aprovados. Integridade
e hashes do backup de três arquivos conferidos. Sem TC420 real, commit ou push.

## Diagnóstico de ConnectionError no TCP físico relatado — 18/11/2026

Responsável enviou início do main e duas mensagens genéricas de ConnectionError,
informando modo TCP sem funcionamento. Log não demonstra recusa de socket,
timeout, ausência de transmissão ou incompatibilidade do frame. Identificada
falha de apresentação: ausência de frame e leitura indisponível eram exceções
genéricas, convertidas pelo adaptador HTTP em mensagem sem motivo TCP.

Criado ErroTCPLocal com códigos/mensagens controlados. Leitor informa abertura
do socket, contadores de bytes/frames rejeitados/pendentes e categoria/número
de erro de sistema, sem conteúdo dos frames ou mensagens arbitrárias. Interface
mostra distinções entre recusa, timeout de conexão, rede, desconexão, nenhum
dado, frame incompleto, formato incompatível e leitura não atual/cancelada.
Formato legado 18 bytes e interpretação/unidade preservados; não há prova
suficiente para modificá-los como correção física. Não acessada a TC420.

Testes novos localhost diferenciam ausência de dados, fragmento incompleto e
formato inválido; simulação de recusa comprova mensagem sem conteúdo da exceção.
Ensaio Tk TCP anterior passou; layout com todas as mensagens mantém botão de
52 px visível. Diagnóstico físico conclusivo depende de nova tentativa do usuário
com linhas TCP LOCAL. Documentação atualizada, sem commit ou push.

Verificação: **2.147 testes aprovados em 48,023 s**, **155 arquivos compilados
em memória**, ensaio Tk TCP com localhost e `git diff --check` aprovados.
Esses resultados validam diagnóstico/fluxo simulado, não resolução física.

## Seleção TCP ligada ao modo local sem credenciais — 13/11/2026

Responsável apontou TCP entrando em HTTPS e pedindo usuário/senha. Confirmou
que TCP não cria servidor, é somente local. Identificado seletor ainda visual
e leitor legado apenas de peso. Preservados quatro arquivos de interface em
backups/antes_tcp_local_2026-11-13_6c816025/originais.zip antes da correção.

Integrado rede/tcp_local.py com leitura de frames legados 18 bytes e primeiro
frame válido antes de publicar. Conexão/ASSUMIR despacham TCP por IP/porta sem
nome/usuário/senha obrigatórios, HTTPS, descoberta, cofre ou servidor. Campos
de credenciais/salvar ficam desabilitados e botão indica CONECTAR TCP. Falha
não migra para HTTPS. Monitor mostra apenas peso conhecido, tara/faixas — e
status TCP; sem candidatura. HTTPS continua com o fluxo existente.

Troca exige ciclo anterior resolvido, parada dos leitores e prova CLIENTE.
SaidaAplicacao acompanha fonte e thread; close falho mantém referência e B2
não confirma. Sem reconexão/persistência de preferência TCP novas. Fonte
apenas local, não distribuição; memória 2B e garantias globais preservadas.

Oito testes novos TCP e ensaio Tk real de conexão e ASSUMIR com localhost
aprovados, provando ausência de HTTPS/UDP/cofre e fechamento pela B2. Não é
teste físico da balança. Compilação de 155 arquivos e diff verificados. Detalhes
em TCP_LOCAL.md; sem reinícios operacionais, commit ou push.

Regressão final desta correção: **2.145 testes aprovados em 43,204 s**.
Integridade/hashes do backup de quatro arquivos conferidos. Compilação de
155 arquivos, ensaios Tk e verificação de diff aprovados.

## Integração autorizada das telas e backup — 13/11/2026

Responsável aprovou mudar código principal e exigiu backup. Antes da mudança,
criado backups/interface_antes_integracao_2026-11-13_c31c01a5/originais.zip:
41 arquivos preservados com manifesto SHA-256 e leitura/hashes verificados.
Sem configuração/cofre/caches. Preserva estado local anterior, não somente HEAD.

Integrado componente comum interface/formularios.py em conexão e ASSUMIR:
tema aprovado, fontes, logo Lanczos, porta, caixa salvar, rodapé, dicas e atalho.
Mantidos callbacks assíncronos e critérios operacionais. Seletor HTTPS/TCP
somente visual, HTTPS já é transporte existente; opção TCP não troca backend.
Porta ASSUMIR informativa, não modifica portas ou promoção nesta intervenção.
Monitor mantém visual, com centro inicial e bandeja/avisos opcionais pelo novo
interface/notificacoes.py. Transições não repetem por amostra, sem threads novas;
Destroy cancela timer, remove ícone e restaura WndProc. B2 não foi ampliada.

Regressão: 2.137 testes aprovados em 38,113 s; 152 compilações em memória,
Tk integrado real, ensaio de recuperação Tk oculto e modelo moderno aprovados.
Cinco testes novos de notificações; inventário Tk atualizado. Primeiras regressões
identificaram dublês sem novo componente, corrigidos mantendo callbacks testados.
Isolamento do helper de persistência ampliado no harness visual offline.
Sem TC420/cofre real, reinício operacional, commit ou push. Shell_TrayWnd ausente
neste desktop: balões e clique na bandeja integrados exigem teste do responsável.
Documentação em INTEGRACAO_VISUAL_001.md; diff verificado.

## Método de conexão e informação contextual no modelo — 13/11/2026

Responsável pediu opções HTTPS/TCP abaixo do campo senha, HTTPS padrão, e
botão circular i à direita com explicação sobreposta conforme escolha.
Adicionada linha “Método de conexão” em conexão e ASSUMIR: radiobuttons
mutuamente exclusivos, StringVar inicial HTTPS e controle circular Canvas.
Dica dinâmica aparece no hover (ou clique), explica HTTPS/TLS ou TCP/porta
9800 e deixa explícito caráter demonstrativo. Não modifica HTTP operacional,
porta, autenticação ou armazenamento. Alturas passaram a 600/550 pixels
para acomodar linha sem comprimir ação/rodapé; largura permanece 560.

Tk real aprovou HTTPS padrão em ambos, troca exclusiva para TCP e retorno,
conteúdo contextual e abertura/fechamento da dica, além de layout, fontes,
logo, rodapé e minimizar/restaurar. Diff aprovado. Nenhum teste de transporte
HTTPS/TCP foi executado; arquivos operacionais e monitor preservados.

## Redução Lanczos da logo — 13/11/2026

Responsável autorizou corrigir serrilhado. Preservado tamanho alvo 90 definido
no código pelo responsável. Substituído subsample por thumbnail Lanczos RGBA
via Pillow quando disponível. Incluído asset assets/logotc420-90-lanczos.png,
gerado do original com o mesmo filtro, para abrir no tamanho padrão sem instalar
dependências. Original preservado. Para outros tamanhos, dependência opcional
em tests/requirements-visual.txt. Espaçamentos verticais compactados para manter
logo 90, botão inteiro e dimensões atuais das janelas.

Instalação normal do Pillow falhou por permissão de escrita no site-packages;
instalação isolada em diretório temporário permitiu gerar asset e verificar o
caminho opcional, sem alterar permissões. Autoteste Tk real passou com asset
pré-processado sem Pillow e com Pillow 13.0.0 temporário: tamanho 90, pixels
visíveis, layout/rodapé/dica e minimizar/restaurar. Asset reduzido inspecionado.
Sem rede TC420, mudanças operacionais, commit ou push. Diff verificado.

## Explicação da logo pixelada — 13/11/2026

Responsável perguntou por que a imagem fica pixelada. Inspeção confirmou uso
de PhotoImage.subsample no modelo: redução por seleção de pixels, sem filtragem
ou suavização, provoca serrilhado e perda de detalhes. Asset original tem
1254×1254; limitação é do redimensionamento atual e do tamanho final pequeno,
não evidência de baixa resolução do original. Orientado usar redução com
antialias (ex.: Lanczos via Pillow) ou asset pré-redimensionado com qualidade.
Sem alteração funcional, instalação de dependência ou nova validação física.

## Orientação para tamanho da logo — 13/11/2026

Responsável perguntou onde ajustar a imagem do modelo. Indicado o divisor
alvo em `fator = max(1, round(maior / 72))`, no método formulario de
tests/ensaio_visual_moderno.py. Valor maior que 72 aumenta a imagem, menor
reduz; dimensões aproximadas por redução inteira. Alteração afeta ambos os
formulários. Autoteste aceita atualmente 64–80 pixels e precisa acompanhar
mudanças fora dessa faixa. Nenhuma mudança funcional ou nova validação física.

## Correção da logo transparente — 13/11/2026

Responsável informou logo ausente após ampliação. Reproduzido: combinação Tk
zoom/subsample gerava imagem com dimensões, mas totalmente transparente, pois
subsample era aplicado antes da ampliação e selecionava o pixel transparente
da origem. Corrigido para subsample inteiro isolado: asset 1254×1254 reduzido
por fator 17, produzindo 74×74 com conteúdo preservado, sem buffer gigante.

Teste anterior de widget mapeado era insuficiente. Autoteste agora verifica
dimensões e presença de pixels não transparentes nos dois formulários, além
de layout e demais verificações. Tk real e diff aprovados. Sem conferência
visual independente neste desktop; responsável deve reabrir o modelo para
conferir. Arquivos principais e monitor permanecem inalterados.

## Logo ampliada no modelo — 13/11/2026

Responsável solicitou aumentar a imagem da balança. Logo passou de limite de
40 para 72 pixels nos dois formulários, mantendo proporção e asset original.
Marca/título agrupados à esquerda para acomodar a imagem sem aumentar janelas
ou comprimir o botão. Redimensionamento Tk em operação única evita buffer
intermediário grande. Tentativas iniciais de tamanho maior e layout vertical
falharam por memória/altura; implementação final passou no autoteste Tk real
de layout, campos, botão, rodapé, dica e minimizar/restaurar. Diff verificado.
Somente modelo/documentação; monitor e arquivos principais preservados.

## Logo e atalho para ensaio no modelo — 13/11/2026

Responsável aprovou modelo compacto e pediu logo à direita do título e botão
quadrado junto ao desenvolvedor, com nome sobreposto no hover, para abrir
ensaio_visual_tk.py. Incluída imagem existente assets/logotc420.png reduzida
proporcionalmente, sem novo asset, em conexão e ASSUMIR. Rodapé tem botão
34×34 com dica “Abrir ensaio visual Tk”, exibida após 450 ms e removida ao
sair/clicar/destruir. Mantidos versão 0.0.1, autor e visual original do monitor.

Atalho abre harness original sem --moderno em processo separado via Python
atual e caminho absoluto, sem shell, main.py ou console novo no Windows.
Autoteste Tk real cobre logo/botão visíveis, dimensões quadradas, dica criada
e removida, invocação do botão e destino capturado com Popen simulado, além
dos controles de layout anteriores. Não houve lançamento de processo pelo
autoteste. Diff verificado; arquivos operacionais preservados. Sem commit/push.

## Modelo compacto, fontes e identificação — 13/11/2026

Responsável solicitou reduzir janelas do ensaio, fonte comum 14, títulos/botões
18 e identificação inferior direita. Em resposta à consulta sobre versão,
definiu **0.0.1**. Rodapé dos dois formulários: `v0.0.1 · Pablops2god`.
Rótulos e campos agora lado a lado para compensar o aumento de fonte: conexão
560×560 (antes 470×710) e ASSUMIR 560×510 (antes 470×640). Redução de altura e
área com largura maior para legibilidade. Porta 9800 e caixa mantidas; monitor
original e arquivos operacionais preservados.

Tk real aprovou construção, centralização, botão sem sobrepor rodapé, rodapé
visível com versão/autor, altura compacta e minimizar/restaurar. Autoteste
inclui checagem de fontes 18 no botão e 14 no rodapé. Diff verificado. Ajuste
permanece visual/offline; notificações têm confirmação anterior do responsável,
e desktop do agente continua sem bandeja acessível. Sem commit ou push.

## Revisão visual: botões, porta TCP e monitor preservado — 13/11/2026

Responsável considerou boa a conexão, pediu botão principal mais alto, campo
Porta TCP 9800 em conexão/ASSUMIR e limitou mudança de aparência a esses dois
formulários. Informou notificações funcionando em seu teste. Aumentados altura
e preenchimento dos botões e dimensões dos formulários; adicionada porta 9800
somente no modelo. Monitor ilustrativo substituído pela classe JanelaTC420
original com dados locais, preservando aparência existente.

Autoteste Tk real passou: porta nos dois formulários, botões com pelo menos
60 pixels sem corte na janela, centro, molduras e minimizar/restaurar. Desktop
do agente continua sem Shell_TrayWnd; validação de avisos é relato do usuário,
não ensaio independente. Modelo e documentação atualizados, sem mudanças em
portas operacionais, rede, persistência, arquivos principais, commit ou push.

## Modelo visual preto, centralização, bandeja e avisos — 13/11/2026

Responsável solicitou ensaio visual antes de alterar telas principais. Criado
`tests/ensaio_visual_moderno.py`, acessível por `ensaio_visual_tk.py --moderno`.
Formulários de conexão/ASSUMIR padronizados; monitor ilustrativo; molduras
nativas, centro inicial, minimizar/restaurar; adaptação experimental Win32 de
bandeja e balões com eventos simulados. Sem arquivos operacionais alterados,
rede, persistência, TC420, novas dependências, commit ou push.

Tk real aprovou construção/centro/molduras/minimização/restauração. 17 testes
do monitor visual e ensaio de recuperação Tk oculto aprovados; diff verificado.
Primeiro autoteste interrompido após falha de registro da bandeja; corrigidos
layout da estrutura Win32 e encerramento do autoteste. Diagnóstico identificou
ausência de Shell_TrayWnd neste desktop: registro permanece False e é apontado
como pendência. Computer Use indisponível por native pipe ausente após tentativas
de recuperação. Sem aprovação de captura visual, clique na bandeja ou exibição
de notificações. Ver `MODELO_VISUAL_TK_MODERNO.md` para roteiro e limitações.

## Persistência optativa no CLIENTE e na tela ASSUMIR — 13/11/2026

Responsável confirmou que a correção anterior funcionou e solicitou caixa de
salvar senha/login automático em ASSUMIR, além de corrigir a opção ignorada ao
descobrir PRINCIPAL com o formulário de conexão aberto. O retorno antecipado
para CLIENTE pulava toda a persistência. Agora respeita a opção marcada sem
autenticar na balança. ASSUMIR grava após resultado positivo e mantém o resultado
da promoção mesmo se a persistência falhar. Caixa desmarcada nessa tela preserva
preferências anteriores. Senha somente no cofre; JSON mantém metadados.

Helper de persistência preserva nome/porta existentes, verifica campos e cofre
antes de habilitar opção e registra somente categorias de falha. Quatro testes
novos cobrem descoberta com/sem opção sem login HTTP, metadados/ausência de senha
no JSON, falha do cofre e confirmação ASSUMIR com opção/resultado variados.
Dublês AST existentes receberam a nova variável de formulário. Sem TC420,
cofre real, reinícios, commit ou push. Validação física desta alteração pendente.

Verificações: regressão completa com **2.131 testes aprovados em 43,023 s**;
quatro testes específicos aprovados em execução separada (o caso ASSUMIR foi
acrescentado após iniciar a regressão); **147 arquivos compilados em memória**
e `git diff --check` aprovado. Primeira execução identificou quatro dublês AST
sem a variável nova, corrigidos antes da regressão aprovada.

## Logs de fila rearmada e fechamento após tentativa sem sucesso — 13/11/2026

Verificações desta alteração: **2.128 testes aprovados em 46,590 s**, **146
arquivos Python compilados em memória** e `git diff --check` aprovado. Testes
controlados não substituem a repetição física do ciclo A/B; aprovação física
completa permanece pendente.

Responsável enviou dois novos logs. Confirmados B como PRINCIPAL inicial, A
CLIENTE/posição 1 e posterior promoção; B reconecta a A com posição 1 e mensagem
de candidatura rearmada. Depois da perda de A, B conta 30 s e sinaliza candidatura,
mas ASSUMIR é fechado sem motivo de recusa registrado. A não mostra certificado
final; B mostra parada confirmada no escopo acompanhado após WinError 10038.
Não há evidência suficiente para diagnosticar senha, rede ou pendência como
causa da tentativa retornar; revisões exatas/horários não foram fornecidos.

Reproduzido segundo caso local de cancelamento: a proteção anterior cobria
somente worker em andamento. Ao terminar sem sucesso, promocao_em_andamento
voltava a False e o observador fechava o formulário devido à inatividade do
leitor parado pelo próprio promotor. Teste novo B3 falhou antes da correção e
passou depois. Formulário de tentativa manual admitida agora permanece até
sucesso ou fechamento explícito, inclusive após retorno sem sucesso. Oferta
cancelada sem tentativa continua sendo fechada normalmente; gates não mudam.

Adicionados diagnósticos seguros de início, etapas e motivos antes silenciosos
em rede/promocao_manual.py. Mensagens de erro só usam classe ou categorias
internas em lista permitida, nunca texto arbitrário com credenciais. Novo teste
operacional verifica recusa na revalidação CLIENTE após acesso à fonte, sem start.
Documentação física, sucessão, operação, prontidão e validação atualizadas. Sem
rede real, reinício de aplicação/PC, credenciais reais, commit ou push.

## ASSUMIR cancelado pela parada do próprio leitor — 13/11/2026

Responsável relatou que, na terceira alternância, o formulário ASSUMIR aparecia,
mas a candidatura era cancelada ao confirmar. Sem novos logs anexados nessa
solicitação. Inspeção e reprodução controlada identificaram disputa concreta:
promover_recuperado para o leitor antes de autenticar; LeitorDadosServidor.parar
limpa o evento de candidatura e muda estado para inativa; verificar_candidatura
interpretava esse estado como cancelamento, destruía o formulário e cancelava
o token do worker ainda executando. Isso podia interromper login/partida ou
descartar o resultado pronto pela identidade da janela destruída.

Correção mínima em interface/janela.py: o fechamento inferido da candidatura
inativa/cancelada só ocorre quando não existe promoção em andamento. Saída e
cancelamento explícitos continuam invalidando o worker; descoberta, provas de
encerramento e prontidão permanecem no backend. Não foram alteradas credenciais,
fila, protocolos, estudos de memória ou condições B2.

Dois testes adicionados em test_interface_b3.py. O primeiro cobre inativa e
cancelada com parada de leitor real e worker suspenso por eventos, preservando
formulário/token e aplicando o resultado no Tk simulado. O segundo preserva
fechamento de candidatura cancelada sem promoção. Reprodução anterior à correção
falhou nos dois subcasos; suíte B3 passou depois (28 testes).

Regressão final: **2.126 testes aprovados em 42,014 s**, **146 arquivos Python
compilados em memória**, git diff --check aprovado. Sem teste físico desta
correção; relato do terceiro ciclo ainda precisa de repetição nos PCs atualizados.
Atualizados sucessão recorrente, operação, prontidão e validação. Sem reinício de
aplicação, acesso à TC420, commit ou push.

## Sucessão recorrente A/B e observador do monitor manual — 13/11/2026

Responsável relatou persistência do bloqueio e definiu explicitamente o ciclo
recorrente A→B→A→B, com fila e promoção manual/automática configurada. Essa
instrução substitui a anterior de manter automático desabilitado permanentemente
nos leitores recuperados. Logs confirmam A com posição 1 e leitura de B, mas
posterior mensagem de candidatura desabilitada; B promoveu, perdeu a fonte e
encerrou seus trabalhadores. Não há nova promoção de A nesses anexos.

Identificadas duas causas: leitor recuperado permanentemente bloqueado e callback
do evento removido; monitor de login manual também não iniciava o observador,
pois não chama executar e compartilha o mainloop da conexão. Botão manual da
correção anterior não implementava a alternância recorrente solicitada agora.

Leitor recuperado começa bloqueado e só rearma após REGISTER com posição inteira
positiva, medição válida do novo PRINCIPAL e autorização por provas dos ciclos
anteriores/supervisão vigente. A fila mantém posição × 30 s e revalida provas.
Supervisor associa o autorizador a cada geração; monitor conserva callbacks da
geração atual e inicia observação única também no caminho manual. Após fila,
credenciais salvas habilitadas usam o mesmo promotor acompanhado; sem elas abre
formulário manual existente. Partidas ambíguas, prontidão e B2 não foram relaxadas.

Validação final: **2.124 testes aprovados em 43,683 s**, **146 arquivos Python
compilados em memória**, git diff --check aprovado. Sete testes novos de sucessão
recorrente e um novo caso de supervisão/interface; Tk real oculto verifica que
o observador não é duplicado. Sequências por gerações e transporte/credenciais
simulados; regressão inclui serviços reais em localhost. Nenhum teste físico
executado pelo agente, reinício de aplicação, commit ou push.

Criado SUCESSAO_RECORRENTE_AB.md com diagnóstico, comportamento atual e roteiro;
atualizados operação, API, supervisão, prontidão, índice, validação e ficha física.
Documentos anteriores conservam as decisões históricas, superadas apenas na
restrição permanente de candidatura. Estudos de memória permanecem encerrados.

## Integração prioritária da recuperação manual A/B — 13/11/2026

Solicitação anexada autorizou a menor correção operacional para alternância
manual após rebaixamentos sucessivos, sem reativar candidatura automática,
sem testes físicos automáticos, commit/push ou alteração dos estudos de memória.
Implementado rede/promocao_manual.py com gate de promoção na SaidaAplicacao,
prova dos ciclos/tentativas anteriores, parada/observação dos leitores, composição
das responsabilidades CLIENTE conhecidas, duas descobertas e acesso à TC420.
Adicionado modo estrito opcional de descoberta na nova recuperação, para erro ou
CHECK incerto não equivalerem a ausência de PRINCIPAL.

Menu Opções → Assumir manualmente vinculado à supervisão/leitor atuais, inclusive
em monitores de login manual. Não depende do evento de candidatura nem usa
credenciais automaticamente. Recuperação recusada solicita nova geração de
leitor somente após resolução conhecida; partidas ambíguas permanecem retidas.
Supervisor monitora a nova geração para aplicar peso/configuração depois de
medição válida. Código operacional não importa o protótipo de recuperação.

Contexto servidor ganhou sinais próprios de prontidão TCP/UDP/amostra e
cancelamento persistente. Promoções esperam até 15 s por workers vivos, saúde e
amostra do contexto com idade até 6 s. Main revalida descoberta antes do start e
também aguarda prontidão; timeout/cancelamento pede parada pelo ID conservando
contexto/tentativa/thread. Saúde reinicializada por ciclo. B2/B3 e protocolo
preservados, sem garantia de exclusividade distribuída.

Verificações finais: **2.116 testes aprovados em 36,647 s**; **145 arquivos Python
compilados em memória**; git diff --check aprovado. Quinze novos testes
operacionais e dois novos casos de supervisão, além do ensaio Tk real oculto de menu,
recusa conectado e faixas. Servidor/B2/registros e sockets reais em localhost,
com TC420/descoberta LAN simuladas; cliente real recebeu CONFIG/SUBSCRIBE.
Teste de nova promoção após resolução no mesmo dono preservou consulta ao ciclo
anterior. Fixtures e inventários atualizados para segunda descoberta/prontidão.
Falhas intermediárias de fixtures/auditorias foram corrigidas antes da regressão
final; não se reutilizou o número de aprovação da versão anterior.
Na revisão final, retomada de leitor e promoção manual passaram a compartilhar
o gate local. Clique recusado por concorrência não solicita retomada do leitor
suspenso pela outra tentativa. Novo teste reproduz essa exclusão; a regressão
final acima já inclui o ajuste.

Criado INTEGRACAO_RECUPERACAO_MANUAL_AB.md com arquivos, recusas, limitações e
roteiro físico A→B→A. Atualizados índice, prontidão, operação, API, supervisão,
validação e ficha física. Nenhum acesso real à TC420, reinício de aplicação/PC,
empacotamento, commit ou push. Validação física/instalação continuam pendentes.

## Auditoria e protótipo de recuperação manual sucessiva — 13/11/2026

Solicitação: estudar em isolamento a separação entre candidatura automática e
oferta manual após A/B rebaixados, sem simplesmente habilitar permitir_candidatura.
Auditados supervisão, leitor, monitor, login manual e callback de promoção em main.
Além do evento compartilhado, identificado monitor manual sem callback de promoção,
callback fechado sobre leitor original e anúncio anterior à primeira amostra.

Criado prototipos/recuperacao_manual.py, sem importação pela aplicação: automático
proibido, oferta manual independente, prova positiva de todos os contextos retidos,
descoberta antes/depois do acesso à fonte, revalidação, retenção antes de start,
recusa de prontidão incerta e serialização local. Adaptador usa avaliador real de
ciclo. Partida ambígua continua retida. Modelo não substitui gates B2/B3, workers
de saída, admissão de tentativas ou coordenação distribuída.

Criados 15 testes específicos, todos aprovados. Incluem sequência A/B simulada,
cancelamento, contexto inválido, clique concorrente, fonte inacessível, descoberta
incerta, PRINCIPAL surgindo durante login, prova alterada, partida incerta e
adaptador com registro/socket real e erro de limpeza. Leitor de produção recebeu
CONFIG e peso por sockets reais em localhost contra serviço sintético, sem LAN,
TC420 ou servidor operacional. Regressão final: **2.099 testes aprovados em
20,018 s**. Execução anterior com 14 novos testes: 2.098 em 21,267 s.

Documento RECUPERACAO_MANUAL_APOS_REBAIXAMENTO.md registra contratos, matriz de
cenários, limites e condições para eventual integração. Índice e prontidão
atualizados. Nenhuma alteração operacional, teste físico, credencial real, commit
ou push. Investigação de memória encerrada e Fases 1/2 não autorizadas permanecem
inalteradas. Procedimento atual de reconfigurar/reiniciar apenas um PC preservado.

## Dois leitores aguardando após segunda perda — 13/11/2026

Responsável relatou A principal indisponível, promoção manual de B e posterior
perda de B, sem oferta de nova promoção manual em A. Analisados quatro anexos:
dois repetem o ensaio anterior; o novo par demonstra A recuperado como cliente,
silêncio SUBSCRIBE e mensagem explícita de candidatura desabilitada. B promovido
apresenta falhas HTTP, abandono após o limiar de 25 s, HTTP/TCP/UDP encerrados,
trabalhadores restantes vazios e início de procura por outro servidor.

Causa conferida no código: SupervisaoPrincipal cria leitor com
permitir_candidatura=False; _aguardar_candidatura retorna sem sinalizar candidatura.
A interface usa essa sinalização para oferecer o fluxo manual também. Portanto,
a restrição não se limita à promoção automática: o leitor de recuperação não
oferece a promoção manual associada à candidatura. Quando A e B já passaram por
PRINCIPAL e rebaixamento, ambos podem aguardar indefinidamente um terceiro fluxo
normal de início. Limitação do contrato vigente, não falha de login demonstrada.

Orientação: em janela controlada e com a fonte acessível, usar Reconfigurar em
apenas um PC, confirmar seu encerramento seguro e iniciar pelo login normal;
alternativa fechar com SIM e reabrir esse PC. Não habilitada candidatura recorrente
nem alteradas garantias B2/B3. Registro físico e prontidão atualizados. Evidências
do executor, sem testes próprios ou confirmação da revisão remota. B termina o
anexo após solicitação de saída, sem confirmação final B2; recuperação de B com
nova leitura após esse segundo abandono ainda não demonstrada. Sem código,
commit, push ou intervenção em equipamento.

## Confirmação física das faixas após recuperação — 13/11/2026

Responsável enviou dois novos logs e captura após correção de CONFIG. A captura
mostra W1.1 (máximo 80000 kg, mínimo 200 kg, divisão 10 kg) e W1.2 (máximo
140000 kg, mínimo 400 kg, divisão 20 kg), com peso/tara zero e CT conectado.
Correção confirmada nesse cenário pelas evidências fornecidas, sem observação
independente. Logs mostram abandono de A, promoção de B e reconexão de A a B.
A continuou recebendo em segundo plano e encerrou com confirmação no escopo
acompanhado. B encerrou HTTP/TCP/UDP com trabalhadores restantes vazios, mas sem
mensagem explícita de confirmação B2 no trecho. Segunda falha do B promovido e
reabertura desta execução não demonstradas. PasswordDeleteError persiste no login.

Atualizados registro físico e prontidão. Nenhuma alteração de código, novo teste
simulado, intervenção remota, commit ou push. Mantida investigação de memória
encerrada e implementação das Fases 1/2 não autorizada.

## Faixas ausentes após recuperação como CLIENTE — 13/11/2026

Solicitação: analisar logs e captura do antigo PRINCIPAL conectado ao PC B com
peso válido e Max/Min/divisão ausentes. Identificado que a descoberta posterior
ao início não consultava CONFIG. Extraída consulta síncrona com os mesmos gates,
reservas e limpeza; repetida no loop enquanto configuracao_pronta não foi
publicada, antes de REGISTER/SUBSCRIBE. Não modifica supervisão, B2/B3 ou memória.

Adicionado teste sem servidor na descoberta inicial e servidor posterior, conferindo
CONFIG antes de REGISTER, conteúdo das faixas e fechamento de arquivo/socket.
Atualizada auditoria AST para a extração do método e seus dois chamadores no
corpo permanente. Testes CONFIG: 24 aprovados. Primeira regressão: 2.084 testes,
uma falha apenas na expectativa AST antiga; repetição após ajuste registrada abaixo.

Regressão final: **2.084 testes simulados aprovados em 20,865 s**. Nenhum desses
testes constitui repetição física da correção na TC420.

Novas evidências físicas do responsável mostram abandono e recuperação do antigo
PRINCIPAL com leituras do B; não comprovam segunda falha do B promovido. Correção
física ainda não validada. Não houve acesso ao equipamento, alteração nos PCs
remotos, commit ou push. CONFIG já publicado não recebe atualização contínua.

## Análise dos logs físicos de promoção e encerramento — 13/11/2026

Solicitação: avaliar evidências enviadas após a solicitação do roteiro físico.
Logs fornecidos pelo responsável demonstram cliente conectado, perda de A,
candidatura e promoção de B, leituras HTTP, indisponibilidade da fonte e retorno
da comunicação. A e o novo ciclo manual de B apresentam confirmação de parada
no escopo acompanhado. A saída do B promovido lista leitor HTTP ainda ativo,
depois encerrado, sem confirmação B2 explícita no trecho enviado.

Segunda falha supervisionada permanece inconclusiva: não aparecem abandono,
confirmação do ciclo e leitor de recuperação. Conferido em rede/servidor.py que
o limiar é temporal (25 s desde a terceira falha, verificado em falha posterior),
não uma quantidade fixa de erros. Sem horários e revisão remota não há causa
confirmada. Registrados PasswordDeleteError e WinError 10058 na parada como
ocorrências a investigar, sem atribuir falha operacional não demonstrada.

Atualizados ficha física e prontidão. Nenhum teste executado pelo agente,
nenhuma intervenção na rede, alteração operacional, commit ou push. Investigação
de memória continua encerrada. O roteiro seguinte prioriza conferir versões,
registrar tempos e aguardar prova positiva antes de restaurar a fonte.

## Inicialização do aplicativo real — 13/11/2026

Por solicitação explícita `python main.py`, iniciado main.py na raiz do projeto,
PID 13028. Processo respondendo com título PRIX TC420 - Conexão na conferência.
Nenhuma falha física provocada ou cenário aprovado. O lançamento não comprova
conexão com a balança. Código não alterado. Diagnóstico anterior da tela offline:
processo 14188 respondia e stderr vazio, mas o controle de Windows não encontrou
janela targetável; não se confirmou visibilidade ao usuário por esse meio.

## Solicitação de início dos testes físicos — 13/11/2026

Responsável solicitou iniciar os testes físicos. Última confirmação explícita
indicava janela ainda indisponível. Solicitados estado atual sem pesagem, PCs
A/B e executor das interrupções para aplicar o roteiro controlado. Aguardando
essas informações; não foi iniciada conexão real nem aplicada falha. Tela
offline aberta anteriormente não equivale a execução física. Sem mudança de código.

## Abertura da tela de testes offline — 13/11/2026

Solicitação: iniciar a tela de testes. Iniciado `python -B tests/ensaio_visual_tk.py`
em processo separado, PID 14188. Processo ativo/respondendo e stderr sem erro na
conferência após abertura. A espera Win32 por input-idle não se aplica ao launcher
console; não foi usada como aprovação de interface. Harness offline documentado
em OPERACAO, sem acesso à TC420 ou início do roteiro físico. Nenhum cenário
marcado como aprovado e nenhum código alterado nesta solicitação.

## Janela física ainda indisponível — 13/11/2026

Responsável respondeu: “Ainda não; manter os testes pendentes.” Registrada a
indisponibilidade na ficha de execução. Não iniciar intervenções ou testes físicos
até nova confirmação da janela controlada. Código intacto; investigação de memória
permanece encerrada por enquanto e Fases 1/2 não autorizadas. Sem novos testes.

## Preparação de acompanhamento da execução física — 13/11/2026

Responsável reiterou foco na segunda falha após promoção, prova de encerramento,
leitor sem candidatura e frescor; investigação de memória não será reaberta.
Criada REGISTRO_EXECUCAO_FISICA_SUPERVISAO.md com campos não preenchidos e passos
não executados. Solicitada confirmação da janela sem pesagem, PCs A/B e executor
das intervenções. Testes físicos permanecem pendentes; nenhuma interrupção,
acesso à TC420, alteração de código ou nova validação executada nesta solicitação.

## Fechamento da investigação de memória e retorno à validação física — 13/11/2026

Responsável aprovou o fechamento documental da 2B.12 e determinou encerrar a
investigação de memória por enquanto. Fase 1 (histórico lógico) e Fase 2 (redução
de referências) continuam expressamente não autorizadas. Manter terminal/slots
implementados e preservar estudos como referência, sem abrir novos protótipos.

Prioridade passa à supervisão comum do PRINCIPAL: promoção, segunda perda,
encerramento e reabertura em janela controlada, sem pesagem real. Preparado
ROTEIRO_FISICO_SUPERVISAO_PRINCIPAL.md, com evidências e distinção entre leitor
rebaixado sem candidatura e promoção de outros clientes. Nenhum teste físico,
acesso TC420, intervenção de rede, mudança de código ou nova regressão executado
nesta solicitação. Última regressão completa continua 2.083 na 2B.9.

## Etapa 2B.12 — revisão e fechamento documental — 13/11/2026

Pedido: fechar consultas, selagem, versionamento e aceitação sem implementar B.
REVISAO_CONTRATOS_2B12.md define schema proposto historico_trabalhadores/1,
envelopes/campos/estados/ordem, prova de partida e tratamento de ambiguidade,
publicações tardias, conflito e selagem. Separa Fase 1 sem mudar lista e Fase 2
com autorização pública independente; inclui critérios por marco e limites de
rollback após coleta de originais. Texto para aprovação, não aprovação inferida.
Sem código, estruturas, protótipos, testes/medições novos ou alteração de shutdown.
Referência de 2.083 testes é da 2B.9. Integração e validação física pendentes.

## Etapa 2B.11 — especificação contratual documental — 13/11/2026

Pedido anexado: proposta concreta sem implementação. Elaborada
ESPECIFICACAO_CONTRATUAL_2B11.md com B como candidata para revisão, sem aprovação
inferida: contratos operacional/histórico, originais e IDs lógicos, partida/join,
associações, selagem/publicações tardias, migração interna e quebra pública da
lista futura. Lista vigente e shutdown permanecem intactos. Economia só poderá
ser medida depois da política aprovada e da liberação real de raízes fortes.
Sem código, protótipo, medição ou testes novos; referência de 2.083 é anterior.

## Etapa 2B.10 — contratos e responsabilidades — 13/11/2026

Solicitação anexada: auditoria/desenho preservando registro.threads e shutdown.
Mapeados consumidores de identidade, ordem, métodos e mutabilidade; separados
fixtures homônimos. Desenho distingue objeto Thread, responsabilidade admitida e
comprovante histórico. Lista forte intacta impede liberar originais; metadados
separados podem conservar provas, mas não eliminam raízes externas.
Relatório CONTRATOS_RESPONSABILIDADES_2B10.md: propostas sem integração.

Medição limitada com mil admissões start/join e vínculo explícito, sem resumir:
2.384.117 → 2.756.304 bytes rastreados; reserva pendente e lista original
preservadas. Não é teste prolongado/servidor ativo. Sem nova regressão completa,
mudança operacional/contratual, shutdown alterado, TC420, commit ou push.

## Etapa 2B.9 — retenção de recursos resolvidos — 12/11/2026

Pedido anexado: auditar referências/consumidores, definir provas e prototipar
threads/sockets separadamente com carga mista, sem tocar produção. Mapa e
critérios em RETENCAO_RECURSOS_RESOLVIDOS_2B9.md. T registra retorno normal de
start, verifica join fora do lock e responsabilidades; resumo muda identidade/
API do Thread exposto. Sem vínculo explícito, listener ativo impede redução.
S exige estado fechado comprovado, preserva tokens/diagnósticos, mas teste
reproduziu mudança de RuntimeError para sucesso em shutdown tardio instrumentado.

Carga de 15.502 reservas/13.724 threads reais encerradas/13.723 sockets simulados:
T 36,005 → 8,887 MB; S 34,315 → 33,217 MB; combinado 36,005 → 7,788 MB rastreados.
Referências externas a todos os threads impedem liberação e resumos elevam custo
até serem soltas. B2 avaliou contexto já resolvido nos quatro modos; não é parada
de servidor ativo. Candidatos não integrados; decisões contratuais pendentes.

Dez testes novos; três baterias sobrepostas de 116 com T/S/combinação (3,017 /
3,204 / 3,092 s); regressão normal 2.083 em 22,053 s e 140 arquivos compilados
em memória aprovados. Sem TC420, tráfego de rede, política automática, commit
ou push. Teste nativo limitado a criar/fechar socket sem bind/connect.

## Etapa 2B.8 — fragmentação, escrita e carga mista — 12/11/2026

Pedido: medir escrita/caudas p95-p99, adversários e proporções da hora, mantendo
produção intacta. Criado harness com 15 cenários (atual/2B.6/2B.7), memória em
construção separada da latência. Quatro cargas de 50 mil e uma mista de 15.502
reservas/13.723 sockets simulados fechados/13.724 Threads reais start/join.
Acrescentadas memória pareada no mesmo grafo e rodada de contenção controlada.

Fusão de pontes p99: 31,1 us atual, 136,6 us 2B.6, 105,5 us 2B.7. Após pico de
25 mil faixas e fusão em uma, dicionários auxiliares vazios ainda ocupavam cerca
de 5,24 MB juntos, confirmados por sys.getsizeof. Mista pareada: 34.853.847 →
34.729.335 bytes (124.512 bytes, cerca de 0,36%), mantendo objetos encerrados.
Um bloqueio raro ficou fora do p99 em 200 operações; máximos/espera registrados.

Resultados/limites em FRAGMENTACAO_ESCRITA_2B8.md e artefatos associados. Quatro
testes novos; 116 existentes sob substituição em 3,414 s e regressão normal de
2.073 em 20,312 s aprovados; 137 arquivos compilados em memória. Nenhuma alteração
operacional, política automática, escolha de mudança contratual, teste físico,
commit ou push. Integração não recomendada com base nestes resultados.

## Etapa 2B.7 — consultas em lote e agregado experimental — 12/11/2026

Pedido: otimizar leitura de faixas e predicado agregado, medir aquisição/posse de
lock e fragmentação, sem tocar produção. Criada subclasse experimental que mescla
fortes/faixas sequencialmente e calcula prova de sockets sem reconstruir histórico,
mantendo gate, threads, erros e cobertura. Tokens/escritor/B2/supervisão preservados.

18 medições concluídas de 50 mil reservas, três backends/seis cargas. Uniforme
sem tokens: posse mediana de lock da consulta 720,418 ms (2B.6) → 29,629 ms
(2B.7), contra 38,779 ms atual; agregado 709,006 → 0,0037 ms. Retenção de
histórico uniforme permaneceu cerca de 2,4 KB. Porém aleatória com todos os tokens
reteve 18,59 MB contra 15,46 MB atual e consulta segurou lock 64,575 contra
36,768 ms. Ganho não universal; nenhuma integração recomendada automaticamente.

Digests equivalentes, contenção controlada medida e limites em
OTIMIZACAO_CONSULTAS_INTERVALOS_2B7.md/JSON. 12 cenários do backend (oito
reaplicados/quatro adicionais), bateria experimental de 116 em 3,431 s e
regressão normal de 2.069 em 29,274 s aprovados; 135 arquivos compilados em memória.
Sem código operacional, contrato, política automática, TC420, commit ou push.

## Etapa 2B.6 — identidades e intervalos isolados — 12/11/2026

Solicitação anexada: prototipar identidades exatas, fortes para pendências,
intervalos uniformes e diagnóstico reconstruível; sem integrar no servidor.
Criado armazenamento experimental: só sem_recurso comprovado sem erro/pendência
vai a faixas; índice fraco reconhece token original, nunca aceita cópia fabricada
por ID. GC não altera prova de responsabilidade; demais estados continuam fortes.

50 mil uniformes: 13.817.088 bytes atuais versus 2.464 no protótipo sem tokens
externos, 2.656 com um token e 13.859.816 com todos os tokens. Carga alternada
sem_recurso/incerta reteve 25 mil entradas fortes/25 mil faixas e 10.923.648 bytes.
Diagnósticos completos coincidiram, mas consulta uniforme passou de 0,164 para
3,058 s sob tracemalloc, pico absoluto 27,89 → 15,67 MB. Custo de reconstrução,
fragmentação e distribuição real limitam integração; nenhuma ativação recomendada.

Relatório IDENTIDADES_INTERVALOS_2B6.md e medições JSON. Oito testes novos;
116 existentes com substituição experimental aprovados em 2,999 s. Regressão
normal 2.057 testes em 26,369 s; 132 arquivos compilados em memória. Sem código
operacional alterado, rede real, TC420, revogação, descarte, commit ou push.

## Etapa 2B.5 — desenho e prototipagem isolada — 12/11/2026

Pedido anexado: investigar retenção dentro do ciclo ativo, preservando identidade,
diagnósticos e pendências; sem implementação operacional. Criados dois protótipos
isolados e medições de 50 mil reservas. A (constantes compartilhadas) reteve
11.413.936 contra 13.817.088 bytes atuais em sem_recurso, redução de 17,4%; B
(separação de objetos fechados sem erro/pendência) reteve 16.213.968 contra
20.217.512 bytes na carga distinta de sockets simulados. Crescimento segue linear.

Token/dono continuam originais. Retirada de referências a objetos fechados e
introspecção privada têm limites de compatibilidade documentados; não ativar
automaticamente. Índice fraco com resultados por intervalos é desenho futuro,
não medido; evolução com descarte de diagnósticos é proposta sujeita a aprovação.
Relatório DESENHO_RETENCAO_CICLO_ATIVO_2B5.md e medições JSON correspondentes.

Seis testes novos aprovados; baterias experimentais sobrepostas de 116 testes
com A e 104 com B aprovadas; regressão normal 2.049 em 21,348 s e 129 arquivos
compilados em memória. Nenhum código operacional, rede real, TC420, política
automática, commit ou push nesta solicitação.

## Etapa 2B.4 — investigação da retenção por ciclo — 12/11/2026

Solicitação: encerrar observação de uma hora e investigar isoladamente política
por ciclo, sem mudar código operacional. Mapeadas raízes do registro e medidos
quatro cenários sintéticos de 50 mil reservas. Sem raiz externa: 13.817.768 →
1.104 bytes rastreados após compactar/GC; com um token externo: registro inteiro
permanece retido, aproximadamente 13,8 MB. Diagnóstico externo conserva memória
própria mesmo após coleta do registro. Tokens e retornos originais preservados.

Achado impeditivo à ativação direta: compactar o ciclo ainda atual faz pedido
tardio de parada do mesmo ID lançar AttributeError no resumo. Investigar apenas
ciclos anteriores é proposta, não ativação. Compactar ciclos encerrados não
limita crescimento dentro de um ciclo ainda executando. Detalhes/medições em
INVESTIGACAO_RETENCAO_POR_CICLO.md e JSON associado. 104 testes existentes
aprovados em 3,056 s; sintaxe do harness verificada. Sem nova suíte completa,
rede real, TC420, mudança operacional, política ativada, commit ou push.

## Consolidação do ensaio de uma hora — 12/11/2026

Pedido: manter a execução intacta e consolidar memória, recursos ativos, retenção,
B2 e reabertura quando disponível. Consulta encontrou status concluido, resultado
final presente, PID 17416 encerrado e stderr vazio. Analisadas 362 amostras:
13.721 conexões TCP e 3.430 consultas UDP; 15.502 entradas finais, 13.724 threads
retidas/zero vivas e 13.723 sockets referenciados/zero abertos após B2.
B2 confirmou parada em 0,768 s, sem pendências ou erros; novo ciclo 2 iniciou e
encerrou, mantendo confirmação do contexto original. Certificação global False.

Python rastreado cresceu de cerca de 0,048 para 36,095 MB; working set de 39,387
para 120,656 MB após saída. Razão bruta memória Python/entrada ficou entre cerca
de 2.328 e 2.367 bytes nos pontos de 15/30/45/60 min, incluindo instrumentação.
Isso não demonstra memória constante nem tamanho isolado de reserva. Resultado
completo em RESULTADO_2B3_UMA_HORA.md. Ensaio aprovado para comunicação, B2 e
reabertura no escopo exercitado; várias horas e regressão física ainda pendentes.
Sem alteração de código, nova regressão, ampliação automática, commit ou push.

## Acompanhamento da hora observacional — 12/11/2026

Responsável reafirmou que a 2B.3 permanece em validação e definiu análise final
de início/meio/fim: memória Python/working set/private bytes, recursos ativos,
taxas de reservas em carga/ociosidade, B2 e reabertura. Conferência somente de
leitura: PID 17416 ativo, status executando e resultado final ainda ausente.
Última amostra consultada: 930,419 s (aproximadamente 15,5 min), 4.028 entradas,
460 sem_recurso, 3.568 threads retidas/4 vivas, 3.567 sockets referenciados/3
abertos, zero erros de limpeza; 9.420.417 bytes Python rastreados. Stderr vazio
na consulta. São dados parciais, sem aprovação da hora, B2 final ou reabertura.
Nenhum código ou parâmetro alterado, nenhum novo teste executado. Ensaio mantido
em andamento; decisão de retenção ou ampliação continua dependente do resultado.

## Etapa 2B.3 — lançamento da janela de uma hora — 12/11/2026

Solicitação anexada: ampliar observação em localhost para uma hora com medições
comparáveis; condicionar várias horas aos resultados e manter regressão física
separada. Nenhuma alteração operacional ou nova compactação. Harness recebeu
JSONL incremental/status e verificação de novo ciclo real após B2. Verificação
prévia de 30 s aprovada com B2 e reabertura confirmadas; sintaxe verificada.

Ensaio de 3.600 s iniciado às 17:35:44 -03:00, PID 17416, término previsto por
volta de 18:36. Processo vivo, status executando, primeiras amostras presentes
e stderr vazio na inspeção inicial. **Resultado de uma hora ainda pendente**;
não registrar aprovação ou estabilidade com base no lançamento. Detalhes e
caminhos em VALIDACAO_DURACAO_RECURSOS.md. Status/resultado final são gravados
pelo próprio harness. Sem nova regressão completa, teste físico, commit ou push.

## Etapa 2B.3 — piloto observacional em localhost — 12/11/2026

Solicitação: carga representativa, duração controlada e recursos, sem nova
compactação; regressão física como atividade separada. Acrescentado harness
tests/ensaio_recursos_localhost.py, com TCP/UDP reais no loopback, portas efêmeras,
fonte HTTP substituída por espera sintética e encerramento pelo SaidaAplicacao
real. Nenhuma alteração em código operacional, credenciais ou equipamento.

Piloto de 120 s: 461 conexões TCP e 115 consultas UDP; após B2, 524 entradas,
464 threads retidas/zero vivas e 463 sockets referenciados/zero abertos.
B2 confirmado_operacional em cerca de 0,636 s, sem pendências ou erros;
certificação global permanece False. Período ocioso final acrescentou 10 reservas
sem_recurso sem novas conexões. Memória rastreada subiu de 49.159 para 1.293.854
bytes, incluindo o harness; working set/private bytes também registrados.

Método, resultados e limitações em VALIDACAO_DURACAO_RECURSOS.md e JSON associado.
Regressão: 2.043 testes em 21,188 s; 125 arquivos compilados em memória;
git diff --check aprovado. Piloto curto não conclui ensaio prolongado; horas/dias
e regressão física de segunda perda após promoção/encerramento-reabertura
continuam pendentes. Sem commit ou push.

## Etapa 2B.2 — representação compacta segura — 12/11/2026

Solicitação anexada: comparar três alternativas, preservar contratos e reduzir
memória de reservas resolvidas. Decisão documentada antes de alterar código em
COMPACTACAO_REGISTRO_TRABALHADORES.md: alternativa A, por reserva; B (ciclos) e
C (separar accept) não adotadas por maior alcance operacional. servidor.py usa
entrada com slots somente para sem_recurso comprovado sem erro/pendência.
Tokens, ordem, campos, retornos e provas B2/supervisão preservados; não há descarte.

Carga reproduzida de 50 mil reservas: 16.217.992 → 13.817.032 bytes Python retidos
(14,8% de redução), mantendo 50 mil entradas e zero threads/handles. Consulta
completa e seu pico temporário medidos; tempo da carga maior nesta amostra.
12 testes novos aprovados; regressão completa 2.043 aprovados em 22,223 s;
124 arquivos compilados em memória. Tracemalloc não mede RSS; crescimento ainda
linear. Sem teste físico/prolongado, commit ou push nesta solicitação.

## Encerramento pelo monitor confirmado pelo responsável — 11/11/2026

O responsável informou que a aplicação fechou como esperado após solicitar
encerramento pelo monitor. O trecho de log fornecido registra término da leitura
HTTP, do servidor TCP e da descoberta UDP, lista vazia de trabalhadores principais
restantes, encerramento do PRINCIPAL e confirmação da parada operacional no
escopo acompanhado. O próprio diagnóstico ressalva cobertura global desconhecida.

Resultado registrado como validação física relatada pelo responsável, sem execução
independente nesta solicitação. Não comprova ausência global de threads/recursos,
recuperação após segunda falha de promoção, estabilidade prolongada de memória
ou compactação da etapa 2B.2. Apenas documentação atualizada; sem alteração de
código ou nova execução de testes automatizados.


## Etapa 2B.1 — auditoria de RegistroTrabalhadores — 09/11/2026

Solicitação: auditar contratos antes de compactar registros/reservas resolvidos,
preservando responsabilidades, APIs, B2 e comportamento do servidor. Resultado em
[AUDITORIA_REGISTRO_TRABALHADORES.md](AUDITORIA_REGISTRO_TRABALHADORES.md): mapa de
referências e consumidores, estados elegíveis, idempotência/identidade dos tokens,
diagnósticos e invariantes de concorrência. Timeouts de accept retêm reservas
sem recurso; apagar essas entradas diretamente alteraria retornos e diagnóstico.
A compactação de ciclos existe, mas não tem chamadas operacionais encontradas.

Nenhum código Python foi alterado nesta solicitação; compactação 2B.2 ainda não
implementada. A referência anterior de 50 mil reservas/16.218.200 bytes rastreados
foi preservada, sem nova medição ou alegação de redução. Regressão atual:
2.031 testes aprovados em 18,844 s. Validação física e testes prolongados pendentes.


## Etapa 2A — memória do terminal e retenção — 09/11/2026

Solicitação: iniciar o controle de memória pelo terminal, com medição anterior,
deixando RegistroTrabalhadores para intervenção independente. O responsável
escolheu expressamente histórico recente em memória, limites de 5.000 linhas e
1.000.000 de caracteres, cortes antigos, exportação parcial sinalizada,
contadores, segurança e exportação sem bloquear Tk. Rotação/gravação automática
em disco foram excluídas desta etapa. Mudanças anteriores foram preservadas.

Antes de alterar o terminal, foram registradas cargas sintéticas acumuladas em
`MEDICOES_RETENCAO_2026-11-09.json`. Com 500 mil mensagens de 62 caracteres,
StringIO retinha 31 milhões de caracteres e 46.501.841 bytes Python rastreados.
Também foi medida a referência para futura compactação: 50 mil reservas resolvidas
sem alocação retiveram 50 mil entradas, zero referências de threads, zero handles
e 16.218.200 bytes rastreados. Não foram conexões reais nem prova de socket vazando.

O terminal passou a usar blocos coalescidos em deque, com corte por ambos os
limites, contadores e retratos coerentes sob lock. Linha parcial conta no limite;
descarte de LF soma linha descartada e corte parcial soma apenas caracteres,
convenção explícita no aviso de exportação. A sanitização da origem permanece;
foi adicionado filtro do histórico para valores rotulados, inclusive fragmentados,
sem guardar conteúdo descartado num histórico auxiliar. APIs públicas anteriores
preservadas e nova consulta de exportação com metadados.

O botão continua exportando `.txt` escolhido pelo usuário. Captura/gravação agora
ocorrem em worker CicloTk/B2; seletor e resultado permanecem no Tk. Não há worker
duplicado por clique repetido, diálogo tardio em janela inválida ou promessa de
histórico integral após cortes. Não foram alterados o servidor ou seus registros.

Após a mudança, a mesma carga reteve 5.000 linhas/310.000 caracteres em 77 blocos,
com 332.240 bytes Python atuais e pico de 643.617 bytes. Contadores: 495 mil linhas
LF e 30.690.000 caracteres descartados. Tempos com tracing: 4,174 s antes e
65,233 s depois; não se afirma equivalência de throughput. O script
`tests/medir_retencao_terminal.py` reproduz a carga atual. Tracemalloc não mede
memória total/RSS; não houve teste prolongado para comprovar estabilidade global.

Verificações: 29 testes novos (23 retenção/sanitização/concorrência e seis
exportação assíncrona); adaptação do teste anterior do botão ao retorno assíncrono.
Regressão completa: **2.031 testes aprovados em 27,980 s**. Compilação em memória
de 122 arquivos e whitespace aprovados. Tk real offline com raiz oculta executou
cinco callbacks durante gravação bloqueada no worker, exportou aviso de cortes e
encerrou pela B2 com workers terminados. Sem TC420, credenciais, clique humano,
logs automáticos, análise estática, ensaio prolongado, commit ou push.

Criado `RETENCAO_TERMINAL.md`, medições brutas e atualizados índice, operação,
módulos, API e revisão geral. Etapa 2B de compactação permanece pendente; não há
conclusão de memória total constante nem novo certificado global de encerramento.

## Etapa 1 — supervisão comum e segunda falha após promoção — 09/11/2026

Solicitação recebida por texto anexado: evoluir sete pontos em etapas separadas,
priorizando a recuperação do PRINCIPAL após promoção. Foi executada somente a
etapa 1; controle de memória, bandeja/semântica de NÃO, porta, análise estática,
duração e posse distribuída continuam propostas, sem implementação conjunta.

Criada `rede/supervisao_principal.py`. Manual, automático e promoção associam o
contexto original à supervisão do monitor, substituindo observadores operacionais
separados de main/conexão. O worker é acompanhado pela B2, não acessa Tk, não
recupera em saída voluntária e exige prova positiva de término do ciclo antes de
criar leitor com a mesma infraestrutura e candidatura desabilitada. O monitor
é preservado; só troca fonte após amostra válida, protegendo identidade e
cancelando supervisões antigas. A atualização imediata não duplica o loop de
refresh. Registros pendentes continuam impedindo recuperação/fechamento indevido.

Doze testes novos cobrem a sequência de duas perdas e as condições de corrida,
limpeza e identidade. Testes de integração manual/automática e inventário de
criadores de threads foram adaptados à arquitetura comum. Regressão completa:
**2.002 testes simulados aprovados em 23,652 s**. Compilação em memória de 119
arquivos e whitespace aprovados. Ensaio Tk real offline com raiz oculta confirmou
promoção, segunda falha, leitura do novo principal na mesma janela e fechamento
pela B2, com threads de leitor/supervisão encerradas.

Criado `SUPERVISAO_PRINCIPAL.md` e atualizados índice, arquitetura, módulos, API,
operação, prontidão e relatório de revisão. Foram preservados os registros de
testes físicos anteriores aprovados em 30/10/2026 conforme responsável; a ausência
de teste físico nesta etapa não significa ausência de validações físicas no
histórico. Segunda perda no principal promovido e saída/reabertura ainda precisam
de repetição física após a mudança. Sem TC420, credenciais reais, novo commit ou
push nesta etapa. Análise estática e ensaio prolongado não foram executados.

## Marcos anteriores

| Commit | Conteúdo |
| --- | --- |
| `ec3ce12` | Fonte HTTP única, integração de configuração e reconexão dos clientes |
| `8e5b2b9` | Registro, candidatura, comunicação Event/GUI e promoção manual |
| `3ddc3f6` | Estados, contador, agendamento de oportunidades e semântica da GUI |

Os marcos foram construídos incrementalmente: protocolo CONFIG, publicação
antes do servidor, espera Event, queda explícita, redescoberta, hostname e fila,
simulação, sinal de candidatura, observação por after, diálogo e login manual.
Depois foram adicionados estado descritivo, contador e registro/agendamento
de falhas. O fluxo original foi preservado a cada etapa.

## 2026-10-07 — persistência isolada

Solicitação: criar módulo de configuração sem integrar interface, main ou rede.
Criados `config/__init__.py`, `config/configuracao.py` e JSON de teste na raiz.
Validado round-trip, arquivo ausente/inválido, UTF-8 e caminho absoluto.

Solicitação seguinte: senha no Windows Credential Manager, separada do JSON.
Instalado keyring 25.7.0 e adicionadas funções salvar/carregar/remover. Teste real
com `WinVaultKeyring` e usuário temporário exclusivo; credencial removida e JSON
preservado. Nenhuma credencial real foi lida/exibida para realizar o teste.

## 2026-10-07 — documentação e commit

Solicitação: documentar profissionalmente todo o projeto, excluir `Navegador
model` e manter os documentos atualizados nas próximas solicitações.

Criada pasta `documentação` com arquitetura, contratos, módulos, inventário de
API, persistência, operação, validação e histórico. Criado `AGENTS.md` para
registrar a manutenção contínua e a exclusão do material de referência.
Documentado o comportamento observado no código, incluindo limitações que
não devem ser confundidas com futuras funções de eleição/recuperação.

Verificações desta etapa: sintaxe dos módulos, imports sem executar scripts
de equipamento, integridade dos links locais e diff sem erros de whitespace.
Nenhum teste HTTP ou eleição real foi realizado na tarefa documental.

## Convenção para novas entradas

### 2026-10-07 — encerramento voluntário do servidor

Solicitação: tornar somente servidor.py encerrável, sem prazo automático,
eleição ou rebaixamento. Evento global, funções solicitar/consultar parada,
Event.wait em leitura e SUBSCRIBE, timeout de 1 s em accept/UDP e fechamento
em finally. Iniciar limpa evento após validar token; acompanha encerramento
com joins de 2 s. Ctrl+C solicita parada. Testes localhost com HTTP simulado:
dois ciclos iniciar/parar, EOF, threads retornam e portas reutilizadas.
Quatro falhas simuladas não solicitam parada. Prazo de 25 s e antigo principal
virar cliente são propostas futuras, ainda não implementadas.

### 2026-10-07 — saúde informativa e commit

Solicitação: somente servidor.py no código para detectar três falhas HTTP
consecutivas, documentar e criar commit. Criados estado, lock, constante e getter.
Sucesso marca saudável e zera; terceiro erro torna não saudável com aviso único.
TCP/UDP/protocolos/eleição intactos. Testes simulados de erro isolado, cinco
falhas, recuperação, último peso, cópia e CHECK. Sem HTTP real nesta tarefa.
Commit também reúne preparação/ativação da promoção automática da etapa anterior.

### 2026-10-07 — callback automático na candidatura

Solicitação: ligar o callback à GUI, centralizar conclusão e atualizar documentos.
Alterados interface/janela.py e somente a injeção do callback em main.py.
Detecção única e trava de promoção preservadas. Corrigida distinção de retorno:
False sem credencial não é sucesso, apesar de diferir de None. Manual continua
usando a mesma conclusão; falha automática em aguardando não abre ASSUMIR.
Testes simulados de sucesso, fallback False/None, rearmar por pulso, falha e
trava; sem TC420 real. Recorte de métodos atualizado. Teste com dois PCs pendente.

### 2026-10-07 — preparação da promoção automática

Solicitação: somente passos 1 e 2 em main.py, sem injetar callback na GUI.
Criado getter de credenciais salvas e callback interno que reaproveita promoção.
Função promover_para_principal preservada; automático ainda não executado.
Testes simulados de credenciais ausentes/desativadas/incompletas/disponíveis e
callback sem acesso real ao cofre ou equipamento. Métodos atuais da interface
fornecidos para a próxima etapa; interface e leitor não foram alterados.

### 2026-10-07 — commit da inicialização automática

Solicitação: versionar as etapas de descoberta pré-login e login automático
na abertura, com documentação atualizada. Verificado diff sem erros de
whitespace. Incluído o ajuste solicitado de salvar_login=false no JSON,
mantendo os demais parâmetros. Caches ficam fora do commit; não foram
executados novos acessos HTTP ou leitura de credenciais.

### 2026-10-07 — desmarcar checkbox salva

Solicitação: limpar a checkbox. Ajustado salvar_login para false no JSON local.
Na próxima abertura o login automático fica desativado e a tela apresenta a
opção desmarcada. Nenhuma credencial foi removida do cofre nesta operação.

### 2026-10-07 — login automático na abertura

Solicitação: alterar apenas main.py para tentar credencial salva após primeira
descoberta vazia. Segunda descoberta evita HTTP quando outro principal aparece.
Sucesso publica approval e abre monitor diretamente; falha/indisponível abre
tela manual. Não alterados ASSUMIR, eleição ou tentativas. Documentos atualizados.
Testes simulados: configuração ausente/desativada/incompleta, senha ausente,
servidor nas duas buscas, sucesso, erro de login/approval, logs sem segredo e
fallback manual. Sem acesso à TC420 nesta etapa; validação real pendente.

### 2026-10-07 — descoberta no botão CONECTAR

Solicitação: busca pré-login com callback de main, sem dependência circular.
JanelaConexao recebe ao_encontrar_servidor. Após validação busca, destrói root
e delega se encontrar; return impede login ao voltar do callback. Sem callback
conserva tela e não acessa HTTP. Sem servidor preserva fluxo principal.
Testes simulados dos caminhos, ausência de callback, ordem destruir/delegar,
validação e injeção por main. Teste físico/Tk visual ainda pendente.
Sem mudança em login automático, candidatura ou protocolos.

### 2026-10-07 — extração do modo cliente e commit

Solicitação: extrair somente em main.py o fluxo cliente para função reutilizável,
atualizar documentação e criar commit. Criada iniciar_como_cliente(servidor);
iniciar mantém descoberta e escolha de papel. Callback de promoção, espera
CONFIG, fontes, REGISTER/SUBSCRIBE do leitor e cleanup permanecem equivalentes.
Ainda não há nova descoberta no botão CONECTAR. Testes simulados dos dois papéis,
delegação, timeout, cleanup e promoção; comparação estrutural do código extraído.
O commit também inclui a integração da persistência à tela de conexão da etapa
anterior, que estava pendente de versionamento. Sem execução HTTP real nesta etapa.

### 2026-10-07 — persistência na tela de conexão

Solicitação: alterar somente o código de interface/conexao.py para adicionar
nome da balança, porta e opção de salvar login, sem mudar descoberta/failover.
Tela ampliada para 480×480; carrega JSON e senha protegida quando habilitada.
Valida campos e grava somente após login e approval. Desmarcado remove senha
do usuário atual, mantendo os parâmetros. Porta permanece apenas armazenada.
Documentação temática e API atualizadas. Testes locais com widgets, HTTP e
persistência simulados cobrem carregamento, validação, falhas e gravação;
validação visual e login real nesta tela atualizada permanecem pendentes.

Registrar data, solicitação, arquivos afetados, comportamento resultante,
testes executados e limitações. Atualizar documentos temáticos junto do
histórico. Não transformar proposta em funcionalidade documentada como pronta.

## 2026-10-07 - descoberta condicionada à saúde

Somente CHECK e UDP alterados em servidor.py. Não saudável fecha CHECK sem OK e silencia UDP; sucesso reativa. SUBSCRIBE/cliente/eleição intactos. Testes locais TCP real e UDP simulado, saúde True-False-True e stream preservado. Sem falha HTTP real ou teste nos dois PCs.

## 2026-10-07 - SUBSCRIBE condicionado à saúde e commit

Solicitação: alterar somente SUBSCRIBE no código e criar commit. Antes de enviar verifica saúde; False encerra via finally. HTTP antigo continua executando; teste real deve parar antes da promoção. Validado TCP localhost com JSON seguido de EOF e encerramento. Documentação atualizada; commit inclui também CHECK/UDP condicionados da etapa anterior. Configuração local e caches excluídos.

### 2026-10-07 — prazo de abandono e commit

Solicitação: implementar o texto anexado em rede/servidor.py e criar commit seguindo AGENTS.md. Prazo monotônico de 25 s desde a terceira falha, cancelado no sucesso; falha concluída após o limite solicita parada e encerra leitura. Documentação atualizada. Testes simulados de HTTP/tempo/evento cobriram limite, recuperação e novo prazo; sintaxe compilada em memória e diff sem erros de whitespace. Sem teste físico ou rebaixamento para cliente. Incluída infraestrutura de parada voluntária pendente. Configuração local e caches excluídos. AGENTS.md já versionado e sem alterações.

### 2026-10-07 — detecção do encerramento no main

Solicitação do anexo: somente ponte Event/observador no login automático, sem mudar imports, servidor.py, promoção ou interface. main.py devolve servidor_encerrado; wrapper sinaliza após retorno normal e observador daemon imprime mensagens de detecção. Sem troca para cliente ou fechamento do monitor. Documentação de API, arquitetura, módulos, operação e validação atualizada. Teste local com threads/Event reais e HTTP/servidor/Tk simulados confirmou sinalização, ordem dos logs, monitor na thread principal e ausência de nova descoberta pelo observador. Sintaxe e diff verificados. Teste físico de perda da TC420 pendente. Nenhum commit solicitado nesta etapa.

### 2026-10-08 — método explícito para troca da fonte

Solicitação: adicionar somente definir_fonte_dados em interface/janela.py, antes do refresh, sem chamadas em outros arquivos; disponibilizar o leitor atual. Método valida callable antes de atribuir e imprime confirmação. Atualizados API e recorte METODOS_JANELA. Verificações: diff e sintaxe, revisão da validação antes da atribuição e ausência de chamadas novas. Sem GUI ou TC420 reais. rede/lerdadosserver.py lido e preservado: registra via REGISTER antes de SUBSCRIBE; perda de conexão chama _aguardar_candidatura e não existe opção de observação sem candidatura. Rebaixamento e modo observador ainda não implementados.

### 2026-10-08 — tipagem da fonte para Pylance

Solicitação: corrigir cinco reportIndexIssue no refresh do monitor após inclusão do setter. interface/janela.py agora anota fonte no construtor e setter como callable sem argumentos retornando Mapping[str, Any], opcional apenas no construtor. Evita retorno inferido como object após callable. API e METODOS_JANELA atualizados. Sintaxe compilada em memória e diff verificado; comportamento de validação/atribuição mantido. Pylance/Pyright não disponível como comando nesta sessão; confirmação dos diagnósticos no IDE pendente. Sem GUI ou TC420 reais.

### 2026-10-08 — variáveis de recuperação e imports

Solicitação: resolver reportPossiblyUnboundVariable de tempo_restante/tentativa e imports ausentes de requests, urllib3 e keyring. rede/lerdadosserver.py reorganiza retorno no ramo de servidor encontrado e define variáveis no caminho restante. Testes simulados de descoberta/relógio/espera confirmaram cancelamento, prazo vencido e espera. Imports reais dos três pacotes passaram em C:\Program Files\python.exe; não foi necessário instalar dependências. IDE deve selecionar esse ambiente; confirmação no Pylance pendente. MODULOS e OPERACAO atualizados; diff verificado. Sem acesso HTTP, cofre de credenciais ou TC420 física.

### 2026-10-08 — leitor sem candidatura

Solicitação: alterar somente rede/lerdadosserver.py no código, adicionando permitir_candidatura=True no construtor e retorno antecipado em _aguardar_candidatura quando False; preservar REGISTER e não integrar em main.py. Implementado conforme escopo. Documentação de API, módulos, arquitetura, operação e validação atualizada. Teste com rede/tempo simulados confirmou EOF, registro preservado, buscas repetidas sem contagem/candidatura e liberação normal com padrão True. Simulador corrigido após erro inicial de construtor; teste final passou. Sem HTTP ou TC420 reais. Integração ao monitor pendente. Diff verificado; nenhum commit solicitado.

### 2026-10-08 — iniciar leitor após encerramento do principal

Solicitação: alterar apenas observar_servidor em main.py para criar/iniciar LeitorDadosServidor(permitir_candidatura=False) após evento, sem troca de fonte, nova janela ou integração de encerramento. Implementado no caminho de login automático. API, arquitetura, módulos, operação e validação atualizados. Teste com evento/thread reais e leitor/monitor simulados confirmou criação única após sinal, opção False, chamada iniciar, logs e fonte local preservada. Sintaxe compilada no teste e diff verificado. Sem ensaio físico, HTTP ou GUI reais. Referência compartilhada, parada ao fechar janela e troca de fonte permanecem pendentes; promoção e recuperação 10/10 não alteradas. Nenhum commit solicitado.

### 2026-10-08 — observação de rebaixamento pelo monitor

Solicitação: adicionar somente observar_rebaixamento em interface/janela.py, logo após definir_fonte_dados, sem chamada ou integração em main.py. Implementado callback periódico via root.after, condicionado ao evento, existência do leitor e servidor_esta_respondendo; troca fonte via setter e termina observação, ou retorna sem reagendar quando monitor não executa. API e METODOS_JANELA atualizados. Sintaxe e diff verificados, sem teste real de Tkinter ou TC420. Integração e encerramento do leitor permanecem pendentes.

### 2026-10-08 — conectar monitor ao leitor rebaixado

Solicitação: somente main.py no código para compartilhar leitor/evento, chamar observar_rebaixamento antes de executar e parar leitor em finally. Implementado no login automático. Adicionado evento de fechamento e lock para evitar início tardio/concorrente após cleanup; espera interrompível do observador e join limitado. Servidor, eleição, protocolo e interface não alterados nesta etapa. Documentação temática atualizada. Testes simulados finais passaram para troca/fonte preservada até conexão, mensagem MONITOR, cleanup normal, fechamento antecipado/durante início e erro no monitor. Threads/eventos/locks e métodos de troca reais; rede/Tk simulados. Sintaxe/diff verificados, teste físico pendente. Login manual/promoção não integrados; nenhum commit solicitado.

### 2026-10-08 — tipo da referência compartilhada do leitor

Solicitação: corrigir reportArgumentType em main.py na atribuição da instância a leitor_rebaixado. Adicionada anotação Dict[str, Optional[LeitorDadosServidor]] e imports de typing, evitando inferência de dicionário com valores somente None. API atualizada. Sintaxe compilada em memória e diff verificado; sem alteração funcional ou teste físico. Confirmação do diagnóstico no Pylance do IDE pendente.

### 2026-10-08 — commit da integração de rebaixamento

Solicitação: criar commit das etapas pendentes. Incluídos main.py, interface/janela.py, rede/lerdadosserver.py e documentação correspondente: detecção de encerramento, leitor sem candidatura, troca de fonte na mesma janela, cleanup e correções de tipagem/variáveis. Revisado diff e compilada sintaxe em memória. Testes simulados das etapas anteriores registrados; não houve novo teste físico. Configuração local e caches excluídos; sem push.

### 2026-10-08 — detectar encerramento no login manual

Solicitação: somente interface/conexao.py no código, evento no construtor e wrapper do servidor com finally, sem leitor ou troca de fonte. Implementado mantendo sessão autenticada e thread daemon. Documentos API, módulos, arquitetura e validação atualizados. Testes simulados do wrapper confirmaram log/evento no retorno normal e exceção, com mesma sessão; sintaxe e diff verificados. Sem GUI/HTTP/TC420 reais. Motivo de encerramento não distinguido; integração de rebaixamento manual pendente. Nenhum commit solicitado.

### 2026-10-08 — integrar rebaixamento manual controlado

Usuário aprovou teste físico anterior de detecção manual: 24.980 kg antes da falha, abandono após 25 s, rotinas encerradas, log CONEXAO e último peso preservado. Relato do usuário, sem execução física pelo agente. Solicitação nova: somente interface/conexao.py no código para importar leitor, guardar instância/evento, iniciar observador e conectar monitor mantendo refresh. Implementado sem cleanup ou distinção de causa, conforme escopo desta etapa. Documentação temática atualizada. Simulação com thread/eventos reais e leitor/Tk simulados confirmou criação após evento, opção False, pronto, fonte preservada até conexão e troca na mesma janela com mensagem MONITOR. Sintaxe/diff verificados. Transição física manual ainda pendente. Nenhum commit solicitado.

### 2026-10-08 — callback opcional no fechamento do monitor

Solicitação: somente interface/janela.py no código, ao_fechar após master, armazenamento no construtor e fechar idempotente com callback e destroy em finally. Implementado sem mudanças em conexao.py. API, METODOS_JANELA e validação atualizados. Sintaxe, construtor/vínculo do X com widgets simulados e quatro cenários de fechamento passaram: sem callback, callback normal, erro no callback, erro na desconexão; segunda chamada sem efeitos. Diff verificado. Não houve GUI real, TC420 ou teste físico. Encerramento do leitor e Tk oculto no login manual ainda não resolvido. Nenhum commit solicitado.

### 2026-10-08 — confirmação do X e commit

Solicitação: alterar somente interface/janela.py nesta etapa, importar messagebox, adicionar confirmar_fechamento com três escolhas apenas registradas e ligar X ao método; preservar fechar e criar commit. Implementado. API, METODOS_JANELA e validação atualizados. Testes simulados de três respostas e vínculo X passaram sem fechar/ocultar/callback/desconexão; sintaxe e diff verificados. Teste visual real pendente; encerramento completo/bandeja não implementados. Commit inclui também alterações autorizadas pendentes da integração manual e callback de fechamento, com documentação correspondente. Configuração local e caches excluídos; sem push.

### 2026-10-08 — proteger rebaixamento de encerramento voluntário

Solicitação: adicionar evento encerramento_solicitado no construtor de interface/conexao.py e guarda após servidor_encerrado.wait no observador, sem ligar botão Sim ou parar servidor. Implementado. API, operação e validação atualizados. Simulações confirmaram cancelamento sem leitor na solicitação voluntária e rebaixamento normal sem essa solicitação; sintaxe e diff verificados. Nenhuma alteração no servidor, leitor ou monitor. Coordenação de inicialização/parada, limpeza e ligação do botão continuam pendentes; sem teste físico ou commit nesta etapa.

### 2026-10-08 — preparar encerramento completo manual

Solicitação: somente interface/conexao.py, importar solicitar_parada_servidor, criar encerrar_aplicacao conforme sequência proposta e passar ao_fechar ao monitor; não ativar Sim. Implementado. API, operação e validação atualizados. Simulações confirmaram idempotência sequencial, evento antes da parada, leitor parado quando existente, solicitação apenas para servidor iniciado/ativo e callback conectado. Sintaxe/diff verificados. Sem TC420 ou Tk reais. Corridas de início/leitor, espera de threads e destruição do monitor após Tk pai continuam pendentes antes de ativação física. Nenhum commit solicitado.

### 2026-10-08 — ativar Sim condicionado ao callback

Solicitação: somente interface/janela.py, Sim chama fechar se ao_fechar configurado; caso ausente avisa e mantém monitor. Não e Cancelar intactos. Implementado. API, METODOS_JANELA e validação atualizados. Simulações dos quatro casos passaram com fechar real e dialog/root/callback simulados; sintaxe e diff verificados. Nenhum acesso ou encerramento da TC420 real. Coordenação manual das threads e teste físico permanecem pendentes; nenhum commit solicitado.

### 2026-10-08 — serializar leitor e encerramento manual

Solicitação: lock_encerramento no construtor de interface/conexao.py, proteção da criação/publicação/início do leitor e proteção da sinalização/captura para cleanup, com parar/Tk fora do lock. Implementado conforme escopo. API, operação e validação atualizados. Testes com threads/locks/eventos reais e leitor/Tk simulados passaram para encerramento primeiro, observador primeiro e abandono normal; confirmados cleanup único e operações de parar/Tk fora do lock. Sintaxe/diff verificados. Sem teste físico; término de threads e ordem de inicialização do servidor ainda pendentes. Nenhum commit solicitado.

### 2026-10-08 — confirmar abertura do monitor e inicialização

Solicitação: verificar se login manual aguarda TCP/UDP ativos antes de abrir monitor; não aplicar lock durante iniciar_servidor. Inspeção confirmou thread_servidor.start seguido de root.after(500, abrir_monitor), sem evento/handshake de inicialização. Os 500 ms são atraso mínimo do agendamento Tk, sem garantia de bind TCP/UDP. iniciar_servidor limpa evento de parada antes de iniciar threads internas; Thread.start não confirma portas ativas. Nenhuma alteração no código ou teste operacional. Evento servidor_inicializacao_concluida e coordenação de encerramento são propostas ainda não implementadas.

### 2026-10-08 — evento opcional após clear do servidor

Solicitação: somente rede/servidor.py no código, evento_inicializacao=None na assinatura e set imediatamente após clear; não integrar em conexao.py nem testar fisicamente. Implementado preservando chamada antiga. API/validação atualizadas. Simulações confirmaram ordem clear/set/start e caminho sem evento com três threads iniciadas; sintaxe/diff verificados. Evento indica exclusivamente clear concluído, sem prontidão das portas ou saúde. Coordenação de parada ainda pendente; nenhum commit solicitado.

### 2026-10-08 — repassar evento de preparação no login manual

Solicitação: somente interface/conexao.py, criar servidor_inicializado e passá-lo ao servidor; preservar finally e encerrar_aplicacao. Implementado. API, operação e validação atualizados. Simulação com wrapper/servidor reais e threads internas simuladas confirmou inicializado após preparação e encerrado em retorno normal, falha antes/depois da confirmação e sessão inválida. Sintaxe/diff verificados. Sem teste físico ou botão Sim real. Coordenação final de parada em thread dedicada permanece pendente; nenhum commit solicitado.

### 2026-10-08 — aguardar parada manual em thread auxiliar

Solicitação: somente interface/conexao.py, finalizar_servidor espera inicialização/retorno, solicita parada após clear e aguarda encerrado por 10 s; encerrar_aplicacao inicia auxiliar sem destruir root nem solicitar parada diretamente. Implementado; lock/captura/leitor preservados. API, operação e validação atualizados. Simulações passaram nos quatro cenários, cleanup único e caminho sem servidor; sintaxe/diff verificados. Sem teste físico ou commit conforme pedido. Documentada limitação: fechar do monitor ainda executa destroy ao retornar callback, logo janela não fica preservada via Sim nesta etapa. Notificação periódica ao Tk e término completo das threads permanecem pendentes.

### 2026-10-08 — separar solicitação e conclusão no monitor

Solicitação: somente interface/janela.py, fechar delega ao callback sem destruir janela e concluir_fechamento realiza limpeza idempotente; não modificar confirmar_fechamento/conexao/servidor. Implementado. API, METODOS_JANELA e validação atualizados. Quatro comportamentos simulados aprovados, incluindo callbacks, modo sem callback, conclusão/desativação e repetição sem limpeza duplicada; também verificado erro na desconexão e callbacks periódicos sem reagendamento. Sintaxe/diff verificados. Sem teste físico ou commit conforme pedido. Notificação de conclusão ao Tk principal ainda pendente.

### 2026-10-08 — concluir janelas após resultado da parada

Solicitação: somente interface/conexao.py, eventos/resultado de finalização, finally na auxiliar e verificar_finalizacao no loop Tk para fechar monitor e root apenas após confirmação; caminho sem servidor confirma diretamente. Implementado. API, operação e validação atualizados. Cinco cenários simulados passaram: confirmado, timeout, já encerrado, sem servidor e exceção; reagendamento, ordem monitor/root, Tk na thread principal e solicitação repetida verificados. Threads/eventos reais, servidor/Tk/timeout simulados. Sintaxe/diff verificados. Sem teste físico ou commit. Espera inicial ilimitada e ausência de nova tentativa após falha documentadas; finalização de todas as threads internas ainda não garantida.

### 2026-10-08 — limitar espera de preparação na parada manual

Solicitação: somente interface/conexao.py, importar time e limitar espera inicial por prazo monotônico de 10 s; preservar restante e finally, sem teste físico/commit. Implementado. API, operação e validação atualizados. Quatro cenários simulados passaram, incluindo timeout com finalizacao_concluida sinalizado, False e interface aberta; sinalização posterior permaneceu sem proteção, conforme limitação pedida. Sintaxe/diff verificados. Proteção de servidor iniciado após timeout e nova tentativa ainda pendentes.

### 2026-10-08 — supervisionar inicialização tardia manual

Solicitação: somente interface/conexao.py, método supervisionar_inicializacao e thread daemon após thread_servidor.start, sem teste físico/commit. Implementado conforme proposta. API, operação e validação atualizados. Quatro cenários simulados aprovados com eventos/threads reais, parada/relógio simulados; interação cobriu solicitação posterior à consulta da supervisão e confirmou possibilidade de parada duplicada antes de confirmação. Sintaxe/diff verificados. Supervisão pode aguardar indefinidamente se nenhuma sinalização ocorrer; tratamento de falha/nova tentativa e deduplicação permanecem pendentes.

### 2026-10-08 — deduplicar parada no ciclo manual

Solicitação: somente interface/conexao.py, flag False no construtor, solicitar_parada_local com decisão sob lock e chamada externa fora dele, substituir chamadas de supervisão/finalização. Implementado. API, operação e validação atualizados. Quatro cenários simulados passaram com locks/threads reais e parada/espera simuladas, incluindo Barrier para simultaneidade; retornos e chamada externa fora do lock verificados. Sintaxe/diff verificados. Flag não é resetada nem confirma parada; revisão da ordem de inicialização e tratamento de falha permanecem pendentes. Sem teste físico ou commit conforme pedido.

### 2026-10-08 — revisar ordem de inicialização e parada

Solicitação: sem alterar código, inspecionar/simular quatro ordens e registrar evento global, flag de parada e continuidade. Métodos/eventos reais, threads internas/hook de escalonamento simulados. Quatro fluxos atuais resultaram evento=True, flag=True e retorno; chamadores atuais aguardam preparação após clear. Injeção adicional de solicitar_parada_local antes do clear reproduziu evento=False/flag=True, continuidade e recusa de nova parada. Falha condicional real demonstrada, não alcançada pelos quatro fluxos normais ensaiados. Relatório e tabela em VALIDACAO. Sem rede/TC420 física, alterações de código ou commit; critério global não comprovado. Diff documental verificado.

### 2026-10-08 — bloquear parada anterior à preparação

Solicitação: somente guarda em solicitar_parada_local de interface/conexao.py; preservar supervisão/finalização/servidor e não implementar retry. Implementado. API, operação e validação atualizados. Ensaio anteriormente falho passou: antes/após clear False/False, depois set e supervisão True/True, retorno do servidor; chamada antecipada não marcou flag nem sinalizou global. Barrier entre supervisão/finalização confirmou chamada única. Exceção externa continua deixando flag True, documentada sem correção nesta etapa. Sintaxe/diff verificados. Garantia depende do ciclo e ordem clear/set sem reinicialização posterior. Sem teste físico ou commit.

### 2026-10-08 — liberar flag após falha na parada local

Solicitação: somente solicitar_parada_local em interface/conexao.py, tratar exceção externa com reset da flag sob lock e False; preservar chamadores/servidor. Implementado conforme proposta. API, operação e validação atualizados. Cinco cenários simulados passaram: sucesso, exceção, nova tentativa explícita, simultaneidade e chamada antes da preparação; eventos/locks/threads reais e parada isolada/simulada. Sintaxe/diff verificados. Sem retry automático, teste físico ou commit. Finalização ainda aguarda confirmação mesmo após retorno False; recuperação de resultado não confirmado pendente.

### 2026-10-08 — avaliar exceção após sinalização da parada

Solicitação: sem código, simular exceção antes/depois de sinalizar global e nova tentativa após efeito parcial. Métodos/eventos/lock reais com exceção injetada e global isolado. Antes: flag=False/evento=False; depois: flag=False/evento=True; retry após efeito parcial fez chamada redundante, mantendo evento=True e flag=True. servidor_encerrado permaneceu False em todos os casos; dois logs observados no cenário redundante, sem outro efeito no estado simulado. Documentados significado da flag, API pública servidor_deve_parar e risco de consulta/clear entre ciclos. VALIDACAO/API atualizados, diff verificado. Sem teste físico ou commit.

### 2026-10-08 — revisar recuperação e opinar sobre estados

Solicitação: revisão simulada de quatro comportamentos pós-timeout, sem código, e opinião sobre pequena máquina de estados. Confirmados segunda solicitação ignorada, ausência de reconhecimento tardio e interface aberta tanto com servidor encerrado quanto ativo; após exceção flag libera mas fluxo de fechamento não oferece recuperação. VALIDACAO atualizada. Proposta: estados explícitos aberto/finalizando/falha/encerrado, evento de intenção preservado, nova tentativa apenas após auxiliar anterior terminar, confirmação tardia monitorada no Tk e distinção entre resultado da tentativa e término do servidor. Nada implementado. Sem teste físico ou commit.

### 2026-10-08 — estados e confirmação tardia manual

Solicitação no anexo: somente interface/conexao.py, introduzir quatro estados, finalizando sob lock e polling que reconhece término tardio, sem habilitar nova tentativa. Implementado com conclusão idempotente das janelas e caso sem servidor explicitamente tratado sem confirmação fictícia. API, operação e validação atualizados. Sete cenários simulados passaram, eventos reais e auxiliar/Tk/resultado simulados; sintaxe/diff verificados. Intenção de encerramento mantida. Confirmação disponível ainda representa retorno da rotina e não comprova todas as threads internas. Sem teste físico ou commit.

### 2026-10-08 — permitir recuperação explícita sem auxiliares simultâneas

Solicitação: somente interface/conexao.py, iniciar_tentativa_encerramento por estados, thread_finalizacao/is_alive, observador único e limpeza do leitor sob/fora lock. Implementado com start/publicação da auxiliar sob lock, polling com decisão atomicamente protegida e captura única do leitor removendo referência. Mantidos intenção e flag da parada; servidor/eleição não alterados. API, operação e validação atualizados. Simulações cobriram oito comportamentos pedidos, evento sinalizado com thread ainda viva, observador único e caminho sem servidor; threads/eventos/locks reais, finalização/Tk simulados. Sintaxe/diff verificados. Sem teste físico ou commit. Limites da confirmação/cleanup e chamadas de entrada na thread Tk documentados.

### 2026-10-08 — auditar intercalações na recuperação

Solicitação: somente inspeção/simulações, sem código, seis intercalações da recuperação. Falhou confirmação antes do retry com estado ainda falha: iniciou auxiliar desnecessária porque método não consulta servidor_encerrado. Outros cinco cenários passaram: confirmação posterior, solicitações concorrentes, término tardio, callback agendado/sem reagendamento após conclusão e flag/global preservados sem restart. Asserções Tk na thread principal, confirmação antes do destroy e cleanup único. Eventos/threads reais, rede/Tk/timeout/auxiliar simulados conforme relatório em VALIDACAO. Critério integral não aprovado; proposta de guarda mínima documentada sem implementar. Sem teste físico ou commit; diff documental verificado.

### 2026-10-08 — priorizar confirmação antes de retry

Solicitação: somente interface/conexao.py, guarda servidor_encerrado sob lock antes de nova tentativa; reproduzir caso aberto sem observador antes de ajuste. Guarda adicionada; reproduzida ausência de agendamento no primeiro pedido com servidor terminado. Fluxo encerrar_aplicacao ajustado para garantir observador único e cleanup do leitor nesse caso, mantendo Tk fora lock. API, operação e validação atualizados. Cinco cenários simulados passaram, incluindo evento após consulta com auxiliar sem nova parada; limpeza/conclusão únicas e sintaxe/diff verificados. Servidor preservado, sem teste físico ou commit. Revisão dos joins internos ainda pendente.

### 2026-10-08 — auditar fim efetivo dos trabalhadores

Solicitação: sem código, inspecionar TCP/UDP/HTTP e cinco simulações com joins limitados. Wrapper/coordenador/trabalhadores e threads/eventos reais, sockets/Web simulados; joins timeout=2 abreviados no ensaio para 20 ms. Todos os cenários retornaram/sinalizaram servidor_encerrado; TCP lento, UDP lento e HTTP bloqueado mantiveram respectivo trabalhador vivo no retorno. Exceção no close UDP terminou thread mas não foi reportada ao coordenador. Cleanup liberou/aguardou sobreviventes. Relatório em VALIDACAO inclui preparação fora do try, timeout HTTP=5 sem cancelamento e handlers não acompanhados. Critério de término completo não aprovado; resultado real da parada ainda proposta. Sem teste físico, alteração de código ou commit; diff documental verificado.

### 2026-10-08 — validar desenho do inventário por ciclo

Solicitação: somente simulações/documentação antes de implementar registro de TCP/UDP/HTTP/handlers. Protótipo isolado em memória com Thread/Lock/Event reais passou quatro intercalações: handler terminado, gate fechado primeiro, handler ativo durante finalização e coordenador durante reserva/start. Adicionais verificaram erro registrado impedindo confirmação e contextos independentes. Referências retidas e ativos calculados por is_alive; gate/start/verificação serializados. VALIDACAO registra desenho, fechamento necessário de cliente recusado e limitação de erros capturados internamente. Nenhum registro/evento novo implementado no servidor ou consumido na interface. Sem código, teste físico ou commit; diff documental verificado.

### 2026-10-08 — implementar estrutura de registro por ciclo

Solicitação: somente rede/servidor.py, RegistroTrabalhadores conforme classe proposta e instância local no início de iniciar_servidor; não substituir starts/joins nem interface. Implementado. API, módulos e validação atualizados. Sete cenários isolados passaram com threads/eventos/locks reais; adicional confirmou dois registros locais distintos e starts atuais preservados com trabalhadores simulados. Sintaxe/diff verificados. Sem teste físico ou commit. Registro ainda vazio nos ciclos reais, sem handlers ou confirmação pública integrada; erros precisam de registro explícito.

### 2026-10-08 — registrar trabalhadores principais

Solicitação: somente rede/servidor.py, três starts via registro, bloquear criação antes dos joins existentes e diagnóstico posterior. Implementado sem novos objetos de thread ou alteração de joins/interface. API, módulos e validação atualizados. Sete critérios simulados passaram com registro/threads/eventos reais, trabalhos internos simulados e joins abreviados; falha UDP deixou TCP vivo, falha HTTP deixou TCP/UDP vivos sem fluxo de parada/gate fechado, registrado como limitação de segurança. Referências falhas removidas e exceções propagadas. Cleanup do teste aguardou sobreviventes. Sintaxe/diff verificados. Handlers ainda fora do registro; sem teste físico ou commit.

### 2026-10-08 — confirmar escopo e formatação da integração

Solicitação: reafirmar três starts via registro, bloqueio/diagnóstico e pendência de inicialização parcial, sem teste físico/commit. Conferido código já implementado na etapa anterior: chamadas em linhas separadas, variável real thread_dados para HTTP, joins preservados. Sete critérios simulados anteriores registrados em VALIDACAO; não repetidos sem nova alteração. Sintaxe novamente compilada em memória. Inicialização parcial e handlers seguem pendentes; nenhuma mudança de código nesta solicitação. Diff documental verificado.

### 2026-10-08 — auditar falha parcial e inicializações concorrentes

Solicitação: sem código, cinco simulações antes de recuperar start parcial. TCP falho não iniciou trabalhadores; UDP falho deixou TCP vivo; HTTP falho deixou TCP/UDP vivos. Nos dois últimos, evento parada=False/gate aberto e nenhum fluxo de joins/timeout de recuperação, inclusive trabalhador anterior bloqueado. Dois coordenadores reais com registros distintos reproduziram clear de B apagando parada de A, ambos ativos no checkpoint. Registro/threads/eventos reais, trabalhos internos e joins abreviados simulados; cleanup externo aguardou todas as threads. Relatório em VALIDACAO. Critério de recuperação segura não aprovado; exclusividade ou parada isolada por ciclo necessárias antes do except de recuperação. Sem código, teste físico ou commit; diff documental verificado.

### 2026-10-08 — validar exclusividade do ciclo em protótipo

Solicitação: somente simulações e documentação; validar lock não bloqueante
antes do clear, liberação por finally e sobreviventes após retorno, mantendo
evento global. Protótipo temporário isolado com Thread/Lock/Event reais e
corpos simulados: B recusado antes de A terminar; clear de B não executado e
parada preservada; lock liberado na exceção e no retorno normal. Quinto cenário
reproduziu admissão prematura de B e perda da parada com antigo TCP vivo;
variantes UDP/HTTP/handler também reproduziram. Vinte threads encerradas no
cleanup, joins com timeout, asserções aprovadas e processo com código zero.
VALIDACAO detalha método, resultados, limites e ordem das próximas correções.
Lock sozinho insuficiente: próximo desenho exige registro anterior preservado
e verificação sob exclusividade antes de reutilizar evento, com futura cobertura
dos handlers. Complementação ainda não implementada/testada. Sem alteração de
código do projeto, teste físico ou commit; diff documental verificado.

### 2026-10-08 — desenhar exclusividade entre ciclos

Solicitação: executar somente protótipo isolado dos sete cenários de controle
livre/executando/pendente, preservando registro anterior e identidade por ciclo;
documentar em VALIDACAO e HISTORICO, sem alterar rede/servidor.py.
Sete cenários aprovados, com UDP e HTTP verificados separadamente: executando
e sobreviventes TCP/UDP/HTTP/handler recusaram B sem clear; último trabalhador
terminado permitiu nova reserva após reconsulta; erro relevante manteve bloqueio;
finalização atrasada com identidade de A não alterou B. Adicionais confirmaram
gate aberto impedindo confirmação mesmo vazio, criação tardia recusada após
fechamento e uma única reserva entre B/C concorrentes. Registro real extraído
por AST; controle isolado e trabalhos simulados, Thread/Lock/Event/Barrier reais.
Vinte e quatro threads iniciadas terminaram no cleanup com joins limitados;
asserções/processo aprovados e SHA-256 do servidor preservado. VALIDACAO
registra desenho, identidade exclusiva, consulta/reserva sob mesmo lock e
limites: handlers registrados só no ensaio, erro persistente sem liberação
automática e integração ainda pendente. Apenas os dois documentos alterados
nesta etapa; sem teste físico ou commit; diff documental verificado.

### 2026-10-08 — adicionar controle de ciclos sem conectar inicialização

Solicitação: somente ControleCicloServidor e instância compartilhada em
rede/servidor.py, preservando iniciar_servidor, clear, starts, joins e handlers.
Implementado conforme classe proposta, com identidade pelo registro em finalizar.
Oito testes isolados passaram usando classes importadas do módulo real:
primeira reserva, recusa concorrente, pendente com vivo, recusa pendente,
admissão após último término, bloqueio por erro, finalização antiga recusada e
gate aberto impedindo reutilização. Adicional confirmou livre após confirmação
e recusa de finalização repetida. Duas threads reais terminaram com espera
limitada; trabalho simulado. Sintaxe/import e comparação AST aprovaram preservação
de todo código anterior; diff verificado. API, MODULOS e VALIDACAO atualizados.
Controle permanece sem uso operacional, requer registro novo por ciclo e não
cobre handlers reais ainda não registrados. Próxima etapa: passagem do registro
aos handlers, antes da proteção efetiva de iniciar_servidor. Sem alteração de
interface, protocolo ou eleição, teste físico ou commit.

### 2026-10-08 — preparar repasse do registro ao servidor TCP

Solicitação: apenas parâmetro opcional em servidor_tcp e repasse do registro
local pela thread_tcp, sem modificar handlers ou conectar controle global.
Implementado registro_trabalhadores=None e kwargs correspondente, preservando
target/daemon. Seis cenários simulados aprovados: compatibilidade antiga,
identidade explícita, registros distintos em dois ciclos, criação/start dos
handlers intactos, inicialização/parada preservadas e controle sem acesso
operacional. Módulo/registro/coordenador reais, sockets e threads simulados;
sem handlers executados ou esperas físicas dos joins. Sintaxe/import e AST
confirmaram somente as duas alterações previstas; diff verificado. API,
MODULOS e VALIDACAO atualizados. Registro recebido ainda sem uso; rastreamento,
coordenação com gate e avaliação de handlers bloqueados continuam pendentes.
Sem alteração de interface, protocolo ou eleição, teste físico ou commit.

### 2026-10-08 — expor consulta de leitura do ciclo atual

Solicitação: somente consulta pública em rede/servidor.py, sem consumir na GUI
ou modificar fluxo. Adicionada consultar_estado_ciclo_servidor com locks de
controle/registro e confirmação por gate/vivos/erros. Oito cenários aprovados,
incluindo pendente/True após término tardio e novo ciclo executando/False.
3.600 consultas de leitores simultâneos em estados estáveis preservaram controle
e registro; listas retornadas isoladas. Setenta e quatro threads reais encerradas
com espera limitada, trabalho simulado, sem rede. Sintaxe/import/AST/diff aprovados;
somente nova função adicionada no código. API, MODULOS e VALIDACAO atualizados.
Resultado representa ciclo atual sem identidade associada à janela; associação
continua próxima etapa. Interface e servidor_encerrado preservados. Sem teste
físico ou commit.

### 2026-10-08 — validar identidade crescente por ciclo em protótipo

Solicitação: oito cenários isolados antes de mudar controle/consulta operacionais.
Protótipo atribuiu ID inteiro somente na reserva aceita sob lock, mantendo bool;
publicou ID no registro do dono. Oito cenários passaram: IDs 1/2, recusa sem
consumo, consulta correspondente, divergência antiga explícita sem confirmação,
finalização antiga recusada, leituras consistentes e ID mantido em pendente.
8.000 consultas com leitores/escritor, reserva simultânea e sobreposição forçada
de leitura/substituição também aprovadas. Confirmação None para ausência/divergência
é contrato apenas do protótipo, sem inferir histórico. Vinte threads reais na
execução final encerradas com espera limitada; handler simulado, sem rede.
Sintaxe/import/bytes/AST intactos e diff documental verificados. VALIDACAO detalha
contrato, captura de ID pelo dono e limites. Script temporário removido. Nenhuma
alteração de código operacional/interface; integração de identidade permanece
próxima etapa. Sem teste físico ou commit.

### 2026-10-08 — registrar handlers TCP do ciclo

Solicitação: somente rede/servidor.py, início via registro quando presente,
compatibilidade None e fechamento do cliente recusado/start falho, sem conectar
controle global. Implementado preservando target/args/daemon. Start falho continua
propagando, agora fecha cliente antes; listener fecha no finally. Sete cenários
aprovados: ativo, término com referência retida, gate recusando/fechando, falha de
start fechando/propagando, None, sobrevivente bloqueado e corrida start/bloqueio.
Seis threads reais terminaram com joins limitados; sockets e trabalho simulados,
sem recv/send real. AST/sintaxe/import e diff verificados. API, MODULOS e VALIDACAO
atualizados. Rastreamento não interrompe handlers; joins seguem dos principais;
controle global e recuperação parcial pendentes. Sem mudança na interface,
protocolo ou eleição, teste físico ou commit.

### 2026-10-08 — validar reserva e finalização antes da integração operacional

Solicitação: antes de editar servidor, protótipo isolado da reserva antes do
clear com finally abrangendo ciclo, sete cenários e ressalva de falha parcial.
Sete comportamentos aprovados: reserva prévia, recusa concorrente sem clear,
handler sobrevivente, TCP/UDP/HTTP sobreviventes, reinício após confirmação,
finally na exceção e finalização antiga recusada. Classes reais, wrapper/evento
isolados e trabalhos simulados; primeiro ensaio adicionou referências sob lock,
segundo repetiu quatro papéis com registrar_e_iniciar real. Falha parcial adicional
deixou gate aberto/parada=False e sobrevivente, embora finally marcasse pendente;
somente cleanup externo recuperou o ensaio. Recuperação do projeto não validada
nem implementada. Vinte e cinco threads reais encerradas com espera limitada;
processos/asserções, sintaxe/import, preservação de bytes/AST e diff documental
verificados. VALIDACAO detalha métodos e limites. Sem alteração de código,
integração operacional, teste físico ou commit.

### 2026-10-08 — validar recuperação de inicialização parcial em protótipo

Solicitação: oito cenários isolados antes de integrar reserva/recuperação/finally,
sem editar servidor. Protótipo com classes reais, threads/eventos/locks reais e
trabalho simulado: falhas TCP/UDP/HTTP limparam apenas iniciados, sinalizaram parada
e propagaram erro original; sobrevivente manteve pendente; término posterior
permitiu reconsulta/reserva; join falho registrou erro sem mascarar original e
manteve bloqueio mesmo sem vivos; caminho normal concluiu; B durante limpeza
foi recusado sem clear. Joins de recuperação com orçamento total de 80 ms;
vinte e três threads iniciadas terminaram com cleanup externo limitado.
Asserções/processo, sintaxe/import, bytes/AST intactos e diff documental verificados.
VALIDACAO registra desenho, distinção entre timeout e erro relevante, resultados
e limites de cobertura. Script temporário removido; nenhuma alteração operacional,
de interface, protocolo ou eleição. Integração única permanece próxima etapa.
Sem teste físico ou commit.

### 2026-10-08 — integrar reserva e recuperação parcial no coordenador

Solicitação: somente rede/servidor.py, reserva após sessão válida/antes de clear,
recuperação parcial e finally em todos os caminhos reservados, sem mudar GUI.
Implementado no coordenador: gate/parada, joins de iniciados com prazo total de
dois segundos, erros separados e exceção original preservada. Finally bloqueia
gate/finaliza; sobreviventes e erros mantêm pendente. Erro na limpeza normal
também é registrado. Dez cenários e adicionais aprovados com classes/coordenador
e 35 threads reais, trabalhos/joins abreviados simulados; sem rede. Instrumentação
do adicional de join foi corrigida para injetar na fase de limpeza. Sessões inválidas
não reservaram; novos ciclos só entraram após confirmação. AST/sintaxe/import/diff
verificados; somente iniciar_servidor alterado no código desta etapa. API, MODULOS
e VALIDACAO atualizados. Retorno do coordenador ainda sinaliza servidor_encerrado
na GUI sem comprovar trabalhadores; revisão desse contrato é próxima etapa.
Sem alteração de interface, protocolo ou eleição, teste físico ou commit.

### 2026-10-08 — integrar identidade ao controle e consulta

Solicitação do anexo: somente servidor, ID crescente na reserva aceita sob lock,
bool preservado e consulta opcional ausente/correspondente/divergente. Implementado
contador/ID e associação ao registro; finalizar por identidade preservado.
Dez cenários e adicionais aprovados com classes reais: IDs 1/2, recusa sem consumo,
consultas compatíveis/correspondentes/divergentes, ausência, pendência, finalização
antiga e concorrência. 8.000 leituras, substituição sobreposta e dois reservadores;
quatorze threads reais encerradas com espera limitada. Sintaxe/import/AST/diff
aprovados. Somente controle/consulta alterados no código; API, MODULOS e VALIDACAO
atualizados. Janela ainda não recebe ID; próxima etapa será análise main/conexao
antes da associação. Sem teste físico ou commit.

### 2026-10-08 — auditar associação entre servidor e janela

Solicitação: inspeção main/conexao/APIs servidor sem código, oito cenários e
proposta mínima de entrega direta. Mapeados três inícios: manual em JanelaConexao,
automático inicial em main e promoção manual/automática no monitor cliente.
Somente manual passa evento de preparo e sinaliza retorno em finally; automático
não sinaliza em exceção e promoção não tem eventos/wrapper. Nenhum guarda ID.
Captura global tardia reproduziu ID novo em vez do antigo. Proposta hipotética:
entrega opcional do ID do registro dentro do try reservado, fora do lock, em
contexto de tentativa antes da thread, sem Tk; não substitui evento após clear.
Oito cenários com wrappers reais extraídos por AST, entry/entrega simuladas e
oito threads reais terminaram com espera limitada; automático sem finally
reproduzido como limitação, não corrigido. Promoção apenas inspecionada.
Sintaxe/bytes/AST intactos e diff documental verificados. VALIDACAO contém
caminhos, consumo de servidor_encerrado, corridas, proposta e limites. Somente
documentação alterada; sem teste físico ou commit.

### 2026-10-08 — adicionar contexto e entrega direta do ID

Solicitação do anexo: só servidor, ContextoCicloServidor e parâmetro opcional,
sem conectar janelas. Implementado resultado único sob lock/Event; ID do registro
aceito entregue no try antes de clear; sessão inválida, recusa e falha pré-reserva
resolvem sem ID com classificação sanitizada. Falha posterior preserva ID.
Dez cenários aprovados; adicionais verificaram BaseException pré-reserva e 16
publishers concorrentes com resolução única. Três threads reais no ensaio final
principal e 16 no adicional encerradas; workers simulados, sem rede. Instrumentação
de repetição ajustada após assert indevido sobre preparo. Sintaxe/import/AST/diff
aprovados; corpo operacional/recuperação/finally preservados. API, MODULOS e
VALIDACAO atualizados. Interface/main intactos; associação manual próxima etapa,
automático/promoção posteriores. Sem teste físico ou commit.

### 2026-10-08 — associar contexto ao início manual

Solicitação: somente interface/conexao.py, contexto por tentativa e ID na janela,
sem mudar fechamento. Implementados atributos/import, contexto antes da thread,
repasse no wrapper com finally preservado e observação por after com guarda de
identidade, sem wait/global. Falha de start do coordenador resolve contexto no
tratamento existente. Dez cenários simulados passaram, incluindo recusa/falhas,
atraso, substituição rápida, callback antigo, retorno, fechamento e fonte do monitor.
Seis coordenadores reais encerrados com espera limitada; workers/root simulados,
sem GUI/rede. Sintaxe/import/AST/diff verificados; métodos de encerramento e monitor
intactos. API, MODULOS, METODOS_JANELA e VALIDACAO atualizados. ID só armazenado;
automático/promoção e fechamento por trabalhadores permanecem pendentes.
Sem teste físico ou commit.

### 2026-10-08 — associar contexto ao login automático

Solicitação: somente main.py, contexto exclusivo após login/configuração, repasse
ao servidor e preservação no resultado, sem mudar monitor/encerramento. Implementado
pelo wrapper existente, com campos anteriores preservados e sem wait/global.
Falha síncrona de start resolve contexto no tratamento existente. Dez cenários
simulados aprovados: contexto/ID, recusa, falhas, atraso sem bloquear monitor,
substituição rápida, manual intacto, fonte e semântica do evento. Seis coordenadores
reais encerrados com espera limitada; login/workers/monitor simulados, sem rede.
Sintaxe/import/AST/diff aprovados; iniciar e promoção intactos. API, MODULOS e
VALIDACAO atualizados. Wrapper automático continua sem finally; erro assíncrono
não sinaliza servidor_encerrado. Contexto apenas preservado, não usado para fechar.
Promoção é próxima associação; acompanhamento unificado permanece pendente.
Sem teste físico ou commit.

### 2026-10-15 — identificar conflito de escopo na associação de promoções

Solicitação do anexo: contexto nas promoções, somente interface, sem main.py.
Inspeção confirmou que manual/automática compartilham promover_para_principal
em main.py, único local que cria a thread correspondente; interface apenas chama
callbacks/aplica resultado. Repasse de contexto exige alteração no arquivo proibido.
Proposto ajuste mínimo: permitir rotina compartilhada de promoção em main.py e
associação em interface/janela.py, mantendo demais caminhos intactos. Nenhum código
alterado; doze cenários ainda não executados. AST/chamadores/sintaxe dos módulos
verificados e diff documental aprovado. VALIDACAO registra evidência e proposta.
Aguardando ajuste de escopo, sem teste físico ou commit.

### 2026-10-15 — associar identidade às promoções manual e automática

Autorização ampliada: somente promover_para_principal/main e associação no monitor,
sem servidor/conexao. Contexto exclusivo criado/retido por tentativa antes da thread,
passado em kwargs e resultado opcional; falhas síncronas/cancelamento resolvem sem
ID. Monitor guarda tentativa atual e referências anteriores, observa por after e
recusa atualização atrasada de identidade. Callbacks/target direto/eleição/transição
preservados; nenhum wrapper de encerramento. Doze cenários e adicionais simulados
aprovados, sete threads reais de promoção encerradas com espera limitada; entry,
HTTP/root simulados. Rebaixamento/fechamento reais testados com dependências falsas.
Regressões AST automático original e bytes manual/servidor, sintaxe/import e diff
aprovados. Sem incompatibilidade nos contratos simulados; lista retida não confirma
limpeza nem altera autorização de fechamento. VALIDACAO registra resultados e limites.
Somente main.py, interface/janela.py, VALIDACAO e HISTORICO alterados nesta etapa.
Sem teste físico ou commit.

### 2026-10-15 — auditar wrappers e eventos de encerramento

Solicitação: somente auditoria/protótipo e documentação. Mapeados manual com
finally, automático sem finally e promoções com target direto. Dez cenários
reproduzidos com wrappers/callbacks reais extraídos por AST e entry simulada:
manual sinaliza erro/normal, automático pula evento em erro, promoções não têm
acompanhamento; recusa sem ID alheio, falha pós-reserva e retorno com sobrevivente
preservam distinções. Protótipo separado de helper/contexto registrou retorno
sanitizado em finally sem mudar resultado da reserva nem ocultar erro. Quatorze
threads reais encerradas com espera limitada; sem Tk/rede. Sintaxe/import,
bytes/AST dos quatro módulos intactos e diff documental verificados. VALIDACAO
contém mapa, referências, corridas, proposta, arquivos candidatos e regressões.
Nenhum código operacional alterado. Sem teste físico ou commit.

### 2026-10-15 — acompanhar retorno do coordenador no contexto

Solicitação do anexo: somente servidor, evento/classificação separados da reserva,
publicados uma vez em finally externo após tentativa de finalização operacional.
Implementados coordenador_retornou, erro_coordenador e registrar_retorno_coordenador.
ID/resolução preservados; sanitização por categorias fixas. Falha secundária no
finally não mascara exceção principal; sem principal propaga. Doze cenários
simulados aprovados, incluindo sobrevivente, recusa, join/finalizar falhos, wrapper
manual e 4.000 leituras sob lock. Dez threads reais encerradas com espera limitada;
workers/rede simulados. Sintaxe/import/AST/diff e bytes dos três caminhos de interface
intactos verificados. Somente servidor, VALIDACAO e HISTORICO alterados. Evento
novo não comprova workers nem autoriza fechamento. Sem teste físico ou commit.

### 2026-10-15 — auditar consumidores do retorno por contexto

Solicitação do anexo: somente auditoria e dois documentos. Inspecionados manual,
automático e promoções; nenhum consumidor atual usa coordenador_retornou. Manual
fecha por evento legado; automático retém contexto mas exceção deixa legado False;
promoção mantém antigos e observa só reserva atual. Doze cenários reproduzidos
com servidor real, wrappers/callbacks extraídos por AST e dependências simuladas,
incluindo A publicando retorno depois de B reservado e worker sobrevivente.
Nove threads reais terminaram com espera limitada; sintaxe/import, bytes/AST dos
quatro módulos intactos e diff documental verificados. VALIDACAO detalha consumidores,
retenção/riscos, retrato imutável proposto e coleta somente com evidência, sem criar
estrutura. Eventos/fechamento/eleição intactos; sem teste físico ou commit.

### 2026-10-15 — adicionar consulta consistente por tentativa

Solicitação do anexo: somente servidor, snapshot de contexto com lock único e ordem
retorno implica reserva resolvida. Antes da edição, documentada permissão anterior
de registrar retorno em contexto pendente; agora publicação prematura retorna False,
sem inventar resultado. Adicionado obter_situacao com cinco campos simples e cópia,
sem global/Event.wait/confirmação de workers. Doze cenários, ordem específica e
80.000 snapshots concorrentes aprovados; nove threads reais terminaram com espera
limitada, workers simulados. Sintaxe/import/AST/diff e bytes dos três caminhos de
interface intactos verificados. Somente ContextoCicloServidor alterado no código;
VALIDACAO detalha contrato/restrição e limites. Confirmação histórica permanece
próxima etapa; sem alteração operacional, teste físico ou commit.

### 2026-10-15 — validar protótipo de confirmação histórica

Solicitação do anexo: histórico isolado por ID, reavaliação e compactação segura,
sem código operacional. Protótipo com registro real e controle/entradas/resumo
isolados passou doze cenários: reserva/recusa, confirmação condicionada a finalização,
gate/vivos/erros, término tardio, consulta antiga após novo ciclo, identidade antiga,
desconhecido e resumo frozen. Oito mil leituras/cem starts tardios recusados,
ordem de locks e coleta por weakrefs/gc adicionais passaram. Quatorze threads reais
encerradas com espera limitada; sem rede. Sintaxe/import, bytes/AST intactos e diff
documental verificados; script temporário removido. VALIDACAO registra pré-condição
essencial: todos os erros publicados antes de finalização histórica; gate sozinho
não congela erros. Resumos retidos sem exclusão automática. Integração e uso no Tk
continuam pendentes. Somente dois documentos alterados; sem teste físico ou commit.

### 2026-10-15 — integrar histórico interno ao controle de ciclos

Solicitação do anexo: somente servidor, histórico por ID, publicação antes de
confirmação e compactação, sem mudar consulta pública/UI. Implementados entradas,
snapshot interno, finalização atômica com selo de publicação e resumo frozen;
recusas sem entrada, identidade de registro preservada e pendentes reavaliáveis.
Erro após selo é rejeitado explicitamente. Compactação explícita libera referências
do controle, inclusive atual, mantendo interface de leitura; sem exclusão automática.
Quatorze cenários/corrida crítica aprovados: mil consultas durante operação final
pendente nunca confirmaram, erro tardio conhecido foi publicado antes do commit;
8.000 leituras/cem ciclos e gc adicionais aprovados. Treze threads reais encerradas
com espera limitada; workers/rede simulados. Regressões TCP/UDP/HTTP/normal,
sintaxe/import/AST/diff e bytes da interface intactos verificados. Coordenador e
consulta pública mantidos; nova consulta histórica pública permanece próxima etapa.
Somente servidor, VALIDACAO e HISTORICO alterados. Sem teste físico ou commit.

### 2026-10-16 — expor consulta histórica pública por ID

Solicitação do anexo: somente função de leitura no servidor e dois documentos.
Adicionada consultar_historico_ciclo_servidor com cinco campos simples, contagem
de vivos/bool de erros; desconhecido/None sem inferir segurança. ID inválido retorna
None/desconhecido sem conversão/eco; ID antigo usa só sua entrada histórica.
Quatorze cenários/regressão crítica A pendente→confirmado→B aprovado, mais 8.000
leituras/cem substituições, sobreposição de compactação e publicação de erro.
Treze threads reais encerradas com espera limitada, sem rede/Tk. Sintaxe/import,
AST/diff e bytes da interface intactos verificados. Somente nova função no código;
consulta anterior e operação preservadas. VALIDACAO detalha contrato/limites.
Avaliador combinado permanece próxima etapa; sem teste físico ou commit.

### 2026-10-16 — validar avaliador isolado por tentativa

Solicitação do anexo: combinar contexto e histórico sem código operacional.
Protótipo validou snapshot/ID/retorno antes de consulta histórica, com seis estados
e diagnóstico sanitizado; desconhecido/sem_ciclo não confirmam. Dezesseis cenários
e crítico aprovados: B reservado entre snapshot A e consulta não afetou identidade
A. Oito mil avaliações concorrentes/cem compactações e snapshot antigo negativo
adicionais passaram. Dez threads reais encerradas com espera limitada; fontes reais,
contextos publicados pelo harness e respostas inválidas simuladas, sem rede/Tk.
Sintaxe/import, bytes/AST intactos e diff documental verificados. Script removido;
só VALIDACAO/HISTORICO atualizados. Integração pública e agregação permanecem próximas
etapas, sem autorização de fechamento. Sem teste físico ou commit.

### 2026-10-16 — integrar avaliador público de encerramento por tentativa

Solicitação do anexo: só servidor, cinco campos, leitura de contexto e histórico
por ID, sem consumidor UI. Adicionado avaliar_encerramento_tentativa e logger
sanitizado; confirmação exige identidade estrita/retorno/cleanup, nunca bool como
ID. Dezesseis cenários, crítico de B entre fontes e 8.000 avaliações/cem compactações
aprovados; dez threads reais encerradas com espera limitada, fontes inválidas
simuladas, sem rede/Tk. Sintaxe/import/AST/diff e regressões das consultas/contexto,
coordenador e bytes dos três caminhos intactos verificados. Somente servidor,
VALIDACAO e HISTORICO alterados. Não há autorização de fechamento; próxima etapa é
auditoria de propriedade e registro das tentativas antes de agregação.
Sem teste físico ou commit.

### 2026-10-16 — auditar propriedade e registro central das tentativas

Solicitação do anexo: só auditoria/protótipo e dois documentos. Mapeados donos
manual, automático e promoções; busca em todos os módulos sem referência confirmou
três pontos internos de partida e API externa ainda sem gate de aplicação. Protótipo
de registro com admissão/versão/retrato passou quatorze cenários, corrida fechar/
registrar, lista aberta obsoleta e falha de start separada. 400 registros/4.000
retratos concorrentes e doze threads reais encerradas com espera limitada. Controle/
contextos individuais reais no teste de worker pendente, sem agregado/rede/Tk.
Sintaxe/import/bytes/AST intactos e diff documental aprovados. VALIDACAO responde
às seis questões, propõe dono de execução/injeção/gate/retencão e distingue partidas
admitidas antes do fechamento de novas admissões. Nenhum código operacional
alterado; sem teste físico ou commit.

### 2026-10-16 — implementar registro central isolado de tentativas

Solicitação do anexo: só servidor, admissão/gate/retrato sem integração UI ou partida.
Adicionadas RegistroTentativasAplicacao e descritor frozen. IDs próprios por registro,
duplicata aberta idempotente, fechamento irreversível e retrato estrutural sob lock;
sem consulta de contexto dentro do lock. Dezesseis cenários/crítico aprovados,
50 disputas Barrier, ambas ordens forçadas, 400 admissões/4.000 retratos e deduplicação
concorrente. Cento e dezesseis threads reais de harness encerradas com espera limitada;
nenhum servidor/Tk/rede iniciado. Falha de start simulada ficou pendente, sem estado
terminal inventado. Sintaxe/import/AST/diff e bytes da interface intactos aprovados.
Somente servidor, VALIDACAO e HISTORICO alterados. Sem instância global, conexão aos
caminhos, falha de partida, agregação, compactação ou autorização de fechamento.
Sem teste físico ou commit.

### 2026-10-16 — controlar estados e falha de partida no registro

Solicitação do anexo: só servidor, estados admitida/iniciando/iniciada/falha_partida,
evidência e retrato consistente, sem chamadores. Implementados descritores frozen
substituíveis sob lock, métodos de transição e marca de entrada observada; falha
terminal exige evidência explícita e recusa se partida/entrada já comprovada.
Admissão fechada preserva transições de tentativas existentes. Dezesseis cenários,
críticos start ainda retido/lançando após execução, 3.000 retratos e 25 disputas
entrada/falha aprovados. Sessenta e três threads reais entre ensaios encerradas
com espera limitada; nenhum servidor/rede/Tk. Sintaxe/import/AST/diff e bytes dos
três chamadores intactos aprovados; avaliador/contexto/controle preservados.
Somente servidor, VALIDACAO e HISTORICO alterados. Sem agregado, autorização de
fechamento, teste físico ou commit.

### 2026-10-16 — integrar partida manual ao registro da execução

Solicitação do anexo: manual em conexao e mínimo ponto de criação compartilhada.
main.iniciar cria registro e injeta apenas JanelaConexao; parâmetro opcional None
preserva uso avulso sem registro oculto. Manual admite/marca iniciando antes da
Thread, wrapper registra entrada e preserva finally legado. Construção falha prova
não execução; start ambíguo não marca falha nem resolve contexto prematuramente.
Sessão capturada local evita alteração por except da UI durante target atrasado.
Dezesseis cenários/críticos aprovados, com dezesseis threads reais encerradas com
espera limitada; root/workers simulados, sem rede/Tk. Regressões de automático/
promoções, fechamento/fonte/finally, bytes servidor/janela e sintaxe/import/AST/diff
aprovados. Somente main.py, interface/conexao.py, VALIDACAO e HISTORICO alterados.
Registro não conectado ao fechamento; outras partidas ainda fora da cobertura.
Sem teste físico ou commit.

### 2026-10-16 — integrar inicialização automática ao registro compartilhado

Solicitação do anexo: conectar a partida automática ao registro criado uma vez por
`main.iniciar`, preservar eleição/rede e validar dezesseis cenários mais corrida
crítica manual/automático/fechamento, sem teste físico ou commit.

`main.py` injeta explicitamente a mesma instância no login automático e no fallback
manual. Automático admite/marca iniciando antes da Thread; wrapper comunica entrada
e start normal confirma iniciada. Construção falha registra falha_partida com prova;
start ambíguo permanece conservador, sem espera ou resolução prematura do contexto.
Admissão recusada impede construção sem virar falha de reserva nem reabrir registro.
Evento legado continua restrito ao retorno normal do servidor; tratamento de falhas
do coordenador permanece no servidor. Uso avulso opcional não cria registro oculto.

Adicionado `tests/test_registro_automatico.py`: 18 testes aprovados via
`python -B -m unittest discover -s tests -v`, abrangendo os dezesseis cenários,
crítico com Barrier nas duas ordens de admissão/fechamento e verificações adicionais.
Oito threads reais do harness com esperas limitadas; partidas simuladas, contextos/
registros reais e coordenador real nos casos de reserva. Sem rede, HTTP, Tk ou
equipamento. AST/sintaxe e diff verificados. VALIDACAO detalha evidências e limites.

Somente main, novo teste e estes dois documentos editados nesta etapa; alterações
preexistentes preservadas. Servidor/conexao/janela e avaliador individual não
alterados. Promoções e avaliador agregado continuam pendentes; o registro ainda
não autoriza fechamento. Sem commit ou push.

### 2026-10-16 — integrar promoções manual e automática ao registro da aplicação

Solicitação do anexo: registrar ambas as promoções antes da Thread, preservar cada
contexto anterior, testar vinte cenários e corridas com fechamento nas duas ordens,
sem alterar fechamento da aplicação, servidor ou conexão.

Confirmado caminho compartilhado em promover_para_principal. Somente main.py mudou
na operação: iniciar_como_cliente aceita registro opcional e main.iniciar o injeta
por callback local nos três caminhos de abertura do CLIENTE. Cada promoção admite/
marca iniciando antes de associar contexto à UI; wrapper exige entrada aceita e
start normal confirma iniciada. Gate fechado retorna None sem Thread, troca de
contexto, falha de reserva ou penalização do leitor. Falhas comprovadas de preparação
ou construção registram falha_partida; start ambíguo preserva contexto/evidência.
Compatibilidade avulsa sem registro não cria instância silenciosa.

42 testes simulados aprovados com python -B -m unittest discover -s tests -v:
18 regressões anteriores e 24 de promoções, incluindo os vinte cenários, crítico
com Barrier nas quatro combinações de modalidade/ordem e passagem da mesma instância
nos três caminhos CLIENTE. Quinze threads reais na suíte nova, todas encerradas com
esperas limitadas; cenário antigo pendente usa worker vivo e contexto preservado.
Registros/contextos reais; coordenador real nos casos de reserva, UI/HTTP/rede
simulados, sem Tk ou equipamento. VALIDACAO detalha evidências e limitações.

SHA-256 comprovou servidor/conexao/janela intactos nesta etapa; avaliador individual,
protocolos e fechamento Tk preservados. AST das outras funções/imports de main,
sintaxe e diff aprovados. Editados main, teste anterior (expectativa da injeção),
novo teste de promoções e estes dois documentos. Cópia temporária removida e
alterações preexistentes preservadas. Próxima etapa: protótipo isolado do avaliador
agregado; não há autorização de fechamento. Sem teste físico, commit ou push.

### 2026-10-16 — prototipar avaliador agregado isolado de encerramento

Solicitação do anexo: avaliar todas as tentativas sem integrar ao servidor ou
fechamento, com vinte cenários e dois críticos concorrentes.

Adicionado prototipos/avaliador_encerramento.py com função experimental injetável,
sete campos propostos e consistente. Exige gate fechado e resolução de todas as
tentativas, valida identidades/tipos/contextos/respostas e revalida registro/contextos
ao final. Mudanças detectadas tornam o resultado conservador e permitem nova consulta.
Falha de partida exige estado terminal consistente; sem_ciclo exige retorno e provas
do ramo anterior à reserva, nunca aprovação automática. Identidades de tentativa e
ciclo permanecem separadas, sem consulta ao ciclo atual. Contadores somam o retrato
avaliado; inconsistências não são corrigidas nem produzem confirmação.

28 testes novos em tests/test_avaliador_agregado.py e 42 regressões passaram:
python -B -m unittest discover -s tests -v (70 testes). Os vinte cenários e críticos
com Barrier demonstraram primeira consulta negativa com B iniciando e posterior
positiva após ciclo encerrado ou falha comprovada; transição durante consulta foi
recusada conservadoramente. Contextos/registro/controle/avaliador individual reais,
publicações simuladas pelo harness, nove threads reais com esperas limitadas e
encerradas, sem coordenador de servidor/rede/HTTP/Tk na suíte nova.

VALIDACAO registra contrato, evidências e limites: confirma somente recursos de
servidor acompanhados; limpeza de sessões HTTP prévias não é demonstrada. Não é
ordem ou autorização para fechar o processo. SHA-256 comprovou main/servidor/conexao/
janela intactos; sintaxe/import -B, AST de leitura e diff aprovados. Somente protótipo,
novo teste e estes documentos editados nesta etapa; alterações anteriores preservadas.
Consulta pública operacional e revisão do fechamento Tk permanecem próximas etapas.
Sem teste físico, commit ou push.

### 2026-10-16 — integrar consulta pública do avaliador agregado

Solicitação do anexo: disponibilizar o protótipo validado em rede/servidor.py sem
modificar inicializações/interface/fechamento, reexecutar os 70 testes e validar
explicitamente a limitação de recursos HTTP externos.

Adicionada avaliar_encerramento_aplicacao(registro), perto do registro/contexto,
com auxiliares privados. Mantidos os oito campos efetivos (incluindo consistente),
classificações, revalidação concorrente e política conservadora do protótipo.
Usa retrato público e avaliador individual existente, sem duplicar avaliação histórica,
criar lock global, fechar admissão, aguardar threads ou alterar eventos/servidores.

102 testes simulados aprovados via python -B -m unittest discover -s tests -q:
28 cenários contra a API pública e 42 regressões de inicialização/promoções (os 70
exigidos), mais os 28 do protótipo preservado e quatro adicionais. Críticos de
partida incerta/transição, gate fechando durante avaliação, histórico divergente,
exceções e leitores concorrentes passaram. Quinze threads reais na suíte integrada,
com esperas limitadas e encerradas; sem HTTP/TCP/UDP/Tk ou equipamento nessa suíte.

Crítico HTTP: conjunto confirmou com sessão antiga simulada ainda aberta, sem
consultá-la ou chamar close. Confirmação das tentativas não demonstra liberação de
sessões HTTP/recursos externos nem autoriza fechar a aplicação; docstring pública
e VALIDACAO preservam essa separação. Auditoria de recursos e política de fechamento
continuam futuras.

Equivalência AST das regras com protótipo verificada. SHA-256 confirmou main/conexao/
janela/protótipo intactos e servidor anterior idêntico ao remover apenas bloco novo;
avaliador individual, coordenador, eleição e protocolos preservados. Sintaxe/import
-B e diff aprovados. Apenas servidor, adaptação do harness anterior, novo teste
integrado e estes documentos editados; alterações anteriores preservadas. Sem
consumidor no fechamento Tk, teste físico, commit ou push.

### 2026-10-16 — auditar recursos de rede/HTTP e prototipar inventário isolado

Solicitação do anexo: mapear criação/propriedade/limpeza/evidências de recursos,
preservar recursos antigos em protótipo e testar dezesseis cenários e dois críticos,
sem alterar funcionamento ou implementar gerenciador/limpeza.

Auditoria confirmou ausência de servidor HTTP local e de requests.Session persistente
no projeto. WebTC420 usa get/post avulsos; inspeção da dependência instalada Requests
2.34.2 e ensaio sem transporte real confirmaram Session temporária encerrada por
contexto, sem comprovar sockets físicos ou logout remoto. Não foi demonstrado
vazamento real de sessão HTTP antiga. VALIDACAO distingue recursos existentes dos
tipos HTTP hipotéticos e documenta propriedade, fechamento e referências antigas.

Lacunas concretas: preparação de sockets TCP/UDP antes do try/finally; construção
de Thread do handler fora da guarda do socket aceito; erro de close no target não
publicado em erros_limpeza, podendo deixar agregado confirmado. Leitores de CLIENTE,
arquivos makefile, descoberta e conexão TCP opcional têm evidências distintas e
não são todos cobertos pelo registro de ciclos. Nada foi corrigido nesta etapa.

Adicionados prototipos/inventario_recursos.py e tests/test_inventario_recursos.py:
metadados frozen por recurso/ciclo/tentativa/dono, reserva anterior à operação,
quatro estados conservadores e provas específicas declaradas. Não cria/fecha/consulta
recursos nem adiciona locks operacionais. Não há gate de criação; resultado só fala
do retrato observado e não autoriza fechamento global.

22 testes novos (dezesseis cenários, dois críticos e quatro verificações de código
real com recursos simulados) e 102 regressões passaram: 124 via python -B -m unittest
discover -s tests -q. Críticos preservaram recurso HTTP experimental pendente em A
mesmo com A+B confirmados pelo agregado, e mostraram reserva visível antes da criação
com Barrier. Cinco threads reais no harness, encerradas com esperas limitadas;
sem sockets/HTTP/Tk/equipamento reais. Falhas de criação/close simuladas não produziram
confirmação no inventário; o teste do handler expôs a lacuna no agregado existente.

SHA-256 confirmou todos os módulos operacionais intactos; sintaxe/import -B e diff
aprovados. Somente novo protótipo, novo teste e dois documentos editados, alterações
preexistentes preservadas. Próximas propostas documentadas, sem gerenciador de
recursos ou alteração do fechamento da janela. Sem teste físico, commit ou push.

### 2026-10-16 — prototipar proteção da criação de sockets por ciclo

Solicitação do anexo: validar reserva/alocação/publicação/bloqueio/limpeza antes
de integrar ao servidor, com dezesseis cenários e dois críticos, sem alterar operação.

Mapeados socket TCP, UDP e accept dos handlers em servidor.py: preparação anterior
ao try/finally, socket aceito antes da guarda do construtor de Thread e ausência
de reserva por recurso. VALIDACAO registra donos, publicação e dependências para
futura passagem do registro do ciclo, sem consulta à identidade global atual.

Adicionados prototipos/guarda_criacao_sockets.py e tests/test_guarda_criacao_sockets.py.
Subclasse somente experimental reutiliza lock/gate/workers/erros do RegistroTrabalhadores
real. Reserva antes de alocar, retém referência antes de preparar/publicar, resolve
com sucesso/ausência comprovada/incerteza, e publicação tardia segue limpeza de A.
Callbacks de rede/limpeza simulados ficam fora do lock. Pendências, fechamento em
curso ou erro impedem confirmação; limpeza concorrente/repetida não duplica close.

22 testes novos e 124 regressões passaram: 146 via python -B -m unittest discover
-s tests -q. Dezesseis cenários, crítico tardio com Barrier e falha parcial passaram;
ausência de handle sem prova mantém criacao_incerta. Nove threads reais no harness,
encerradas com esperas limitadas, somente sockets simulados, sem portas/Tk/equipamento.

Documentada limitação: controlador/histórico operacionais ainda não conhecem reservas;
subclasse não pode ser inserida diretamente sem adaptar o protocolo numa etapa futura.
Limpeza operacional existente permanece inalterada, assim como falhas dos handlers.
SHA-256 confirmou todos os módulos operacionais intactos; sintaxe/import -B e diff
aprovados. Apenas novo protótipo/teste e estes documentos editados, alterações
preexistentes preservadas. Sem inventário integrado, teste físico, commit ou push.

### 2026-10-16 — integrar guarda de criação de sockets ao servidor

Solicitação do anexo: integrar reservas TCP/UDP/accept e confirmação histórica,
preservar contratos públicos/interface e validar dezesseis cenários/três críticos,
sem inventário operacional novo, teste físico ou commit.

Dependências do protótipo revisadas: RegistroTrabalhadores ganhou reservas sob seu
lock/gate existentes, tokens do registro/ciclo, retenção antes de preparar/publicar
e resolução explícita. TCP/UDP/accept usam guarda sem lock durante IO/close; UDP
recebe explicitamente o registro do coordenador. Publicação após bloqueio mantém
recurso no ciclo original e o fecha sob controle. Criação opaca continua incerta.
Falha de start preserva thread/socket por poder ser ambígua; recusa da guarda não
inicia handler e fecha conexão aceita. Não há controle global de recursos novo.

Limpeza do coordenador visita sockets elegíveis após bloquear e executar joins
existentes. Criação/uso/close pendentes ou erro impedem confirmação e compactação
histórica. Resolução de recurso admitido continua após publicação do coordenador;
fileno=-1 comprova liberação local após close, sem novo fechamento de socket resolvido.

173 testes simulados passaram via python -B -m unittest discover -s tests -q:
27 novos e 146 regressões. Críticos de publicação tardia, falha parcial e accept no
encerramento preservaram recursos/identidades sem confirmação prematura. Dois testes
antigos da auditoria agora exigem fechamento nos caminhos corrigidos. Sete threads
reais na suíte nova, encerradas com esperas limitadas; nenhum socket/rede/Tk real.
VALIDACAO detalha estados, provas, protocolos CHECK/UDP e limites conservadores.

AST confirmou contexto/avaliadores/consulta histórica e corpo de atender_cliente/
leitura HTTP intactos; hashes main/conexao/janela intactos, eventos legados/eleição/
inicializações preservados. Sintaxe/import -B e diff aprovados; cópia temporária
removida. Editados servidor, novo teste, dois testes da auditoria e estes documentos;
alterações anteriores preservadas. Próxima etapa continua sendo registro dos erros
originais de close dos handlers, sem antecipar política do Tk. Sem commit ou push.

### 2026-10-16 — preservar erros originais de fechamento dos handlers

Solicitação do anexo: registrar close falho no ciclo correto, preservar exceção
original de atendimento e impedir confirmação antes da publicação da limpeza,
com dezesseis cenários/três críticos e sem alterar interface/protocolo.

atender_cliente delega apenas seu finally à finalização protegida, com registro/token
opcionais fornecidos pelo wrapper. Wrapper reserva resultado pendente por handler;
publicação sob lock preserva erro sanitizado antes de resolver a responsabilidade.
Mesmo com close posterior bem-sucedido, primeira falha continua no histórico. Se
publicação falha, pendência não some e thread pode encerrar sem confirmar o ciclo.
Erro de atendimento permanece o mesmo objeto principal; close é registrado separado.
Não há consulta ao ciclo global, objetos de exceção retidos ou controle global novo.

197 testes simulados passaram: 24 novos e 173 regressões via python -B -m unittest
discover -s tests -q. Críticos com publicação tardia, duas falhas simultâneas e
atendimento/close falhando preservaram identidade e histórico negativo. Oito threads
reais na suíte nova, encerradas com esperas limitadas; sockets simulados, sem rede,
Tk ou equipamento. Um teste anterior passou a provocar recv falho no handler real
para manter a publicação de limpeza no fluxo testado.

VALIDACAO detalha os estados, categorias fixas e limitações. Hashes main/conexao/
janela intactos; AST de contratos públicos, controlador/compactação, protocolo,
guarda de criação, TCP/UDP e HTTP preservados. Sintaxe/import -B e diff aprovados;
cópia temporária removida. Somente servidor, novo teste, adaptação do teste anterior
e estes documentos editados; alterações preexistentes preservadas. Próxima etapa
é auditar encerramento Tk, sem modificá-lo agora. Sem teste físico, commit ou push.

### 2026-10-16 — auditar encerramento Tkinter e modelar estados isolados

Solicitação do anexo: mapear fechamento real, threads, eventos, registro agregado,
bloqueios e callbacks, com dezesseis cenários e três críticos, sem alterar operação.

Auditoria dos quatro arquivos confirmou: fluxo manual usa evento legado para
destruir interface, sem fechar admissão ou consultar agregado; CLIENTE e principal
automático não recebem callback de saída, logo Sim apenas informa não configurado.
Não só imprime mensagem, sem ocultar; Cancelar mantém estado. Root da Conexão não
possui WM_DELETE_WINDOW próprio. Mapeados destroy de troca para CLIENTE, ASSUMIR,
saída direta, conclusão manual, finally de main e exceções antes/depois da destruição.

VALIDACAO documenta ordem real, donos/daemon/joins/eventos das threads, consultas
ausentes, partida tardia, parada global sem ID e IO síncrono no Tk. Identificados
risco de callbacks tardios e marcação encerrado antes de destroy, além das evidências
que ainda faltam para uma política segura. Não se validou comportamento nativo Tcl/Tk.

Adicionados prototipos/estados_encerramento_interface.py e teste isolado: modelo
proposto separa gate, agregado, recursos e destruição apenas simulada; uma intenção
de parada, cancelamento sem fechamento, gerações de atualização e consulta fora
do lock. Não é coordenador operacional e não executa parada/destroy de serviços.

222 testes simulados passaram via python -B -m unittest discover -s tests -q:
25 novos (dezesseis cenários, três críticos com Barrier e seis reproduções AST dos
caminhos atuais) e 197 regressões. Sete threads reais com esperas limitadas e
encerradas; sem Tk/rede/equipamento. Críticos preservaram admissão concorrente,
pendência após retorno do coordenador e uma única solicitação de saída modelada.

SHA-256 confirmou main/conexao/janela/servidor intactos; sintaxe/import -B e diff
aprovados. Somente novo modelo/teste e estes documentos editados, alterações
preexistentes preservadas. Dependências de um futuro coordenador registradas,
sem mudar opções Sim/Não/Cancelar. Sem teste físico, commit ou push.

### 2026-10-16 — prototipar coordenador de encerramento independente do Tk

Solicitação do anexo: máquina de estados isolada, gate antes da parada, coordenação
única, evidências adicionais ao agregado, vinte cenários/quatro críticos e regressões.

Adicionados prototipos/coordenador_encerramento.py e teste correspondente. Protótipo
separa solicitação curta, passagem explícita de parada e avaliações conservadoras;
callbacks fora do lock, sem workers próprios, rede ou Tk. Cancelar não reabre gate,
Não não oculta, política visual simulada é independente. Erros sanitizados ficam
retidos; agregação positiva exige sete responsabilidades externas explicitamente
confirmadas, nenhuma consulta em curso e passagem de parada concluída.

VALIDACAO mapeia leitores CLIENTE/rebaixamento, retentativas/descoberta, observadores,
callbacks, TCP opcional, preparações e completude do inventário. Não há verificador
de Session persistente inexistente nem adaptador operacional desses controles.
Métodos de parada/avaliação são síncronos para executor externo à UI; apenas o
harness usa threads, sem implementar ainda executor/polling Tk de produção.

250 testes simulados passaram via python -B -m unittest discover -s tests -q:
28 novos (vinte cenários, quatro críticos e quatro adicionais) e 222 regressões.
Barreiras validaram admissão concorrente e pedido único; CLIENTE ativo impediu
confirmação apesar do agregado positivo; falha de parada permaneceu impeditiva.
Operação retida permitiu consultar metadados/atualizações visuais simuladas; todas
as threads de ensaio encerradas com esperas limitadas. Sem Tk/rede/equipamento real.

SHA-256 confirmou main/janela/conexao/servidor intactos; sintaxe/import -B e diff
aprovados. Apenas novo coordenador/teste e estes documentos editados; versões
anteriores preservadas. Próxima etapa: revisar responsabilidades de parada ainda
sem comprovação suficiente, especialmente CLIENTE, antes de integrar. Sem teste
físico, commit ou push.

### 2026-10-16 — auditar responsabilidades de encerramento do CLIENTE

Solicitação: mapear atividades, proprietários, parada, provas e continuidade na
promoção; criar protótipo isolado e validar 18 cenários e quatro corridas, sem
integrar o coordenador nem alterar módulos operacionais.

Auditoria registrada em VALIDACAO: thread do leitor reúne recepção/reconexão e
primeira eleição; descoberta é chamada síncrona com UDP/TCP locais; falha de
promoção cria retentativa daemon sem referência mantida. Mapeados CONFIG,
REGISTER, SUBSCRIBE e arquivos, preparação da promoção, observadores de
rebaixamento, supervisor/finalizador manual, callbacks after e TCP direto opcional
(não iniciado no fluxo normal). Eventos e esperas não foram inventariados como
threads independentes. Proprietários, referências, guardas e provas faltantes
constam na tabela; não foi presumida Session HTTP persistente.

Lacunas: parar não aguarda threads, não alcança sockets temporários, ignora
OSError de close e pode concorrer com alocação/conexão. Retentativa perde
referência; callbacks não têm cancelamento central; atualizar_peso não verifica
fechamento. Promoção inicia servidor antes de pedir parada ao leitor: interface
continua intencionalmente, mas descoberta/retentativa antiga pode ainda terminar.
Servidor encerrado não comprova essas responsabilidades. Sim no CLIENTE normal
continua sem callback de encerramento completo. Nada disso foi corrigido agora.

Criado prototipos/responsabilidades_cliente.py: inventário somente de metadados,
identidades por responsabilidade/proprietário, estados ativo/parada_solicitada/
encerramento_confirmado/desconhecido, reservas antes de atividade, preparação
resolvida e provas específicas de término/liberação. Usa registro de tentativas
compartilhado do ensaio para admissão de promoções; preserva reservas antigas e
falhas, sem iniciar rede/threads/Tk. Destruição/atualização de callbacks é apenas
modelo atômico em memória. Confirmação diz respeito ao conjunto CLIENTE declarado,
não à aplicação inteira; provedor de provas e cobertura operacional ainda faltam.

280 testes simulados aprovados por python -B -m unittest discover -s tests -q:
30 novos (18 cenários, quatro corridas e oito adicionais) e 250 regressões.
Reconexão/promoção retidas antes da parada permaneceram registradas com ativação
tardia recusada; callback liberado após destruição fez zero acessos; agregado
real de servidor positivo não apagou descoberta CLIENTE antiga. Quatro testes
com objetos falsos reproduziram lacunas atuais, sem sockets/janelas reais.

SHA-256 de main.py e Python de interface/rede/tc420 preservado; sintaxe/import
sem bytecode e git diff --check verificados. Somente novo protótipo/teste e
VALIDACAO/HISTORICO editados; alterações anteriores preservadas. Próxima etapa:
integrar mecanismos faltantes de prova CLIENTE antes do coordenador, depois
política visual e testes de integração/físicos controlados. Sem teste físico,
commit ou push.

### 2026-10-16 — prototipar guarda de retentativas do CLIENTE e criar commit

Solicitação recebida em anexo: mecanismo isolado de admissão e comprovação das
retentativas, sem alterar os 12 arquivos operacionais. Pedido textual “e commit”
autoriza o commit desta etapa, substituindo a restrição de commit do anexo;
mantidas as restrições de teste físico e push.

Revisados os caminhos _manter_atualizado, _aguardar_candidatura,
registrar_falha_recuperacao/_aguardar_proxima_tentativa, descoberta UDP/CHECK TCP
e decisão/preparação da promoção. VALIDACAO registra quem espera, cria threads,
abre conexões, libera candidatura e permanece após mudar de modo, separando os
controles existentes das lacunas. Nenhum caminho operacional foi alterado.

Criados prototipos/guarda_retentativas_cliente.py e
tests/test_guarda_retentativas_cliente.py. Guarda por aplicação com tokens por
geração/retentativa/secundária, admissão e fechamento atômicos e irreversíveis,
partida única, entrada/retorno registrados e observação de término fora do lock.
Exceção de start não presume ausência; reserva anterior ao fechamento continua
acompanhada. Promoção muda somente metadados, preservando todas as gerações.

Secundárias são responsabilidades declaradas, sem nova guarda de socket real.
Publicação com falha permanece rastreada; thread terminada com socket pendente
não confirma. Limpeza/comprovação executa fora do lock; pendência em curso,
erro de limpeza e publicação impedem confirmação. Resultado confirma apenas
o conjunto de retentativas, nunca encerramento da aplicação.

312 testes simulados aprovados: 32 novos (18 cenários, quatro corridas e dez
adicionais) mais 280 regressões. Corridas exercitam admissão contra fechamento,
start ambíguo com entrada tardia, geração antiga após promoção e thread morta
antes da liberação do socket simulado. Barreiras/eventos/joins limitados; sem
rede ou Tk reais. Sintaxe/import sem bytecode, diff e SHA-256 dos 12 arquivos
operacionais verificados.

Commit desta etapa restrito aos dois novos arquivos e a estas novas seções de
VALIDACAO/HISTORICO; alterações preexistentes preservadas fora do commit.
Sem credenciais ou __pycache__ no commit. Próxima etapa: estudar integração da
guarda ao CLIENTE antes de tratar sockets, callbacks e coordenador. Sem teste
físico ou push.

### 2026-10-16 — analisar integração da guarda de retentativas, sem implementar

Solicitação: mapear funções reais, propriedade estável, admissão/entrada/parada/
conclusão e dependências de limpeza; testar doze cenários de integração proposta
e manter 312 regressões. Sem alterações operacionais ou necessidade de novo commit.

VALIDACAO recebeu mapa de main.iniciar/iniciar_como_cliente e suas closures,
LeitorDadosServidor.iniciar/registrar_falha_recuperacao e respectivos alvos,
busca/confirmar_servidor, promoção no Tk, observadores de rebaixamento e pedidos
de parada. Cada linha distingue solicitante, reserva, prova de entrada, falha
ambígua, conclusão e recursos dependentes. Listados arquivos, funções, ordem
proposta, compatibilidade e reversão em execução futura.

Proprietário recomendado: reutilizar escopo main.iniciar, junto ao registro de
servidores já existente, com guarda única de retentativas e coleção durável de
leitores/gerações. Cinco caminhos recebem a mesma referência; nenhuma troca de
registro na promoção, singleton ou alteração do agregado de servidores.
Retentativas síncronas são fases/secundárias do worker já existente; não criar
threads por reconexão para adaptar o aplicativo ao protótipo.

Dependências explicitadas: parada local do leitor não fecha admissão global;
controle local por geração ainda falta no modelo. Preparação da promoção no Tk
precisa de admissão própria, não de uma filha de worker já retornado. Sockets
CONFIG/REGISTER/SUBSCRIBE/UDP/CHECK e arquivos makefile ainda não publicam prova
confiável de liberação. Thread terminada, close tentado e self.cliente=None não
bastam. Exceções de start, publicação/limpeza e resultados desconhecidos continuam
impeditivos. Transferência de janela para CLIENTE não é encerramento global.

Conclusão: não integrar tudo em uma alteração pequena. Próxima etapa recomendada
é prototipar comprovação dos sockets/arquivos CLIENTE; depois injetar propriedade,
conectar execução/admissão/provas, tratar callbacks e só então coordenador.
Protocolos, tempos, sucessão/eleição e leitores rebaixados sem candidatura devem
permanecer compatíveis. Proposta ainda sem implementação operacional.

Criado tests/test_proposta_integracao_retentativas.py: 17 ensaios com a guarda
existente intacta (12 cenários pedidos, quatro corridas e composição de duas
reconexões na mesma thread). Não importa/executa módulos operacionais nos novos
testes; caminhos são etiquetas de injeção em memória. Harness usa barreiras,
eventos e joins limitados; sem rede/Tk/equipamento. 329 testes simulados aprovados,
incluindo as 312 regressões, com python -B -m unittest discover -s tests -q.

SHA-256 dos 12 arquivos operacionais preservado; sintaxe do teste e diff
verificados. Somente novo teste e novas seções de VALIDACAO/HISTORICO editados;
alterações anteriores preservadas. Sem novo commit, teste físico ou push.

### 2026-10-16 — prototipar comprovação dos recursos do CLIENTE

Solicitação: registro isolado de criação/uso/fechamento de sockets e arquivos,
incluindo gerações antigas, erros preservados e associação explícita de makefile.
Não integrar retentativas; manter 12 arquivos operacionais e guarda anterior.

Conferidos caminhos CONFIG/REGISTER/SUBSCRIBE de LeitorDadosServidor, UDP/CHECK
de buscar_servidor/confirmar_servidor e TCP direto opcional. VALIDACAO identifica
criador, geração/worker, fechamento, tratamento atual e ausência de provas.
Separados makefiles de socket dos arquivos comuns de configuração e imagens
carregadas por Tk; nenhum conteúdo local de configuração/credenciais foi lido.

Criados prototipos/recursos_cliente.py e tests/test_recursos_cliente.py. Tokens
imutáveis por registro com IDs crescentes, geração/retentativa fixas, reserva
anterior à alocação e handle associado antes da preparação. Criação tardia mantém
proprietário; falha após alocação guarda handle para limpeza; fábrica sem handle
permanece desconhecida até prova explícita de ausência. Promoção não apaga histórico.

Fechamento fora do lock com resultado/erro publicados atomicamente. Socket exige
close retornado; arquivo exige também closed is True. São provas do objeto,
sem afirmar liberação remota ou de objetos associados. Agregado considera socket
e arquivo individualmente e não confirma enquanto criação/uso/limpeza pendem.
Erros de atendimento/criação/limpeza/evidência são separados e sanitizados;
atendimento original é preservado se close também falhar. Repetição não apaga
erro de limpeza. Conjunto de recursos confirmado não significa aplicação encerrada.

365 testes simulados aprovados: 36 novos (18 cenários, quatro corridas e 14
adicionais) mais 329 regressões. Criação retida contra fechamento preservou
geração; consulta durante observação de limpeza não confirmou antes da prova;
socket fechado com arquivo aberto e geração antiga pendente mantiveram agregado
negativo. Ensaiados erros concorrentes e makefile em criação durante close do
socket. Sem rede/Tk/equipamento; esperas do harness limitadas.

SHA-256 dos 12 arquivos operacionais e da guarda de retentativas preservado;
sintaxe/import sem bytecode e diff verificados. Somente novo protótipo/teste e
novas seções de VALIDACAO/HISTORICO editados. Próxima etapa: ensaiar associação
com a guarda, sem duplicar limpeza ou criar dependências circulares. Sem commit,
teste físico ou push; alterações anteriores preservadas.

### 2026-10-16 — compor experimentalmente retentativas e recursos do CLIENTE

Solicitação: combinar execução e limpeza com identidades estáveis, cobertura
explícita e consultas coerentes, incluindo recursos sem retry e gerações antigas;
manter os dois protótipos e os 12 arquivos operacionais intactos.

Criados prototipos/composicao_cliente.py e tests/test_composicao_cliente.py.
Contexto estável identifica aplicação e referências dos registros, futuro
proprietário em main.iniciar. Manifesto imutável declara gerações/retentativas
e vínculos de todos os recursos. Retentativa opcional é metadado da composição:
o ID obrigatório no registro de recursos continua como atividade proprietária;
nenhuma mudança ao contrato anterior nem retry fictício para atividade independente.

Avaliador somente consulta APIs públicas; não fecha objetos, pede parada, inicia
threads ou resolve secundárias. Exige execução confirmada, recursos associados
comprovados, cobertura completa e ambas as admissões fechadas. Recurso sem retry
também bloqueia positivo global. Ausência de entradas não comprova instrumentação
completa; declaração completa=False é o padrão. Declaração externa incorreta de
cobertura ainda não pode ser detectada sem a futura instrumentação operacional.

Quatro leituras T1/R1/T2/R2 revalidam retratos completos, com schemas e provas
coerentes, sem lock global compartilhado. Mudança ou erro conserva negativo;
positivo se apoia na monotonicidade dos contratos atuais após gates fechados,
não em snapshot genérico com ABA arbitrário. Modo PRINCIPAL não apaga a geração
CLIENTE antiga. VALIDACAO detalha contratos, limites e a associação futura.

397 testes simulados aprovados: 32 novos (18 cenários, cinco críticos e nove
adicionais) mais 365 regressões. Cobertas criação pendente, fechamento entre
consultas, makefile de geração antiga, erro de limpeza com publicação atrasada
e cobertura incompleta apesar de recursos aparentemente vazios. Ensaios usam
protótipos/objetos falsos, sem módulos operacionais, rede ou Tk nos novos testes;
eventos/joins limitados. Verificada também ausência de mutação/limpeza pelo avaliador.

SHA-256 dos 12 arquivos operacionais e dos dois protótipos anteriores preservado;
sintaxe/import sem bytecode e diff verificados. Somente nova composição/teste e
novas seções de VALIDACAO/HISTORICO editados. Integração operacional, callbacks
e ligação ao coordenador continuam futuras. Sem teste físico, commit ou push;
alterações anteriores preservadas.

### 2026-10-21 — instalar infraestrutura passiva dos registros CLIENTE

Solicitação: criar proprietário estável em main.iniciar, mantendo referências
entre mudanças de papel/clientes, sem instrumentação real ou cobertura completa.
Escopo operacional limitado a main.py e um novo módulo de infraestrutura;
servidor e os dois módulos de interface protegidos.

Revisados guarda_retentativas_cliente, recursos_cliente e composicao_cliente:
classes/avaliador são puros, com fábricas injetadas; objetos falsos pertencem aos
testes. Criado rede/infraestrutura_cliente.py como fachada de reutilização direta,
sem copiar algoritmos nem alterar protótipos. A dependência do pacote prototipos
fica explícita e concentrada na fachada. Proprietário publica contexto só após
os dois registros/vínculo existirem; falha não disponibiliza objeto parcial pronto.

main.iniciar cria uma única infraestrutura antes da descoberta, separada do
registro de servidores. Parâmetro opcional em iniciar_como_cliente e metadados
de instância ligam leitores/monitores construídos em main e janela manual ao
mesmo proprietário. Callback manual captura o mesmo contexto. Sem parâmetro novo,
iniciar_como_cliente preserva o comportamento anterior, sem registro privado implícito.
Promoção não recria registros. Ainda não são registradas gerações reais/atividades.

Limite documentado: leitor rebaixado criado dentro de JanelaConexao não recebe
automaticamente o metadado da janela; essa passagem exige futura alteração de
outro módulo. Ampliação interrompida nesse limite, preservando arquivos protegidos.
Nenhuma alteração de conexão/peso/descoberta/eleição/reconexão ou fechamento visual.

avaliar somente consulta a composição com completa=False e informa cobertura
operacional incompleta. Vazio ou gates fechados não geram confirmação CLIENTE.
Não há polling, ligação ao coordenador ou alteração do agregado do servidor.

418 testes simulados aprovados: 21 novos (16 cenários, três críticos, dois
adicionais) e 397 regressões. Expectativa de um teste anterior ajustada apenas
ao novo parâmetro opcional, sem remover cenários. Verificados proprietário único,
isolamento por execução, referências compartilhadas, promoção retida concorrente,
vazio não instrumentado, falha parcial antes da descoberta e consultas sem mutação.
Rede/Tk/threads da aplicação são falsas; harness tem esperas limitadas.

SHA-256 dos 20 arquivos anteriores protegidos de interface/rede/tc420/prototipos
preservado; sintaxe/import sem bytecode e diff verificados. Alterados main.py,
novo módulo, novo teste, expectativa de injeção de promoção e estas seções de
VALIDACAO/HISTORICO. Sem teste físico, commit ou push; mudanças preexistentes
preservadas. Próxima etapa: instrumentação de recursos e passagem de referências
pendente antes de guarda, cobertura completa, callbacks e coordenador.

### 2026-10-21 — instrumentar parcialmente socket SUBSCRIBE e makefile do CLIENTE

Solicitação: receber infraestrutura por injeção e registrar recursos reais do
leitor, sem mudar protocolo/eleição/reconexão ou habilitar cobertura completa.
Antes da implementação, documentada divisão: somente SUBSCRIBE e seu makefile;
CONFIG, REGISTER e UDP/CHECK ficam para etapas separadas. Localizado leitor
interno em JanelaConexao.observar_servidor e os outros criadores no main/CLI.

Alterados somente main.py, interface/conexao.py, rede/lerdadosserver.py e a
fachada rede/infraestrutura_cliente.py, além de testes e VALIDACAO/HISTORICO.
Construtores opcionais encaminham a mesma infraestrutura, incluindo rebaixamento
manual. Adaptador cria geração/atividade proprietária, sem admitir retry fictícia.
Reservas antecedem socket/makefile; proxies encaminham as mesmas operações de
comunicação aos objetos reais, com identidade/uso/limpeza pelo registro validado.

parar/finally continuam responsáveis por pedir shutdown e close nos locais
anteriores. Socket e arquivo têm tokens/provas distintos. Erros de close ficam
retidos mesmo quando o fluxo legado captura OSError; erro de atendimento é
preservado separadamente. Criação/publicação tardia mantém proprietário original.
Publicação incerta conserva handle/diagnóstico no adaptador e reserva desconhecida;
não transforma tentativa de limpeza em confirmação. Fábrica que lança após entrar
sem devolver handle permanece conservadora; prova de ausência só com não entrada.

Cobertura operacional continua incompleta mesmo após fechar todos os recursos
observados. Não integrados guarda de partidas, outros canais de conexão, visual
ou coordenador. Não se afirma cancelamento instantâneo da corrida de parada local.

444 testes simulados aprovados: 26 novos (16 cenários, quatro críticos e seis
adicionais), mais 418 regressões. Executado ciclo real do leitor com sockets/arquivos
falsos, verificando mensagem SUBSCRIBE e timeouts, provas do par e negativo global.
Método do observador manual validou injeção; corridas cobrem criação tardia,
limpeza/consulta, makefile independente e gerações antigas. Sem rede/Tk/equipamento;
harness tem esperas limitadas. Expectativa de um teste anterior ajustada somente
ao argumento opcional da infraestrutura.

SHA-256 preservou janela.py, servidor.py, buscarservidor.py e os nove protótipos;
sintaxe/import sem bytecode e diff verificados. Alterações preexistentes preservadas.
Próximas etapas: demais canais/limpeza, guarda de retentativas, cobertura completa,
callbacks e coordenador, separadamente. Sem teste físico, commit ou push.

### 2026-10-21 — instrumentar somente a conexão CONFIG do CLIENTE

Solicitação: registrar criação, propriedade e limpeza de CONFIG, sem alterar
REGISTER, descoberta ou SUBSCRIBE, preservando erros originais e cobertura global
incompleta. Mapeamento registrado antes da alteração: fase inicial de
_manter_atualizado, create_connection(timeout=5), CONFIG\n, makefile, JSON/evento,
arquivo fechado antes do socket e except que mantém reconexão existente.

Alterados apenas bloco CONFIG em rede/lerdadosserver.py e métodos dedicados em
rede/infraestrutura_cliente.py, além de testes/documentos. Legado sem infraestrutura
mantém seus context managers. Com injeção, ler_configuracao reutiliza registro,
reservas e adaptadores existentes; cada par CONFIG recebe identidades distintas
de SUBSCRIBE e usa a geração original, sem novo registro ou retry fictícia.

Corpos de socket/arquivo são observados por usar com cleanup individual: parse/
comunicação falhos não são substituídos por exceções de close. Evidências de
atendimento e limpeza continuam separadas; close isolado ainda propaga erro.
Recusa entre publicação e entrada no uso também limpa handles conhecidos.
Fábrica opaca/create_connection que lança sem devolver handle permanece desconhecida;
ausência só com evidência suficiente de não entrada, sem deduzir de timeout.

467 testes simulados aprovados: 23 novos (16 cenários, quatro críticos, três
adicionais) e 444 regressões. Corridas validam criação CONFIG tardia, pares CONFIG/
SUBSCRIBE simultâneos, erro de cleanup atrasado e geração antiga ainda em uso.
Validados timeout/fluxo no leitor real, erro JSON preservado e gate entre publicar
arquivo/usar. Teste de ciclo anterior atualizado para incluir CONFIG e verificar
configuração/evento além de SUBSCRIBE. Sem rede/Tk/equipamento; esperas limitadas.

main, interface, servidor, busca e protótipos preservados; loop REGISTER/SUBSCRIBE
e sua lógica de reconexão não foram alterados. Sintaxe/import sem bytecode e diff
verificados. Cobertura operacional continua incompleta. Próxima etapa: REGISTER
em alteração separada, depois descoberta/guarda/composição/callbacks/coordenador.
Sem teste físico, commit ou push; alterações anteriores preservadas.

### 2026-10-21 — instrumentar REGISTER sem alterar os outros protocolos

Solicitação: reutilizar infraestrutura para socket/arquivo REGISTER com reservas,
geração estável, erros separados e cobertura incompleta, preservando CONFIG,
SUBSCRIBE, descoberta, eleição e interface. Mapeamento prévio em VALIDACAO:
REGISTER dentro do while de _manter_atualizado, create_connection(timeout=5),
REGISTER|nome em UTF-8, makefile, JSON com validação de nome/posição e cleanup.

Alterados somente bloco REGISTER de rede/lerdadosserver.py e novo método
registrar_cliente de rede/infraestrutura_cliente.py, além de testes/documentação.
Sem injeção permanece o legado. Com injeção, reserva/publicação usam registro
compartilhado e IDs próprios; callback conserva posição int exata positiva e
nome igual, atribuindo somente após validar. Helper já existente de uso/limpeza
é reutilizado sem alterar seu corpo, CONFIG ou proxies de SUBSCRIBE.

Arquivo e socket fecham separadamente, com original de comunicação/JSON preservado
se cleanup também falhar; falha isolada de close propaga. Conexão opaca que lança
sem handle permanece desconhecida; ausência exige prova suficiente antes da
fábrica. Identidade original é preservada em criação tardia e promoção. Cobertura
operacional permanece incompleta, sem nova eleição/reconexão ou fechamento visual.

489 testes simulados aprovados: 22 novos (16 cenários, quatro críticos e dois
adicionais) mais 467 regressões. Concorrência de três protocolos produz seis IDs
independentes; erro de cleanup atrasado não permite confirmação; geração antiga
continua pendente durante promoção. Validação rejeita bool/zero/negativo/string/
float/nome divergente. Ensaio real de timeout mantém timeout=5 e fluxo de candidatura;
JSON e duplo close preservam original. Ciclo completo anterior agora verifica
CONFIG/REGISTER/SUBSCRIBE e seis recursos, sem remover suas asserções anteriores.

main/interface/servidor/busca/protótipos preservados por SHA-256; sintaxe/import
sem bytecode e diff verificados. Sem rede/Tk/equipamento; esperas limitadas do
harness. Próxima etapa: descoberta em escopo separado, depois cobertura/guarda/
composição/callbacks/coordenador. Sem teste físico, commit ou push; alterações
preexistentes preservadas.

## 2026-10-21 — Recursos de descoberta do CLIENTE

Solicitação: instrumentar descoberta UDP/CHECK TCP com o proprietário estável,
preservar protocolo/eleição/promoção e auditar limites de cobertura somente por
leitura. Exigidos 16 cenários, quatro corridas e as 489 regressões. Sem teste
físico, commit ou push.

Resultado: main, janela de conexão e os quatro chamadores do leitor encaminham
o mesmo registro. Cada socket possui reserva, ID e geração próprios. Preparações
sem leitor têm adaptador retido na infraestrutura, incluindo handles de publicação
incerta cujo cleanup falhou. Não há makefile na descoberta. Timeout/None/False
continuam resultados operacionais separados das evidências de fechamento.
Histórico de gerações e buscas concorrentes permanece visível. Endereços,
mensagens, portas, timeout=2 e decisões de eleição não foram modificados.

Verificações: 514 testes simulados aprovados, 25 novos e 489 anteriores, com
eventos/barreiras limitados e transporte falso. Cobrem os 16 cenários, quatro
corridas, paridade de protocolo, setup falho, preparações e retenção de handle.
Sintaxe, AST dos métodos anteriores e SHA-256 confirmam preservação dos helpers
anteriores (exceto construtor que retém preparações), servidor, janela e nove
protótipos. git diff --check verificado. Detalhes em VALIDACAO.md.

Auditoria separa cobertos, pendentes e desconhecidos: caminhos sem injeção/CLI,
HTTP, balança direta, arquivos/Tk e admissão/término das threads não constituem
cobertura completa. Nenhum positivo operacional global foi habilitado. Próxima
etapa proposta é auditoria consolidada antes da guarda de retentativas. Sem
validação física, commit ou push; alterações preexistentes preservadas.

## 2026-10-21 — Auditoria consolidada da cobertura do CLIENTE

Solicitação: auditar os caminhos a partir de main.iniciar, construir matriz de
origem/geração/recurso/reserva/publicação/cleanup/evidência/exceção, separar CLIENTE
e PRINCIPAL e cobertura de recursos/atividades. Somente análise, testes simulados,
VALIDACAO/HISTORICO; sem corrigir lacunas, teste físico, commit ou push.

Conclusão: **cobertura parcial de recursos e atividades incompletas**. IDs e
históricos dos handles registrados conservam geração e proprietário estável,
inclusive durante promoção/rebaixamento. Isso não prova exaustividade: a fábrica
socket.create_connection pode criar/fechar sockets intermediários sem ID/prova
individual; HTTP e arquivos das preparações também não têm registro CLIENTE.
SUBSCRIBE pode pular cleanup do arquivo se socket.close lançar exceção diferente
de OSError; close de arquivo pode substituir erro do corpo. Parse JSON ocorre
fora do escopo de atendimento registrado. Handle de publicação incerta antes da
associação pode depender da vida do adaptador de leitor (preparações já são retidas).

Matriz e fronteiras documentadas em VALIDACAO.md: quatro protocolos, reconexões,
auxiliares, callbacks, HTTP, persistência, entradas sem injeção, balança direta,
Tk/keyring e serviços do PRINCIPAL. O callback de promoção mantém o registro,
mas ainda não publica marcador promover nos registros CLIENTE. Threads operacionais
não reservam retentativas na guarda; geração não equivale a prova de atividade.
Avaliação global permanece negativa; não foi habilitado certificado completo.

Verificações: **539 testes simulados aprovados**, 25 novos e 514 regressões,
incluindo os 16 cenários, quatro críticos e cinco reproduções adicionais de
lacunas. Inventário AST revisado possui 18 chaves de criadores; auxiliar sintética
não mapeada invalida sua completude. Testes reais de funções usam transporte/Tk/
threads operacionais falsos; concorrência do harness usa esperas limitadas. Falhas
de publicação são injetadas, sem alegar vazamento real. Sintaxe sem bytecode,
git diff --check e SHA-256 dos 26 fontes operacionais/protótipos verificados.

Proposta mínima, não implementada: instrumentar tentativas internas de conexão;
isolar limpeza/erros do SUBSCRIBE e reter adaptadores incertos; definir donos e
evidências de HTTP/arquivos e fronteiras externas; repetir auditoria antes de
integrar guarda de atividades e encerramento. Nenhum fonte operacional/protótipo
foi alterado; mudanças desta etapa limitam-se ao novo teste e aos dois documentos.
Sem teste físico, commit ou push; alterações anteriores preservadas.

## 2026-10-21 — Tentativas internas de conexão CONFIG/REGISTER

Solicitação: corrigir somente L1 da auditoria, reservando/acompanhando cada socket
das tentativas internas, sem duplicidade na transferência, sem modificar cleanup
SUBSCRIBE, HTTP/arquivos, guarda, eleição ou coordenador. Manter 539 regressões,
16 cenários e quatro corridas; sem teste físico, commit ou push.

Resultado: RecursosLeitorCliente.conectar_tcp percorre os mesmos endereços de
getaddrinfo, com timeout=5 por endereço, família/tipo/protocolo originais e último
OSError em esgotamento. Cada socket passa por reservar/criar antes de timeout/
connect. Falhas são limpas no registro; sucesso entrega o wrapper aberto para
CONFIG/REGISTER com o mesmo token/geração, sem reserva exterior duplicada.
abrir_socket aceita explicitamente wrapper do mesmo registro e rejeita outro;
o arquivo do protocolo mantém ID próprio e geração de origem. O proprietário
estável continua em main.iniciar, sem admissão operacional de novas atividades.

Compatibilidade: ordem, quantidade de endereços, retornos normais, timeout e fluxo
de reconexão preservados nos testes simulados. Diferença intencional: quando
operação e close lançam, propaga o erro original da operação, guarda erro de close
e aborta a sequência naquele endereço. Setup não OSError também recebe cleanup.
O caminho sem injeção e a API genérica com fábricas opacas continuam com os limites
anteriores. Retenção durável de handles incertos L4 não foi redesenhada.

Verificações: 566 testes simulados aprovados, 27 novos e 539 regressões. Cobertos
16 cenários, quatro corridas e sete adicionais, com transporte/DNS falsos e
barreiras limitadas. Comparação funcional com fábrica anterior e ensaio do leitor
real verificam protocolo, posição, configuração, timeout e decisões de candidatura.
Fixtures de quatro módulos adaptados ao novo limite, sem retirar suas asserções;
inventário de auditoria atualizado. Sintaxe, git diff --check e hashes verificados:
somente fachada e chamadas CONFIG/REGISTER do leitor alteradas operacionalmente;
24 outros fontes/protótipos e trecho integral SUBSCRIBE/cleanup preservados.

VALIDACAO.md detalha transferência, evidências, compatibilidade e limites.
Cobertura global segue parcial e atividades incompletas. Próximas etapas:
SUBSCRIBE, HTTP/arquivos e nova auditoria antes da guarda. Nenhuma alteração
nesses caminhos posteriores. Sem teste físico, commit ou push; trabalho anterior
preservado.

## 2026-10-21 — L2: limpeza independente do SUBSCRIBE

Solicitação: corrigir somente a limpeza SUBSCRIBE, acompanhando socket/makefile
individualmente, preservando gerações e erros em leitura, parada, reconexão e
promoção. Exigidos 16 cenários, quatro corridas e as 566 verificações anteriores.
Sem mudanças em CONFIG/REGISTER/descoberta/HTTP, guarda, eleição ou interface.

Resultado: o leitor mantém referências locais do par por iteração e limpa socket
e arquivo independentemente pelo helper _fechar_recurso_subscribe. O registro
existente publica provas/erros de cada token; uma falha não omite a outra limpeza
nem substitui o tratamento do erro original da leitura. Erros históricos continuam
impeditivos mesmo após close posterior bem-sucedido. Publicação/remoção da referência
corrente usa lock curto e comparação por identidade, sem fechar nova conexão por
engano. Operações reais de rede/close acontecem fora desse lock.

parar conserva sinalização/shutdown/close do socket, com tentativa de close em
finally, sem fechar arquivo ou aguardar worker na chamadora. Arquivo.close fica
na thread de leitura. Não houve novo cancelamento, join, timeout ou política de
encerramento. Leitura/cleanup em curso permanecem pendentes; falha de shutdown
não é prova de término. Legado sem registro retém handles de close falho no leitor
sem alegar evidência global. Detalhes e limites em VALIDACAO.md.

Verificações: 593 testes simulados aprovados, 27 novos e 566 anteriores; dois
testes de auditoria que reproduziam L2 agora exigem o comportamento corrigido.
Incluídos 16 cenários, quatro corridas e sete adicionais. Leitura bloqueada e
close atrasado não produzem positivo; reconexão/promoção mantêm recursos antigos;
arquivo não é fechado pela chamadora de parar. Transporte/DNS/Tk são falsos,
concorrência do harness usa eventos/barreiras limitados e espera operacional
substituída no teste. Sintaxe, git diff --check e hashes verificados: somente o
leitor mudou operacionalmente; 25 fontes/protótipos e callbacks CONFIG/REGISTER
preservados. Nenhuma afirmação de validação física de desbloqueio do socket.

Cobertura global segue parcial e atividades incompletas. HTTP/arquivos (L3 da
solicitação atual), nova auditoria e guarda permanecem para etapas posteriores.
Sem teste físico, commit ou push; alterações preexistentes preservadas.

## 2026-10-21 — L3-A: auditoria de HTTP e arquivos auxiliares

Solicitação: analisar HTTP/arquivos, separar recursos próprios (A), administrados
por biblioteca (B) e propriedade não demonstrada (C), apresentar matriz/proposta
mínima sem instrumentar nem modificar fontes operacionais, registros ou protótipos.
Exigidos 16 cenários, quatro verificações críticas e as 593 regressões.

Resultado: WebTC420 usa requests.post/get sem Session persistente, streaming,
uploads de arquivos ou Response retido entre operações. HTTP se dirige à balança
nas preparações/login/configuração/promoção; CLIENTE consulta o PRINCIPAL por TCP,
não HTTP. Polling refresh foi demarcado como exclusivamente PRINCIPAL e excluído
da instrumentação CLIENTE proposta. Dois open de configuração usam with; nenhum
temporário/arquivo de sincronização/corpo HTTP salvo foi identificado. Tk e keyring
permanecem fronteiras B/C, sem acesso ao conteúdo de credenciais/configuração real.

Inspeção local Requests 2.34.2/urllib3 2.8.0 e documentação pública confirmam o
limite: API de alto nível usa Session temporária e consumo não streaming. Ausência
de Response.close explícito não demonstra vazamento. Faltam evidências/origens
operacionais, não se presume socket aberto nem ausência física em falhas. A matriz
e as referências oficiais estão em VALIDACAO.md. Web/arquivos não publicam geração;
promover durante requisição preserva a referência, mas não cria prova desse vínculo.

Proposta não implementada: protótipo público específico para operação/Response,
depois integração HTTP por contexto imutável de operação e fronteira da biblioteca;
etapa separada para arquivo_comum antes de open e comprovação de close/closed.
Não usar atributos privados de sockets ou criar Session persistente/recursos
fictícios. Eventual tipo HTTP exigirá revisão explícita de contrato/validação,
pois Response não é um arquivo/socket já suportado. Arquivos candidatos e limites
de mudança registrados, sem autorização automática de L3-B.

Verificações: 616 testes simulados aprovados, 23 novos e 593 anteriores; 16
cenários, quatro críticos e três adicionais. Requests real com BaseAdapter falso,
corpo/arquivos em memória, AST de chamadores reais e eventos limitados; sem DNS,
rede, Tk, keyring ou leitura/escrita da configuração real. Cenários de streaming
são ensaios de contrato, não funcionalidade existente no aplicativo. Sintaxe,
git diff --check e SHA-256 dos 26 fontes operacionais/protótipos verificados:
nenhum foi modificado. Cobertura global parcial e atividades incompletas, sem
confirmação global. Sem teste físico, commit ou push; trabalho anterior preservado.

## 2026-10-21 — L3-B1: incompatibilidade HTTP e proposta de adaptação

Solicitação: integrar operações HTTP se compatíveis com a matriz L3-A; se ela
mostrar ausência de recurso persistente ou incompatibilidade com o registro,
não forçar implementação e propor a menor adaptação antes de alterar outros
módulos. Arquivos locais, guarda, protocolos, interface e coordenador preservados.

Resultado: aplicada essa condição de escopo. A matriz confirma Response local
sem streaming/Session persistente e sem necessidade demonstrada de close
adicional pelo aplicativo. Requisição em curso é responsabilidade real, mas
RegistroRecursosCliente só modela sockets/arquivos com handle e provas de close.
Verificação isolada rejeita operacao_http/resposta_http sem criar entradas; não
há compatibilidade suficiente para renomear operação como socket ou arquivo.

Integração L3-B1 não instalada nem declarada aprovada. Proposta concreta em
VALIDACAO.md: protótipo isolado de registro de operações, depois instância na
infraestrutura já pertencente a main.iniciar; contexto imutável por operação,
admissão antes da execução, publicação terminal atômica, snapshots de todas as
gerações, sem novo dono global ou cancelamento. Obrigações de close só existiriam
se um caminho real as exigisse. Arquivos futuros, transições, limites e estado
dos 16 cenários/quatro corridas estão explícitos, sem transformar testes de
auditoria em aprovação de uma integração inexistente.

Verificações: 616 regressões/testes simulados anteriores reexecutados e aprovados;
sem novos testes versionados. Incompatibilidade de tipos, ausência de closed em
Response, três chamadas HTTP sem stream/Session explícito e agregado negativo
conferidos isoladamente sem rede. SHA-256 dos 26 fontes operacionais/protótipos e
git diff --check verificados. Só VALIDACAO/HISTORICO atualizados; nenhum código
operacional, protótipo, dado local ou biblioteca alterado. Cobertura global segue
parcial e atividades incompletas. Sem teste físico, commit ou push.

## 2026-10-21 — L3-B1.1: registro experimental de operações HTTP

Solicitação: implementar somente prototipos/operacoes_http_cliente.py, testes
isolados e VALIDACAO/HISTORICO, sem instalar em main nem alterar caminhos HTTP,
recursos, guarda ou protótipos anteriores. Validar 16 cenários, quatro corridas,
separação de execução/cleanup e as 616 regressões.

Resultado: RegistroOperacoesHttpCliente vinculado ao proprietário fornecido pelo
chamador, com contextos/IDs/recibos congelados e emitidos por instância. Reserva
antes de executar; chamada fora do lock; recibo preparado separado da publicação
atômica. Falha/timeout pode resolver execução, mantendo erro sanitizado. Início
ambíguo/falha de publicação/conflito ficam desconhecidos. Primeiro resultado nunca
é substituído; recibos divergentes e pendentes ficam preservados e impedem positivo.
Mesmo recibo é idempotente se não houver incerteza. Gate fecha idempotentemente,
sem apagar reservas antigas ou impedir a execução de uma previamente admitida.

Proprietário estável associado apenas por simulação à infraestrutura real;
nenhum segundo dono global ou campo HTTP operacional criado. Consulta readonly
inclui todas as gerações e não retém payload/Response/objeto de exceção. Conjunto
HTTP fechado/vazio pode estar resolvido sem prova de cobertura; encerramento
global fica sempre False. O adicional com Response pública/corpo falso demonstra
execução concluída e cleanup ainda pendente, sem alterar a composição existente.

Verificações: 649 testes simulados aprovados, 33 novos e 616 anteriores; 16
cenários, quatro corridas, um adicional exigido e doze extras. Incluem publicação
tardia, conflito concorrente, recibo pendente impedindo positivo intermediário,
erros preservados, propriedade entre gerações, cópias de retratos e callback fora
de lock. Transporte falso e threads apenas no harness, com esperas limitadas.
Sintaxe sem bytecode, git diff --check e hashes dos 26 fontes anteriores
verificados; nenhum alterado. Sem rede/Tk/equipamento, teste físico, commit ou push.

VALIDACAO.md documenta APIs efetivas, provas externas, estados e limitações.
Próximo passo proposto: L3-B1.2 passiva; L3-B1.3 real, arquivos, auditoria, guarda
e composição permanecem posteriores. Cobertura operacional/global incompleta.

## 2026-10-21 — L3-B1.2: instalação passiva do registro HTTP

Solicitação: instalar uma instância HTTP por aplicação no proprietário existente,
preservando identidade em gerações/promoções, sem ativar operações, fechar gate
em mudança de papel ou alterar caminhos de comunicação/interface. Exigidos 16
cenários, três corridas e as 649 verificações anteriores.

Resultado: rede/infraestrutura_cliente.py reutiliza RegistroOperacoesHttpCliente
validado e expõe registro_http somente de leitura, ligado ao mesmo dono/aplicacao_id.
main.iniciar já cria e compartilha a infraestrutura uma vez; main e componentes
não precisaram de alterações. Nenhuma dependência dos testes, cópia de contrato,
singleton ou módulo operacional adicional. Operações/contextos HTTP continuam vazios.

Montagem local dos registros antigos, HTTP e estado de descoberta seguida por
uma única publicação do pacote privado _InstalacaoCliente. Acessores dependem
desse pacote completo. Falha HTTP/falha de montagem propaga original sem falso
pronto nem recriação dos anteriores. Reinicialização explícita de dono pronto
é recusada. Regras detalhadas e limites de publicação em VALIDACAO.md.

Promoções preservam referência e admissão HTTP aberta. Consulta HTTP reutiliza
o retrato readonly; avaliação CLIENTE mantém completa=False, sem composição HTTP
nova ou decisão global de aplicação. Não houve chamadas novas a HTTP, contextos,
admissões, fechamento, guarda, cancelamento ou coordenador.

Verificações: 671 testes simulados aprovados, 22 novos e 649 anteriores, incluindo
16 cenários, três corridas e três adicionais. Callbacks reais de main por AST,
dependências de rede/Tk falsas e concorrência limitada do harness. Uma asserção
do teste isolado anterior foi adaptada à presença da instância passiva, mantendo
isolamento e as demais verificações. Sintaxe sem bytecode, git diff --check e
hashes verificados: dos 27 fontes anteriores, apenas a fachada mudou; main,
interfaces, servidor, HTTP e todos os protótipos preservados.

Próxima etapa proposta: L3-B1.3 real, depois arquivos/auditoria/guarda/composição/
encerramento. Cobertura operacional segue incompleta. Sem teste físico, commit
ou push; alterações anteriores preservadas.

## 2026-10-21 — L3-B1.3: primeiro caminho HTTP acompanhado

Solicitação: conectar o registro instalado ao menor caminho completo da matriz
L3-A, preservar comunicação e 671 regressões, verificar 16 cenários/quatro
corridas, sem testes físicos, commit ou push. Escopo limitado a main, injeção
estritamente necessária na fachada, testes e estes dois documentos.

Selecionado main.iniciar → tentar_login_automatico → WebTC420.login. A fachada
executar_login_automatico captura geração/atividade de preparação da infraestrutura
existente, reserva no registro estável e executa o login inteiro fora dos locks,
até validação/retorno. Resultado ou erro volta ao ID/contexto original. Não há
novo registro, leitor fictício, atividade de retentativa ou contexto mutável no web.

Antes de alterar o código, VALIDACAO registrou a nova restrição de admissão: recusa
gera exceção explícita sem envio HTTP. main já informa o tipo da falha e retorna
False, mantendo seu contrato e fallback. Erros HTTP originais prevalecem sobre
falhas de publicação; publicação falha após sucesso bloqueia a partida do PRINCIPAL.
Falha comprovada antes de entrada resolve reserva; início já observado ou falha
na prova conserva desconhecido. Publicação tardia, duplicada e conflitante segue
o contrato anterior. Não se adicionaram tentativas, cancelamento ou recuperação.

tc420/web.py intacto: POST, URL/query, timeout, verify, validação, retornos e
exceções originais. Não foi introduzido close, Session persistente, tipo Response
ou acesso a sockets internos. Conclusão operacional não comprova limpeza: ensaios
de corpo recebido com close falho e de recurso anterior pendente mantêm avaliação
global negativa. Promoção concorrente conserva dono e geração de origem; não
se integrou automaticamente mudança de papel nos registros ou decisão de saída.

Verificações: **701 testes simulados aprovados**, 30 novos e 671 anteriores intactos,
com 16 cenários e corridas A/B/C/D; main por AST, login/Requests reais com transporte
falso, threads/barreiras limitadas. Adicionais cobrem dono em main, locks, privacidade,
recusas intermediárias e falhas de preparação/publicação. Sintaxe por ast.parse,
git diff --check e hashes conferidos: apenas main e fachada entre os 27 fontes
anteriores mudaram; 25 preservados, incluindo interfaces, HTTP, servidor e protótipos.
Detalhes e correspondência dos testes em VALIDACAO.md.

Logins manual/de promoção e approval permanecem sem instrumentação HTTP;
refresh pertence ao PRINCIPAL. Próximo passo: revisar esses caminhos separadamente,
depois L3-B2 e auditoria/guarda. Cobertura operacional incompleta, encerramento global
não confirmado. Nenhum teste físico, commit ou push; alterações anteriores preservadas.

## 2026-10-21 — L3-B1.4: login HTTP da promoção

Solicitação: selecionar só o próximo caminho HTTP independente da matriz L3-A,
reutilizar o registro instalado, preservar 701 regressões e testar 16 cenários e
quatro corridas. Sem teste físico, commit ou push; atualização dos dois documentos.

Escolhido main.iniciar_como_cliente → promover_para_principal → WebTC420.login,
compartilhado pelos callbacks manual/automático de promoção. A closure já dispõe
da infraestrutura e do leitor; captura sua geração/atividade antes de admitir
HTTP. Fachada executar_login_promocao rejeita origem de outro registro e usa o
mesmo dono instalado, sem geração adicional, leitor ou retentativa fictícia.

Extraído _executar_login_http do contrato operacional anterior, reutilizado pelo
login automático e pela promoção: uma reserva por POST, execução/validação fora
dos locks e publicação no ID/contexto original. Login automático conserva contrato;
WebTC420, protocolos, timeouts e interpretação não foram alterados. Recusa HTTP
explícita segue o except anterior de promoção: diagnóstico da classe, falha de
recuperação e None sem rede ou partida. Compatibilidade registrada em VALIDACAO
antes da alteração. Nenhuma política nova de eleição, repetição ou encerramento.

Verificações: **725 testes simulados aprovados**, 24 novos e 701 anteriores,
incluindo os 16 cenários/quatro corridas. Dois testes antigos atualizados: instalação
passiva verificada sem acionar promoção e concorrência do login automático agora
exigindo a identidade adicional da promoção. Nenhum removido. Novos ensaios usam
callback real por AST e login/Requests com transporte falso, sem rede/Tk/keyring/
equipamento. Erros originais, duplicação, limpeza pendente, origem e locks cobertos.
Sintaxe sem bytecode, git diff --check e hashes conferidos: somente main e fachada
entre os 27 fontes anteriores mudaram; os outros 25, inclusive interfaces, HTTP,
servidor e todos os protótipos, preservados. Escopo desta solicitação: dois fontes,
três testes (um novo) e os dois documentos; alterações preexistentes preservadas.

Matriz L3-A atualizada com classificação acumulada: logins automático e da promoção
instrumentados; login da janela inicial e approval pendentes; refresh exclusivo
do PRINCIPAL não aplicável. Recursos internos/limpeza física permanecem sem prova.
Cobertura HTTP incompleta; encerramento global não confirmado, mesmo após resolver
operações admitidas. Próximo passo: outro caminho HTTP isolado antes de L3-B2,
auditoria e guarda. Sem teste físico, commit ou push.

## 2026-10-21 — L3-B1.5: login HTTP manual inicial

Solicitação: instrumentar o login da janela inicial, preservar interface e
725 regressões, acompanhar autenticação anterior ao leitor e fechamento durante
HTTP, verificar 16 cenários/quatro corridas e manter justificadas as duas adaptações
de L3-B1.4. Solicitado também maior detalhamento da resposta final.

JanelaConexao.conectar, acionada pelo botão ou Enter, agora chama a fachada
executar_login_manual quando recebe a infraestrutura de main. Origem explícita de
preparação pelo contrato já existente, contexto capturado antes da reserva e mesmo
núcleo de execução/publicação; nenhuma janela cria registro ou herda geração futura.
Login automático/de promoção, main, WebTC420, protocolos, guarda e coordenador
preservados. Nenhuma nova thread de autenticação ou mudança de concorrência/botão.

Removidos logs antigos de usuário/token; erros no console mostram apenas classe,
para evitar URL com autenticação. Mensagens visuais mantidas. O label ainda usa
str(erro) do tratamento legado e pode mostrar detalhes HTTP; essa fronteira está
documentada. Recusa não envia HTTP e segue o tratamento existente, sem falso sucesso.

Destruição da janela não elimina o registro. A fachada publica sem Tk e sem
callback novo; o fluxo visual legado pode acessar widgets destruídos e lançar
TclError depois da publicação, inclusive no finally. Reprodução no harness e
dependência documentadas para a etapa de encerramento Tk. Não se declara corrigida
a janela destruída nem validada concorrência em Tk real; HTTP continua síncrono.

Verificações: **751 testes simulados aprovados**, 26 novos e os 725 anteriores,
nenhum teste antigo alterado/removido. Classe/construtor/callbacks reais por AST,
widgets que falham após destruição e transporte/persistência falsos; 16 cenários e
corridas A/B/C/D aprovados. Adicionais cobrem recusa, validação, descoberta, erro
de publicação, limpeza pendente, dono de main, legacy, locks e status HTTP.
Sintaxe sem bytecode, git diff --check e hashes verificados: só conexão e fachada
entre os 27 fontes anteriores mudaram; 25 preservados. Escopo: dois fontes, um
teste novo e dois documentos. Alterações preexistentes preservadas.

VALIDACAO mantém os nomes e justificativas das duas adaptações de L3-B1.4:
instalação passiva sem acionar promoção agora instrumentada; concorrência do login
automático exigindo também a operação da promoção, resolvida e com geração própria.
Matriz acumulada atualizada: três logins instrumentados; approval pendente, refresh
não aplicável ao CLIENTE. Próximo passo L3-B1.6, depois arquivos/auditoria/guarda/
composição. Cobertura parcial, encerramento global não confirmado. Sem teste físico,
commit ou push.

## 2026-10-21 — L3-B1.6: approval nos três fluxos

Solicitação: instrumentar approval no mesmo dono HTTP, preservar origem, protocolo,
interpretação, logins e 751 regressões; testar 16 cenários/quatro corridas, sem
arquivos, guarda, correção Tk, teste físico, commit ou push.

Auditado obter_configuracao → approval → interpretar_approval: GET de configuração
depois do login, nos fluxos automático, promoção e conexão manual. Não é autenticação;
recusa lança como antes, parser conserva retornos inclusive {} para dados não
reconhecidos. WebTC420 permanece integralmente inalterado.

Contexto explícito local preparado antes do login e compartilhado com approval:
identidade de preparação nos inícios, geração/atividade do leitor na promoção.
Nenhuma consulta à última geração nem contexto mutável no web. Logins aceitam
contexto opcional, mantendo retorno/defaults; IDs distintos para POST e GET.
Núcleo operacional generalizado da fachada envolve GET e parse fora dos locks,
publica na origem e mantém erros sanitizados/estado conservador se publicação
falhar. Recusa depois do login não envia GET e segue tratamentos existentes.

Rejeição de negócio não implica falha de limpeza; resolver falha HTTP não comprova
liberação de Response/Session/OS. Registros anteriores, protocolos, eleição,
arquivos, guarda/coordenador e política Tk preservados. Nenhum callback visual
novo. TclError legado após destruir janela durante approval foi reproduzido no
harness e continua pendente, com HTTP publicado antes dos acessos visuais antigos.

Verificações: **779 testes simulados aprovados**, 28 novos e 751 anteriores.
Os novos incluem 16 cenários, quatro corridas e três fluxos completos POST+GET,
API/parse reais com transporte falso, sem rede/GUI/keyring/equipamento reais.
Oito testes antigos em três arquivos adaptados para incluir approval nos fluxos
completos: dois do login automático, cinco do manual e um da promoção. Asserções
de login/concorrência permanecem; IDs/pares e contagens ampliadas. Nomes, razões
e limites dos harnesses documentados em VALIDACAO, junto às duas adaptações antigas
L3-B1.4. Nenhum teste removido. Sintaxe sem bytecode e git diff --check verificados.

Hashes: três dos 27 fontes anteriores mudaram (main, conexão e fachada); outros
24 preservados, incluindo HTTP e todos os protótipos. Escopo do agente: três fontes,
quatro testes (um novo) e dois documentos. AGENTS.md recebeu alteração externa
concomitante sobre detalhamento da resposta final; lida e preservada.

Matriz acumulada: três logins e approval nos três chamadores instrumentados no
fluxo injetado. Refresh do PRINCIPAL e script diagnóstico separado não pertencem
ao dono CLIENTE de main. API direta/chamadas legadas sem infraestrutura não foram
convertidas em cobertura automaticamente. Próxima etapa: auditoria de cobertura
efetiva, depois arquivos L3-B2. Cobertura global incompleta e encerramento não
confirmado. Sem teste físico, commit ou push; alterações anteriores preservadas.

## 2026-10-21 — L3-B1.7: auditoria de cobertura efetiva HTTP

Solicitação anexada e AGENTS.md relidos: somente inspeção operacional, testes
simulados e VALIDACAO/HISTORICO; preservar 779 regressões, produzir matriz
consolidada, verificar 16 cenários e quatro críticos. Sem correção operacional,
teste físico, commit ou push; resposta final detalhada.

Inventário textual/AST dos 27 fontes identifica só três APIs diretas em WebTC420:
requests.post no login, requests.get no approval e no refresh. Os três fluxos de
main.iniciar com infraestrutura estão cobertos, com um dono, dois IDs por par
POST/GET, contexto original e resultado publicado depois da interpretação. Refresh
é do PRINCIPAL e diagnóstico separado não pertence ao dono CLIENTE.

Conclusão ampliada: **cobertura de operações HTTP Parcial**. Comprovados ramos
legados sem infraestrutura no automático, na promoção e na janela, além de API
auxiliar direta com GET sem reserva. Gate fechado/registro vazio não intercepta
essas chamadas nem prova cobertura. Nenhum escape adicional foi localizado dentro
dos três ramos normais injetados; código dinâmico/dependências externos continuam
fora da prova de completude. Matriz consolidada e domínios em VALIDACAO.

Sanitização: console/retrato HTTP preservam categorias/erros sem token, senha,
URL ou Response serializada. Exposição visual já documentada foi comprovada com
HTTPError real sobre adapter falso: str(erro) no label inclui dados da URL. AST
também identifica impressão de token no script diagnóstico separado, sem executar
ou reproduzir seu conteúdo. Nenhuma mensagem/tratamento foi alterado. TclError
legado continua pendente e distinto do acompanhamento HTTP.

Recursos HTTP têm evidência contratual Parcial; liberação física Desconhecida.
Requests 2.34.2/urllib3 2.8.0 conferidos localmente: sessão temporária, consumo
padrão, tentativa de fechar adapters/descartar pools; isso não certifica cada
Response/descritor/OS. Parser bloqueado mantém operação pendente; close falho ou
publicação desconhecida não vira prova de limpeza. Global CLIENTE não confirmado.

**803 testes simulados aprovados**: 24 novos e os 779 anteriores intactos, incluindo
16 cenários e A/B/C/D: escapes legados, parser ainda bloqueado, login antigo em
paralelo à promoção real por callback e falha de publicação após GET/parse. Testes
que aprovam a detecção das lacunas não são correções nem prova de cobertura ampla.
API/parse reais sobre transporte falso, sem rede/Tk/equipamento/persistência reais.
Sintaxe sem bytecode, git diff --check e SHA-256 verificados: 27 fontes e todos os
testes antigos preservados; apenas teste novo e dois documentos alterados.

Proposta mínima, sem implementar: definir entradas suportadas e exigir/repassar
infraestrutura ou recusar HTTP sem dono; encaminhar auxiliares suportados com
contexto explícito e delimitar API crua; revisar separadamente mensagem visual
sensível; reauditar antes de L3-B2. Nenhum módulo operacional, registro, protótipo,
guarda, coordenador ou política Tk foi alterado. Alterações anteriores e AGENTS.md
preservados. Sem teste físico, commit ou push.

## 2026-10-21 — L3-B1.8: proteção das entradas HTTP suportadas

Solicitação: classificar três entradas legadas e impedir HTTP sem infraestrutura
do dono existente; preservar assinaturas, protocolos, origens e 803 regressões;
validar 16 cenários/quatro corridas. Auxiliares diretos, segurança visual, guarda,
coordenador e arquivos fora do escopo. Sem teste físico, commit ou push.

Classificadas automático, entrada CLIENTE/callback de promoção e janela manual:
todas utilizadas, nenhuma comprovada obsoleta. As três referências operacionais
estão em main e já injetam infraestrutura. Antes da alteração, VALIDACAO registrou
compatibilidade: manter assinaturas/defaults e usos sem HTTP, mas recusar a antiga
autenticação sem referência pelos canais False/None/status já existentes.

Adicionado exigir_infraestrutura_http na fachada: valida publicação, tipo do
registro, proprietário e aplicação, sem construir registro, admitir operação ou
buscar dono global. Referências globais novas são somente de tipos. Entradas
validam antes de criar Web e usam exclusivamente os executores existentes; foram
retirados os três fallbacks de POST/GET diretos. Erro InfraestruturaHttpInvalida
tem código estático seguro; diagnóstico e tratamento de falhas seguem os canais
existentes. Descoberta/modo CLIENTE sem HTTP continuam compatíveis. Cada pedido
ainda precisa de reserva, independentemente da validação inicial.

**827 testes simulados aprovados**, 24 novos e 803 anteriores. Dezesseis cenários
e corridas A/B/C/D cobrem fechamento antes da reserva, preparação versus leitor,
entradas concorrentes e recusa sem execução. API/parse reais com transporte falso;
nenhum Tk, rede, persistência/keyring ou equipamento real. Nenhum teste eliminado.

Adaptações em cinco arquivos de testes anteriores, detalhadas por fixture/método em
VALIDACAO: fixtures de 18 casos do automático e 24 da promoção recebem o dono e
adaptador necessários, sem enfraquecer asserções do ciclo do servidor; avulsa do
automático exige recusa sem infraestrutura e sucesso com ela; sequência da promoção
repassa o mesmo dono. Contraexemplo das três entradas e teste manual sem referência
agora exigem zero HTTP; AST da promoção exige validador/executores sem chamada crua.
Asserções negativas novas impedem simples acomodação de um retorno diferente.

Sintaxe sem bytecode e git diff --check verificados. SHA-256: três dos 27 fontes
anteriores mudaram (main, conexão e fachada); outros 24 preservados, incluindo
WebTC420, TCP/UDP, servidor, arquivos e todos os protótipos. Escopo: três fontes,
seis arquivos de testes (um novo) e dois documentos; alterações anteriores e
AGENTS.md preservados. Matriz acumulada atualizada com L1 protegida.

API crua WebTC420 permanece sem proteção nesta etapa; seu contraexemplo segue
aprovado e documentado para L3-B1.9. Cobertura HTTP ampla Parcial; liberação física
desconhecida e encerramento global não confirmado. Sequência: auxiliares, segurança
visual, nova auditoria, L3-B2 e guarda/composição. TclError permanece pendente da
revisão Tk. Sem teste físico, commit ou push.

## 2026-10-22 — L3-B1.9: compatibilidade da fronteira WebTC420, fase 1

Solicitação: mapear todos os consumidores antes de alterar WebTC420; implementar
somente encaminhamentos operacionais sem mudar o contrato público. Se necessário
proteger na API, apresentar impacto antes de modificar. Preservar 827 regressões,
protocolos e demais responsabilidades; sem teste físico, commit ou push.

Inventário identifica três construções operacionais (automático, promoção e janela),
todas já usando executor acompanhado. PRINCIPAL recebe o mesmo objeto autenticado
e usa obter_estado/refresh; monitor armazena web mas não chama login/approval HTTP
diretamente. Ferramenta teste_approval e testes independentes usam API crua de forma
legítima, sem pertencer ao dono CLIENTE. Nove arquivos anteriores de testes importam
WebTC420 diretamente, além dos fixtures operacionais simulados. Matriz/nomes e
contratos detalhados em VALIDACAO. Não executar nem reproduzir dados do diagnóstico.

Nenhum novo consumidor operacional que pudesse ser simplesmente encaminhado foi
encontrado. Contraexemplos com a mesma instância autenticada pelo executor comprovam
GET cru depois de fechar gate e durante publicação pendente. Registro recusa ID
inválido/estrangeiro/concluído, mas a API não recebe ID/vínculo e não distingue
esse uso de consumidor independente. Não impor registro global indiscriminado.

Alternativas avaliadas: encaminhamento já existente; proxy/restrição interna com
impacto em identidade/tipo; vínculo opcional explícito na instância. Recomendada
para decisão a terceira: preservar modo independente, vincular as três construções
operacionais e exigir autorização efêmera de uso único emitida pelo executor antes
do POST/GET. Sem registro duplicado, inferência por token/última geração ou flag
compartilhada entre threads. Instância vinculada recusa chamada crua/replay; reserva
anterior ao gate pode concluir; refresh do PRINCIPAL preservado. Nada implementado.

**851 testes simulados aprovados**: 24 novos e as 827 regressões intactas. Dezesseis
cenários avaliados e quatro críticos exercitados; A/D reproduzem bypass, portanto
aprovação dos ensaios não significa cumprimento das garantias de bloqueio. B verifica
um ID por auxiliar; C preserva origem durante promoção de metadados. Também há
compatibilidade independente, assinaturas, sanitização e consumidores estáticos.
Sintaxe sem bytecode, git diff --check e hashes verificados: todos os 27 fontes
anteriores e testes antigos preservados. Somente teste novo e os dois documentos.

Fase de compatibilidade concluída; L3-B1.9 não aprovada como proteção da API.
Proposta/impacto estão prontos para decisão, respeitando a restrição do anexo
"Não altere tc420/web.py automaticamente". Mudança de contrato opcional ou proxy
aguarda autorização explícita; nenhum módulo operacional foi editado. Cobertura
ampla Parcial, recursos físicos desconhecidos e global não confirmado. Segurança
visual/TclError continuam pendentes. Sem teste físico, commit ou push.

## 2026-10-22 — L3-B1.9: modo acompanhado opcional autorizado e implementado

Solicitação complementar: após revisar a proposta concreta e o impacto do contrato,
o responsável respondeu **“Autorizar modo acompanhado opcional (recomendado)”**.
A restrição de não alterar automaticamente WebTC420 foi respeitada: a implementação
abaixo ocorreu após essa autorização explícita. O registro da fase 1 acima conserva
o resultado anterior à autorização.

Implementado `politica_http` opcional no construtor de WebTC420 e vínculo explícito
nas três construções operacionais: login automático, manual e promoção. A fachada
existente confere o proprietário, admite no registro compartilhado e autoriza somente
a execução aceita. Login/approval da instância vinculada recusam chamadas diretas
antes de Requests. Uma permissão vale apenas para objeto/tipo/thread corretos, uma
vez, dentro da execução. ContextVar isola concorrência; contexto copiado não permite
execução em outra thread nem replay após retorno. A permissão expira antes da
publicação. Não há novo registro, proxy, identidade duplicada ou inferência de origem.

Modo independente e refresh do PRINCIPAL preservados. Operações aceitas antes do
fechamento podem concluir. Corpos originais de protocolo/parser comparados por AST,
descontando as duas consultas iniciais à política; construtor estendido de modo
opcional. Requests, parâmetros, timeout, parser, retornos e exceções autorizadas
preservados. Erros novos estáticos e sem dados sensíveis; segurança visual segue
pendente em L3-B1.10.

**860 testes simulados aprovados** por
`python -B -m unittest discover -s tests -q`: 827 regressões anteriores e 33 testes
da fronteira. Dezesseis cenários e corridas A/B/C/D agora verificam as garantias de
bloqueio, origem e publicação. Ensaios adicionais cobrem proprietário/objeto/tipo,
uso único, contexto entre threads, replay, concorrência na mesma instância e o caso
em que uma identidade válida no registro genérico não autoriza HTTP fora da fachada.
Nenhuma regressão removida. Dois testes anteriores adaptados: fábrica manual aceita
o argumento opcional; auditoria AST exige o vínculo na construção operacional.

Sintaxe dos sete arquivos Python afetados e `git diff --check` verificados.
Quatro dos 27 fontes anteriores alterados: main.py, interface/conexao.py,
rede/infraestrutura_cliente.py e tc420/web.py; 23 preservados, incluindo protocolos,
eleição, arquivos locais, registros, guarda e coordenador. Teste novo e dois documentos
atualizados, além das duas adaptações de testes descritas.

Resultado: L3-B1.9 concluída nos caminhos suportados e na simulação. A cobertura
ampla permanece conservadora até L3-B1.11; modo independente não é interceptado
globalmente e não há prova contra alterações arbitrárias de atributos privados.
Descritores físicos e encerramento global não confirmados. L3-B1.10, L3-B2,
composição e TclError continuam pendentes. Sem teste físico, commit ou push.

## 2026-10-22 — Análise diagnóstica do estado do projeto e da suíte de testes

Solicitação: "analise". Análise diagnóstica global do estado do repositório,
inventário de código, integridade da suíte de testes simulados e alinhamento
entre implementações no working tree e documentação técnica. Sem alteração em
código-fonte, testes físicos, commit ou push.

Constatações da análise:
1. Suíte de testes: 860 testes simulados distribuídos em 33 arquivos de testes,
   todos aprovados via `python -B -m unittest discover -s tests -q` (tempo ~6,9 s).
   Todos os testes operam sobre transporte e interfaces simuladas; nenhum teste
   físico com equipamento TC420 real ou dois computadores na rede foi realizado.
2. Alinhamento código versus documentação técnica:
   - No código-fonte, a proteção da fronteira HTTP (`tc420/web.py` e
     `rede/infraestrutura_cliente.py`) já possui a implementação concreta da
     alternativa 3 (vínculo opcional aditivo `politica_http=None`, autorização
     efêmera de uso único via `PoliticaHttpCliente` e `_PermissaoHttp` em
     `ContextVar`, isolada por thread e chamada).
   - O módulo `tests/test_fronteira_webtc420_compatibilidade.py` possui 32 ensaios
     (8 ensaios adicionais além dos 24 de Fase 1, elevando a suíte de 851 para
     859 testes aprovados).
   - Documentação em `HISTORICO.md` e `VALIDACAO.md` constava na Fase 1 (851
     testes, com a proteção de `tc420/web.py` registrada como proposta aguardando
     decisão). `API.md` e `MODULOS.md` ainda não detalham `politica_http`.
3. Limitações e pendências técnicas identificadas e preservadas:
   - Sanitização de mensagem visual: widgets Tkinter (`interface/janela.py` e
     `interface/conexao.py`) ainda utilizam `str(erro)` em labels, o que pode
     expor parâmetros de URL em caso de `HTTPError` não sanitizado.
   - `TclError` legado na destruição de janelas Tkinter em fechamento concorrente.
   - Liberação física de sockets/descritores de nível de SO permanece com
     evidência desconhecida (apenas o encerramento contratual da aplicação é auditado).
   - Validação em hardware TC420 real e rede local física pendente de execução.

Verificações da etapa: `git diff --check` sem erros de whitespace, diretórios
`__pycache__` gerados por execuções sem `-B` foram limpos. Escopo da tarefa restrito
à análise diagnóstica e registro documental em `HISTORICO.md`. Sem commits ou push.

## 2026-10-22 — L3-B1.10: proteção das mensagens visuais de autenticação

Solicitação: executar a etapa do texto anexado, seguindo AGENTS.md, impedindo
exposição de URLs/dados de autenticação na interface sem alterar protocolo,
operações, autorizações ou ciclo de vida Tk. Escopo limitado a apresentação,
auxiliar, testes simulados e VALIDACAO/HISTORICO; sem teste físico, commit ou push.

Inspeção anterior à alteração confirmou P1 da L3-B1.7 no except de
JanelaConexao.conectar: a interpolação da exceção no label recebia falhas do
login e approval. Login automático e promoção já imprimiam apenas o tipo e
retornavam False/None, respectivamente; esses fluxos foram preservados.

Implementado interface/mensagens_seguras.py e substituída somente a interpolação
visual por sua classificação. Mensagens fixas distinguem timeout, conexão,
HTTP 401/403, demais erros HTTP, recusa de login/approval, resposta inválida e
falha inesperada. Prefixos RuntimeError conhecidos reconhecem a categoria sem
copiar o corpo; códigos seguros de infraestrutura/admissão mantidos por igualdade
exata. Não há regex, str/repr arbitrário, novo log ou mutação do erro original.
Console mantém o tipo; registro mantém identidades, categorias e publicações.

Criados 20 testes em tests/test_mensagens_seguras_http.py para os 16 cenários
e quatro críticos: URL com credenciais incorporadas/query, dados estruturados
em args/headers/Response, concorrência de dois logins e erro após destroy.
Quatro expectativas anteriores foram atualizadas: manual 02/03/04 e auditoria
HTTP 14 (antes exigia o vazamento, agora exige sua ausência). Os demais 856
ensaios anteriores não foram alterados. Marcadores sensíveis gerados em memória.

Verificações: `python -B -m unittest discover -s tests -q` aprovou **880 testes
simulados** em 5,430 s, incluindo os 860 anteriores adaptados conforme acima.
`git diff --check` sem erros de whitespace, com avisos LF/CRLF. O teste crítico D
reproduz o TclError legado após a publicação HTTP: apenas os dois acessos config
preexistentes (label e botão), nenhum agendamento adicional. Encerramento global
permanece não confirmado.

Resultado: L3-B1.10 concluída nos caminhos autorizados e em simulação. Detalhes,
mensagens e matriz de rastreabilidade em VALIDACAO.md. Nenhuma alteração nesta
etapa em tc420/web.py, executor, registros, TCP/UDP, eleição, guarda, reconexão
ou coordenador; mudanças prévias do working tree preservadas. Outros pontos
registrados sem correção: script diagnóstico independente com impressão de
token (não executado), print de erro do refresh PRINCIPAL e demais diagnósticos
de candidatura/comunicação/encerramento; saídas dinâmicas de IP/configuração
no sucesso não têm garantia geral de sanitização. Não se afirma sanitização
universal, liberação física ou cobertura global. Permanecem L3-B1.11, L3-B2,
composição/retentativas e revisão do encerramento Tkinter.

## 2026-10-22 — L3-B1.11: rea auditoria HTTP com ressalvas

Solicitação: reavaliar conjuntamente L3-B1.8/9/10, as três entradas suportadas,
fronteira WebTC420, mensagens/diagnósticos, origens e publicações; 16 cenários e
quatro críticas, preservando 880 regressões. Somente análise, teste simulado e
VALIDACAO/HISTORICO; AGENTS.md relido. Nenhuma mudança operacional autorizada.

Criado tests/test_reauditoria_http.py com 29 testes novos, helpers de simulação
reutilizados sem herança de classes de testes. Main/classes/funções reais por
AST e Requests real com adapter falso; sem Tk, persistência, equipamento ou rede
reais. Marcadores sensíveis gerados exclusivamente em memória, sem versionar
credenciais nem imprimir os marcadores capturados.

Confirmado: main.iniciar publica e propaga um dono/registro nos fluxos automático,
manual e promoção; ausência/inconsistência bloqueia autenticação; POST/GET exigem
reservas distintas e conservam o contexto. Fechamento entre POST/GET impede o
GET novo. Política acompanhada recusa chamada direta, outro objeto/operação/
thread e reuso; permissão expira antes da publicação, inclusive comprovada na
thread original. IDs/contextos estrangeiros são recusados; ID local isolado não
instala permissão. Preparação anterior ao leitor e geração do leitor mantêm
origens após novas gerações/mudança explícita de modo, sem apagar operações.
Parser/publicação bloqueados e publicação falha não confirmam resolução prematura.
Approval recusado e close falho preservam erros distintos; conclusão lógica não
prova liberação de descritores Requests. Modo independente mantém contrato fora
do registro, inclusive com o gate da infraestrutura observadora fechado.

Ressalvas comprovadas, sem correção nesta etapa:

- rede/servidor.py:278–294: worker PRINCIPAL recebe HTTPError real do adapter
  falso no refresh, imprime token da URL e conserva str(erro) em ultimo_erro.
  obter_saude_tc420 devolve esse dado em cópia consultável. Retrato HTTP CLIENTE
  continua sanitizado; não se comprovou envio remoto do campo de saúde.
- interface/janela.py:391–392: fonte de dados injetada que lança erro HTTP tem
  texto impresso. No main normal a fonte é obter_dados_atuais, não uma nova
  chamada web; callbacks de candidatura também têm prints arbitrários estáticos.
- Infraestrutura estrangeira completa: chamadas isoladas às três entradas aceitam
  uma segunda instalação coerente e publicam seis operações no segundo dono.
  A validação verifica coerência interna, sem referência independente de dono
  esperado. Registro estrangeiro incompatível é bloqueado, e main normal mantém
  o dono correto; a expectativa ampla “outra aplicação nunca executa HTTP” não
  foi satisfeita. Não foi observado HTTP sem registro nesse contraexemplo.
- Script independente imprime token/erro, apenas inspecionado por AST; saídas
  dinâmicas de configuração/IP e diagnósticos TCP/encerramento mantêm limites.

As propostas mínimas ficaram em VALIDACAO: mensagem/categoria fixa no console e
saúde do worker, sanitização dos prints de callbacks sem alterar Tk e, se exigido
para chamadas isoladas, origem esperada independente da infraestrutura recebida.
Nenhuma dessas propostas foi implementada. Não foram encontrados handlers de
logs persistentes nesses fontes; isso não exclui redirecionamento externo.

Classificação: entradas Cobertas no domínio main e Parciais no requisito amplo
de dono externo; instâncias acompanhadas Cobertas nos caminhos suportados;
apresentação/diagnósticos Parciais; recursos Requests Parciais no contrato público
e Indeterminados na liberação física. Auditoria realizada com ressalvas, sem
aprovação integral de todos os critérios. Os testes de achados aprovam quando
comprovam a limitação: não significam que ela foi corrigida.

Verificações: `python -B -m unittest discover -s tests -q` — **909 testes simulados
aprovados** em 6,457 s (29 novos + 880 anteriores sem alteração). As quatro
críticas passaram; todos os 16 cenários foram examinados, com ressalva explícita
no cenário de infraestrutura estrangeira completa. SHA-256 dos 28 fontes
operacionais/experimentais antes/depois idênticos. `git diff --check` sem erro de
whitespace, somente avisos LF/CRLF. Apenas teste novo e VALIDACAO/HISTORICO
alterados nesta rodada; working tree anterior preservado. Sem teste físico,
commit ou push. Cobertura/encerramento global, descritores físicos e TclError
continuam não confirmados/pendentes. Priorizar os achados antes de L3-B2.

## 2026-10-22 — L3-B1.12: diagnóstico seguro do refresh PRINCIPAL

Solicitação: eliminar exposição de token/URLs no console de ler_tc420 e em
saude_tc420[ultimo_erro], preservando falhas, estado de saúde, requisições e
responsabilidades do PRINCIPAL. Autorizados somente diagnóstico em servidor,
extração pura indispensável, testes e VALIDACAO/HISTORICO. AGENTS.md relido.

Inspeção confirmou a cadeia obter_estado → refresh → requests.get e o except
comum de Exception: str(erro) era armazenado sob lock e interpolado no console.
obter_saude_tc420 devolve cópia do diagnóstico; CHECK/SUBSCRIBE/descoberta usam
saudavel e não enviam ultimo_erro nos caminhos examinados.

Extraída a política pura para mensagens_seguras.py na raiz, separando categoria
e mensagem fixa. O adaptador interface/mensagens_seguras.py conserva
mensagem_erro_login(erro), assinatura e textos anteriores. Servidor importa o
módulo neutro, sem dependência de interface/Tk nem duplicação das regras.
O except calcula uma mensagem local por erro, grava essa mensagem sob o lock
existente e imprime a mesma variável. Args, request, response e exceção ativa
permanecem intactos; o worker continua tratando a falha sem relançamento como
antes. Contadores, transição de saúde, recuperação, intervalo e abandono mantidos.

Criados 20 testes em tests/test_diagnostico_refresh_seguro.py para os 16 cenários
e quatro críticos. Cobrem HTTPError real com token na query/userinfo, timeout,
conexão, 4xx/5xx, erro inesperado, cópia/atualização do diagnóstico, sucesso com
parâmetros GET originais, exceção ativa preservada, contrato da interface,
abandono no limite anterior e encerramento global negativo. Críticos: dois
destinos simultâneos, conteúdo estruturado com str/repr hostis, falha seguida
de recuperação e duas atividades concorrentes com mensagens locais e lock antigo.
Somente transporte, relógio, parada e dependências simulados; UUIDs efêmeros.

Uma adaptação justificada em test_reauditoria_http.py: teste 25 antes aprovava
quando comprovava o vazamento; agora exige ausência do token no console e saúde
e mensagem fixa para HTTP 401. Os demais 908 testes anteriores não mudaram.
Verificação: `python -B -m unittest discover -s tests -q` — **929 testes simulados
aprovados** em 7,545 s (20 novos + 909 anteriores com a adaptação descrita).
`git diff --check` sem erro de whitespace, somente avisos LF/CRLF.

SHA-256 comparado ao início: fontes anteriores alterados somente em
rede/servidor.py (diagnóstico e import), interface/mensagens_seguras.py
(adaptador) e teste 25 da rea auditoria; adicionados módulo neutro e teste novo.
Os outros 26 fontes operacionais/experimentais permaneceram idênticos. Não houve
alteração em tc420/web.py, protocolo, autorizações/registros HTTP, identidade da
infraestrutura, eleição/promoção, SUBSCRIBE/CONFIG/REGISTER, descoberta, guarda
ou coordenador. Mudanças preexistentes do working tree preservadas.

Resultado: L3-B1.12 concluída no escopo autorizado e nos testes simulados.
Demais diagnósticos fora do worker continuam com as limitações da L3-B1.11.
Identidade da infraestrutura fica para L3-B1.13 e rea auditoria final para
L3-B1.14; L3-B2 permanece posterior. TclError legado, liberação física e
encerramento global continuam pendentes/não confirmados. Sem teste físico,
commit ou push. Matriz e mensagens efetivas registradas em VALIDACAO.md.

## 2026-10-22 — L3-B1.13: viabilidade analisada, implementação pendente

Solicitação: comprovar infraestrutura esperada com âncora externa confiável nos
três fluxos, preservando identidade existente, múltiplas aplicações e origens.
O anexo condiciona a implementação à compatibilidade e determina documentar e
interromper a ampliação se necessário mudar a arquitetura pública das entradas
ou criar novo proprietário. AGENTS.md relido.

Revisados main.iniciar, automático, fábrica/closure de promoção, JanelaConexao,
instalação conjunta da infraestrutura, seu validador, contexto de aplicação,
registro de tentativas e testes L3-B1.8/9. A identidade existente pode ser
reutilizada, mas não há referência esperada independente disponível nos três
contratos públicos: automático é função de módulo, janela conserva atributo
recebido e promoção captura o argumento da montagem do leitor. O registro de
tentativas é independente e não possui vínculo prévio com o dono CLIENTE.

Criado somente tests/test_viabilidade_ancora_http.py, com seis caracterizações:
A/B internamente coerentes são aceitas; automático/promoção aceitam B junto de
registro de tentativas sem vínculo de dono; janela construída com A aceita troca
do atributo para B antes do login; troca privada controlada de registro de
recursos não é detectada pelo validador HTTP; troca de registro HTTP já é recusada.
Os envios são acompanhados em B, não HTTP sem registro. Aprovar esses testes
comprova as lacunas, não sua correção.

Resultado: **análise de viabilidade concluída; L3-B1.13 não implementada nem
aprovada**. Não adotada comprovação circular nem comparação de dois argumentos
livres. Documentada em VALIDACAO a proposta de entradas vinculadas por main a
referências estáveis da instalação existente, sem novo UUID/proprietário, e
com captura local do dono validado. É necessário delimitar o contrato público
de montagem dessas entradas e a migração dos consumidores isolados. Tornar o
registro de tentativas um comprovante também criaria um vínculo de bootstrap
que hoje não existe; seu significado não foi alterado nesta rodada.

Por essa condição de escopo, nenhuma implementação operacional ou ampliação
arquitetural foi feita. Alterados apenas teste novo, VALIDACAO/HISTORICO.
Os 16 cenários de aceitação, as quatro corridas e o teste adicional exigindo
recusa da comprovação circular continuam pendentes da implementação. Não foram
contabilizados como aprovados pelos testes de caracterização.

Verificações: `python -B -m unittest discover -s tests -q` aprovou **935 testes
simulados** em 8,393 s (seis novos + 929 anteriores intactos). SHA-256 dos 29
fontes operacionais/experimentais antes/depois idênticos. `git diff --check` sem
erro de whitespace, somente avisos LF/CRLF. Working tree preexistente preservado.
Sem teste físico, commit ou push. L3-B1.14/L3-B2 não liberadas por esta análise;
TclError, diagnósticos fora da sanitização já implementada, liberação física e
encerramento global continuam pendentes/não confirmados.

## 2026-10-22 — L3-B1.13-A: montagem de entradas HTTP vinculadas

Solicitação: implementar a decisão arquitetural limitada autorizada no anexo:
main.iniciar captura a instalação original, sem novo proprietário/UUID/singleton,
e vincula automático/manual/promoção; consumidores isolados conservam contrato
explícito sem alegação de propriedade externa. AGENTS.md relido. A autorização
supera a condição de parada da análise de viabilidade anterior.

Adicionado rede/entradas_http.py com VinculoEntradasHttp frozen, capturando
infraestrutura, instalação, contexto, HTTP, recursos, retentativas e aplicacao_id
existentes. Sua validação exige referências originais e coerência interna; B
coerente, ID nominal igual ou registro substituído não comprovam pertencer a A.
vincular devolve closure cuja autoridade prevalece sobre keywords ou atributos
públicos apresentados pelo consumidor. Sem estado global de aplicação ou nova
identidade, e sem inferir propriedade de registros vazios ou threads.

main.iniciar monta os três caminhos pelo vínculo capturado após a instalação.
Automático usa referência validada local; janela guarda validador separado do
atributo público e usa resultado local; promoção captura infraestrutura e origem
do leitor antes do POST e mantém contexto no GET. Keyword de montagem aditivo
vinculo_http=False preserva argumentos antigos. Modo isolado (default/False)
exige infraestrutura válida, registro, reserva e autorização existentes, sem
prova de proprietário externo. None/vínculo inválido ou incompleto não causam
fallback isolado: falha antes de Web, com False/None/status seguro e botão normal.
RegistroTentativasAplicacao e guarda não precisaram mudar.

Criados 23 testes em test_entradas_http_vinculadas.py: 16 cenários, quatro corridas,
adicional B coerente/troca de recursos nos três caminhos e dois complementos de
imutabilidade/autoridade e sanitização. Corridas comprovaram referência local A
durante troca de atributo para B, origem de promoção conservada após nova geração,
duas aplicações simultâneas e gate fechado após validar sem requisição.

Preservados e ampliados os seis testes de caracterização: aceitação isolada
continua permitida, mas cada teste agora exige recusa no contrato vinculado.
Três testes antigos de AST/montagem adaptados em auditoria_http_arquivos (11),
entradas_http_suportadas (15) e registro_promocoes (22), para observar referência
local e propagação do vínculo; helper criar_janela aceita keywords de montagem.
Nenhum teste excluído. São nove testes anteriores ampliados/adaptados; os demais
926 mantêm expectativas. A aceitação do modo isolado não é tratada como proteção
externa e a caracterização original permanece visível.

Verificação final: `python -B -m unittest discover -s tests -q` — **958 testes
simulados aprovados** em 8,625 s (23 novos + 935 anteriores). `git diff --check`
sem erros de whitespace, apenas avisos LF/CRLF. SHA-256: apenas main.py e
interface/conexao.py mudaram entre os 29 fontes operacionais/experimentais
preexistentes; outros 27 idênticos. Acrescentados módulo de vínculo e teste;
cinco arquivos de testes anteriores adaptados, além de VALIDACAO/HISTORICO.
Working tree anterior preservado.

Resultado: L3-B1.13-A implementada e aprovada nos caminhos autorizados/simulados.
Sem alteração em WebTC420, executor HTTP, registros, protocolos, descoberta,
eleição, guarda, tentativas ou mecanismos de encerramento. Não há prova contra
manipulação arbitrária de atributos privados/closures Python, liberação física
ou encerramento global. Entradas isoladas, diagnósticos fora do escopo e TclError
continuam com os limites documentados. Próximo marco L3-B1.14 antes de L3-B2.
Sem teste físico, commit ou push.

## 2026-10-22 — L3-B1.14: auditoria HTTP conjunta e lacunas de mutação

Solicitação: auditar conjuntamente propriedade, imutabilidade, admissão,
autorizações, publicação e diagnósticos; 16 cenários/cinco verificações críticas,
preservando os 958 testes e todos os módulos operacionais. AGENTS.md relido.
Somente inspeção, teste novo e VALIDACAO/HISTORICO foram alterados nesta rodada.

Criado tests/test_auditoria_final_http.py com 29 ensaios integrados e de achados.
Main/entradas reais por AST, infraestrutura/autorizações reais e Requests com
adapter falso. GUI/persistência/threads operacionais falsas, concorrência somente
no harness com esperas limitadas e marcadores sensíveis efêmeros, sem credenciais
versionadas ou impressas. Helpers anteriores reutilizados, sem herdar testes
ou executar seus corpos como novos testes.

Comprovado nos caminhos usuais: main captura autoridade e monta três entradas;
POST/GET têm reservas distintas ativas antes do envio, origem legítima e publicação
após parse. B coerente/ID nominal igual e registros substituídos antes de validar
são recusados; atributo público da janela não substitui autoridade. Gate entre
validar/reservar e entre POST/GET continua obrigatório; POST falho não provoca GET.
Objeto/operação/thread/uso único e expiração antes de publicar foram verificados
em conjunto com a montagem vinculada. Parser/publicação suspensos e publicação
falha não confirmam resolução antecipada. IDs/histórico/origens conservados após
nova geração e mudança explícita de modo na simulação.

Achados reproduzidos, sem correção:

- M1, rede/entradas_http.py:11–55: frozen bloqueia atribuição normal, mas
  vars(vinculo) fornece alias gravável de __dict__. Substituir o snapshot pelos
  campos de outro vínculo faz a mesma closure A aceitar B e registrar em B.
- M2, rede/infraestrutura_cliente.py:69–150 e consumo local em conectar: após
  validar A, alteração controlada de vars(A)[_instalacao] para instalação B
  migra POST/GET ao registro B. Política continua apontando para A e registro
  A original fica vazio. Referência local ao objeto não fixa seu conteúdo;
  properties relêem a instalação ao preparar contexto/reservar/executar.

Esses testes exigem acesso às estruturas internas e sincronização controlada
no harness; não demonstram ataque remoto nem mutação oferecida por setter
público normal. As requisições migradas continuam reservadas/publicadas em B:
o achado é violação do proprietário esperado, não HTTP sem qualquer registro.
Menores correções propostas em VALIDACAO: retirar alias gravável do snapshot e
fixar instalação/registros durante preparar/reservar/executar, conferindo dono
no ponto de uso. Só repetir validação não elimina a janela. Nenhuma implementada.

Diagnósticos corrigidos CLIENTE e worker refresh PRINCIPAL permaneceram seguros
para o mesmo HTTPError sensível; exceção original preservada, sem atribuir refresh
ao CLIENTE. Callback genérico atualizar_refresh_web ainda imprime erro de fonte
injetada (teste 29), distinto do worker corrigido. Outros prints de candidatura,
TCP/encerramento e script independente continuam documentados, sem alterações.
Modo independente e isolado conservam seus limites explícitos. Operação resolvida
com close falho não foi convertida em prova física; TclError legado separado.

Classificação consolidada em VALIDACAO: propriedade/imutabilidade Parciais;
admissão Coberta no registro utilizado, com ressalva de identidade sob migração;
autorização Coberta nos caminhos acompanhados; publicação Coberta no contrato
lógico; diagnósticos Parciais; recursos Requests Parciais no contrato público e
Desconhecidos no físico; encerramento global Não confirmado.

Verificação: `python -B -m unittest discover -s tests -q` — **987 testes simulados
aprovados**, 10,857 s (29 novos + 958 anteriores intactos). Executados os 16
cenários e cinco críticas; testes de M1/M2 aprovam ao detectar lacunas, não sua
correção. SHA-256 dos 69 fontes Python anteriores idênticos, incluindo todos os
30 operacionais/experimentais e testes anteriores. `git diff --check` sem erro
de whitespace, avisos LF/CRLF. Working tree preexistente preservado.

Resultado: L3-B1.14 concluída como auditoria com achados. Não declarada proteção
integral contra mutações nem liberação automática de L3-B2. Priorizar estabilidade
da autoridade/instalação antes de avançar. Sem teste físico, commit ou push.

## 2026-10-22 — L3-B1.15: autoridade e instalação HTTP estabilizadas

Solicitação: corrigir M1/M2 da auditoria final, eliminando aliases mutáveis do
vínculo e migração dos registros após validar, sem novo proprietário/UUID,
registro, permissões, lock global ou alteração do executor/protocolo. AGENTS.md
relido. Escopo: vínculo, integração estritamente necessária à seleção da
instalação, testes e VALIDACAO/HISTORICO.

VinculoEntradasHttp passa a frozen com slots, sem __dict__ ou alias por vars.
Na infraestrutura, adicionada _ReferenciasHttp frozen com slots, contendo os
objetos originais de instalação/contexto/HTTP/recursos/retentativas e ID existente.
_InstalacaoCliente e InfraestruturaRegistrosCliente também não têm dicionário de
instância. Não se criam registros nem identidades: somente referências fixadas.

Getters usados para preparar contexto e escolher registros retornam os objetos
fixados, sem reler _instalacao. Validador reforçado recusa divergências entre
instalação/contexto apresentados e referências originais. Troca antes de validar
é recusada; troca forçada após validar não redireciona a operação em curso, que
permanece em A. Campos internos da instalação/contexto também são alterados nos
ensaios, sem redirecionar POST/GET para B. O estado operacional dos registros
continua mutável, como necessário; suas referências é que ficam fixadas.

Integração limitada a construção/seleção/validação em infraestrutura_cliente.py.
Corpo/assinaturas/responsabilidades do executor, reservas, autorizações e publicação
não foram modificados. Não foi necessário ampliar contrato interno do executor.
Entradas isoladas válidas e WebTC420 independente mantêm contratos; main e
interfaces não mudaram nesta etapa. Não se promete defesa geral contra código
Python que reescreva arbitrariamente todos os slots privados ou métodos.

Criado test_autoridade_http_estavel.py com 26 testes: 16 cenários, cinco críticos,
adicional anticircular e complementos de parser, publicação falha, campos internos
após validar e troca entre POST/GET. Corridas cobrem instalação B após validação,
aliases bloqueados, promoção/nova geração, A/B simultâneas e gate fechado antes
da reserva. Sem rede/equipamento/Tk/persistência reais; esperas limitadas.

Oito testes anteriores adaptados, nenhum removido: auditoria_final_http 09/18
agora exigem eliminação dos escapes; 06/07 usam object.__setattr__ como instrumento
de teste porque vars(infraestrutura) não existe mais; 05 e entradas_vinculadas 09
constroem B com ID nominal igual desde a origem por UUID falso no harness;
entradas_vinculadas 21 e viabilidade 05 exigem recusa da troca de recursos pelo
validador reforçado. Os demais 979 anteriores mantêm expectativas. Explicação
completa e matriz em VALIDACAO.

Verificações: `python -B -m unittest discover -s tests -q` — **1013 testes simulados
aprovados** em 8,826 s (26 novos + 987 anteriores com oito adaptações justificadas).
`git diff --check` sem erro de whitespace; avisos LF/CRLF. SHA-256: apenas
rede/entradas_http.py e rede/infraestrutura_cliente.py mudaram entre os 30 fontes
operacionais/experimentais; outros 28 idênticos. Três arquivos de testes antigos
adaptados e teste novo, além de VALIDACAO/HISTORICO. Working tree anterior mantido.

Resultado: L3-B1.15 concluída nos caminhos autorizados e nas simulações. M1/M2
corrigidos pelos mecanismos examinados; sem autorização para concluir segurança
universal do processo Python, liberação física ou encerramento global. Próxima
etapa: verificação direcionada dos dois escapes antes de L3-B2. TclError e demais
diagnósticos pendentes continuam separados. Sem teste físico, commit ou push.

## 2026-10-23 — L3-B2-A: análise e delimitação dos arquivos locais

Solicitação: retomar L3-A e executar somente análise de arquivos, proposta mínima,
testes simulados e VALIDACAO/HISTORICO, preservando 1013 regressões. Confirmado
planejamento: .exe apenas após desenvolvimento, confiabilidade e validações,
sem empacotamento nesta rodada. AGENTS.md relido; nenhum fonte operacional mudou.

Inventário real: dois pontos de open no mesmo configuracao.json, em
carregar_configuracao (r/UTF-8/with/json.load) e salvar_configuracao
(w/UTF-8/with/json.dump). Leitura chamada por automático, credenciais de promoção
e construção da janela; escrita manual após login/approval e antes do PRINCIPAL.
Dados pertencem à aplicação; handles são temporários por operação, normalmente
fechados antes da transição. Não há arquivo aberto persistente por geração.
Close falho/operação bloqueada pode continuar pendente e justifica acompanhar
cada abertura real, sem criar recurso durável fictício.

PhotoImage dos dois assets é fronteira Tk, sem arquivo Python entregue; keyring
é backend não examinado. Makefiles de CONFIG/REGISTER/SUBSCRIBE são arquivos de
socket já classificados, não novos arquivos locais. Consulta de caminho/isfile
não é handle. Não encontrados novos arquivos explícitos temporários/log/SQLite
ou corpo HTTP em disco nos fontes; não é inventário universal de dependências.
Nenhuma configuração real, imagem ou credencial foi lida.

Proposta: contexto explícito de preparação de arquivos, capturado pela composição
na infraestrutura existente, com origem positiva anterior ao leitor; mesmo
registro_recursos de main e ID por open. Reservar antes de abrir, associar antes
de ler/escrever, fechar e exigir closed is True, preservando erros separados e
recursos antigos. Não criar leitor/retentativa/HTTP fictícios nem geração atual
retroativa. Registro não tem escopo de aplicação com None: se esse escopo for
exigido, definir contrato antes da integração. Nenhuma instrumentação instalada.

Achado F1: with atual pode substituir o erro de leitura/escrita por falha de
close. Teste real de leitura com ValueError e close RuntimeError reproduz a
substituição, com original em __context__. O modelo proposto preserva erro
primário e registra cleanup separadamente; não se afirma que a função operacional
já foi corrigida. Próxima integração precisa explicitar essa precedência e o
contrato de recusa de admissão, pois leituras em main/construtor antecedem o
tratamento HTTP. Caminhos, formatos, conteúdo, codificação e permissões mantidos.

Criado test_delimitacao_arquivos_locais.py com 25 ensaios: comportamento real de
open/with/JSON por fakes, inventário AST e modelo apenas no harness usando o
registro existente. Cobrem falha antes/depois de adquirir, aquisição sem handle,
leitura/escrita/close, closed falso, concorrência, publicação tardia e quatro
corridas: abertura/encerramento, fechamento/consulta, promoção com arquivo pendente
e limpeza durante outra exceção. Recurso antigo não desaparece com nova geração;
registro resolvido não confirma cobertura global. Não houve arquivo de dados,
Tk, keyring, rede ou hardware reais. Escrever em memória não prova atomicidade
ou ausência de corrupção em duas escritas concorrentes reais.

Verificações: `python -B -m unittest discover -s tests -q` — **1038 testes simulados
aprovados** em 10,447 s (25 novos + 1013 anteriores sem adaptação). SHA-256 dos
71 fontes Python anteriores idênticos, incluindo os 30 operacionais/experimentais.
Somente teste novo e VALIDACAO/HISTORICO alterados. `git diff --check` sem erro
de whitespace, avisos LF/CRLF. Working tree preexistente preservado. Sem teste
físico, commit ou push.

Resultado: L3-B2-A concluída como análise/delimitação; instrumentação real dos
arquivos e L3-B2 completa pendentes. Matriz e dependências em VALIDACAO. Sequência
mantida: instrumentação, auditoria consolidada, atividades/guarda, composição,
Tk/encerramento e validações finais; .exe apenas na entrega posterior. Cobertura
global, liberação física, TclError e demais pendências não foram encerrados.

## 2026-10-23 — L3-B2-B: configuração local acompanhada e precedência de erros

Solicitação: instrumentar os dois open de configuracao.json identificados na
L3-B2-A, reutilizando o registro de main.iniciar, com identidade por abertura,
proprietário aplicação e erros de operação/limpeza preservados. Escopo limitado
à persistência, passagem mínima de contexto, auxiliar, testes e VALIDACAO/HISTORICO.
Sem teste físico, commit, push ou empacotamento.

Confirmados carregar_configuracao (r/UTF-8/json.load) e salvar_configuracao
(w/UTF-8/json.dump), mesmo caminho derivado da raiz pelo __file__. Mantidos
campos, conversões de porta/salvar_login, indent=4, ensure_ascii=False, sobrescrita,
defaults de permissões, retornos e política de configuração ausente/inválida.
Não introduzidos temporário, backup, escrita atômica, fsync ou lock de dados.

Criado config/arquivos.py com executar_arquivo e ContextoArquivosConfiguracao.
main.iniciar prepara um contexto na infraestrutura existente e o encaminha ao
automático, à closure de promoção e à janela manual (leitura inicial/escrita na
conexão). Contexto captura o mesmo registro_recursos e seu proprietário; não
constrói outro registro. Cada abertura recebe uma preparação positiva distinta
pelo alocador existente, sem leitor/retentativa/HTTP fictícios. O campo legado
geracao_id é origem da preparação, não propriedade de uma geração de leitor.
Arquivos permanecem da aplicação inclusive quando o papel muda para PRINCIPAL.

Reserva arquivo_comum anterior ao open, associação antes do JSON e fechamento
individual exigindo close retornado e closed is True. Operação recusada após
gate ainda executa cleanup do handle já aberto. Ausência comprovada somente se
a fábrica não executou; exceção de open sem handle conserva criação desconhecida.
Handle devolvido mas não associado fica retido no contexto e recebe tentativa
de close direto, sem inventar publicação/evidência no registro. Se associado,
limpeza usa o registro existente. Pendências públicas contêm IDs/categorias e
observação de closed, sem caminho/conteúdo/texto de exceção. Não foi adicionada
recuperação automática de pendências ou integração do coordenador.

Corrigido F1: o auxiliar substitui with nos dois pontos para preservar a mesma
instância e traceback do primário com raise sem argumento. Falha de cleanup é
causa separada (__cause__) e mantém erro/estado conservador no registro/contexto.
Leitura continua tratando OSError/JSONDecodeError/ValueError como None, inclusive
quando o primário desses tipos vem acompanhado de falha de close de outro tipo;
isso corrige a precedência sem alegar limpeza bem sucedida. Escrita propaga o
primário com a causa de limpeza. Close isolado falho não é ocultado pelo auxiliar;
a leitura ainda aplica seu catch histórico quando cabível. Chamadas isoladas sem
contexto continuam compatíveis, sem alegação de registro/cobertura operacional.

Criado tests/test_arquivos_configuracao_integrados.py: 32 testes novos. Cobrem os
16 cenários, quatro corridas (abertura/encerramento, close/consulta,
leitura/escrita simultâneas e primário/cleanup), publicação falha antes/depois de
associar, observação pendente após close retornar, histórico/arquivo antigo após
promoção, validação antes de abrir e integração de main/automático/manual/promoção.
Simulados PhotoImage, Keyring e socket/makefile para excluir identidades fictícias
ou duplicação. Persistência real executada com arquivos em memória e dependências
substituídas; interfaces/main por AST, transporte e threads de servidor falsos.
Nenhum dado persistido, backend de credenciais, Tk, equipamento ou rede reais.

Preservadas as 1038 regressões com adaptações justificadas em seis módulos:
test_registro_automatico/test_auditoria_cobertura_http recebem o keyword no fake;
test_registro_promocoes verifica a passagem; test_entradas_http_suportadas verifica
o novo opcional sem mudar argumentos antigos; test_auditoria_http_arquivos_cliente
e test_delimitacao_arquivos_locais exigem o executor de escopo no lugar do with
literal. O antigo ensaio de F1 passa a exigir None pelo primário tratado e causa
de limpeza preservada. Nenhum teste removido; não houve passagem sem adaptações.

Verificação: `python -B -m unittest discover -s tests -q` — **1070 testes simulados
aprovados em 11,111 s**, 1038 anteriores + 32 novos. Comparação SHA-256 dos 72
fontes Python preexistentes: alterados apenas config/configuracao.py, main.py,
interface/conexao.py e seis módulos de testes; outros 63 idênticos. Dois fontes
novos: auxiliar e teste integrado. Protocolos TCP/UDP, HTTP/WebTC420, eleição,
registro de retentativas e coordenador preservados; working tree anterior mantido.
configuracao.json não foi alterado nesta rodada. VALIDACAO atualizada com matriz,
composição efetiva, precedência, provas, testes e fronteiras; histórico registrado.
`git diff --check` sem erro de whitespace, com avisos LF/CRLF do working tree.

Resultado: L3-B2-B concluída no escopo suportado por main.iniciar. Cobertura global,
encerramento e liberação física permanecem não confirmados. Auditoria consolidada,
atividades/guarda, composição, Tk/TclError e validações finais continuam pendentes.
Não há certificação de durabilidade ou concorrência no disco a partir de StringIO.
Executável continua reservado à etapa de entrega; sem empacotamento antecipado.

## 2026-10-23 — AC1: auditoria consolidada de recursos, operações e atividades

Solicitação: percorrer os caminhos reais a partir de main.iniciar, consolidar
TCP/UDP, HTTP, configuração local, gerações e atividades; executar 16 cenários e
cinco verificações críticas e identificar pontos de integração da guarda, sem
alterar módulos operacionais. Somente inspeção, teste novo e VALIDACAO/HISTORICO.
Sem teste físico, commit, push ou empacotamento.

Matriz consolidada adicionada a VALIDACAO com classificações Coberto, Parcial,
Desconhecido e Não aplicável, separando recursos (handles), operações HTTP e
atividades. Confirmados SUBSCRIBE, CONFIG e REGISTER, inclusive sockets de
tentativas internas por endereço, makefiles com identidade própria e transferência
sem duplicação; descoberta UDP/CHECK TCP nos ramos de preparação, leitor,
candidatura e promoção. Provas de socket continuam contratuais; arquivos exigem
close retornado e closed is True, sem inferência por término de thread.

Reutilizadas as auditorias L3-B1.14/B1.15 e suas regressões: montagem vinculada à
aplicação, referências originais, reservas antes de POST/GET, autorização de uso
único, origem e parse completo de approval antes da publicação. Novos ensaios
unem essas operações à configuração local na mesma infraestrutura. HTTP resolvido
não comprova sockets internos Requests/urllib3 nem término de atividades. Modo
independente WebTC420 e consumidores isolados permanecem contratos separados.

Confirmada preservação de recursos antigos na promoção operacional. Identificado
que modo_atual ainda não recebe transição pelos fluxos operacionais, embora as
APIs promover dos registros existam; o teste do harness não foi apresentado como
integração real dessa transição. Refresh/listeners/handlers/trabalhadores do
PRINCIPAL permanecem sob seus contratos próprios, sem recursos fictícios CLIENTE.

Localizados pontos para AC2: LeitorDadosServidor.iniciar/_manter_atualizado e
registrar_falha_recuperacao/_aguardar_proxima_tentativa partem threads sem reserva
na guarda; candidatura/reconexão são fases do loop, não threads artificiais.
Observadores da aplicação podem criar leitores após rebaixamento. parar sinaliza
_parada, faz shutdown/close do socket SUBSCRIBE, mas não comprova término de
threads nem fechamento do arquivo associado. Matriz registra criação, origem,
admissão, execução, recursos, finalização, reconexão, promoção, parada e lacuna.
Guarda, composição e coordenador não foram integrados nesta auditoria.

Novo achado **AC1-F1**: o contexto de arquivos retém handles não associados somente
enquanto o próprio contexto permanece alcançável. A infraestrutura é referenciada
pelo contexto, mas não o retém. Teste 27 executa main real por AST: open falso
devolve handle, publicação falha antes da associação, close também falha e main
sai por exceção. Mantendo a infraestrutura viva, após liberar a pilha e coletar
ciclos, weakref do fake sem __del__ não encontra mais o handle; a identidade no
registro continua não resolvida e sem prova de limpeza. É perda de retenção, não
prova de fechamento físico. Os testes B2-B mantinham o contexto vivo.

Menor proposta registrada, sem implementar: reter o contexto no proprietário da
aplicação antes de abrir, com consulta sanitizada às pendências, reutilizando o
registro e preservando a responsabilidade da aplicação. A classificação local
foi revisada para Parcial; a instrumentação normal permanece efetiva, mas falta
resolver esse caminho excepcional antes de cobertura integral dos arquivos.

Também reproduzidos diagnóstico genérico da descoberta que imprime texto do erro
e callback atualizar_refresh_web cujo after fora do try lança TclError em root
falsa destruída. Mensagens HTTP tratadas e retratos sanitizados não equivalem a
segurança de todos os logs. Propostas mínimas: mensagens controladas genéricas e
tratamento/cancelamento de callbacks em AC4; nada corrigido operacionalmente.

Criado tests/test_auditoria_consolidada_ac1.py com **28 testes novos**. Cobrem os
16 cenários e verificações A–E: promoção com pendências; HTTP/configuração
concorrentes; publicação falha após alocação; recursos fechados com atividade sem
término; consulta enquanto thread criadora terminou e cleanup ainda está em curso.
Complementos reproduzem falta de guarda, parar sem término, metadados, diagnóstico,
TclError simulado, refresh PRINCIPAL e perda de retenção após saída de main.
Fontes reais com sockets, arquivos de dados, Tk, transporte HTTP e partidas de
servidor falsos; sem equipamento, rede/DNS, keyring ou persistência reais. GC/weakref
são apenas evidência de retenção do fake, sem depender de finalizador de arquivo.

Verificações: `python -B -m unittest discover -s tests -q` — **1098 testes simulados
aprovados em 12,324 s**, 28 novos e 1070 anteriores sem adaptações. SHA-256 dos
90 arquivos preexistentes inventariados, incluindo 74 fontes Python: somente
VALIDACAO/HISTORICO alterados; fontes/testes anteriores e configuracao.json
idênticos. Único fonte novo: teste AC1. Working tree anterior preservado.
`git diff --check` sem erro de whitespace, com avisos LF/CRLF.

Resultado: **AC1 concluída como auditoria com lacunas documentadas**. TCP/UDP e
HTTP cobertos nos caminhos/contratos delimitados; arquivos locais e atividades
Parciais; descritores internos Requests/OS Desconhecidos; domínio PRINCIPAL
separado; diagnósticos Parciais. Encerramento global e cobertura completa continuam
não confirmados. Infraestrutura.avaliar continua fornecendo cobertura incompleta
de recursos/guarda sem compor HTTP; retrato HTTP também não confirma global.
Sequência AC2/AC3/AC4/AC5 preservada, com AC1-F1 pendente de correção delimitada:
guarda, composição, callbacks/Tk, coordenador; depois testes físicos e executável.

## 2026-10-23 — AC1-F1: retenção estável de arquivos e cleanup explícito

Solicitação: priorizar a correção do handle de configuracao.json perdido após
associação/close falharem e main sair, antes de AC2. Preservar formatos/protocolos,
erros originais e estado conservador; sem integrar encerramento, guarda ou Tk.

Confirmada a causa: _pendentes pertencia ao contexto local de main, enquanto a
infraestrutura não retinha esse contexto. Registro já conservava identidade
desconhecida, mas, antes da associação, não possuía o objeto para cleanup futuro.

Alterados somente os pontos operacionais necessários em config/arquivos.py e
rede/infraestrutura_cliente.py. O construtor do contexto agora o vincula à
infraestrutura antes de operações. Proprietário mantém contextos privados sob
lock próprio, com inclusão idempotente por instância e consulta sanitizada às
pendências; não cria proprietário global ou outro registro. main continua usando
o mesmo contexto que já construía; não precisou de alteração em main.py.

Cada reserva prepara célula/índices de responsabilidade antes de open. Falha nessa
preparação impede alocação e permite ausência por não execução comprovada. Após
open, a guarda normal tenta reter o handle; se lança, o caminho compensatório usa
a célula já alcançável, preserva o erro de retenção e tenta cleanup do mesmo objeto.
Sem lock durante open, JSON, close ou observação. Fases abertura/uso/limpeza
recusam cleanup explícito concorrente nesses intervalos.

Retenção só resolve depois de close/evidência suficientes e publicação local
concluída; closed falso/indisponível, close falho ou publicação interrompida
mantêm a referência. Handle associado usa prova publicada do registro; handle
não associado pode comprovar fechamento no contexto, sem fabricar associação ou
ausência no registro. Assim a retenção pode resolver enquanto a identidade de
criação ambígua e erros históricos permanecem conservadores. Consulta durante
publicação vê conclusão local falsa mesmo se close já retornou.

Infraestrutura expõe consulta de contextos próprios/pendências e uma tentativa
síncrona explícita por recurso_id. Mesmo objeto, identidade e proprietário para
cleanup posterior, sem nova reserva/open. Histórico do contexto guarda metadados
sanitizados e libera sua referência após resolução comprovada. Sem tentativa
automática no encerramento, loop indefinido, thread permanente ou timeout de
descarte; essa API não é chamada pelo Tk/coordenador. Registro público inalterado.

Precedência de erros preservada: operação primária mantém instância/traceback,
cleanup em causa separada; anotação falha adicionalmente encadeia o terceiro erro
ao cleanup sem apagar os anteriores. Leitura conserva None para erros já tratados;
escrita propaga o primário. Caminho/UTF-8/JSON/campos/sobrescrita/retornos intactos.

Criado test_retencao_arquivos_aplicacao.py com 29 ensaios: 16 cenários e cinco
verificações A–E, retenção após liberar pilha/GC, duas operações concorrentes,
promoção durante cleanup, compensação de guarda falha, publicação pendente, três
erros, falha antes de open, close durante uso recusado e retratos sem texto sensível.
O cenário E comprova falha controlada da guarda com compensação disponível; não
certifica retenção sob interrupção do processo/intérprete ou falha que impeça
também escrever/adquirir lock da célula compensatória. Limites explícitos em
VALIDACAO, sem afirmar que esses casos não ensaiados foram aprovados.

Mantidos os 1098 testes anteriores, adaptando três expectativas em dois módulos:
B2-B teste 08 e AC1 teste 18 passam a reconhecer prova local após close
compensatório, mantendo registro desconhecido; AC1 teste 27 preserva a reprodução
original com main por AST, associação e close falhos, mas exige referência viva
pela infraestrutura e cleanup posterior no mesmo objeto. Nenhum teste removido.

Verificação: `python -B -m unittest discover -s tests -q` — **1127 testes simulados
aprovados em 22,121 s**, 29 novos + 1098 regressões. SHA-256 dos 91 arquivos
preexistentes, incluindo 75 fontes Python: alterados somente os dois fontes
operacionais de retenção, dois módulos de testes e VALIDACAO/HISTORICO; outros
71 fontes Python idênticos. Um teste novo. main.py, config/configuracao.py e configuracao.json,
WebTC420/executor HTTP, protocolos, descoberta, eleição, guarda, Tk e coordenador
preservados. Dados, rede/DNS, Keyring, Tk e equipamento reais não acessados;
weakref/GC apenas verificam retenção dos fakes, sem alegar fechamento físico.
`git diff --check` sem erro de whitespace, com avisos LF/CRLF do working tree.

Resultado: AC1-F1 corrigido no contrato delimitado. Matriz acumulada atualizada:
arquivos locais Cobertos nesse recorte, mantendo os limites de criação ambígua,
consumidores isolados e falha da própria compensação. Cobertura global/encerramento
não confirmados. Próxima etapa AC2; modo_atual, callbacks/TclError, composição,
coordenador e validações finais continuam pendentes. Working tree anterior
preservado. Sem teste físico, commit, push ou empacotamento.

## 2026-10-23 — AC2-A: admissão e partida da retentativa de recuperação

Solicitação: mapear as partidas reais, comparar com a guarda experimental e
integrar somente reserva/partida nos caminhos compatíveis, mantendo término,
recursos e encerramento para AC2-B/C e etapas posteriores. Leitura prévia do
protótipo, infraestrutura e matriz AC1; contrato de recusa documentado em
VALIDACAO antes de alterar o comportamento do caminho isolado.

Delimitado registrar_falha_recuperacao → Thread/_aguardar_proxima_tentativa como
única partida de retentativa desta rodada. iniciar/_manter_atualizado permanece
thread permanente, reconexão comum/_aguardar_candidatura são fases síncronas,
não novas threads. Observadores da aplicação e threads PRINCIPAL fora do escopo.

RecursosLeitorCliente conserva o token opaco da geração já criada. Leitor monta
PartidasRetentativasCliente, novo auxiliar de rede, capturando proprietário,
guarda e geração originais. Não constrói guarda por retry nem usa modo_atual ou
geração nova para reatribuir tentativas antigas. Nenhuma assinatura pública mudou.

Após os critérios/limite existentes, reservar antes de construir/start. Recusa
retorna False sem thread; leitor isolado sem proprietário também recusa, em vez
de criar guarda implícita. iniciar do leitor isolado continua compatível. Guarda
partir é reutilizada sem alterações; fábrica e start fora de locks da guarda e
da candidatura. Proxy retém/delega thread real e marca invocação antes de start.
Falha comprovada anterior à invocação usa comprovar_nao_execucao; falha de start
nunca usa is_alive nem presume ausência. Erro original preservado, inclusive se
a comprovação adicional falhar. Falha de confirmação após partida não apaga
o start conhecido nem confirma término.

Gate fechado antes da reivindicação de partir cancela sem fábrica. Partida já
reivindicada antes do fechamento pode concluir depois, permanecendo identificada;
não equivale a admissão nova após recusa. A guarda já observa entrada/retorno no
wrapper existente, mas observar_termino_thread/join/cleanup/secundárias não foram
integrados. Identidades de recursos não foram renumeradas nem associadas a retries
por coincidência de números. AC2-C fará essa vinculação explicitamente.

Criado test_partidas_retentativas_cliente.py com 30 testes: 16 cenários, corridas
A–E e socket pendente independente da partida. Cobrem dois starts/gerações,
recusa, construção falha, start ambíguo com entrada antes/depois da exceção,
publicação tardia, promoção durante partida, concorrência com um start falho,
gates em ambas as ordens, rotina real com relógio/descoberta falsos e montagem
real de main por AST. Sem rede/DNS, Tk, dados persistidos, credenciais ou hardware.

Adaptados três testes antigos de caracterização nos módulos de auditoria de
cobertura, auditoria consolidada AC1 e responsabilidades: agora verificam partida
registrada sem término ou recusa isolada sem proprietário, em vez de exigir o
comportamento corrigido de retry sem guarda. Nenhum teste removido; invariantes
de recursos pendentes e global negativo preservadas.

Verificação: `python -B -m unittest discover -s tests -q` — **1157 testes simulados
aprovados em 12,815 s**, 30 novos + 1127 regressões. SHA-256 dos 92 arquivos
preexistentes, incluindo 76 fontes Python: somente leitor, token na infraestrutura,
três módulos de teste e VALIDACAO/HISTORICO alterados; outros 71 fontes Python
idênticos. Dois fontes novos: auxiliar de partidas e teste. Protótipo da guarda,
TCP/UDP, eleição, registros de recursos, HTTP, JSON, AC1-F1, Tk e coordenador
preservados. Intervalos/limites/rotina de espera e política de parada mantidos.
`git diff --check` sem erro de whitespace, com avisos LF/CRLF do working tree.

Resultado: AC2-A concluída no caminho delimitado de recuperação. Atividades
continuam Parciais, sem prova terminal ou composição com recursos. Cobertura
global/encerramento não confirmados; modo_atual pendente. Sequência mantida:
AC2-B, AC2-C, AC3, AC4, AC5, validação física e executável. Working tree anterior
preservado. Sem teste físico, commit, push ou empacotamento.

## 2026-10-23 — AC2-B: saída acompanhada e observação explícita de término

Solicitação: acompanhar entrada, retorno normal/excepcional e término da thread
de registrar_falha_recuperacao, preservando partidas ambíguas/gerações e sem
integrar recursos, Tk ou coordenador. Revisados alvo real, todos os retornos,
exceções e contratos da guarda; dependência de ajuste privado da publicação
documentada em VALIDACAO antes da implementação. Sem alteração de API pública
da guarda ou do ciclo geral CLIENTE.

Mantida a rotina _aguardar_proxima_tentativa intacta. Identificadas oito saídas:
executando falso antes do while; parada após busca; estado de candidatura alterado;
tentativa alterada; servidor encontrado; prazo vencido; evento de parada na espera;
fim do while. Erros de relógio/descoberta também pertencem à execução monitorada.
Sinais de parada e eventual espera em curso após promoção não são provas de término.

Na guarda, auxiliares privados de publicação substituem escritas inline do
wrapper: entrada anterior à rotina; saída garantida por try/except BaseException/
else. Retorno normal e excepcional registrados; erro original conserva instância
e traceback. Falha de publicação invalida retorno e marca erro; se a operação já
falhou, a publicação adicional aparece em __cause__, sem apagar o primário.
Nem erro operacional com thread terminada nem saída incompleta viram sucesso.
Esquema de retratos/métodos públicos mantidos; sem nova evidência de recurso.

Adaptador conserva tokens admitidos e fica alcançável pela infraestrutura entre
gerações. Nova consulta observar_termino_retentativas faz passagem finita sem
espera, usando observar_termino_thread da guarda sobre o proxy/thread concreta
já retida. Exige partida resolvida/fora de curso, entrada e retorno, antes de
aceitar is_alive booleano False. Resultado só contém ID da retentativa/geração e
termino_observado. Fábrica sem start pode provar ausência, mas isso não equivale
a thread terminada. Consulta não é feita implicitamente por avaliar, Tk ou parada.

Nenhum join, timeout de descarte, espera ativa, thread vigilante ou callback novo
em produção. Observação fora dos locks da guarda/infra/adaptador. A própria thread
não confirma término enquanto viva e não faz self-join. Se o alvo retorna mas
a thread ainda executa sua saída, consulta continua negativa. Start que lança
com entrada preserva ambiguidade; prova posterior só com saída e término concreto
observados. Sem entrada, is_alive=False nunca prova ausência. Consultas concorrentes
usam a mesma identidade; promoção/nova geração não apagam origem ou histórico.

Criado test_finalizacao_retentativas_cliente.py com **35 testes novos**: 16
cenários, corridas A–E, thread terminada com socket pendente, erros de publicação,
primário/causa, todos os retornos reais, erro do relógio/descoberta, BaseException,
observações inválidas, retenção pela aplicação, consultas repetidas e ausência de
join operacional. Threads Python do harness demonstram cauda viva após alvo
retornar e observação da própria thread; relógio/transporte/IO/Tk são falsos.
Join limitado apenas no harness para seus trabalhadores. Sem hardware, rede/DNS,
Keyring, interface ou dados persistidos reais.

Verificação: `python -B -m unittest discover -s tests -q` — **1192 testes simulados
aprovados em 8,726 s**, 35 novos + 1157 regressões anteriores **sem adaptações**.
SHA-256 dos 94 arquivos preexistentes, incluindo 78 fontes Python: alterados
somente guarda (implementação privada), infraestrutura, adaptador e os dois
documentos; outros 75 fontes Python idênticos, inclusive todos os testes antigos.
Um teste novo. main/leitor/alvo, protocolos, eleição, recursos/JSON/AC1-F1,
executor HTTP, callbacks Tk e coordenador preservados. Working tree anterior mantido.
`git diff --check` sem erro de whitespace, com avisos LF/CRLF do working tree.

Resultado: AC2-B concluída no escopo da thread de espera, com comprovação dependente
de consulta externa explícita, sem encerramento automático. Prova de término não
substitui cleanup; atividades permanecem Parciais. Cobertura global/encerramento
não confirmados. Próxima etapa AC2-C, depois AC3/AC4/AC5 e validações finais;
modo_atual continua pendente na etapa própria. Sem teste físico, commit, push ou
empacotamento; executável apenas na entrega.

## 2026-10-27 — AC2-C: propriedade dos sockets criados pela recuperação

Solicitação: auditar propriedade real antes de vincular recursos às retentativas,
sem atribuir automaticamente sockets da mesma geração ou confundir término com
cleanup. Revisados alvo completo, guarda, recursos, composição, infraestrutura e
AC1/AC2-A/B; menor adaptação registrada em VALIDACAO antes de editar operação.

Conclusão da auditoria: a thread de espera chama buscar_servidor diretamente e
cria socket UDP e, sob resposta válida, confirmação TCP. Esses recursos são
próprios da retentativa. SUBSCRIBE, CONFIG/REGISTER e descobertas do loop permanente
são de outra atividade. A busca entrega endereço/estado para futura candidatura,
sem transferir sockets ao leitor. Alvo não cria arquivos, HTTP ou novas threads.

Os contratos existentes permitem representar o vínculo sem mudar seus registros:
nova instância de RecursosRetentativaCliente reutiliza o registro/geração original
e usa como atividade a identidade real admitida. Adaptador permanente e registros
anteriores não são modificados. Contexto explícito da execução seleciona o adaptador
somente para a descoberta da recuperação, sem inferir por geração/estado/thread ID.
Não cria outra guarda, geração fictícia ou registro de recursos.

Gancho privado na reserva registra a evidência antes da fábrica, evitando uma
lista vazia tomada como ausência durante alocação concorrente. Token deve ter
sido emitido pelo caminho de criação desse adaptador; recurso do leitor não pode
ser reatribuído. Duplicação idêntica é idempotente; vínculo incompatível/token ou
geração estrangeiros recusados. Falha de vínculo impede a fábrica, tenta prova
de não alocação e mantém erro/cobertura incompleta. Falha posterior de publicação
do handle conserva o vínculo e as pendências retidas pelo adaptador/infraestrutura.

Nova consulta obter_associacoes_retentativas expõe app/geração/retry, evidência,
escopo de cobertura e IDs/tipos/estado de criação/limpeza dos recursos próprios.
Não chama observador terminal ou fecha recursos. AC2-B permanece separado; thread
terminal com socket próprio/independente aberto não confirma a composição/global.
Campos brutos antigos de atividade dos recursos continuam positivos; None lógico
para independentes é representado por VinculoRecurso na composição, sem renumerar
histórico ou inventar retries para leitor/aplicação.

Cobertura do recorte só é declarada depois da saída do caminho explicitamente
auditado espera_recuperacao_descoberta e sem falha de associação. Lista vazia,
alvo que terminou ou simples uso de parte do adaptador não comprovam cobertura.
Rotina desconhecida com execução completa e recursos não associados continua
negativa. A declaração refere-se somente ao fluxo auditado e não é certificado
universal de callbacks externos/dependências nem cobertura completa do aplicativo.

Criado test_associacoes_retentativas_cliente.py com 35 ensaios: 16 cenários,
verificações A–E e cobertura desconhecida. Exercita descoberta real com UDP/CHECK
falsos, recursos próprios/independentes, associação antes de fábrica bloqueada,
thread terminal com recurso pendente, promoção/nova geração, duplicidades e
IDs inválidos, falhas de vínculo/cleanup/publicação, contexto em outra thread,
persistência em memória e parcialidade da cobertura. Nenhum teste introduz
global positivo; composição completa é fornecida somente em recortes controlados
do harness, nunca na infraestrutura operacional. Sem rede/DNS, hardware, Tk,
Keyring ou dados persistidos reais.

Uma adaptação em test_partidas_retentativas_cliente.test_23: verificar registro/
geração originais e atividade da retry no adaptador passado à busca, preservando
a verificação de espera de 5 s; não exigir o mesmo objeto do leitor permanente.
Nenhum teste removido. `python -B -m unittest discover -s tests -q` — **1227 testes
simulados aprovados em 12,133 s**, 35 novos e 1192 regressões anteriores.
SHA-256 dos 95 arquivos preexistentes, incluindo 79 fontes Python: apenas três
fontes operacionais, um teste anterior e VALIDACAO/HISTORICO alterados; outros
75 fontes Python idênticos. Dois fontes novos: adaptador de associação e teste.
Guarda, recursos/composição experimentais, HTTP/JSON/AC1-F1, protocolos, thread
permanente, eleição, Tk e coordenador preservados; working tree anterior mantido.
`git diff --check` sem erro de whitespace, com avisos LF/CRLF do working tree.

Resultado: AC2-C concluída no escopo auditado com vínculos mínimos necessários e
matriz de recursos próprios, de outra atividade e dependências operacionais.
Próxima etapa AC3, composição operacional. Cobertura global/encerramento não
confirmados; modo_atual, callbacks/TclError, coordenador e validações finais
pendentes. Sem teste físico, commit, push ou empacotamento.

## 2026-10-27 — AC3-A: composição operacional somente de leitura

Solicitação: combinar os contratos operacionais de retentativas, associações reais,
recursos independentes, HTTP e arquivos AC1-F1 em consulta passiva; separar retry,
CLIENTE e aplicação, revalidar evidências e preservar 1227 regressões. Sem integrar
ao Tk/coordenador, observar threads automaticamente ou executar limpeza.

Contratos examinados: composição experimental e seus validadores, guarda e
observação explícita, associações AC2-C, recursos TCP/UDP/arquivos, HTTP e retenções
AC1-F1, matriz AC1 e evidências de AC2-C. São suficientes para compor evidências
conhecidas por consultas públicas; faltam revisões comuns e cobertura exaustiva
das atividades permanentes/observadoras. A delimitação e os limites estão na seção
AC3-A de VALIDACAO.md; não foi necessário ampliar contratos nem criar lock global.

Criado rede/composicao_operacional_cliente.py. Infraestrutura recebeu apenas
avaliar_responsabilidades_cliente(), mantendo avaliar() legado. Reutiliza os dois
validadores puros de guarda/recursos do protótipo, sem copiar seu avaliador ou
alterar os três protótipos. Dois ciclos iguais revalidam retratos, associações,
HTTP e contextos de arquivo; diferenças ou falhas descartam positivos. Igualdade
não é snapshot atômico. Confirmação individual exige gates fechados, estado
terminal comprovado, cobertura explícita do escopo auditado encerrado e recursos
próprios limpos na região monotônica dos contratos existentes. Não fecha gates.

Recursos sem associação comprovada e gerações antigas permanecem no inventário
e nas pendências, sem inferência por coincidência numérica. HTTP com erro
funcional publicado é resolvido, com erro sanitizado preservado, sem inferir
fechamento físico de Requests. Histórico e retenções de arquivos são distintos
do registro: cleanup posterior pode resolver handle e manter identidade
desconhecida. O indicador de conhecidos resolvidos é diagnóstico, inclusive em
inventários vazios, nunca certificado de cobertura ou snapshot atômico. CLIENTE
permanece não confirmado por cobertura incompleta; aplicação global fora do escopo.

Novo tests/test_composicao_operacional_cliente.py com 33 testes: os 16 cenários,
seis verificações críticas A–F e adicional de conhecidos positivos com cobertura
incompleta, além de contratos inválidos, sanitização, gates abertos e inspeção AST
sem ações. A corrida HTTP/recursos foi exercitada tanto por intercalação entre
consultas quanto por thread real de teste com eventos, transportes e handles
falsos. Consulta não chama observador, is_alive, join, close, shutdown, limpeza ou
criação de thread. Nenhum efeito de rede, hardware, UI ou persistência real.

`python -B -m unittest discover -s tests -q`: **1260 testes simulados aprovados em
13,353 s**, 33 novos e 1227 regressões anteriores sem adaptações. SHA-256 dos
168 arquivos preexistentes: somente infraestrutura e VALIDACAO/HISTORICO alterados;
dois fontes novos. Dos 81 fontes Python anteriores, 80 permanecem idênticos.
Nenhuma remoção, working tree anterior preservado. Protótipos, guarda, recursos,
leitor, protocolos, HTTP, arquivos/AC1-F1, JSON, eleição, Tk e coordenador intactos.
`git diff --check` aprovado, com avisos LF/CRLF do working tree; fontes novos
conferidos quanto a sintaxe e espaços finais.

Resultado: AC3-A concluída como composição passiva com confirmações por escopo
e limitações documentadas. AC3-B verificará cobertura operacional; AC4, AC5 e
validação física continuam pendentes. Sem teste físico, commit, push ou
empacotamento; executável apenas após desenvolvimento/confiabilidade/validação.

## 2026-10-27 — AC3-B: auditoria da cobertura das atividades CLIENTE

Solicitação: mapear atividades reais a partir de main.iniciar, documentar origem,
identidade, admissão, partida, execução, término, recursos, promoção, parada e
cobertura; investigar leitor permanente, reconexões, modo_atual, HTTP e callbacks;
validar AC3-A e priorizar integração. Autorizados somente novos testes simulados,
VALIDACAO.md e HISTORICO.md; nenhuma mudança operacional.

VALIDACAO recebeu percurso da montagem, duas matrizes complementares com todos
os campos por atividade, diagnóstico detalhado e plano mínimo. Identificadas
thread permanente, recuperação temporária, fases síncronas CONFIG/REGISTER/
SUBSCRIBE/descoberta/candidatura, preparação da aplicação, promoção, operações
HTTP/arquivos, pontes de rebaixamento automáticas/manuais, supervisão/finalização
e cadeias de callbacks. Trabalhadores PRINCIPAL permanecem no domínio próprio;
iniciar_leitura/ler_balanca da janela é caminho latente sem chamador na montagem,
não uma thread fictícia da execução atual.

Achado prioritário confirmado: LeitorDadosServidor.iniciar conserva self.thread,
mas não reserva atividade nem publica entrada/retorno/erro/término. A geração
dos recursos não substitui a identidade da partida. parar sinaliza flags/eventos
e tenta shutdown/close do SUBSCRIBE; thread pode continuar viva. CONFIG/REGISTER
não são self.cliente e não recebem interrupção direta desse método. Iniciar pode
criar thread de leitor já construído mesmo com gates CLIENTE fechados. Risco de
substituir self.thread em reinício antes de comprovar fim antigo foi identificado
por inspeção, sem alegar ensaio dinâmico específico de reinício nesta rodada.

Reconexões permanecem no mesmo alvo/geração com IDs individuais de recursos,
sem novas retries. Ensaio dinâmico de dois ciclos produziu dez recursos distintos.
Corrida determinística com eventos mostrou REGISTER alocando/enviando após parar:
a checagem executando não reserva a fase e parar não fecha gate de recursos.
Nenhuma correção foi introduzida e nenhum protocolo foi alterado.

Promoção real com dependências falsas sinalizou leitor antigo ainda vivo e mudou
a fonte visual, mantendo origem/IDs e modo_atual=cliente nos registros. APIs de
promover existem, porém main/leitor/janelas não as chamam. O avaliador não usa
papel para excluir pendências ou provar término; metadado desatualizado não deve
ser usado como prova de cobertura. Atualizar o campo não resolveria a ausência
de acompanhamento de atividades.

HTTP login/approval é síncrono nos caminhos encontrados, sem thread própria.
Thread auxiliar criada somente no harness demonstrou HTTP resolvido enquanto
chamador continua ativo; outro ensaio conservou callback pendente após publicação.
Refresh do PRINCIPAL permanece distinto. TclError legado reproduzido com root
falsa destruída e flag ainda ativa; atualizar_peso também pode acessar widget
destruído. Fechamento normal seta executando=False e protege o refresh específico,
mas não comprova cancelamento integral da fila. Nada foi corrigido em Tk.

Criado tests/test_auditoria_atividades_cliente_ac3b.py com 26 testes: 16 cenários
obrigatórios (01–16), críticas A=02, B=07, C=17, D=18, E=08/24, F=16 e complementos
de imutabilidade/observação explícita, gates, widgets tardios e inventário AST.
Recuperação usa caminho auditado real AC2-C e pode ter positivo individual; recursos
independentes, HTTP, gerações antigas e retenções AC1-F1 continuam representados.
Conhecidos resolvidos com leitor não acompanhado conserva CLIENTE/global falsos;
nenhum teste força cobertura completa. Thread real somente no harness controlado,
com transporte/handles/widgets falsos; sem hardware, rede/DNS, Tk ou cofre reais.

`python -B -m unittest discover -s tests -q`: **1286 testes simulados aprovados
em 8,636 s**, 26 novos e as **1260 regressões anteriores preservadas sem mudanças**.
SHA-256 dos 170 arquivos anteriores: somente os dois documentos alterados; um
teste novo, nenhuma remoção. Todos os 83 fontes Python anteriores idênticos,
inclusive módulos operacionais, avaliador, registros e protótipos. Working tree
anterior preservado. Sintaxe/espaços finais do teste novo conferidos;
git diff --check aprovado com avisos LF/CRLF já existentes.

Resultado: AC3-B concluída como auditoria, sem declaração de cobertura completa.
Prioridade confirmada para AC3-C: identidade e ciclo formal da thread permanente,
depois admissão das fases/ponte de criação e publicação de modo no marco correto,
sem atribuir recursos independentes a retries. AC3-D depende de cobertura e
coerência suficientes; AC4/AC5 tratam callbacks/coordenador. Plano documentado,
não implementado. Sem teste físico, commit, push ou empacotamento; executável
somente após as validações previstas.

## 2026-10-27 — AC3-C1: ciclo formal da thread permanente do CLIENTE

Solicitação: integrar somente admissão/partida/entrada/retorno e observação
explícita do término da thread permanente, mantendo origem entre reconexões,
promoções e gerações. Preservar parar, REGISTER/CONFIG/SUBSCRIBE, eleição,
recuperação, HTTP/JSON, Tk e coordenador; caracterizar REGISTER após parar.

Antes da implementação, VALIDACAO recebeu a comparação dos contratos e a
necessidade de registro específico: GuardaRetentativasCliente é exclusiva de
retries; leitores permanentes não foram cadastrados como retentativas fictícias.
Documentada também a recusa nova de admissão de iniciar: assinatura/retorno None
preservados, sem thread ou alteração de flags/referência na recusa.

Criado rede/atividades_permanentes_cliente.py. Infraestrutura de main.iniciar
possui um RegistroAtividadesPermanentesCliente e fornece acesso fixo ao registro,
obter_atividades_permanentes passivo e observar_termino_leitores explícito.
Captura uma origem opaca vinculada ao adaptador de recursos da mesma aplicação;
cada início recebe ID próprio e tipo leitor_permanente, sem nova geração ou retry.
Gate dedicado e explícito, independente dos outros; parar não o fecha.

Leitor captura registro/origem no construtor; iniciar reserva antes das flags,
construção e start. O registro retém a thread concreta antes de chamar start
fora do lock; registra resultado de partida e envolve o alvo com entrada,
retorno normal/excepcional e erro sanitizado. Construtor falho antes de start
pode resolver ausência; exceção depois de start preserva ambiguidade e eventual
entrada anterior/tardia. Falhas de publicação invalidam a prova correspondente,
inclusive quando publicam e depois lançam. Erro primário conserva instância e
traceback, com erro de publicação como causa. Não foram acrescentados joins,
watchers, limpeza, efeitos Tk ou rollback artificial de flags após falhas.

Observar término exige partida resolvida, entrada e retorno, is_alive booleano
falso consultado fora do lock e revalidação antes da prova. Retorno do alvo e
parar não bastam; erro funcional do alvo permanece separado de término físico.
Origem/IDs e handles de todas as partidas ficam retidos, mesmo ao substituir
self.thread ou criar geração B. Retratos não expõem threads/exceções/tokens.
Consulta de composição permanece byte a byte intacta e passiva; inclusão do
registro novo no conjunto fica para AC3-D, sem antecipar cobertura completa.

Novo tests/test_atividades_permanentes_cliente.py com 40 ensaios: 16 cenários,
seis corridas A–F e adicional de atividade terminada com SUBSCRIBE aberto.
Reconexão real com transporte falso mantém uma atividade e dez recursos distintos.
REGISTER após parar continua executando, agora com atividade explicitamente
registrada em curso, sem término prematuro. Promoção real por closure com
dependências falsas conserva A viva e B independente. Modo_atual não corrigido.
Testados erros de construção/start/alvo/publicação, primário com secundário,
entrada tardia, observação inválida, gates, reinício, origem estrangeira,
retenção, cópias sanitizadas e caminho legado sem infraestrutura.

Uma adaptação de regressão em test_partidas_retentativas_cliente.test_25:
substituir exigência de alvo bruto por execução do wrapper e prova de delegação
única, entrada/retorno no registro permanente e nenhuma retry. Demais 1285 testes
anteriores intactos; nenhum removido. `python -B -m unittest discover -s tests -q`:
**1326 testes simulados aprovados em 12,275 s**, 40 novos + 1286 regressões com
essa adaptação. Threads reais somente no harness; transporte, handles e Tk falsos.
Sem hardware, rede/DNS, cofre ou persistência real de usuário.

SHA-256 dos 171 arquivos anteriores: somente leitor, infraestrutura, um teste
anterior e VALIDACAO/HISTORICO alterados; dois fontes novos. Dos 84 fontes Python
anteriores, 81 idênticos. Nenhuma remoção, working tree anterior preservado.
Guarda/protótipos/retries, associações, avaliador, HTTP/JSON/AC1-F1, protocolos,
eleição, Tk e coordenador intactos. Sintaxe/espaços finais conferidos e git diff
--check aprovado, com avisos LF/CRLF já presentes.

Resultado: AC3-C1 concluída no recorte solicitado. Permanecem pendentes a corrida
REGISTER (AC3-C2), composição das atividades/observadores (AC3-D), modo_atual,
callbacks/TclError (AC4), coordenação (AC5) e validações finais. Sem teste físico,
commit, push ou empacotamento. Executável apenas na entrega validada.

## 2026-10-27 — AC3-C2: admissão REGISTER sincronizada com a parada

Solicitação: impedir nova admissão REGISTER após início efetivo da parada,
preservando operações já aceitas e suas identidades/recursos; sincronizar
admissão e fechamento sem lock durante IO. Preservar CONFIG/SUBSCRIBE/descoberta,
eleição, recuperação, HTTP/JSON, Tk, coordenador e ciclo permanente independente.

Revisados parar, loop de leitura, conector, registrar_cliente e contratos de
reserva/criação/uso/limpeza antes da integração. VALIDACAO documentou o contrato:
controle por geração, mesmo lock para admitir e fechar, autorização aceita pode
concluir depois da parada; recusa antes da decisão impede socket/envio/sucesso.
Não é garantia de que nenhum pacote REGISTER será enviado depois de parar.

Criado rede/admissao_register_cliente.py. AdmissaoRegisterCliente emite token
opaco por operação e conserva origem original; RecursosRegisterCliente reutiliza
IO existente e publica vínculo de reserva antes de alocar, sem nova geração ou
recurso fictício. Nenhuma API pública do registro de recursos foi modificada.
O leitor instala o controle e fecha seu gate na primeira ação de parar; depois
executa a sinalização/interrupção anterior. O caminho REGISTER solicita token
antes do conector e sai sem sucesso fictício quando recusado. Mensagem, porta,
timeout, tentativas, tratamento de resposta e eleição preservados.

O auxiliar não segura lock durante fábrica/conexão/envio/resposta/parse/close.
Cada autorização executa uma vez; recursos têm IDs próprios e origem fixa.
Fechar admissão não apaga autorizações nem cancela trabalho aceito. Controle
permanece fechado com parada repetida ou reinício do mesmo leitor; nova geração
possui outro controle. Erros funcionais e cleanup continuam separados pelo
registro existente. Publicação tardia/falha de vínculo/saída mantém pendência;
primário preservado quando publicação também falha. Nenhum observador implícito,
fechamento de recurso alheio, mudança de retry ou confirmação global.

Necessidade de retenção documentada antes de ampliá-la: o controle precisa
sobreviver à retirada da referência do leitor. Registro permanente recebeu
apenas retenção auxiliar por geração, validando dono/origem e recusando autoridade
duplicada, além da consulta passiva obter_controles_register. Não altera provas
de partida/entrada/retorno/término nem seu gate. O controlador retém exclusivamente
handles incertos de REGISTER, sem guardar o adaptador original ou ampliar retenção
de CONFIG/SUBSCRIBE/descoberta. Testes 36/38 removem o leitor e confirmam histórico/
handle ainda alcançáveis pela aplicação. A lacuna histórica fora do recorte
REGISTER continua com sua caracterização anterior aprovada.

Consulta local obter_operacoes_register e consultas dos controles retidos são
passivas e não afirmam snapshot atômico. O avaliador permanece byte a byte
intacto, CLIENTE/global falsos e cobertura incompleta; composição dos novos
registros é AC3-D. CONFIG/SUBSCRIBE/descoberta têm auditoria específica em AC3-C3.

Novo tests/test_admissao_register_cliente.py com 38 testes: 16 cenários, corridas
A=02/04/05, B=18, C=17, D=19, E=20, F=21 e adicional 22 distinguindo admissão de
envio. Cobertos ainda erros combinados, publicação tardia, gate de recursos,
identidades estrangeiras, IO sem locks, consulta imutável, reuso recusado,
associação incerta, duas operações simultâneas, closed falso, recurso independente,
preservação de protocolo, retenção após perder leitor e autoridade única.

Apoio de transporte atualizado para o adaptador específico; quatro testes antigos
ajustados no seam de conexão (AC3-B 04/17 e AC3-C1 13/19), preservando suas
assertivas e reforçando autorização/execução em curso. Caracterização de envio
após parar permanece válida quando houve admissão prévia. Nenhum teste removido;
demais 1322 métodos anteriores preservados. Execução preliminar interrompida
durante ajuste dos fakes não foi contabilizada como aprovação.

`python -B -m unittest discover -s tests -q`: **1364 testes simulados aprovados
em 9,560 s**, 38 novos e 1326 regressões com esses ajustes. Ensaios finais com
transporte/DNS/handles/widgets falsos e threads do harness para sincronização;
nenhum teste físico da rede/TC420. SHA-256 dos 173 arquivos anteriores: apenas
leitor, retenção auxiliar no registro permanente, helper e dois testes anteriores,
VALIDACAO/HISTORICO alterados; dois fontes novos. Dos 86 fontes Python anteriores,
81 idênticos. Sem remoção; working tree anterior preservado. Recursos/API,
infraestrutura main, protótipos, retries, avaliador, HTTP/JSON, protocolos, eleição,
Tk e coordenador intactos. Sintaxe/espaços finais e git diff --check aprovados,
com avisos LF/CRLF já existentes.

Resultado: AC3-C2 concluída exclusivamente para admissão REGISTER. Operação
aceita mantém responsabilidade até provas suficientes; recusa não prova término
de thread nem limpeza de operações anteriores. Próximo passo AC3-C3, depois
AC3-D, AC4, AC5 e validações finais. Sem teste físico, commit, push ou
empacotamento; executável permanece na entrega validada.

## 2026-10-27 — AC3-C3: auditoria dos demais caminhos de admissão

Solicitação: auditar CONFIG, SUBSCRIBE e descoberta por origem, separando
admissão/reserva/criação/IO/publicação/cleanup/parada; caracterizar tentativas
internas, gerações antigas e composição; decidir próxima correção mínima.
Somente inspeção, novos testes e VALIDACAO/HISTORICO, sem mudanças operacionais.

Inspecionados leitor, conector, descoberta, montagem main/UI, recursos, admissão
REGISTER, guarda/associações de retries, atividades permanentes e composição.
VALIDACAO recebeu contratos por fase, matriz de autoridades/origens, matriz de
decisão com categorias crítica/parcial/coberta/desconhecida e plano fundamentado.
Reserva válida de socket foi distinguida de autorização da operação contra parar;
criação/comunicação posterior não foi tratada automaticamente como falha.

CONFIG: somente inicial no corpo permanente da montagem inspecionada; checagem
de executando impede entrada já parada com IP conhecido, mas não sincroniza
contra reserva posterior. Conector suspenso após checagem cria/envia depois de
parar; fallback tenta próximo endereço após sinalização, na mesma chamada/geração.
Entrada classificada crítica; validade das tentativas internas parcial, sem
assumir autorização ilimitada nem mudar ordem/quantidade/timeouts.

SUBSCRIBE: entrada e reconexão têm janela depois da checagem e antes de reservar.
parar pode encontrar self.cliente=None, e socket/arquivo tardios ainda são criados
e enviam SUBSCRIBE; shutdown não alcançou aquele handle. Leitura contínua não
foi presumida nesse caso se executando já é false. Reserva anterior à parada
continua acompanhada; socket antigo fechado não prova fim de leitura/arquivo/thread.
Proteção existente de makefile com pai fechado foi reproduzida e classificada
coberta nesse recorte, sem criar responsabilidade artificial.

Descoberta: separadas retry (ID exato AC2-C), leitor/candidatura (geração original),
preparação da aplicação (contexto próprio) e promoção (origem do leitor, autoridade
de tentativa PRINCIPAL). UDP inicial do leitor pode começar mesmo se o alvo
entra após parar, sem check inicial. Lacunas equivalentes na passagem da checagem
para busca de candidatura/recuperação foram reproduzidas. Busca já em curso pode
criar/repetir CHECK após cancelamento; timeout por chamada não é deadline global.
Tentativas internas classificadas parciais, não automaticamente indevidas. Fechar
guarda impede novas partidas mas não cancela busca/repetição da retry admitida.

Preparação nova é recusada por gate de geração fechado; contexto prévio ainda
pode operar com gate de recursos aberto. Parar um leitor alheio não deve cancelar
automaticamente preparação da aplicação. Promoção com registro fechado recusa
antes da descoberta, enquanto tentativa aceita mantém seus recursos de origem.
Scripts externos sem infraestrutura permanecem fora da cobertura comprovada.

Promoção/nova geração preservam recursos antigos e thread A ainda pendente;
modo_atual não governa identidade. B não reabre REGISTER de A. Não se afirmou
que exista gate CONFIG/SUBSCRIBE por geração: a ausência desse gate é a lacuna.
Composição permaneceu conservadora e passiva. Mesmo com sockets fechados/alvo
retornado, falta de observação terminal do leitor mantém consolidado falso;
registro permanente/operações adicionais ainda não compõem o diagnóstico AC3-A.

Novo tests/test_auditoria_admissao_demais_caminhos.py com 36 testes: 16 cenários,
seis verificações A=03, B=07, C=04/22, D=21, E=13/14, F=28 e complementos de gates,
fábrica tardia, makefile, autoridades por origem e consulta sem mutação. Corpos
operacionais reais com transporte/DNS/handles/widgets falsos; threads do harness
intercaladas por eventos/barreiras. Nenhum controle adicional foi implementado.

`python -B -m unittest discover -s tests -q`: **1400 testes simulados aprovados
em 9,717 s**, 36 novos e **1364 regressões anteriores intactas, sem adaptações**.
SHA-256 dos 175 arquivos anteriores: somente VALIDACAO/HISTORICO alterados; um
teste novo, nenhuma remoção. Todos os **88 fontes Python preexistentes idênticos**;
REGISTER, guarda, permanente, recursos, protótipos, composição, HTTP/JSON,
protocolos, eleição, Tk e coordenador preservados. Working tree anterior mantido.
Sintaxe/espaços finais do teste novo e git diff --check aprovados, com avisos
LF/CRLF já existentes. Sem teste físico da rede/TC420 ou persistência de usuário.

Resultado: AC3-C3 concluída como auditoria com lacunas explícitas. Prioridade
técnica proposta para AC3-C4: entrada de descoberta do leitor permanente, que
pode ocorrer com parada já publicada, e definição explícita dos limites de busca/
CHECKs dessa origem. CONFIG/SUBSCRIBE também críticos, a tratar em recortes
próprios, sem transportar controle a preparações/promoções/retries por suposição.
Não é avaliação de frequência ou risco físico medidos. AC3-D, AC4, AC5 e validações
finais permanecem pendentes. Sem teste físico, commit, push ou empacotamento;
executável somente na entrega após validação.

## 2026-10-27 — AC3-C4: admissão da descoberta inicial do leitor

Solicitação: implementar o recorte do texto anexado seguindo AGENTS.md, recusando
a descoberta inicial após parar e conservando operações aceitas e seus recursos,
sem alterar CHECKs, CONFIG, SUBSCRIBE ou outras autoridades.

Resultado: o primeiro ponto de descoberta de _manter_atualizado usa autoridade
específica por geração, com admitir/fechar_admissao no mesmo lock. parar fecha
essa autoridade antes das flags; recusas retornam None sem UDP. Tokens aceitos
são registrados antes da reserva e conservam geração original, vínculos UDP/TCP
individuais e evidências de publicação/cleanup. A infraestrutura retém controles
antigos e permite consulta passiva. Não foi reutilizado REGISTER nem duplicado
o registro de sockets. Fábricas/rede/close ficam fora do lock de admissão.

Preparação, recuperação AC2-C, promoção e demais chamadas de descoberta mantêm
o comportamento anterior. Somente o bloco inicial anterior a CONFIG recebeu
o controle. Auxiliar compartilhado de descoberta, atividades permanentes,
guarda, associações, avaliador e demais caminhos fora do escopo foram preservados.

Falhas de associação/publicação/limpeza não confirmam responsabilidade; erro
primário é preservado. Fábrica opaca que lança após invocação mantém reserva
incerta conforme contrato anterior. CHECKs de busca aceita podem continuar após
parar: comportamento caracterizado, não corrigido. Consulta sem socket não prova
fim. Sem infraestrutura não há prova de cleanup. Composição permanece incompleta,
sem confirmação de encerramento global; integração fica em AC3-D.

Verificações: linha de base com 1400 testes simulados aprovados em 9,424 s.
Novo tests/test_admissao_descoberta_inicial_cliente.py: 33 testes cobrindo os
16 cenários, seis corridas, limite CHECK/recusa e falhas adicionais. Suíte final
`python -B -m unittest discover -s tests -q`: **1433 aprovados em 12,722 s**.
O teste 33 da AC3-C3 precisou mudar: antes exigia o envio indevido após parar;
agora exige recusa sem fábrica/envio/recurso. Outros 1399 testes anteriores
não foram adaptados. Não se declara aprovação dos 1400 sem alterações.

Escopo dos fontes/testes conferido por hashes do estado imediatamente anterior:
leitor e fachada alterados, auxiliar específico novo, um teste anterior ajustado
e arquivo novo de testes; documentação restrita a VALIDACAO/HISTORICO. Sintaxe
AST e espaços finais conferidos; git diff --check aprovado, apenas avisos
preexistentes de LF/CRLF. Alterações anteriores
do workspace preservadas. VALIDACAO contém caminho real, matriz, limites e
pendências. AC3-C4 implementada no recorte inicial; AC3-C5/C6/C7, AC3-D, AC4, AC5
e validações físicas seguem pendentes. Sem teste físico, commit, push ou pacote.

## 2026-10-28 — AC3-C5: autorização individual de CHECK durante descoberta

Solicitação: controlar cada confirmação TCP após anúncio UDP, recusando novas
tentativas depois do cancelamento aplicável e conservando autorizações antigas,
recursos e contratos das diferentes origens; preservar protocolos e escopo.

Resultado: novo AdmissaoChecksCliente registra autorização antes da reserva TCP.
Leitor usa o mesmo lock/fechamento da autoridade original AC3-C4; recuperação usa
reservar_secundaria na guarda AC2-C, sem modificá-la nem herdar parar do leitor.
Preparação não possui cancelamento próprio de CHECK e continua independente.
Promoção mantém a autoridade original; mudar papel não resolve responsabilidades.

RecursosCheckCliente delega reserva ao dono original e mantém registros/vínculos
UDP/TCP e retry existentes. Autorização aceita pode criar/enviar depois de parar;
recusa impede fábrica/conexão/envio TCP e retorna a busca pela limpeza do UDP.
Consulta representa tentativa sem socket como pendente. Falhas de publicação,
associação ou cleanup não confirmam resolução. Recuperação exige prova True da
resolução secundária; publicação falsa, ambígua ou falha mantém pendência. Erro
primário é preservado. Handle incerto fica retido e fábrica opaca que lança não
recebe prova de ausência inventada. Rede/timeout/close ficam fora dos locks.

Passagem de contexto cobre busca inicial, loop e candidatura do leitor, inclusive
legado; recuperação instrumentada mantém identidade AC2-C. Sem infraestrutura
não se afirma prova de limpeza. Preparação e auxiliares isolados sem autoridade
continuam com contrato anterior. Cancelar admissões não interrompe imediatamente
recv UDP ou CHECK aceito. confirmar_servidor direto mantém retorno booleano;
formatos, portas, timeouts, respostas, ordem e repetição não cancelada preservados.

Verificações: linha de base com 1433 testes simulados aprovados em 11,394 s.
Novo tests/test_admissao_checks_cliente.py com 44 testes: 16 cenários, seis
corridas, teste adicional e complementos de publicação/cleanup/origem/legado.
Resultado final `python -B -m unittest discover -s tests -q`: **1477 testes
simulados aprovados em 15,566 s**. Duas expectativas antigas adaptadas:
AC3-C3/teste 21 (CHECK após fechar a guarda) e AC3-C4/teste adicional (CHECK ainda
não admitido após parar) passam a exigir recusa. Os outros 1431 testes anteriores
não foram adaptados; não se declara aprovação dos 1433 sem alterações.

Escopo conferido por hashes: seis fontes existentes de rede alterados apenas
para autorização/passagem/consulta, auxiliar específico novo, dois testes antigos
ajustados, um teste novo e documentação restrita a VALIDACAO/HISTORICO. Sintaxe
AST, espaços finais e git diff --check aprovados, com avisos LF/CRLF preexistentes.
Alterações anteriores do workspace preservadas. Nenhuma mudança em CONFIG,
SUBSCRIBE, REGISTER, eleição, HTTP/arquivos, guarda, atividades permanentes,
Tkinter, coordenador ou avaliador. VALIDACAO detalha autoridades, matriz e limites.
Composição permanece passiva/incompleta, sem confirmação global. AC3-C5 concluída
nos contextos com autoridade comprovada; AC3-C6/C7, AC3-D, AC4, AC5 e validações
físicas seguem pendentes. Sem teste físico, commit, push ou empacotamento.

## 2026-10-28 — AC3-C6: admissão CONFIG e tentativas por endereço

Solicitação: impedir operações CONFIG e novas tentativas por endereço após
fechamento da geração, preservando tentativas aceitas, protocolo, recursos e
ciclo da thread; manter SUBSCRIBE e demais caminhos para etapas próprias.

Resultado: AdmissaoConfigCliente usa o lock/fechamento já existente da geração,
com identidades exclusivas para operação e tentativa. O leitor admite a operação
antes do conector; cada endereço solicita autorização antes da reserva TCP.
Recusas não criam socket. Tentativa aceita pode conectar/enviar/ler/publicar
depois da parada. TCP/makefile continuam no registro existente com IDs e vínculo
pai/arquivo próprios. Endereço é identificado no diagnóstico pela ordem, sem
host/IP ou mensagens de erro. Controles antigos são retidos pela infraestrutura.

Conector específico CONFIG preserva ordem, timeout 5, primeiro sucesso e última
falha de rede, sem alterar o conector geral de REGISTER. Falhas após conexão não
passam a repetir endereços. Publicação e cleanup incertos mantêm responsabilidade
pendente; erro primário é preservado. Uma opção privada de _criar, ativada somente
por CONFIG, evita que falha de prova de ausência substitua a falha de criação.
Essa dependência foi registrada em VALIDACAO antes da integração final; defaults
dos demais caminhos e contrato público geral foram preservados. Fábrica opaca
que lança sem handle não recebe prova inventada. Handles incertos são retidos.

Sem infraestrutura também há gate por endereço, mas nenhuma confirmação de
limpeza instrumental. Helper CONFIG independente não herda parada do leitor.
Consulta não observa threads nem limpa recursos; CONFIG terminado não comprova
término da thread. Não há nova thread, geração ou retentativa por endereço.
Avaliador permanece passivo/incompleto, sem confirmação de encerramento global.

Verificações: linha de base com 1477 testes simulados aprovados em 9,908 s.
Novo test_admissao_config_cliente.py com 40 testes: 16 cenários, seis corridas,
contrato de duas tentativas comunicadas e terceira recusada, conector real com
três endereços disponíveis e falhas adicionais. Resultado final de
`python -B -m unittest discover -s tests -q`: **1517 aprovados em 9,954 s**.
O teste de escopos não altera o algoritmo para continuar após sucesso: no conector
real o primeiro endereço falha, o segundo retorna CONFIG e a terceira autorização
é solicitada explicitamente para demonstrar a recusa.

Duas expectativas AC3-C3 adaptadas: testes 03/04 passam a exigir recusa após
parar no DNS/antes do próximo endereço. Apoio de transporte, fixture legada de
SUBSCRIBE e mapa de criadores do inventário ajustados à passagem CONFIG; a
expectativa da lacuna SUBSCRIBE permanece. Não se declara aprovação dos 1477
sem adaptações. Sintaxe AST, espaços finais e git diff --check aprovados, apenas
avisos LF/CRLF preexistentes. Comparação de hashes confirmou o recorte de fontes,
testes e documentação; alterações anteriores do workspace foram preservadas.

Produção restrita ao caminho CONFIG do leitor, retenção/consulta e opção privada
da infraestrutura, com auxiliar específico novo. SUBSCRIBE, REGISTER, descoberta,
CHECKs, eleição, HTTP/JSON, guarda, atividades permanentes, Tkinter, coordenador
e avaliador preservados. VALIDACAO detalha caminho, matriz, evidências e limites.
AC3-C6 concluída; AC3-C7, AC3-D, AC4, AC5 e validações físicas seguem pendentes.
Sem teste físico, commit, push ou empacotamento.

## 2026-10-28 — AC3-C7: admissão SUBSCRIBE inicial e reconexões

Solicitação: fechar a lacuna de admissão SUBSCRIBE nas conexões inicial e
subsequentes, preservando a leitura do peso, tentativas aceitas, recursos e
responsabilidades de gerações antigas; manter demais caminhos fora do escopo.

Resultado: AdmissaoSubscribeCliente registra um token exclusivo por passagem
no bloco SUBSCRIBE. Reutiliza lock/fechamento da geração original, sem nova flag
de parada. Recusa acontece antes da reserva/fábrica/envio. Tentativa já admitida
pode conectar/enviar depois de parar, mas não autoriza outras reconexões. Primeira
tentativa e reconexões possuem IDs distintos, sem novas threads ou retries.

RecursosSubscribeCliente usa o registro existente e publica vínculos antes da
fábrica. TCP/makefile conservam identidades e associação ao pai. A finalização
da tentativa ocorre depois da limpeza individual anterior; pai fechado continua
recusando makefile. Falhas de criação/publicação/cleanup mantêm estado conservador
e handles incertos retidos. Exceção original é preservada, inclusive quando a
publicação de ausência falha, usando a opção interna já existente da AC3-C6.
Sem infraestrutura há gate, mas nenhuma prova instrumental de limpeza.

O processamento de quadros, JSON, timeout 5/None, SUBSCRIBE, EOF, candidatura,
reconexões legítimas, shutdown e sequência de close permanecem no fluxo anterior.
Controles antigos são retidos na infraestrutura e consultados passivamente.
Promoção e nova geração não transferem recursos nem reabrem a autoridade antiga.
Nenhuma espera de thread foi adicionada à aplicação. A consulta do avaliador
permanece passiva/incompleta, sem confirmação global.

Verificações: linha de base com 1517 testes simulados aprovados em 10,594 s.
Novo test_admissao_subscribe_cliente.py com 39 testes: 16 cenários, seis corridas,
estabilidade dos dois quadros de peso através de reconexão/parada/recusa, falhas
e retenção adicionais. Teste com thread real e transporte falso demonstra que
SUBSCRIBE resolvido não comprova término da atividade permanente. Execução final
`python -B -m unittest discover -s tests -q`: **1556 aprovados em 10,292 s**.

Duas expectativas históricas AC3-C3 (06/07) adaptadas para recusa em vez de
conexão após parar antes da admissão. O apoio de interleaving foi atualizado
para a fronteira de admitir, com parada/reunião garantidas na saída. O caso 19
de criação posterior de tentativa já aceita permanece aprovado. Não se declara
aprovação dos 1517 sem adaptações. Sintaxe AST, espaços finais e git diff --check
conferidos; apenas avisos LF/CRLF preexistentes. Hashes do estado anterior
confirmam o recorte nos diretórios de fontes/testes/documentação.

Produção restrita ao leitor e passagem/consulta da infraestrutura, com auxiliar
específico novo; auditoria anterior ajustada, teste novo e VALIDACAO/HISTORICO.
Alterações anteriores preservadas. CONFIG, REGISTER, descoberta, CHECKs, eleição,
HTTP/JSON, guarda, atividades permanentes, Tkinter, coordenador e avaliador não
foram modificados. AC3-C7 concluída no recorte; AC3-D, AC4, AC5, testes físicos
e executável permanecem pendentes. Sem teste físico, commit, push ou pacote.

## 2026-10-28 — AC3-D1: atividades e admissões na composição operacional

Solicitação: integrar evidências passivas da thread permanente e das admissões
ao avaliador AC3-A, preservando revalidação, gerações, autoridades e contratos
de recursos/HTTP/arquivos, sem alterar parada, controles, interface ou coordenador.

Resultado: duas rodadas de leitura incluem atividades permanentes, REGISTER,
descoberta/CHECK, CONFIG/endereços e SUBSCRIBE. Validação recalcula conclusão
local e cruza tipos/IDs/geração/atividade/retry, vínculos de recursos, relação
arquivo–TCP e autorização secundária. Recurso limpo, publicação resolvida,
operação concluída e thread terminada são evidências distintas no diagnóstico.
Autorizações sem socket e gerações antigas permanecem representadas; reserva
secundária da guarda aparece mesmo antes da publicação local do CHECK.

A infraestrutura recebeu somente obter_operacoes_register, consulta de controles
já retidos. As demais fontes eram públicas. Composição não observa término,
não chama parar/admitir/fechar, não cria nem limpa recursos, não altera HTTP ou
modo_atual. Conhecidos resolvidos passa a incluir permanentes e admissões;
fechamento dos gates é reportado separadamente. Não foi introduzida confirmação
CLIENTE ou global, pois falta prova de cobertura operacional suficiente.

Preservada a separação preparação/recuperação/leitor. Preparação não é penalizada
por não possuir cancelamento próprio de CHECK. Seus recursos existentes entram
na avaliação; ausência desse controle não prova ausência de trabalho. VALIDACAO
documenta limites: retratos sem versão conjunta/snapshot atômico, cobertura
declarada incompleta, origens preparadas sem certificado de reserva/partida,
fases síncronas anteriores a reservas, publicações incertas e callbacks globais.
Nenhuma API de registro/controle foi ampliada para corrigir essas lacunas.

Verificações: linha de base com 1556 testes simulados aprovados em 11,333 s.
Novo test_composicao_admissoes_cliente.py com 45 testes: 16 cenários, seis
verificações críticas, callback global fora da cobertura, contratos reais,
inconsistências e concorrência. Execução final
`python -B -m unittest discover -s tests -q`: **1601 aprovados em 10,382 s**.
AC3-B/teste 16 e AC3-C3/teste 28 foram adaptados: conhecidos não podem continuar
resolvidos com thread ativa ou sem observação, após sua integração. Outros 1554
testes anteriores não foram adaptados. Não se declara aprovação dos 1556 sem
alterações. Sintaxe AST, espaços finais e git diff --check conferidos, apenas
avisos LF/CRLF preexistentes.

Hashes do estado anterior confirmam o recorte nos diretórios de fontes/testes/
documentação: composição e acessor mínimo da infraestrutura; dois testes antigos,
teste novo e VALIDACAO/HISTORICO. Alterações anteriores preservadas. Leitor,
admissões, registros permanentes/retries, protocolos, eleição, HTTP/JSON, callbacks
e coordenador permaneceram intactos. AC3-D1 concluída; AC3-D2, AC4, AC5, validações
físicas e executável seguem pendentes. Sem teste físico, commit, push ou pacote.

## AC3-D2 — auditoria de suficiência operacional (2026-10-28)

Solicitação: examinar se a composição AC3-D1 possui evidências suficientes para
comprovar encerramento CLIENTE; matriz por domínio, fronteiras de admissão,
gerações antigas, HTTP/Requests, AC1-F1, coerência temporal e separação global.
Escopo autorizado e executado: somente inspeção, testes simulados e atualização
de VALIDACAO/HISTORICO. Nenhum módulo operacional alterado.

Resultado: auditoria concluída, cobertura completa ainda não demonstrada.
VALIDACAO registra os predicados reais, matriz com admissão/execução/limpeza/
cobertura e classificação Suficiente/Parcial/Desconhecida/Não aplicável com
evidências e recortes. Registros conhecidos vazios, gates fechados, retorno da
operação e término da thread continuam insuficientes isoladamente. CLIENTE e
global permanecem não confirmados por contrato.

Criado tests/test_auditoria_suficiencia_cliente_ac3d2.py: 32 testes, incluindo
os 16 cenários obrigatórios, sete críticas A–G e nove complementares. Reutiliza
helpers e algumas caracterizações anteriores por chamada explícita, sem herdar
ou redescobrir as classes antigas. O ciclo A/B usa controles reais com transporte
falso: A inicia famílias de rede, conserva falha de publicação e autorizações
pendentes após promoção; B conclui operações e thread; A permanece considerada.
Outra caracterização conserva limpeza desconhecida de A com B terminada.

Achados temporais: mudança persistente e publicação/limpeza entre registros são
detectadas nas simulações; uso 0→1→0 do recurso escapa de duas leituras iguais.
Nova SUBSCRIBE depois da captura da última fonte da segunda rodada deixa o
resultado conhecido desatualizado até consulta seguinte, com gates abertos.
Preparação ativa antes da reserva do UDP permanece invisível ao inventário,
apesar de thread de teste em andamento. Nenhum desses experimentos produz
positivo CLIENTE; snapshot_atomico permanece False. Não foi implementada
sincronização global nem inferida falha com todos os gates fechados a partir de
experimento com gates abertos.

HTTP: testes do executor e de WebTC420 com GET/POST substituídos mostram execução,
interpretação e publicação contratuais resolvidas sem prova física de sockets
Requests. Isso não demonstra vazamento real da biblioteca. AC1-F1 mantém
identidade desconhecida pendente mesmo depois de limpar o handle e remover a
retenção. Callbacks Tk e estado externo PRINCIPAL/coordenador simulados não
invalidam prova individual de retry nem autorizam saída da aplicação.

Plano mínimo proposto: P0 ledger de fases/origens anteriores à reserva e fronteira
temporal fundamentada; P1 integração das autorizações/observações existentes,
delimitação HTTP física e prova explícita para associação AC1-F1; P2 AC4 para
Tkinter/modo_atual e AC5 para composição/coordenador global. VALIDACAO explicita
condições necessárias para futuro positivo e propõe que o coordenador AC5 execute
as observações de leitores/retries depois de fechar admissões e sinalizar parada,
fora de Tk/locks de IO, com prazo e pré-condições; nada foi conectado nesta rodada.

Verificações: baseline completo **1601 testes simulados aprovados em 55,462 s**;
bateria nova isolada **32 aprovados em 0,285 s**; execução final
`python -B -m unittest discover -s tests -q`: **1633 aprovados em 32,939 s**.
Os 1601 anteriores permanecem sem adaptação. AST e espaços finais do teste novo
conferidos; git diff --check sem erro, apenas avisos LF/CRLF preexistentes.
Hashes SHA-256 contra snapshot anterior à tarefa conferem o recorte: novo teste,
VALIDACAO e HISTORICO; módulos operacionais e testes anteriores preservados.
AC3-D3 dependerá das lacunas comprovadas; AC4, AC5, validação física e executável
continuam futuros. Sem teste físico, commit, push ou empacotamento.

## AC3-D3-A — identidade da preparação antes do primeiro UDP (2026-10-28)

Solicitação: eliminar invisibilidade da preparação admitida/em execução antes
de criar recurso, preservando origem, recursos, resultados funcionais e erros;
manter composição/coordenador inalterados. Revisados main.iniciar, login
automático, conexão manual, descoberta, infraestrutura e achado AC3-D2.

Fronteira escolhida e documentada: descoberta síncrona sem leitor chamada por
buscar_servidor com a infraestrutura compartilhada. Inicialização, verificação
do login automático e conexão manual usam esse mesmo ponto antes do UDP. Seus
fluxos completos têm limites diferentes, incluindo JSON/keyring anteriores,
HTTP e criação de PRINCIPAL posteriores, callbacks e interface; não foram
reclassificados automaticamente como uma única preparação. Operações com dono
de leitor/recuperação já fornecido mantêm seu caminho anterior.

Implementado rede/preparacoes_cliente.py, com PreparacaoClienteId opaco e
RegistroPreparacoesCliente. Infraestrutura retém o registro e expõe
registro_preparacoes, obter_preparacoes e executar_descoberta_preparacao.
Ramo sem leitor de buscar_servidor registra responsabilidade antes de executar
preparar_descoberta e antes da reserva UDP. Admissão sozinha não cria geração,
recurso, thread, retentativa ou REGISTER. O dono de recursos anterior continua
gerando seu contexto original, apenas correlacionado por geração/atividade.

O ledger conserva reserva, início, execução/publicação em curso, retorno,
resultado retorno/falha, categorias de erro e falhas de publicação/associação.
Não guarda respostas, endpoints, configuração ou argumentos de autenticação.
Tokens estrangeiros/reutilizados são recusados. Retorno funcional e exceção
operacional seguem ao chamador; se publicação também falha, a exceção original
permanece principal com a falha de publicação como causa. Publicação parcial
seguida de erro não confirma execução. Recursos pendentes e publicações de
recurso permanecem separados de execução_resolvida; sair da função não prova
limpeza global. Histórico de preparações antigas permanece retido na promoção.

Limites explícitos: sem autoridade própria formal de encerramento da preparação,
o registro informa nao_estabelecida e não herda leitor.parar. Nenhuma política
de simultaneidade foi criada; gates anteriores ainda podem recusar o trabalho.
Consulta passiva não é snapshot atômico. Composição antiga não consulta esse
ledger: durante a janela pré-UDP ainda pode considerar conhecidas resolvidas,
mas CLIENTE/global continuam False e cobertura incompleta. Coerência temporal
continua para AC3-D3-B e integração consolidada para AC3-D3-C. HTTP/Requests,
arquivos AC1-F1, interface, eleição e coordenador mantêm contratos anteriores.

Testes: novo tests/test_preparacoes_cliente.py, **35 casos**, abrangendo os 16
cenários, seis corridas A–F, reprodução adicional AC3-D2 e 12 complementares.
Corrida F usa funções reais de login automático e conexão manual por AST,
concorrentes na mesma infraestrutura, com sockets/widgets falsos: identidades
independentes, pendentes antes do UDP e resultados preservados após liberação.
Também exercita main.iniciar encaminhando a infraestrutura real, publicação
atrasada/falha, dupla exceção, falhas pré/durante descoberta, recursos pendentes,
proprietários HTTP/arquivo distintos, ausência de thread/geração extra e consulta
passiva. Threads/barreiras existem somente nos ensaios.

Verificações: baseline **1633 testes simulados aprovados em 21,561 s**; após a
implementação os mesmos 1633 passaram sem alterações em 26,634 s. Bateria nova
isolada final **35 aprovados em 0,158 s**. Execução completa final:
`python -B -m unittest discover -s tests -q`: **1668 aprovados em 20,932 s**.
Nenhuma expectativa antiga adaptada. AST e espaços finais conferidos;
git diff --check sem erro, apenas avisos LF/CRLF preexistentes.

Hashes SHA-256 contra o estado anterior confirmam o recorte: novo registro,
infraestrutura, ponto de preparação em buscarservidor, novo teste e os dois
documentos. Composição e método avaliador da fachada, registros anteriores,
controles de leitor, main/interface, HTTP/JSON, protocolos, eleição e coordenador
preservados. AC3-D3-A concluída na fronteira segura de descoberta documentada;
acompanhamento não representa cancelamento ou encerramento consolidado completo.
Sem teste físico, commit, push ou empacotamento.

## AC3-D3-B1 — auditoria e protótipo de coerência temporal (2026-10-28)

Solicitação: auditar revisões existentes, reproduzir ABA e demonstrar um contrato
temporal verificável por fonte e inventário, isolado da aplicação. Escopo:
inspeção, protótipo experimental, novos testes e VALIDACAO/HISTORICO; nenhum
módulo operacional ou API pública alterado.

Auditoria documentada por domínio: atividades, guarda/associações de retries,
REGISTER, descoberta/CHECK por origem, CONFIG/tentativas, SUBSCRIBE, recursos,
HTTP, AC1-F1, preparação e inventário da infraestrutura. Sequências atuais
identificam operações/gerações/recibos, não todas as transições temporais.
Retratos compostos ainda consultam células e registros com locks distintos.
Não se encontrou contrato nativo de revisão suficiente para reutilizar como
garantia temporal completa; locks, identidades e retenções atuais devem ser
preservados na integração futura.

Implementado somente prototipos/coerencia_temporal_cliente.py: fontes escalares
experimentais com revisão monotônica e leitura coerente de selo/conteúdo;
inventário com revisão própria de inclusões/substituições/gerações/papéis;
consulta I0/V0/E/V1/I1. Contadores locais não são um contador global de eventos.
Fontes substituídas/gerações antigas permanecem coletadas. Mudança de fonte ou
inventário produz alterado; revisão ausente, regredida ou não confiável e erro
de consulta produzem desconhecido, sem validar coerência.

Escrita e revisão são protegidas pelo mesmo lock local. Confiança é retirada
antes da mudança e só restaurada após publicação válida; falha de publicação,
inclusive ausência silenciosa de incremento, deixa incerteza sticky. Escrita
posterior não a apaga. O avaliador apenas lê: não para, fecha gate/recurso,
observa thread, cancela callback, faz join ou espera estabilidade. Nenhum lock
global envolve a coleta. Exceções de consulta não expõem seu texto no resultado.

ABA real de usos 0→1→0 em recurso falso foi reproduzido mantendo retratos reais
iguais e módulos intactos. Modelo de admissão/recurso/preparação detecta mudanças
mesmo com pendentes 0→1→0; preparação pode mudar sem socket. Críticas também
cobrem nova geração/fonte, antiga alterada, falha após mudar estado, duas fontes
com escritores concorrentes e fonte pendente fora da cobertura.

Limite explicitado em VALIDACAO: estabilidade vale no intervalo comum delimitado
por selos confiáveis das fontes declaradas, sob o contrato de todos os escritores.
Mudança anterior ao primeiro selo ou posterior ao último pode ficar fora desse
intervalo, inclusive dentro da chamada do avaliador; ambos os limites têm testes.
Não é prova do estado no instante da resposta, snapshot atômico global, ausência
de caminho não inventariado ou encerramento. CLIENTE/global continuam False e
cobertura incompleta em todos os resultados experimentais.

Proposta B2/C documenta revisões locais, dependências/locks auxiliares, publicação
prévia de fontes em construção, inventário versionado, retenção de gerações,
falhas conservadoras e API temporal aditiva. Retratos atuais com validadores de
campos exatos devem continuar compatíveis; wrapper de getter/hash não substitui
instrumentação nativa do escritor. B2 deverá integrar em recortes pequenos;
AC3-D3-C incorporará revisões/preparação à composição posteriormente. AC4/AC5,
validação física e executável continuam futuros.

Verificações: baseline completo **1668 testes simulados aprovados em 15,584 s**.
Novo tests/test_coerencia_temporal_cliente.py: **41 testes**, com os 16 cenários,
sete verificações críticas e 18 complementares; execução isolada final em
0,071 s. Execução completa final
`python -B -m unittest discover -s tests -q`: **1709 aprovados em 20,591 s**.
Os 1668 anteriores permanecem sem adaptações. AST/espaços finais conferidos;
git diff --check sem erro, apenas avisos LF/CRLF preexistentes. Comparação SHA-256
com estado pré-tarefa confirma apenas novo protótipo, novo teste e estes dois
documentos; arquivos operacionais e testes anteriores preservados.
Sem teste físico, commit, push ou empacotamento.

## AC3-D3-B2-A — revisão temporal da preparação operacional (2026-10-28)

Solicitação: aplicar B1 a uma primeira fonte delimitada, com revisão monotônica,
estado/revisão coerentes, falhas conservadoras e API compatível; preservar os
demais registros, composição e coordenador. Fonte selecionada após auditoria:
RegistroPreparacoesCliente. Suas mutações locais compartilham lock; dependências
de recursos/buffers não têm revisão e foram explicitamente excluídas da garantia.

Implementado fonte_id por instância, revisão inteira iniciada em zero e confiança
temporal. Reserva, entrada, vínculo de origem, início/fim da publicação, resultado
e flags de falha avançam revisão quando há mudança efetiva sob o mesmo lock.
Consultas, recusas sem efeito e publicação idêntica não avançam. Não foram
adicionados threads, gerações, lock global ou inventário completo.

Consulta complementar: registro.obter_revisao e obter_evidencia_temporal,
encaminhada por infraestrutura.obter_evidencia_temporal_preparacoes. Envelope
traz selo e estado local juntos; não consulta recursos, não guarda handle/thread
ou textos operacionais, e declara dependencias_temporais_cobertas=False.
obter_preparacoes/obter_retrato mantêm campos e contrato anteriores, incluindo
suas dependências não versionadas. Apenas comparar o selo com esse retrato
composto não certifica estabilidade dos recursos.

Confiança é retirada antes da mutação e restaurada só após incremento válido.
Falha parcial/publicação incerta ou incremento silenciosamente ausente mantém
fonte não confiável; publicação posterior não limpa a incerteza. Finalização
preserva a instância e o traceback do erro operacional, separando erro adicional
como causa. Falha na entrada não executa o corpo. Histórico de A permanece após
promoção/B; publicação tardia de A avança revisão da fonte, sem reset.

Novo tests/test_revisao_preparacoes_cliente.py com 40 testes: 16 cenários, seis
corridas A–F, adicional da composição e 17 complementares. Verificam ABA,
leitura bloqueada somente pela seção crítica local, concorrência sem perder
incrementos, publicação tardia, falhas antes/depois de mutar/incrementar e na
finalização, preservação do traceback, consulta passiva/API legada e limite de
recursos externos. Socket fechado após preparação muda o retrato legado sem
mudar selo local: limite esperado, documentado. Composição não lê nova API,
não modifica revisões e não confirma CLIENTE/global.

Verificações: baseline completo **1709 testes simulados aprovados em 14,580 s**;
após instrumentação os mesmos 1709 aprovados sem adaptações em 12,981 s.
Bateria nova isolada **40 aprovados em 0,188 s**. Execução completa final:
`python -B -m unittest discover -s tests -q`: **1749 aprovados em 11,493 s**.
Nenhum teste antigo modificado. Conferência de sintaxe, whitespace e escopo
registrada em VALIDACAO. Mudanças limitadas à fonte selecionada, encaminhamento
passivo mínimo na infraestrutura, novo teste e estes documentos; protocolos,
outros registros, controles/leitor/guarda, HTTP/JSON, eleição/promoção, Tkinter,
composição e coordenador preservados. B2-B/B2-C/AC3-D3-C permanecem futuros.
Sem teste físico, commit, push ou empacotamento.

## AC3-D3-B2-B1 — revisão temporal da guarda de retentativas (2026-10-28)

Solicitação: instrumentar a guarda operacional do CLIENTE, incluindo os
publicadores privados AC2-B e observação explícita, preservando API legada,
partidas ambíguas, gerações antigas e independência dos recursos AC2-C.
Confirmado que a infraestrutura usa diretamente GuardaRetentativasCliente de
prototipos/guarda_retentativas_cliente.py; não há cópia operacional separada.

Auditoria e tabela de transições em VALIDACAO abrangem gerações/papéis, reservas,
gate/parada, fases de partida, thread/start, entrada/retorno/invalidação privada,
ausência comprovada, observação/término/erro, autorizações secundárias e suas
fases de publicação/resolução/limpeza. A sequência de IDs foi preservada e não
é utilizada como revisão. Campos privados que influenciam decisões futuras
participam da detecção de alteração efetiva.

Implementado fonte_id próprio por guarda, revisão inteira monotônica e selo de
confiança. As seções locais já protegidas por lock comparam valores antes/depois
e avançam somente quando mudam. Thread é comparada por identidade interna,
sem igualdade nem observação. Fábrica, start, alvo, is_alive, publicadores e
limpadores continuam fora do lock. Fonte/registros novos têm identidades
distintas; promoção e novas gerações não reiniciam revisão da guarda retida.

obter_revisao e obter_evidencia_temporal são complementares e passivos.
infraestrutura.obter_evidencia_temporal_retentativas encaminha a guarda original
e aplica o ID da instalação. Formato legado permanece exatamente igual; novo
envelope inclui gerações sem reservas e publicações tentadas, com dependências
temporais não cobertas, cobertura incompleta e CLIENTE/global False. Não consulta
associações ou recursos e não executa observação de thread.

Mudanças parciais/falhas de publicação/incremento invalidam confiança de forma
sticky, sem reparação automática. Erro original e traceback são preservados,
com falha adicional separada como causa. Há proteção conservadora mesmo quando
o próprio invalidador falha antes de publicar suas flags. Número de revisão
isolado não autoriza estabilidade quando confiavel=False.

Novo tests/test_revisao_guarda_retentativas_cliente.py: 41 testes simulados,
incluindo 16 cenários, seis corridas, adicional AC2-C e 18 complementares.
Verificam reserva/leitura coerentes, entrada antes de start retornar, ABA,
retorno antigo após promoção/B, falha após mutação e dois observadores com um
único avanço real. Caso completo start inicia alvo, entrada é publicada e start
lança: ambiguidade e origem preservadas; retorno tardio avança revisão sem
antecipar término. Também cobre erros e contradições de observação, secundárias,
idempotência, dupla falha/traceback e consulta passiva/API legada.

Teste adicional usa recuperação real AC2-C com transporte falso, retém UDP,
conclui/observa a retry e só depois limpa o recurso. Associação externa muda,
selo da guarda permanece igual e consolidação continua não confirmada. Este
limite impede afirmar que a revisão da guarda versiona sockets ou adaptadores.

Verificações: baseline completo **1749 testes simulados aprovados em 14,809 s**;
após instrumentação os mesmos 1749 aprovados sem adaptações em 17,841 s.
Bateria nova isolada final **41 aprovados em 0,068 s**. Execução final
`python -B -m unittest discover -s tests -q`: **1790 aprovados em 23,484 s**.
AST/espaços finais conferidos; git diff --check sem erro, apenas avisos LF/CRLF
preexistentes. Hashes SHA-256 confirmam guarda, encaminhamento passivo mínimo,
novo teste e os dois documentos; testes anteriores, preparação, recursos,
atividades permanentes, controles, adaptadores AC2, protocolos, HTTP/JSON,
composição, eleição/promoção, Tkinter e coordenador preservados.
Conteúdo histórico e mudanças prévias do workspace mantidos. B2-B2/B2-B3/B2-B4,
B2-C e AC3-D3-C seguem futuros, sem inventário global ou composição temporal
antecipados. Sem teste físico, commit, push ou empacotamento.

## AC3-D3-B2-B2 — revisão temporal das atividades permanentes (2026-10-28)

Solicitação: instrumentar exclusivamente o registro permanente do CLIENTE,
preservando AC3-C1, partidas ambíguas, observação explícita, gerações antigas,
API legada e fronteiras de recursos/controles. Auditoria em VALIDACAO identifica
as transições locais: origens, retenção REGISTER, reserva/gate/reivindicação,
thread/start, entrada, retorno/diagnóstico, resolução/invalidação da partida,
ausência comprovada e observação/erro/contradição.

Implementado em rede/atividades_permanentes_cliente.py fonte_id próprio,
revisão monotônica e confiança temporal. Publicações sob o lock local comparam
estado anterior/posterior e avançam apenas com mudança efetiva. Referências a
thread/controle são comparadas por identidade, sem callbacks. Construção, start,
alvo e is_alive continuam fora do lock; não há lock global nem join na consulta.
Origens/atividades antigas e identidade da fonte persistem após promoção/B.

Consultas complementares obter_revisao/obter_evidencia_temporal e encaminhamento
passivo mínimo obter_evidencia_temporal_atividades_permanentes na infraestrutura.
Envelope junta selo/retrato local e expõe origens/vínculos retidos sem ler estado
interno dos controles. Formato legado permanece intacto. Dependências não cobertas,
cobertura incompleta e CLIENTE/global negativos continuam explícitos.

Mutação parcial, revisão ou publicação defeituosa invalidam confiança de forma
sticky, sem reset/reparação automática. Falha adicional no diagnóstico, contador
ou invalidador não substitui a instância/traceback operacional original; erro
adicional é separado como causa. Fallback independente mantém selo indisponível
se a própria invalidação falhar. Número de revisão isolado não prova estabilidade.

Novo tests/test_revisao_atividades_permanentes_cliente.py: 41 testes, com os 16
cenários, seis corridas, adicional SUBSCRIBE e 18 complementares. Caracterizam
leitura coerente, entrada antes da partida publicada, ABA, promoção com retorno
tardio, falha parcial e dois observadores com um único avanço. Start entra e
lança enquanto alvo continua: entrada/ambiguidade preservadas, retorno revisado
e término confirmado apenas por observação explícita posterior.

Adicional utiliza iniciar real do leitor com thread/transporte falsos e controle
SUBSCRIBE real: socket/arquivo ficam pendentes depois de retornar e observar a
thread; cleanup posterior altera recursos sem mudar revisão permanente.
REGISTER/CONFIG/SUBSCRIBE internos também não avançam o selo por mera mudança
de controle. Composição não consulta nova API nem produz confirmação consolidada.

Verificações: baseline **1790 testes simulados aprovados em 15,658 s**;
após instrumentação os mesmos 1790 aprovados sem adaptações em 11,868 s.
Bateria nova isolada final **41 aprovados em 0,059 s**. Execução completa final
`python -B -m unittest discover -s tests -q`: **1831 aprovados em 11,548 s**.
Nenhum teste antigo adaptado. Conferências de AST, whitespace e hashes do recorte
registradas em VALIDACAO. Mudanças limitadas ao registro permanente, encaminhamento
passivo na infraestrutura, novo teste e estes documentos. Preparação, guarda,
controles, recursos, leitor/protocolos, HTTP/JSON, eleição/promoção, composição,
Tkinter e coordenador preservados; histórico e alterações prévias mantidos.
B2-B3/B2-B4, B2-C, AC3-D3-C e AC4/AC5 seguem futuros. Sem teste físico, commit,
push ou empacotamento.

## AC3-D3-B2-B3-A — fonte temporal REGISTER por geração (2026-10-28)

Solicitação: integrar revisão monotônica exclusivamente ao controle REGISTER,
mantendo admissão/parada atômicas, operações antigas, handles incertos,
retratos legados e recursos externos independentes; executar os 16 cenários,
seis corridas e teste adicional, sem ampliar a composição temporal.

Resultado: AdmissaoRegisterCliente possui fonte_id por instância, revisão inicial
zero e APIs passivas obter_revisao/obter_evidencia_temporal. Gate, admissões,
início/saída, dono, resultado/erros, vínculos e retenção local de handles incertos
publicam suas mudanças com a revisão sob o mesmo lock. Contexto privado no
próprio arquivo cobre as pequenas escritas herdadas do buffer e os vínculos,
sem alterar o registro de recursos. Fábricas, IO e cleanup seguem fora do lock.
Idempotência, recusa sem efeito e consultas não avançam a revisão. Fechamento
preserva autorizações antigas; promoção/criação de B mantém A retida e com
identidade independente.

Falha de publicação ou acompanhamento após mutação invalida a confiança de
forma persistente. Erro operacional conserva instância e quadros do traceback;
falhas adicionais ficam encadeadas e separadas em atributo privado da exceção,
sem textos/objetos operacionais nos retratos. Uma falha exclusivamente funcional
com resultado corretamente publicado não invalida sozinha o selo local.

Infraestrutura apenas encaminha obter_evidencias_temporais_register para os
controles retidos. O retrato legado permanece intacto; a nova evidência copia
somente estado local, sem consultar recursos, observar thread ou limpar.
Limpeza exclusiva do TCP não muda o selo REGISTER; mudanças na retenção própria
de handles incertos mudam. A lista não é inventário versionado, não há snapshot
atômico global nem dependências temporalmente cobertas. Composição permanece
inalterada e não consulta a nova API; nenhuma confirmação consolidada adicionada.
Comparar projeções locais tem custo linear no estado retido, sem benchmark.

Verificações: baseline **1831 testes simulados aprovados em 14,669 s**; após
instrumentação, os mesmos **1831 sem adaptações em 11,012 s**. Novo arquivo
test_revisao_admissao_register_cliente.py: **40 aprovados em 0,193 s**, com os
16 cenários em ordem, seis corridas (duas ordens para admissão/parada e falha
parcial com consulta concorrente) e REGISTER pelo caminho real com transporte
falso e limpeza TCP posterior independente. Complementares verificam buffer
herdado, vínculos, falhas de revisão, traceback, múltiplos erros adicionais,
passividade, cópias defensivas e composição negativa.

Execução completa final, python -B -m unittest discover -s tests -q:
**1871 testes simulados aprovados em 12,304 s**. Nenhum teste anterior adaptado.
AST, whitespace e comparação SHA-256 do recorte registrados em VALIDACAO.
Alterações somente em rede/admissao_register_cliente.py, encaminhamento mínimo
em rede/infraestrutura_cliente.py, novo teste e estes dois documentos. Demais
fontes, controles, recursos, protocolos, promoção/eleição, UI e coordenador
preservados, assim como os prefixos históricos e as alterações prévias locais.
CONFIG, SUBSCRIBE, descoberta/CHECKs, recursos, inventário e composição temporal
permanecem próximos recortes. Sem teste físico, commit, push ou empacotamento.

## Marco de entrega — mudança de prioridade e auditoria de prontidão (2026-10-28)

Solicitação: suspender expansão temporal depois do REGISTER e classificar as
pendências como bloqueadoras, importantes sem bloquear o primeiro ensaio e
aprimoramentos futuros; priorizar interface, encerramento e teste com TC420,
mantendo o executável para depois. A sequência anterior de revisões deixa de
ser uma condição automática de avanço.

Criado PRONTIDAO.md como plano vigente com três grupos de bloqueadores
confirmados por código: falta de saída nos monitores criados pelo main;
coordenação operacional incompleta/aceite do evento legado de retorno como
encerramento; IO síncrono no Tk e callbacks tardios sem proteção suficiente.
Cada grupo tem critério finito de aceite. Preservada a distinção entre terminar
os donos operacionais acompanhados e provar encerramento global; desconhecido
continua desconhecido, sem exigir expandir revisões para iniciar o ensaio.

Classificadas também convergência visual, dados antigos, HTTP interno, arquivos
com associação desconhecida, ocultação, concorrência de principais e validação
no equipamento. Falhas reais reproduzidas continuam exigindo correção; revisões
de fontes restantes, inventário versionado, composição temporal completa e
certificação formal ficam adiados. Caminho TCP direto legado fica fora do
ensaio inicial. Definido roteiro físico controlado com casos de leitura,
cliente, perda/retorno, promoção/rebaixamento, parada e reabertura.

README e OPERACAO apontam ao novo plano; VALIDACAO registra evidências e limites.
Verificações: revisão de código/testes de caracterização, AST dos callbacks de
saída e busca da integração ausente do coordenador experimental. Bateria
completa: **1871 testes simulados aprovados em 11,319 s**, sem testes novos ou
adaptações. Código operacional preservado; hashes e whitespace conferidos.
Esta solicitação concluiu a revisão e documentação, não as correções dos três
bloqueadores. Sem Tk real, teste físico, commit, push ou executável.

## B1 — saída encaminhada por um proprietário por execução (2026-10-28)

Solicitação: instalar ao_fechar em todos os monitores, preservar CANCELAR,
encaminhar SIM ao dono correto, deduplicar solicitações e impedir callback
antigo de controlar geração/janela substituta. Não antecipar B2, destroy ou
saída de processo sem comprovação operacional.

Criado interface/saida_aplicacao.py com SaidaAplicacao e callbacks revogáveis
por substituição de vínculo. Primeiro pedido registra intenção e invoca uma
vez o destino capturado, fora do lock; outros pedidos retornam False. Falha
conserva pendência e categoria sanitizada. Novo vínculo depois da solicitação
é recusado. Nenhuma certificação global ou revisão temporal adicionada.

main cria uma instância por execução, compartilha nos caminhos cliente/manual
e passa callbacks aos dois monitores. Cliente encaminha ao leitor capturado;
promoção mantém o mesmo proprietário. Principal automático sem destino seguro
apenas registra intenção pendente. Monitor manual recebe vínculo próprio,
revogando o anterior da conexão, e usa o encerramento legado como destino.

JanelaConexao mantém a solicitação/parada existentes, mas não aceita mais o
evento de retorno da rotina servidor como comprovação de saída da aplicação
nas instâncias construídas com esse proprietário. Polling fica pendente da B2,
sem destroy; a confirmação direta é recusada e finalizacao_confirmada permanece
falsa. Responsabilidade pelo servidor promovido, leitor rebaixado, gates e
todos os demais donos continua B2. Rede síncrona/callbacks tardios continuam B3.

Verificações: 17 testes novos de entradas reais simuladas, manual ativo,
promoção, SIM/NÃO/CANCELAR, substituição, concorrência e falha. Casos de auditoria
20/21/25 preservados; 22/23/24 adaptados para a proteção contra conclusão
prematura. Assinatura/injeção de proprietário exigiram atualização em dois
outros casos antigos. Nenhuma família nova de auditoria ou etapa temporal.

Bateria isolada: **17 aprovados em 0,161 s**. Completa final:
**1888 testes simulados aprovados em 14,350 s**, mantendo os 1871 casos
anteriores com adaptações funcionais justificadas em VALIDACAO. AST,
whitespace e hashes do recorte conferidos. PRONTIDAO, README, OPERACAO, API e
MODULOS atualizados, além de VALIDACAO e deste histórico. B1 concluída como
encaminhamento seguro; saída efetiva permanece pendente da B2. Sem ensaio
visual/Tk real, teste físico, commit, push ou executável.

## B2 — coordenação operacional de entrega (2026-10-28)

Solicitação: integrar o proprietário B1 à parada de todos os donos conhecidos,
fechar novas admissões, interromper/limpar recursos e observar término com prazo
fora do Tk. Concluir interface somente com evidência operacional, mantendo a
composição global conservadora; timeout/falha deve permitir reavaliação explícita
sem duplicar limpeza ativa. Preservar protocolos, peso, eleição e plano finito.

SaidaAplicacao agora retém leitores, registros de tentativas, contextos de ciclos,
inicializações e partidas. A infraestrutura fixa o proprietário da execução;
main/conexão compartilham-no e mantêm gerações antigas, promoção e rebaixamento.
Trabalho novo é recusado depois de SIM. Gates existentes fecham antes do cleanup;
falha de um gate não impede tentar os outros ou solicitar parada dos donos.

Executor de coordenação e tarefas de limpeza usam workers, sem IO/join no Tk.
Prazo padrão 10 s por tentativa, observação limitada, timeout/falha sanitizados
e retry explícito. Tarefa ainda ativa ou start incerto não é duplicado. Resultado
parada_operacional_confirmada permite conclusão via after no Tk; certificados
encerramento_confirmado/global permanecem False. Aviso informa pendência sem
texto de exceção. O evento servidor_encerrado sozinho não autoriza saída.

Servidor recebe parada por ciclo, protegida contra identidade divergente e clear
tardio. Registros de trabalhadores/handlers continuam exigidos. Corrida concreta
corrigida: joins apenas em trabalhadores efetivamente iniciados, incluindo a
guarda do observador automático recusado. Leitor com entrada tardia não reabre
execução. Recursos e retenções são limpos fora dos locks, sem inventar associação;
erros de cleanup e operações ativas permanecem negativos. Primeiro erro é
preservado quando a interrupção e o cleanup também falham.

Coordenador experimental avaliado, mantido separado porque seu positivo exige
cobertura global/inventário não obtidos. Reutilizados gates, observadores e
avaliações individuais já implementados; nenhuma revisão temporal nova.

Verificações: baseline **1888 aprovados em 13,259 s**. Novo arquivo B2 com os
15 cenários obrigatórios e 25 complementares: **40 aprovados em 2,632 s** no
ensaio isolado. Completa final **1928 testes simulados aprovados em 15,058 s**.
Quatro casos B1 adaptados ao executor e um caso de refresh mantém sua auditoria
restrita ao callback correspondente; casos 20–25 da auditoria de encerramento
preservados. AST, whitespace, hashes e diff conferidos em VALIDACAO.

PRONTIDAO e documentos temáticos afetados atualizados. B1/B2 concluídas nos
escopos descritos; B3 permanece o único bloqueador planejado antes do ensaio
visual, da TC420 física e do executável posterior. Não houve Tk real, ensaio
visual/físico, commit, push ou .exe.

## B3 — interface responsiva e callbacks seguros — 28/10/2026

Solicitação: corrigir o último bloqueador planejado, retirando descoberta/login/
approval e promoções do loop Tk, protegendo resultados antigos e agendamentos,
sem regressão de B1/B2 ou nova família de instrumentação temporal. Preservar os
1928 testes anteriores, acrescentar os 16 cenários obrigatórios e manter o prazo
de 10 s por tentativa de saída. Sem ensaio visual/físico ou executável nesta etapa.

Resultado: CicloTk centraliza fila, identidade das operações e agendamentos.
CONECTAR coleta campos no Tk e executa rede/persistência/partida no worker;
promoção manual/automática segue o mesmo modelo. Todo worker é registrado em
B2 antes de start. A autorização de partida verifica parada, cancelamento e
vínculo atual sob o lock do proprietário; trabalho já admitido continua retido.
Contextos de promoção não são mais associados ao monitor a partir do worker.

Agendamentos de peso, candidatura, rebaixamento, contexto e resultado são
protegidos e cancelados/invalidados no fechamento. A observação de saída continua
ativa durante B2 para confirmação, diagnóstico e retry. Peso/refresh protegem
root e labels; TclError de programação não é escondido genericamente. A tela de
conexão confirma saída no botão de fechar. A passagem para cliente ocorre após
retornar do mainloop anterior, sem aguardar CONFIG dentro desse loop.

Verificações: baseline **1928 testes simulados aprovados em 18,995 s**.
Novo arquivo test_interface_b3.py com **26 casos**, incluindo os 16 pedidos e
dez adicionais, aprovado isoladamente em **0,371 s**. A regressão conserva os
1928 casos anteriores com adaptações funcionais em 13 arquivos de testes;
os casos 20–24 da auditoria de encerramento e os arquivos B1/B2 não mudaram.
test_25 passa a exigir ausência de acesso após parada. Transporte HTTP usa
executor imediato controlado nas caracterizações antigas; a concorrência real
da interface é exercitada separadamente com eventos e guardas de thread Tk.
Regressão completa: **1954 testes simulados aprovados em 15,889 s**, unittest
com código de saída zero. AST/whitespace e git diff --check aprovados, somente
avisos de conversão LF/CRLF preexistentes. SHA-256 confirmou o escopo e preservou
os prefixos históricos anteriores de HISTORICO/VALIDACAO.

PRONTIDAO, VALIDACAO, API, arquitetura, métodos da janela, módulos, operação e
README atualizados. B1/B2/B3 concluídas nos escopos descritos; ensaio visual real
é o próximo passo ainda pendente, seguido da TC420 física e depois do .exe.
Certificação global permanece desconhecida. Inicialização anterior à primeira
janela continua síncrona; o TCP direto legado permanece fora do ensaio inicial.
Sem expansão temporal, Tk real, teste físico, commit, push ou executável.

## Preparação e abertura do ensaio visual Tk — 29/10/2026

Solicitação: iniciar o primeiro ensaio visual real após B1/B2/B3, usando widgets
Tkinter e as classes reais da tela de conexão e monitor, com todas as dependências
externas simuladas. O roteiro cobre abertura, demora, sucesso, atualização,
timeout, promoções, diálogos de fechamento, retorno tardio, timeout B2 e reabertura.

Foi adicionado `tests/ensaio_visual_tk.py`. O harness não executa `main.py`, não
usa credenciais ou configuração persistida, não cria WebTC420/servidor e não abre
sockets/portas do aplicativo. Os campos contêm valores de ensaio, workers usam
atrasos controlados e peso/configuração vêm de memória. O painel auxiliar oferece
ações, log, dez marcações e cópia do resultado; as janelas exercitadas são as
classes operacionais reais.

Verificações: compilação Python e análise AST aprovadas; ausência de imports de
main/socket/requests/keyring e das portas reais confirmada; diff do novo arquivo
sem erro. A regressão completa permaneceu em **1954 testes simulados aprovados em
27,203 s**. O harness gráfico foi aberto no Windows com autorização para GUI.
A tentativa somente de diagnóstico por CIM recebeu “Acesso negado”, sem impacto
na abertura e sem uso como prova.

O ensaio visual permanece aberto e **não foi declarado aprovado**: aparência,
responsividade e os dez itens dependem da observação e do checklist do responsável.
Após receber o log copiado, registrar o resultado final e qualquer defeito concreto.
Sem teste físico, TC420, commit, push ou geração de `.exe` nesta solicitação.

## Reinício do ensaio visual Tk — 29/10/2026

Solicitação: reiniciar o ensaio porque a primeira execução possivelmente não
seguiu o roteiro na ordem correta. A instância anterior já não existia quando o
PID registrado foi consultado; portanto, nenhum processo adicional foi encerrado.

Uma nova execução limpa de `tests/ensaio_visual_tk.py` foi aberta no Windows às
07:54:54, PID 23780. A consulta após a partida confirmou `Responding=True`.
Checklist, proprietário B1/B2, operações B3, fonte simulada e janelas começaram
novamente do estado inicial. Nenhum arquivo operacional foi alterado neste
reinício e a bateria automatizada não foi repetida, pois o mesmo harness já havia
sido compilado e a regressão de 1954 casos havia passado imediatamente antes.

O resultado visual continua pendente: reiniciar o processo não aprova nenhum dos
dez itens. Sem conexão física, credenciais, servidor real, commit, push ou `.exe`.

## Segundo reinício para confirmar timeout B2 — 29/10/2026

Solicitação: reiniciar novamente porque o comportamento da operação longa pode
ter apresentado uma falha, mas o responsável deseja reproduzi-la em estado limpo
antes de registrar um defeito. O PID 23780 da execução anterior já não existia;
nenhuma terminação forçada foi necessária.

Uma terceira execução limpa do harness foi aberta às 08:03:41, PID 23296. A
consulta após a partida confirmou `Responding=True`. O objetivo desta execução é
isolar “Operação longa (12 s)”: primeiro SIM deve produzir timeout B2 após cerca
de 10 s e conservar a janela; depois do retorno do worker, um novo SIM deve
reavaliar a parada sem duplicar o trabalho e permitir a conclusão comprovada.

Nenhum defeito foi registrado apenas pela suspeita. A classificação depende da
nova observação e do log copiado. Sem mudança de código operacional, teste físico,
credenciais, servidor real, commit, push ou `.exe`.

## Checklist visual recebido e correção da reabertura — 29/10/2026

O responsável enviou checklist com dez marcações. O log anexado sustenta os nove
primeiros comportamentos: janelas reais abertas, interface responsiva durante
workers, monitor e valores atualizados, falha sanitizada, promoções, CANCELAR/NÃO,
SIM e timeout/retry. O anexo não contém `TclError`, mas termina com traceback
`RuntimeError: saida_ja_solicitada` ao tentar abrir monitor novamente.

O item 10 não foi aprovado com esse log. A causa foi localizada no harness:
“Abrir monitor” reutilizava o `SaidaAplicacao` cuja intenção de saída é permanente,
enquanto uma nova execução real deve criar outro proprietário. Não foi encontrada
evidência de regressão no código operacional por esse traceback.

Foi corrigido somente `tests/ensaio_visual_tk.py`. Abertura após parada agora é
recusada com mensagem, sem exceção; “Reabrir execução” encerra o conjunto antigo,
faz o mainloop retornar e cria outro harness completo no mesmo processo. A
compilação, AST e diff passaram. O PID antigo 23296 exigiu encerramento elevado
por ter sido aberto fora do sandbox. A versão corrigida foi iniciada às 10:57:34,
PID 23532, para repetir apenas fechamento e reabertura.

Situação: **nove itens sustentados e item 10 pendente de nova observação**. A
validação física não foi iniciada. Sem credenciais, servidor real, commit, push
ou `.exe`.

## Nova abertura do ensaio visual corrigido — 30/10/2026

Solicitação: executar novamente o ensaio porque o responsável precisou sair e não
pôde testar a versão corrigida. O PID anterior 23532 já não existia, portanto
nenhum processo foi encerrado.

Uma nova execução de `tests/ensaio_visual_tk.py` foi iniciada às 07:52:32, PID
2596. A enumeração de aplicativos do Windows confirmou as janelas reais
`PRIX TC420 - Conexão` e `Controle — ensaio visual offline`, além do console do
processo. O painel foi elevado e a árvore de acessibilidade confirmou a janela
ativa. A captura gráfica do painel expirou no mecanismo de automação; isso não é
usado como aprovação visual e não encerrou o processo.

O código executado já contém a correção de reabertura: uma execução parada não
recebe novo vínculo, e “Reabrir execução” cria outro proprietário e outro conjunto
de janelas após o retorno do mainloop. O item 10 continua aguardando a observação
do responsável. Sem TC420, credenciais, servidor real, commit, push ou `.exe`.

## Esclarecimento da segunda tentativa após timeout — 30/10/2026

O responsável informou que, depois de fechar o monitor e escolher SIM, não surgiu
automaticamente outra opção SIM. A enumeração do Windows mostrou que a execução
já havia sido encerrada antes da inspeção, portanto não houve estado vivo para
diagnosticar naquele momento.

O contrato foi esclarecido: B2 não reabre sozinho o diálogo de decisão. O primeiro
SIM inicia a tentativa; o timeout mantém a janela e mostra o aviso. Depois que o
worker de 12 s termina, o usuário precisa clicar novamente no X do monitor para
abrir outro diálogo SIM/NÃO/CANCELAR e escolher SIM. Essa ação explícita é a nova
tentativa prevista por B2.

O texto do painel e o log inicial da operação longa foram atualizados para dizer:
após o aviso, aguardar 3 s, clicar novamente no X e escolher SIM. Não houve mudança
no coordenador ou no código operacional. O ensaio permanece pendente e será
reaberto com a orientação corrigida. A nova execução foi iniciada às 07:58:40,
PID 17032. O Windows confirmou as janelas `PRIX TC420 - Conexão` e
`Controle — ensaio visual offline`; o painel foi elevado e recebeu foco. Sem
TC420, commit, push ou `.exe`.

## Correção do tempo da operação longa visual — 30/10/2026

O responsável informou que o aviso de timeout não apareceu. A inspeção das
janelas mostrou conexão e painel ativos, mas nenhum monitor. A causa foi localizada
no harness: o worker durava 12 s desde o clique no painel, enquanto o prazo de B2
começa somente no SIM. Se o diálogo levasse mais de 2 s, o worker terminava antes
dos 10 s da coordenação; B2 confirmava corretamente a parada e fechava o monitor,
sem produzir timeout. Portanto, o resultado não reproduzia o cenário pretendido.

`tests/ensaio_visual_tk.py` passou a usar um evento controlado. O worker permanece
ativo até o painel observar `estado=timeout`; três segundos depois, o evento é
liberado. O teste não depende mais da velocidade do usuário, não duplica worker e
libera o evento ao encerrar o harness. Painel, log e OPERACAO foram atualizados.
O coordenador B2 e os arquivos operacionais não foram alterados. Pendente executar
novamente o cenário determinístico. A versão corrigida foi aberta às 08:03:41,
PID 14188; o Windows confirmou as janelas de conexão e painel, e o painel foi
elevado. Sem TC420, commit, push ou `.exe`.

## Reabertura solicitada do ensaio determinístico — 30/10/2026

Solicitação: abrir novamente o ensaio visual. O PID anterior 14188 já estava
encerrado. Uma execução limpa da versão com worker controlado foi iniciada às
08:08:12, PID 7416. O Windows confirmou `PRIX TC420 - Conexão`,
`Controle — ensaio visual offline` e o console do processo; o painel foi elevado
e recebeu foco.

Nenhuma mudança adicional de código foi necessária nesta solicitação. O resultado
do timeout determinístico e da reabertura continua pendente da observação do
responsável. Sem TC420, credenciais, servidor real, commit, push ou `.exe`.

## Ensaio visual offline aprovado — 30/10/2026

O responsável repetiu o cenário determinístico e informou **“passou”**. A
operação controlada permaneceu ativa até o timeout de B2, o monitor foi preservado,
o worker foi liberado depois, e um segundo pedido explícito pelo X permitiu a
conclusão. A reabertura criou uma nova execução sem traceback ou `TclError`.

A enumeração do Windows após a confirmação encontrou novamente as janelas
`PRIX TC420 - Conexão` e `Controle — ensaio visual offline`, coerente com o item
de reabertura. O checklist visual passa a **10/10 aprovado**. As falhas anteriores
do harness — reutilização de proprietário encerrado e janela temporal insuficiente
de 12 s — permanecem documentadas e foram corrigidas antes desta aprovação.

B1, B2, B3 e o ensaio visual estão concluídos nos limites testados. O próximo
marco é a validação física com TC420 e computadores na rede. Ela não foi iniciada;
não há afirmação de compatibilidade física, certificação global ou prontidão de
produção. Sem commit, push ou geração de `.exe`.

## Preparação da validação física — Teste 1 PRINCIPAL — 30/10/2026

Solicitação: encerrar o ciclo visual e iniciar exclusivamente a preparação do
primeiro teste físico, com um computador PRINCIPAL. O harness PID 7416 foi
encerrado. Computer Use confirmou que não restaram janelas Python e a consulta de
processos não encontrou `python`/`pythonw` ativos.

A configuração local foi inspecionada sem imprimir valores: arquivo presente,
IP configurado, usuário configurado e porta válida. `salvar_login=False`; nenhuma
senha, token, IP ou usuário foi incluído nos resultados ou documentos.

O checklist físico está em **1/8**: limpeza do ensaio offline concluída. A etapa
parou antes de qualquer tráfego ou execução de `main.py`, aguardando confirmação
humana de autorização, disponibilidade da TC420 e condição não crítica. Não houve
teste de conectividade, autenticação, approval, leitura física, commit, push ou
`.exe`.

## Teste físico 1 iniciado — PRINCIPAL — 30/10/2026

O responsável confirmou que a TC420 estava autorizada, disponível e fora de
operação crítica. A primeira tentativa local de conectividade não enviou pacote:
uma precedência incorreta no cast PowerShell produziu porta zero e foi recusada
por `Test-NetConnection`. Os nomes/tipos das chaves foram conferidos sem mostrar
valores; repetido com parênteses corretos, o teste TCP retornou porta configurada
válida e acessível.

`python -B main.py` foi iniciado pela raiz às 08:18:09, PID 11064. Inicialmente
apenas o console apareceu durante a descoberta síncrona documentada. Na consulta
seguinte, o Windows confirmou `PRIX TC420 - Conexão`. Nenhum valor de IP, porta,
usuário ou senha foi exibido. Como `salvar_login=False`, a autenticação aguarda
entrada direta do responsável na janela.

Checklist físico: **4/8** — limpeza, autorização, conectividade e execução
confirmadas. Login/approval, comparação de dados, mudança controlada de peso e
saída por SIM permanecem pendentes. Sem segundo computador, commit, push ou `.exe`.

## Monitor físico PRINCIPAL aberto — 30/10/2026

O responsável relatou: “O monitor abriu com peso e configuração”. O resultado
confirma que a autenticação/approval desta execução alcançou o monitor real do
modo PRINCIPAL. A tentativa de confirmação complementar pela enumeração de
janelas da sessão do Codex não encontrou a janela Tk; portanto, o registro se
baseia explicitamente na observação visual humana e não atribui valores ou
estados que ainda não foram comparados.

O checklist físico avançou para **5/8**. Permanecem pendentes: comparar peso,
tara, unidade, estabilidade e W1.1/W1.2 com o terminal da TC420; realizar uma
mudança controlada de peso; e solicitar a saída por SIM, verificando a conclusão
operacional. Não houve mudança de código, segundo computador, commit, push ou
geração de `.exe` nesta solicitação.

Na verificação imediatamente posterior, o PID 11064 não existia mais, não havia
processos `python`/`pythonw` ativos e a janela não foi localizada pela enumeração
disponível. Assim, a abertura permanece confirmada pela observação do responsável,
mas a permanência do monitor precisa de confirmação humana antes do próximo passo.
Nenhuma causa de encerramento foi inferida e nenhuma saída operacional foi
declarada aprovada.

## Esclarecimento sobre o monitor fechado — 30/10/2026

O responsável informou que o monitor não estava mais aberto porque ele próprio
o havia fechado. A ausência do PID, dos processos Python e da janela fica assim
explicada por uma ação humana, sem evidência de queda espontânea do aplicativo.

O resultado preservado é: autenticação/approval e abertura do monitor PRINCIPAL
foram observados. Permanecem não verificados a comparação completa com o terminal
físico, a atualização após mudança controlada de peso e o encerramento formal por
SIM com comprovação operacional. Nenhuma mudança de código, commit, push ou `.exe`.

## Aprovação do Teste físico 1 — PRINCIPAL — 30/10/2026

O responsável informou que os três itens anteriormente pendentes já haviam sido
realizados e passaram: comparação dos dados exibidos com o terminal da TC420,
mudança controlada de peso com acompanhamento no monitor e saída por SIM com
conclusão operacional. Combinados aos cinco itens já registrados, o checklist do
PRINCIPAL sozinho foi encerrado em **8/8 aprovado**.

Essa aprovação é evidência observacional do equipamento real nas condições do
ensaio; não é resultado simulado. Ela não foi estendida ao cenário CLIENTE,
recuperação de rede, promoção/rebaixamento, certificação global ou produção. Não
houve mudança de código, nova execução da regressão, commit, push ou `.exe`. O
próximo passo planejado é o Teste físico 2 com um segundo computador CLIENTE.

## Início do Teste físico 2 — PC A — 30/10/2026

Solicitação: iniciar o ensaio de comunicação entre um PRINCIPAL e um CLIENTE,
começando exclusivamente pelo PC A e sem mudanças preventivas de código. A
verificação local encontrou zero processos Python e nenhuma ocupação TCP nas
portas 42100/42101 ou UDP na porta 42101.

`python -B main.py` foi aberto pela raiz, PID 22712. A janela real
`PRIX TC420 - Conexão` foi confirmada pela enumeração do Windows. O checklist do
Teste 2 segue em **0/10** até a preparação dos dois computadores ser confirmada
e o PRINCIPAL estar autenticado com leitura real estável. Credenciais permanecem
sob entrada direta do responsável. Sem alteração de firewall, código, commit,
push ou `.exe`.

## Reinício do Teste físico 2 após congelamento — 30/10/2026

O responsável relatou que a conexão manual iniciou dados da TC420 e o servidor,
mas a interface congelou na primeira coleta. Ao receber a solicitação de reinício,
o PID 22712 já estava encerrado e as portas TCP 42100/42101 e UDP 42101 estavam
livres. Não foi necessário forçar o término de nenhum processo.

Uma nova execução de `python -B main.py` foi iniciada, PID 22708. Cinco segundos
depois, o processo constava ativo e responsivo, e o Windows confirmou
`PRIX TC420 - Monitor`. A recorrência do congelamento ainda está sendo observada;
o PC B não foi iniciado, o checklist continua em 0/10 e nenhuma alteração de
código, firewall, commit, push ou `.exe` foi realizada.

## Terceira execução do PC A — Teste físico 2 — 30/10/2026

O responsável informou que a segunda execução não travou e pediu nova repetição.
No momento do reinício, o PID 22708 já não existia e as portas 42100/42101 estavam
livres. Uma terceira execução foi aberta, PID 22008. Após cinco segundos, o
Windows registrava o processo ativo e responsivo, com a janela
`PRIX TC420 - Conexão` visível.

A terceira primeira coleta ainda não foi observada. Assim, há uma ocorrência de
congelamento na tentativa inicial e uma tentativa posterior estável, sem causa
determinada ou correção aplicada. O PC B não foi iniciado; sem alteração de código,
firewall, commit, push ou `.exe`.

## Terceira coleta e conexão de cliente observadas — 30/10/2026

Após o responsável inserir a credencial diretamente, a terceira execução abriu
o monitor. O console confirmou autenticação, configuração W1.1/W1.2, comunicação
HTTP saudável, leituras contínuas e processo responsivo. O congelamento da
primeira tentativa não se repetiu durante esta observação.

O console também mostrou os servidores operacionais iniciados e eventos de
conexão, REGISTER e SUBSCRIBE de um cliente. A documentação omite deliberadamente
endereços e credenciais. Ainda é necessária confirmação do responsável de que o
cliente é o PC B previsto, que não houve login independente e que os dois monitores
estão estáveis antes de pontuar os itens específicos do CLIENTE. O item 2 foi
aprovado, levando o checklist a **1/10**. Nenhuma alteração de código, firewall,
commit, push ou `.exe` foi realizada.

## Diagnóstico da candidatura e suspensão física — 30/10/2026

O responsável questionou se a candidatura havia sido desativada no ensaio e
relatou que o PC A suspendeu após inatividade; ao retornar, o servidor indicou
saúde ruim, enquanto o PC B deixou de atualizar sem procurar servidor ou mostrar
ASSUMIR. Nenhuma candidatura foi desativada pelo Codex e nenhuma configuração foi
alterada para o Teste 2.

O código mantém candidatura habilitada no CLIENTE normal. O modo sem candidatura
é deliberadamente usado somente pelo antigo PRINCIPAL após rebaixamento. A
consulta do plano de energia mostrou suspensão após 15 minutos em bateria e nunca
em corrente alternada. A análise também encontrou um mecanismo compatível com o
sintoma do PC B: após SUBSCRIBE, o socket fica sem timeout e a leitura por linha
pode bloquear enquanto uma conexão preservada pela suspensão não entrega dados.
Nesse estado, o fluxo não chega à descoberta nem à candidatura.

O resultado é diagnóstico, não correção: o Teste 2 permanece em **1/10**, com uma
possível falha bloqueadora a confirmar pelo console do PC B. Sem mudança de código,
energia, firewall, commit, push ou `.exe`.

## Causa do peso antigo após suspensão confirmada — 30/10/2026

O responsável reproduziu que, ao suspender o PC PRINCIPAL com a aplicação aberta,
o CLIENTE continua exibindo indefinidamente o último peso, não busca servidor e
não apresenta ASSUMIR. A candidatura não foi desativada pelo ensaio.

A análise do contrato mostrou que a “saúde do servidor” não é monitorada de ponta
a ponta. O PRINCIPAL verifica a TC420 por HTTP, responde CHECK durante descoberta
e encerra SUBSCRIBE quando consegue observar saúde ruim. Durante a suspensão, ele
não executa essas rotinas. No CLIENTE, o SUBSCRIBE remove o timeout, bloqueia em
`readline()` e só inicia descoberta/candidatura depois de EOF ou exceção. Além
disso, o pacote de medição não possui timestamp ou sequência, e a interface
continua lendo a última cópia armazenada.

Assim, uma conexão TCP silenciosa mas aparentemente aberta mantém o último peso
sem validade temporal e impede o caminho que liberaria ASSUMIR. Os testes
simulados cobriam término e erro explícitos, não silêncio indefinido. O defeito
fica confirmado como bloqueador do Teste 2, ainda em **1/10**. Nenhum código,
configuração de energia, firewall, commit, push ou `.exe` foi alterado.

## Correção delimitada do silêncio SUBSCRIBE — 30/10/2026

Solicitação: corrigir o defeito físico reproduzido sem reabrir auditorias gerais.
Foi implementado prazo monotônico experimental de seis segundos no CLIENTE,
recepção por `recv()` com acumulador de linhas e invalidação local do frescor.
Fragmentos não renovam prazo; pacote completo e válido renova mesmo com peso
constante. Silêncio segue para cleanup, descoberta e candidatura já existentes.

O monitor passou a conservar o último valor apenas com indicação explícita
`SEM COM.`/`ÚLTIMA LEITURA`. `main.py` injeta o callback de frescor apenas no
CLIENTE; PRINCIPAL mantém a fonte anterior. A fachada de recursos ganhou `recv()`
acompanhado. O protocolo de rede e o prazo de sucessão não mudaram.

Foram adicionados nove testes específicos. Resultado final: **1.963 testes
simulados aprovados em 21,684 s**, além de `py_compile` e `git diff --check`.
Ainda não há aprovação física da correção; o Teste 2 permanece 1/10 até repetir
a suspensão controlada. Sem commit, push ou `.exe`.

## Repetição física com CLIENTE possivelmente desatualizado — 30/10/2026

O responsável informou que o CLIENTE continuou mostrando a última leitura. O
console do PRINCIPAL confirmou detecção de saúde ruim, abandono após 25 segundos,
encerramento TCP/UDP e início do leitor rebaixado. O endereço de rede incluído no
relato não foi reproduzido na documentação.

No PC B não apareceram “Silêncio do servidor detectado”, “Conexão com servidor
perdida”, “Procurando outro servidor” ou a contagem de candidatura. Essas saídas
são obrigatórias no novo caminho. Como as alterações locais não são copiadas
automaticamente para outro computador, o ensaio fica inconclusivo até verificar
versão e reiniciar o CLIENTE. Não houve nova alteração de código, energia,
firewall, commit, push ou `.exe` nesta solicitação.

## Validação física do silêncio após atualizar o PC B — 30/10/2026

O responsável confirmou que, depois de sincronizar a versão do segundo
computador, a correção funcionou no teste físico. A detecção de silêncio e o
estado de última leitura seguiram o comportamento esperado, permitindo considerar
o defeito reproduzido e sua correção fisicamente validados. A falha da tentativa
anterior foi atribuída à execução de versões diferentes nos dois computadores.

O Teste físico 2 completo continua pendente. Foi definido novo relatório de dez
itens para comunicação normal, comparação dos monitores, mudança de peso,
referência à perda já validada, regras de sucessão e encerramento isolado. O
checklist formal recomeça em **0/10** para não misturar observações de execuções
diferentes. Sem nova mudança de código, testes simulados, commit, push ou `.exe`.

## Aprovação do Teste físico 2 — PRINCIPAL + CLIENTE — 30/10/2026

O responsável executou os nove passos normais e informou que todos passaram. O
PC A operou como PRINCIPAL; o PC B, com a mesma versão, entrou diretamente como
CLIENTE e completou CONFIG, REGISTER e SUBSCRIBE. Os dois monitores coincidiram
nos campos observados e acompanharam uma mudança controlada de peso. Encerrar o
CLIENTE por SIM não interrompeu o PRINCIPAL, que depois também encerrou por SIM.

Com a evidência física separada da detecção de silêncio e recuperação, o Teste 2
fica consolidado em **10/10 aprovado**. Não foi realizada promoção efetiva nem
declarada garantia de posse distribuída exclusiva. Não houve mudança de código,
nova regressão simulada, commit, push ou geração de `.exe` nesta solicitação.

## Início do Teste físico 3A — 30/10/2026

Solicitação: avançar para perda e recuperação interrompendo somente a rede do PC
B, mantendo PRINCIPAL e TC420 funcionando. A preparação local encontrou zero
processos Python e portas operacionais livres. `main.py` foi iniciado no PC A,
PID 17300. O Windows confirmou a janela real do monitor; após cinco segundos o
processo estava ativo e responsivo.

Checklist em **0/8**, aguardando confirmação das leituras e início do PC B. A
interrupção de rede permanece ação manual do responsável; ASSUMIR não deverá ser
confirmado. Sem mudança de código, rede, firewall, commit, push ou `.exe`.

O responsável confirmou depois que os dois computadores estavam conectados. O
checklist do Teste 3A passou para **2/8**. Nenhuma interrupção foi executada pelo
Codex e os resultados de perda/recuperação permanecem pendentes.

## Aprovação do Teste físico 3A — 30/10/2026

O responsável informou que todos os oito itens passaram após desconectar e
restabelecer somente a rede do PC B. Foram confirmados detecção da perda,
indicação de última leitura, busca, participação na sucessão sem promoção,
reencontro do PRINCIPAL, cancelamento da candidatura, retomada do recebimento e
coerência final dos valores na mesma janela.

O Teste 3A fica **8/8 aprovado**. O cenário PC A ↔ TC420 permanece pendente como
Teste 3B; portanto, a etapa física 3 ainda não foi declarada integralmente
concluída. Sem mudança de código, nova regressão simulada, commit, push ou `.exe`.

## Início do Teste físico 3B — 30/10/2026

Solicitação: testar perda exclusiva de acesso do PRINCIPAL à TC420. O PID do 3A
já estava encerrado; não havia processos Python ou portas operacionais ocupadas.
`main.py` foi iniciado no PC A, PID 24516, e a janela real de conexão foi
confirmada.

Checklist em **0/8**, aguardando autenticação e preparação do PC B. A falha será
provocada manualmente apenas no enlace PC A/TC420; sem ação de rede pelo Codex,
mudança de código, commit, push ou `.exe`.

## Aprovação do Teste físico 3B — 30/10/2026

O responsável enviou os oito itens como aprovados. Foram observados preparação de
PRINCIPAL/CLIENTE, perda exclusiva do acesso à TC420, saúde HTTP ruim, reação do
CLIENTE, abandono do papel PRINCIPAL, sucessão sem promoção e restauração segura.
O Teste 3B encerra em **8/8 aprovado**.

Somado ao 3A, o marco físico 3 está concluído. A verificação posterior encontrou
um processo Python local, PID 24516, ainda ativo e responsivo; portanto, o estado
restaurado foi preservado e não foi documentado fechamento do aplicativo. O Teste
4 não foi iniciado. Sem mudança de código, nova regressão, commit, push ou `.exe`.

## Aprovação do Teste físico 4 — promoção e rebaixamento — 30/10/2026

Solicitação/resultado: o responsável marcou como aprovados os dez itens da troca
controlada de papéis. PC A iniciou como PRINCIPAL; PC B iniciou como CLIENTE; a
perda isolada de acesso do PC A à TC420 levou ao abandono do servidor; PC B
aguardou a liberação da candidatura, assumiu como novo PRINCIPAL e forneceu dados
reais; PC A encontrou esse novo servidor e permaneceu como CLIENTE. Os monitores
foram comparados com resultado coerente e o encerramento foi solicitado de forma
controlada.

Verificações adicionais do Codex: o PID 24516, que ainda estava ativo após o
Teste 3B, já havia encerrado; não restavam processos `python`/`pythonw`; e não
havia janela PRIX TC420 aberta. O Teste físico 4 fica **10/10 aprovado**. O limite
continua explícito: o ensaio comprova uma transição coordenada, não exclusividade
distribuída sob todas as falhas possíveis. Nenhum código foi modificado, nenhuma
regressão simulada foi repetida e não houve commit, push ou geração de `.exe`.
Próximo marco: Teste físico 5 — encerramento e reabertura entre computadores.

## Início do Teste físico 5 — 30/10/2026

Solicitação: iniciar o último ensaio físico planejado, cobrindo liberação de
recursos, reabertura dos dois computadores e novo encerramento. A inspeção local
do PC A encontrou zero processos `python`/`pythonw`, zero listeners TCP 42100 e
zero endpoints UDP 42101. Em seguida, `python -B main.py` foi iniciado, PID
18220, e a janela `PRIX TC420 - Monitor` foi confirmada.

Resultado parcial: a máquina local estava limpa e uma nova instância abriu. O
checklist permanece **0/10**, pois autenticação/leitura real e as verificações no
PC B exigem confirmação do responsável. Não houve alteração de código, rede ou
firewall, regressão simulada, commit, push ou geração de `.exe`.

## Implementação da nova interface do monitor — 30/10/2026

Solicitação: remodelar somente o monitor com base na imagem fornecida, preservando
conexão, ASSUMIR, protocolos, eleição, B1/B2/B3 e tempos. `interface/janela.py`
recebeu menu superior, layout 620 × 300, botões de copiar peso/tara, ícone da
janela e barra operacional inferior. Assets são resolvidos pela raiz ou
`sys._MEIPASS` e as imagens permanecem referenciadas pela instância.

Os estados usam callbacks existentes: saúde HTTP/evento de encerramento no AP e
frescor SUBSCRIBE/candidatura/promoção no CT. A alternância de três segundos usa
o `CicloTk`, reinicia nas transições e é cancelada no fechamento. Cópia de leitura
antiga é recusada. Não foi criado contador enganoso: sem getter de SUBSCRIBEs
ativos, a tela mostra `Clientes: —`.

Somente `Info` foi habilitado. Exportação de log, terminal, reconfiguração e
desativação de login automático ficaram visíveis e desabilitados por ausência de
contrato seguro comum ao monitor. Os pontos de criação em `main.py` e
`interface/conexao.py` apenas encaminham o evento de servidor encerrado; não houve
mudança de protocolo ou prazo. O harness offline ganhou simuladores visuais.

Verificações: 10 testes novos e regressão completa com **1.973 testes simulados
aprovados em 30,137 s**, compilação e `git diff --check`. O Tk real abriu as três
janelas offline e permaneceu responsivo; a captura visual automatizada expirou,
logo a estética ainda depende da inspeção do responsável. O harness PID 26016
permaneceu aberto para essa inspeção após o Windows recusar seu encerramento pelo
processo de automação. Sem TC420, credenciais reais, commit, push ou `.exe`.
O Teste físico 5 anterior não foi concluído e deverá ser repetido com a interface
nova.

## Menu funcional, exportação do terminal e reconfiguração — 30/10/2026

Solicitação: corrigir o menu que não abria; definir Exportar log como gravação do
texto integral do terminal; fazer Reconfigurar voltar à tela de conexão; e ajustar
Info para versão, desenvolvedor, GitHub e aviso de software não oficial.

O menu agora é aberto por botão e `tk_popup`. `interface.registro_terminal` foi
adicionado para espelhar stdout/stderr de forma thread-safe, preservando a saída
original. Exportar log solicita um `.txt` e grava UTF-8. Reconfigurar usa a mesma
parada coordenada B2, deduplica pedidos e somente após confirmação operacional
abre novo processo com `--reconfigurar`; esse modo vai diretamente para
`JanelaConexao`, sem descoberta ou login automático prévios.

Info mostra provisoriamente versão `1.0.0-beta`, desenvolvedor `Pablo`, GitHub não
configurado e aviso de independência/não oficialidade Toledo/PRIX. Não existe
remote Git no workspace; falta a URL exata do responsável. Abrir terminal e
desativar login automático continuam desabilitados.

Foram adicionados seis testes, totalizando **1.979 testes simulados aprovados em
31,561 s**. Compilação e diff passaram. O harness antigo foi encerrado e a versão
atualizada abriu em Tk real. Sem TC420, credenciais, commit, push ou `.exe`; o
Teste físico 5 permanece pendente após a mudança funcional.

## Reinício do ensaio visual offline — 04/11/2026

Solicitação: executar novamente o ensaio visual Tkinter. A instância anterior já
estava encerrada e não havia processos Python ativos. O harness foi iniciado em
uma execução limpa, PID 23588. Foram confirmadas as janelas reais `PRIX TC420 -
Conexão` e `Controle — ensaio visual offline`.

O ensaio permanece isolado: não inicia transporte real, não usa a TC420 nem lê
credenciais de produção. Nenhum código foi alterado, nenhuma regressão foi
repetida e não houve commit, push ou geração de `.exe`. O resultado dos passos
visuais depende da interação e confirmação do responsável.

## Cor de fundo do monitor — 04/11/2026

Solicitação: substituir a cor de fundo das áreas de leitura pelo verde `#8FD33F`.
Foi criada uma constante única aplicada a peso, tara, rótulos, botões de copiar e
restauração visual após o estado `SEM COM.`. Cabeçalho preto, menu e cores de
estado operacional foram preservados.

Foi adicionado um teste específico. A regressão completa encerrou com **1.980
testes simulados aprovados em 33,782 s**; compilação e diff também passaram. O
harness anterior foi encerrado e a versão atualizada abriu no PID 25620 para
inspeção visual offline. Sem TC420, credenciais reais, commit, push ou `.exe`.


## Análise profunda dos Chats e enriquecimento do dossiê do TCC — 04/11/2026

Solicitação: realizar análise minuciosa na pasta `Chats/` (conversas do ChatGPT e sessões do Codex), examinar os documentos de preparação para o congresso/TCC já iniciados em `APRESENTACAO_TCC/` e enriquecê-los com profundidade técnica, histórica e metodológica.

Foram analisadas 362 interações no histórico expandido do ChatGPT (`ChatGPT_Branch`), registros históricos de 24/09 a 04/11 e as 28 sessões do Codex em `Chats/md/`. Com base nessa base de evidências, foram substancialmente aprofundados e atualizados os artefatos em `APRESENTACAO_TCC/`:
- `01_LINHA_DO_TEMPO.md`: reconstrução cronológica minuciosa em 7 fases operacionais e síntese de 10 marcos para apresentação;
- `02_BASE_DE_CONHECIMENTO.md`: expansão didática em 7 dimensões pedagógicas para cada conceito de Redes, Concorrência, Sistemas Distribuídos, Interface Tkinter e Qualidade;
- `03_ARQUITETURA_EXPLICADA.md`: documentação da arquitetura distribuída de duas camadas com 5 diagramas Mermaid e justificativas técnicas detalhadas;
- `04_DESAFIOS_E_RESULTADOS.md`: estudo de caso aprofundado dos 8 maiores desafios de engenharia (Problema → Investigação → Causa → Solução → Teste → Resultado → Aprendizado), evolução dos 1.980 testes simulados e matriz dos 44 critérios físicos homologados;
- `05_ROTEIRO_DOS_SLIDES.md`: planejamento estruturado de 12 slides com tempos sugeridos, falas recomendadas e fontes documentais;
- `06_GUIA_DE_APRESENTACAO.md`: pitches de 30s e 2min, roteiro oral completo de 12 a 15 minutos, instruções para demonstração ao vivo e táticas de defesa;
- `07_PERGUNTAS_DA_BANCA.md`: 35 questões aprofundadas com intenção do avaliador, respostas fundamentadas e armadilhas a evitar;
- `08_GLOSSARIO_TECNICO.md`: expansão terminológica com termos industriais, de concorrência e metrologia.

Verificações: nenhum arquivo de código-fonte, teste original ou configuração da aplicação foi alterado. Nenhum executável ou slide (PowerPoint/PDF) foi gerado. Nenhuma credencial ou dado sensível foi exposto. O status pendente do Teste Físico 5 foi estritamente preservado.

## Comentários didáticos nos arquivos principais e testes — 04/11/2026

Solicitação: criar primeiro um commit para preservar o código e depois explicar
as partes, classes, funções e métodos dos arquivos principais, comentando também
os testes quando possível, sem alterar o código original além dos comentários.

Foi criado o commit local **`638ab73`** (`Preserva estado atual antes da comentacao
didatica do codigo`). Ele preservou as modificações encontradas em `main.py`,
`config/configuracao.py`, `rede/buscarservidor.py` e `tc420/web.py`, que já continham
acréscimos de docstrings. A edição solicitada começou após esse commit.

Foram acrescentadas **746 linhas de comentários `#` em 101 arquivos Python**:
30 arquivos operacionais/auxiliares e 71 arquivos em `tests/`. As explicações dos
módulos centrais cobrem inicialização, papéis, descoberta UDP/TCP, leitura HTTPS,
comandos CONFIG/REGISTER/SUBSCRIBE/CHECK, frescor, sucessão, interface Tk, workers,
recursos, autorização HTTP, configuração, keyring e saída coordenada. Os módulos
de apoio receberam cabeçalhos de responsabilidade. Nos testes foram comentados
a organização dos cenários e o isolamento; regressões de silêncio SUBSCRIBE e do
monitor também receberam explicações individuais. Não houve anotação individual
de todos os métodos de todas as suítes nem alteração dos módulos experimentais.

Foi criado `GUIA_CODIGO_COMENTADO.md` com ordem de leitura, conceitos e limites,
referenciado no README e na referência de módulos. As docstrings existentes foram
preservadas. Comentários novos registram detalhes efetivos do código, incluindo
parâmetros na URL do POST de login, backend de keyring dependente do ambiente,
campos de refresh como texto e a distinção entre confirmação operacional e global.

Verificações em relação ao commit de preservação: AST idêntica sem posições,
tokens executáveis idênticos e comparação textual com somente inserções de linhas
de comentário nos 101 arquivos. Compilação em memória aprovada, sem geração de
caches. A suíte `python -B -m unittest discover -s tests -q` aprovou **1.980 testes
simulados em 27,878 s**. A verificação de whitespace também foi aprovada.

As ferramentas temporárias de inserção foram removidas. Os comentários e a
documentação desta etapa permanecem no diretório de trabalho para revisão, sem
segundo commit ou push. Não houve comunicação real com a TC420, login real,
execução de ensaio manual ou homologação física nesta solicitação. Os números
de linha mudaram pela inserção de comentários; a lógica executável foi preservada.

## Correção do monitor que não encerrava a aplicação — 09/11/2026

Solicitação: investigar erros ao tentar fechar o monitor, quando a aplicação
continuava em execução. O trabalho anterior de comentários e as demais mudanças
já existentes no diretório foram preservados.

Causa reproduzida em `interface/saida_aplicacao.py`: o callback construía a thread
coordenadora, mas sobrescrevia a variável local `coordenacao` com `None` antes de
chamar `start()`. A aplicação ficava em `parando` sem que a rotina de limpeza
começasse. A inicialização dessa variável foi movida para antes da construção,
preservando a thread até sua partida após o bloqueio das admissões. A confirmação
operacional e os tratamentos de timeout/falha foram mantidos.

Foi adicionado um teste de regressão do pedido de fechamento até a conclusão da
interface, com partida efetiva da coordenação, parada do leitor e uma única chamada
de conclusão. Durante a regressão completa, um segundo defeito foi identificado:
o formulário manual de promoção chamava `_iniciar_promocao` duas vezes na mesma
confirmação. A chamada duplicada foi removida em `interface/janela.py`.

Verificações: a suíte de saída anterior falhou com três falhas e 70 erros em 40
testes, incluindo erros de cleanup. Após ambas as correções, **1.981 testes
simulados aprovados em 22,450 s** na suíte completa. Compilação em memória e
verificação de whitespace aprovadas. Um ensaio offline com widgets Tk reais,
raiz oculta e fonte sintética confirmou fechamento da raiz, retorno do mainloop
e término da coordenação, sem atingir o watchdog de três segundos.

Foram atualizadas operação, referência de módulos, validação e a observação de
escopo do guia de código comentado. Sem TC420, rede de produção, credenciais,
commit ou push nesta etapa. O ensaio Tk foi programático; não representa clique
humano ou validação física da correção nos computadores do responsável.

## Revisão geral de inconsistências — 09/11/2026

Solicitação: revisar o projeto de forma geral e verificar outras inconsistências.
Foram inspecionados inicialização, comunicação, configuração, interface, saída,
registros associados e testes. A análise de definições por AST em 43 módulos não
encontrou duplicações de funções/classes. As mudanças anteriores foram preservadas.

Correções: carregar configuração somente como objeto JSON; considerar a saúde da
TC420 no frescor do monitor principal; revogar cópia após falha da fonte e antes
da primeira amostra ou refresh pós-promoção; atualizar rótulos de faixas após
troca de fonte e substituir limites ausentes por `—`; sinalizar retorno do wrapper
automático em finally; remover impressão de token e erro bruto do ensaio manual.
Os limiares de saúde, o protocolo e a confirmação conservadora de saída não foram
substituídos por novas garantias.

Nove testes adicionados, com reprodução prévia dos problemas nos oito casos
iniciais. Expectativas antigas de exposição de token e de não sinalização do
evento após erro foram atualizadas. A suíte completa encerrou com **1.990 testes
simulados aprovados em 24,896 s**. Sintaxe/compilação em memória de 117 arquivos
e verificação de whitespace aprovadas. Ensaio Tk real offline verificou faixas
ausentes/parciais, rótulos e cópia conforme saúde sintética; houve ajuste no
harness por codificação do travessão no shell, sem falha correspondente no widget.

Criado `REVISAO_GERAL_2026-11-09.md`, separando correções, evidências, limites e
propostas. Atualizados índice, referência de módulos, API, configuração, operação,
prontidão e validação. Continuam delimitados: observador após promoção, NÃO sem
ocultação da janela, retenção sem limite de terminal/históricos, porta persistida
separada de HTTPS e ausência de consenso distribuído. Não houve análise de tipos
Pylance/Pyright, ensaio prolongado ou validação física nesta solicitação.
Sem credenciais reais, TC420, commit ou push.
## Laboratório e administrador experimental — 18/11/2026

Solicitação: melhorar ensaio_visual_tk.py, preparar administrador, investigar
metadados TCP e planejar EXE instalável. O responsável confirmou senha própria
de administrador e esclareceu que método manual significa promoção em ASSUMIR.

Implementado somente no laboratório: cinco abas, checklist manual, registro
limitado a 1.000 entradas, TCP virtual e autorização na primeira configuração,
ASSUMIR manual e Reconfigurar. Cadastro/validação usam verificador com sal e
PBKDF2 em trabalhador; nada é persistido e a senha de teste se perde ao reiniciar
ou reconstruir o ensaio. Guardas impedem rede/cofre reais; a saída aguarda B2 e
restaura os patches. Código operacional de autenticação preservado.

Autoteste Tk real offline aprovado; dois testes do verificador aprovados;
regressão completa: 2.154 testes em 38,456 s. Nenhum desses resultados constitui
validação física com a TC420. Backup anterior em
backups/ensaio_antes_admin_2026-11-18/originais.zip.

O manual oficial confirma saída contínua P03 Ethernet com porta configurável,
mas a seção consultada não estabelece mínimo/máximo/divisão no frame de 18
bytes. Parser preservado até especificação e confronto autorizado com bytes.
EXE/instalador permanecem planejados, não produzidos. Detalhes, fontes e limites
em LABORATORIO_ADMINISTRADOR.md. Sem commit ou push.
## Revisão do fluxo administrativo no laboratório — 18/11/2026

Solicitação: separar cadastro/login/conexão; HTTP automático sem login após
cadastro; TCP com novo login a cada abertura; login em ASSUMIR manual e
Reconfigurar; Esqueci a senha com confirmação SIM/NÃO e limpeza dos dados da
conexão e cadastro administrativo antes de novo cadastro.

Implementado no ensaio offline: títulos distintos, autorização por abertura,
simuladores de abertura HTTP/TCP e restauração confirmada. NÃO preserva estado;
SIM limpa campos simulados, opção de salvar login e credencial administrativa,
revoga autorização e abre cadastro. Não há persistência real nem limpeza de
cofre/disco nesta etapa. Código operacional preservado.

Autoteste Tk real com dados simulados aprovado, incluindo ambos os caminhos
de confirmação, HTTP sem login, TCP com login e novo cadastro após restauração.
Regressão completa: 2.154 testes aprovados em 42,655 s; compilação em memória
de 159 arquivos Python e verificação de whitespace aprovadas.
Documentação LABORATORIO_ADMINISTRADOR.md atualizada. Sem TC420, commit ou push.
## Fechamento da conexão no ensaio — 18/11/2026

Solicitação: não era possível encerrar a tela de conexão no laboratório.
Identificada ligação do X ao fluxo operacional, enquanto o ensaio possui painel
e modais próprios. O X agora confirma e encaminha ao encerramento do laboratório,
aguardando B2 e fechando eventual modal administrativo. Cancelar o cadastro
inicial por X/Escape também encerra o ensaio, evitando conexão oculta inacessível.
Autoteste Tk real offline aprovado: NÃO mantém execução, SIM confirma B2,
destrói a raiz e restaura os patches. Código operacional preservado; sem TC420,
commit ou push. Documentação do laboratório atualizada.
## Monitor fechado na reconfiguração do ensaio — 18/11/2026

Solicitação: fechar o monitor após login administrativo na reconfiguração e
também ao confirmar Esqueci a senha/restauração. Implementada transição assíncrona
com prova B2 antes de destruir o monitor. Login válido apresenta conexão;
restauração confirmada apresenta novo cadastro e depois conexão limpa. Novo
coordenador/registro simulado evita reutilizar admissões encerradas. Recusa ou
cancelamento preservam o monitor. Corrigida também preparação do cenário manual
do ensaio para não disparar promoção automática ou cancelar o formulário.

Autoteste Tk real offline aprovado, verificando janela anterior destruída,
conexão visível após login e novo cadastro após restauração, sem rede real.
Regressão completa: 2.154 testes aprovados em 44,827 s. Compilação dos três
arquivos Python alterados e verificação de whitespace aprovadas.
Somente laboratório e documentação alterados; sem TC420, commit ou push.
## Login obrigatório após cadastro no ensaio — 18/11/2026

Solicitação: esclarecer ausência da tela de login após cadastrar a primeira senha.
O ensaio autenticava implicitamente ao cadastrar. Ajustado para Cadastro → Login
administrativo → Conexão, também após restauração. Cadastro mantém autorização
falsa e não executa a continuação; login válido libera o acesso. A exceção do
HTTP automático em abertura posterior foi preservada. Autoteste com Tk real e
dados simulados aprovado, incluindo bloqueio intermediário nos dois cadastros,
reconfiguração, restauração e saída B2. Código operacional preservado. Documentação
do laboratório atualizada. Sem TC420, commit ou push.
## Login no atalho de ensaio — 18/11/2026

Solicitação: botão de ensaio na conexão também deve pedir login administrativo.
No laboratório, o atalho agora solicita senha a cada acesso antes de apresentar
o painel. Autoteste com Tk real offline aprovado: sem login e senha incorreta
não abrem; senha correta abre. Demais fluxos do autoteste e saída B2 aprovados.
Código operacional preservado, regra ainda restrita ao protótipo. Documentação
atualizada; sem TC420, commit ou push.
## Atualização do dossiê de apresentação TCC — 18/11/2026

Solicitação: atualizar a documentação da pasta de apresentação TCC, localizada
como APRESENTACAO_TCC. Atualizados capítulos 00–09 com complementos atuais e
aviso de preservação histórica; README, conferência e registro revisados; criado
capítulo 10 com estado, fontes, resultados, limitações e ajustes para a defesa.
Incluídos supervisão/sucessão, memória, localhost, TCP local, visual integrado,
administrador experimental e instalador pendente. Última regressão completa
referenciada: 2.154 casos em 44,827 s; autotestes posteriores tratados separadamente.

Manifesto original preservado; novo manifesto datado contém hashes das fontes
selecionadas, excluindo configuração operacional e credenciais. Verificações
documentais de links/fontes/hashes e whitespace; nenhuma suíte ou aplicação
executada nesta solicitação. Sem TC420, alteração de código, PPTX/PDF, commit ou push.
## Integração do administrador ao aplicativo — 19/11/2026

Solicitação: aplicar no principal os fluxos validados no ensaio, com backup antes.
Preservados oito originais em backups/antes_administrador_operacional_2026-11-19,
ZIP e SHA-256 conferidos antes das alterações, sem configuração/credenciais reais.

Implementados verificador persistente separado, Cadastro → Login → aplicação,
HTTP automático dispensado quando já cadastrado, abertura TCP com login,
proteção de ASSUMIR manual/Reconfigurar/atalho do ensaio e restauração SIM/NÃO.
Na execução ativa, a restauração aguarda B2 e limpa na nova execução antes da
rede; falhas não anunciam sucesso. TCP salva parâmetros locais e continua sem
servidor/sucessão. Corrigida a reabertura da raiz/monitor para ocorrer uma vez,
após ambas as janelas fecharem. Cadastro e temporários ignorados pelo Git.

Oito testes novos aprovados, incluindo persistência em diretório temporário e
loop de reconfiguração sem duplicar login ou iniciar após cancelamento; ensaio Tk de
produção e autoteste do laboratório aprovados, sem rede/cofre real. O ensaio
operacional também verificou monitor, B2 e restauração adiada. Compilação em
memória de 163 arquivos Python aprovada. Documentação operacional e índice TCC
atualizados. Regressão final: 2.162 testes aprovados em 42,643 s; links e
whitespace conferidos. As falhas intermediárias de fixtures dos formulários e
de dependência externa no callback isolado de promoção foram corrigidas antes
da aprovação final. Documentos distinguem implementação, testes e limites.
Sem TC420,
cadastro/alteração de dados reais, EXE/instalador, commit ou push.
## Roteiro de instalação Windows e caminhos — 19/11/2026

Solicitação: horário nas leituras, arquivos/logs próprios, log automático ao
encerrar, EXE, instalação elevada em Program Files, firewall e desinstalador.
Criado ROTEIRO_INSTALACAO_WINDOWS.md com sete etapas e critérios de aceite.
Decisão inicial: binários em Program Files e dados por usuário em LocalAppData;
rede privada padrão e pública opcional com regras restritas, sem aplicar firewall.

Iniciada etapa 1: config/caminhos.py separa caminhos do EXE e desenvolvimento,
fornece pasta logs e impede nomes de arquivo com travessia. Configuração e cadastro
administrativo acompanham o mesmo diretório. Sem migração de dados reais.
Horários, log automático, EXE/instalador e regras ainda não implementados.
Referências oficiais de PyInstaller, Inno Setup e Microsoft consultadas.
Validação: três testes novos e oito administrativos aprovados; regressão completa
de 2.165 testes em 61,133 s aprovada. Compilação dos três arquivos Python e
whitespace aprovados. Não equivale a instalar EXE ou testar firewall real.
Sem TC420, instalação local, alteração de firewall, commit ou push.
## Correção do requisito de data/hora — 19/11/2026

Responsável esclareceu: cada refresh deve ter data e horário, não apenas cada
nova leitura válida. Roteiro Windows corrigido para exibir data/hora local da
atualização da tela nos três modos. Frescor e última amostra continuam separados:
redesenhar não renova comunicação. Formato proposto DD/MM/AAAA HH:MM:SS.
Alteração documental, sem implementação visual ou execução de testes nesta
solicitação. Sem TC420, commit ou push.
## Data e hora visíveis em cada refresh — 23/11/2026

Responsável relatou ausência de data/hora no teste físico; o requisito anterior
estava somente documentado. Implementados rótulo Atualização: DD/MM/AAAA HH:MM:SS
na barra superior do monitor e prefixo correspondente na linha Estado do terminal.
Valor local atualizado em cada refresh ativo, mesmo com peso igual, fonte ausente
ou comunicação indisponível. Não renova idade da amostra nem altera frescor,
protocolo, limites metrológicos ou a prova B2. Dimensões do monitor preservadas.

Dois testes novos verificam avanço com peso igual/sem comunicação e atualização
sem fonte. Autoteste Tk real offline verifica rótulo visível e largura suficiente.
Regressão final: 2.167 testes aprovados em 47,376 s; 165 arquivos Python compilados
em memória e whitespace aprovado. Três fixtures de callback isolado receberam
a nova dependência de relógio, preservando as verificações anteriores.
Roteiro de instalação atualizado: horário implementado, log automático e pacote
instalável ainda pendentes. Log físico do usuário mostra encerramento confirmado
no escopo acompanhado; não é validação física independente desta alteração.
Sem TC420, commit ou push nesta solicitação.
## Fabricação do executável Windows — 23/11/2026

Solicitação: fabricar o executável. Criados ambiente isolado, spec PyInstaller,
lock de dependências, ícone ICO a partir do asset aprovado, informações de versão
0.0.1/Pablops2god, script de build e distribuidor ZIP com manifesto SHA-256.
Backup prévio de main.py, registro_terminal.py e .gitignore preservado sem dados reais.

Ajustado espelho do terminal para stdout/stderr ausentes no EXE sem console,
sem buffer extra ou gravação automática. Dois testes novos de sanitização e
limite sem console. Inventário HTTP passa a excluir .venv-build/build/dist;
falhas intermediárias eram dependências do build sendo contadas como código
operacional. Pacote inclui assets e backend Windows do keyring, sem config,
cadastro ou credenciais reais. Laboratório de desenvolvimento não distribuído.

Diagnóstico explícito do EXE usa Tk real, disco temporário, sockets/cofre
bloqueados: imagens, login, monitor, data/hora e B2 aprovados. Teste inicial
ajustado para processar mapeamento da janela antes de verificar visibilidade.
Regressão final: 2.169 testes aprovados em 48,884 s. Documentação de distribuição
atualizada. Sem TC420, cofre real, firewall, instalação em Program Files,
assinatura digital, EXE instalador, desinstalador, log automático, commit ou push.
ZIP final íntegro: 1.013 arquivos com hashes conferidos, 16.171.421 bytes.
Cópia extraída executou diagnóstico com sucesso fora da pasta de build e sem
Python no PATH. Ambiente ainda é o computador de build, não Windows limpo.
Resultado sanitizado em RESULTADO_BUILD_WINDOWS.json; 168 arquivos Python
compilados em memória, whitespace e integridade do backup aprovados.
## Permissões de firewall do pacote — 23/11/2026

Responsável perguntou pelas permissões de firewall. ZIP anterior não configurava
regras automaticamente. Incluídos configurador/removedor manuais, com UAC,
perfil privado padrão e público opcional, EXE exato, TCP 42100/UDP 42101,
origem LocalSubnet e nomes delimitados pelo caminho. Atualização idempotente
e remoção apenas das próprias regras. Programa normal continua sem elevação.

Planos e parâmetros verificados por teste PowerShell, sem executar cmdlets
mutantes ou pedir UAC. Parser aprovado. Documentação e LEIA-ME atualizados;
ZIP e manifesto regenerados sem alterar o EXE. Sem alteração do firewall
deste computador, TC420, instalador/desinstalador, commit ou push. Aplicação
real das regras e rede continuam pendentes; políticas corporativas podem impedir.
Conferido também o caminho padrão do script já copiado ao pacote, sem informar
EXE manualmente. ZIP final: 1.016 arquivos e 16.174.195 bytes; integridade e
todos os hashes aprovados. Binário EXE permaneceu igual ao previamente validado.
## Dossiê atualizado e guia do TCC escrito — 23/11/2026

Solicitação: atualizar APRESENTACAO_TCC e criar Markdown de apoio ao TCC escrito.
Criados capítulos 11 (estado vigente, matriz N01–N10 e limites das evidências)
e 12 (guia com tema, problema, objetivos, estrutura, textos-base, metodologia,
avaliação, resultados, discussão, conclusão e plano de escrita). Dados acadêmicos
e normas mantidos como campos a confirmar; nenhuma referência científica inventada.

Capítulos 00–10, índice, conferência e registro revisados. Corrigido o resumo
antigo que tratava administrador e EXE como pendentes. Mantidos como pendentes
instalador/desinstalador, log automático, firewall real e máquina limpa.
Manifestos anteriores preservados e novo manifesto datado das fontes selecionadas.
Conferidos links, fontes e métricas do pacote com o resultado de build registrado.
Resultado documental: 121 links locais sem destinos ausentes e 26 fontes com
SHA-256 verificado; UTF-8 e whitespace conferidos. Guia com 326 linhas.
Nenhum teste ou ensaio foi reexecutado nesta tarefa; sem alteração de código,
dados reais, firewall, TC420, slides/DOCX/PDF, commit ou push.

## Preferência de extensão do TCC — 23/11/2026

Solicitação: considerar 35 páginas como limite ideal para o TCC.
Resultado: registrada a preferência por uma eventual versão ampliada de até
35 páginas no total, distinguindo-a dos limites de 15/25 páginas encontrados
nos modelos fornecidos. Mantidos os entregáveis atuais e a versão extensa
anterior. Planejamento em PLANEJAMENTO_EXTENSAO_TCC.md.
Verificações: consultada a auditoria documental dos modelos. Não houve nova
geração de DOCX/PDF, alteração de código, testes operacionais, commit ou push.

## Limite do artigo confirmado pelo autor — 23/11/2026

Solicitação: seguir o modelo sugerido, com até 15 páginas de artigo e
25 páginas no total com apêndices, substituindo a preferência por 35 páginas.
Resultado: planejamento e README do TCC atualizados; os entregáveis vigentes
já atendem ao modelo e foram mantidos, sem preenchimento artificial de páginas.
Verificação documental executada: 12 páginas de artigo e referências, 20 no
total, 10 figuras, uma tabela, 17 referências externas e três apêndices;
nenhum erro documental detectado pelo verificador. Modelos originais preservados.
Sem alteração de código operacional, novos testes físicos, commit ou push.

## TCC ampliado para 24 páginas — 24/11/2026

Solicitação: ampliar o trabalho para 24 páginas, retirar o apêndice de declaração
de IA e manter citações, referências, organização e formatação.
Resultado: 14 páginas de artigo e referências e 10 de apêndices, dentro dos
limites 15/25 do modelo. Declaração e chamada retiradas; antigo Apêndice C
reorganizado como B, com quatro partes de rastreabilidade e protocolo proposto.
Ampliação técnica sobre módulos, threads, TCP/HTTP, sucessão e aceitação.
Mantidas 17 referências, dez figuras, uma tabela e resumo de 224 palavras.
Não foram inventados novos resultados. A orientação de transparência do guia
foi registrada; retirada a pedido do autor não representa dispensa institucional.

Preservação: ZIP com os cinco arquivos anteriores, incluindo DOCX/PDF e scripts.
DOCX anterior aberto por outro processo não foi substituído; a versão nova usa
sufixo _24_paginas. Nenhuma janela ou processo do usuário foi encerrado.
Verificações: geração e exportação Word, 24 PNGs Poppler inspecionados, contagem
e estrutura aprovadas, fonte e geometria do PI mantidas, originais preservados.
Renderizador padrão tentou executar e confirmou soffice ausente; Word/Poppler
foram a alternativa. Documentação e registro da pesquisa atualizados.
Sem mudança de código operacional, TC420, cofre, firewall, testes físicos,
regressão completa, commit ou push.

## Seleção isolada para GitHub — 25/11/2026

Solicitação: separar somente o necessário para publicação; confirmado pelo
responsável incluir aplicativo, testes e documentação técnica, sem TCC ou apresentação.
Criada cópia em publicacao_github/PRIX_TC420_2026-11-25 com 251 arquivos,
incluindo fontes, testes, assets, módulos de prototipos utilizados, ferramentas
de empacotamento e documentação. Criados README, dependências operacionais e
de desenvolvimento e exportador por lista de permissões, sem sobrescrita.
Atualizado .gitignore para dados locais, backups, conversas, material acadêmico,
logs e coletas de processo. Configuração e conversas já estavam rastreadas no
Git anterior: ignorar não as remove do histórico. A cópia não inclui .git;
nenhum histórico foi reescrito, nem remoto configurado ou alterado.

Endereços operacionais identificados, nomes de estações e caminhos de usuário
foram substituídos apenas na cópia; fonte original do aplicativo preservada.
Configurações reais, cadastro administrativo, conversas, TCC, builds, backups,
logs brutos e executáveis não integram a seleção. Licença não foi inventada;
atribuição de imagens/marcas do fabricante registrada no README.
Verificações: 169 fontes Python compiladas em memória; 2.169 testes aprovados
em 52,064 s executados dentro da cópia; manifesto SHA-256 e ausência dos arquivos
proibidos conferidos. Busca por padrões conhecidos não encontrou credenciais,
sem representar garantia absoluta ou auditoria de todo o histórico anterior.
ZIP de fontes separado e relatório externos à árvore do repositório.
Sem TC420 real, alteração operacional, firewall, commit ou push.

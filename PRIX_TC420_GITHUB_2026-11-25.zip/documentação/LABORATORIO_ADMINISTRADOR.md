# Laboratório Tk e administrador experimental — 18/11/2026

**Atualização de 19/11:** o fluxo recebeu [integração operacional](ADMINISTRADOR_OPERACIONAL.md)
autorizada, com cadastro persistente separado. Este documento e o ensaio
continuam descrevendo o laboratório offline de 18/11, cuja senha fica em memória.

O botão de ensaio da conexão também solicita login administrativo a cada clique,
mesmo quando já houve autorização para configurar. O painel só é apresentado
após senha válida. Autoteste Tk offline verificou bloqueio antes do login e com
senha incorreta, e abertura após senha correta. Regra implementada no protótipo;
o atalho da aplicação operacional ainda não recebeu autenticação administrativa.

Fluxo corrigido após cadastro: cadastrar não autentica. Tanto no primeiro acesso
quanto após restauração, a sequência é **Cadastro → Login administrativo →
Conexão**. Somente o login válido libera a continuação. O autoteste Tk offline
confirmou que autorização e conexão permanecem bloqueadas entre cadastro e login.
O HTTP automático em abertura posterior com cadastro existente continua dispensado
do login administrativo, conforme a regra anterior.

Reconfiguração do monitor: após login administrativo válido, o ensaio solicita
parada, aguarda prova B2, destrói o monitor e apresenta a conexão com novo dono
operacional simulado. Esqueci a senha → SIM também aguarda B2 e fecha o monitor
antes de abrir o novo cadastro; após cadastrar, aparece a conexão limpa.
Senha incorreta, cancelamento e NÃO na restauração não fecham o monitor.
Se B2 permanecer pendente, o monitor é preservado e o registro informa o motivo.
O autoteste verifica a destruição efetiva da janela anterior nos dois caminhos.

Correção de fechamento: o X da conexão agora pede confirmação para encerrar
todo o laboratório pelo coordenador do ensaio, aguardando B2. NÃO preserva as
janelas. SIM fecha também eventual modal administrativo. X/Escape no cadastro
inicial encerra o ensaio, evitando deixar a conexão oculta e inacessível.
Autoteste com Tk real aprovado para NÃO e SIM no WM_DELETE_WINDOW da conexão,
incluindo confirmação B2 e restauração dos patches. Sem ensaio físico nesta correção.

## Revisão do fluxo solicitada em 18/11

As telas distinguem Cadastro de administrador e Login de administrador.
Sem cadastro, a abertura exige cadastro antes de configurar. Com cadastro,
HTTP automático abre o monitor simulado sem login administrativo. TCP exige
login em cada nova abertura simulada, mesmo após autorização na abertura
anterior; após autenticação nesta abertura, selecionar TCP não pede novamente.
ASSUMIR manual e Reconfigurar continuam solicitando login para liberar a ação.
Os botões da aba Administrador simulam nova abertura HTTP ou TCP, preservando
o cadastro apenas na memória do laboratório. O HTTP automático simulado não
realiza autenticação nem comunicação com equipamento real.

No login, Esqueci a senha pergunta se deseja restaurar e avisa que os dados
salvos da conexão e a senha administrativa serão apagados. NÃO mantém tudo.
SIM apaga os campos do formulário, desmarca salvar login, restaura o seletor
HTTPS, revoga a autorização administrativa e abre novo cadastro. No laboratório,
isso afeta somente dados simulados; nenhum arquivo ou cofre real é apagado.
A integração futura deverá limpar também a persistência real correspondente,
de forma consistente, antes de anunciar restauração concluída.

O autoteste Tk cobre HTTP automático, novo login TCP, recusa e confirmação
da restauração, formulário limpo e novo cadastro, além dos cenários anteriores.
Regressão após esta revisão: 2.154 testes aprovados em 42,655 s; compilação em
memória de 159 arquivos Python e verificação de whitespace aprovadas.

## Uso

Execute `python -B tests/ensaio_visual_tk.py`. O laboratório reúne cinco abas:
Cenários, TCP local, Administrador, Checklist e Registro. O registro visual
retém até 1.000 entradas. O checklist é manual; seus itens não representam
validações automáticas.

Na primeira configuração, cadastre uma senha **somente de teste**, com no mínimo
oito caracteres e confirmação. Essa senha é independente da senha da TC420.
O protótipo exige autorização antes da configuração inicial, do TCP na abertura, da promoção manual
em ASSUMIR e da ação Reconfigurar do monitor. Senha incorreta mantém a ação
bloqueada. A candidatura automática não recebeu uma nova exigência de senha.

O verificador usa sal aleatório, PBKDF2-HMAC-SHA256 com 200.000 iterações e
comparação constante. O cálculo ocorre fora da thread Tk. Senha e verificador
não são gravados em disco; o estado desaparece ao encerrar ou reconstruir o
ensaio, inclusive no fluxo de reconfiguração. Não existe senha padrão.

## Isolamento e limites

Somente arquivos de teste foram alterados nesta entrega. A tela administrativa
**não está integrada ao main.py** e não constitui um controle de acesso pronto
para produção. Persistência, restauração operacional, política de tentativas e
gestão de administradores continuam pendentes de desenho e validação.

O ensaio substitui rede, cofre e persistência por simuladores. Guardas recusam
abertura de sockets e requisições HTTP reais. A exportação não grava arquivos.
O TCP virtual permite avançar a idade da leitura e simular um novo frame sem
contatar a balança. O encerramento aguarda a B2 e restaura os patches do processo.
Os widgets Tk são reais; dados, operações e falhas são simulados.

## TCP: mínimo, máximo e divisão

O parser operacional atual extrai peso de frames de 18 bytes. Esta entrega não
alterou o parser nem inventou campos ausentes. O manual oficial, seção 8.9,
página impressa 47, identifica a saída contínua Ethernet como protocolo P03,
com porta configurável (a ilustração mostra 9800). Essa seção não apresenta o
mapa de bytes necessário para concluir que mínimo, máximo e divisão estão no
frame. Os valores desenhados na tela do equipamento não comprovam transmissão.

Antes de ampliar o parser, obter a especificação P03 aplicável ao equipamento
e confrontá-la com frames reais autorizados, incluindo unidades, sinal, tara,
estabilidade e faixas. A captura ainda não foi realizada nesta etapa.

Fonte consultada em 18/11/2026:
[Manual TC420, Toledo do Brasil](https://www.toledobrasil.com/blob/manuals/156_pt_manual_1723821221.pdf).

## Executável e instalador: próxima entrega

Não foram produzidos EXE ou instalador. Primeiro validar o fluxo administrativo
no laboratório; depois definir persistência e integrar os caminhos autorizados.
O empacotamento deverá incluir recursos visuais e dependências, separar dados
graváveis da pasta de instalação, preservar o cofre por usuário e excluir
credenciais, backups e logs reais. Recomenda-se validar primeiro um pacote em
pasta e depois o instalador, em Windows limpo sem Python, com arquitetura e
versões suportadas explicitamente definidas. Não há promessa de compatibilidade
com qualquer sistema operacional ou computador.

Referência de empacotamento:
[PyInstaller — funcionamento](https://www.pyinstaller.org/en/stable/operating-mode.html).

## Verificações desta entrega

- `python -B tests/ensaio_visual_tk.py --autoteste`: aprovado com Tk real e rede
  simulada; cadastro, recusa, autorização, ASSUMIR, reconfiguração, TCP virtual,
  limite do registro, saída B2 e restauração dos patches.
- Suíte completa: **2.154 testes aprovados em 38,456 s**.
- Dois testes unitários do verificador aprovados, usando senhas aleatórias
  geradas em execução.
- Compilação em memória de 159 arquivos Python aprovada; backup ZIP íntegro
  (um arquivo original); verificação de whitespace dos arquivos alterados aprovada.
- Backup anterior: `backups/ensaio_antes_admin_2026-11-18/originais.zip`.

Não houve acesso à TC420, validação física de bandeja/notificações, alteração
operacional de autenticação, commit ou push.

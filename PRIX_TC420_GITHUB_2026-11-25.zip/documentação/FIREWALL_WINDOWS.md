# Permissões de firewall no pacote — 23/11/2026

O ZIP atualizado inclui ferramentas manuais de configuração. Não modifica
firewall ao abrir o aplicativo, nem desativa qualquer proteção do Windows.
O instalador automático ainda não foi produzido.

## Procedimento no computador de destino

1. Extraia o ZIP atualizado na pasta definitiva.
2. Abra `Configurar-Rede.cmd`, ao lado do EXE.
3. A ferramenta inclui rede **privada**. Responda S somente se também precisar
   usar uma rede classificada como pública; N é o padrão.
4. Confirme a elevação UAC usando uma conta administrativa do Windows.
   Essa credencial não é a senha de administrador cadastrada no aplicativo.
5. Faça isso em cada PC que possa se tornar PRINCIPAL.

## O que será autorizado

| Direção | Protocolo | Porta local | Programa | Origem |
|---|---|---:|---|---|
| Entrada | TCP | 42100 | Caminho exato de PRIX_TC420.exe | Sub-rede local |
| Entrada | UDP | 42101 | Mesmo EXE | Sub-rede local |

Não são criadas regras genéricas para Python ou para todos os programas; nem
regras de saída, roteador, compartilhamento de arquivos ou visibilidade no
Explorador. HTTPS 443 e TCP direto 9800 são conexões de saída à balança. Em rede
corporativa com bloqueio de saída, GPO, perfil Domínio, VLAN ou isolamento Wi-Fi,
o administrador da rede deverá avaliar a política aplicável. Scripts locais
não garantem que uma regra seja efetiva contra uma política superior/bloqueio.

A configuração usa nomes próprios com hash do caminho. Repetir atualiza as
mesmas duas regras; escolher somente privada retira o perfil público dessas
regras. O grupo é conferido antes da atualização/remoção para evitar atingir
regras de outro grupo. Não altera regras anteriores criadas pelo prompt do
Windows ou manualmente por terceiros. As duas operações não são transação:
falha intermediária pode deixar somente uma regra; corrigir a causa e repetir.

## Remoção e mudança de pasta

Abra `Remover-Permissoes-Rede.cmd` **antes de mover ou excluir a pasta**.
Remove somente os nomes correspondentes àquele caminho. Ao mudar de pasta,
configure novamente no destino. Scripts não removem regras arbitrárias nem
apagam dados/configuração do aplicativo.

Os launchers usam PowerShell com ExecutionPolicy Bypass somente para aquele
processo, sem mudar a política persistente. Não contornam GPO ou falta de
credencial administrativa. Leia os scripts antes de executar em ambiente gerenciado.

## Verificações e limite

`tests/validar_firewall_pacote.ps1` confere planos privado/público, portas,
direção, sub-rede, identidade da remoção e compatibilidade dos parâmetros com
o cmdlet instalado. O modo `-Simular` retorna antes de UAC e antes de qualquer
consulta/criação/alteração/remoção de regra. Teste aprovado, sem alterar firewall
real. O script foi analisado pelo parser PowerShell; aplicação real das regras,
UAC e comunicação entre PCs permanecem pendentes de validação no destino.

Fontes Microsoft:
[New-NetFirewallRule](https://learn.microsoft.com/en-us/powershell/module/netsecurity/new-netfirewallrule?view=windowsserver2025-ps)
e [Remove-NetFirewallRule](https://learn.microsoft.com/en-us/powershell/module/netsecurity/remove-netfirewallrule?view=windowsserver2025-ps).

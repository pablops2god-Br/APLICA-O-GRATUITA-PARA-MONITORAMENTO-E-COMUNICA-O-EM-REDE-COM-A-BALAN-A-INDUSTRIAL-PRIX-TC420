# Referência de módulos e arquivos

23/11: `empacotamento/` contém spec, lock, script de geração, distribuidor ZIP
e diagnóstico offline do EXE. O espelho do terminal suporta ausência de console.
Ver [EXECUTAVEL_WINDOWS.md](EXECUTAVEL_WINDOWS.md).

23/11: `JanelaTC420.atualizar_refresh_web` atualiza data/hora local na barra
superior e no terminal, mantendo separado o frescor da amostra. Mesma regra
para PRINCIPAL, CLIENTE e TCP local, sem novo campo no protocolo de rede.

`config/caminhos.py` prepara instalação Windows: dados por usuário no EXE,
caminho de desenvolvimento preservado e helper para logs. Ver
[roteiro de instalação](ROTEIRO_INSTALACAO_WINDOWS.md).

## Administrador operacional — 19/11/2026

- `config/administrador.py`: verificador persistente, método e limpeza delimitada.
- `interface/administrador.py`: cadastro/login, confirmação de restauração e bootstrap.
- `main.py`: prepara administrador antes da rede e reabre após B2.
- `tests/test_administrador_operacional.py`: persistência e falhas sem dados reais.
- `tests/ensaio_admin_operacional_tk.py`: widgets operacionais reais em ambiente isolado.

Ver [contrato e limites](ADMINISTRADOR_OPERACIONAL.md). O laboratório anterior
continua separado, com credenciais somente em memória.

## TCP local — 13/11/2026

`rede/tcp_local.py` integra interpretador legado à fonte local com socket e
thread acompanhados pela SaidaAplicacao. `tests/test_tcp_local.py` cobre leitura,
falhas e B2; `tests/ensaio_tcp_local_tk.py` cobre ambas as telas reais contra
localhost. Não cria servidor ou sucessão. Ver [TCP_LOCAL.md](TCP_LOCAL.md).

## Formulários e avisos integrados — 13/11/2026

- `interface/formularios.py`: construção comum de conexão/ASSUMIR, dicas,
  centralização e atalho do ensaio; mantém callbacks separados da apresentação.
- `interface/notificacoes.py`: bandeja Windows opcional, restauração do monitor,
  limpeza no Destroy e avisos por transição, sem nova thread.
- `tests/ensaio_integracao_visual_tk.py`: widgets operacionais reais com rede,
  configuração e cofre isolados; preservação do monitor e limpeza local.
- `tests/test_notificacoes_visuais.py`: deduplicação, startup e transições.

Seletor de método é visual; integração não implementa novo transporte.
Detalhes e backup: [INTEGRACAO_VISUAL_001.md](INTEGRACAO_VISUAL_001.md).

## Terminal limitado — interface/registro_terminal.py

Retenção padrão de 5.000 linhas e 1.000.000 de caracteres em blocos coalescidos,
com locks e contadores de descarte. Mantidas `instalar_registro_terminal()` e
`obter_texto_terminal()`; a segunda retorna somente o texto ainda retido.
`obter_exportacao_terminal()` fornece retrato coerente com aviso de cortes.
Sanitização adicional cobre valores rotulados; origem permanece responsável por
não emitir segredos. Não grava automaticamente em disco. O botão captura/grava
no worker B3/B2 e só mostra resultado no Tk. [Contrato e medições](RETENCAO_TERMINAL.md).

## Supervisão comum — rede/supervisao_principal.py

`SupervisaoPrincipal(contexto, saida, infraestrutura=None, *, intervalo=0.1)`
acompanha retorno e prova B2 do contexto original. `iniciar()` registra uma única
thread; `cancelar()` só sinaliza; `obter_leitor()` consulta a referência publicada.
`pronto` não comprova amostra válida. O leitor tem candidatura desabilitada, usa
a mesma infraestrutura e é parado no worker ao cancelar/sair. O monitor aplica
a troca no Tk com identidade protegida. Observadores separados do main/manual
foram removidos. Contrato em [SUPERVISAO_PRINCIPAL.md](SUPERVISAO_PRINCIPAL.md).

As assinaturas completas estão em [API.md](API.md). Esta seção descreve os
contratos e a responsabilidade dos arquivos, incluindo código legado.

Em 04/11/2026 foram acrescentados comentários didáticos aos arquivos operacionais
e aos testes, sem alterar instruções executáveis. O [guia do código
comentado](GUIA_CODIGO_COMENTADO.md) apresenta a ordem de leitura, o alcance das
anotações e as verificações de integridade em relação ao commit `638ab73`.

A [revisão geral de 09/11/2026](REVISAO_GERAL_2026-11-09.md) registra correções
posteriores: carga de configuração exige objeto JSON; monitor trata saúde e
falhas da fonte, bloqueia cópia até refresh válido e atualiza os widgets de faixa;
retorno do servidor automático é sinalizado em finally; ensaio manual usa
diagnósticos controlados sem imprimir token. As comparações de código inalterado
da etapa de comentários não abrangem essas alterações funcionais posteriores.

## Interface B3: interface/ciclo_tk.py

CicloTk pertence a uma janela e à sua thread Tk. Centraliza agendamentos,
cancelamento e consumo da fila de resultados. iniciar(chave, trabalho, aplicar)
deduplica a operação e registra o worker no proprietário B2 antes de start.
Root, geração, vínculo e proprietário são verificados antes da aplicação.
OperacaoInterface retém cancelamento e o vínculo capturado; o ContextVar do
worker permite à admissão B2 recusar partidas de uma operação antiga. A fila
nunca chama Tk a partir de worker, nem representa prova de encerramento.

JanelaConexao separa coleta/aplicação Tk de descoberta, HTTP, arquivos e partida
operacional. JanelaTC420 usa esse mecanismo nas duas promoções e agenda apenas
observações locais. Fechamento invalida callbacks; o scheduler de saída continua
ativo enquanto B2 precisa informar pendência ou observar confirmação.

## Saída B1/B2: interface/saida_aplicacao.py

Correção em 09/11/2026: o callback `solicitar` inicializa sua referência local de
coordenação antes de construir o worker e a conserva até `start()`, após o
bloqueio das admissões. A referência não é mais sobrescrita por `None` entre a
construção e a partida. O agendamento Tk continua observando a confirmação
operacional, sem destruir a janela antecipadamente. Em `interface/janela.py`, a
confirmação manual de promoção invoca `_iniciar_promocao` uma única vez.

SaidaAplicacao é criado uma vez por main.iniciar e compartilhado pelos caminhos
cliente/manual/automático. Entradas isoladas aceitam injeção opcional ou criam
um proprietário local. Cada monitor recebe callback com vínculo próprio;
substituição revoga o callback anterior e pedidos repetidos/concorrentes não
duplicam a coordenação ativa. Com a montagem instalada, B2 fecha gates, acompanha
inicializações e partidas e executa parada/cleanup em workers. Reavaliação tem
prazo de 10 s por tentativa e aceita novo SIM após falha/timeout; não duplica
cleanup ativo. Leitores, contextos/ciclos e observadores permanecem retidos por
instância, inclusive promoção e rebaixamento. Nenhuma decisão usa modo_atual.
Promoção não transfere o callback a outro dono operacional por variável global.
O fluxo manual não conclui pela mera sinalização de servidor_encerrado.
O observador Tk permite concluir somente com parada_operacional_confirmada;
certificação global permanece desconhecida. O coordenador experimental não foi
usado como atalho para um positivo global. Entradas isoladas sem montagem
mantêm compatibilidade B1 sem ganhar confirmação. Detalhes em PRONTIDAO.md.

InfraestruturaRegistrosCliente instala o proprietário uma vez, fecha gates e
fornece tarefas/provas dos registros existentes. RegistroRecursosCliente permite
enumerar IDs e interromper/fechar objetos fora do lock. Handles incertos são
limpos após os produtores, sem regularizar associação desconhecida. Erros reais
de limpeza e recursos ainda em uso impedem a conclusão operacional.

No servidor, solicitar_parada_ciclo verifica o ID antes de sinalizar e interrompe
sockets acompanhados. O sinal da aplicação conserva a parada apesar de clear
tardio. iniciar_servidor aguarda apenas trabalhadores efetivamente iniciados,
evitando join em partida recusada. No leitor, entrada tardia respeita a parada
da execução. Nenhum protocolo, formato de peso ou critério de eleição mudou.

## Orquestração: main.py

`obter_credenciais_salvas()` retorna IP/usuário/senha em memória ou None quando
indisponível/desativado/incompleto. Não conecta nem imprime credenciais.
O callback interno tentar_promocao_automatica reaproveita promover_para_principal
ou retorna False sem credencial. É passado à GUI e chamado uma vez por pulso
de candidatura. Sucesso conclui no mesmo monitor; falha entra na espera do
controlador; sem credencial abre manual somente com estado liberada.

`tentar_login_automatico()` retorna False quando indisponível/falho, ou objeto
modo cliente/servidor se uma segunda busca encontrar principal, ou objeto
modo principal/web/configuracao após autenticação, approval e start do servidor.
Não cria GUI nem salva configuração/credencial. Só inicia após ausência de
servidor na primeira busca de iniciar; sucesso abre monitor diretamente e
falha cai na tela manual. Porta salva permanece sem efeito no HTTPS.

`iniciar()` decide principal ou cliente pela descoberta inicial e delega o
caminho cliente a `iniciar_como_cliente(servidor)`, função reutilizável. No cliente,
injeta os getters do leitor na GUI e define o callback de promoção. Espera
configuração por até cinco segundos antes de abrir o monitor. O `finally`
encerra o leitor ao sair do mainloop; falha antes de entrar nesse bloco não é
coberta por esse cleanup.

O callback local de `iniciar_como_cliente`, `promover_para_principal(ip, usuario, senha)`, retorna `None`
em cancelamento/falha ou um dicionário com `web`, `configuracao`, `fonte_dados`.
Encontrar servidor cancela sem registrar falha. Exceções registram falha no
controlador. O log de promoção mostra somente o tipo da exceção, evitando URLs
que poderiam conter credenciais. Não utiliza o módulo de persistência ainda.

## Interface

### interface/conexao.py — JanelaConexao

Cria Tk de 480×480 com nome, IP, porta, usuário, senha e opção de salvar login.
Carrega JSON e, quando marcado, a senha do cofre. Sem arquivo: nome/senha vazios,
opção desmarcada, IP `192.0.2.21`, porta `9800` e usuário `admin`.
Enter aciona conectar. Valida nome, IP, porta inteira 1–65535, usuário e senha.
Antes do login busca servidor; se encontrar, destrói root e chama o callback
ao_encontrar_servidor, sem HTTP/persistência. Sem callback informa erro e retorna.
Sem servidor,
desabilita botão, faz login síncrono e obtém configuração. Publica CONFIG antes
do servidor. `servidor_iniciado` evita outro start nessa instância.

`abrir_monitor()` oculta o root e cria Toplevel com a mesma instância web e fonte
local do servidor. `executar()` inicia mainloop. Após login e approval salva
parâmetros; marcado salva senha, desmarcado remove a do usuário atual. Porta é
apenas persistida. Esta tela ainda imprime token no console
e texto bruto de exceções; não compartilhar esses logs sem revisão.

### interface/janela.py — JanelaTC420

Parâmetros opcionais: `web`, `configuracao`, `fonte_dados`,
`candidatura_liberada`, `estado_candidatura`, `ao_promover`, `master`.
Com master usa Toplevel; sem master cria e possui Tk. Painel 620×230 com
cabeçalho preto, peso e tara amarelos, faixa e indicadores. Sem configuração,
usa o fallback W1.1: 10/200/80000 kg; W1.2: 20/400/140000 kg.

`atualizar_refresh_web()` consulta fonte injetada e atualiza widgets. Erros são
impressos e o callback continua enquanto `executando` for verdadeiro.
`verificar_candidatura()` distingue espera de cancelamento e controla abertura
única de ASSUMIR. Não cria thread para consultar eventos.

`abrir_janela_promocao()` cria Toplevel 340×230; se já existir, traz à frente.
`concluir_promocao(resultado)` centraliza a troca de fonte e sessão usada pelo
caminho manual e automático. A GUI recebe ao_promover_automaticamente sem
conhecer Credential Manager. False não é resultado de promoção bem-sucedida.
Usa IP/usuário iniciais iguais à tela de login. Valida os três campos; botão e
Enter chamam callback. `promocao_em_andamento` evita reentrada. Falha mantém
janela e fonte anterior. Sucesso troca fontes e fecha diálogo. `finally`
limpa a trava. Senha não é impressa, gravada em arquivo ou enviada ao leitor.

`fechar_janela_promocao()` destrói diálogo e limpa referência. `fechar()` para
atualizações e destrói monitor. `executar()` inicia os dois callbacks e executa
mainloop apenas quando dona do root.

`iniciar_leitura()`, `ler_balanca()` e `atualizar_peso()` são o caminho TCP direto
legado. Não são chamados pelo fluxo normal de main. A classe ainda instancia
`ConexaoTC420`, mas isso por si só não abre conexão.

## Rede

### rede/servidor.py

`obter_saude_tc420()` retorna cópia protegida por lock_saude: saudavel,
falhas_consecutivas, ultimo_sucesso (epoch time.time) e ultimo_erro (texto).
Começa False/0/None/None. Sucesso HTTP marca True, zera falhas/erro e registra
horário. Uma ou duas falhas após sucesso preservam True; terceira marca False.
Aviso de perda apenas na transição da terceira falha; sucesso avisa ao passar
de False para True. Falha isolada recuperada não repete aviso de estabelecimento.
Estado controla CHECK e UDP: respondem somente quando saudável. SUBSCRIBE e eleição permanecem intactos.

Mantém `dados_atuais`, `configuracao_atual` e `clientes_registrados` em memória.
`definir_configuracao()` substitui cópia superficial. `obter_dados_atuais()`
retorna cópia. `ler_tc420()` consulta a balança continuamente, captura erros e
preserva último estado. Não faz login.

`atender_cliente()` implementa quatro comandos e fecha socket no finally.
`servidor_tcp()` aceita e cria thread daemon por conexão. `servidor_descoberta()`
responde UDP. `iniciar_servidor(web)` rejeita instância sem token, inicia três
rotinas e permanece aguardando. Executar este arquivo diretamente apenas
imprime orientação; não inicia serviço sem sessão autenticada.

### rede/buscarservidor.py

`buscar_servidor()` usa broadcast, filtra resposta e chama `confirmar_servidor`.
Retorna IP ou `None`; timeouts/erros não promovem máquina. Execução direta imprime
o resultado. A confirmação sempre fecha seu socket.

### rede/lerdadosserver.py — LeitorDadosServidor

Getters retornam peso/configuração, posição, eventos, estado e contador.
`obter_max_tentativas_recuperacao()` retorna 10. Estado e tentativa são lidos sob
lock; getters separados não constituem um snapshot atômico dos dois campos.
`definir_estado_candidatura()` não valida enumeração e altera somente estado.

`iniciar()` é idempotente enquanto executando. `_manter_atualizado()` mantém
loop de conexão, trata EOF/exceções, limpa stream/socket, esquece IP após queda
e preserva dados. `_aguardar_candidatura()` atribui oportunidade inicial;
`registrar_falha_recuperacao()` agenda worker somente quando liberada e abaixo
do limite; `_aguardar_proxima_tentativa()` libera novo pulso ou cancela.
`aguardar_configuracao()` usa Event.wait sem polling. `parar()` encerra estados,
mas preserva última configuração, dados e posição. Não importar WebTC420 aqui.

Execução direta usa descoberta e mantém o terminal vivo pelo join da thread.
Ctrl+C chama parar. CONFIG e REGISTER usam conexões curtas com timeout de 5 s.

## Comunicação com o equipamento

`tc420/web.py`: cliente HTTPS e parsers, conforme [protocolos](PROTOCOLOS.md).
`tc420/conexao.py`: socket direto e buffer de frames de 18 bytes.
`tc420/protocolo.py`: extração em kg, conversão em toneladas e alias compatível
`interpretar_peso`. Nenhum desses módulos implementa eleição ou persistência.

## Persistência

`config/configuracao.py`: resolve caminho na raiz, salva/lê JSON e opera keyring.
Contrato e tratamento de erro em [CONFIGURACAO.md](CONFIGURACAO.md).
`configuracao.json`: artefato atual de teste com nome “Balança Teste”; não prova
configuração de produção e não contém senha.

## Scripts, imagens e pacotes

| Arquivo | Papel |
| --- | --- |
| `teste_approval.py` | Teste manual real: pede credenciais, imprime token, approval e refresh a cada 0,5 s; Ctrl+C encerra monitoramento |
| `tc420.py` na raiz | Experimento TCP direto; executa conexão ao ser carregado como script |
| `assets/null_cursor.png` | Indicador de zero; reduzido por subsample(8,13) |
| `assets/settled.png` | Indicador de estabilidade; subsample(13,10) |
| `assets/transparent.png` | Imagem presente; não referenciada pelo código Python atual |
| `config/__init__.py` | Inicializador vazio do pacote de persistência |
| `interface/__init__.py`, `rede/__init__.py`, `tc420/__init__.py` | Inicializadores de pacotes |

Os scripts manuais acessam o equipamento; não importá-los como testes unitários
e não executá-los junto do principal para validar a regra de uma autenticação.

## Encerramento de SUBSCRIBE por saúde

Antes de cada envio, SUBSCRIBE consulta saúde. Quando False, registra encerramento e retorna; finally fecha socket e cliente recebe EOF. Clientes existentes entram na busca/candidatura normal. CHECK e UDP continuam condicionados à saúde. A rotina HTTP antiga permanece ativa nesta etapa. Teste real deve terminar ao iniciar contagem de candidatura, antes da promoção, para não disputar a TC420. Desligamento após 25 s implementado; rebaixamento para cliente ainda pendente.

## Parada voluntária do servidor

Evento global evento_parada_servidor e APIs solicitar_parada_servidor()/servidor_deve_parar(). Leitura e SUBSCRIBE verificam evento e usam Event.wait para interromper pausas. TCP accept e UDP recvfrom têm timeout de 1 s para conferir parada; finally fecha sockets. iniciar_servidor limpa evento após validar token, acompanha threads e faz joins de até 2 s por thread. Ctrl+C solicita parada. Chamar em outro processo não afeta o servidor original. Após a terceira falha HTTP consecutiva, inicio_indisponibilidade registra time.monotonic(). Uma nova falha concluída após 25 s solicita parada e encerra a leitura. Sucesso limpa o prazo. HTTP em andamento pode atrasar o encerramento. main.py ainda não converte o principal em cliente.

HTTP em andamento não é cancelado: aguarda retorno/timeout. Joins limitados não garantem fim de toda operação bloqueada; handlers com recv/send bloqueados não são acompanhados individualmente. Reiniciar somente após confirmar que as threads anteriores terminaram; não iniciar servidores concorrentes com o mesmo evento. Saúde, dados, configuração e registros não são zerados automaticamente no restart.

## Detecção do encerramento em main.py

No caminho de login automático de main.py, tentar_login_automatico() cria servidor_encerrado (threading.Event) e devolve esse evento no resultado principal. A thread executa iniciar_servidor(web), registra MAIN: servidor PRINCIPAL foi encerrado. e sinaliza o evento após retorno normal. iniciar() cria observador daemon que aguarda o evento, registra a detecção e inicia LeitorDadosServidor(permitir_candidatura=False) em background. O observador não acessa Tkinter; a descoberta é executada pelo leitor. Monitor permanece aberto e troca a fonte pelo leitor conectado através do callback da interface. Caminhos de login manual e promoção não receberam esse mecanismo. O sinal representa retorno normal, sem distinguir abandono por saúde de parada voluntária; exceção não tratada no servidor não sinaliza o evento.

## Variáveis na espera de recuperação

_aguardar_proxima_tentativa retorna imediatamente no ramo de servidor encontrado; no caminho restante define tempo_restante e tentativa antes das consultas posteriores. Mantém cancelamento, prazo e incremento de tentativa.

## Leitor sem candidatura

LeitorDadosServidor aceita permitir_candidatura=True por padrão. Com False, _aguardar_candidatura retorna False antes de iniciar contagem ou liberar candidatura. Após perda da conexão, o ciclo continua buscando servidores com intervalo de reconexão. CONFIG, REGISTER e SUBSCRIBE permanecem iguais; a posição de sucessão continua registrada. Clientes existentes preservam o padrão True. main.py usa esse modo no observador de encerramento do servidor iniciado por login automático. O parâmetro é definido na criação; não implementa cancelamento de candidatura já ativa nem guarda adicional na rotina de próxima tentativa. A troca da fonte e a parada do leitor ao sair do monitor estão integradas para o login automático.


O evento de encerramento representa retorno normal do servidor, sem distinguir motivo de parada. A integração atual do monitor e cleanup está descrita abaixo.

## Troca de fonte e encerramento do leitor rebaixado

No principal iniciado por login automático, main.py compartilha leitor_rebaixado e leitor_pronto com o monitor. O observador publica o leitor sem candidatura e sinaliza pronto após iniciar(). Antes de executar(), chama observar_rebaixamento; o callback da interface troca a fonte somente quando servidor_esta_respondendo sinaliza conexão. A mesma janela é mantida. Um finally sinaliza monitor_encerrado e chama parar no leitor existente. Lock serializa criação/início e cleanup; observador verifica fechamento enquanto espera o servidor e não cria leitor após cleanup. A espera usa timeout de 0,1 s, e o cleanup acompanha observador com join de até 1 s. Também cobre erro na construção/agendamento do monitor. Login manual possui integração controlada própria; promoção ainda não possui integração. O sinal de conexão não garante que o primeiro pacote já chegou; main não zera web/configuração nem atualiza cabeçalho. Parar usa o ciclo de vida existente do leitor, sem join adicional da thread TCP.

## Encerramento do servidor no login manual

JanelaConexao cria servidor_encerrado (threading.Event) após servidor_iniciado=False. No login manual, thread daemon executa wrapper que chama iniciar_servidor(self.web) com a mesma sessão autenticada; finally registra CONEXAO: servidor PRINCIPAL foi encerrado. e sinaliza evento tanto no retorno normal quanto em exceção. Exceções continuam propagando na thread. Evento não distingue abandono de outro motivo e indica fim da rotina, sem garantir fim de toda thread interna. A detecção recebeu integração posterior com leitor e monitor; veja a seção de integração manual.

## Integração manual do leitor e monitor

No login manual, JanelaConexao mantém leitor_rebaixado e leitor_pronto. Ao iniciar o servidor, inicia também observador daemon; após servidor_encerrado, cria LeitorDadosServidor(permitir_candidatura=False), publica instância, inicia leitor e sinaliza pronto. abrir_monitor conecta observar_rebaixamento ao evento/callback e mantém atualizar_refresh_web. Troca da fonte acontece no callback Tk, quando leitor sinaliza conexão, na mesma Toplevel. Qualquer término da rotina servidor dispara esse fluxo, sem distinguir causa. Nesta etapa não há encerramento do leitor junto com a janela nem cancelamento do observador; integração controlada, não recuperação final para uso contínuo. Login por promoção permanece sem essa integração.

## RegistroTrabalhadores — estrutura implementada sem integração

RegistroTrabalhadores implementado em rede/servidor.py. Cada iniciar_servidor cria instância local independente; agora registra apenas os três trabalhadores principais, sem handlers. registrar_e_iniciar protege registro/start com lock, recusa se criação bloqueada e remove referência/propaga exceção de start. bloquear_criacao impede novos registros. obter_situacao retorna gate, nomes das threads vivas por is_alive e cópia de erros; encerramento_confirmado exige gate fechado, nenhuma thread viva e nenhum erro de limpeza. Erros são registrados explicitamente, sem captura automática de trabalhadores; falha de start é propagada, não adicionada a erros_limpeza. Destinado a objetos Thread distintos com uma chamada de início por objeto; não implementa deduplicação de referências repetidas. Os starts principais agora usam registrar_e_iniciar, joins existentes preservados; registro não é exposto externamente nem passado aos handlers. Logo confirmação da classe ainda não abrange todos os trabalhadores do servidor real; passagem por ciclo e integração futura pendentes.

## Registro dos três trabalhadores principais — etapa atual

iniciar_servidor agora inicia os mesmos objetos thread_tcp, thread_udp e thread_dados via registro_trabalhadores.registrar_e_iniciar. Depois do loop/KeyboardInterrupt bloqueia criação antes dos três joins timeout=2 existentes. Após joins imprime nomes de trabalhadores principais vivos consultando obter_situacao; diagnóstico não autoriza fechamento. Handlers ainda iniciam diretamente e não participam do registro. Se segundo/terceiro start falha, referência falha é removida e exceção propaga antes do try do loop: threads anteriores podem permanecer vivas, evento de parada não é sinalizado por esse erro e gate não é bloqueado. Inicialização parcial ainda sem cleanup; corrigir antes de teste físico. Registro continua local sem API externa ou sinal de trabalhadores encerrados.

## Controle de ciclos — estrutura disponível sem uso no fluxo

rede/servidor.py define ControleCicloServidor após RegistroTrabalhadores e
controle_ciclo_servidor, única instância compartilhada no módulo. Consulta do
registro anterior e reserva são serializadas pelo mesmo lock. Estados:
livre inicial, executando após reserva, livre ou pendente após finalização
conforme encerramento_confirmado. A identidade em finalizar é o próprio
registro, exigindo registro novo por ciclo. Sem espera de trabalhadores,
limpeza automática de erros ou alteração do evento global.

Estrutura testada isoladamente, ainda não chamada por iniciar_servidor.
Comportamento operacional, interface, protocolo e eleição preservados;
inicializações concorrentes reais continuam possíveis. Próxima etapa prevista:
passar registro aos handlers TCP; só depois proteger iniciar_servidor. Handlers
atuais fora do registro impedem interpretar confirmação como término completo.

## Repasse do registro ao TCP — primeira parte

servidor_tcp agora aceita registro_trabalhadores=None; thread_tcp recebe o
registro local de iniciar_servidor por kwargs. Assinatura anterior sem argumentos
continua compatível. Corpo TCP intacto e parâmetro ainda sem uso: handlers não
são registrados. Controle global, evento, joins, interface, protocolo e eleição
preservados. Próxima etapa requer coordenar registrar_e_iniciar dos handlers com
bloqueio de criação e avaliar operações de socket bloqueadas após fim do listener.

## Rastreamento dos handlers — integração atual

servidor_tcp agora usa o registro recebido para iniciar handlers sob seu lock.
None mantém início direto; recusa fecha cliente e start falho fecha/propaga.
O fluxo normal passa a acompanhar handlers no registro local do ciclo, superando
a lacuna de início direto. Referências são retidas após término. Não há interrupção
de handlers bloqueados, joins adicionais ou integração do controle global.
Accept, destino/argumentos do handler, sockets ativos, protocolo e eleição
preservados. Recuperação parcial e exclusividade operacional continuam pendentes.

## Controle operacional e recuperação parcial — etapa atual

iniciar_servidor agora reserva controle global após validar sessão, antes de clear.
Recusas não alteram evento nem finalizam ciclo alheio. Try externo cobre todo o
ciclo reservado; finally bloqueia criação e finaliza registro correto, mantendo
referência global em pendente enquanto houver vivos ou erros. Sessão inválida
não reserva. Estados/identidade da classe de controle não foram alterados.

Exception dispara gate, parada, cópia do registro e joins com prazo total de dois
segundos, incluindo handlers iniciados; erros de limpeza registrados sem ocultar
exceção original. Erro na limpeza normal também impede confirmação. Joins normais
e lógica operacional original preservados; o evento inicializado continua logo
após clear. Interface/protocolo/eleição intactos. A próxima revisão precisa tratar
servidor_encerrado: retorno do coordenador ainda não prova fim dos trabalhadores.

## Consulta pública do ciclo — disponível sem consumo na interface

rede/servidor.py expõe consultar_estado_ciclo_servidor, leitura sob lock do
controle e do registro, retornando estado e confirmação calculada por gate,
vivos e erros. Sem registro: livre/True; com registro: inclui listas de vivos e
erros. Consulta não modifica controle ou fluxo operacional. Pendente/True após
término tardio é esperado. Representa ciclo atual do módulo, sem associação
à instância de janela. Interface, servidor_encerrado, timeout, recuperação,
protocolo e eleição intactos; uso para fechar janelas ainda não implementado.

## Identidade integrada ao controle e à consulta

ControleCicloServidor atribui ID crescente somente na reserva aceita, publicando
ciclo_id e registro.ciclo_id sob lock, com retorno bool. Consulta aceita ID opcional
e distingue ausente/correspondente/divergente; divergência retorna confirmação
None sem estado/listas do ciclo novo. Sem filtro campos anteriores preservados.
finalizar por identidade do objeto inalterado. Inicialização/parada, interface,
protocolo e eleição intactos; janela ainda sem associação. IDs locais à instância
compartilhada do controle no processo, sem persistência/histórico.

## Entrega direta de identidade — disponível sem consumo nas janelas

rede/servidor.py define ContextoCicloServidor e parâmetro contexto_ciclo opcional
em iniciar_servidor. Contexto resolve uma vez com ID do registro reservado ou
classificação sanitizada sem ID antes da reserva. Evento resolvido é independente
do evento inicializacao após clear. Publicação fora do lock do controle e sem
Tk/global tardio. Corpo operacional, recuperação, finalização, protocolo e eleição
preservados. main/conexao/janela ainda sem contexto; próxima etapa será manual.

## Contexto do ciclo na conexão manual

interface/conexao.py importa ContextoCicloServidor, inicializa contexto/ID na
JanelaConexao e cria contexto por tentativa aceita pelo fluxo local antes da
thread. Wrapper preservado entrega contexto ao servidor; observação com after
armazena ID somente após resolvido, verificando identidade do contexto.
Sem Tk na thread do servidor, wait bloqueante ou consulta global tardia.
Encerramento, monitor/fonte, eventos, servidor, main, protocolo e eleição intactos.
Integração apenas manual; ID ainda não usado como autorização para fechar.

## Identidade no login automático

main.py importa ContextoCicloServidor, cria um por tentativa automática, repassa
pelo wrapper e retorna referência em contexto_ciclo junto dos campos anteriores.
Resultado fica retido em iniciar durante monitor; sem bloqueio ou consulta global.
Monitor/fonte/observador/cleanup intactos. Sem alteração manual, servidor ou promoção.
Wrapper automático não ganhou finally; diferenças de acompanhamento permanecem.
Próxima associação prevista: promoção manual/automática, antes de fechar Tk pela
confirmação real dos trabalhadores.

## Detecção de silêncio SUBSCRIBE

- `rede/lerdadosserver.py`: prazo monotônico de seis segundos, recepção `recv()`
  com acumulador, validação de linha completa, estado local de frescor e entrada
  no fluxo existente de recuperação.
- `rede/infraestrutura_cliente.py`: fachada de socket acompanhado expõe `recv()`
  sob o mesmo registro de uso e fechamento.
- `main.py`: injeta no monitor CLIENTE o callback local de comunicação atual.
- `interface/janela.py`: diferencia visualmente última leitura de medição atual e
  restaura o display normal somente após pacote válido.
- `tests/test_silencio_subscribe_cliente.py`: nove regressões específicas do
  defeito físico, sem transporte real.

Não houve mudança nas mensagens CONFIG, REGISTER, SUBSCRIBE, CHECK nem no formato
JSON entre computadores. A validação física da correção permanece pendente.

## Menu e registro do terminal

- `interface/registro_terminal.py`: instala uma saída espelhada no ponto de
  entrada real, conserva stdout/stderr originais e oferece retrato thread-safe do
  histórico recente limitado e sanitizado para exportação, com contadores de cortes.
- `interface/janela.py`: abre o menu por popup explícito, exporta `.txt`, mostra
  informações e solicita reconfiguração sem antecipar a conclusão B2.
- `main.py`: depois da parada comprovada, abre nova execução com
  `--reconfigurar`; esse modo constrói diretamente `JanelaConexao`.
- `interface/conexao.py`: reutiliza o callback de reconfiguração armazenado no
  proprietário `SaidaAplicacao` ao criar o monitor manual.

Não foram alterados protocolo, eleição, candidatura ou prazos de recuperação.

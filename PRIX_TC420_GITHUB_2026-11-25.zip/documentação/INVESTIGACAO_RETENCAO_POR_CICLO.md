# Etapa 2B.4 — investigação isolada da retenção por ciclo

12/11/2026. Política operacional **não implementada**. Nenhum arquivo operacional
foi alterado; nenhuma execução física ou nova carga de rede foi iniciada.
O ensaio de uma hora da 2B.3 está encerrado e consolidado.

## Contratos e referências

`ControleCicloServidor._compactar_ciclo` substitui a entrada histórica pelo resumo
somente com confirmação positiva: coordenador finalizado, publicação concluída,
gate fechado, nenhuma thread viva, nenhum erro e prova de sockets resolvidos.
Recusa pendências e aceita repetição. Mantém um resumo por ID, portanto ainda
existe crescimento proporcional à quantidade de ciclos, embora menor.

O resumo preserva a situação histórica do controle e a avaliação pelo contexto.
`ContextoCicloServidor` contém ID/eventos/categorias, não o RegistroTrabalhadores.
SaidaAplicacao e SupervisaoPrincipal conservam contextos; esses vínculos por si
só não exigem reter o registro operacional completo. O registro de tentativas
da aplicação é outra estrutura e não deve ser confundido com trabalhadores.

Referências que podem impedir liberação do registro completo:

- `_historico[id].registro` e `registro_atual`, até serem substituídos;
- um único token externo: token.dono aponta para o registro, que retém todos os
  tokens, entradas, threads e recursos conhecidos;
- referência direta ao registro, frames/callbacks/harnesses ainda alcançáveis;
- snapshots de diagnóstico: não retêm o registro/token diretamente, mas mantêm
  sua própria memória de dicionários, IDs e valores.

Threads padrão normalmente soltam argumentos ao terminar; não se deve presumir
isso para wrappers/dublês ou frames preservados por outros componentes. A coleta
de ciclos do GC só ajuda quando não há raiz externa alcançando o registro.

## Medição sintética isolada

Harness explícito: `python -B tests/investigar_retencao_ciclo.py`.
Resultados em [INVESTIGACAO_RETENCAO_CICLO_2B4.json](INVESTIGACAO_RETENCAO_CICLO_2B4.json).
Python 3.13.15, win32; 50.000 reservas sem alocação por cenário, GC explícito,
sem threads iniciadas ou sockets criados. Tracemalloc, não RSS/memória total.

| Raiz externa mantida | Bytes antes | Bytes após compactar | Registro coletado? |
| --- | ---: | ---: | --- |
| Nenhuma | 13.817.768 | 1.104 | Sim |
| Um token | 13.814.832 | 13.814.896 | Não |
| Registro direto | 13.814.808 | 13.814.872 | Não |
| Diagnóstico completo | 27.815.208 | 15.593.288 | Sim |

Ao soltar a raiz externa e executar GC, os quatro cenários ficaram próximos de
1,1 KB rastreado e o registro foi coletado. Isso demonstra dependência das raízes,
não um limite de memória do processo. As pequenas diferenças entre cenários
incluem objetos de instrumentação. Picos e tempos constam do JSON. Uma execução
por cenário; não é benchmark estatístico nem comparação com carga real mista.

No cenário com token externo, a repetição de fechar_socket retornou True,
publicar_limpeza_handler sem responsabilidade retornou False e os 50 mil
diagnósticos permaneceram consultáveis pelo dono original. O mecanismo atual
não revoga tokens nem apaga entradas do registro externo: preserva o contrato,
ao custo de conservar toda a memória enquanto esse token existir.

## Incompatibilidade reproduzida antes de qualquer ativação

Quando se compacta o ciclo que ainda é `registro_atual`, o método troca esse
atributo por `_ResumoHistoricoCiclo`. A consulta pública de situação continua
funcionando, mas `solicitar_parada_ciclo(mesmo_id)` faz:

1. aceita a identidade atual e sinaliza o evento de parada;
2. chama registro.bloquear_criacao();
3. lança AttributeError: o resumo não possui esse método, lock ou reservas.

O harness reproduziu essa exceção e a registrou como achado esperado, não como
uma aprovação desse comportamento. A integração automática direta é inadequada.
Há também uma janela concorrente a considerar: um pedido de parada pode capturar
o registro antes da substituição e continuar usando-o fora do lock do controle.
Nunca revogar essa referência ou mutilar o registro enquanto a operação existir.

Depois que outro ciclo assume, pedido de parada pelo ID antigo retorna False
antes de acessar o registro atual. A avaliação do contexto antigo permanece
confirmada após a compactação. Isso favorece investigar apenas ciclos anteriores,
sem compactar o apontado como atual. Não constitui autorização para integrar.

## Política candidata — proposta, não implementação

Primeira alternativa a avaliar: ao admitir um novo ciclo, manter integralmente
o atual e compactar somente IDs anteriores com prova positiva de encerramento.
Isso evita trocar registro_atual por um resumo enquanto ele ainda pode receber
pedidos de parada pela mesma identidade. Pendências, erros e ciclos sem prova
positiva permanecem integrais, sem prazo de descarte automático.

A chamada de compactação não pode ser feita recursivamente sob o lock não
reentrante do controle. A integração futura deve separar decisão e execução,
revalidar o ID original e conservar a ordem controle→registro. Nenhum close/join
ou GC forçado deve ser colocado no Tk ou sob lock global.

Manter tokens externos válidos significa aceitar que eles podem impedir a
liberação. Ganho deve ser medido com referências reais das montagens manuais,
automáticas e promovidas; não assumir que todos os registros ficarão coletáveis.
Diagnósticos individuais já capturados continuarão ocupando sua própria memória.

**Limitação central:** compactar ciclos encerrados não reduz o crescimento dentro
de um ciclo que continua executando por horas ou dias. O ensaio de uma hora
concentrou o histórico no mesmo ciclo. Logo, a política por ciclo pode melhorar
a retenção entre gerações, mas não resolve sozinha o caso operacional observado.
Resolver esse crescimento exigiria investigar outra representação compatível
ou aprovar explicitamente uma evolução de diagnóstico/identidade; não apagar
informações silenciosamente.

Antes de implementar: definir quando considerar um ciclo elegível, onde acionar
a política, semântica de parada tardia se houver mudança, retenção dos resumos
por ID e tratamento de referências externas. Qualquer revogação de token,
perda de diagnóstico ou alteração de API depende de aprovação explícita.

## Verificações realizadas

- Harness: confirmação recusada com reserva pendente; compactação repetida;
  igualdade histórica; avaliação positiva por contexto; parada tardia do ciclo
  atual reproduzindo incompatibilidade; pedido antigo recusado após novo ciclo;
  quatro cenários de retenção medidos com weakref e GC.
- **104 testes existentes aprovados em 3,056 s**: guarda de sockets integrada,
  erros de handlers, B2 e supervisão do PRINCIPAL.
- Sintaxe do novo harness verificada. Não foi executada nova regressão completa
  nem ensaio físico nesta investigação.

Conclusão: investigação 2B.4 concluída neste escopo; ativação operacional segue
não implementada. Nenhuma nova janela de várias horas foi iniciada.

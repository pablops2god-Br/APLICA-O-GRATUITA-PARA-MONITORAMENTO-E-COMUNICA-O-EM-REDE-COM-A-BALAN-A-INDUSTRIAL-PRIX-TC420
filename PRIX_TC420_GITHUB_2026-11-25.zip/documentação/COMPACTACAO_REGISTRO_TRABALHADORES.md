# Etapa 2B.2 — representação compacta de reservas resolvidas

Decisão anterior à alteração de código — 12/11/2026.

A: representação por reserva com slots, preservando campos e token. Escolhida:
menor intervenção, ganho a medir, crescimento ainda linear.
B: compactação de ciclos completos exige integração de ciclo de vida e não
elimina referências externas; não ativar automaticamente.
C: separar accept de identidade do socket altera a admissão conservadora;
exploratória, não adotada.

Plano: nova dataclass privada congelada com slots e os mesmos oito campos da
entrada operacional. Converter somente na resolução sem alocação comprovada,
sem recurso, erro, uso ou pendência de handler. Reter o token original, ID,
ordem no dicionário e todos os diagnósticos. Não remover entradas, threads,
erros ou sockets. Transições pendentes continuam usando a estrutura original.
Retornos repetidos e publicações tardias continuam reconhecendo o mesmo token.
Não alterar predicados de encerramento, locks, B2, supervisão ou interface.
A conversão ocorre sob o lock existente; sem close, join ou novo lock.

## Implementação efetiva

`rede/servidor.py` agora contém `_CriacaoSocketResolvida`, dataclass congelada
com slots, sem dicionário por instância. `resolver_falha_criacao_socket` a utiliza
somente após prova explícita de ausência de alocação e recurso None, com erro
None e sem pendência/erro de handler. O estado em uso passa a False pela mesma
transição preexistente. O resultado de publicação de handler é copiado.

O token é o mesmo objeto; não mudou a comparação por identidade. Não foram
alterados assinaturas, formatos, ordem nem conteúdo de `obter_situacao`.
`fechar_socket` continua True em repetição para sem_recurso e publicação sem
responsabilidade de handler continua False. Reservas incertas ou com erro não
são convertidas. Nem sockets fechados nem threads foram compactados.
Não existe varredura automática adicional nem descarte por idade/quantidade.

Callbacks tardios seguem pelos métodos existentes: entradas continuam presentes,
com campos equivalentes e dataclasses.replace disponível. Não há fechamento ou
publicação em andamento elegível para conversão. Nenhum predicado B2/histórico
ou da supervisão foi modificado. O mecanismo de compactação de ciclos completos
continua sem nova integração operacional.

## Medição reproduzível

Executado antes e depois de alterar servidor.py:
`python -B tests/medir_compactacao_registro.py`. Python 3.13.15, win32,
tracemalloc, GC antes da coleta, 50.000 reservas resolvidas sem alocação.
Arquivos [antes](MEDICAO_REGISTRO_2B2_ANTES.json) e
[depois](MEDICAO_REGISTRO_2B2_DEPOIS.json).

| Indicador | Antes | Depois |
| --- | ---: | ---: |
| Entradas e diagnósticos individuais | 50.000 | 50.000 |
| Referências de threads / handles | 0 / 0 | 0 / 0 |
| Bytes Python retidos | 16.217.992 | 13.817.032 |
| Pico da carga, bytes | 16.228.984 | 13.828.128 |
| Tempo da carga, segundos | 3,124 | 3,445 |
| Consulta completa, segundos | 0,130 | 0,115 |
| Pico absoluto durante consulta, bytes | 30.294.080 | 27.893.120 |

Redução de 2.400.960 bytes (aproximadamente 14,8%). A referência de 09/11 era
16.218.200 bytes, próxima da reprodução atual. A nova medição é isolada em
50 mil reservas; a anterior tinha pontos acumulados e seu script de registro
não está disponível. Não se presume equivalência bit a bit dos harnesses.
Os dois resultados atuais usam exatamente o mesmo script e ambiente.

Uma execução por versão, sem significância estatística de desempenho. A carga
ficou mais lenta nesta amostra, pela conversão adicional; não há promessa de
ganho de velocidade. Consultas continuam O(n), constroem todos os dicionários
individuais sob o lock existente e têm alocação temporária significativa.
Não foi adicionado trabalho ao Tk. Não são RSS, memória total ou sockets reais.

## Verificação

12 novos testes em `tests/test_compactacao_registro.py`: representação/token,
ausência comprovada, falsificação/outro ciclo/dono, repetições, equivalência
de diagnósticos/ordem contra representação original, incerteza/erro preservados,
close bloqueado fora do lock, fechamento concorrente, resultado tardio após
finalização, erro de handler, start ambíguo e histórico após novo ciclo.

Novos testes: 12 aprovados. Regressão: **2.043 testes aprovados em 22,223 s**,
incluindo os testes existentes de B2 e supervisão que exigem prova positiva
antes de recuperar o PRINCIPAL. **124 arquivos Python compilados em memória**.
Nenhum teste físico, novo teste Tk ou teste prolongado nesta etapa.

## Limitações e continuidade

A implementação reduz o custo por entrada elegível, mas conserva crescimento
linear de tokens, entradas e diagnósticos. Erros, threads e recursos conhecidos
permanecem retidos. A representação privada de uma entrada resolvida muda de
classe e não tem __dict__; nenhuma API pública expõe essa classe e a busca nos
consumidores não encontrou dependência de introspecção dela. Requer Python 3.10+
para slots em dataclass; validação executada em 3.13.15.

Próximas atividades: ensaio prolongado autorizado para avaliar o processo todo;
medição de carga representativa com conexões; avaliar separadamente threads e
sockets fechados. Uma limitação absoluta de histórico demandaria evolução do
contrato de diagnósticos/identidades, antes de qualquer descarte.


# Supervisão comum do PRINCIPAL — etapa 1, 09/11/2026

Regra vigente posterior em 13/11: a nova solicitação exige sucessão recorrente.
O leitor começa sem candidatura, porém a rearma após REGISTER/posição e medição
válida de outro PRINCIPAL, com ciclos locais anteriores confirmados. Antes da
fila e durante a espera, revalida autorização. A interface acompanha o evento
inclusive no monitor de login manual. Portanto, a restrição permanente das notas
anteriores foi substituída pelo [rearmamento condicionado](SUCESSAO_RECORRENTE_AB.md).

Atualização operacional de 13/11: o leitor recuperado continua com candidatura
automática desabilitada. A ação **Opções → Assumir manualmente** agora é
independente, com prova dos ciclos/tentativas anteriores e responsabilidades
CLIENTE conhecidas, duas descobertas, acesso à fonte e prontidão antes do anúncio.
Recusa pode pedir nova geração de leitor, somente após resolução positiva; o
monitor observa a nova geração sem trocar para dados antigos. Não há retentativa
automática de promoção. Ver [integração A/B](INTEGRACAO_RECUPERACAO_MANUAL_AB.md).
As descrições anteriores abaixo devem ser lidas com essa atualização.

Esta implementação trata somente ciclo de vida e recuperação após promoção.
Terminal, compactação de registros, bandeja, porta HTTPS, análise estática e
exclusividade distribuída permanecem em etapas separadas.

## Contrato implementado

`rede/supervisao_principal.py` define `SupervisaoPrincipal`, associada ao contexto
original da tentativa e ao mesmo `SaidaAplicacao` da execução. O monitor chama
`supervisionar_principal(contexto)` no login automático, na abertura do monitor
manual e na conclusão de promoção do cliente.

Cada contexto possui uma supervisão acompanhada pela B2. Repetir o contexto atual
devolve a mesma instância. Contexto anterior já supervisionado não substitui o
atual. Ao instalar outro contexto, a supervisão anterior é cancelada; seus
callbacks não podem alterar a fonte do ciclo novo.

O worker não acessa Tk. Aguarda resolução da reserva e retorno do coordenador.
Tentativa sem ciclo termina sem criar leitor. Depois consulta
`avaliar_encerramento_tentativa(contexto)`: somente `encerramento_confirmado is
True` permite recuperação. Trabalhador vivo, socket pendente, erro de limpeza,
retorno isolado ou resultado desconhecido não bastam.

Pedido de saída do proprietário e cancelamento local impedem recuperação. O
sinal da B2 distingue saída voluntária de retorno operacional, sem inferir essa
distinção apenas pelo evento global do servidor. O trabalho é admitido pelo
proprietário antes da construção do leitor, que usa a mesma infraestrutura,
`permitir_candidatura=False` e acompanhamento B2. A supervisão permanece registrada
até saída/cancelamento, quando para o leitor no próprio worker.

`pronto` significa leitor iniciado, não medição válida. O callback Tk só troca a
fonte quando `comunicacao_esta_atual()` confirma amostra válida. Até lá, conserva
o último peso identificado como antigo. Retorno do coordenador invalida a
comunicação principal mesmo se a saúde anterior ainda estiver positiva.

A mesma janela recebe fonte/frescor/configuração do leitor e mantém candidatura
desabilitada. Refresh imediato com `reagendar=False` evita criar outro loop.
Destruição da raiz cancela a supervisão; fechamento normal continua condicionado
à confirmação operacional B2, sem nova certificação global.

## Integração

- `main.iniciar`: observador exclusivo removido; entrega contexto ao monitor comum
  e cancela a supervisão ao sair desse escopo.
- `JanelaConexao`: observador de rebaixamento separado removido; preserva a
  supervisão de inicialização/saída e entrega contexto/infraestrutura/proprietário.
- `JanelaTC420.concluir_promocao`: associa o contexto promovido à mesma supervisão.
- `JanelaTC420.observar_rebaixamento`: API de compatibilidade mantida; os três
  caminhos operacionais acima não a usam para criar observadores adicionais.
- B2 e CicloTk: contratos reutilizados, sem alteração de autorização global.

Não houve mudança de comandos TCP/UDP, login HTTPS, tempos de candidatura ou
limites de tentativas. O leitor rebaixado reconecta sem se candidatar. Consenso e
exclusividade entre PCs concorrentes não foram implementados.

## Verificações e limites

Doze testes novos em `tests/test_supervisao_principal.py` usam contextos, registros,
threads e leitores reais acompanhados, com transporte e Tk controlados. Cobrem
duas perdas, ausência de ciclo, trabalhador/socket pendente, erro de limpeza,
saída voluntária, saída/cancelamento durante criação, falha de criação,
deduplicação, callback antigo e refresh sem segundo agendamento.

Na aceitação, B começa cliente com última leitura de A, é promovido, perde seu
ciclo e reconecta como leitor sem candidatura somente após prova de encerramento
e nova amostra válida. A identidade do monitor é conservada. Ao sair, a B2 confirma
parada operacional sem threads do leitor/supervisão restantes.

Regressão: **2.002 testes simulados aprovados em 23,652 s**. Compilação em memória
de **119 arquivos Python** e `git diff --check` aprovados. Ensaio offline com Tk
real e raiz oculta também passou: promoção, segunda falha, troca na mesma janela
e fechamento pela B2. Sem TC420, rede real, credenciais ou clique humano.

Os testes físicos anteriores continuam como registros históricos: `PRONTIDAO.md`
registra aprovações dos testes 1, 2, 3A, 3B e 4 em 30/10/2026, conforme responsável.
Não foram repetidos aqui. Após esta mudança, repetir segunda perda no principal
promovido e saída/reabertura; o Teste físico 5 não foi aprovado por esta etapa.

Prova pendente mantém recuperação pendente. Falha ao criar leitor registra somente
classe do erro e não publica prontidão; não há retry automático dessa criação
nesta etapa. Não se força fechamento nem se descarta responsabilidade ativa.

## Propostas para as próximas etapas

1. Limitar terminal, definir exportação/retenção e compactar só responsabilidades
   comprovadamente resolvidas.
2. Revisar NÃO/bandeja e separar porta HTTPS de TCP legado.
3. Executar análise estática, duração e regressão física dos cenários impactados.
4. Formalizar recuperação controlada e requisitos de posse distribuída.

São propostas separadas, sem implementação ou validação nesta etapa.

Atualização posterior: a etapa 2A implementou somente a parte do terminal,
conforme [RETENCAO_TERMINAL.md](RETENCAO_TERMINAL.md). Compactação dos registros,
ensaio prolongado e demais propostas continuam separados da etapa 1.

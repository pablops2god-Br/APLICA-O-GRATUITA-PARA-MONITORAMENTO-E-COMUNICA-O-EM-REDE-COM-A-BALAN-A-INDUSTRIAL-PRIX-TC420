# Ficha de execução física — supervisão do PRINCIPAL

## Evidências recebidas em 13/11/2026

### Novos logs: fila rearmada, cancelamento posterior de ASSUMIR

Anexos 399e12de e 3876838d fornecidos pelo responsável: neste ensaio B inicia
PRINCIPAL, A conecta como CLIENTE com posição 1, depois promove com prontidão
TCP/UDP/HTTP. B abandona o ciclo inicial, encontra A, recebe posição 1 e registra
explicitamente candidatura rearmada. Após A abandonar sua fonte, B conta 30 s,
sinaliza candidatura e a interface a detecta. Depois aparece fechamento de
ASSUMIR por candidatura cancelada; não há nova promoção de B nem razão operacional
de recusa no trecho. A termina no pedido de saída, sem certificado final nesse
anexo; B confirma parada no escopo acompanhado. WinError 10038 aparece após o
pedido de saída de B e antes da confirmação, sem comprovar pendência final.

Esse envio comprova rearmamento e processamento da fila, mas não o ciclo completo.
Sem horários, revisão exata e diagnóstico da tentativa, não atribuir cancelamento
a senha incorreta, TC420 indisponível ou ciclo pendente. Inspeção local reproduziu
outro fechamento indevido: após tentativa manual sem sucesso, o estado inativa
do leitor fechava o formulário quando promocao_em_andamento voltava a False.
Correção local mantém formulário já admitido para nova tentativa/fechamento
explícito e acrescenta diagnósticos de etapa/recusa, sem liberar partidas incertas.
Essa correção posterior ainda não foi testada fisicamente.

### Persistência da falta de candidatura e nova regra recorrente

Novo par de anexos mostra A recebendo posição 1 de B, mas, após perda de B,
candidatura desabilitada. B apresenta o novo anúncio de espera por prontidão,
é promovido e depois abandona a fonte, encerrando HTTP/TCP/UDP e trabalhadores.
Isso demonstra o bloqueio anterior; não há candidatura de A nem recuperação
completa nesses logs. Revisões exatas e horários não informados.

Responsável definiu alternância contínua manual/automática pela fila. Código
local atualizado para rearmamento após REGISTER/amostra/prova e observador único
no monitor manual. Executar [roteiro recorrente](SUCESSAO_RECORRENTE_AB.md) na mesma
versão em A/B. Validação física dessa atualização ainda não executada pelo agente.

### Versão com recuperação manual integrada: execução pendente

Após autorização posterior, a recuperação manual foi integrada no código local.
Os logs e capturas abaixo pertencem às execuções anteriores. Não aprovam a nova
ação Opções → Assumir manualmente. Seguir o procedimento em
[integração A/B](INTEGRACAO_RECUPERACAO_MANUAL_AB.md) com mesma revisão em ambos
os PCs, registrar horários, promoções manuais, prontidão, leituras/faixas e B2.
Nesta implementação houve somente ensaios simulados/localhost/Tk oculto.

### Segunda perda de B: ambos aguardando servidor

Novo par de logs fornecido pelo responsável demonstra B promovido perdendo a
fonte, abandonando PRINCIPAL após o limiar, encerrando HTTP/TCP/UDP com lista
de trabalhadores restantes vazia e iniciando descoberta. A, já recuperado como
CLIENTE de B, detecta silêncio e informa candidatura desabilitada. Ambos seguem
sem servidor. Não há tentativa manual rejeitada ou erro de login nesse trecho;
a sinalização necessária para oferecer a promoção manual não é produzida.

O leitor de recuperação é criado com permitir_candidatura=False. A restrição
vigente impede tanto nova candidatura automática quanto a oferta manual que
depende do mesmo estado. Assim, dois PCs rebaixados não se alternam novamente
como PRINCIPAL por esse fluxo. Trata-se de limitação operacional confirmada,
não de aprovação de disponibilidade contínua. Segunda perda e abandono de B
agora evidenciados; reconexão de B a outro PRINCIPAL e primeira leitura recente
após esse abandono continuam pendentes. A apresenta confirmação de saída no
escopo acompanhado; o trecho final de B só mostra solicitação de encerramento.

Recuperação pelo fluxo existente: com TC420 acessível, reconfigurar somente um
PC e concluir sua parada segura antes do login normal, ou encerrá-lo com SIM
e reabri-lo. O outro permanece como CLIENTE aguardando. Não houve alteração
para permitir novas candidaturas nesta análise.

### Repetição após correção: faixas visíveis

Logs adicionais e nova captura fornecidos pelo responsável confirmam a recuperação
do antigo PRINCIPAL como CLIENTE do PC B com campos preenchidos na interface:
W1.1 máximo 80000 kg, mínimo 200 kg, divisão 10 kg; W1.2 máximo 140000 kg,
mínimo 400 kg, divisão 20 kg. A tela apresenta peso 0 kg, tara 0 kg e status
`CT conectado`. A ausência de faixas relatada anteriormente não se reproduziu
nesse cenário. Evidência física fornecida pelo responsável, sem execução ou
inspeção independente do agente; revisão exata dos PCs não informada.

Nos logs correspondentes, A abandona o papel após indisponibilidade, encerra
HTTP/TCP/UDP com trabalhadores restantes vazios, encontra B e atualiza a fonte.
A continua recebendo após a opção de segundo plano e depois apresenta confirmação
de parada operacional no escopo acompanhado. B detecta silêncio de SUBSCRIBE,
é promovido, atende A e termina HTTP/TCP/UDP com trabalhadores restantes vazios;
seu trecho não contém certificado explícito de parada B2. Não houve segunda
perda da fonte no B promovido nesses logs. Esse cenário de supervisão continua
pendente, assim como a reabertura após esta execução. PasswordDeleteError ainda
aparece no início de A, sem impedir o login; não foi corrigido nesta análise.

### Complemento: reconexão com faixas ausentes

Novos logs e captura enviados pelo responsável mostram o antigo PRINCIPAL
abandonando o papel após indisponibilidade da fonte, encerrando HTTP/TCP/UDP com
trabalhadores restantes vazios e depois conectando ao PC B promovido. A mensagem
de fonte atualizada e a captura confirmam recepção de medições, mas Max/Min/divisão
de W1.1 e W1.2 aparecem como `—`. Não confundir esse fluxo do antigo PRINCIPAL
com a segunda falha do PC B promovido, não demonstrada neste complemento.

Causa identificada no código local: CONFIG era consultado apenas antes do loop;
quando a descoberta inicial não encontrava servidor, a descoberta posterior
seguia para REGISTER/SUBSCRIBE sem obter a configuração. Correção local repete
a consulta admitida enquanto CONFIG ainda não foi publicado, antes de registrar
e receber medições. Não altera candidatura nem condições de encerramento.
Repetição física com a correção e conferência da versão nos dois PCs pendentes.
Essa correção não implementa atualização contínua de CONFIG após uma configuração
já obtida; troca posterior de parâmetros requer investigação própria.

O responsável forneceu logs de execução física de dois computadores. Análise
documental desses logs, sem observação independente da interface ou da rede.
Os campos originais abaixo permanecem como modelo; seus estados iniciais não
substituem esta atualização. Horários, revisões instaladas e método/duração das
interrupções não foram informados.

| Cenário | Evidência recebida | Conclusão limitada aos logs |
| --- | --- | --- |
| PRINCIPAL inicial A | HTTP saudável; cliente registrado e inscrito; saída com trabalhadores restantes vazios e confirmação B2 | Funcionamento e encerramento acompanhado evidenciados |
| CLIENTE B | Recebe dados de A; posição 1; detecta perda e sinaliza candidatura após contagem de 30 s | Detecção e candidatura evidenciadas |
| Promoção de B | Login, configuração, TCP/UDP ativos, promoção concluída e novas leituras HTTP | Promoção e comunicação com a TC420 evidenciadas |
| Perda da fonte em B promovido | 17 erros consecutivos; leitura antiga identificada; HTTP depois saudável novamente | Indisponibilidade e recuperação no mesmo papel evidenciadas; abandono/supervisão não demonstrados |
| Saída de B promovido | TCP/UDP encerrados; leitor HTTP ainda listado, encerrando depois; retorno ao prompt | Processo aparentemente terminou; falta confirmação positiva B2 no trecho fornecido |
| Reabertura de B por login manual | Novo servidor com leituras; saída com lista vazia e confirmação B2 | Reabertura e encerramento do novo ciclo evidenciados |

Não aparecem abandono do papel PRINCIPAL, confirmação do ciclo promovido pela
supervisão ou criação do leitor de recuperação sem candidatura. A contagem de
falhas não mede duração: no código local, o abandono requer ao menos 25 s desde
a terceira falha, avaliado em uma falha posterior; uma leitura válida reinicia
essa condição. Sem horários e sem conferir a revisão de B, não concluir que
houve defeito nem que o cenário de segunda falha foi aprovado.

Ocorrências separadas: `PasswordDeleteError` na remoção de credencial (login
prosseguiu) e `WinError 10058` no UDP durante parada de A (seguido de confirmação
B2). Causas específicas não confirmadas. Não houve alteração de código nesta
análise. Próximo ensaio: registrar revisões e horários; manter B aberto e a fonte
indisponível até observar abandono e confirmação positiva, antes de restaurar
a comunicação e disponibilizar outro PRINCIPAL. Executar em janela controlada.

## Modelo preparado antes do recebimento dos logs

Preparada em 13/11/2026. **Estado inicial: execução não iniciada.** O responsável confirmou:
“Ainda não; manter os testes pendentes.” Janela controlada não disponível;
identificação dos PCs e executor das intervenções continuam pendentes.
Não preencher resultados antes de observar o comportamento real.

Versão/commit e alterações locais: a preencher.
Data, início/fim e fuso: a preencher.
PC A (principal inicial): a preencher.
PC B (cliente promovível): a preencher.
Outros clientes observados: a preencher.
Responsável pelas intervenções físicas e restauração: a preencher.

| Evento | Horário | Papel/estado observado | Evidência de encerramento ou frescor | Resultado |
| --- | --- | --- | --- | --- |
| Leitura inicial em A e clientes | — | — | — | Não executado |
| Primeira falha, método aplicado | — | — | — | Não executado |
| Promoção de B e primeira leitura válida | — | — | — | Não executado |
| Segunda falha, mantendo B em execução | — | — | — | Não executado |
| Retorno do coordenador/ciclo de B | — | — | — | Não executado |
| Confirmação positiva das responsabilidades | — | — | — | Não executado |
| B como leitor de recuperação sem candidatura | — | — | — | Não executado |
| Outro PRINCIPAL disponibilizado | — | — | — | Não executado |
| Primeira nova leitura válida em B/clientes | — | — | — | Não executado |
| Saída B2 e fechamento | — | — | — | Não executado |
| Reabertura e nova saída | — | — | — | Não executado |

Registrar se a interface identificou a leitura antiga durante indisponibilidade.
Não considerar ausência de segunda promoção de B como falha: esse leitor não
tem candidatura. Retorno do coordenador não substitui confirmação do ciclo.

Ocorrências, pendências e limitações de observação: a preencher.
Intervenções revertidas e estado final do equipamento/rede: a preencher.
Conclusão por cenário: aprovado/reprovado/inconclusivo, com fundamento nos logs
e observações; distinguir relato do executor de inspeção independente.

Roteiro: [ROTEIRO_FISICO_SUPERVISAO_PRINCIPAL.md](ROTEIRO_FISICO_SUPERVISAO_PRINCIPAL.md).
Sem mudanças de arquitetura/memória. Se ocorrer falha, isolar o comportamento
antes de propor correção. Não registrar senhas/tokens nesta ficha ou nos logs.

# Roteiro do aplicativo Windows — 19/11/2026

Solicitação: horário nas leituras, pasta de dados/logs, salvamento automático,
EXE, instalador em Program Files, firewall e desinstalador.

## Decisões iniciais

- Binários: `C:\Program Files\PRIX TC420`, instalador elevado; aplicativo normal
  sem exigir administrador do Windows. Senha administrativa do aplicativo é outra coisa.
- Dados por usuário: `%LOCALAPPDATA%\PRIX TC420`; subpasta `logs`.
- Desenvolvimento conserva os caminhos atuais, sem copiar ou migrar dados reais
  automaticamente. Futuro EXE não incluirá configuração, cadastro ou senhas existentes.
- Log automático inicialmente no encerramento normal: retrato sanitizado do
  histórico retido, com aviso de cortes. Não é registro integral nem resistente
  a término forçado, queda de energia ou falha do disco.
- Regras por programa e portas: entrada TCP 42100 e UDP 42101; rede privada
  padrão, rede pública opcional explícita, restrição à sub-rede local. Não abrir
  portas no roteador. TCP direto 9800 e HTTPS são conexões de saída à balança.

## Etapas e critérios de conclusão

1. **Caminhos graváveis — iniciada e implementada em código.** EXE separa dados
   de binários. Configuração e cadastro administrativo seguem o mesmo diretório;
   helper cria `logs` quando utilizado. Testar com pasta temporária simulando EXE.
2. **Data e horário a cada refresh — regra corrigida pelo responsável.** Mostrar
   data e horário locais em cada atualização do monitor, inclusive quando o peso
   permanecer igual. Identificar como atualização da tela, não como instante de
   nova medição da TC420. Manter separadamente o relógio monotônico da última
   amostra válida para o frescor: refresh não renova comunicação nem torna peso
   antigo atual. Aplicar nos modos PRINCIPAL, CLIENTE e TCP local; não precisa
   alterar o protocolo de rede para exibir o horário local. Formato proposto:
   `Atualização: DD/MM/AAAA HH:MM:SS`. Testar também ausência de comunicação,
   garantindo avanço do horário sem ocultar o aviso de última leitura.
3. **Log automático de encerramento.** Nome por sessão/data/hora sem colisões;
   UTF-8 sanitizado, indicação de retenção e gravação fora do Tk. Integrar ao
   encerramento acompanhado antes de destruir a raiz; erro visível e sem falsa
   confirmação. Definir retenção em disco antes de habilitar gravação recorrente.
4. **EXE em pasta com PyInstaller.** Inventariar dependências, incluir assets e
   backend keyring, verificar execução sem console, bandeja, reconfiguração e
   localização dos recursos. Primeiro pacote em pasta, depois avaliar arquivo único.
   Ensaio no EXE não pode depender de Python instalado; definir sua inclusão ou
   apresentação de indisponibilidade. Testar Windows/arquitetura explicitamente.
5. **Instalador e desinstalador com Inno Setup.** Versão, ícone, atalhos, entrada
   em Aplicativos Instalados e UAC. Instalador não deve iniciar aplicativo elevado
   como rotina. Atualização preserva dados; desinstalação remove binários/regras
   próprias e preserva dados por padrão, com limpeza opcional explícita. Não
   apagar diretórios genéricos nem credenciais de outros aplicativos/usuários.
6. **Firewall.** Instalador oferece regras delimitadas ao EXE/portas/perfis.
   Remover somente suas regras na desinstalação. Não alterar o firewall deste
   computador durante desenvolvimento. Políticas corporativas podem impedir regras.
   Descoberta usa UDP e CHECK TCP; visibilidade no Explorador do Windows não é
   requisito do protocolo. VLAN, isolamento Wi-Fi e roteamento precisam ser testados.
7. **Aceite em máquina limpa e dois PCs.** Instalar sem Python, abrir como usuário
   comum, cadastrar administrador, validar HTTPS/TCP, descoberta, sucessão,
   logs, encerramento, reabertura, atualização e desinstalação. Teste físico em
   janela controlada; aprovação de localhost não substitui o teste de rede real.

## Estado desta entrega

Complemento de firewall: [ferramentas manuais incluídas no ZIP](FIREWALL_WINDOWS.md)
para configurar/remover as duas regras com elevação. Integração automática com
instalador e teste de regras reais continuam pendentes.

Marco posterior em 23/11: [EXE em pasta gerado](EXECUTAVEL_WINDOWS.md), com
runtime/dependências e diagnóstico offline. Etapa 4 avançou; teste em Windows
limpo permanece pendente. Etapas 3 (log automático), 5 e 6 (instalador/firewall)
continuam pendentes. O avanço ao EXE foi solicitado diretamente pelo responsável.

Implementados o primeiro bloco de caminhos e, em 23/11, data/hora local a cada
refresh no monitor e na linha Estado do terminal. EXE em pasta gerado conforme
o marco acima; instalador ainda não gerado, nenhuma regra de firewall foi criada
e nenhum dado real foi migrado.
Log automático permanece próximo passo. A data/hora aparece na barra superior
do monitor, mantendo dimensões e áreas de peso/tara; protocolo de pesagem preservado.
Verificação de 23/11: 2.167 testes aprovados em 47,376 s, 165 compilações em
memória e autoteste Tk real offline aprovado, incluindo visibilidade do horário.

Validação desta etapa: três testes novos de caminhos e oito testes administrativos
aprovados; regressão completa de **2.165 testes em 61,133 s**, todos aprovados.
Três arquivos Python alterados/novos compilados em memória; whitespace conferido.
São testes isolados, não instalação real em Program Files.

## Referências técnicas

Consultadas em 19/11/2026:

- [PyInstaller: funcionamento e pacote em pasta](https://www.pyinstaller.org/en/stable/operating-mode.html).
- [Inno Setup: diretório de instalação](https://jrsoftware.org/ishelp/topic_setup_defaultdirname.htm)
  e [privilégios do instalador](https://jrsoftware.org/is6help/topic_setup_privilegesrequired.htm).
- [Microsoft: regras de firewall por programa, porta e perfil](https://learn.microsoft.com/en-us/powershell/module/netsecurity/new-netfirewallrule?view=windowsserver2025-ps).

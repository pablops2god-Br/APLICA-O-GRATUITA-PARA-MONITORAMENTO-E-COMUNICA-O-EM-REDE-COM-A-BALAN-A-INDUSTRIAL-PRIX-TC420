# Etapa 2B.11 — proposta de evolução contratual

Detalhamento posterior para revisão em [2B.12](REVISAO_CONTRATOS_2B12.md): campos,
selagem, versionamento e aceitação por fase. Nenhum dos textos autoriza integração.

13/11/2026. **Especificação para revisão; não aprovada para integração.** Nenhum
modelo, método ou política descrito abaixo está implementado por esta etapa.
Base: auditorias 2B.9/2B.10 e código vigente de RegistroTrabalhadores e controle.

## Decisão proposta

Alternativa B: separar consulta histórica da obtenção de trabalhadores operacionais.
Durante migração, registro.threads continua sendo a lista forte original. Somente
após aprovação explícita de uma versão contratual nova ela poderia passar a expor
apenas trabalhadores cuja retenção operacional ainda é necessária. Não misturar
Thread e resumos na mesma lista. Não mudar shutdown, tokens de socket ou protocolos.

A mantém compatibilidade integral e crescimento dos originais. C muda diretamente
a lista, com maior risco. B permite migrar dependências antes da mudança, mas não
evita que a alteração final da lista seja uma quebra pública. Ausência de chamada
externa encontrada não é consentimento para quebrar contrato.

## APIs candidatas — nomes e semântica propostos

| Consulta | Contrato proposto |
| --- | --- |
| obter_trabalhadores_operacionais() | Snapshot imutável, em ordem de admissão, com IDs lógicos e Thread originais ainda necessários; chamador pode fazer join fora dos locks |
| consultar_trabalhador(ciclo_id, trabalhador_id) | Retrato imutável de estado, partida, término, join, responsabilidades, pendências e categorias de erro; sem referência obrigatória à Thread |
| obter_historico_trabalhadores(ciclo_id) | Histórico lógico em ordem de admissão; inclui comprovantes resolvidos e identifica trabalhadores ainda pendentes, sem convertê-los em sucesso |
| avaliar_responsabilidades(ciclo_id) | Avaliação conservadora do conjunto conhecido, incluindo admissão em curso, partidas incertas e publicações pendentes |

ID lógico é par ciclo/trabalhador monotônico, não ident/native_id do SO e nunca
reutilizado no mesmo ciclo. Histórico não devolve Thread proxy nem simula join.
Thread original já entregue continua válido; se o consumidor o retiver, a memória
permanece legitimamente alcançável. ID inexistente retorna estado desconhecido,
nunca comprovante de ausência de execução. Interfaces finais precisam ser
aprovadas antes de implementação; esta tabela não adiciona métodos ao servidor.

## Admissão e estados

Antes de start, admitir trabalhador, reter Thread forte e publicar conjunto inicial
de responsabilidades. Criar reserva antes de alocar socket. Vínculo de handler
deve existir antes de ele poder executar; TCP/UDP/HTTP não compartilham por
suposição o mesmo conjunto de recursos. Responsabilidades novas precisam ser
admitidas pelo mesmo protocolo antes de executar. Transferência de dono deve ser
atômica, sem intervalo sem acompanhamento.

Estados separados, não um booleano: partida pendente/observada/incerta/ausência
comprovada; execução em curso/término observado; join pendente/confirmado; recursos
ativos/resolvidos; limpeza pendente/sucesso/erro. Exceção de start conserva
incerteza mesmo com ident conhecido. Timeout, coleta de lixo, is_alive False
ou fileno -1 isolados nunca resolvem responsabilidade.

Comprovante só é elegível com partida resolvida positivamente, término e join
confirmados quando houve execução, nenhuma admissão/transferência/publicação em
curso, todas as responsabilidades associadas resolvidas e nenhum erro impeditivo.
Ausência comprovada de execução é caminho distinto e requer evidência própria,
não inferência por ident None. Falha de leitura mantém desconhecido/pendente.

## Publicações tardias e concorrência

Antes de selar um comprovante, todos os produtores de resultados devem publicar
conclusão ou transferência; retorno do coordenador não sela handlers pendentes.
Resultados repetidos idênticos são idempotentes, identificados pelo ID e geração
originais. Publicações ainda admissíveis mantêm a referência operacional forte.
Não descartar erro tardio por trabalhador não aparecer na visão operacional.

Uma publicação conflitante após selagem seria violação de invariante: deve ser
registrada e impedir nova recuperação/admissão automática enquanto investigada,
nunca reinterpretada silenciosamente como sucesso. Esse tratamento necessita
teste e decisão explícita na implementação; não há alegação de que possa corrigir
uma recuperação já realizada. A segurança principal é impedir selagem prematura.

Join/close/shutdown fora dos locks. Manter ordem controle→registro. Snapshots
externos continuam válidos; sua retirada da tabela não destrói objetos ainda em
uso por chamadores. Troca operacional→comprovante precisa ser atômica sob lock,
com revalidação da geração. Erro durante troca conserva a participação operacional.

## Migração interna antes da mudança pública

| Consumidor | Migração proposta |
| --- | --- |
| registrar_e_iniciar / servidor_tcp | Publicar admissão e vínculo completo antes de start; registrar resultado sem perder exceção ambígua |
| obter_situacao | Construir o mesmo retrato a partir de registros operacionais e históricos, preservando nomes, ordem e erros |
| Controle.finalizar e consulta histórica | Combinar obrigações ainda abertas e comprovantes; não depender de uma lista encurtada para concluir ausência |
| Recuperação parcial de iniciar_servidor | Obter snapshot dos originais retidos para joins e manter comparação com current_thread |
| principais_iniciados | Conservar referências enquanto coordenador precisa fazer join; depois liberar o snapshot local |
| SaidaAplicacao | Continuar conservando suas próprias partidas/tarefas; consumir prova por contexto, sem confundir suas threads com trabalhadores do servidor |
| SupervisaoPrincipal | Continuar exigindo retorno do coordenador e confirmação positiva do contexto original |
| Testes/harnesses | Separar contagem de históricos da quantidade operacional; preservar assertIs para referências ainda operacionais e starts incertos |

Migração interna é controlável, mas não autoriza mudar o atributo público. Primeiro
acrescentar modelo paralelo sem liberar originais, confrontando resultados com a
avaliação vigente. Qualquer divergência impede liberação e confirmação automática.
Depois migrar consumidores, validar concorrência e falhas; só então aplicar a
decisão pública aprovada e medir liberação efetiva.

## Compatibilidade pública e duração de retenção

Proposta para a versão futura: originais disponíveis enquanto partida, execução,
join, responsabilidade, erro ou publicação puderem exigir ação. Resolvidos podem
deixar a visão operacional apenas após comprovação, não após prazo arbitrário.
Histórico lógico permanece consultável até descarte do registro/ciclo pela
política já existente; não se propõe expirar IDs ou diagnósticos nesta etapa.
Isso ainda cresce linearmente em metadados e não promete memória constante.

Na versão vigente, registro.threads continua integral. Uma fase de depreciação
pode anunciar a nova consulta sem alterar a lista, mas continuará retendo memória.
Documentação de migração deve dizer claramente que comprimento, conteúdo e
mutabilidade da lista mudariam na versão futura. Não apresentar nova API como
compatibilidade automática. Consumidores externos precisam poder escolher migrar
ou permanecer no contrato A; não foi definido calendário de retirada.

## Benefício esperado e como medir

Não há percentual garantido. Na 2B.9 o candidato T passou de 36,005 a 8,887 MB,
mas já incorporava provas e alterava identidade da lista; isso é referência
experimental, não orçamento do novo desenho. Na 2B.10 associações acrescentaram
cerca de 372 bytes/trabalhador em uma amostra limitada. Não subtrair diretamente
esses números: cargas, comprovantes e estruturas não são os mesmos.

Medir futuramente custo líquido: originais liberados menos comprovantes,
associações, índices e capacidade auxiliar remanescente; incluir raízes externas.
Enquanto a visão forte original existir, esperar custo adicional e nenhum ganho
de liberação. Após migração aprovada, repetir carga mista/contínua, medindo escrita,
consultas, lock, p95/p99/máximo, pico e memória retida; separar tracemalloc de RSS.

## Aceitação e autorização necessárias

Exigir testes de identidade e joins dos originais, start incerto, trabalhador
vivo, join sem término, erro/limpeza pendente, transferência concorrente, callback
tardio, repetição e conflito, snapshot externo, ciclo antigo após novo, parada
operacional e segunda falha após promoção. Comparar diagnóstico e confirmação
com a referência antes de liberar qualquer objeto. Verificar que encurtar a visão
não cria prova de encerramento por ausência.

Decisões ainda não aprovadas: contrato final das consultas; mudança de conteúdo/
mutabilidade de registro.threads; protocolo de selagem e conflitos; migração e
versionamento. Nenhuma aprovação é inferida da recomendação de estudar B.
Shutdown tardio e validade dos tokens de socket ficam fora desta evolução.

## Resultado documental

Especificação 2B.11 concluída para revisão. Não houve implementação, protótipo,
medição ou nova execução de testes. Conferência documental com 2B.10 e critérios
vigentes do controle de ciclos. A última regressão completa permanece a da 2B.9:
2.083 testes; não é validação executada nesta solicitação. Regressão física pendente.

# Executável Windows — 23/11/2026

## Entrega

Gerado PRIX TC420 **0.0.1**, Windows x64, com PyInstaller 6.22.3 e Python
3.13.15. Formato em pasta (onedir), sem console, com ícone e informações de
versão/desenvolvedor Pablops2god. Este pacote inclui o runtime Python e suas
dependências. Não contém configuração, cadastro administrativo ou senhas reais.

- Executável: `dist/PRIX_TC420/PRIX_TC420.exe`.
- Pacote para copiar: `dist/PRIX_TC420_0.0.1_Windows_x64.zip`.
- Hashes: `dist/PRIX_TC420_0.0.1_Windows_x64.sha256.json`.
- Instruções acompanham o pacote em `LEIA-ME.txt`.

Atualização de firewall: ZIP inclui `Configurar-Rede.cmd` e
`Remover-Permissoes-Rede.cmd`, com elevação quando executados pelo usuário.
Regras restritas ao EXE/portas/sub-rede, privada padrão e pública opcional.
Ver [FIREWALL_WINDOWS.md](FIREWALL_WINDOWS.md). O ZIP foi regerado com novos
hashes; tamanhos/contagem da primeira geração abaixo são registro histórico.

Extraia o ZIP inteiro e execute o EXE dentro da pasta. **Mantenha `_internal`
ao lado dele**; copiar somente o arquivo EXE não funciona. O pacote não instala
nada em Program Files, não cria atalhos, não muda firewall e não inclui
desinstalador. Para remover os binários desta versão, feche o programa e exclua
a pasta extraída; dados por usuário permanecem separados.

Dados do EXE ficam em `%LOCALAPPDATA%\PRIX TC420`. O primeiro uso pede cadastro
e login administrativos. HTTPS, CLIENTE e TCP local conservam seus contratos;
data/hora por refresh já está incluída. A exportação manual de log continua
disponível. **Log automático de encerramento ainda não foi implementado.**
O laboratório visual de desenvolvimento não é distribuído: seu atalho informa
indisponibilidade no EXE. O diagnóstico offline abaixo é uma função diferente.

## Ajustes necessários ao empacotamento

O EXE sem console recebe stdout/stderr ausentes. O registro do terminal agora
usa um sink sem buffer nesse caso, mantendo retenção limitada e sanitização,
sem tentar escrever em None e sem criar um segundo histórico ilimitado.
Não foi introduzida gravação automática em disco.

Recursos PNG são explicitamente incluídos; a logo usa o asset Lanczos pronto,
sem exigir Pillow. Backend Windows do keyring e metadados das dependências são
incluídos. O inventário estático HTTP ignora ambiente de build e saídas geradas,
para não tratar código de dependências como consumidor operacional do projeto.

Backup anterior dos três arquivos existentes alterados para o build:
`backups/antes_executavel_2026-11-23/originais.zip`, com SHA256.json. Novos
arquivos de empacotamento estão em `empacotamento/`. Build, dist e ambiente
virtual são ignorados pelo Git; não houve commit ou push.

## Reprodução do build

Na raiz, executar `empacotamento/gerar_executavel.ps1`. O script cria um ambiente
`.venv-build` se necessário, instala `requirements-build.lock.txt`, aplica
`PRIX_TC420.spec` e gera ZIP/manifesto com `distribuir.py`.

O lock registra versões de dependências usadas neste build; não é promessa de
identidade binária entre máquinas. Fontes do aplicativo não devem ser alteradas
durante a geração. Consultar o manifesto SHA-256 antes de distribuir.

O spec inclui código/recursos explicitamente; não copia diretório do projeto,
backups, chats, documentos ou JSON de configuração. O distribuidor recusa JSON
operacional/cadastro na pasta de saída e verifica a integridade do ZIP.

## Diagnóstico e limites da validação

O EXE aceita explicitamente `--autoteste-pacote caminho_do_relatorio.json`.
Esse modo usa arquivos temporários, dados sintéticos, sockets bloqueados e
cofre substituído. Cria telas reais Tk para conferir imagens, login, monitor,
data/hora e encerramento B2. Grava somente relatório de resultados, sem senha.
Não deve ser confundido com conexão real ou com o laboratório completo.

O build foi executado e testado em Windows 10 x64, build 19045. Importação do
backend Windows foi conferida; não houve leitura/gravação de credencial real.
Validação independente em Windows limpo sem Python e na rede com dois PCs/TC420
permanece pendente. Ausência de Python no PATH do teste não equivale a máquina
limpa. Bandeja/notificações dependem também do ambiente desktop real.

O executável não possui assinatura digital. Instalador, desinstalador, regras
de firewall e implantação em Program Files são a etapa seguinte do
[roteiro Windows](ROTEIRO_INSTALACAO_WINDOWS.md); não foram executados nesta entrega.

Resultado final em [RESULTADO_BUILD_WINDOWS.json](RESULTADO_BUILD_WINDOWS.json):
ZIP íntegro, 1.013 arquivos verificados por SHA-256, 16.171.421 bytes compactados
(cerca de 16,2 MB), 31.345.281 bytes na pasta. A cópia extraída passou no
diagnóstico com PATH limitado ao Windows e diretório corrente diferente.
Regressão: **2.169 testes aprovados em 48,884 s**. Compilação em memória de
168 arquivos Python e verificação de whitespace aprovadas. Não é validação
independente em máquina limpa.

Referências técnicas consultadas:
[PyInstaller — uso](https://pyinstaller.org/en/stable/usage.html) e
[limitações do modo sem console](https://pyinstaller.org/en/stable/common-issues-and-pitfalls.html).

# Arquivos de configuração: reserva, retenção, uso e comprovação local de limpeza.
"""Escopo de configuração: erros primários preservados e handles acompanhados."""
from threading import Lock


# Tenta fechar sem substituir a exceção original; uma falha de limpeza fica encadeada como causa.
def _limpar_apos_erro(original, fechar):
    try:
        fechar()
    except BaseException as limpeza:
        # Mantém a instância e o traceback primários; a causa não é um log.
        original.__cause__ = limpeza
        original.__suppress_context__ = True


# Garante tentativa de fechamento tanto no sucesso da operação quanto na saída por exceção.
def _usar_e_fechar(usar, fechar):
    try:
        resultado = usar()
    except BaseException as original:
        _limpar_apos_erro(original, fechar)
        raise
    else:
        fechar()
        return resultado


# Seleciona abertura acompanhada pelo contexto ou abertura isolada com fechamento ao final.
def executar_arquivo(abrir, operar, contexto_arquivos=None):
    """Sem contexto mantém consumidor isolado, sem alegar registro de recurso."""
    if contexto_arquivos is not None:
        return contexto_arquivos.executar(abrir, operar)
    arquivo = abrir()
    return _usar_e_fechar(lambda: operar(arquivo), arquivo.close)


# Acompanha identidade e fechamento dos arquivos usados na configuração, sem expor seu conteúdo nos retratos.
class ContextoArquivosConfiguracao:
    """Mesmo proprietário/registro da montagem, uma preparação por abertura.

    Retém também handles cuja associação/publicação falhou. Não armazena caminho,
    conteúdo, argumentos de configuração ou exceções em retratos consultáveis.
    """
    __slots__ = ("_registro", "_retentativas", "_proprietario", "_lock", "_pendentes", "_historico")

    # Vincula registros à infraestrutura e retém este contexto antes de qualquer abertura de arquivo.
    def __init__(self, infraestrutura):
        from rede.infraestrutura_cliente import exigir_infraestrutura_http
        exigir_infraestrutura_http(infraestrutura)
        self._proprietario = infraestrutura
        self._registro = infraestrutura.registro_recursos
        self._retentativas = infraestrutura.registro_retentativas
        self._lock = Lock()
        self._pendentes = {}
        self._historico = {}
        # Publicar o próprio contexto antes de qualquer operação/alocação.
        infraestrutura._reter_contexto_arquivos(self)

    # Reduz a exceção a uma categoria, evitando guardar sua mensagem nos diagnósticos consultáveis.
    @staticmethod
    def _categoria(erro):
        return ("falha_io" if isinstance(erro, OSError) else
                "falha_operacao" if isinstance(erro, Exception) else "falha_base")

    # Produz somente metadados de acompanhamento; o objeto aberto não é entregue ao consumidor do retrato.
    @staticmethod
    def _retrato(token, item):
        return {"recurso_id": token.numero, "geracao_id": item["geracao_id"],
                "atividade_id": item["geracao_id"], "erro_limpeza": item["erro_limpeza"],
                "erro_retencao": item["erro_retencao"], "erro_publicacao": item["erro_publicacao"],
                "closed_observado": item["closed_observado"], "fase": item["fase"],
                "limpeza_comprovada": item["limpeza_comprovada"],
                "handle_retido": item["arquivo"] is not None}

    # Copia sob lock os metadados dos arquivos ainda não liberados pelo contexto.
    def obter_pendencias(self):
        with self._lock:
            return [self._retrato(token, item)
                    for token, item in self._pendentes.items()]

    # Consulta também operações anteriores, inclusive as que já tiveram a limpeza comprovada.
    def obter_historico(self):
        with self._lock:
            return [self._retrato(token, item) for token, item in self._historico.items()]

    # Localiza no registro compartilhado a situação da identidade reservada para o arquivo.
    def _estado(self, identidade):
        return next(r for r in self._registro.obter_retrato()["recursos"]
                    if r["recurso_id"] == identidade.numero)

    # Serializa a limpeza local e só libera o handle retido quando obtém a comprovação de fechamento.
    def _fechar(self, identidade, arquivo):
        with self._lock:
            item = self._pendentes.get(identidade)
            if item is None or item["fase"] in ("abertura", "uso", "limpeza"):
                return False
            if item["arquivo"] is not arquivo:
                raise ValueError("handle_arquivo_estrangeiro")
            item["fase"] = "limpeza"
        etapa = "close"
        try:
            estado = self._estado(identidade)
            if estado["criacao_resolvida"] and not estado["ausencia_comprovada"]:
                self._registro.fechar(identidade)
                etapa = "publicacao"
                estado = self._estado(identidade)
                comprovada = (estado["prova_fechamento"] == "close_retornou_e_closed_true"
                              and not estado["limpeza_em_curso"] and estado["usos"] == 0)
            else:
                # Sem associação não há API pública de prova desse handle no
                # registro. Prova local resolve retenção, não a criação ambígua.
                arquivo.close()
                comprovada = arquivo.closed is True
            etapa = "publicacao"
            self._publicar_limpeza(item, comprovada)
            if comprovada:
                with self._lock:
                    item["limpeza_comprovada"] = True
                    item["arquivo"] = None
                    item["fase"] = "resolvida"
                    self._pendentes.pop(identidade, None)
                return True
            return False
        except BaseException as erro:
            # O handle já está retido. Falhar ao registrar diagnóstico não pode
            # substituir o close original nem liberar a referência.
            with self._lock:
                item["limpeza_comprovada"] = False
            _limpar_apos_erro(erro, lambda: self._registrar_falha(item, erro, etapa))
            raise
        finally:
            with self._lock:
                item["fase"] = "resolvida" if identidade not in self._pendentes else "pendente"

    # Atualiza a evidência local de fechamento sob o lock do contexto.
    def _publicar_limpeza(self, item, comprovada):
        with self._lock:
            item["closed_observado"] = comprovada

    # Distingue falha ao fechar de falha ao publicar o resultado da limpeza.
    def _registrar_falha(self, item, erro, etapa):
        with self._lock:
            item["erro_publicacao" if etapa == "publicacao" else "erro_limpeza"] = self._categoria(erro)

    # Permite repetir a limpeza de uma identidade válida ainda associada a um arquivo retido.
    def tentar_limpeza(self, recurso_id):
        if type(recurso_id) is not int or recurso_id < 1:
            raise ValueError("identidade_arquivo_invalida")
        with self._lock:
            encontrado = next(((token, item["arquivo"]) for token, item in self._pendentes.items()
                               if token.numero == recurso_id and item["arquivo"] is not None), None)
        return False if encontrado is None else self._fechar(*encontrado)

    # Guarda a referência do arquivo para que ela continue alcançável caso uma etapa posterior falhe.
    def _reter_handle(self, item, arquivo):
        with self._lock:
            item["arquivo"] = arquivo

    # Reserva identidade antes de abrir, acompanha o uso e tenta limpar mesmo se criação ou operação falhar.
    def executar(self, abrir, operar):
        geracao = self._retentativas.nova_geracao_cliente()
        if geracao is None:
            raise RuntimeError("admissao_preparacao_arquivo_recusada")
        identidade = self._registro.reservar("arquivo_comum", geracao.numero, geracao.numero)
        if identidade is None:
            raise RuntimeError("admissao_arquivo_recusada")
        # Alocar a célula de retenção e vinculá-la ao contexto ANTES de open.
        # Se isso falhar, não há handle; comprovar a não execução da fábrica.
        item = None
        try:
            item = {"arquivo": None, "geracao_id": geracao.numero,
                    "erro_limpeza": None, "erro_retencao": None, "erro_publicacao": None,
                    "closed_observado": None, "limpeza_comprovada": False, "fase": "abertura"}
            with self._lock:
                self._pendentes[identidade] = item
                self._historico[identidade] = item
        except BaseException as original:
            with self._lock:
                self._pendentes.pop(identidade, None)
                if item is not None:
                    item["fase"] = "sem_handle"
            _limpar_apos_erro(original, lambda: self._registro.comprovar_ausencia(identidade, nao_alocado=True))
            raise
        entrou = False
        # Marca a entrada na fábrica e retém imediatamente o objeto retornado pela abertura.
        def alocar():
            nonlocal entrou
            entrou = True
            arquivo = abrir()
            try:
                self._reter_handle(item, arquivo)
            except BaseException as original:
                # Compensação: célula já publicada, chave já existente. Não
                # depende de inserir outro objeto/índice depois da falha.
                with self._lock:
                    item["arquivo"] = arquivo
                    item["erro_retencao"] = self._categoria(original)
                raise
            return arquivo
        try:
            self._registro.criar(identidade, alocar)
        except BaseException as original:
            with self._lock:
                item["fase"] = "pendente"
            if not entrou:
                _limpar_apos_erro(original, lambda: self._registro.comprovar_ausencia(
                    identidade, nao_alocado=True))
            if item["arquivo"] is not None:
                _limpar_apos_erro(original, lambda: self._fechar(identidade, item["arquivo"]))
            else:
                with self._lock:
                    self._pendentes.pop(identidade, None)
                    item["fase"] = "sem_handle"
            raise

        # Marca a fase de uso e a encerra em finally; o fechamento ocorre na etapa externa de limpeza.
        def usar():
            with self._lock:
                item["fase"] = "uso"
            try:
                return self._registro.usar(identidade, operar, fechar_ao_sair=False)
            finally:
                with self._lock:
                    item["fase"] = "pendente"
        return _usar_e_fechar(
            usar, lambda: self._fechar(identidade, item["arquivo"]))

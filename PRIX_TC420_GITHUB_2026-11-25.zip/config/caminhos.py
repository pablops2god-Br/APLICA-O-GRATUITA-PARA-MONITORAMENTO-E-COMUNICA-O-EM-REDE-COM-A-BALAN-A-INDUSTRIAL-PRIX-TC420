"""Separa recursos instalados de dados graváveis por usuário."""
import os
from pathlib import Path
import sys


def pasta_dados():
    """Desenvolvimento conserva o caminho antigo; EXE usa LocalAppData."""
    if not getattr(sys, 'frozen', False):
        return Path(__file__).resolve().parents[1]
    base = os.environ.get('LOCALAPPDATA')
    if not base:
        base = str(Path.home() / 'AppData' / 'Local')
    return Path(base) / 'PRIX TC420'


def arquivo_dados(nome):
    if Path(nome).name != nome or nome in ('', '.', '..'):
        raise ValueError('nome_arquivo_invalido')
    pasta = pasta_dados()
    pasta.mkdir(parents=True, exist_ok=True)
    return pasta / nome


def pasta_logs():
    pasta = pasta_dados() / 'logs'
    pasta.mkdir(parents=True, exist_ok=True)
    return pasta

# Persistência: JSON para parâmetros e keyring para credenciais, com backend definido pelo ambiente.
"""
Módulo de Persistência e Gerenciamento Seguro de Credenciais
============================================================

Este módulo implementa o princípio da Separação de Privilégios de Armazenamento:

1. DADOS NÃO-SENSÍVEIS (configuracao.json):
   - Nome da rede, endereço IP da balança, porta e nome de usuário.
   - Gravados em formato JSON legível em disco para fácil inspeção e portabilidade.

2. DADOS SENSÍVEIS (Windows Credential Manager via Keyring):
   - Senha administrativa de acesso ao terminal TC420.
   - NUNCA é gravada em texto claro no arquivo JSON ou no disco.
   - É protegida através da API DPAPI (Data Protection API) do Windows, vinculada
     ao contexto de segurança exclusivo do usuário logado no sistema operacional.
"""

import json
import os

import keyring

from config.arquivos import executar_arquivo


SERVICO_CREDENCIAL = "PRIX_TC420"


def guardar_login_automatico(ip, usuario, senha, *, nome_rede=None, porta=None,
                             contexto_arquivos=None):
    """Worker: guarda no cofre antes de habilitar a opção no JSON, sem expor senha.

    Ao entrar como CLIENTE, as credenciais são guardadas por escolha do operador,
    sem autenticar na balança nem alegar que a senha foi validada.
    """
    if not ip or not usuario or not senha:
        print("LOGIN: login automático não salvo; preencha IP, usuário e senha.")
        return False
    try:
        atual = carregar_configuracao(contexto_arquivos=contexto_arquivos) or {}
        if not salvar_senha(usuario, senha):
            print("LOGIN: login automático não salvo; cofre indisponível.")
            return False
        salvar_configuracao(
            nome_rede=nome_rede if nome_rede is not None else atual.get('nome_rede', 'TC420'),
            ip=ip, porta=porta if porta is not None else atual.get('porta', 42100),
            usuario=usuario, salvar_login=True, contexto_arquivos=contexto_arquivos)
    except Exception as erro:
        print("LOGIN: falha ao salvar login automático:", type(erro).__name__)
        return False
    print("LOGIN: credencial armazenada e login automático habilitado neste computador.")
    return True


# Calcula o JSON a partir da localização deste módulo, independentemente do diretório de execução.
def obter_caminho_configuracao():
    from config.caminhos import arquivo_dados
    return str(arquivo_dados('configuracao.json'))


# Verifica a existência do arquivo; não valida ainda o conteúdo JSON.
def existe_configuracao():
    caminho = obter_caminho_configuracao()
    return os.path.isfile(caminho)


# Normaliza porta e opção de login e grava apenas os campos explicitamente listados no dicionário.
def salvar_configuracao(nome_rede, ip, porta, usuario, salvar_login, *, contexto_arquivos=None):
    """
    Grava os parâmetros de rede no arquivo 'configuracao.json'.
    
    Campos armazenados: nome_rede, ip, porta, usuario e a flag booleana salvar_login.
    """
    configuracao = {
        "nome_rede": nome_rede,
        "ip": ip,
        "porta": int(porta),
        "usuario": usuario,
        "salvar_login": bool(salvar_login),
    }
    caminho = obter_caminho_configuracao()
    executar_arquivo(lambda: open(caminho, "w", encoding="utf-8"),
                     lambda arquivo: json.dump(configuracao, arquivo, indent=4, ensure_ascii=False),
                     contexto_arquivos)
    return configuracao


# Usa o contexto de arquivos quando fornecido e devolve None para as falhas tratadas abaixo.
def carregar_configuracao(*, contexto_arquivos=None):
    """
    Carrega os parâmetros de rede do arquivo 'configuracao.json'.
    
    Retorna o dicionário de parâmetros ou None caso o arquivo não exista ou esteja corrompido.
    """
    if not existe_configuracao():
        return None
    caminho = obter_caminho_configuracao()
    try:
        configuracao = executar_arquivo(
            lambda: open(caminho, "r", encoding="utf-8"), json.load, contexto_arquivos)
        # JSON sintaticamente válido também pode ser uma lista, número ou null.
        return configuracao if isinstance(configuracao, dict) else None
    except (OSError, json.JSONDecodeError, ValueError):
        return None


# Delega a persistência ao backend ativo do keyring; este método não escolhe o backend do sistema.
def salvar_senha(usuario, senha):
    """
    Grava a senha criptografada no cofre seguro do Windows (Credential Manager / Keyring).
    
    Utiliza o identificador de serviço 'PRIX_TC420' vinculado ao nome do usuário.
    Retorna True se gravado com sucesso, ou False caso o serviço de cofre falhe.
    """
    if not usuario or not senha:
        return False
    try:
        keyring.set_password(SERVICO_CREDENCIAL, usuario, senha)
        return True
    except Exception as erro:
        print(f"Erro ao salvar credencial: {type(erro).__name__}")
        return False


# Consulta a combinação serviço/usuário; nenhuma senha é acrescentada ao JSON por esta função.
def carregar_senha(usuario):
    """
    Recupera a senha administrativa do cofre seguro do Windows para o usuário informado.
    
    Retorna a senha descriptografada em memória ou None se não existir ou ocorrer erro.
    """
    if not usuario:
        return None
    try:
        return keyring.get_password(SERVICO_CREDENCIAL, usuario)
    except Exception as erro:
        print(f"Erro ao carregar credencial: {type(erro).__name__}")
        return None


# Solicita a exclusão no keyring e converte falhas em False, mostrando apenas a classe do erro.
def remover_senha(usuario):
    """
    Remove a credencial armazenada do cofre seguro do Windows (usado ao desmarcar 'Salvar login').
    """
    if not usuario:
        return False
    try:
        keyring.delete_password(SERVICO_CREDENCIAL, usuario)
        return True
    except Exception as erro:
        print(f"Erro ao remover credencial: {type(erro).__name__}")
        return False

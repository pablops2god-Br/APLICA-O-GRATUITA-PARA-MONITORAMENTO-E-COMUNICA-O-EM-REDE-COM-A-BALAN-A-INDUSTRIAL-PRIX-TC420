"""Verificador administrativo persistente, separado da credencial da balança."""
import hashlib
import hmac
import json
import os
from pathlib import Path
import secrets
import threading

_lock = threading.RLock()


def caminho():
    from config.configuracao import obter_caminho_configuracao
    return Path(obter_caminho_configuracao()).with_name('administrador.json')


def carregar():
    with _lock:
        try:
            dados = json.loads(caminho().read_text(encoding='utf-8'))
        except FileNotFoundError:
            return None
        # Arquivo inválido não deve ser interpretado como primeiro cadastro.
        if (dados.get('versao') != 1 or dados.get('iteracoes') != 200_000
                or len(bytes.fromhex(dados['sal'])) != 16
                or len(bytes.fromhex(dados['resumo'])) != 32):
            raise ValueError('cadastro_administrativo_invalido')
        return dados


def _gravar(dados):
    destino = caminho()
    temporario = destino.with_name(destino.name + '.' + secrets.token_hex(8) + '.tmp')
    try:
        with temporario.open('x', encoding='utf-8') as arquivo:
            json.dump(dados, arquivo)
            arquivo.flush()
            os.fsync(arquivo.fileno())
        os.replace(temporario, destino)
    finally:
        temporario.unlink(missing_ok=True)


def cadastrar(senha):
    if len(senha) < 8:
        raise ValueError('senha_curta')
    sal = secrets.token_bytes(16)
    resumo = hashlib.pbkdf2_hmac('sha256', senha.encode(), sal, 200_000)
    with _lock:
        if carregar() is not None:
            raise ValueError('administrador_ja_cadastrado')
        _gravar(dict(versao=1, iteracoes=200_000, sal=sal.hex(), resumo=resumo.hex(), metodo='HTTPS'))
    return True


def verificar(senha):
    dados = carregar()
    if dados is None:
        return False
    resumo = hashlib.pbkdf2_hmac('sha256', senha.encode(), bytes.fromhex(dados['sal']), dados['iteracoes'])
    return hmac.compare_digest(resumo.hex(), dados['resumo'])


def salvar_metodo(metodo):
    with _lock:
        dados = carregar()
        if dados is None:
            raise ValueError('administrador_ausente')
        dados['metodo'] = 'TCP' if metodo == 'TCP' else 'HTTPS'
        _gravar(dados)


def salvar_tcp(ip, porta, nome='TC420'):
    from config import configuracao as cfg
    anterior = cfg.carregar_configuracao() or {}
    cfg.salvar_configuracao(nome, ip, porta, anterior.get('usuario', ''), False)
    salvar_metodo('TCP')


def restaurar():
    """Limpa somente configuração da conexão, credencial associada e cadastro.

    O cadastro é removido por último. Falhas impedem anunciar sucesso e permitem
    repetir a limpeza. Não remove logs, código, backups ou arquivos arbitrários.
    """
    from config import configuracao as cfg
    import keyring
    with _lock:
        arquivo = Path(cfg.obter_caminho_configuracao())
        if arquivo.exists():
            dados = json.loads(arquivo.read_text(encoding='utf-8'))
            usuario = dados.get('usuario') if isinstance(dados, dict) else None
            if usuario and keyring.get_password(cfg.SERVICO_CREDENCIAL, usuario) is not None:
                keyring.delete_password(cfg.SERVICO_CREDENCIAL, usuario)
            arquivo.unlink()
        caminho().unlink(missing_ok=True)
    return True

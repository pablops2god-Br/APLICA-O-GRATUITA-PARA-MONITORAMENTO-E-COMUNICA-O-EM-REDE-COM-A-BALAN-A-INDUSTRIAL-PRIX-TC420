"""2B.9 isolada. Nenhum módulo operacional importa estes protótipos."""
from dataclasses import dataclass, replace
import threading
from weakref import WeakKeyDictionary

from rede.servidor import RegistroTrabalhadores

_ThreadPadrao = threading.Thread


@dataclass(frozen=True, slots=True)
class ThreadResolvida:
    """Resumo experimental, NÃO substituto completo da API de threading.Thread."""
    name: str
    ident: int
    native_id: object
    daemon: bool
    def is_alive(self):
        return False
    def join(self, timeout=None):
        if timeout is not None:
            max(timeout, 0)
    def start(self):
        raise RuntimeError('threads can only be started once')


class RegistroThreadsExperimental(RegistroTrabalhadores):
    def __init__(self):
        super().__init__()
        self._partidas_comprovadas = WeakKeyDictionary()
        self._associacoes = WeakKeyDictionary()

    def registrar_e_iniciar(self, thread):
        resultado = super().registrar_e_iniciar(thread)
        if resultado and type(thread) is _ThreadPadrao:
            with self.lock:
                # Só retorno normal de start. Exceção ambígua não chega aqui.
                self._partidas_comprovadas[thread] = True
        return resultado

    def registrar_com_responsabilidades(self, thread, reservas):
        # API NOVA somente do protótipo: depende de declaração completa pelo
        # produtor. Não se infere vínculo examinando args privados da Thread.
        if type(thread) is not _ThreadPadrao:
            raise TypeError('thread_padrao_exigida')
        reservas = tuple(reservas)
        if not reservas:
            raise ValueError('responsabilidades_explicitas_exigidas')
        with self.lock:
            if any(self._buscar_socket_sob_lock(t) is None for t in reservas):
                raise ValueError('reserva_de_outro_registro')
            self._associacoes[thread] = reservas
        return self.registrar_e_iniciar(thread)

    def _responsabilidades_resolvidas_sob_lock(self, thread):
        if self.erros_limpeza:
            return False
        reservas = self._associacoes.get(thread)
        if reservas is None:
            # Sem vínculo explícito, só prova global conservadora deste registro.
            return self._sockets_encerrados_sob_lock()
        for token in reservas:
            e = self._buscar_socket_sob_lock(token)
            if (e is None or e.estado not in ('fechada', 'sem_recurso') or e.em_uso
                    or e.erro is not None or e.limpeza_handler_pendente
                    or e.erro_fechamento_handler is not None):
                return False
        return True

    def resumir_threads_resolvidas(self):
        with self.lock:
            candidatas = [t for t in self.threads if type(t) is _ThreadPadrao
                and self._partidas_comprovadas.get(t) is True and t.ident is not None]
        prontas = set()
        for t in candidatas:
            # Join nunca ocorre sob lock do registro/controle.
            if t is not threading.current_thread():
                t.join(timeout=0)
                if not t.is_alive():
                    prontas.add(t)
        quantidade = 0
        with self.lock:
            global_resolvido = not self.erros_limpeza and self._sockets_encerrados_sob_lock()
            for i, t in enumerate(self.threads):
                if (type(t) is _ThreadPadrao and t in prontas
                        and self._partidas_comprovadas.get(t) is True and not t.is_alive()
                        and (global_resolvido or self._associacoes.get(t) is not None
                             and self._responsabilidades_resolvidas_sob_lock(t))):
                    self.threads[i] = ThreadResolvida(t.name, t.ident, t.native_id, t.daemon)
                    quantidade += 1
        return quantidade


class RegistroSocketsExperimental(RegistroTrabalhadores):
    def separar_sockets_resolvidos(self):
        quantidade = 0
        with self.lock:
            for numero, e in self._reservas_socket.items():
                # O estado fechada só é publicado após a prova do fechamento;
                # fileno isoladamente não autoriza a conversão.
                if (e.estado == 'fechada' and not e.em_uso and e.erro is None
                        and not e.limpeza_handler_pendente
                        and e.erro_fechamento_handler is None and e.recurso is not None):
                    self._reservas_socket[numero] = replace(e, recurso=None)
                    quantidade += 1
        return quantidade


class RegistroCombinadoExperimental(RegistroThreadsExperimental, RegistroSocketsExperimental):
    pass

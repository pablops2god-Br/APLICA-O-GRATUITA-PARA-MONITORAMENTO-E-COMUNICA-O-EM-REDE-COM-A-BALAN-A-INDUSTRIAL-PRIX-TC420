"""2B.6: armazenamento experimental, nunca importado pelo código operacional.

Só sem_recurso comprovado e sem erro/pendência entra em intervalos. Todos os
demais estados conservam entrada, token e recurso fortes. Chamador usa o lock
do registro, como no dicionário original. GC só altera o índice de identidades.
"""
from bisect import bisect_right
from collections.abc import MutableMapping
from dataclasses import dataclass
from weakref import WeakValueDictionary

from rede.servidor import RegistroTrabalhadores, _CriacaoSocketResolvida


@dataclass(frozen=True, slots=True)
class _IdentidadeDiagnostico:
    # Não é token operacional, não autentica operações e nunca é cadastrado.
    criacao_id: int
    ciclo_id: object


class ArmazenamentoIntervalos(MutableMapping):
    def __init__(self):
        self.fortes = {}
        self.identidades = WeakValueDictionary()  # chave int, não igualdade de tokens
        self.intervalos = []  # (primeiro, ultimo, ciclo_id, resultado_handler)
        self.ultimo = 0

    def _posicao(self, numero):
        return bisect_right(self.intervalos, numero, key=lambda faixa: faixa[0]) - 1

    def __getitem__(self, numero):
        if numero in self.fortes:
            return self.fortes[numero]
        pos = self._posicao(numero)
        if pos < 0 or numero > self.intervalos[pos][1]:
            raise KeyError(numero)
        _, _, ciclo, publicado = self.intervalos[pos]
        original = self.identidades.get(numero)
        identidade = original if original is not None else _IdentidadeDiagnostico(numero, ciclo)
        return _CriacaoSocketResolvida(identidade, resultado_limpeza_handler_publicado=publicado)

    def __setitem__(self, numero, entrada):
        if numero != entrada.reserva.criacao_id:
            raise ValueError('identidade_divergente')
        nova = numero == self.ultimo + 1
        if not nova and numero not in self.fortes:
            raise ValueError('resultado_terminal_nao_reescrever')
        if not nova and self.fortes[numero].reserva is not entrada.reserva:
            raise ValueError('token_original_exigido')
        elegivel = (entrada.estado == 'sem_recurso' and entrada.recurso is None
            and not entrada.em_uso and entrada.erro is None
            and not entrada.limpeza_handler_pendente and entrada.erro_fechamento_handler is None)
        if elegivel:
            # Entrada/token ainda fortes no argumento até a publicação terminar.
            self.identidades[numero] = entrada.reserva
            ciclo = entrada.reserva.ciclo_id
            flag = entrada.resultado_limpeza_handler_publicado
            pos = self._posicao(numero) + 1
            inicio = fim = numero
            esquerda = direita = pos
            if pos and self.intervalos[pos-1][1] == numero-1 and self.intervalos[pos-1][2:] == (ciclo, flag):
                inicio = self.intervalos[pos-1][0]
                esquerda = pos-1
            if pos < len(self.intervalos) and self.intervalos[pos][0] == numero+1 and self.intervalos[pos][2:] == (ciclo, flag):
                fim = self.intervalos[pos][1]
                direita = pos+1
            # Preparar substituição antes de alterar a lista evita remover
            # vizinhos antes de alocar o novo intervalo.
            substituicao = [(inicio, fim, ciclo, flag)]
            self.intervalos[esquerda:direita] = substituicao
            self.fortes.pop(numero, None)
        else:
            self.fortes[numero] = entrada
        if nova:
            self.ultimo = numero

    def __iter__(self):
        return iter(range(1, self.ultimo + 1))

    def __len__(self):
        return self.ultimo

    def __delitem__(self, numero):
        raise TypeError('remocao_de_historico_nao_suportada')


class RegistroIntervalosExperimental(RegistroTrabalhadores):
    def __init__(self):
        super().__init__()
        self._reservas_socket = ArmazenamentoIntervalos()

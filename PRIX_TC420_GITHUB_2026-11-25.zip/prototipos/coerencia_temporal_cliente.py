"""AC3-D3-B1: modelo isolado, sem importacao ou adaptacao de registros reais.

Revisoes locais cercam a coleta de evidencias. Estabilidade vale no intervalo
comum validado das fontes declaradas, sob o contrato dos escritores, nunca como
certificado de cobertura ou estado da aplicacao no instante da resposta.
"""
from contextlib import contextmanager
from dataclasses import dataclass
from threading import Lock
from uuid import uuid4


class _Versionado:
    def __init__(self, aplicacao_id, revisao=0):
        if type(aplicacao_id) is not str or not aplicacao_id:
            raise ValueError('aplicacao_invalida')
        if type(revisao) is not int or revisao < 0:
            raise ValueError('revisao_invalida')
        self._aplicacao_id = aplicacao_id
        self._instancia_id = uuid4().hex
        self._revisao = revisao
        self._confiavel = True
        self._lock = Lock()

    @property
    def aplicacao_id(self):
        return self._aplicacao_id

    @property
    def instancia_id(self):
        return self._instancia_id

    def _publicar_revisao(self):
        self._revisao += 1

    @contextmanager
    def _mudanca(self):
        # Uso interno apenas com atribuicoes locais; nenhum IO/callback de usuario.
        with self._lock:
            anterior = self._confiavel
            revisao_anterior = self._revisao
            self._confiavel = False
            yield
            self._publicar_revisao()
            if self._revisao != revisao_anterior + 1:
                raise RuntimeError('revisao_nao_publicada')
            self._confiavel = anterior
        # Excecao deixa confiavel=False, inclusive se a revisao nao avancou.

    def _selo(self):
        return dict(aplicacao_id=self.aplicacao_id, instancia_id=self.instancia_id,
                    revisao=self._revisao, confiavel=self._confiavel)

    def ler_revisao(self):
        with self._lock:
            return self._selo()


class RegistroTemporalExperimental(_Versionado):
    """Estado escalar sintetico; nao acompanha sockets/threads de verdade."""
    def __init__(self, aplicacao_id, *, revisao=0, **estado):
        super().__init__(aplicacao_id, revisao)
        self._validar_campos(estado)
        self._estado = estado.copy()

    @staticmethod
    def _validar_campos(campos):
        if any(type(k) is not str or not k or type(v) not in (str, int, bool, type(None))
               for k, v in campos.items()):
            raise TypeError('estado_experimental_invalido')

    def publicar(self, **campos):
        self._validar_campos(campos)
        with self._mudanca():
            self._estado.update(campos)

    def ler_evidencia(self):
        with self._lock:
            return self._selo() | {'conteudo': self._estado.copy()}


@dataclass(frozen=True)
class FonteExperimental:
    nome: str
    instancia_id: str
    registro: object


class InventarioTemporalExperimental(_Versionado):
    """Revisao de inclusoes/substituicoes/papeis, nao contador global de eventos.

    Fontes substituidas permanecem no conjunto coletado. Nao oferece remocao nem
    descarte automatico de geracoes antigas. Publicar antes de usar nova fonte
    e responsabilidade do escritor, ainda nao demonstrada na aplicacao real.
    """
    def __init__(self):
        super().__init__(uuid4().hex)
        self._fontes = []
        self._atuais = {}
        self._geracoes = {}

    def _entrada(self, nome, registro):
        # Captura de metadados fora do lock do inventario.
        if type(nome) is not str or not nome:
            raise ValueError('nome_invalido')
        identidade = registro.instancia_id
        if type(identidade) is not str or not identidade:
            raise ValueError('instancia_invalida')
        if registro.aplicacao_id != self.aplicacao_id:
            raise ValueError('fonte_estrangeira')
        return FonteExperimental(nome, identidade, registro)

    def incluir(self, nome, registro, *, substituir=False):
        entrada = self._entrada(nome, registro)
        with self._mudanca():
            if ((nome in self._atuais) is not substituir
                    or any(f.instancia_id == entrada.instancia_id for f in self._fontes)):
                raise ValueError('inclusao_invalida')
            self._fontes.append(entrada)
            self._atuais[nome] = entrada.instancia_id

    def nova_geracao(self, geracao):
        if type(geracao) is not int or geracao < 1:
            raise ValueError('geracao_invalida')
        with self._mudanca():
            if geracao in self._geracoes:
                raise ValueError('geracao_duplicada')
            self._geracoes[geracao] = 'cliente'

    def promover(self, geracao):
        with self._mudanca():
            if geracao not in self._geracoes:
                raise ValueError('geracao_desconhecida')
            self._geracoes[geracao] = 'principal'

    def ler_inventario(self):
        with self._lock:
            return self._selo() | {
                'fontes': tuple(self._fontes), 'atuais': tuple(sorted(self._atuais.items())),
                'geracoes': tuple(sorted(self._geracoes.items())),
            }


def _selo_valido(dado, instancia, aplicacao):
    if (type(dado) is not dict or dado['instancia_id'] != instancia
            or dado['aplicacao_id'] != aplicacao or dado['confiavel'] is not True
            or type(dado['revisao']) is not int or dado['revisao'] < 0):
        raise ValueError('evidencia_temporal_inconfiavel')
    return dado['revisao']


def _manifesto(inventario, catalogo):
    revisao = _selo_valido(inventario, catalogo.instancia_id, catalogo.aplicacao_id)
    fontes, atuais, geracoes = (inventario[n] for n in ('fontes', 'atuais', 'geracoes'))
    if any(type(x) is not tuple for x in (fontes, atuais, geracoes)):
        raise ValueError('inventario_invalido')
    if any(type(f) is not FonteExperimental for f in fontes):
        raise ValueError('fonte_invalida')
    ids = {f.instancia_id for f in fontes}
    if len(ids) != len(fontes) or len(dict(atuais)) != len(atuais):
        raise ValueError('inventario_duplicado')
    if (any(not any(f.nome == nome and f.instancia_id == ident for f in fontes)
            for nome, ident in atuais)
            or len(dict(geracoes)) != len(geracoes)
            or any(type(g) is not int or g < 1 or papel not in ('cliente', 'principal')
                   for g, papel in geracoes)):
        raise ValueError('inventario_incoerente')
    return revisao, tuple((f.nome, f.instancia_id) for f in fontes), atuais, geracoes


def avaliar_coerencia_experimental(catalogo):
    """Uma tentativa finita de leitura, sem esperar estabilidade ou executar IO.

    I0 -> vetor V0 completo -> evidencias E completas -> vetor V1 completo -> I1.
    V0=E.revisao=V1 e I0=I1 delimitam intervalo comum das fontes declaradas.
    Falta de revisao confiavel e desconhecida; divergencia confiavel e alteracao.
    Nunca promove essa propriedade a encerramento CLIENTE/global.
    """
    resultado = dict(
        estado_temporal='desconhecido', coerencia_validada=False, snapshot_atomico=False,
        cobertura_operacional='incompleta', encerramento_cliente_confirmado=False,
        encerramento_global_confirmado=False, revisoes_antes={}, revisoes_depois={},
        evidencias={}, pendencias=['cobertura_nao_demonstrada', 'aplicacao_fora_do_escopo'])
    try:
        inicial = catalogo.ler_inventario()
        manifesto = _manifesto(inicial, catalogo)
        fontes = inicial['fontes']
        antes = {f.instancia_id: _selo_valido(f.registro.ler_revisao(), f.instancia_id,
                 catalogo.aplicacao_id) for f in fontes}
        evidencias = {}
        for fonte in fontes:
            dado = fonte.registro.ler_evidencia()
            _selo_valido(dado, fonte.instancia_id, catalogo.aplicacao_id)
            if type(dado['conteudo']) is not dict:
                raise ValueError('conteudo_invalido')
            evidencias[fonte.instancia_id] = dado
        depois = {f.instancia_id: _selo_valido(f.registro.ler_revisao(), f.instancia_id,
                  catalogo.aplicacao_id) for f in fontes}
        final = catalogo.ler_inventario()
        manifesto_final = _manifesto(final, catalogo)
        if (manifesto_final[0] < manifesto[0] or any(not
                antes[i] <= evidencias[i]['revisao'] <= depois[i] for i in antes)):
            raise ValueError('revisao_regrediu')
        inventario_mudou = manifesto != manifesto_final
        fontes_mudaram = any(not antes[i] == evidencias[i]['revisao'] == depois[i] for i in antes)
        resultado.update(revisoes_antes=antes, revisoes_depois=depois, evidencias=evidencias)
        if inventario_mudou or fontes_mudaram:
            resultado['estado_temporal'] = 'alterado'
            if inventario_mudou:
                resultado['pendencias'].append('inventario_alterado')
            if fontes_mudaram:
                resultado['pendencias'].append('fontes_alteradas')
        else:
            resultado.update(estado_temporal='estavel', coerencia_validada=True)
    except Exception:
        resultado['pendencias'].append('revisao_ou_consulta_inconfiavel')
    return resultado

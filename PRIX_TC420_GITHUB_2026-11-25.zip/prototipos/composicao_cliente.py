"""Composição somente de leitura de dois contratos experimentais independentes.

Cobertura é uma declaração EXTERNA, explícita e vinculada à instância da aplicação;
não é inferida de inventários vazios. Não instrumenta criação operacional.
Revalida retratos completos, sem lock compartilhado, callbacks de limpeza ou joins.
"""
from dataclasses import dataclass
from uuid import uuid4

from prototipos.guarda_retentativas_cliente import GuardaRetentativasCliente
from prototipos.recursos_cliente import RegistroRecursosCliente


def _id(valor):
    if type(valor) is not int or valor < 1:
        raise ValueError("identidade_invalida")


@dataclass(frozen=True)
class ContextoClienteExperimental:
    retentativas: GuardaRetentativasCliente
    recursos: RegistroRecursosCliente
    aplicacao_id: str

    @classmethod
    def vincular(cls, retentativas, recursos):
        if (type(retentativas) is not GuardaRetentativasCliente
                or type(recursos) is not RegistroRecursosCliente):
            raise ValueError("registros_invalidos")
        return cls(retentativas, recursos, uuid4().hex)


@dataclass(frozen=True)
class VinculoRecurso:
    recurso_id: int
    geracao_id: int
    atividade_id: int  # ID bruto do proprietário no registro de recursos.
    retentativa_id: int | None = None  # None = atividade independente, sem retry.


@dataclass(frozen=True)
class CoberturaCliente:
    contexto: ContextoClienteExperimental
    geracoes: tuple = ()
    retentativas: tuple = ()  # Pares (geracao_id, retentativa_id).
    vinculos: tuple = ()
    completa: bool = False


def _validar_retentativas(retrato):
    if type(retrato) is not dict or set(retrato) != {
            "admissao_fechada", "retentativas", "secundarias", "conjunto_encerrado"}:
        raise ValueError("contrato_retentativas")
    if any(type(retrato[nome]) is not bool for nome in ("admissao_fechada", "conjunto_encerrado")):
        raise ValueError("contrato_retentativas")
    if type(retrato["retentativas"]) is not list or type(retrato["secundarias"]) is not list:
        raise ValueError("contrato_retentativas")
    pares, ids = {}, set()
    flags = ("partida_em_curso", "partida_resolvida", "start_invocado", "entrada", "retorno",
             "thread_terminada", "ausencia_comprovada", "parada_solicitada", "erro", "partida_ambigua")
    for item in retrato["retentativas"]:
        if type(item) is not dict or set(item) != set(flags) | {"id", "geracao", "modo_atual", "estado"}:
            raise ValueError("contrato_retentativas")
        _id(item["id"])
        _id(item["geracao"])
        if item["id"] in ids or any(type(item[nome]) is not bool for nome in flags):
            raise ValueError("contrato_retentativas")
        if item["estado"] not in (
                "admitida", "iniciando", "executando", "parada_solicitada",
                "encerramento_confirmado", "desconhecido") or item["modo_atual"] not in ("cliente", "principal"):
            raise ValueError("contrato_retentativas")
        if item["estado"] == "encerramento_confirmado" and (
                item["erro"] or item["partida_em_curso"] or not item["partida_resolvida"]
                or (item["ausencia_comprovada"] and (item["entrada"] or item["retorno"] or item["thread_terminada"]))
                or not (item["ausencia_comprovada"] or (
                    item["entrada"] and item["retorno"] and item["thread_terminada"]))):
            raise ValueError("prova_retentativa_contraditoria")
        ids.add(item["id"])
        pares[item["geracao"], item["id"]] = item
    secundarios_ids = set()
    for item in retrato["secundarias"]:
        if type(item) is not dict or set(item) != {
                "id", "retentativa", "tipo", "resolvida", "publicacao_em_curso", "limpeza_em_curso", "erro"}:
            raise ValueError("contrato_secundarias")
        _id(item["id"])
        _id(item["retentativa"])
        if item["id"] in ids | secundarios_ids or item["retentativa"] not in ids:
            raise ValueError("contrato_secundarias")
        secundarios_ids.add(item["id"])
        if (any(type(item[n]) is not bool for n in (
                "resolvida", "publicacao_em_curso", "limpeza_em_curso", "erro"))
                or item["tipo"] not in ("socket", "descoberta", "promocao", "operacao")):
            raise ValueError("contrato_secundarias")
        pai = next(p for p in pares.values() if p["id"] == item["retentativa"])
        if pai["estado"] == "encerramento_confirmado" and (
                not item["resolvida"] or item["publicacao_em_curso"] or item["limpeza_em_curso"] or item["erro"]):
            raise ValueError("prova_secundaria_contraditoria")
    esperado = retrato["admissao_fechada"] and all(
        item["estado"] == "encerramento_confirmado" for item in pares.values())
    if esperado != retrato["conjunto_encerrado"]:
        raise ValueError("agregado_retentativas_contraditorio")
    return pares


def _validar_recursos(retrato):
    if type(retrato) is not dict or set(retrato) != {
            "escopo", "admissao_fechada", "recursos", "encerramento_confirmado"}:
        raise ValueError("contrato_recursos")
    if (retrato["escopo"] != {"geracao_id": None, "retentativa_id": None}
            or type(retrato["recursos"]) is not list or any(type(retrato[n]) is not bool
                for n in ("admissao_fechada", "encerramento_confirmado"))):
        raise ValueError("contrato_recursos")
    recursos = {}
    flags = ("encerramento_confirmado", "publicado", "criacao_em_curso", "criacao_resolvida",
             "ausencia_comprovada", "fechamento_solicitado", "limpeza_em_curso")
    erros = ("erros_criacao", "erros_atendimento", "erros_limpeza", "erros_evidencia")
    for item in retrato["recursos"]:
        if type(item) is not dict or set(item) != set(flags + erros) | {
                "recurso_id", "geracao_id", "retentativa_id", "tipo", "modo_atual",
                "associado_a", "estado", "prova_fechamento", "usos"}:
            raise ValueError("contrato_recursos")
        for nome in ("recurso_id", "geracao_id", "retentativa_id"):
            _id(item[nome])
        if (item["recurso_id"] in recursos or any(type(item[n]) is not bool for n in flags)
                or type(item["usos"]) is not int or item["usos"] < 0
                or item["tipo"] not in RegistroRecursosCliente.TIPOS
                or item["modo_atual"] not in ("cliente", "principal")):
            raise ValueError("contrato_recursos")
        for nome in erros:
            if type(item[nome]) is not list or any(type(e) is not dict or set(e) != {
                    "etapa", "categoria"} or any(type(v) is not str for v in e.values()) for e in item[nome]):
                raise ValueError("contrato_erros")
        if item["estado"] not in ("ativo", "fechamento_solicitado", "encerramento_confirmado", "desconhecido"):
            raise ValueError("contrato_recursos")
        if item["encerramento_confirmado"] != (item["estado"] == "encerramento_confirmado"):
            raise ValueError("prova_recurso_contraditoria")
        if item["encerramento_confirmado"] and (
                item["criacao_em_curso"] or not item["criacao_resolvida"] or item["limpeza_em_curso"]
                or item["usos"] or item["erros_limpeza"] or item["erros_evidencia"]
                or not (item["ausencia_comprovada"] or item["prova_fechamento"] in (
                    "close_retornou_e_closed_true", "close_retornou"))):
            raise ValueError("prova_recurso_contraditoria")
        if item["encerramento_confirmado"]:
            if item["ausencia_comprovada"]:
                if item["publicado"] or item["prova_fechamento"] is not None:
                    raise ValueError("prova_ausencia_contraditoria")
            elif item["prova_fechamento"] != (
                    "close_retornou_e_closed_true" if item["tipo"].startswith("arquivo_") else "close_retornou"):
                raise ValueError("prova_tipo_invalida")
        recursos[item["recurso_id"]] = item
    esperado = retrato["admissao_fechada"] and all(i["encerramento_confirmado"] for i in recursos.values())
    if esperado != retrato["encerramento_confirmado"]:
        raise ValueError("agregado_recursos_contraditorio")
    return recursos


def _validar_cobertura(contexto, cobertura, retentativas, recursos):
    if (type(cobertura) is not CoberturaCliente or cobertura.contexto is not contexto
            or cobertura.completa is not True or any(type(t) is not tuple for t in (
                cobertura.geracoes, cobertura.retentativas, cobertura.vinculos))):
        raise ValueError("cobertura_ausente_ou_invalida")
    for geracao in cobertura.geracoes:
        _id(geracao)
    if len(set(cobertura.geracoes)) != len(cobertura.geracoes):
        raise ValueError("geracao_duplicada")
    pares = set()
    for par in cobertura.retentativas:
        if type(par) is not tuple or len(par) != 2:
            raise ValueError("retentativa_invalida")
        for valor in par:
            _id(valor)
        if par in pares or par[0] not in cobertura.geracoes:
            raise ValueError("retentativa_invalida")
        pares.add(par)
    if pares != set(retentativas):
        raise ValueError("retentativas_fora_cobertura")
    vinculos = {}
    for vinculo in cobertura.vinculos:
        if type(vinculo) is not VinculoRecurso:
            raise ValueError("vinculo_invalido")
        for valor in (vinculo.recurso_id, vinculo.geracao_id, vinculo.atividade_id):
            _id(valor)
        if vinculo.recurso_id in vinculos or vinculo.geracao_id not in cobertura.geracoes:
            raise ValueError("vinculo_invalido")
        item = recursos.get(vinculo.recurso_id)
        if item is None or (item["geracao_id"], item["retentativa_id"]) != (
                vinculo.geracao_id, vinculo.atividade_id):
            raise ValueError("propriedade_invalida")
        if vinculo.retentativa_id is not None:
            _id(vinculo.retentativa_id)
            if (vinculo.retentativa_id != vinculo.atividade_id
                    or (vinculo.geracao_id, vinculo.retentativa_id) not in retentativas):
                raise ValueError("associacao_retentativa_invalida")
        vinculos[vinculo.recurso_id] = vinculo
    if set(vinculos) != set(recursos):
        raise ValueError("recursos_fora_cobertura")
    for recurso_id, item in recursos.items():
        pai_id = item["associado_a"]
        if item["tipo"] == "arquivo_socket":
            _id(pai_id)
            pai = recursos.get(pai_id)
            filho_v, pai_v = vinculos[recurso_id], vinculos.get(pai_id)
            if (pai is None or pai["tipo"] not in ("socket_tcp", "socket_udp")
                    or pai_v is None or (filho_v.geracao_id, filho_v.atividade_id, filho_v.retentativa_id)
                    != (pai_v.geracao_id, pai_v.atividade_id, pai_v.retentativa_id)):
                raise ValueError("associacao_socket_invalida")
        elif pai_id is not None:
            raise ValueError("associacao_socket_invalida")
    return vinculos


def avaliar_cliente(contexto, cobertura=None):
    """Quatro leituras: T1, R1, T2, R2. Sem mutações, lock global ou retries.

    Para positivos, ambos os gates devem estar fechados e os estados terminais
    comprovados. Nessa região dos contratos atuais, criação/entrada/provas/erros
    são monotônicos; não há novo uso nem reserva que faça um ABA positivo. A
    igualdade completa delimita intervalo comum [R1,T2]. Mudança detectada recusa
    positivo e exige nova chamada. Não é certificado de imutabilidade futura.
    """
    resultado = {
        "aplicacao_id": None, "consistente": False, "cobertura_completa": False,
        "admissoes_fechadas": False, "retentativas": [], "recursos_sem_retentativa": [],
        "encerramento_confirmado": False, "pendencias": [],
    }
    etapa = "contexto"
    try:
        if (type(contexto) is not ContextoClienteExperimental
                or type(contexto.retentativas) is not GuardaRetentativasCliente
                or type(contexto.recursos) is not RegistroRecursosCliente
                or type(contexto.aplicacao_id) is not str or not contexto.aplicacao_id):
            raise ValueError("contexto_invalido")
        resultado["aplicacao_id"] = contexto.aplicacao_id
        etapa = "consulta"
        t1 = contexto.retentativas.obter_retrato()
        r1 = contexto.recursos.obter_retrato()
        t2 = contexto.retentativas.obter_retrato()
        r2 = contexto.recursos.obter_retrato()
        if t1 != t2 or r1 != r2:
            resultado["pendencias"].append("consulta_inconsistente")
            return resultado
        etapa = "contratos"
        retentativas, recursos = _validar_retentativas(t2), _validar_recursos(r2)
        resultado["consistente"] = True
        resultado["admissoes_fechadas"] = t2["admissao_fechada"] and r2["admissao_fechada"]
        etapa = "cobertura"
        vinculos = _validar_cobertura(contexto, cobertura, retentativas, recursos)
        resultado["cobertura_completa"] = True
        for par, item in retentativas.items():
            associados = sorted(v.recurso_id for v in vinculos.values()
                               if (v.geracao_id, v.retentativa_id) == par)
            resultado["retentativas"].append({
                "geracao_id": par[0], "retentativa_id": par[1], "recursos": associados,
                "execucao_confirmada": item["estado"] == "encerramento_confirmado",
                "encerramento_confirmado": resultado["admissoes_fechadas"]
                and item["estado"] == "encerramento_confirmado"
                and all(recursos[i]["encerramento_confirmado"] for i in associados),
            })
        resultado["recursos_sem_retentativa"] = sorted(
            v.recurso_id for v in vinculos.values() if v.retentativa_id is None)
        resultado["encerramento_confirmado"] = (
            t2["conjunto_encerrado"] and r2["encerramento_confirmado"]
            and all(i["encerramento_confirmado"] for i in resultado["retentativas"]))
        if not resultado["encerramento_confirmado"]:
            resultado["pendencias"].append("responsabilidades_ou_admissao_pendentes")
    except Exception:
        # Não publicar texto/objetos de erro, nem converter falha em ausência.
        resultado["encerramento_confirmado"] = False
        for item in resultado["retentativas"]:
            item["encerramento_confirmado"] = False
        resultado["pendencias"].append("falha_" + etapa)
    return resultado

"""2B.7 experimental. Nenhuma importação pelo servidor operacional."""
from prototipos.identidades_intervalos import RegistroIntervalosExperimental


def diagnostico_entrada(e):
    return dict(criacao_id=e.reserva.criacao_id, ciclo_id=e.reserva.ciclo_id,
        estado=e.estado, em_uso=e.em_uso, erro=e.erro,
        limpeza_handler_pendente=e.limpeza_handler_pendente,
        resultado_limpeza_handler_publicado=e.resultado_limpeza_handler_publicado)


class RegistroConsultasExperimental(RegistroIntervalosExperimental):
    def _diagnosticos_em_lote_sob_lock(self):
        # Fortes conservam ordem de admissão: substituições não mudam posição;
        # entradas retiradas para faixas nunca voltam para a tabela forte.
        fortes = iter(self._reservas_socket.fortes.items())
        atual = next(fortes, None)
        for inicio, fim, ciclo, publicado in self._reservas_socket.intervalos:
            while atual is not None and atual[0] < inicio:
                yield diagnostico_entrada(atual[1])
                atual = next(fortes, None)
            for numero in range(inicio, fim+1):
                yield dict(criacao_id=numero, ciclo_id=ciclo, estado='sem_recurso',
                    em_uso=False, erro=None, limpeza_handler_pendente=False,
                    resultado_limpeza_handler_publicado=publicado)
        while atual is not None:
            yield diagnostico_entrada(atual[1])
            atual = next(fortes, None)

    def _sockets_encerrados_sob_lock(self):
        armazenamento = self._reservas_socket
        # Prova de cobertura: nenhuma entrada simplesmente ausente vale como
        # encerrada. Disjunção/ordem das faixas são invariantes do escritor.
        cobertas = len(armazenamento.fortes) + sum(
            fim-inicio+1 for inicio, fim, _, _ in armazenamento.intervalos)
        return cobertas == len(armazenamento) and all(
            e.estado in ('fechada', 'sem_recurso') and not e.limpeza_handler_pendente
            and e.erro_fechamento_handler is None for e in armazenamento.fortes.values())

    def encerramento_confirmado(self):
        # Mesmo predicado, sem construir os dicionários do histórico.
        with self.lock:
            return (self.criacao_bloqueada
                and not any(t.is_alive() for t in self.threads)
                and not self.erros_limpeza and self._sockets_encerrados_sob_lock())

    def obter_situacao(self):
        with self.lock:
            return dict(criacao_bloqueada=self.criacao_bloqueada,
                threads_vivas=[t.name for t in self.threads if t.is_alive()],
                erros_limpeza=list(self.erros_limpeza),
                sockets_encerrados=self._sockets_encerrados_sob_lock(),
                criacoes_socket=tuple(self._diagnosticos_em_lote_sob_lock()),
                falhas_fechamento_handlers=tuple(dict(
                    criacao_id=e.reserva.criacao_id, ciclo_id=e.reserva.ciclo_id,
                    origem='handler.close', tipo=e.erro_fechamento_handler)
                    for e in self._reservas_socket.fortes.values()
                    if e.erro_fechamento_handler is not None))

"""Modelo de estados proposto, sem Tk, serviços, threads próprias ou rede.

Não descreve automaticamente o comportamento atual da interface e não é um
coordenador operacional. Recursos confirmados são evidência fornecida pelo ensaio.
"""
from threading import Lock

from rede.servidor import RegistroTentativasAplicacao, avaliar_encerramento_aplicacao


class ModeloEncerramentoInterface:
    def __init__(self, registro):
        if not isinstance(registro, RegistroTentativasAplicacao):
            raise ValueError("registro_invalido")
        self.registro = registro
        self._lock = Lock()
        self._estado = "aberta"
        self._tentativas = False
        self._recursos = None
        self._erro = None
        self._destruida = False
        self._sequencias = 0
        self._geracao = 0
        self._consulta = 0
        self._pulsos = 0
        self._atualizacoes = 0

    def solicitar(self, opcao):
        if opcao not in ("sim", "nao", "cancelar"):
            raise ValueError("opcao_invalida")
        with self._lock:
            if opcao != "sim" or self._estado != "aberta":
                return False
            # Apenas registro de ensaio em memória. Nenhum serviço é parado.
            self.registro.fechar_admissao()
            self._estado = "encerrando"
            self._sequencias += 1
            self._geracao += 1
            return True

    @staticmethod
    def _validar_agregado(resultado):
        campos = {"admissao_fechada", "total_tentativas", "confirmadas",
                  "falhas_partida_confirmadas", "pendentes", "desconhecidas",
                  "consistente", "encerramento_confirmado"}
        if type(resultado) is not dict or set(resultado) != campos:
            raise ValueError("consulta_invalida")
        for campo in ("admissao_fechada", "consistente", "encerramento_confirmado"):
            if type(resultado[campo]) is not bool:
                raise ValueError("consulta_invalida")
        for campo in ("total_tentativas", "confirmadas", "falhas_partida_confirmadas", "pendentes", "desconhecidas"):
            if type(resultado[campo]) is not int or resultado[campo] < 0:
                raise ValueError("consulta_invalida")
        if sum(resultado[c] for c in ("confirmadas", "falhas_partida_confirmadas", "pendentes", "desconhecidas")) != resultado["total_tentativas"]:
            raise ValueError("consulta_inconsistente")
        if resultado["encerramento_confirmado"] and (
                not resultado["admissao_fechada"] or not resultado["consistente"]
                or resultado["pendentes"] or resultado["desconhecidas"]):
            raise ValueError("consulta_inconsistente")
        return resultado["encerramento_confirmado"]

    def atualizar_evidencias(self, *, recursos_confirmados=None, avaliar=avaliar_encerramento_aplicacao):
        with self._lock:
            if self._estado == "aberta" or self._destruida:
                return False
            self._consulta += 1
            consulta = self._consulta
            # Invalida evidência anterior enquanto uma nova consulta está em curso.
            self._tentativas = False
            self._recursos = None
            self._estado = "encerrando"
        erro = None
        try:
            tentativas = self._validar_agregado(avaliar(self.registro))
            if self.registro.obter_retrato()["admissao_fechada"] is not True:
                raise ValueError("admissao_aberta")
        except Exception:
            tentativas = False
            erro = "consulta_agregada_nao_confirmada"
        recursos = recursos_confirmados if type(recursos_confirmados) is bool else None
        with self._lock:
            if consulta != self._consulta or self._destruida:
                return False
            self._tentativas, self._recursos, self._erro = tentativas, recursos, erro
            self._estado = ("erro_consulta" if erro else
                            "evidencias_completas" if tentativas and recursos is True else
                            "aguardando_recursos" if tentativas else "encerrando")
            return True

    def registrar_destruicao_simulada(self):
        with self._lock:
            if (self._destruida or self._estado != "evidencias_completas" or self._erro
                    or not self._tentativas or self._recursos is not True
                    or self.registro.obter_retrato()["admissao_fechada"] is not True):
                return False
            self._destruida = True
            self._estado = "janela_destruida"
            self._geracao += 1
            return True

    def registrar_atualizacao_simulada(self, geracao):
        with self._lock:
            if self._destruida or type(geracao) is not int or geracao != self._geracao:
                return False
            self._atualizacoes += 1
            return True

    def registrar_pulso_interface(self):
        with self._lock:
            if self._destruida:
                return False
            self._pulsos += 1
            return True

    def obter_retrato(self):
        with self._lock:
            return {
                "estado": self._estado,
                "admissao_fechada": self.registro.obter_retrato()["admissao_fechada"],
                "tentativas_confirmadas": self._tentativas, "recursos_confirmados": self._recursos,
                "janela_destruida": self._destruida, "erro": self._erro,
                "sequencias_parada_modeladas": self._sequencias, "geracao_interface": self._geracao,
                "pulsos_interface": self._pulsos, "atualizacoes_simuladas": self._atualizacoes,
            }

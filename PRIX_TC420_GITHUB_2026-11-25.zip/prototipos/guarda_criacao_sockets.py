"""Ensaio de reserva por ciclo; nenhuma integração com sockets operacionais.

Estende somente no protótipo o RegistroTrabalhadores real, usando seu lock/gate.
Callbacks de alocação/preparação/publicação/limpeza são fornecidos pelo harness.
"""
from dataclasses import dataclass, field, replace

from rede.servidor import RegistroTrabalhadores


class FalhaSemAlocacao(Exception):
    """Declaração de prova pelo produtor: nenhum recurso foi alocado."""


@dataclass(frozen=True)
class ReservaCriacao:
    ciclo_id: int
    criacao_id: int
    _dono: object = field(repr=False)


@dataclass(frozen=True)
class _Entrada:
    reserva: ReservaCriacao
    estado: str = "reservada"
    criacao_pendente: bool = True
    recurso: object = field(default=None, repr=False)
    erro: object = None


class RegistroCriacaoExperimental(RegistroTrabalhadores):
    def __init__(self, ciclo_id):
        super().__init__()
        if type(ciclo_id) is not int or ciclo_id <= 0:
            raise ValueError("ciclo_invalido")
        self.ciclo_id = ciclo_id
        self._ultimo_id_criacao = 0
        self._criacoes = {}

    def reservar_criacao(self):
        with self.lock:
            if self.criacao_bloqueada or self.publicacao_limpeza_concluida:
                return None
            self._ultimo_id_criacao += 1
            reserva = ReservaCriacao(self.ciclo_id, self._ultimo_id_criacao, self)
            self._criacoes[reserva.criacao_id] = _Entrada(reserva)
            return reserva

    def _buscar(self, reserva):
        if type(reserva) is not ReservaCriacao or reserva._dono is not self:
            return None
        entrada = self._criacoes.get(reserva.criacao_id)
        return entrada if entrada is not None and entrada.reserva is reserva else None

    def _anexar_alocacao(self, reserva, recurso):
        if recurso is None:
            raise ValueError("alocacao_sem_recurso")
        with self.lock:
            entrada = self._buscar(reserva)
            if entrada is None or entrada.estado != "reservada":
                raise ValueError("reserva_invalida")
            # A reserva já impede confirmação. A referência passa ao dono antes
            # de preparar/bind/listen ou expor o recurso a outro componente.
            self._criacoes[reserva.criacao_id] = replace(entrada, estado="alocada", recurso=recurso)

    def _publicar(self, reserva):
        with self.lock:
            entrada = self._buscar(reserva)
            if entrada is None or entrada.estado != "alocada":
                raise ValueError("publicacao_invalida")
            bloqueada = self.criacao_bloqueada or self.publicacao_limpeza_concluida
            self._criacoes[reserva.criacao_id] = replace(
                entrada, estado="aguarda_limpeza" if bloqueada else "publicada", criacao_pendente=False)
            return not bloqueada

    def _resolver_falha(self, reserva, recurso, ausencia_comprovada):
        with self.lock:
            entrada = self._buscar(reserva)
            if entrada is None:
                raise ValueError("reserva_invalida")
            if recurso is not None:
                # Também retém a referência se a anexação/publicação falhou.
                atualizada = replace(entrada, recurso=recurso, estado="aguarda_limpeza",
                                     criacao_pendente=False, erro="falha_criacao_com_recurso")
            elif ausencia_comprovada:
                atualizada = replace(entrada, estado="sem_recurso", criacao_pendente=False,
                                     erro="falha_sem_alocacao")
            else:
                # Exceção opaca não comprova que o alocador não criou algo.
                atualizada = replace(entrada, estado="criacao_incerta", erro="falha_criacao_incerta")
            self._criacoes[reserva.criacao_id] = atualizada

    def criar_simulado(self, alocar, preparar, fechar, comprovar_fechado, ao_publicar=None):
        reserva = self.reservar_criacao()
        if reserva is None:
            return None, None
        recurso = None
        try:
            recurso = alocar()
            self._anexar_alocacao(reserva, recurso)
            preparar(recurso)
            if ao_publicar is not None:
                ao_publicar(recurso)
            publicado = self._publicar(reserva)
        except Exception as erro:
            self._resolver_falha(reserva, recurso, isinstance(erro, FalhaSemAlocacao))
            if recurso is not None:
                self.limpar_recurso_simulado(reserva, fechar, comprovar_fechado)
            return reserva, None
        if not publicado:
            self.limpar_recurso_simulado(reserva, fechar, comprovar_fechado)
            return reserva, None
        return reserva, recurso

    def limpar_recurso_simulado(self, reserva, fechar, comprovar_fechado):
        with self.lock:
            entrada = self._buscar(reserva)
            if entrada is None:
                return False
            if entrada.estado in ("fechada", "sem_recurso"):
                return True
            if entrada.criacao_pendente or entrada.estado in ("fechando", "erro_limpeza"):
                return False
            self._criacoes[reserva.criacao_id] = replace(entrada, estado="fechando")
            recurso = entrada.recurso
        # Não há lock durante fechamento, comprovação ou outros callbacks.
        try:
            if comprovar_fechado(recurso) is not True:
                fechar(recurso)
            if comprovar_fechado(recurso) is not True:
                raise ValueError("liberacao_nao_comprovada")
        except Exception:
            with self.lock:
                atual = self._buscar(reserva)
                self._criacoes[reserva.criacao_id] = replace(
                    atual, estado="erro_limpeza", erro="falha_limpeza_recurso")
                self.erros_limpeza.append("falha_limpeza_recurso")
            return False
        with self.lock:
            atual = self._buscar(reserva)
            self._criacoes[reserva.criacao_id] = replace(atual, estado="fechada")
        return True

    def limpar_simulado(self, fechar, comprovar_fechado):
        # É o ensaio da limpeza do proprietário, não uma nova rotina operacional.
        self.bloquear_criacao()
        with self.lock:
            reservas = tuple(entrada.reserva for entrada in self._criacoes.values())
        for reserva in reservas:
            self.limpar_recurso_simulado(reserva, fechar, comprovar_fechado)
        return self.encerramento_confirmado()

    def obter_situacao(self):
        with self.lock:
            criacoes = tuple({
                "criacao_id": e.reserva.criacao_id, "ciclo_id": e.reserva.ciclo_id,
                "estado": e.estado, "criacao_pendente": e.criacao_pendente,
                "recurso_presente": e.recurso is not None, "erro": e.erro,
            } for e in self._criacoes.values())
            return {
                "criacao_bloqueada": self.criacao_bloqueada,
                "threads_vivas": [t.name for t in self.threads if t.is_alive()],
                "erros_limpeza": list(self.erros_limpeza),
                "ciclo_id": self.ciclo_id, "criacoes": criacoes,
                "criacoes_pendentes": sum(e.criacao_pendente for e in self._criacoes.values()),
                "recursos_pendentes": sum(e.estado not in ("fechada", "sem_recurso")
                                          for e in self._criacoes.values()),
            }

    def encerramento_confirmado(self):
        situacao = self.obter_situacao()
        return (situacao["criacao_bloqueada"] and not situacao["threads_vivas"]
                and not situacao["erros_limpeza"] and situacao["criacoes_pendentes"] == 0
                and situacao["recursos_pendentes"] == 0)

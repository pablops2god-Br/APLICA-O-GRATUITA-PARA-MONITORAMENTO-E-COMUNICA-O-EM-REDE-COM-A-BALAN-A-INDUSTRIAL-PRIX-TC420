"""Registro isolado de recursos CLIENTE; fábricas/objetos são fornecidos pelo ensaio.

Não abre rede/Tk, não importa a guarda de retentativas, não autoriza saída global.
close retornado prova o fechamento do objeto socket, não do par remoto nem de
makefiles associados. Arquivos exigem adicionalmente closed is True.
"""
from dataclasses import dataclass
from threading import Lock


@dataclass(frozen=True)
class RecursoId:
    origem: object
    numero: int


class RegistroRecursosCliente:
    TIPOS = ("socket_tcp", "socket_udp", "arquivo_socket", "arquivo_comum")

    def __init__(self):
        self._lock = Lock()
        self._origem = object()
        self._sequencia = 0
        self._recursos = {}
        self._objetos = {}
        self._modos = {}
        self._fechada = False

    @staticmethod
    def _validar_id(valor):
        if type(valor) is not int or valor < 1:
            raise ValueError("proprietario_invalido")

    def _buscar(self, identidade):
        if (type(identidade) is not RecursoId or identidade.origem is not self._origem
                or identidade not in self._recursos):
            raise ValueError("recurso_invalido")
        return self._recursos[identidade]

    @staticmethod
    def _erro(erro, etapa):
        categoria = ("falha_io" if isinstance(erro, OSError) else
                     "falha_operacao" if isinstance(erro, Exception) else "falha_base")
        return {"etapa": etapa, "categoria": categoria}

    def reservar(self, tipo, geracao_id, retentativa_id, *, associado_a=None):
        self._validar_id(geracao_id)
        self._validar_id(retentativa_id)
        if tipo not in self.TIPOS:
            raise ValueError("tipo_invalido")
        with self._lock:
            if self._fechada:
                return None
            if tipo == "arquivo_socket":
                socket = self._buscar(associado_a)
                if (socket["tipo"] not in ("socket_tcp", "socket_udp")
                        or socket["geracao_id"] != geracao_id
                        or socket["retentativa_id"] != retentativa_id):
                    raise ValueError("associacao_invalida")
                if (not socket["publicado"] or socket["fechamento_solicitado"]
                        or socket["prova_fechamento"]):
                    return None
            elif associado_a is not None:
                raise ValueError("associacao_invalida")
            self._sequencia += 1
            identidade = RecursoId(self._origem, self._sequencia)
            self._modos.setdefault(geracao_id, "cliente")
            self._recursos[identidade] = {
                "tipo": tipo, "geracao_id": geracao_id, "retentativa_id": retentativa_id,
                "associado_a": associado_a, "objeto": None, "publicado": False,
                "criacao_tentada": False, "criacao_em_curso": False,
                "criacao_resolvida": False, "ausencia_comprovada": False,
                "fechamento_solicitado": False, "limpeza_em_curso": False,
                "prova_fechamento": None, "usos": 0,
                "erros_criacao": [], "erros_atendimento": [],
                "erros_limpeza": [], "erros_evidencia": [],
            }
            return identidade

    def criar(self, identidade, alocar, *, preparar=None):
        """Reserva prévia obrigatória; associa antes de preparação/publicação.

        Alocar que lança sem devolver handle é ambíguo. Ausência requer prova
        explícita. Preparar que falha após associação mantém handle para limpeza.
        Reservas anteriores ao fechamento podem completar e ficam solicitadas.
        """
        if not callable(alocar) or (preparar is not None and not callable(preparar)):
            raise ValueError("fabrica_invalida")
        with self._lock:
            item = self._buscar(identidade)
            if item["criacao_tentada"] or item["criacao_resolvida"]:
                return False
            item["criacao_tentada"] = True
            item["criacao_em_curso"] = True
        try:
            objeto = alocar()
            with self._lock:
                item = self._recursos[identidade]
                if objeto is None:
                    raise ValueError("handle_ausente")
                anterior = self._objetos.get(id(objeto))
                if anterior is not None:
                    falha = {"etapa": "associacao", "categoria": "handle_duplicado"}
                    item["erros_evidencia"].append(falha.copy())
                    self._recursos[anterior]["erros_evidencia"].append(falha.copy())
                    raise ValueError("handle_duplicado")
                item["objeto"] = objeto
                self._objetos[id(objeto)] = identidade
            if preparar is not None:
                preparar(objeto)
            with self._lock:
                self._recursos[identidade]["publicado"] = True
            return True
        except BaseException as erro:
            with self._lock:
                self._recursos[identidade]["erros_criacao"].append(self._erro(erro, "criacao"))
            raise
        finally:
            with self._lock:
                item = self._recursos[identidade]
                item["criacao_em_curso"] = False
                item["criacao_resolvida"] = item["objeto"] is not None

    def comprovar_ausencia(self, identidade, *, nao_alocado):
        """Provedor externo deve provar inexistência de recurso/efeito tardio."""
        if nao_alocado is not True:
            raise ValueError("ausencia_nao_comprovada")
        with self._lock:
            item = self._buscar(identidade)
            if item["criacao_em_curso"] or item["objeto"] is not None:
                return False
            item["ausencia_comprovada"] = True
            item["criacao_resolvida"] = True
            return True

    def fechar_admissao(self):
        with self._lock:
            if self._fechada:
                return False
            self._fechada = True
            for item in self._recursos.values():
                item["fechamento_solicitado"] = True
            return True

    def promover(self, geracao_id):
        self._validar_id(geracao_id)
        with self._lock:
            self._modos[geracao_id] = "principal"

    def fechar(self, identidade):
        """Reivindica limpeza; executa close/observação sem lock; publica junto.

        Não deduz fechamento de socket via fileno nem fecha makefiles por tabela.
        Uso em curso continua pendente mesmo depois de close retornar.
        """
        with self._lock:
            item = self._buscar(identidade)
            item["fechamento_solicitado"] = True
            if (item["limpeza_em_curso"] or not item["criacao_resolvida"]
                    or item["ausencia_comprovada"] or item["prova_fechamento"]):
                return False
            objeto, tipo = item["objeto"], item["tipo"]
            if objeto is None:
                return False
            item["limpeza_em_curso"] = True
        prova, erro_limpeza, erro_evidencia = None, None, None
        etapa = "close"
        try:
            objeto.close()
            if tipo.startswith("arquivo_"):
                etapa = "observacao_closed"
                if objeto.closed is True:
                    prova = "close_retornou_e_closed_true"
                else:
                    erro_evidencia = {"etapa": etapa, "categoria": "fechamento_nao_comprovado"}
            else:
                prova = "close_retornou"
            return prova is not None
        except BaseException as erro:
            if etapa == "close":
                erro_limpeza = self._erro(erro, etapa)
            else:
                erro_evidencia = self._erro(erro, etapa)
            raise
        finally:
            with self._lock:
                item = self._recursos[identidade]
                if erro_limpeza is not None:
                    item["erros_limpeza"].append(erro_limpeza)
                if erro_evidencia is not None:
                    item["erros_evidencia"].append(erro_evidencia)
                item["prova_fechamento"] = prova
                item["limpeza_em_curso"] = False

    def identidades_para_encerramento(self):
        """IDs conhecidos prontos para cleanup; nao chama objetos externos."""
        with self._lock:
            return tuple(token for token, item in self._recursos.items()
                         if item['criacao_resolvida'] and not item['criacao_em_curso']
                         and not item['ausencia_comprovada'] and not item['prova_fechamento']
                         and not item['limpeza_em_curso'])

    def interromper_e_fechar(self, identidade):
        with self._lock:
            item = self._buscar(identidade)
            objeto, tipo = item['objeto'], item['tipo']
        if tipo.startswith('socket_') and objeto is not None:
            interromper = getattr(objeto, 'shutdown', None)
            if interromper is not None:
                try:
                    interromper(2)
                except OSError:
                    pass  # Socket desconectado: close ainda deve ser tentado.
        return self.fechar(identidade)

    def usar(self, identidade, operacao, *, fechar_ao_sair=True):
        """Mantém o erro original se atendimento e limpeza falharem juntos."""
        if not callable(operacao) or type(fechar_ao_sair) is not bool:
            raise ValueError("operacao_invalida")
        with self._lock:
            item = self._buscar(identidade)
            if (self._fechada or not item["publicado"] or not item["criacao_resolvida"]
                    or item["fechamento_solicitado"]):
                raise RuntimeError("recurso_indisponivel")
            item["usos"] += 1
            objeto = item["objeto"]
        try:
            try:
                resultado = operacao(objeto)
            except BaseException as erro:
                with self._lock:
                    self._recursos[identidade]["erros_atendimento"].append(
                        self._erro(erro, "atendimento"))
                if fechar_ao_sair:
                    try:
                        self.fechar(identidade)
                    except BaseException:
                        pass  # Evidência da limpeza já publicada; preservar o original.
                raise
            else:
                if fechar_ao_sair:
                    self.fechar(identidade)
                return resultado
        finally:
            with self._lock:
                self._recursos[identidade]["usos"] -= 1

    @staticmethod
    def _estado(item):
        if item["erros_limpeza"] or item["erros_evidencia"]:
            return "desconhecido"
        if not item["criacao_resolvida"] or item["criacao_em_curso"]:
            return "desconhecido"
        if (not item["limpeza_em_curso"] and item["usos"] == 0
                and (item["ausencia_comprovada"] or item["prova_fechamento"])):
            return "encerramento_confirmado"
        if item["fechamento_solicitado"]:
            return "fechamento_solicitado"
        return "ativo"

    def obter_retrato(self, *, geracao_id=None, retentativa_id=None):
        for filtro in (geracao_id, retentativa_id):
            if filtro is not None:
                self._validar_id(filtro)
        with self._lock:
            recursos = []
            for identidade, item in self._recursos.items():
                if ((geracao_id is not None and item["geracao_id"] != geracao_id)
                        or (retentativa_id is not None and item["retentativa_id"] != retentativa_id)):
                    continue
                estado = self._estado(item)
                recursos.append({
                    "recurso_id": identidade.numero, "geracao_id": item["geracao_id"],
                    "retentativa_id": item["retentativa_id"], "tipo": item["tipo"],
                    "modo_atual": self._modos[item["geracao_id"]],
                    "associado_a": item["associado_a"].numero if item["associado_a"] else None,
                    "estado": estado, "encerramento_confirmado": estado == "encerramento_confirmado",
                    **{nome: item[nome] for nome in (
                        "publicado", "criacao_em_curso", "criacao_resolvida", "ausencia_comprovada",
                        "fechamento_solicitado", "limpeza_em_curso", "prova_fechamento", "usos")},
                    **{nome: [erro.copy() for erro in item[nome]] for nome in (
                        "erros_criacao", "erros_atendimento", "erros_limpeza", "erros_evidencia")},
                })
            return {
                "escopo": {"geracao_id": geracao_id, "retentativa_id": retentativa_id},
                "admissao_fechada": self._fechada, "recursos": recursos,
                "encerramento_confirmado": self._fechada and all(
                    recurso["encerramento_confirmado"] for recurso in recursos),
            }

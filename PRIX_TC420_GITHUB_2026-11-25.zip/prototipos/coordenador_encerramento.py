"""Coordenador experimental de evidências, sem integração operacional ou Tk.

solicitar_encerramento é curto. executar_parada e avaliar_encerramento são passos
síncronos explícitos para um executor externo ao UI no ensaio; não criam workers.
Nenhum resultado chama widgets ou comprova recursos sem os controles fornecidos.
"""
from threading import Lock

from rede.servidor import RegistroTentativasAplicacao, avaliar_encerramento_aplicacao
from prototipos.estados_encerramento_interface import ModeloEncerramentoInterface


RESPONSABILIDADES = (
    "leitores_cliente", "retentativas_descoberta", "observadores_servidor",
    "callbacks_interface", "tcp_direto_opcional", "preparacao_inicializacoes",
    "inventario_operacional",
)
ESTADOS_EVIDENCIA = ("confirmado", "pendente", "desconhecido")


class CoordenadorEncerramentoExperimental:
    def __init__(self, registro, *, solicitar_paradas=None, consultar_responsabilidades=None,
                 avaliar_agregado=avaliar_encerramento_aplicacao):
        if not isinstance(registro, RegistroTentativasAplicacao):
            raise ValueError("registro_invalido")
        paradas = {} if solicitar_paradas is None else solicitar_paradas
        if type(paradas) is not dict or any(
                nome not in ("servidores",) + RESPONSABILIDADES or not callable(callback)
                for nome, callback in paradas.items()):
            raise ValueError("paradas_invalidas")
        self.registro = registro
        self._paradas = tuple(paradas.items())
        self._consultar_responsabilidades = consultar_responsabilidades
        self._avaliar_agregado = avaliar_agregado
        self._lock = Lock()
        self._estado = "executando"
        self._fases = [self._estado]
        self._admissao_fechada = False
        self._parada_iniciada = False
        self._parada_concluida = False
        self._sequencias = 0
        self._chamadas_parada = []
        self._erros = []
        self._agregado_confirmado = False
        self._responsabilidades = dict.fromkeys(RESPONSABILIDADES, "desconhecido")
        self._consulta = 0
        self._consultas_pendentes = set()

    def _mudar_sob_lock(self, estado):
        if estado != self._estado:
            self._estado = estado
            self._fases.append(estado)

    def _registrar_erro_sob_lock(self, etapa, componente, erro):
        categoria = "falha_io" if isinstance(erro, OSError) else "falha_operacao"
        self._erros.append({"etapa": etapa, "componente": componente, "categoria": categoria})
        self._mudar_sob_lock("encerramento_pendente")

    def solicitar_encerramento(self):
        with self._lock:
            if self._estado != "executando":
                return False
            self._sequencias += 1
            self._mudar_sob_lock("encerramento_solicitado")
        try:
            self.registro.fechar_admissao()
            if self.registro.obter_retrato()["admissao_fechada"] is not True:
                raise ValueError("admissao_nao_fechada")
        except Exception as erro:
            with self._lock:
                self._registrar_erro_sob_lock("admissao", "registro", erro)
            return True
        with self._lock:
            self._admissao_fechada = True
            self._mudar_sob_lock("admissao_fechada")
        return True

    def cancelar_saida(self):
        with self._lock:
            # Não desfaz fechamento de gate nem parada já solicitada.
            return self._estado == "executando"

    def responder_usuario(self, resposta):
        if resposta == "sim":
            return self.solicitar_encerramento()
        if resposta == "cancelar":
            return self.cancelar_saida()
        if resposta == "nao":
            return False  # Sem ocultação ou parada implícita.
        raise ValueError("resposta_invalida")

    def executar_parada(self):
        with self._lock:
            if not self._admissao_fechada or self._parada_iniciada:
                return False
            self._parada_iniciada = True
            self._mudar_sob_lock("aguardando_encerramento")
        # Callback pode demorar: nunca executa sob o lock do coordenador.
        for nome, callback in self._paradas:
            with self._lock:
                self._chamadas_parada.append(nome)
            try:
                callback()
            except Exception as erro:
                with self._lock:
                    self._registrar_erro_sob_lock("parada", nome, erro)
                # Continua tentando os demais serviços, sem repetir os anteriores.
        with self._lock:
            self._parada_concluida = True
            if self._erros:
                self._mudar_sob_lock("encerramento_pendente")
        return True

    def avaliar_encerramento(self):
        with self._lock:
            if not self._admissao_fechada or self._estado == "encerramento_confirmado":
                return False
            self._consulta += 1
            consulta = self._consulta
            self._consultas_pendentes.add(consulta)
            self._agregado_confirmado = False
            self._responsabilidades = dict.fromkeys(RESPONSABILIDADES, "desconhecido")
            parada_concluida = self._parada_concluida
        agregado = False
        responsabilidades = dict.fromkeys(RESPONSABILIDADES, "desconhecido")
        erros = []
        try:
            agregado = ModeloEncerramentoInterface._validar_agregado(self._avaliar_agregado(self.registro))
            if self.registro.obter_retrato()["admissao_fechada"] is not True:
                raise ValueError("admissao_inconsistente")
        except Exception as erro:
            erros.append(("consulta_agregada", "registro", erro))
        try:
            if self._consultar_responsabilidades is not None:
                evidencias = self._consultar_responsabilidades()
                if (type(evidencias) is not dict or set(evidencias) != set(RESPONSABILIDADES)
                        or any(type(v) is not str or v not in ESTADOS_EVIDENCIA for v in evidencias.values())):
                    raise ValueError("evidencias_invalidas")
                responsabilidades = evidencias.copy()
        except Exception as erro:
            erros.append(("consulta_recursos", "inventario_operacional", erro))
        with self._lock:
            self._consultas_pendentes.remove(consulta)
            if consulta != self._consulta:
                # Falha observada nunca desaparece porque chegou uma consulta nova.
                for etapa, componente, erro in erros:
                    self._registrar_erro_sob_lock(etapa, componente, erro)
                return False
            for etapa, componente, erro in erros:
                self._registrar_erro_sob_lock(etapa, componente, erro)
            self._agregado_confirmado = agregado
            self._responsabilidades = responsabilidades
            confirmado = (parada_concluida and self._parada_concluida and agregado
                          and not self._erros and not self._consultas_pendentes
                          and all(v == "confirmado" for v in responsabilidades.values()))
            self._mudar_sob_lock("encerramento_confirmado" if confirmado else "encerramento_pendente")
            return True

    def obter_retrato(self):
        with self._lock:
            return {
                "estado": self._estado, "fases": tuple(self._fases),
                "admissao_fechada": self._admissao_fechada,
                "sequencias_parada": self._sequencias,
                "parada_iniciada": self._parada_iniciada,
                "parada_concluida": self._parada_concluida,
                "chamadas_parada": tuple(self._chamadas_parada),
                "consultas_em_curso": len(self._consultas_pendentes),
                "tentativas_confirmadas": self._agregado_confirmado,
                "responsabilidades": self._responsabilidades.copy(),
                "erros": tuple(e.copy() for e in self._erros),
                "encerramento_confirmado": self._estado == "encerramento_confirmado",
            }


class PoliticaVisualSimulada:
    """Somente metadados visuais: nunca para serviços nem chama widgets."""
    def __init__(self):
        self._lock = Lock()
        self._destruida = False
        self._oculta = False
        self._geracao = 0
        self._atualizacoes = 0

    def solicitar_ocultacao(self):
        with self._lock:
            if self._destruida:
                return False
            self._oculta = True
            return True

    def marcar_destruida_no_ensaio(self):
        with self._lock:
            self._destruida = True
            self._geracao += 1

    def registrar_atualizacao(self, geracao):
        with self._lock:
            if self._destruida or type(geracao) is not int or geracao != self._geracao:
                return False
            self._atualizacoes += 1
            return True

    def obter_retrato(self):
        with self._lock:
            return {"destruida": self._destruida, "oculta": self._oculta,
                    "geracao": self._geracao, "atualizacoes": self._atualizacoes}

"""Inventário experimental do CLIENTE: apenas evidências fornecidas pelo ensaio.

Não descobre recursos, não inicia workers, não fecha sockets e não chama Tk.
O executor futuro deve reservar ANTES de alocar, resolver a preparação mesmo
quando start falhar e fornecer provas de término/liberação, nunca só stop.set().
"""
from threading import Lock

from rede.servidor import ContextoCicloServidor, RegistroTentativasAplicacao


# Descoberta/eleição/reconexão síncronas são fases do leitor, não novas threads.
# Cada chamada/socket/arquivo efetivamente iniciado ganha identidade separada.
PROVAS = {
    "leitor": ("thread_terminada",),
    "retentativa": ("thread_terminada",),
    "descoberta": ("chamada_retornada", "sockets_liberados"),
    "configuracao": ("chamada_retornada", "socket_liberado", "arquivo_liberado"),
    "registro": ("chamada_retornada", "socket_liberado", "arquivo_liberado"),
    "recepcao_peso": ("chamada_retornada", "socket_liberado", "arquivo_liberado"),
    "observador": ("thread_terminada",),
    "supervisor": ("thread_terminada",),
    "finalizador": ("thread_terminada",),
    "tcp_direto_opcional": ("thread_terminada", "socket_liberado"),
    "callback": ("callback_consumido_ou_invalidado",),
    "promocao": ("chamada_retornada",),
}


class ResponsabilidadesClienteExperimental:
    def __init__(self, registro):
        if not isinstance(registro, RegistroTentativasAplicacao):
            raise ValueError("registro_invalido")
        self.registro = registro
        self._lock = Lock()
        self._itens = {}
        self._sequencia = 0
        self._fechado = False
        self._modo = "cliente"
        self._geracao = 0
        self._destruida = False
        self._atualizacoes = 0
        self._erro_gate = False

    def _reservar(self, tipo, proprietario, daemon):
        if tipo not in PROVAS or type(proprietario) is not int or proprietario < 1:
            raise ValueError("responsabilidade_invalida")
        if type(daemon) is not bool:
            raise ValueError("daemon_invalido")
        if self._fechado or self.registro.obter_retrato()["admissao_fechada"]:
            return None
        if tipo == "callback" and self._destruida:
            return None
        self._sequencia += 1
        chave = self._sequencia
        self._itens[chave] = {
            "id": chave, "tipo": tipo, "proprietario": proprietario,
            "daemon": daemon, "preparacao_resolvida": False, "iniciada": False,
            "parada_solicitada": False, "erro": False,
            "provas": dict.fromkeys(PROVAS[tipo]), "geracao": self._geracao,
            "tentativa_id": None,
        }
        return chave

    def reservar(self, tipo, proprietario, *, daemon=False):
        if tipo == "promocao":
            if daemon is not False:
                raise ValueError("promocao_sincrona")
            return self.reservar_promocao(proprietario)
        with self._lock:
            return self._reservar(tipo, proprietario, daemon)

    def reservar_promocao(self, proprietario):
        """Mesma admissão real de servidores, sem executar qualquer promoção.

        A reserva local precede admitir: exceção, inclusive após publicação no
        registro externo, deixa responsabilidade desconhecida e visível.
        """
        with self._lock:
            chave = self._reservar("promocao", proprietario, False)
            if chave is None:
                return None
            item = self._itens[chave]
            try:
                contexto = ContextoCicloServidor()
                tentativa = self.registro.admitir(contexto)
                if tentativa is None:
                    item["preparacao_resolvida"] = True
                    item["provas"] = dict.fromkeys(PROVAS["promocao"], True)
                else:
                    item["tentativa_id"] = tentativa
            except Exception:
                item["erro"] = True  # Sem mensagem/objeto possivelmente sensível.
            return chave

    def ativar(self, chave):
        with self._lock:
            item = self._itens[chave]
            if (self._fechado or self.registro.obter_retrato()["admissao_fechada"]
                    or item["preparacao_resolvida"] or item["iniciada"] or item["erro"]):
                return False
            item["iniciada"] = True
            return True

    def resolver_preparacao(self, chave, *, nao_iniciada=False):
        """Comprova que não haverá publicação/alocação tardia desta reserva.

        nao_iniciada exige prova externa de ausência de execução E de recursos;
        start que lançou exceção depois de iniciar não satisfaz esse contrato.
        """
        if type(nao_iniciada) is not bool:
            raise ValueError("prova_invalida")
        with self._lock:
            item = self._itens[chave]
            if nao_iniciada and item["iniciada"]:
                raise ValueError("execucao_observada")
            item["preparacao_resolvida"] = True
            if nao_iniciada:
                item["provas"] = dict.fromkeys(item["provas"], True)

    def comprovar(self, chave, **provas):
        if any(valor is not None and type(valor) is not bool for valor in provas.values()):
            raise ValueError("prova_invalida")
        with self._lock:
            item = self._itens[chave]
            if not provas.keys() <= item["provas"].keys():
                raise ValueError("prova_invalida")
            for nome, valor in provas.items():
                if item["provas"][nome] is True and valor is not True:
                    item["erro"] = True  # Reuso/conflito exige investigação.
                item["provas"][nome] = valor

    def registrar_falha(self, chave):
        with self._lock:
            self._itens[chave]["erro"] = True

    def solicitar_parada(self):
        with self._lock:
            if self._fechado:
                return False
            self._fechado = True
            try:
                self.registro.fechar_admissao()
            except Exception:
                self._erro_gate = True
            for item in self._itens.values():
                item["parada_solicitada"] = True
            return True

    def promover(self, chave):
        with self._lock:
            item = self._itens[chave]
            if item["tipo"] != "promocao" or not item["iniciada"]:
                raise ValueError("promocao_nao_iniciada")
            self._modo = "principal"
            # Não remove nem confirma leitor/descoberta antigos.

    def destruir_janela_simulada(self):
        with self._lock:
            self._destruida = True
            self._geracao += 1
            for item in self._itens.values():
                if item["tipo"] == "callback":
                    item["preparacao_resolvida"] = True
                    item["provas"]["callback_consumido_ou_invalidado"] = True

    def executar_callback_simulado(self, chave):
        """Representa atomicamente um acesso; não aceita função/Tk reais."""
        with self._lock:
            item = self._itens[chave]
            if item["tipo"] != "callback":
                raise ValueError("callback_invalido")
            if (self._destruida or self._fechado or item["geracao"] != self._geracao
                    or item["erro"] or not item["iniciada"]
                    or item["provas"]["callback_consumido_ou_invalidado"] is True):
                return False
            self._atualizacoes += 1
            item["preparacao_resolvida"] = True
            item["provas"]["callback_consumido_ou_invalidado"] = True
            return True

    @staticmethod
    def _estado(item):
        if item["erro"]:
            return "desconhecido"
        if item["preparacao_resolvida"] and all(v is True for v in item["provas"].values()):
            return "encerramento_confirmado"
        if item["parada_solicitada"]:
            return "parada_solicitada"
        if item["iniciada"]:
            return "ativo"
        return "desconhecido"

    def obter_retrato(self):
        with self._lock:
            itens = []
            for original in self._itens.values():
                item = dict(original, provas=original["provas"].copy())
                item["estado"] = self._estado(original)
                itens.append(item)
            fechado = self._fechado and self.registro.obter_retrato()["admissao_fechada"]
            return {
                "modo": self._modo, "responsabilidades": itens,
                "admissao_fechada": fechado, "erro_gate": self._erro_gate,
                "atualizacoes": self._atualizacoes, "janela_destruida": self._destruida,
                "encerramento_confirmado": bool(fechado and not self._erro_gate and all(
                    i["estado"] == "encerramento_confirmado" for i in itens)),
            }

"""Guarda usada na infraestrutura CLIENTE; executor e provas são injetados.

Não abre sockets, não chama Tk, não decide eleição e não autoriza saída global.
Uma instância acompanha todas as gerações CLIENTE de uma execução da aplicação.
Fábricas/rotinas/is_alive/publicadores são sempre chamados fora do lock.
"""
from dataclasses import dataclass
from contextlib import contextmanager
from threading import Lock
from uuid import uuid4


@dataclass(frozen=True)
class Identidade:
    origem: object
    numero: int
    categoria: str


class GuardaRetentativasCliente:
    def __init__(self):
        self._lock = Lock()
        self._origem = object()
        self._sequencia = 0
        self._geracoes = {}
        self._reservas = {}
        self._secundarias = {}
        self._fechada = False
        self._fonte_id = uuid4().hex
        self._revisao = 0
        self._temporal_comprometida = False
        self._revisao_confiavel = True

    @property
    def fonte_id(self):
        return self._fonte_id

    def _estado_local(self):
        # Apenas valores locais; nunca comparar/chamar a thread concreta.
        reservas = tuple((token, tuple((n, id(v) if n == 'thread' else v)
                         for n, v in item.items())) for token, item in self._reservas.items())
        secundarias = tuple((token, tuple(item.items())) for token, item in self._secundarias.items())
        return (self._sequencia, self._fechada, tuple(self._geracoes.items()),
                reservas, secundarias, self._temporal_comprometida)

    def _avancar_revisao(self):
        self._revisao += 1

    @staticmethod
    def _separar_falha(original, adicional):
        if original is not adicional:
            original.__cause__ = adicional
            original.__suppress_context__ = True

    @contextmanager
    def _publicacao_local(self, original=None):
        """Somente as secoes locais que ja usavam o lock; callbacks ficam fora."""
        with self._lock:
            antes = self._estado_local()
            anterior = self._revisao
            self._revisao_confiavel = False
            falha = None
            try:
                yield
            except BaseException as erro:
                falha = erro
                raise
            finally:
                try:
                    mudou = antes != self._estado_local()
                    if mudou:
                        if falha is not None:
                            self._temporal_comprometida = True
                        self._avancar_revisao()
                        if self._revisao != anterior + 1:
                            raise RuntimeError('revisao_guarda_nao_publicada')
                    self._revisao_confiavel = not self._temporal_comprometida
                except BaseException as acompanhamento:
                    self._temporal_comprometida = True
                    self._revisao_confiavel = False
                    primario = falha if falha is not None else original
                    if primario is None:
                        raise
                    self._separar_falha(primario, acompanhamento)

    def _selo(self):
        return {'fonte_id': self._fonte_id, 'revisao': self._revisao,
                'confiavel': self._revisao_confiavel,
                'escopo': 'estado_local_guarda_retentativas'}

    def obter_revisao(self):
        with self._lock:
            return self._selo()

    def obter_evidencia_temporal(self):
        with self._lock:
            retrato = self._retrato_local()
            return self._selo() | {'retrato': retrato,
                'geracoes': [{'geracao_id': g.numero, 'modo_atual': modo}
                             for g, modo in self._geracoes.items()],
                'publicacoes_tentadas': [token.numero for token, item in self._secundarias.items()
                                        if item['publicacao_tentada']],
                'sequencia_identidades': self._sequencia,
                'dependencias_temporais_cobertas': False, 'snapshot_atomico': False,
                'cobertura_operacional': 'incompleta', 'encerramento_cliente_confirmado': False,
                'encerramento_global_confirmado': False}

    def _identidade(self, categoria):
        self._sequencia += 1
        return Identidade(self._origem, self._sequencia, categoria)

    def _buscar(self, tabela, identidade):
        # Aceita apenas os tokens emitidos, inclusive contra colisões de números.
        if type(identidade) is not Identidade or identidade.origem is not self._origem:
            raise ValueError("identidade_invalida")
        if identidade not in tabela:
            raise ValueError("identidade_invalida")
        return tabela[identidade]

    def nova_geracao_cliente(self):
        with self._publicacao_local():
            if self._fechada:
                return None
            identidade = self._identidade("geracao")
            self._geracoes[identidade] = "cliente"
            return identidade

    def promover(self, geracao):
        with self._publicacao_local():
            self._buscar(self._geracoes, geracao)
            self._geracoes[geracao] = "principal"
            # Mudança de papel não remove nem resolve reservas antigas.

    def reservar_retentativa(self, geracao):
        with self._publicacao_local():
            self._buscar(self._geracoes, geracao)
            if self._fechada:
                return None
            chave = self._identidade("retentativa")
            self._reservas[chave] = {
                "geracao": geracao, "fase": "admitida", "thread": None,
                "partida_em_curso": False, "partida_resolvida": False,
                "start_invocado": False, "entrada": False, "retorno": False,
                "thread_terminada": False, "ausencia_comprovada": False,
                "parada_solicitada": False, "erro": False,
                "partida_ambigua": False,
            }
            return chave

    def fechar_admissao(self):
        with self._publicacao_local():
            if self._fechada:
                return False
            self._fechada = True
            for item in self._reservas.values():
                item["parada_solicitada"] = True
            return True

    def parada_solicitada(self, chave):
        with self._lock:
            return self._buscar(self._reservas, chave)["parada_solicitada"]

    def partir(self, chave, fabrica_thread, rotina):
        """Tenta a partida uma vez. A fábrica recebe o alvo já rastreável.

        A thread concreta é criada pela fábrica injetada, fora do lock da guarda.
        Se start lançar, só entrada/retorno/término observado ou prova explícita
        de não execução podem resolver a incerteza. Não há join ou espera interna.
        """
        if not callable(fabrica_thread) or not callable(rotina):
            raise ValueError("executor_invalido")
        with self._publicacao_local():
            item = self._buscar(self._reservas, chave)
            if item["fase"] != "admitida" or item["ausencia_comprovada"]:
                return False
            if self._fechada:
                # A fábrica nem será chamada. Recursos secundários ainda contam.
                item["partida_resolvida"] = True
                item["ausencia_comprovada"] = True
                item["fase"] = "cancelada_antes_partida"
                return False
            item["fase"] = "iniciando"
            item["partida_em_curso"] = True

        def executar():
            try:
                if not self._publicar_entrada(chave):
                    return
            except BaseException as original:
                self._invalidar_saida_preservando(chave, original)
                raise
            try:
                rotina()
            except BaseException as original:
                try:
                    self._publicar_saida(chave, excepcional=True)
                except BaseException as publicacao:
                    self._invalidar_saida_preservando(chave, publicacao)
                    self._separar_falha(original, publicacao)
                raise
            else:
                try:
                    self._publicar_saida(chave, excepcional=False)
                except BaseException as original:
                    self._invalidar_saida_preservando(chave, original)
                    raise

        original_partida = None
        try:
            thread = fabrica_thread(executar)
            with self._publicacao_local():
                item = self._reservas[chave]
                item["thread"] = thread
                item["start_invocado"] = True
            thread.start()
        except BaseException as original:
            original_partida = original
            with self._publicacao_local(original):
                self._reservas[chave]["partida_ambigua"] = True
            raise
        finally:
            with self._publicacao_local(original_partida):
                item = self._reservas[chave]
                item["partida_em_curso"] = False
                item["partida_resolvida"] = True
        return True

    def _publicar_entrada(self, chave):
        with self._publicacao_local():
            atual = self._reservas[chave]
            if atual["entrada"] or atual["ausencia_comprovada"]:
                atual["erro"] = True
                return False
            atual["entrada"] = True
            atual["fase"] = "executando"
            return True

    def _publicar_saida(self, chave, *, excepcional):
        with self._publicacao_local():
            item = self._reservas[chave]
            if excepcional:
                item["erro"] = True
            item["retorno"] = True

    def _invalidar_saida(self, chave):
        with self._publicacao_local():
            self._temporal_comprometida = True
            item = self._reservas[chave]
            item["erro"] = True
            item["retorno"] = False

    def _invalidar_saida_preservando(self, chave, original):
        try:
            self._invalidar_saida(chave)
        except BaseException as adicional:
            # A propria invalidacao pode falhar antes de publicar qualquer flag.
            # O selo desconhecido nao depende de repetir o publicador que falhou.
            with self._lock:
                self._temporal_comprometida = True
                self._revisao_confiavel = False
            self._separar_falha(original, adicional)

    def comprovar_nao_execucao(self, chave, *, ausencia_comprovada):
        """Declaração do executor externo; nunca inferida de uma exceção.

        O provedor deve provar ausência de entrada futura, não só is_alive=False
        antes de start. Secundárias continuam exigindo comprovação separada.
        """
        if ausencia_comprovada is not True:
            raise ValueError("ausencia_nao_comprovada")
        with self._publicacao_local():
            item = self._buscar(self._reservas, chave)
            if item["partida_em_curso"] or item["entrada"]:
                return False
            item["ausencia_comprovada"] = True
            item["partida_resolvida"] = True
            item["fase"] = "cancelada_antes_partida"
            return True

    def observar_termino_thread(self, chave):
        with self._publicacao_local():
            item = self._buscar(self._reservas, chave)
            if (item["partida_em_curso"] or not item["partida_resolvida"]
                    or not item["entrada"] or not item["retorno"]):
                return False
            thread = item["thread"]
        try:
            viva = thread.is_alive()
            if type(viva) is not bool:
                raise ValueError("observacao_invalida")
        except Exception as original:
            with self._publicacao_local(original):
                self._reservas[chave]["erro"] = True
            return False
        with self._publicacao_local():
            item = self._reservas[chave]
            if viva:
                if item["thread_terminada"]:
                    item["erro"] = True
                return False
            item["thread_terminada"] = True
            return True

    def reservar_secundaria(self, chave, tipo):
        if tipo not in ("socket", "descoberta", "promocao", "operacao"):
            raise ValueError("tipo_invalido")
        with self._publicacao_local():
            item = self._buscar(self._reservas, chave)
            if (self._fechada or item["retorno"] or item["ausencia_comprovada"]
                    or item["erro"]):
                return None
            identidade = self._identidade("secundaria")
            self._secundarias[identidade] = {
                "retentativa": chave, "tipo": tipo, "resolvida": False,
                "publicacao_em_curso": False, "publicacao_tentada": False,
                "limpeza_em_curso": False, "erro": False,
            }
            return identidade

    def publicar_secundaria(self, identidade, registrar):
        """Exercita publicação externa com reserva prévia, sem criar sockets.

        Mesmo se registrar publicar e depois lançar, a reserva fica pendente.
        Depois do fechamento, não chama publicador ainda não iniciado.
        """
        if not callable(registrar):
            raise ValueError("publicador_invalido")
        with self._publicacao_local():
            item = self._buscar(self._secundarias, identidade)
            if (self._fechada or item["publicacao_tentada"] or item["resolvida"]
                    or item["limpeza_em_curso"]
                    or item["erro"]):
                return False
            item["publicacao_tentada"] = True
            item["publicacao_em_curso"] = True
        erro_publicacao = None
        try:
            registrar()
        except BaseException as original:
            erro_publicacao = original
            with self._publicacao_local(original):
                self._temporal_comprometida = True
                self._secundarias[identidade]["erro"] = True
            raise
        finally:
            with self._publicacao_local(erro_publicacao):
                self._secundarias[identidade]["publicacao_em_curso"] = False
        return True

    def resolver_secundaria(self, identidade, *, responsabilidades_resolvidas):
        if responsabilidades_resolvidas is not True:
            raise ValueError("liberacao_nao_comprovada")
        with self._publicacao_local():
            item = self._buscar(self._secundarias, identidade)
            if item["publicacao_em_curso"] or item["limpeza_em_curso"]:
                return False
            item["resolvida"] = True
            return True

    def finalizar_secundaria(self, identidade, limpar_e_comprovar):
        """Uma limpeza por vez; True deve atestar TODOS os efeitos resolvidos.

        Não implementa close/fileno nem uma segunda guarda de sockets. O provedor
        do ensaio é responsável por verificar o recurso e retornar prova estrita.
        """
        if not callable(limpar_e_comprovar):
            raise ValueError("limpeza_invalida")
        with self._publicacao_local():
            item = self._buscar(self._secundarias, identidade)
            if item["resolvida"] or item["publicacao_em_curso"] or item["limpeza_em_curso"]:
                return False
            item["limpeza_em_curso"] = True
        sucesso = False
        erro_limpeza = None
        try:
            comprovado = limpar_e_comprovar()
            if comprovado is not True:
                raise ValueError("limpeza_nao_comprovada")
            sucesso = True
        except BaseException as original:
            erro_limpeza = original
            with self._publicacao_local(original):
                self._secundarias[identidade]["erro"] = True
            raise
        finally:
            with self._publicacao_local(erro_limpeza):
                item = self._secundarias[identidade]
                item["limpeza_em_curso"] = False
                if sucesso:
                    item["resolvida"] = True
        return True

    def registrar_erro_limpeza(self, identidade):
        with self._publicacao_local():
            self._buscar(self._secundarias, identidade)["erro"] = True

    def _estado(self, chave, item):
        filhas = [s for s in self._secundarias.values() if s["retentativa"] == chave]
        if item["erro"] or any(s["erro"] for s in filhas):
            return "desconhecido"
        terminou = item["ausencia_comprovada"] or (
            item["entrada"] and item["retorno"] and item["thread_terminada"])
        if (terminou and item["partida_resolvida"] and not item["partida_em_curso"]
                and all(s["resolvida"] and not s["publicacao_em_curso"]
                        and not s["limpeza_em_curso"] for s in filhas)):
            return "encerramento_confirmado"
        if item["partida_ambigua"] and not item["entrada"] and not item["ausencia_comprovada"]:
            return "desconhecido"
        if item["parada_solicitada"]:
            return "parada_solicitada"
        return item["fase"] if item["fase"] in ("admitida", "iniciando", "executando") else "desconhecido"

    def obter_retrato(self):
        with self._lock:
            return self._retrato_local()

    def _retrato_local(self):
        reservas = []
        for chave, item in self._reservas.items():
            reservas.append({
                "id": chave.numero, "geracao": item["geracao"].numero,
                "modo_atual": self._geracoes[item["geracao"]],
                "estado": self._estado(chave, item),
                **{nome: item[nome] for nome in (
                    "partida_em_curso", "partida_resolvida", "start_invocado",
                    "entrada", "retorno", "thread_terminada", "ausencia_comprovada",
                    "parada_solicitada", "erro", "partida_ambigua")},
            })
        secundarias = [{"id": chave.numero, "retentativa": item["retentativa"].numero,
                        **{nome: item[nome] for nome in (
                            "tipo", "resolvida", "publicacao_em_curso", "limpeza_em_curso", "erro")}}
                       for chave, item in self._secundarias.items()]
        return {
            "admissao_fechada": self._fechada,
            "retentativas": reservas, "secundarias": secundarias,
            "conjunto_encerrado": self._fechada and all(
                item["estado"] == "encerramento_confirmado" for item in reservas),
        }

"""Consulta experimental; sem importação pelo fluxo operacional da aplicação.

Evidências limitadas aos servidores/coordenadores/trabalhadores do contrato atual.
Não comprova limpeza de sessões HTTP ou de recursos externos a esse contrato.
"""
from rede.servidor import ContextoCicloServidor, RegistroTentativasAplicacao


ERROS_RESERVA = {None, "sessao_invalida", "reserva_recusada", "falha_antes_reserva", "falha"}
ERROS_COORDENADOR = {None, "falha_execucao", "falha_limpeza"}
ERROS_PARTIDA = {"falha_partida", "falha_criacao_thread", "falha_start"}
PRE_RESERVA = {"sessao_invalida", "reserva_recusada", "falha_antes_reserva"}


def _contexto(contexto):
    if not isinstance(contexto, ContextoCicloServidor):
        raise ValueError("contexto_invalido")
    situacao = contexto.obter_situacao()
    campos = {"reserva_resolvida", "ciclo_id", "erro_reserva",
              "coordenador_retornou", "erro_coordenador"}
    if type(situacao) is not dict or set(situacao) != campos:
        raise ValueError("contexto_invalido")
    resolvida, ciclo, erro, retornou, falha = (
        situacao["reserva_resolvida"], situacao["ciclo_id"],
        situacao["erro_reserva"], situacao["coordenador_retornou"],
        situacao["erro_coordenador"],
    )
    if type(resolvida) is not bool or type(retornou) is not bool:
        raise ValueError("contexto_invalido")
    if ciclo is not None and (type(ciclo) is not int or ciclo <= 0):
        raise ValueError("contexto_invalido")
    if erro is not None and type(erro) is not str:
        raise ValueError("contexto_invalido")
    if falha is not None and type(falha) is not str:
        raise ValueError("contexto_invalido")
    if erro not in ERROS_RESERVA or falha not in ERROS_COORDENADOR:
        raise ValueError("contexto_invalido")
    if (not resolvida and (ciclo is not None or erro is not None or retornou or falha is not None)
            or ciclo is not None and erro is not None
            or not retornou and falha is not None):
        raise ValueError("contexto_inconsistente")
    return (resolvida, ciclo, erro, retornou, falha)


def _retrato(registro):
    retrato = registro.obter_retrato()
    if type(retrato) is not dict or set(retrato) != {"admissao_fechada", "tentativas"}:
        raise ValueError("retrato_invalido")
    if type(retrato["admissao_fechada"]) is not bool or type(retrato["tentativas"]) is not tuple:
        raise ValueError("retrato_invalido")
    return retrato["admissao_fechada"], retrato["tentativas"]


def _validar_identidades(tentativas):
    ids, contextos = set(), set()
    for tentativa in tentativas:
        chave = tentativa.tentativa_id
        if type(chave) is not int or chave <= 0 or chave in ids:
            raise ValueError("identidade_invalida")
        if id(tentativa.contexto) in contextos:
            raise ValueError("contexto_duplicado")
        ids.add(chave)
        contextos.add(id(tentativa.contexto))


def _classificar(tentativa, situacao, individual):
    estado = tentativa.estado_partida
    erro = tentativa.erro_partida
    observada = tentativa.execucao_observada
    if type(estado) is not str or type(observada) is not bool:
        raise ValueError("partida_invalida")
    if estado == "falha_partida":
        if observada or type(erro) is not str or erro not in ERROS_PARTIDA:
            raise ValueError("falha_partida_inconsistente")
        # O registro terminal real exige evidência de não execução. None é a
        # única ausência de contexto aceita; contexto fornecido deve ser válido.
        if situacao is not None:
            resolvida, ciclo, erro_reserva, retornou, erro_coordenador = situacao
            if ciclo is not None or retornou or erro_coordenador is not None:
                raise ValueError("falha_partida_inconsistente")
            if resolvida and erro_reserva != "falha_antes_reserva":
                raise ValueError("falha_partida_inconsistente")
        return "falhas_partida_confirmadas"
    if erro is not None or estado not in ("admitida", "iniciando", "iniciada"):
        raise ValueError("partida_inconsistente")
    if situacao is None:
        raise ValueError("contexto_ausente")
    resolvida, ciclo, erro_reserva, retornou, erro_coordenador = situacao
    if estado == "admitida" and (observada or ciclo is not None or retornou):
        raise ValueError("partida_inconsistente")
    if not observada and (ciclo is not None or retornou):
        raise ValueError("execucao_sem_evidencia")
    if type(individual) is not dict or set(individual) != {
        "ciclo_id", "estado", "encerramento_confirmado", "erro_reserva", "erro_coordenador"
    }:
        raise ValueError("avaliacao_invalida")
    if (type(individual["ciclo_id"]) is not type(ciclo)
            or individual["ciclo_id"] != ciclo
            or individual["erro_reserva"] != erro_reserva
            or individual["erro_coordenador"] != erro_coordenador):
        raise ValueError("avaliacao_divergente")
    estado_individual = individual["estado"]
    confirmado = individual["encerramento_confirmado"]
    esperado = {
        "confirmado": True, "reserva_pendente": False,
        "coordenador_executando": False, "trabalhadores_pendentes": False,
        "sem_ciclo": None, "desconhecido": None,
    }
    if type(estado_individual) is not str or estado_individual not in esperado:
        raise ValueError("avaliacao_invalida")
    if confirmado is not esperado[estado_individual]:
        raise ValueError("avaliacao_inconsistente")
    if estado_individual == "desconhecido":
        return "desconhecidas"
    if estado_individual == "reserva_pendente" and resolvida:
        raise ValueError("avaliacao_inconsistente")
    if estado_individual == "sem_ciclo" and (not resolvida or ciclo is not None):
        raise ValueError("avaliacao_inconsistente")
    if estado_individual in ("confirmado", "coordenador_executando", "trabalhadores_pendentes"):
        if not resolvida or ciclo is None:
            raise ValueError("avaliacao_inconsistente")
        if estado_individual == "coordenador_executando" and retornou:
            raise ValueError("avaliacao_inconsistente")
        if estado_individual != "coordenador_executando" and not retornou:
            raise ValueError("avaliacao_inconsistente")
    # A fotografia de partida prevalece: entrada observada não resolve start
    # ambíguo, nem um ciclo já limpo autoriza pular iniciando -> iniciada.
    if estado in ("admitida", "iniciando"):
        return "pendentes"
    if estado_individual == "confirmado":
        return "confirmadas"
    if estado_individual == "sem_ciclo":
        if not retornou:
            return "pendentes"
        # Antes da reserva o coordenador não cria workers. Erro genérico ou
        # de limpeza não demonstra ausência de efeitos operacionais pendentes.
        if observada and erro_reserva in PRE_RESERVA and erro_coordenador in (None, "falha_execucao"):
            return "confirmadas"
        return "desconhecidas"
    return "pendentes"


def avaliar_encerramento_aplicacao(registro, avaliar_tentativa):
    """Avalia um retrato e revalida fontes; não autoriza fechamento da janela.

    O registro real e o avaliador individual são autoridades das evidências.
    Falha comprovada cobre ausência de execução do servidor, não efeitos HTTP
    anteriores. Não consulta ciclo global nem executa espera, rede ou mutação.
    """
    resultado = dict(admissao_fechada=False, total_tentativas=0, confirmadas=0,
                     falhas_partida_confirmadas=0, pendentes=0, desconhecidas=0,
                     consistente=False, encerramento_confirmado=False)
    if not isinstance(registro, RegistroTentativasAplicacao) or not callable(avaliar_tentativa):
        return resultado
    try:
        fechado, tentativas = _retrato(registro)
    except Exception:
        return resultado
    resultado.update(admissao_fechada=fechado, total_tentativas=len(tentativas), consistente=True)
    try:
        _validar_identidades(tentativas)
    except Exception:
        resultado.update(desconhecidas=len(tentativas), consistente=False)
        return resultado
    situacoes = []
    ciclos = set()
    for tentativa in tentativas:
        situacoes.append(None)
        try:
            situacao = None if tentativa.contexto is None else _contexto(tentativa.contexto)
            situacoes[-1] = situacao
            if situacao is not None and situacao[1] is not None:
                if situacao[1] in ciclos:
                    raise ValueError("ciclo_duplicado")
                ciclos.add(situacao[1])
            individual = (None if tentativa.estado_partida == "falha_partida"
                          else avaliar_tentativa(tentativa.contexto))
            categoria = _classificar(tentativa, situacao, individual)
        except Exception:
            # Mantém uma categoria por tentativa, sem mensagens de exceção.
            categoria = "desconhecidas"
            resultado["consistente"] = False
        resultado[categoria] += 1
    try:
        fechado_final, finais = _retrato(registro)
        if fechado_final is not fechado or len(finais) != len(tentativas):
            raise ValueError("retrato_alterado")
        for tentativa, final, situacao in zip(tentativas, finais, situacoes, strict=True):
            if tentativa is not final:
                raise ValueError("partida_alterada")
            if tentativa.contexto is not None and _contexto(tentativa.contexto) != situacao:
                raise ValueError("contexto_alterado")
    except Exception:
        resultado.update(confirmadas=0, falhas_partida_confirmadas=0, pendentes=0,
                         desconhecidas=len(tentativas), consistente=False)
    resultado["encerramento_confirmado"] = (
        fechado and resultado["consistente"] and resultado["pendentes"] == 0
        and resultado["desconhecidas"] == 0
        and resultado["confirmadas"] + resultado["falhas_partida_confirmadas"] == len(tentativas)
    )
    return resultado

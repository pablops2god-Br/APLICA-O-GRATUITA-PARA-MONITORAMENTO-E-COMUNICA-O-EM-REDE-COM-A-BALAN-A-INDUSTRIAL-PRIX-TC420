"""Experimento sem ligação com main/Tk: manual explícito, automático proibido.

Callbacks de transporte/partida são contratos de ensaio, não adaptadores reais.
Uma integração deve executá-los em worker acompanhado por SaidaAplicacao.
"""
from threading import Lock

from rede.servidor import avaliar_encerramento_tentativa


def ciclo_resolvido(contexto):
    """Mesma exigência positiva usada na supervisão, incluindo retorno do dono."""
    situacao = contexto.obter_situacao()
    return (situacao['coordenador_retornou'] is True
            and avaliar_encerramento_tentativa(contexto)['encerramento_confirmado'] is True)


class RecuperacaoManual:
    """Estado local de ensaio; não garante exclusividade entre computadores.

    buscar retorna False (ausência), True (presença) ou None (incerto).
    fonte verifica autenticação/configuração/acesso atual sem iniciar servidor.
    preparar apenas cria contexto, sem IO/start; iniciar recebe esse contexto.
    pronto só retorna True com listeners e primeira leitura válida comprovados.
    Todos os contextos permanecem retidos, inclusive partidas que lançam exceção.
    """

    permitir_candidatura_automatica = False

    def __init__(self, contextos, *, buscar, fonte, preparar, iniciar, pronto,
                 vigente=lambda: True, avaliar=ciclo_resolvido):
        self._contextos = list(contextos)
        self._buscar, self._fonte = buscar, fonte
        self._preparar, self._iniciar, self._pronto = preparar, iniciar, pronto
        self._vigente, self._avaliar = vigente, avaliar
        self._lock = Lock()
        self._ocupada = False
        self._principal = False

    def _seguro(self):
        return (self._vigente() is True and bool(self._contextos)
                and all(self._avaliar(c) is True for c in self._contextos))

    def oferta_manual(self):
        # Oferta não executa rede e não autoriza por si só uma partida.
        with self._lock:
            if self._ocupada or self._principal:
                return False
            try:
                return self._seguro()
            except Exception:
                return False

    def solicitar_automatica(self):
        return 'automatica_desabilitada'

    def solicitar_manual(self):
        with self._lock:
            if self._ocupada or self._principal:
                return 'ocupada'
            self._ocupada = True
        try:
            if not self._seguro():
                return 'ciclo_pendente'
            ausente = self._buscar()
            if ausente is not False:
                return 'principal_detectado' if ausente is True else 'descoberta_incerta'
            if self._fonte() is not True:
                return 'fonte_indisponivel'
            # Revalida depois do login, que pode ter bloqueado por vários segundos.
            if not self._seguro():
                return 'ciclo_pendente'
            ausente = self._buscar()
            if ausente is not False:
                return 'principal_detectado' if ausente is True else 'descoberta_incerta'
            if not self._seguro():
                return 'ciclo_pendente'
            contexto = self._preparar()
            if contexto is None or any(contexto is c for c in self._contextos):
                return 'contexto_invalido'
            # Retenção precede start: exceção não autoriza perder a responsabilidade.
            with self._lock:
                self._contextos.append(contexto)
            if self._vigente() is not True:
                return 'cancelada_com_contexto_retido'
            self._iniciar(contexto)
            if self._pronto(contexto) is not True:
                return 'partida_pendente'
            if self._vigente() is not True:
                return 'cancelada_com_contexto_retido'
            with self._lock:
                self._principal = True
            return 'promovida'
        except Exception:
            # Não expõe credenciais/URLs nem transforma uma partida incerta em sucesso.
            return 'falha_sem_confirmacao'
        finally:
            with self._lock:
                self._ocupada = False

    def observar_rebaixamento(self):
        with self._lock:
            if self._ocupada:
                return False
            try:
                if not self._seguro():
                    return False
            except Exception:
                return False
            self._principal = False
            return True

"""Inventário de evidências experimental; não cria, encerra ou inspeciona recursos.

Somente o harness o utiliza. O lock protege metadados locais do protótipo; nenhum
lock ou callback é introduzido na aplicação. Provas são declarações do produtor,
não verificações automáticas do SO. Um retrato não impede criações futuras.
"""
from dataclasses import dataclass, replace
from threading import Lock


PROVAS_COMUNS = frozenset({"fechamento_retornou", "referencias_liberadas", "operacoes_encerradas"})
PROVAS_POR_TIPO = {
    nome: PROVAS_COMUNS for nome in (
        "tcp_escuta", "udp_descoberta", "tcp_cliente", "tcp_handler_socket",
        "tcp_balanca", "arquivo_socket", "http_requisicao", "web_tc420",
        "http_sessao_cliente",
    )
}
PROVAS_POR_TIPO.update(
    handler_thread=frozenset({"thread_terminou", "recursos_filhos_resolvidos"}),
    http_servidor=PROVAS_COMUNS | {"shutdown_retornou", "server_close_retornou", "thread_terminou"},
)


@dataclass(frozen=True)
class RecursoExperimental:
    recurso_id: int
    tipo: str
    ciclo_id: object
    tentativa_id: object
    proprietario: object
    hipotetico: bool = False
    fase: str = "reservada"
    estado: str = "desconhecido"
    erro_limpeza: bool = False
    provas: frozenset = frozenset()


class InventarioRecursosExperimental:
    def __init__(self):
        self._lock = Lock()
        self._recursos = {}
        self._ultimo_id = 0

    def reservar(self, tipo, *, ciclo_id=None, tentativa_id=None, proprietario=None, hipotetico=False):
        if type(tipo) is not str or tipo not in PROVAS_POR_TIPO:
            raise ValueError("tipo_invalido")
        if type(hipotetico) is not bool:
            raise ValueError("origem_invalida")
        for chave in (ciclo_id, tentativa_id):
            if chave is not None and (type(chave) is not int or chave <= 0):
                raise ValueError("identidade_invalida")
        if proprietario is not None and (type(proprietario) is not str or not proprietario):
            raise ValueError("proprietario_invalido")
        with self._lock:
            self._ultimo_id += 1
            chave = self._ultimo_id
            self._recursos[chave] = RecursoExperimental(
                chave, tipo, ciclo_id, tentativa_id, proprietario, hipotetico)
            return chave

    def _buscar(self, recurso_id):
        if type(recurso_id) is not int:
            return None
        return self._recursos.get(recurso_id)

    def publicar_criacao(self, recurso_id):
        with self._lock:
            recurso = self._buscar(recurso_id)
            if recurso is None or recurso.fase != "reservada":
                return False
            self._recursos[recurso_id] = replace(recurso, fase="criada", estado="ativo")
            return True

    def registrar_limpeza_solicitada(self, recurso_id):
        with self._lock:
            recurso = self._buscar(recurso_id)
            if recurso is None or recurso.fase != "criada" or recurso.estado == "encerramento_confirmado":
                return False
            self._recursos[recurso_id] = replace(
                recurso, estado="desconhecido" if recurso.erro_limpeza else "limpeza_solicitada")
            return True

    def registrar_erro_limpeza(self, recurso_id):
        with self._lock:
            recurso = self._buscar(recurso_id)
            if recurso is None or recurso.fase != "criada":
                return False
            self._recursos[recurso_id] = replace(recurso, estado="desconhecido", erro_limpeza=True)
            return True

    def registrar_falha_criacao(self, recurso_id):
        with self._lock:
            recurso = self._buscar(recurso_id)
            if recurso is None or recurso.fase != "reservada":
                return False
            # Não inventa um recurso criado/fechado. A reserva permanece pendente
            # até uma futura política de comprovação de ausência de efeitos.
            self._recursos[recurso_id] = replace(recurso, fase="falhou", estado="desconhecido")
            return True

    def registrar_evidencias(self, recurso_id, **provas):
        with self._lock:
            recurso = self._buscar(recurso_id)
            if recurso is None or recurso.fase != "criada" or recurso.erro_limpeza:
                return False
            exigidas = PROVAS_POR_TIPO[recurso.tipo]
            if not set(provas).issubset(exigidas) or any(type(v) is not bool for v in provas.values()):
                return False
            # Provas parciais/negativas não são combinadas com fotografias antigas.
            positivas = frozenset(nome for nome, valor in provas.items() if valor)
            dono = (recurso.proprietario is not None and recurso.ciclo_id is not None
                    and recurso.tentativa_id is not None)
            completo = dono and positivas == exigidas
            self._recursos[recurso_id] = replace(
                recurso, provas=positivas,
                estado="encerramento_confirmado" if completo else "desconhecido")
            return completo

    def obter_retrato(self):
        with self._lock:
            recursos = tuple(self._recursos.values())
            pendencias = tuple(r.recurso_id for r in recursos if r.estado != "encerramento_confirmado")
            return {
                "recursos": recursos,
                "pendencias": pendencias,
                "todos_recursos_observados_encerrados": not pendencias,
                "novas_criacoes_possiveis": True,
            }

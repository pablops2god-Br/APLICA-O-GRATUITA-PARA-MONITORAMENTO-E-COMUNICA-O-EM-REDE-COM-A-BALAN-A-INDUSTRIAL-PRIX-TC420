"""Registro experimental de operações HTTP, sem rede, recursos ou saída global.

O chamador fornece o proprietário existente. Retorno/erro publicado prova apenas
resolução da operação admitida; não fecha nem certifica Response, Session ou OS.
Tokens emitidos são imutáveis, locais à instância e validados por identidade.
"""
from dataclasses import dataclass, field
from threading import Lock


@dataclass(frozen=True, eq=False)
class ContextoHttpCliente:
    origem: object = field(repr=False)
    geracao_id: int
    atividade_id: int


@dataclass(frozen=True, eq=False)
class OperacaoHttpId:
    origem: object = field(repr=False)
    numero: int


@dataclass(frozen=True, eq=False)
class PublicacaoHttpId:
    origem: object = field(repr=False)
    numero: int


class RegistroOperacoesHttpCliente:
    OPERACOES = ("login", "approval")
    MOTIVOS = ("inicio_ambiguo", "falha_publicacao", "evidencia_insuficiente")

    def __init__(self, proprietario, aplicacao_id):
        if proprietario is None or type(aplicacao_id) is not str or not aplicacao_id:
            raise ValueError("proprietario_invalido")
        self._proprietario = proprietario
        self._aplicacao_id = aplicacao_id
        self._origem = object()
        self._lock = Lock()
        self._contextos = set()
        self._operacoes = {}
        self._publicacoes = {}
        self._publicadas = set()
        self._modos = {}
        self._sequencia = 0
        self._sequencia_publicacao = 0
        self._fechada = False

    @property
    def proprietario(self):
        return self._proprietario

    @property
    def aplicacao_id(self):
        return self._aplicacao_id

    @staticmethod
    def _validar_numero(numero):
        if type(numero) is not int or numero < 1:
            raise ValueError("identidade_invalida")

    @staticmethod
    def _erro(erro):
        if erro is None:
            return None
        if not isinstance(erro, BaseException):
            raise ValueError("erro_invalido")
        categoria = ("timeout" if isinstance(erro, TimeoutError) else
                     "falha_io" if isinstance(erro, OSError) else
                     "falha_operacao" if isinstance(erro, Exception) else "falha_base")
        return {"etapa": "operacao", "categoria": categoria}

    def _buscar(self, operacao_id):
        if (type(operacao_id) is not OperacaoHttpId or operacao_id.origem is not self._origem
                or operacao_id not in self._operacoes):
            raise ValueError("operacao_invalida")
        return self._operacoes[operacao_id]

    def criar_contexto(self, geracao_id, atividade_id):
        self._validar_numero(geracao_id)
        self._validar_numero(atividade_id)
        with self._lock:
            if self._fechada:
                return None
            contexto = ContextoHttpCliente(self._origem, geracao_id, atividade_id)
            self._contextos.add(contexto)
            self._modos.setdefault(geracao_id, "cliente")
            return contexto

    def admitir(self, contexto, operacao):
        if type(operacao) is not str or operacao not in self.OPERACOES:
            raise ValueError("operacao_http_invalida")
        with self._lock:
            if (type(contexto) is not ContextoHttpCliente or contexto.origem is not self._origem
                    or contexto not in self._contextos):
                raise ValueError("contexto_invalido")
            if self._fechada:
                return None
            self._sequencia += 1
            token = OperacaoHttpId(self._origem, self._sequencia)
            self._operacoes[token] = {
                "contexto": contexto, "operacao": operacao, "iniciada": False,
                "execucoes_ativas": 0, "original": None, "conflitos": [], "incertezas": [],
                "erros_execucao": [],
                "recibos": [],
            }
            return token

    def _iniciar(self, operacao_id, gerenciada):
        with self._lock:
            item = self._buscar(operacao_id)
            if item["iniciada"] or item["original"] is not None or item["incertezas"]:
                return False
            # Fechar admissão não cancela operação previamente aceita.
            item["iniciada"] = True
            item["execucoes_ativas"] = 1 if gerenciada else 0
            return True

    def iniciar(self, operacao_id):
        """Modo externo: o executor deve só publicar depois de realmente retornar."""
        return self._iniciar(operacao_id, False)

    def _preparar_sob_lock(self, operacao_id, resultado, erro, evidencia):
        self._sequencia_publicacao += 1
        publicacao = PublicacaoHttpId(self._origem, self._sequencia_publicacao)
        self._publicacoes[publicacao] = (operacao_id, {
            "publicacao_id": publicacao.numero, "resultado": resultado,
            "erro": erro, "evidencia": evidencia,
        })
        self._buscar(operacao_id)["recibos"].append(publicacao)
        return publicacao

    def preparar_publicacao(self, operacao_id, *, erro=None):
        """Recibo imutável: preparar não publica nem resolve a responsabilidade.

        Não armazena retorno, Response, mensagem ou objeto de exceção. Um recibo
        pode ser republicado idempotentemente; recibos distintos não são presumidos
        equivalentes, mesmo que tenham a mesma categoria sanitizada.
        """
        evidencia_erro = self._erro(erro)
        with self._lock:
            item = self._buscar(operacao_id)
            if not item["iniciada"]:
                raise ValueError("inicio_nao_comprovado")
            return self._preparar_sob_lock(
                operacao_id, "falha" if erro is not None else "retorno", evidencia_erro,
                "retorno_ou_falha_observado")

    def publicar(self, operacao_id, publicacao_id):
        with self._lock:
            item = self._buscar(operacao_id)
            if (type(publicacao_id) is not PublicacaoHttpId
                    or publicacao_id.origem is not self._origem
                    or publicacao_id not in self._publicacoes
                    or self._publicacoes[publicacao_id][0] is not operacao_id):
                raise ValueError("publicacao_invalida")
            self._publicadas.add(publicacao_id)
            if item["original"] is None:
                item["original"] = publicacao_id
            elif item["original"] is not publicacao_id:
                if publicacao_id not in item["conflitos"]:
                    item["conflitos"].append(publicacao_id)
                return False
            return not item["conflitos"] and not item["incertezas"]

    def comprovar_nao_inicio(self, operacao_id, *, nao_executada, erro=None):
        """Prova fornecida pelo executor: nenhuma execução passada ou futura.

        Exceção isolada ou is_alive=False não satisfaz esse contrato. Não resolve
        um início já ambíguo; não há recuperação automática de incertezas.
        """
        if nao_executada is not True:
            raise ValueError("nao_execucao_nao_comprovada")
        evidencia_erro = self._erro(erro)
        with self._lock:
            item = self._buscar(operacao_id)
            if item["iniciada"] or item["original"] is not None or item["incertezas"]:
                return False
            publicacao = self._preparar_sob_lock(
                operacao_id, "falha" if erro is not None else "nao_iniciada", evidencia_erro,
                "nao_execucao_comprovada")
            item["original"] = publicacao
            self._publicadas.add(publicacao)
            return True

    def marcar_desconhecida(self, operacao_id, *, motivo):
        if type(motivo) is not str or motivo not in self.MOTIVOS:
            raise ValueError("motivo_invalido")
        with self._lock:
            item = self._buscar(operacao_id)
            if motivo not in item["incertezas"]:
                item["incertezas"].append(motivo)

    def executar(self, operacao_id, chamada):
        """Executa uma vez, sem lock; devolve retorno ou relança o erro original.

        Falha de publicação deixa incerteza. Erro da chamada prevalece sobre erro
        de publicação; não representa limpeza de recursos internos da biblioteca.
        """
        if not callable(chamada):
            raise ValueError("chamada_invalida")
        if not self._iniciar(operacao_id, True):
            raise RuntimeError("operacao_nao_iniciavel")
        try:
            try:
                retorno = chamada()
            except BaseException as erro:
                evidencia_erro = self._erro(erro)
                with self._lock:
                    self._buscar(operacao_id)["erros_execucao"].append(evidencia_erro)
                try:
                    recibo = self.preparar_publicacao(operacao_id, erro=erro)
                    self.publicar(operacao_id, recibo)
                except BaseException:
                    self.marcar_desconhecida(operacao_id, motivo="falha_publicacao")
                raise
            else:
                try:
                    recibo = self.preparar_publicacao(operacao_id)
                    if not self.publicar(operacao_id, recibo):
                        raise RuntimeError("publicacao_conflitante")
                except BaseException:
                    self.marcar_desconhecida(operacao_id, motivo="falha_publicacao")
                    raise
                return retorno
        finally:
            with self._lock:
                self._buscar(operacao_id)["execucoes_ativas"] -= 1

    def promover(self, geracao_id):
        self._validar_numero(geracao_id)
        with self._lock:
            if geracao_id not in self._modos:
                raise ValueError("geracao_desconhecida")
            self._modos[geracao_id] = "principal"

    def fechar_admissao(self):
        with self._lock:
            if self._fechada:
                return False
            self._fechada = True
            return True

    def _evidencia(self, recibo):
        if recibo is None:
            return None
        dado = self._publicacoes[recibo][1]
        return {**dado, "erro": dado["erro"].copy() if dado["erro"] is not None else None}

    def obter_retrato(self):
        """Somente leitura, todas as gerações; sem prova de fechamento global."""
        with self._lock:
            operacoes = []
            for token, item in self._operacoes.items():
                original = self._evidencia(item["original"])
                desconhecida = bool(item["conflitos"] or item["incertezas"])
                pendentes = [r.numero for r in item["recibos"] if r not in self._publicadas]
                resolvida = (original is not None and not desconhecida
                             and not item["execucoes_ativas"] and not pendentes)
                estado = ("desconhecida" if desconhecida else "concluida" if resolvida else
                          "em_andamento" if item["iniciada"] else "reservada")
                contexto = item["contexto"]
                erro = (original["erro"] if original and original["erro"] else
                        item["erros_execucao"][0] if item["erros_execucao"] else None)
                operacoes.append({
                    "operacao_id": token.numero, "geracao_id": contexto.geracao_id,
                    "atividade_id": contexto.atividade_id, "operacao": item["operacao"],
                    "modo_atual": self._modos[contexto.geracao_id], "estado": estado,
                    "resultado": "desconhecido" if desconhecida else original["resultado"] if original else None,
                    "erro": erro.copy() if erro is not None else None,
                    "publicacao_pendente": not resolvida, "execucao_resolvida": resolvida,
                    "publicacoes_pendentes": pendentes,
                    "inicio_confirmado": item["iniciada"], "execucoes_ativas": item["execucoes_ativas"],
                    "publicacao_original": original,
                    "conflitos_publicacao": [self._evidencia(r) for r in item["conflitos"]],
                    "incertezas": list(item["incertezas"]),
                    "erros_execucao": [e.copy() for e in item["erros_execucao"]],
                })
            resolvidas = all(o["execucao_resolvida"] for o in operacoes)
            return {
                "aplicacao_id": self._aplicacao_id, "admissao_fechada": self._fechada,
                "operacoes": operacoes, "operacoes_resolvidas": resolvidas,
                "conjunto_http_resolvido": self._fechada and resolvidas,
                "cobertura_operacional": "incompleta", "encerramento_global_confirmado": False,
            }

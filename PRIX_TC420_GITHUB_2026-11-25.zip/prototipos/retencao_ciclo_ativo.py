"""Estudo 2B.5. Nenhum módulo operacional importa este arquivo."""
from dataclasses import dataclass, replace
from rede.servidor import RegistroTrabalhadores


@dataclass(frozen=True, slots=True)
class SemRecursoMinimo:
    """A: token original e flag variável; constantes compartilhadas na classe.

    Não substitui entradas operacionais pendentes. Não preserva introspecção
    privada de todos os campos como dataclass, apenas atributos consultados.
    """
    reserva: object
    resultado_limpeza_handler_publicado: bool = False
    estado = 'sem_recurso'
    recurso = None
    em_uso = False
    erro = None
    limpeza_handler_pendente = False
    erro_fechamento_handler = None


class RegistroSeparacaoExperimental(RegistroTrabalhadores):
    """B: retirar referência a recurso fechado, sem retirar identidade/histórico.

    Interface experimental explícita; não acionada em produção.
    Preserva todas as threads, incluindo starts ambíguos.
    """
    def separar_recursos_resolvidos(self):
        quantidade = 0
        with self.lock:
            for numero, e in self._reservas_socket.items():
                if (e.estado == 'fechada' and not e.em_uso and e.erro is None
                        and not e.limpeza_handler_pendente
                        and e.erro_fechamento_handler is None and e.recurso is not None):
                    self._reservas_socket[numero] = replace(e, recurso=None)
                    quantidade += 1
        return quantidade

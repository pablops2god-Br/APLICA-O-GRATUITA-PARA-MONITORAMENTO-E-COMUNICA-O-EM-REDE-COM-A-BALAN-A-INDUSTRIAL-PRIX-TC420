"""Diagnóstico explícito do EXE; sem rede, cofre ou configuração reais."""
import json
import os
from pathlib import Path
import secrets
import sys
import tempfile
import time
import tkinter as tk
from unittest.mock import patch


def executar(relatorio):
    resultado = dict(aprovado=False, empacotado=bool(getattr(sys, 'frozen', False)))
    destino = Path(relatorio)
    etapa = 'dependencias'
    try:
        import keyring.backends.Windows
        from config import administrador as armazenamento
        from config.caminhos import pasta_dados, pasta_logs
        from interface.conexao import JanelaConexao
        from interface import administrador as ui
        from interface.saida_aplicacao import SaidaAplicacao
        from interface.registro_terminal import instalar_registro_terminal, obter_texto_terminal
        from rede.servidor import RegistroTentativasAplicacao
        with tempfile.TemporaryDirectory() as pasta, \
             patch.dict(os.environ, {'LOCALAPPDATA': pasta}), \
             patch('config.configuracao.obter_caminho_configuracao', return_value=str(Path(pasta)/'configuracao.json')), \
             patch('socket.socket', side_effect=AssertionError('rede proibida')) as rede, \
             patch('keyring.get_password', side_effect=AssertionError('cofre proibido')) as cofre:
            instalar_registro_terminal()
            etapa = 'terminal_sem_console'
            print('AUTOTESTE: terminal sem console funcional.')
            assert 'terminal sem console funcional' in obter_texto_terminal()
            senha = secrets.token_urlsafe(16)
            etapa = 'persistencia_temporaria'
            armazenamento.cadastrar(senha)
            assert armazenamento.verificar(senha)
            saida = SaidaAplicacao()
            saida.configurar(registro=RegistroTentativasAplicacao())
            reaberturas = []
            saida.ao_reconfigurar = lambda: reaberturas.append(True)
            controle = ui.ControleAdministrador()
            controle.autorizado = True
            ui._controle = controle
            app = JanelaConexao(saida_aplicacao=saida)
            etapa = 'monitor_e_assets'
            erros = []
            app.root.report_callback_exception = lambda *args: erros.append(type(args[1]).__name__)
            class Leitor:
                thread = None
                parado = False
                def parar(self): self.parado = True
                def obter_dados_atuais(self):
                    return dict(peso_liquido='0', tara='—', unidade='kg', estado='TCP', multirange='—')
                def comunicacao_esta_atual(self): return True
                def registrar_diagnostico(self, _estado): pass
            leitor = Leitor()
            saida.acompanhar_leitor(leitor)
            with patch('interface.notificacoes.notificar_estado'):
                app.abrir_monitor_tcp_local(leitor)
                app.monitor.root.deiconify()
                app.root.update()
                app.root.update_idletasks()
                assert app.monitor.label_atualizacao.winfo_ismapped()
                assert app.root.logo_widget.winfo_exists()
                app.monitor.menu_opcoes.invoke('Reconfigurar')
                etapa = 'login_administrativo'
                limite = time.monotonic()+10
                while controle.tela.botao.cget('state') != 'normal' and time.monotonic()<limite:
                    app.root.update()
                    time.sleep(.01)
                controle.tela.senha.insert(0, senha)
                controle.tela.botao.invoke()
                etapa = 'encerramento_b2'
                while not reaberturas and time.monotonic()<limite:
                    app.root.update()
                    time.sleep(.01)
            assert reaberturas == [True]
            assert saida.obter_situacao()['parada_operacional_confirmada'] and leitor.parado
            assert not erros, erros
            rede.assert_not_called()
            cofre.assert_not_called()
            etapa = 'concluido'
            resultado.update(aprovado=True, tkinter=tk.TkVersion,
                             backend_windows_importado=True, assets=True, administrador=True,
                             monitor=True, data_hora=True, saida_b2=True,
                             pasta_dados=str(pasta_dados()), pasta_logs=str(pasta_dados()/'logs'))
    except Exception as erro:
        # Não transcrever traceback/locals potencialmente sensíveis.
        resultado['erro'] = type(erro).__name__
        resultado['etapa'] = etapa
        import traceback
        resultado['linha_diagnostico'] = traceback.extract_tb(erro.__traceback__)[-1].lineno
    finally:
        destino.write_text(json.dumps(resultado, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    if not resultado['aprovado']:
        raise SystemExit(1)

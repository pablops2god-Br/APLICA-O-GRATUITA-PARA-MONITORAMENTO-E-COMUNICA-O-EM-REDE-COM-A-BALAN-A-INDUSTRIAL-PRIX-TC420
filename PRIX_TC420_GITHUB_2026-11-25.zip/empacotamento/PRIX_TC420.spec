# Executar da raiz: .venv-build/Scripts/python -m PyInstaller empacotamento/PRIX_TC420.spec
from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules, copy_metadata

raiz = Path(SPECPATH).parent
dados = [(str(p), 'assets') for p in (raiz / 'assets').glob('*.png')]
dados += copy_metadata('keyring', recursive=True)
a = Analysis(
    [str(raiz / 'main.py')], pathex=[str(raiz)], binaries=[], datas=dados,
    hiddenimports=collect_submodules('keyring.backends') + collect_submodules('win32ctypes'),
    hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=['PIL'], noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [], exclude_binaries=True, name='PRIX_TC420',
    debug=False, bootloader_ignore_signals=False, strip=False, upx=False,
    console=False, disable_windowed_traceback=False,
    icon=str(raiz / 'empacotamento' / 'icone.ico'),
    version=str(raiz / 'empacotamento' / 'version_info.txt'),
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='PRIX_TC420')

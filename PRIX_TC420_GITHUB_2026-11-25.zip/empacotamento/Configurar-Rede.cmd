@echo off
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Rede-PRIX-TC420.ps1" -Acao Configurar -PerguntarPerfil
if errorlevel 1 echo A configuracao nao foi concluida.
pause

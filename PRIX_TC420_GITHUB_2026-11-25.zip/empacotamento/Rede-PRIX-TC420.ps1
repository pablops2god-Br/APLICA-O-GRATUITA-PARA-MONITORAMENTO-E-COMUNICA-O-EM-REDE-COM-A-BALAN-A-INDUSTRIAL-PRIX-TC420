[CmdletBinding()]
param(
    [ValidateSet('Configurar', 'Remover')][string]$Acao = 'Configurar',
    [string]$Executavel = '',
    [switch]$IncluirPublica,
    [switch]$PerguntarPerfil,
    [switch]$Simular
)
$ErrorActionPreference = 'Stop'
try {
    if (-not $Executavel) { $Executavel = Join-Path $PSScriptRoot 'PRIX_TC420.exe' }
    $arquivoPrix = (Resolve-Path -LiteralPath $Executavel).ProviderPath
    if ([IO.Path]::GetFileName($arquivoPrix) -ne 'PRIX_TC420.exe') {
        throw 'Selecione o PRIX_TC420.exe desta distribuicao.'
    }
    if ($PerguntarPerfil -and $Acao -eq 'Configurar' -and -not $Simular) {
        Write-Host 'A rede PRIVADA sera autorizada para este aplicativo na sub-rede local.'
        $respostaPrix = Read-Host 'Autorizar tambem rede PUBLICA? [S/N] (padrao N)'
        $IncluirPublica = $respostaPrix -match '^[sS]$'
    }
    $perfisPrix = @('Private')
    if ($IncluirPublica) { $perfisPrix += 'Public' }
    $shaPrix = [Security.Cryptography.SHA256]::Create()
    try {
        $hashPrix = [BitConverter]::ToString($shaPrix.ComputeHash(
            [Text.Encoding]::UTF8.GetBytes($arquivoPrix.ToUpperInvariant()))).Replace('-', '').Substring(0, 16)
    } finally { $shaPrix.Dispose() }
    $regrasPrix = @(
        @{ Name = "PRIX_TC420-$hashPrix-TCP"; DisplayName = 'PRIX TC420 - dados TCP'; Protocol = 'TCP'; LocalPort = 42100 },
        @{ Name = "PRIX_TC420-$hashPrix-UDP"; DisplayName = 'PRIX TC420 - descoberta UDP'; Protocol = 'UDP'; LocalPort = 42101 }
    )
    if ($Simular) {
        [pscustomobject]@{ Acao = $Acao; Executavel = $arquivoPrix; Perfis = $perfisPrix;
            Direcao = 'Inbound'; Remotos = 'LocalSubnet'; Regras = $regrasPrix } | ConvertTo-Json -Depth 5
        exit 0
    }
    $identidadePrix = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principalPrix = New-Object Security.Principal.WindowsPrincipal($identidadePrix)
    if (-not $principalPrix.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        $argumentosPrix = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'),
            '-Acao', $Acao, '-Executavel', ('"' + $arquivoPrix + '"'))
        if ($IncluirPublica) { $argumentosPrix += '-IncluirPublica' }
        $processoPrix = Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" `
            -ArgumentList $argumentosPrix -Verb RunAs -WindowStyle Hidden -PassThru -Wait
        if ($processoPrix.ExitCode -ne 0) { throw 'Operacao recusada ou falhou. Consulte o administrador da rede.' }
        Write-Host 'Operacao de firewall concluida.'
        exit 0
    }
    foreach ($regraPrix in $regrasPrix) {
        $existentePrix = Get-NetFirewallRule -Name $regraPrix.Name -PolicyStore PersistentStore -ErrorAction SilentlyContinue
        if ($existentePrix -and $existentePrix.Group -ne 'PRIX TC420') {
            throw 'Nome de regra existente pertence a outro grupo; nenhuma substituicao autorizada.'
        }
        if ($Acao -eq 'Remover') {
            if ($existentePrix) { Remove-NetFirewallRule -Name $regraPrix.Name -PolicyStore PersistentStore }
        } else {
            $parametrosPrix = @{
                Name = $regraPrix.Name; DisplayName = $regraPrix.DisplayName; Group = 'PRIX TC420';
                Program = $arquivoPrix; Direction = 'Inbound'; Action = 'Allow'; Enabled = 'True';
                Profile = $perfisPrix; Protocol = $regraPrix.Protocol; LocalPort = $regraPrix.LocalPort;
                RemoteAddress = 'LocalSubnet'; EdgeTraversalPolicy = 'Block'; PolicyStore = 'PersistentStore'
            }
            if ($existentePrix) {
                $parametrosPrix.Remove('DisplayName')
                $parametrosPrix.Remove('Group')
                $parametrosPrix['NewDisplayName'] = $regraPrix.DisplayName
                Set-NetFirewallRule @parametrosPrix
            }
            else { New-NetFirewallRule @parametrosPrix | Out-Null }
        }
    }
    Write-Host ('Firewall: ' + $Acao + ' concluido para ' + $arquivoPrix)
    exit 0
} catch {
    Write-Host ('Falha: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}

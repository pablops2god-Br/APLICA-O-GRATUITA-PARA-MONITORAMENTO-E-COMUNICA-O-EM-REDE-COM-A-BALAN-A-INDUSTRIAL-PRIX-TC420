@echo off
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Rede-PRIX-TC420.ps1" -Acao Remover
if errorlevel 1 echo A remocao nao foi concluida.
pause

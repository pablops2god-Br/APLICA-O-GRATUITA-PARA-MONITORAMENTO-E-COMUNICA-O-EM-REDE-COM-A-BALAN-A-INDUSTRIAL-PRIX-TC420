"""Ferramentas de empacotamento e diagnóstico offline da distribuição."""

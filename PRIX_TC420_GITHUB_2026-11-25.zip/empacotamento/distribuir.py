"""Produz ZIP e manifesto apenas a partir da pasta gerada pelo PyInstaller."""
import hashlib
import json
from pathlib import Path
import platform
import shutil
from zipfile import ZipFile, ZIP_DEFLATED


def executar():
    raiz = Path(__file__).resolve().parents[1]
    pacote = raiz / 'dist' / 'PRIX_TC420'
    if not (pacote / 'PRIX_TC420.exe').is_file():
        raise RuntimeError('executavel_ausente')
    shutil.copyfile(raiz/'empacotamento/LEIA-ME.txt', pacote/'LEIA-ME.txt')
    for nome_rede in ('Rede-PRIX-TC420.ps1', 'Configurar-Rede.cmd', 'Remover-Permissoes-Rede.cmd'):
        shutil.copyfile(raiz/'empacotamento'/nome_rede, pacote/nome_rede)
    informacoes = dict(versao='0.0.1', arquitetura='Windows x64',
                       python=platform.python_version(), assinatura_digital=False,
                       formato='onedir', instalador=False, log_automatico=False, firewall_manual=True)
    (pacote/'VERSAO.json').write_text(json.dumps(informacoes, indent=2)+'\n', encoding='utf-8')
    arquivos = sorted(p for p in pacote.rglob('*') if p.is_file())
    for p in arquivos:
        if p.name.lower() in ('configuracao.json', 'administrador.json'):
            raise RuntimeError('dados_operacionais_na_distribuicao')
    manifesto = {p.relative_to(pacote).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in arquivos}
    nome = 'PRIX_TC420_0.0.1_Windows_x64'
    arquivo_zip = raiz / 'dist' / (nome+'.zip')
    with ZipFile(arquivo_zip, 'w', ZIP_DEFLATED) as z:
        for p in arquivos:
            z.write(p, p.relative_to(pacote.parent))
    with ZipFile(arquivo_zip) as z:
        if z.testzip() is not None:
            raise RuntimeError('zip_invalido')
    saida = dict(arquivos=manifesto, zip_sha256=hashlib.sha256(arquivo_zip.read_bytes()).hexdigest())
    (raiz/'dist'/(nome+'.sha256.json')).write_text(json.dumps(saida,indent=2)+'\n',encoding='utf-8')
    print('Distribuicao gerada:', arquivo_zip.name)


if __name__ == '__main__':
    executar()

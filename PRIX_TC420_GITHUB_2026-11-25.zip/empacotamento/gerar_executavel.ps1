$ErrorActionPreference = 'Stop'
$raizPrix = Split-Path -Parent $PSScriptRoot
Push-Location $raizPrix
try {
    $pythonPrix = Join-Path $raizPrix '.venv-build\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $pythonPrix)) {
        python -m venv .venv-build
        if ($LASTEXITCODE -ne 0) { throw 'Falha ao criar ambiente de build.' }
    }
    & $pythonPrix -m pip install -r empacotamento/requirements-build.lock.txt
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao instalar dependencias.' }
    & $pythonPrix -m PyInstaller --noconfirm empacotamento/PRIX_TC420.spec
    if ($LASTEXITCODE -ne 0) { throw 'Falha no PyInstaller.' }
    & $pythonPrix empacotamento/distribuir.py
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao gerar ZIP.' }
    Write-Host 'Executavel: dist\PRIX_TC420\PRIX_TC420.exe'
} finally {
    Pop-Location
}

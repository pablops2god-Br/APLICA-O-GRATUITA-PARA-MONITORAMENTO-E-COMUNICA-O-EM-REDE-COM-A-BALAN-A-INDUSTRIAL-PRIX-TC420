# Mensagem de login: reutiliza o tratamento de erros HTTP para apresentação na interface.
"""Adaptador visual compatível com a política neutra de mensagens HTTP."""

from mensagens_seguras import mensagem_erro_http


def mensagem_erro_login(erro):
    """Preserva as mensagens e a assinatura usadas pela janela de conexão."""
    from rede.tcp_local import ErroTCPLocal
    if type(erro) is ErroTCPLocal:
        return ErroTCPLocal.MENSAGENS.get(erro.codigo, ErroTCPLocal.MENSAGENS['sem_frame'])
    return mensagem_erro_http(erro)

"""Espelho limitado do terminal; nenhuma gravação automática em disco."""
from collections import deque
import re
from threading import RLock
import sys


LIMITE_LINHAS = 5_000
LIMITE_CARACTERES = 1_000_000
TAMANHO_BLOCO = 4_096


class _SanitizadorTerminal:
    """Oculta valores rotulados, inclusive divididos entre writes.

    Só guarda cauda já sanitizada. A origem ainda deve impedir emissão de
    segredos sem rótulo; este filtro não identifica arbitrariamente uma senha.
    """
    _rotulo = re.compile(
        r"\b(?:senha|password|passwd|pwd|token|access_token|refresh_token|"
        r"authorization|api[_-]?key|cookie|set-cookie)[\"']?[ \t]*[:=][ \t]*",
        re.IGNORECASE)

    def __init__(self):
        self._cauda = ''
        self._ocultando = False

    def processar(self, texto):
        saida = []
        indice = 0
        while indice < len(texto):
            if self._ocultando:
                fim = indice
                # Ocultar até LF também protege valores com espaços, & e outros separadores.
                while fim < len(texto) and texto[fim] != '\n':
                    fim += 1
                if fim == len(texto):
                    break
                saida.append(texto[fim])
                indice = fim + 1
                self._ocultando = False
            else:
                prefixo = (self._cauda + ''.join(saida))[-128:]
                combinado = prefixo + texto[indice:]
                achado = next((m for m in self._rotulo.finditer(combinado)
                               if m.end() > len(prefixo)), None)
                if achado is None:
                    saida.append(texto[indice:])
                    break
                consumido = achado.end() - len(prefixo)
                saida.append(texto[indice:indice + consumido])
                saida.append('[OCULTO]')
                indice += consumido
                self._ocultando = True
        resultado = ''.join(saida)
        self._cauda = (self._cauda + resultado)[-128:]
        return resultado


class _RegistroTerminal:
    """Blocos coalescidos evitam reter um objeto para cada write de um caractere."""
    def __init__(self, *, limite_linhas=LIMITE_LINHAS, limite_caracteres=LIMITE_CARACTERES):
        if (type(limite_linhas) is not int or limite_linhas < 1
                or type(limite_caracteres) is not int or limite_caracteres < 1):
            raise ValueError('limites_terminal_invalidos')
        self._lock = RLock()
        self._blocos = deque()
        self._limite_linhas = limite_linhas
        self._limite_caracteres = limite_caracteres
        self._caracteres = self._quebras = 0
        self._caracteres_descartados = self._linhas_descartadas = 0
        self._sanitizador = _SanitizadorTerminal()

    def _linhas(self):
        # Linha parcial conta; um LF final não cria outra linha vazia.
        return self._quebras + bool(self._caracteres and not self._blocos[-1].endswith('\n'))

    def _remover(self, quantidade):
        while quantidade:
            bloco = self._blocos.popleft()
            cortar = min(quantidade, len(bloco))
            retirado = bloco[:cortar]
            if cortar < len(bloco):
                self._blocos.appendleft(bloco[cortar:])
            quebras = retirado.count('\n')
            self._quebras -= quebras
            self._caracteres -= cortar
            self._caracteres_descartados += cortar
            # Corte parcial só soma caracteres; LF descartado encerra uma linha.
            self._linhas_descartadas += quebras
            quantidade -= cortar

    def _limitar(self):
        excesso = self._caracteres - self._limite_caracteres
        if excesso > 0:
            self._remover(excesso)
        while self._linhas() > self._limite_linhas:
            bloco = self._blocos[0]
            quebra = bloco.find('\n')
            self._remover(len(bloco) if quebra < 0 else quebra + 1)

    def acrescentar(self, texto):
        if not isinstance(texto, str):
            raise TypeError('texto_terminal_deve_ser_str')
        with self._lock:
            for inicio in range(0, len(texto), TAMANHO_BLOCO):
                parte = self._sanitizador.processar(texto[inicio:inicio + TAMANHO_BLOCO])
                if not parte:
                    continue
                self._caracteres += len(parte)
                self._quebras += parte.count('\n')
                while parte:
                    if self._blocos and len(self._blocos[-1]) < TAMANHO_BLOCO:
                        livre = TAMANHO_BLOCO - len(self._blocos[-1])
                        self._blocos[-1] += parte[:livre]
                        parte = parte[livre:]
                    else:
                        self._blocos.append(parte[:TAMANHO_BLOCO])
                        parte = parte[TAMANHO_BLOCO:]
                self._limitar()
                # O contexto do filtro também não conserva texto já expulso da retenção.
                cauda = self._blocos[-1][-128:] if self._blocos else ''
                if len(cauda) < 128 and len(self._blocos) > 1:
                    cauda = self._blocos[-2][-(128 - len(cauda)):] + cauda
                self._sanitizador._cauda = cauda

    def obter_texto(self):
        """API anterior: texto sanitizado ainda retido, sem cabeçalho adicional."""
        with self._lock:
            return ''.join(self._blocos)

    def obter_situacao(self):
        with self._lock:
            return dict(limite_linhas=self._limite_linhas,
                        limite_caracteres=self._limite_caracteres,
                        linhas_retidas=self._linhas(), caracteres_retidos=self._caracteres,
                        blocos_retidos=len(self._blocos),
                        linhas_descartadas=self._linhas_descartadas,
                        caracteres_descartados=self._caracteres_descartados,
                        parcial=self._caracteres_descartados > 0)

    def obter_exportacao(self):
        """Texto e contadores do mesmo instante; aviso não ocupa o histórico."""
        with self._lock:
            situacao = self.obter_situacao()
            texto = ''.join(self._blocos)
        if situacao['parcial']:
            texto = (
                '[PRIX TC420 — HISTÓRICO PARCIAL]\n'
                'Somente o trecho ainda retido está disponível; conteúdo antigo não pode ser recuperado.\n'
                f"Descartados por retenção: {situacao['linhas_descartadas']} linhas encerradas por LF "
                f"e {situacao['caracteres_descartados']} caracteres.\n"
                'Um corte parcial de linha é contabilizado somente em caracteres.\n'
                f"Limites: {situacao['limite_linhas']} linhas e {situacao['limite_caracteres']} caracteres.\n\n"
            ) + texto
        return dict(texto=texto, **situacao)


# Encaminha as escritas ao terminal original e ao registro usado na exportação.
class _SaidaSemConsole:
    """Sink sem buffer: o EXE windowed não possui stdout/stderr do console."""
    encoding = 'utf-8'
    errors = 'replace'
    def write(self, texto):
        return len(texto)
    def flush(self):
        pass
    def isatty(self):
        return False


class _SaidaEspelhada:
    # Conserva o stream original e o registro compartilhado que receberão as próximas escritas.
    def __init__(self, original, registro):
        self.original = original if original is not None else _SaidaSemConsole()
        self.registro = registro

    # Escreve primeiro na saída original e depois conserva o mesmo trecho no espelho.
    def write(self, texto):
        resultado = self.original.write(texto)
        self.registro.acrescentar(texto)
        return resultado

    # Preserva o comportamento de descarga da saída original.
    def flush(self):
        return self.original.flush()

    # Delega os demais atributos ao stream original para manter compatibilidade com seus consumidores.
    def __getattr__(self, nome):
        return getattr(self.original, nome)


_registro = _RegistroTerminal()
_instalado = False
_lock_instalacao = RLock()


# Substitui stdout/stderr por espelhos uma única vez, preservando os streams originais.
def instalar_registro_terminal():
    global _instalado
    with _lock_instalacao:
        if not _instalado:
            sys.stdout = _SaidaEspelhada(sys.stdout, _registro)
            sys.stderr = _SaidaEspelhada(sys.stderr, _registro)
            _instalado = True
    return _registro


# Expõe somente o trecho ainda retido, sem ler arquivos de log.
def obter_texto_terminal():
    return _registro.obter_texto()


def obter_exportacao_terminal():
    return _registro.obter_exportacao()

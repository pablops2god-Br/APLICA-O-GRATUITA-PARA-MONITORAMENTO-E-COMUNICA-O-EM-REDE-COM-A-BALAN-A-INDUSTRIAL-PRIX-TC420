# Monitor: apresentação de pesos, saúde, candidatura e comandos do operador.
import tkinter as tk
from datetime import datetime
from tkinter import filedialog, messagebox
import threading
import sys
from pathlib import Path
from typing import Any, Callable, Mapping, Optional

from tc420.conexao import ConexaoTC420
from tc420.protocolo import interpretar_peso


COR_FUNDO_MONITOR = "#8FD33F"
COR_FUNDO_MONITOR_ATIVA = "#7FC72F"


# Resolve imagens tanto na árvore do projeto quanto no diretório temporário usado pelo empacotador.
def _caminho_asset(nome: str) -> str:
    """Resolve assets na raiz e também no diretório temporário do empacotador."""
    raiz = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))
    return str(raiz / "assets" / nome)


# Consulta a saúde compartilhada pelo servidor local sem fazer uma requisição HTTP.
def _saude_principal_padrao():
    from rede.servidor import obter_saude_tc420
    return obter_saude_tc420()


# Apresenta a fonte de dados selecionada e coordena menu, estados visuais e interação de promoção.
class JanelaTC420:
    # Monta o monitor, as faixas metrológicas e os callbacks; a fonte injetada permite observar principal ou cliente.
    def __init__(
        self,
        web=None,
        configuracao=None,
        fonte_dados: Optional[Callable[[], Mapping[str, Any]]] = None,
        comunicacao_atual=None,
        candidatura_liberada=None,
        estado_candidatura=None,
        ao_promover=None,
        ao_promover_automaticamente=None,
        obter_saude_principal=None,
        servidor_encerrado=None,
        ao_reconfigurar=None,
        master=None,
        ao_fechar=None,
    ):
        self.web = web
        self.configuracao = configuracao
        self.fonte_dados = fonte_dados
        self.comunicacao_atual = comunicacao_atual
        self.candidatura_liberada = candidatura_liberada
        self.estado_candidatura = estado_candidatura
        self.ao_promover = ao_promover
        self.ao_promover_automaticamente = ao_promover_automaticamente
        self.obter_saude_principal = (
            obter_saude_principal
            if obter_saude_principal is not None
            else (_saude_principal_padrao if web is not None else None)
        )
        self.servidor_encerrado = servidor_encerrado
        self.ao_reconfigurar = ao_reconfigurar
        self.reconfiguracao_solicitada = False
        self.modo_monitor = "principal" if web is not None else "cliente"
        self.promocao_em_andamento = False
        self.contexto_promocao_atual = None
        self.contextos_promocao = []
        self.ciclo_servidor_id = None
        self.candidatura_detectada = False
        self.janela_promocao = None
        self.comunicacao_confirmada = False
        self._estado_status = None
        self._indice_status = 0
        self._token_status = 0
        self.saida_aplicacao = None
        self.infraestrutura_cliente = None
        self._ciclo_tk = None
        self._supervisao_principal = None
        self._contextos_supervisionados = []

        # Sem master, a janela é a principal (modo CLIENTE):
        # ela cria e passa a ser dona do próprio Tk.
        # Com master, ela é embutida (modo PRINCIPAL) e vira
        # uma Toplevel da JanelaConexao.
        self.master = master
        self.dona_root = master is None
        self.ao_fechar = ao_fechar

        if self.dona_root:
            self.root = tk.Tk()
        else:
            self.root = tk.Toplevel(master)

        self.root.title("PRIX TC420 - Monitor")
        self.root.geometry("620x300")
        self.root.resizable(False, False)
        self.root.configure(bg="#B6B6B6")

        self.balanca = ConexaoTC420()
        self.executando = True

        # Cabe?alho conserva os widgets para atualizar faixas ap?s troca de fonte.
        self.frame_cabecalho = tk.Frame(
            self.root, bg="black", width=600, height=50)
        self.frame_cabecalho.place(x=10, y=35)
        self.labels_configuracao = {}
        for faixa, y in (("W1.1", 3), ("W1.2", 27)):
            tk.Label(self.frame_cabecalho, text=faixa, font=("Verdana", 11),
                     fg="white", bg="black").place(x=10, y=y)
            campos = self.labels_configuracao[faixa] = {}
            for campo, x in (("max", 100), ("min", 245), ("divisao", 400)):
                label = tk.Label(self.frame_cabecalho, font=("Verdana", 11),
                                 fg="white", bg="black")
                label.place(x=x, y=y)
                campos[campo] = label
        self.atualizar_configuracao(configuracao)

        # =====================================================
        # DISPLAY PRINCIPAL
        # =====================================================

        self.frame_peso = tk.Frame(
            self.root,
            bg=COR_FUNDO_MONITOR,
            width=600,
            height=100,
            highlightbackground="black",
            highlightthickness=2,
        )
        self.frame_peso.place(x=10, y=85)

        # W1.1 atual
        self.label_faixa = tk.Label(
            self.frame_peso,
            text="W1.1",
            font=("Verdana", 26),
            fg="black",
            bg=COR_FUNDO_MONITOR,
        )
        self.label_faixa.place(x=10, y=8)

        # =====================================================
        # INDICADOR DE ESTADO / ESTABILIDADE
        # =====================================================

        self.img_zero_original = tk.PhotoImage(file=_caminho_asset("null_cursor.png"))
        self.img_estavel_original = tk.PhotoImage(file=_caminho_asset("settled.png"))
        self.img_copiar_original = self.img_zero_original.__class__(
            file=_caminho_asset("copiar-48x48.png")
        )
        self.img_copiar = self.img_copiar_original.subsample(2, 2)
        self._instalar_icone()

        # Reduz as imagens
        self.img_zero = self.img_zero_original.subsample(8, 13)
        self.img_estavel = self.img_estavel_original.subsample(13, 10)

        self.label_estado = tk.Label(
            self.frame_peso,
            image=self.img_zero,
            bg=COR_FUNDO_MONITOR,
            borderwidth=0,
        )
        self.label_estado.place(
            x=16,
            y=65,
            width=40,
            height=15,
        )

        # Peso
        self.label_peso = tk.Label(
            self.frame_peso,
            text="0",
            font=("Verdana", 54, "bold"),
            fg="black",
            bg=COR_FUNDO_MONITOR,
            anchor="e",
        )
        self.label_peso.place(
            x=100,
            y=2,
            width=350,
            height=80,
        )

        # Unidade
        self.label_unidade = tk.Label(
            self.frame_peso,
            text="kg",
            font=("Verdana", 28),
            fg="black",
            bg=COR_FUNDO_MONITOR,
        )
        self.label_unidade.place(x=465, y=48)

        self.botao_copiar_peso = tk.Button(
            self.frame_peso,
            image=self.img_copiar,
            command=lambda: self.copiar_medicao("peso"),
            relief="flat",
            bd=0,
            bg=COR_FUNDO_MONITOR,
            activebackground=COR_FUNDO_MONITOR_ATIVA,
            cursor="hand2",
        )
        self.botao_copiar_peso.place(x=552, y=4, width=40, height=40)

        # =====================================================
        # TARA
        # =====================================================

        self.frame_tara = tk.Frame(
            self.root,
            bg=COR_FUNDO_MONITOR,
            width=600,
            height=50,
            highlightbackground="black",
            highlightthickness=2,
        )
        self.frame_tara.place(x=10, y=185)

        tk.Label(
            self.frame_tara,
            text="TARE",
            font=("Verdana", 16),
            fg="black",
            bg=COR_FUNDO_MONITOR,
        ).place(x=10, y=10)

        self.label_tara = tk.Label(
            self.frame_tara,
            text="0",
            font=("Verdana", 24),
            fg="black",
            bg=COR_FUNDO_MONITOR,
            anchor="e",
        )
        self.label_tara.place(
            x=100,
            y=3,
            width=350,
            height=40,
        )

        tk.Label(
            self.frame_tara,
            text="kg",
            font=("Verdana", 16),
            fg="black",
            bg=COR_FUNDO_MONITOR,
        ).place(x=465, y=10)

        self.botao_copiar_tara = tk.Button(
            self.frame_tara,
            image=self.img_copiar,
            command=lambda: self.copiar_medicao("tara"),
            relief="flat",
            bd=0,
            bg=COR_FUNDO_MONITOR,
            activebackground=COR_FUNDO_MONITOR_ATIVA,
            cursor="hand2",
        )
        self.botao_copiar_tara.place(x=552, y=3, width=40, height=40)
        self._configurar_botoes_copia(False)

        self._montar_barra_superior()
        self._montar_barra_status()

        # =====================================================
        # FECHAMENTO
        # =====================================================

        self.root.protocol(
            "WM_DELETE_WINDOW",
            self.confirmar_fechamento,
        )
        from interface.notificacoes import preparar_monitor
        preparar_monitor(self)

    # Atualiza as faixas sem recriar a janela e sem inventar valores quando a configuração faltar.
    def atualizar_configuracao(self, configuracao):
        self.configuracao = configuracao
        for faixa, labels in self.labels_configuracao.items():
            dados = configuracao.get(faixa, {}) if isinstance(configuracao, Mapping) else {}
            for campo, prefixo in (('max', 'Max '), ('min', 'Min '), ('divisao', 'e=d=')):
                valor = dados.get(campo) if isinstance(dados, Mapping) else None
                labels[campo].config(text=prefixo + (str(valor) if valor is not None else '—'))

    # Tenta usar o asset do produto como ícone da janela.
    def _instalar_icone(self):
        try:
            self.img_icone_janela = self.img_zero_original.__class__(
                file=_caminho_asset("logotc420.png")
            )
            self.root.iconphoto(True, self.img_icone_janela)
        except (tk.TclError, OSError):
            self.img_icone_janela = None

    # Constrói o menu e seus comandos de exportação, reconfiguração e informações.
    def _montar_barra_superior(self):
        self.frame_menu = tk.Frame(self.root, bg="#eeeeee", height=27)
        self.frame_menu.place(x=0, y=0, width=620, height=27)
        self.label_atualizacao = tk.Label(
            self.frame_menu, text='Atualização: —', bg='#eeeeee', fg='#333333',
            font=('Segoe UI', 10), anchor='e')
        self.label_atualizacao.place(x=270, y=2, width=340, height=23)
        self.menu_opcoes = tk.Menu(self.root, tearoff=False)
        self.menu_opcoes.add_command(label="Exportar log", command=self.exportar_log)
        self.menu_opcoes.add_command(label="Abrir terminal", state="disabled")
        self.menu_opcoes.add_command(label="Assumir manualmente",
                                     command=self.solicitar_promocao_manual)
        self.menu_opcoes.add_command(
            label="Reconfigurar",
            command=self.solicitar_reconfiguracao,
            state="normal" if self.ao_reconfigurar is not None else "disabled",
        )
        self.menu_opcoes.add_separator()
        self.menu_opcoes.add_command(label="Info", command=self.mostrar_info)
        self.menu_opcoes.add_separator()
        self.menu_opcoes.add_command(
            label="Desativar login automático",
            state="disabled",
        )
        self.botao_opcoes = tk.Button(
            self.frame_menu,
            text="Opções ▾",
            command=self.abrir_menu_opcoes,
            font=("Verdana", 10),
            relief="flat",
            bg="#eeeeee",
            activebackground="#dddddd",
        )
        self.botao_opcoes.pack(side="left", padx=(5, 0), fill="y")

    # Abre o popup abaixo do botão e libera o grab do menu ao terminar.
    def abrir_menu_opcoes(self):
        try:
            self.menu_opcoes.tk_popup(
                self.botao_opcoes.winfo_rootx(),
                self.botao_opcoes.winfo_rooty() + self.botao_opcoes.winfo_height(),
            )
        finally:
            self.menu_opcoes.grab_release()

    # Seletor/aplicação ficam no Tk; retrato e gravação são trabalho acompanhado pela B2.
    def exportar_log(self):
        from interface.ciclo_tk import ciclo
        controle = ciclo(self)
        if not controle.valido() or 'exportar_log' in controle.operacoes:
            return False
        caminho = filedialog.asksaveasfilename(
            parent=self.root,
            title="Exportar histórico recente do terminal",
            defaultextension=".txt",
            filetypes=(("Arquivo de texto", "*.txt"), ("Todos os arquivos", "*.*")),
            initialfile="prix-tc420-log.txt",
        )
        if not caminho:
            return False
        if getattr(self, 'saida_aplicacao', None) is None:
            messagebox.showerror(
                'PRIX TC420 - Exportar log', 'A exportação não está disponível nesta janela.',
                parent=self.root)
            return False

        def gravar():
            from interface.registro_terminal import obter_exportacao_terminal
            exportacao = obter_exportacao_terminal()
            Path(caminho).write_text(exportacao['texto'], encoding='utf-8')
            # A fila do Tk não precisa conservar outra cópia do texto exportado.
            return {chave: valor for chave, valor in exportacao.items() if chave != 'texto'}

        def aplicar(resultado, erro):
            if erro is not None:
                messagebox.showerror(
                    'PRIX TC420 - Exportar log', 'Não foi possível criar o arquivo selecionado.',
                    parent=self.root)
                return
            mensagem = 'Histórico recente do terminal exportado com sucesso.'
            if resultado['parcial']:
                mensagem += (
                    '\nHistórico parcial: mensagens antigas foram descartadas por retenção.'
                    f"\n{resultado['linhas_descartadas']} linhas encerradas por LF e "
                    f"{resultado['caracteres_descartados']} caracteres descartados.")
            else:
                mensagem += '\nNão houve descarte por retenção nesta sessão.'
            messagebox.showinfo('PRIX TC420 - Exportar log', mensagem, parent=self.root)

        return controle.iniciar('exportar_log', gravar, aplicar)

    # Confirma uma única solicitação e inicia o mesmo fluxo de fechamento antes de reabrir a conexão.
    def solicitar_reconfiguracao(self):
        from interface.administrador import controle_atual
        administrador = controle_atual()
        if administrador is not None:
            return administrador.pedir(self, 'Reconfigurar balança', self.reiniciar_administracao)
        if self.ao_reconfigurar is None or self.reconfiguracao_solicitada:
            return False
        confirmar = messagebox.askyesno(
            "PRIX TC420 - Reconfigurar",
            "A aplicação será encerrada com segurança e reaberta na tela de conexão.\n\nContinuar?",
            parent=self.root,
        )
        if not confirmar:
            return False
        self.reconfiguracao_solicitada = True
        print("MONITOR: reconfiguração solicitada; aguardando parada operacional.")
        self.fechar()
        return True

    def reiniciar_administracao(self):
        if self.ao_reconfigurar is None or self.reconfiguracao_solicitada:
            return False
        self.reconfiguracao_solicitada = True
        self.fechar()
        return True

    # Cria o indicador de cor e os textos de situação operacional do monitor.
    def _montar_barra_status(self):
        self.frame_status = tk.Frame(
            self.root,
            bg="#eeeeee",
            highlightbackground="#777777",
            highlightthickness=1,
        )
        self.frame_status.place(x=10, y=245, width=600, height=45)
        self.canvas_status = tk.Canvas(
            self.frame_status,
            width=24,
            height=24,
            bg="#eeeeee",
            highlightthickness=0,
        )
        self.canvas_status.place(x=8, y=9)
        self.indicador_status = self.canvas_status.create_oval(
            3, 3, 21, 21, fill="#777777", outline="#333333", width=1
        )
        self.label_status = tk.Label(
            self.frame_status,
            text="Estado indisponível",
            font=("Verdana", 10),
            bg="#eeeeee",
            anchor="w",
        )
        self.label_status.place(x=38, y=2, width=405, height=39)
        self.separador_clientes = tk.Frame(self.frame_status, bg="#777777")
        self.separador_clientes.place(x=450, y=0, width=1, height=45)
        self.label_clientes = tk.Label(
            self.frame_status,
            text="Clientes: —",
            font=("Verdana", 10),
            bg="#eeeeee",
            anchor="center",
        )
        self.label_clientes.place(x=451, y=2, width=147, height=39)

    # Mostra as informações e o aviso de independência do software definidos nesta janela.
    def mostrar_info(self):
        messagebox.showinfo(
            "PRIX TC420 - Informações",
            "Monitor PRIX TC420\n"
            "Versão: 1.0.0-beta\n"
            "Desenvolvedor: Pablo\n"
            "GitHub: não configurado\n\n"
            "Software independente e não oficial da Toledo do Brasil / PRIX.",
            parent=self.root,
        )

    # Copia valor e unidade já exibidos somente quando a comunicação é considerada atual.
    def copiar_medicao(self, campo):
        if not self.comunicacao_confirmada:
            messagebox.showwarning(
                "PRIX TC420 - Última leitura",
                "A leitura exibida não é atual e não será copiada.",
                parent=self.root,
            )
            return False
        widget = self.label_peso if campo == "peso" else self.label_tara
        unidade = self.label_unidade.cget("text")
        texto = f"{widget.cget('text')} {unidade}".strip()
        self.root.clipboard_clear()
        self.root.clipboard_append(texto)
        self.root.update_idletasks()
        return True

    # Sincroniza a disponibilidade dos botões com a validade da medição apresentada.
    def _configurar_botoes_copia(self, habilitados):
        estado = "normal" if habilitados else "disabled"
        cursor = "hand2" if habilitados else "arrow"
        for nome in ("botao_copiar_peso", "botao_copiar_tara"):
            botao = getattr(self, nome, None)
            if botao is not None:
                botao.config(state=estado, cursor=cursor)

    # Invoca callback opcional com um valor padrão e diagnóstico por classe de erro em caso de falha.
    def _consultar(self, callback, padrao=None):
        if callback is None:
            return padrao
        try:
            return callback()
        except Exception as erro:
            print(f"Falha ao consultar estado visual: {type(erro).__name__}")
            return padrao

    # Traduz papel, saúde, comunicação e candidatura em chave, cor e mensagens para a barra.
    def _retrato_status(self):
        if self.modo_monitor == 'tcp_local':
            if self.comunicacao_confirmada:
                return 'tcp_ok', '#31c94b', ('TCP local conectado', 'Leitura direta — sem servidor')
            return 'tcp_falha', '#c62828', ('TCP local sem comunicação', 'Última leitura recebida')
        if self.promocao_em_andamento:
            return "promovendo", "#7b2cbf", (
                "Promoção em andamento",
                "Assumindo o papel PRINCIPAL",
            )

        if self.modo_monitor == "principal":
            encerrado = bool(self._consultar(self.servidor_encerrado, False))
            if encerrado:
                return "ap_encerrado", "#c62828", (
                    "Servidor encerrado",
                    "Procurando outro servidor",
                )
            saude = self._consultar(self.obter_saude_principal)
            if isinstance(saude, Mapping):
                saude = saude.get("saudavel")
            if saude is True:
                return "ap_ok", "#31c94b", ("Servidor ON", "AP OK")
            return "ap_falha", "#e6b800", (
                "Servidor ON",
                "Falha de comunicação com a TC420",
                "Tentando reconectar",
            )

        candidatura = self._consultar(self.estado_candidatura, "inativa")
        if candidatura == "liberada":
            return "ct_liberada", "#7b2cbf", (
                "Candidatura liberada",
                "Pronto para assumir",
            )
        if candidatura == "aguardando":
            return "ct_aguardando", "#7b2cbf", (
                "Candidatura em espera",
                "Aguardando posição de sucessão",
            )
        if self.comunicacao_confirmada:
            return "ct_ok", "#31c94b", (
                "CT conectado",
                "Recebendo mensagens válidas",
            )
        if self.estado_candidatura is None or candidatura == "cancelada":
            return "ct_indisponivel", "#c62828", (
                "Servidor indisponível",
                "Procurando servidor PRINCIPAL",
            )
        return "ct_falha", "#e6b800", (
            "Falha na comunicação",
            "Tentando reconectar",
        )

    # Aplica o retrato operacional e ajusta a área de mensagens quando o estado muda.
    def _sincronizar_status(self):
        if not hasattr(self, "frame_status"):
            return
        chave, cor, mensagens = self._retrato_status()
        from interface.notificacoes import notificar_estado
        notificar_estado(self, chave)
        if chave != self._estado_status:
            self._estado_status = chave
            self._indice_status = 0
            self._token_status += 1
            token = self._token_status
            self._alternar_status(token, chave, cor, mensagens)
        else:
            self.canvas_status.itemconfigure(self.indicador_status, fill=cor)

        principal = self.modo_monitor == "principal"
        self.label_clientes.config(text="Clientes: —" if principal else "")
        self.separador_clientes.place(x=450, y=0, width=1, height=45) if principal else self.separador_clientes.place_forget()
        self.label_status.place_configure(width=405 if principal else 550)

    # Alterna as mensagens do estado atual usando reagendamento, sem pausar o loop gráfico.
    def _alternar_status(self, token, chave, cor, mensagens):
        if token != self._token_status or chave != self._estado_status:
            return
        self.canvas_status.itemconfigure(self.indicador_status, fill=cor)
        self.label_status.config(text=mensagens[self._indice_status % len(mensagens)])
        self._indice_status += 1
        self._agendar(3000, self._alternar_status, token, chave, cor, mensagens)

    # =========================================================
    # COMUNICAÇÃO COM A TC420
    # =========================================================

    # Substitui o callback de leitura após validar que a nova fonte é chamável.
    def definir_fonte_dados(
        self, fonte_dados: Callable[[], Mapping[str, Any]], comunicacao_atual=None
    ) -> None:
        if not callable(fonte_dados):
            raise ValueError(
                "A fonte de dados deve ser uma função."
            )
        self.fonte_dados = fonte_dados
        self.comunicacao_atual = comunicacao_atual
        print("Fonte de dados do monitor atualizada.")

    # Usa o ciclo Tk protegido para descartar callbacks de uma janela encerrada ou inválida.
    def _agendar(self, prazo, callback, *args):
        from interface.ciclo_tk import ciclo
        return ciclo(self).agendar(prazo, callback, *args)

    # Permite que a observação de saída continue após o bloqueio das atividades normais da janela.
    def agendar_saida(self, prazo, callback):
        from interface.ciclo_tk import ciclo
        return ciclo(self).agendar_saida(prazo, callback)

    # Executa a promoção em worker acompanhado e aplica o resultado depois na thread da interface.
    def _iniciar_promocao(self, trabalho, janela=None):
        from interface.ciclo_tk import ciclo
        if self.promocao_em_andamento or not ciclo(self).valido():
            return False
        self.promocao_em_andamento = True

        # Consome o retorno da promoção e atualiza a interface somente no callback de aplicação do worker.
        def aplicar(resultado, erro):
            self.promocao_em_andamento = False
            if janela is not None and (self.janela_promocao is not janela or not janela.winfo_exists()):
                return
            if resultado is not None and resultado is not False:
                self.concluir_promocao(resultado)
                if janela is not None:
                    self.fechar_janela_promocao(janela)
            else:
                if erro:
                    print('Promocao nao realizada:', erro)
                if janela is not None:
                    print('PROMOCAO: tentativa sem sucesso; formulário mantido para nova tentativa ou fechamento.')
                if janela is None and self.estado_candidatura is not None and self.estado_candidatura() == 'liberada':
                    self.abrir_janela_promocao()
                elif janela is None and getattr(self, '_supervisao_principal', None) is not None:
                    self.solicitar_promocao_manual()

        if not ciclo(self).iniciar('promocao', trabalho, aplicar):
            self.promocao_em_andamento = False
            return False
        if janela is not None:
            self._formulario_promocao_admitido = janela
        return True

    # Observa o evento e troca para o leitor rebaixado quando ele sinaliza conexão, mantendo o monitor.
    def observar_rebaixamento(self, evento, obter_leitor):
        # Reagenda a observação enquanto a janela estiver ativa e o leitor ainda não estiver pronto para a troca.
        def verificar():
            from interface.ciclo_tk import ativa
            if not ativa(self):
                return
            if evento.is_set():
                leitor = obter_leitor()
                if (
                    leitor is not None
                    and leitor.servidor_esta_respondendo()
                ):
                    self.definir_fonte_dados(
                        leitor.obter_dados_atuais,
                        leitor.comunicacao_esta_atual,
                    )
                    if hasattr(self, 'labels_configuracao'):
                        self.atualizar_configuracao(leitor.obter_configuracao())
                    self.modo_monitor = "cliente"
                    self.obter_saude_principal = None
                    self.servidor_encerrado = None
                    self.estado_candidatura = getattr(
                        leitor, "obter_estado_candidatura", None
                    )
                    self._estado_status = None
                    print(
                        "MONITOR: fonte de dados alterada "
                        "para o novo PRINCIPAL."
                    )
                    return
            self._agendar(1000, verificar)

        self._agendar(1000, verificar)

    def supervisionar_principal(self, contexto):
        """Um observador por contexto; callbacks de uma supervisão antiga não trocam a fonte."""
        from interface.ciclo_tk import ativa
        from rede.supervisao_principal import SupervisaoPrincipal
        if not ativa(self) or contexto is None or getattr(self, 'saida_aplicacao', None) is None:
            return None
        atual = getattr(self, '_supervisao_principal', None)
        if atual is not None and atual.contexto is contexto:
            return atual
        anteriores = getattr(self, '_contextos_supervisionados', [])
        if any(anterior is contexto for anterior in anteriores):
            return None
        if atual is not None:
            atual.cancelar()
        anteriores.append(contexto)
        self._contextos_supervisionados = anteriores
        supervisao = SupervisaoPrincipal(
            contexto, self.saida_aplicacao, getattr(self, 'infraestrutura_cliente', None))
        self._supervisao_principal = supervisao
        self.servidor_encerrado = contexto.coordenador_retornou.is_set
        if not getattr(self, '_supervisao_destroy_vinculado', False):
            def cancelar_ao_destruir(evento):
                if evento.widget is self.root and self._supervisao_principal is not None:
                    self._supervisao_principal.cancelar()
            self.root.bind('<Destroy>', cancelar_ao_destruir, add='+')
            self._supervisao_destroy_vinculado = True
        supervisao.iniciar()
        self.iniciar_observacao_candidatura()

        def verificar():
            if (not ativa(self) or self._supervisao_principal is not supervisao
                    or not supervisao.vigente()):
                return
            leitor = supervisao.obter_leitor()
            # A oferta manual independe de primeira amostra de outro PRINCIPAL.
            # O leitor continua sem candidatura automática e o worker revalida tudo.
            if supervisao.pronto.is_set() and leitor is not None:
                from rede.promocao_manual import promover_recuperado, tentar_recuperacao_automatica
                self.ao_promover = lambda ip, usuario, senha: promover_recuperado(
                    supervisao, ip, usuario, senha)
                self.ao_promover_automaticamente = lambda: tentar_recuperacao_automatica(supervisao)
                self.candidatura_liberada = leitor.candidatura_esta_liberada
                self.estado_candidatura = leitor.obter_estado_candidatura
            if (supervisao.pronto.is_set() and leitor is not None
                    and leitor is not getattr(self, '_leitor_recuperacao_atual', None)
                    and leitor.comunicacao_esta_atual()):
                self._leitor_recuperacao_atual = leitor
                self.definir_fonte_dados(leitor.obter_dados_atuais, leitor.comunicacao_esta_atual)
                self.atualizar_configuracao(leitor.obter_configuracao())
                self.modo_monitor = 'cliente'
                self.obter_saude_principal = None
                self.servidor_encerrado = None
                self.estado_candidatura = leitor.obter_estado_candidatura
                self.candidatura_liberada = leitor.candidatura_esta_liberada
                self._estado_status = None
                # Peso/indicadores e cópia mudam somente no refresh da nova fonte.
                self.atualizar_refresh_web(reagendar=False)
            if not supervisao.terminou.is_set():
                self._agendar(100, verificar)

        self._agendar(100, verificar)
        return supervisao

    def solicitar_promocao_manual(self):
        """Ação explícita após rebaixamento; nenhuma tentativa automática é liberada."""
        supervisao = getattr(self, '_supervisao_principal', None)
        saida = getattr(self, 'saida_aplicacao', None)
        if (supervisao is None or not supervisao.vigente() or not supervisao.pronto.is_set()
                or saida is None or not saida.ciclos_aptos_promocao()
                or self.promocao_em_andamento):
            print('PROMOCAO: opção manual indisponível; ciclo anterior pendente.')
            return False
        leitor = supervisao.obter_leitor()
        if leitor is None or leitor.comunicacao_esta_atual():
            print('PROMOCAO: opção manual indisponível; CLIENTE conectado.')
            return False
        from rede.promocao_manual import promover_recuperado
        self.ao_promover = lambda ip, usuario, senha: promover_recuperado(
            supervisao, ip, usuario, senha)
        self.abrir_janela_promocao()
        return True

    # Lê a fonte já selecionada e atualiza peso, tara, indicadores e aviso de última leitura sem novo login.
    def atualizar_refresh_web(self, reagendar=True):
        from tkinter import TclError
        from interface.ciclo_tk import ativa
        if not ativa(self):
            return
        if not self.executando:
            return

        # Horário do refresh local; não altera o instante da última amostra válida.
        self.ultima_atualizacao_tela = datetime.now().astimezone().strftime('%d/%m/%Y %H:%M:%S')
        label = getattr(self, 'label_atualizacao', None)
        if label is not None:
            label.config(text='Atualização: ' + self.ultima_atualizacao_tela)

        if self.fonte_dados is None:
            return

        try:
            # A janela apenas OBSERVA a fonte de dados que
            # recebeu. Ela não sabe (nem precisa saber) se
            # está no PC principal ou no PC cliente.
            dados = self.fonte_dados()

            peso = dados["peso_liquido"]
            tara = dados["tara"]
            unidade = dados["unidade"]
            faixa = dados["multirange"]
            estado = dados["estado"]
            if self.comunicacao_atual is not None:
                comunicacao_atual = bool(self.comunicacao_atual())
            elif (getattr(self, 'modo_monitor', None) == 'principal'
                  and getattr(self, 'obter_saude_principal', None) is not None):
                # O principal também conserva amostras antigas quando a TC420 deixa de responder.
                saude = self.obter_saude_principal()
                comunicacao_atual = isinstance(saude, Mapping) and saude.get('saudavel') is True
            else:
                comunicacao_atual = True
            if (getattr(self, 'modo_monitor', None) == 'principal'
                    and getattr(self, 'servidor_encerrado', None) is not None
                    and self.servidor_encerrado()):
                comunicacao_atual = False
            self.comunicacao_confirmada = comunicacao_atual
            if not all(widget.winfo_exists() for widget in (
                    self.label_estado, self.label_peso, self.label_tara,
                    self.label_unidade, self.label_faixa)):
                return

            # Uma leitura antiga pode ser conservada para diagnóstico, mas não
            # deve continuar parecendo uma medição atual confirmada.
            if not comunicacao_atual:
                if hasattr(self, "_configurar_botoes_copia"):
                    self._configurar_botoes_copia(False)
                self.label_estado.place_forget()
                self.label_faixa.config(
                    text="SEM COM.",
                    fg="white",
                    bg="#b00020",
                )
                self.label_peso.config(fg="#b00020")
                self.label_tara.config(fg="#b00020")
                self.root.title("PRIX TC420 - Monitor — ÚLTIMA LEITURA")
                print('TCP local sem leitura atual; valor exibido é a última leitura recebida.'
                      if getattr(self, 'modo_monitor', None) == 'tcp_local' else
                      'Sem comunicação com o servidor; valor exibido é a última leitura recebida.')
            elif estado in ("Z0", "Z1"):
                if hasattr(self, "_configurar_botoes_copia"):
                    self._configurar_botoes_copia(True)
                # Balança em zero
                self.root.title("PRIX TC420 - Monitor")
                self.label_peso.config(fg="black")
                self.label_tara.config(fg="black")
                self.label_estado.config(
                    image=self.img_zero
                )
                self.label_estado.place(
                    x=16,
                    y=65,
                    width=40,
                    height=15,
                )

            elif estado == "00":
                if hasattr(self, "_configurar_botoes_copia"):
                    self._configurar_botoes_copia(True)
                # Peso estabilizado
                self.root.title("PRIX TC420 - Monitor")
                self.label_peso.config(fg="black")
                self.label_tara.config(fg="black")
                self.label_estado.config(
                    image=self.img_estavel
                )
                self.label_estado.place(
                    x=16,
                    y=65,
                    width=40,
                    height=15,
                )

            else:
                if hasattr(self, "_configurar_botoes_copia"):
                    self._configurar_botoes_copia(True)
                # Peso em movimento
                self.root.title("PRIX TC420 - Monitor")
                self.label_peso.config(fg="black")
                self.label_tara.config(fg="black")
                self.label_estado.place_forget()

            print(
                f"[{self.ultima_atualizacao_tela}] "
                f"Estado: {estado} | "
                f"Peso: {peso} {unidade} | "
                f"Tara: {tara} {unidade} | "
                f"Faixa: {faixa}"
            )

            self.label_peso.config(text=str(peso))
            self.label_tara.config(text=str(tara))
            self.label_unidade.config(text=unidade)

            if comunicacao_atual and faixa in ("1", "2"):
                self.label_faixa.config(
                    text=f"W1.{faixa}",
                    fg="black",
                    bg=COR_FUNDO_MONITOR,
                )
            if getattr(self, 'modo_monitor', None) == 'tcp_local':
                self.leitor_tcp_local.registrar_diagnostico(comunicacao_atual)
                self.botao_copiar_tara.config(state='disabled')
                if comunicacao_atual:
                    self.label_faixa.config(text='TCP', fg='black', bg=COR_FUNDO_MONITOR)
                    self.root.title('PRIX TC420 - Monitor TCP local')

        except TclError:
            raise
        except Exception as erro:
            # Uma falha da fonte não pode deixar a cópia da amostra anterior habilitada.
            self.comunicacao_confirmada = False
            if hasattr(self, '_configurar_botoes_copia'):
                self._configurar_botoes_copia(False)
            if all(hasattr(self, nome) for nome in ('label_estado', 'label_faixa', 'root')):
                self.label_estado.place_forget()
                self.label_faixa.config(text='SEM COM.', fg='white', bg='#b00020')
                self.root.title('PRIX TC420 - Monitor — ÚLTIMA LEITURA')
            print(f"Erro no refresh web: {type(erro).__name__}")

        if hasattr(self, "_sincronizar_status"):
            self._sincronizar_status()

        if self.executando and reagendar:
            self._agendar(
                1000,
                self.atualizar_refresh_web,
            )

    def iniciar_observacao_candidatura(self):
        """Inclui o monitor de login manual, que compartilha o mainloop da conexão."""
        if getattr(self, '_observando_candidatura', False):
            return
        self._observando_candidatura = True
        self.verificar_candidatura()

    # Observa a liberação de candidatura e coordena a tentativa automática ou o formulário manual.
    def verificar_candidatura(self):
        from tkinter import TclError
        from interface.ciclo_tk import ativa
        if not ativa(self):
            return
        if not self.executando:
            return

        if self.candidatura_liberada is not None:
            try:
                liberada = self.candidatura_liberada()
                if liberada and not self.candidatura_detectada:
                    self.candidatura_detectada = True
                    print("")
                    print("Candidatura detectada pela interface.")
                    if self.ao_promover_automaticamente is not None:
                        self._iniciar_promocao(self.ao_promover_automaticamente)
                    elif self.estado_candidatura is not None and self.estado_candidatura() == 'liberada':
                        self.abrir_janela_promocao()
                elif not liberada:
                    self.candidatura_detectada = False
                    estado = None
                    if self.estado_candidatura is not None:
                        try:
                            estado = self.estado_candidatura()
                        except Exception as erro:
                            print(
                                "Erro ao consultar estado "
                                f"da candidatura: {erro}"
                            )
                    # O promotor para o leitor e limpa sua candidatura antes do
                    # login. Isso não é cancelamento da operação já admitida.
                    # Saída/cancelamento explícito continuam invalidando o worker.
                    if (estado in ("cancelada", "inativa") and not self.promocao_em_andamento
                            and getattr(self, '_formulario_promocao_admitido', None)
                            is not self.janela_promocao):
                        if (
                            self.janela_promocao is not None
                            and self.janela_promocao.winfo_exists()
                        ):
                            print(
                                "Candidatura cancelada. "
                                "Fechando janela ASSUMIR."
                            )
                            from interface.ciclo_tk import ciclo
                            ciclo(self).cancelar('promocao')
                            self.janela_promocao.destroy()
                            self.janela_promocao = None
            except TclError:
                raise
            except Exception as erro:
                print(f"Erro ao verificar candidatura: {type(erro).__name__}")

        if self.executando:
            self._agendar(500, self.verificar_candidatura)

    # Aplica os dados retornados pela promoção e passa a observar a fonte do novo principal.
    def concluir_promocao(self, resultado):
        from interface.ciclo_tk import ativa
        if not ativa(self):
            return
        contexto = resultado.get("contexto_ciclo")
        if contexto is not None:
            if not any(anterior is contexto for anterior in self.contextos_promocao):
                self.associar_contexto_promocao(contexto)
            else:
                self.observar_contexto_promocao(contexto)
        self.web = resultado["web"]
        self.configuracao = resultado["configuracao"]
        if hasattr(self, 'labels_configuracao'):
            self.atualizar_configuracao(self.configuracao)
        self.fonte_dados = resultado["fonte_dados"]
        self.comunicacao_atual = None
        # O texto ainda exibido pertence à fonte anterior até o próximo refresh.
        self.comunicacao_confirmada = False
        if hasattr(self, '_configurar_botoes_copia'):
            self._configurar_botoes_copia(False)
        self.modo_monitor = "principal"
        self.obter_saude_principal = resultado.get("obter_saude_principal")
        self.servidor_encerrado = resultado.get("servidor_encerrado")
        self.candidatura_liberada = None
        self.candidatura_detectada = False
        self._estado_status = None
        if contexto is not None and hasattr(self, 'supervisionar_principal'):
            self.supervisionar_principal(contexto)
        print("")
        print("PROMOÇÃO CONCLUÍDA.")
        print("Esta máquina agora é o PRINCIPAL.")

    # Retém o contexto da promoção para não perder a identidade de uma tentativa em acompanhamento.
    def configurar_tcp_local(self, leitor):
        self.leitor_tcp_local = leitor
        self.web, self.configuracao = None, None
        self.fonte_dados = leitor.obter_dados_atuais
        self.comunicacao_atual = leitor.comunicacao_esta_atual
        self.comunicacao_confirmada = False
        self.modo_monitor = 'tcp_local'
        self.candidatura_liberada = self.estado_candidatura = None
        self.ao_promover = self.ao_promover_automaticamente = None
        self.obter_saude_principal = self.servidor_encerrado = None
        self._estado_status = None
        self.atualizar_configuracao({})

    def _iniciar_tcp_local(self, ip, porta, janela):
        from interface.ciclo_tk import ciclo
        from rede.tcp_local import conectar_local
        if self.promocao_em_andamento:
            return
        self.promocao_em_andamento = True
        self._formulario_promocao_admitido = janela
        def aplicar(leitor, erro):
            self.promocao_em_andamento = False
            if erro is not None or leitor is None:
                print('TCP LOCAL: conexão não concluída:', erro or 'sem leitura válida')
                return
            self.configurar_tcp_local(leitor)
            from interface.administrador import controle_atual
            administrador = controle_atual()
            if administrador is not None:
                administrador.metodo_inicial = 'TCP'
            self.fechar_janela_promocao(janela)
        def conectar():
            from interface.administrador import controle_atual
            if controle_atual() is not None:
                from config.administrador import salvar_tcp
                salvar_tcp(ip, porta)
            return conectar_local(ip, porta, self.saida_aplicacao, self.infraestrutura_cliente,
                                  getattr(self, '_supervisao_principal', None))
        iniciado = ciclo(self).iniciar('tcp_local', conectar, aplicar)
        if not iniciado:
            self.promocao_em_andamento = False

    def associar_contexto_promocao(self, contexto):
        from interface.ciclo_tk import ativa
        if not ativa(self):
            return
        if not any(anterior is contexto for anterior in self.contextos_promocao):
            self.contextos_promocao.append(contexto)
        self.contexto_promocao_atual = contexto
        self.ciclo_servidor_id = None
        self.observar_contexto_promocao(contexto)

    # Observa a resolução do contexto por reagendamento Tk e associa o ID correspondente.
    def observar_contexto_promocao(self, contexto):
        from interface.ciclo_tk import ativa
        if not ativa(self):
            return
        if self.contexto_promocao_atual is not contexto:
            return
        if contexto.resolvido.is_set():
            self.ciclo_servidor_id = contexto.ciclo_id
            return
        if self.executando:
            self._agendar(100, lambda: self.observar_contexto_promocao(contexto))

    # Constrói o formulário de credenciais usado quando a promoção requer entrada manual.
    def abrir_janela_promocao(self, _administrado=False):
        from interface.administrador import controle_atual
        administrador = controle_atual()
        if administrador is not None and not _administrado:
            return administrador.pedir(self, 'Promoção manual / ASSUMIR',
                                       lambda: self.abrir_janela_promocao(_administrado=True))
        from interface.ciclo_tk import ativa
        if not ativa(self):
            return
        if (
            self.janela_promocao is not None
            and self.janela_promocao.winfo_exists()
        ):
            self.janela_promocao.lift()
            self.janela_promocao.focus_force()
            return

        janela = tk.Toplevel(self.root)
        self.janela_promocao = janela
        janela.title("Assumir TC420")
        from interface.formularios import montar_formulario
        janela._administrador_dono = self
        formulario = montar_formulario(janela, True, lambda: confirmar())
        entry_ip = formulario.entradas['IP da TC420']
        entry_porta = formulario.entradas['Porta TCP']
        entry_usuario = formulario.entradas['Usu\u00e1rio']
        entry_senha = formulario.entradas['Senha']
        entry_ip.insert(0, '192.0.2.21')
        entry_porta.insert(0, '9800')
        entry_usuario.insert(0, 'admin')
        salvar_login_var = formulario.salvar

        # Lê as credenciais na thread Tk e as entrega ao trabalho de promoção, sem executar rede no callback.
        def confirmar():
            ip = entry_ip.get().strip()
            metodo = getattr(janela, 'metodo_conexao', None)
            if metodo is not None and metodo.get() == 'TCP':
                try:
                    porta = int(entry_porta.get().strip())
                    if not ip or not 1 <= porta <= 65535:
                        raise ValueError
                except ValueError:
                    print('TCP LOCAL: informe IP e porta válidos.')
                    return
                self._iniciar_tcp_local(ip, porta, janela)
                return
            usuario = entry_usuario.get().strip()
            senha = entry_senha.get()
            salvar_login = salvar_login_var.get()
            if not ip or not usuario or not senha:
                print(
                    "Preencha IP, usuário e senha "
                    "para assumir a TC420."
                )
                return

            if self.ao_promover is None:
                print("Promoção não configurada.")
                return
            if self.promocao_em_andamento:
                return

            if self.ao_promover is not None:
                def promover():
                    from interface.administrador import controle_atual
                    if controle_atual() is not None:
                        from config.administrador import salvar_metodo
                        salvar_metodo('HTTPS')
                    resultado = self.ao_promover(ip, usuario, senha)
                    if resultado and salvar_login:
                        from config.configuracao import guardar_login_automatico
                        from config.arquivos import ContextoArquivosConfiguracao
                        try:
                            infra = getattr(self, 'infraestrutura_cliente', None)
                            contexto = ContextoArquivosConfiguracao(infra) if infra is not None else None
                            guardar_login_automatico(ip, usuario, senha, contexto_arquivos=contexto)
                        except Exception as erro:
                            # Persistência não pode descartar uma promoção já concluída.
                            print('LOGIN: falha ao preparar gravação:', type(erro).__name__)
                    return resultado
                self._iniciar_promocao(promover, janela)

        entry_senha.bind("<Return>", lambda event: confirmar())
        janela.protocol(
            "WM_DELETE_WINDOW",
            lambda: self.fechar_janela_promocao(janela),
        )
        entry_senha.focus_set()

    # Destrói o formulário auxiliar informado pelo fluxo de promoção.
    def fechar_janela_promocao(self, janela):
        if self.promocao_em_andamento:
            return
        janela.destroy()
        if getattr(self, '_formulario_promocao_admitido', None) is janela:
            self._formulario_promocao_admitido = None
        self.janela_promocao = None

    # Inicia a leitura TCP direta do caminho legado e agenda o consumo dos resultados no Tk.
    def iniciar_leitura(self):
        from interface.ciclo_tk import ciclo
        controle = ciclo(self)
        controle.agendar(25, self._consumir_pesos)
        thread = threading.Thread(
            target=self.ler_balanca,
            daemon=True,
        )
        if self.saida_aplicacao is not None:
            self.saida_aplicacao.iniciar_thread(thread)

    # Consome na thread gráfica as publicações do leitor legado e agenda a próxima observação.
    def _consumir_pesos(self):
        from interface.ciclo_tk import ciclo
        ciclo(self).consumir()
        ciclo(self).agendar(25, self._consumir_pesos)

    # Recebe frames no worker legado e publica o peso na fila, sem atualizar widgets a partir da thread.
    def ler_balanca(self):
        try:
            print(
                f"Conectando à TC420 "
                f"{self.balanca.ip}:{self.balanca.porta}..."
            )

            self.balanca.conectar()

            print("TC420 CONECTADA!")

            while self.executando:
                frame = self.balanca.receber()

                try:
                    peso = interpretar_peso(frame)

                except ValueError as erro:
                    print(f"Frame inválido: {erro}")
                    continue

                print(f"Peso: {peso}")

                self._ciclo_tk.publicar(self.atualizar_peso, peso)

        except Exception as erro:
            if self.executando:
                print(f"Erro na comunicação: {erro}")

    # =========================================================
    # ATUALIZAÇÃO DA INTERFACE
    # =========================================================

    # Aplica o peso recebido apenas se a janela e o widget continuarem válidos.
    def atualizar_peso(self, peso):
        from interface.ciclo_tk import ativa
        if not ativa(self):
            return
        if not self.label_peso.winfo_exists():
            return
        self.label_peso.config(
            text=str(peso),
        )

    # =========================================================
    # ENCERRAMENTO
    # =========================================================

    # Pede confirmação ao operador antes de encaminhar o fechamento.
    def confirmar_fechamento(self):
        resposta = messagebox.askyesnocancel(
            title="PRIX TC420 - Fechar monitor",
            message=(
                "Deseja encerrar completamente a aplicação?\n\n"
                "SIM: Encerrar a aplicação.\n"
                "NÃO: Continuar em segundo plano.\n"
                "CANCELAR: Voltar ao monitor."
            ),
            parent=self.root,
        )
        if resposta is True:
            print("MONITOR: usuário solicitou encerrar a aplicação.")
            if self.ao_fechar is None:
                print(
                    "MONITOR: encerramento completo ainda não "
                    "configurado para este modo."
                )
                return
            self.fechar()
        elif resposta is False:
            print("MONITOR: usuário solicitou continuar em segundo plano.")
        else:
            print("MONITOR: fechamento cancelado.")

    # Encaminha o pedido ao callback de saída quando existe; o fechamento efetivo tem etapa própria.
    def fechar(self):
        if not self.executando:
            return
        if self.ao_fechar is not None:
            self.ao_fechar()
            return
        self.concluir_fechamento()

    # Mostra o estado pendente e permite que o operador solicite nova avaliação.
    def informar_encerramento_pendente(self, estado):
        from interface.ciclo_tk import ciclo
        if not ciclo(self).valido(encerramento=True):
            return
        messagebox.showwarning(
            'PRIX TC420 - Encerramento pendente',
            'A parada ainda nao foi comprovada (' + estado + ').\n'
            'A janela permanecera aberta. Escolha SIM novamente para reavaliar.',
            parent=self.root)

    # Cancela o ciclo Tk e destrói a janela após as condições exigidas pelo caminho de saída.
    def concluir_fechamento(self):
        if not self.executando:
            return
        saida = getattr(self, 'saida_aplicacao', None)
        if saida is not None and not saida.obter_situacao()['parada_operacional_confirmada']:
            return False
        from interface.ciclo_tk import ciclo
        supervisao = getattr(self, '_supervisao_principal', None)
        if supervisao is not None:
            supervisao.cancelar()
        ciclo(self).fechar()
        self.executando = False

        try:
            self.balanca.desconectar()

        except Exception:
            pass

        self.root.destroy()
        if (getattr(self, "reconfiguracao_solicitada", False)
                and getattr(self, "ao_reconfigurar", None) is not None):
            reabrir = self.ao_reconfigurar
            self.ao_reconfigurar = None
            if reabrir is not None:
                reabrir()

    # Inicia as observações de peso/candidatura e mantém o processamento de eventos da interface.
    def executar(self):
        self.atualizar_refresh_web()
        self.iniciar_observacao_candidatura()

        # Só inicia o loop quando a janela é a principal
        # (modo CLIENTE). No PRINCIPAL, a JanelaConexao já
        # possui o mainloop.
        if self.dona_root:
            self.root.mainloop()

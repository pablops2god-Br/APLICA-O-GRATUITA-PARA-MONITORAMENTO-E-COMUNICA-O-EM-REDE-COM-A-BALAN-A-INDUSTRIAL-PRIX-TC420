# Conexão manual: widgets permanecem no Tk; descoberta e autenticação rodam em worker.
import threading
import time
import tkinter as tk

from config.configuracao import (
    carregar_configuracao,
    carregar_senha,
    remover_senha,
    salvar_configuracao,
    salvar_senha,
)
from interface.janela import JanelaTC420
from rede.buscarservidor import buscar_servidor
from rede.servidor import (
    ContextoCicloServidor,
    definir_configuracao,
    iniciar_servidor,
    obter_dados_atuais,
    solicitar_parada_servidor,
)
from tc420.web import WebTC420


# Reúne formulário de conexão, partida manual e acompanhamento do monitor e da saída.
class JanelaConexao:
    # Constrói os widgets e os sinais de ciclo; a rede é iniciada somente pela ação de conexão.
    def __init__(self, ao_encontrar_servidor=None, registro_tentativas=None, infraestrutura_cliente=None, *, vinculo_http=False, contexto_arquivos=None, saida_aplicacao=None):
        from interface.saida_aplicacao import SaidaAplicacao
        self.saida_aplicacao = (saida_aplicacao or getattr(infraestrutura_cliente, 'saida_aplicacao', None)
                               or SaidaAplicacao())
        self._callback_saida = self.saida_aplicacao.vincular(
            'conexao_manual', lambda: self.encerrar_aplicacao(_encaminhada=True))
        from rede.entradas_http import criar_validador_entrada
        self._validar_infraestrutura_http = criar_validador_entrada(vinculo_http)
        self._contexto_arquivos = contexto_arquivos
        self.infraestrutura_cliente = infraestrutura_cliente
        self.saida_aplicacao.configurar(infraestrutura_cliente, registro_tentativas)
        self.root = tk.Tk()
        self.web = None
        self.configuracao = None
        self.ao_encontrar_servidor = ao_encontrar_servidor
        self.ao_reconfigurar = getattr(self.saida_aplicacao, "ao_reconfigurar", None)
        self.registro_tentativas = registro_tentativas
        self.tentativa_servidor_id = None

        # Garante que o servidor seja iniciado UMA única vez,
        # mesmo que o botão CONECTAR seja clicado novamente.
        self.servidor_iniciado = False
        self.servidor_encerrado = threading.Event()
        self.servidor_inicializado = threading.Event()
        self.contexto_ciclo_servidor = None
        self.ciclo_servidor_id = None
        self.encerramento_solicitado = threading.Event()
        self.lock_encerramento = threading.Lock()
        self.parada_servidor_solicitada = False
        self.leitor_rebaixado = None
        self.leitor_pronto = threading.Event()
        self.finalizacao_concluida = threading.Event()
        self.finalizacao_confirmada = False
        self.estado_encerramento = "aberto"
        self.verificacao_finalizacao_ativa = False
        self.thread_finalizacao: threading.Thread | None = None

        self.root.protocol('WM_DELETE_WINDOW', self.confirmar_fechamento)
        self.root.title("PRIX TC420 - Conexão")
        from interface.formularios import montar_formulario
        self.root._administrador_dono = self
        formulario = montar_formulario(self.root, False, self.conectar)
        self.campo_nome = formulario.entradas['Nome da balan\u00e7a']
        self.campo_ip = formulario.entradas['IP da TC420']
        self.campo_porta = formulario.entradas['Porta TCP']
        self.campo_usuario = formulario.entradas['Usu\u00e1rio']
        self.campo_senha = formulario.entradas['Senha']
        self.salvar_login_var = formulario.salvar
        self.check_salvar = formulario.check_salvar
        self.metodo_conexao_var = formulario.metodo
        self.botao_conectar = formulario.botao
        self.label_status = formulario.status
        self.carregar_dados_salvos()

        # Enter também aciona o botão
        self.root.bind(
            "<Return>",
            lambda event: self.conectar(),
        )

        # Coloca o cursor inicialmente na senha
        self.campo_senha.focus_set()

    # =========================================================
    # CONECTAR
    # =========================================================

        self.saida_aplicacao.conectar_interface(
            self._callback_saida, self.agendar_saida, self.concluir_encerramento_confirmado,
            self.informar_encerramento_pendente)
        from interface.administrador import controle_atual
        administrador = controle_atual()
        if administrador is not None:
            if not administrador.autorizado:
                self.root.withdraw()
                administrador.pedir(self, 'Configuração da conexão', self.root.deiconify)
            # Leitura do método é feita em worker junto do carregamento inicial administrativo.
            if getattr(administrador, 'metodo_inicial', 'HTTPS') == 'TCP':
                self.metodo_conexao_var.set('TCP')

    def reiniciar_administracao(self):
        """Reabre cadastro somente depois da confirmação B2 da execução atual."""
        self._reiniciar_admin = True
        self.encerrar_aplicacao()

    def cancelar_administracao(self):
        self.encerrar_aplicacao()

    # Preenche o formulário a partir do JSON e consulta a senha no keyring conforme a opção salva.
    def carregar_dados_salvos(self):
        configuracao = carregar_configuracao(**({"contexto_arquivos": self._contexto_arquivos}
                                              if self._contexto_arquivos is not None else {}))
        if configuracao is None:
            self.campo_ip.insert(0, "192.0.2.21")
            self.campo_porta.insert(0, "9800")
            self.campo_usuario.insert(0, "admin")
            return

        self.campo_nome.insert(0, configuracao.get("nome_rede", ""))
        self.campo_ip.insert(0, configuracao.get("ip", "192.0.2.21"))
        self.campo_porta.insert(0, str(configuracao.get("porta", 9800)))
        usuario = configuracao.get("usuario", "admin")
        self.campo_usuario.insert(0, usuario)
        salvar_login = configuracao.get("salvar_login", False)
        self.salvar_login_var.set(salvar_login)
        if salvar_login:
            senha = carregar_senha(usuario)
            if senha:
                self.campo_senha.insert(0, senha)

    # Traduz a escolha da caixa de confirmação em pedido de encerramento da aplicação.
    def confirmar_fechamento(self):
        from tkinter import messagebox
        if messagebox.askyesnocancel('PRIX TC420', 'Encerrar a aplicacao?', parent=self.root) is True:
            self.encerrar_aplicacao()

    # Lê e valida os campos no Tk e envia o trabalho de rede para um worker acompanhado.
    def conectar(self):
        from interface.ciclo_tk import ciclo
        from interface.administrador import controle_atual
        administrador = controle_atual()
        if administrador is not None and not getattr(self, '_metodo_admin_salvo', False):
            def guardar():
                from config.administrador import salvar_metodo
                metodo = self.metodo_conexao_var.get()
                def aplicar(_resultado, erro):
                    if erro:
                        self.label_status.config(text='Falha ao salvar o método de conexão.', fg='red')
                        return
                    self._metodo_admin_salvo = True
                    administrador.metodo_inicial = metodo
                    self.conectar()
                ciclo(self).iniciar('metodo_administrativo', lambda: salvar_metodo(metodo), aplicar)
            if not administrador.autorizado:
                return administrador.pedir(self, 'Configuração da conexão', guardar)
            return guardar()
        self._metodo_admin_salvo = False
        controle = ciclo(self)
        if not controle.valido() or 'conectar' in controle.operacoes or self.servidor_iniciado:
            return
        nome_rede = self.campo_nome.get().strip()
        ip = self.campo_ip.get().strip()
        porta_texto = self.campo_porta.get().strip()
        usuario = self.campo_usuario.get().strip()
        senha = self.campo_senha.get()
        salvar_login = self.salvar_login_var.get()
        metodo_var = getattr(self, 'metodo_conexao_var', None)
        tcp_local = metodo_var is not None and metodo_var.get() == 'TCP'

        if not nome_rede and not tcp_local:
            self.label_status.config(text="● Informe o nome da balança", fg="red")
            return

        if not ip:
            self.label_status.config(
                text="● Informe o IP da TC420",
                fg="red",
            )
            return

        if not porta_texto:
            self.label_status.config(text="● Informe a porta", fg="red")
            return
        try:
            porta = int(porta_texto)
            if not 1 <= porta <= 65535:
                raise ValueError
        except ValueError:
            self.label_status.config(text="● Informe uma porta válida", fg="red")
            return

        if tcp_local:
            from rede.tcp_local import conectar_local
            self.botao_conectar.config(state='disabled')
            self.label_status.config(text='Conectando por TCP local...', fg='#9aa6ad')
            def conectar_tcp():
                if administrador is not None:
                    from config.administrador import salvar_tcp
                    salvar_tcp(ip, porta, nome_rede or 'TC420')
                return {'tcp_local': conectar_local(ip, porta, self.saida_aplicacao,
                                                   self.infraestrutura_cliente)}
            controle.iniciar('conectar', conectar_tcp, self._aplicar_conexao)
            return

        if not usuario:
            self.label_status.config(
                text="● Informe o usuário",
                fg="red",
            )
            return

        if not senha:
            self.label_status.config(text="● Informe a senha", fg="red")
            return

        self.botao_conectar.config(state="disabled")
        self.label_status.config(text="Conectando...", fg="#555555")
        controle.iniciar('conectar',
                         lambda: self._conectar_operacional(nome_rede, ip, porta, usuario, senha, salvar_login),
                         self._aplicar_conexao)

    # Aplica o resultado na thread do Tk: erro, transição para cliente ou abertura do monitor principal.
    def _aplicar_conexao(self, resultado, erro):
        from interface.ciclo_tk import ciclo
        if not ciclo(self).valido():
            return
        self.botao_conectar.config(state="normal")
        if erro is not None:
            self.label_status.config(text="Erro na conexão: " + erro, fg="red")
            return
        if 'tcp_local' in resultado:
            self.abrir_monitor_tcp_local(resultado['tcp_local'])
            return
        if 'servidor' in resultado:
            self._servidor_encontrado = resultado['servidor']
            ciclo(self).fechar()
            self.root.destroy()
            return
        self.label_status.config(text="● Login realizado com sucesso", fg="green")
        self.observar_contexto_ciclo(self.contexto_ciclo_servidor)
        ciclo(self).agendar(500, self.abrir_monitor)

    # No worker, procura outro principal, autentica se necessário e prepara configuração e servidor.
    def _conectar_operacional(self, nome_rede, ip, porta, usuario, senha, salvar_login):
        print("")
        print("=== VERIFICAÇÃO DE SERVIDOR ===")
        print("Procurando servidor TC420 antes do login...")
        servidor = buscar_servidor(**({"infraestrutura_cliente": self.infraestrutura_cliente}
                                     if getattr(self, "infraestrutura_cliente", None) is not None else {}))
        if servidor:
            if self.ao_encontrar_servidor is None:
                raise RuntimeError('cliente_indisponivel')
            # A descoberta muda o papel, mas não deve ignorar a escolha de persistência.
            if salvar_login:
                from config.configuracao import guardar_login_automatico
                guardar_login_automatico(
                    ip, usuario, senha, nome_rede=nome_rede, porta=porta,
                    contexto_arquivos=self._contexto_arquivos)
            return {"servidor": servidor}

        try:
            infraestrutura = getattr(self, "infraestrutura_cliente", None)
            infraestrutura = self._validar_infraestrutura_http(infraestrutura)
            self.web = WebTC420(ip, politica_http=infraestrutura.criar_politica_http())
            contexto_http = infraestrutura.preparar_http_inicial()
            infraestrutura.executar_login_manual(self.web, usuario, senha, contexto_http=contexto_http)
            configuracao = infraestrutura.executar_approval(contexto_http, self.web)
            salvar_configuracao(
                nome_rede=nome_rede,
                ip=ip,
                porta=porta,
                usuario=usuario,
                salvar_login=salvar_login,
                **({"contexto_arquivos": self._contexto_arquivos}
                   if self._contexto_arquivos is not None else {}),
            )
            if salvar_login:
                if not salvar_senha(usuario, senha):
                    print("Aviso: não foi possível salvar a senha.")
            else:
                remover_senha(usuario)
            self.configuracao = configuracao
            definir_configuracao(self.configuracao)

            print("\n=== LOGIN TC420 ===")
            print("IP:", ip)
            print("Login realizado com sucesso.")

            print("\n=== CONFIGURAÇÃO TC420 ===")

            for nome, dados in configuracao.items():
                print(nome)

                for chave, valor in dados.items():
                    print(f"  {chave}: {valor}")

            # ---------------------------------------------
            # A MESMA sessão HTTP autenticada passa para o
            # servidor. Assim existe um único login/token na
            # máquina principal: a janela local e os clientes
            # remotos compartilham a mesma conexão.
            # ---------------------------------------------
            if not self.servidor_iniciado:
                saida = getattr(self, 'saida_aplicacao', None)
                contexto = ContextoCicloServidor()
                if saida is not None:
                    saida.acompanhar_contexto(contexto)
                self.contexto_ciclo_servidor = contexto
                self.ciclo_servidor_id = None
                self.tentativa_servidor_id = None
                registro = self.registro_tentativas
                tentativa_id = None
                if registro is not None:
                    tentativa_id = registro.admitir(contexto)
                    if tentativa_id is None:
                        contexto.registrar_falha("falha_antes_reserva")
                        raise RuntimeError("CONEXAO: admissão de tentativa recusada.")
                    self.tentativa_servidor_id = tentativa_id
                    if not registro.marcar_iniciando(tentativa_id):
                        contexto.registrar_falha("falha_antes_reserva")
                        raise RuntimeError("CONEXAO: registro não autorizou a partida.")
                sessao_servidor = self.web
                self.servidor_iniciado = True

                # Registra a entrada da thread e sinaliza o retorno do servidor em finally, inclusive após falha.
                def executar_servidor():
                    try:
                        if registro is not None:
                            if not registro.registrar_entrada_execucao(tentativa_id):
                                contexto.registrar_falha("falha_antes_reserva")
                                return
                        iniciar_servidor(
                            sessao_servidor,
                            evento_inicializacao=self.servidor_inicializado,
                            contexto_ciclo=contexto,
                        )
                    except BaseException:
                        contexto.registrar_falha("falha_antes_reserva")
                        raise
                    finally:
                        print("")
                        print(
                            "CONEXAO: servidor PRINCIPAL foi encerrado."
                        )
                        self.servidor_encerrado.set()

                try:
                    thread_servidor = threading.Thread(
                        target=executar_servidor,
                        daemon=True,
                    )
                except Exception:
                    contexto.registrar_falha("falha_antes_reserva")
                    if registro is not None:
                        try:
                            registro.registrar_falha_partida(
                                tentativa_id, "falha_criacao_thread",
                                execucao_nao_iniciada=True,
                            )
                        except Exception:
                            print("CONEXAO: falha ao registrar erro de criação da thread.")
                    raise
                # Uma exceção de start não prova ausência de execução.
                if saida is None:
                    thread_servidor.start()
                else:
                    saida.iniciar_servidor_thread(
                        thread_servidor, contexto, registro, tentativa_id)
                if registro is not None:
                    if not registro.marcar_iniciada(tentativa_id):
                        raise RuntimeError("CONEXAO: registro não confirmou a partida.")
                supervisor = threading.Thread(target=self.supervisionar_inicializacao, daemon=True)
                for auxiliar in (supervisor,):
                    if saida is None:
                        auxiliar.start()
                    else:
                        saida.iniciar_thread(auxiliar)

            return {"principal": True}
        except Exception as erro:
            print("Erro ao realizar login:", type(erro).__name__)
            self.web = None
            self.configuracao = None
            raise

    # Encaminha callbacks ao ciclo protegido da janela para evitar atuação sobre uma janela inválida.
    def _agendar(self, prazo, callback, *args):
        from interface.ciclo_tk import ciclo
        return ciclo(self).agendar(prazo, callback, *args)

    # Agenda observações de saída mesmo quando o trabalho normal da janela já foi bloqueado.
    def agendar_saida(self, prazo, callback):
        from interface.ciclo_tk import ciclo
        return ciclo(self).agendar_saida(prazo, callback)

    # Espera por reagendamento Tk até o contexto resolver o ID, sem bloquear o loop gráfico.
    def observar_contexto_ciclo(self, contexto):
        if self.contexto_ciclo_servidor is not contexto:
            return
        if contexto.resolvido.is_set():
            self.ciclo_servidor_id = contexto.ciclo_id
            return
        self._agendar(100, lambda: self.observar_contexto_ciclo(contexto))

    # Solicita parada local levando em conta o sinal de inicialização do servidor.
    def solicitar_parada_local(self):
        with self.lock_encerramento:
            if self.parada_servidor_solicitada:
                return False
            if not self.servidor_inicializado.is_set():
                print(
                    "CONEXAO: parada aguardando inicialização do servidor."
                )
                return False
            self.parada_servidor_solicitada = True
        try:
            print("CONEXAO: solicitando parada única do servidor local.")
            solicitar_parada_servidor()
        except Exception as erro:
            with self.lock_encerramento:
                self.parada_servidor_solicitada = False
            print(
                "CONEXAO: falha ao solicitar parada do servidor:",
                erro,
            )
            return False
        return True

    # Observa inicialização e pedido de saída para não perder uma parada durante a partida.
    def supervisionar_inicializacao(self):
        while (
            not self.servidor_inicializado.is_set()
            and not self.servidor_encerrado.is_set()
        ):
            self.servidor_encerrado.wait(timeout=0.1)
        if self.servidor_encerrado.is_set():
            return
        if self.encerramento_solicitado.is_set():
            print(
                "CONEXAO: inicialização tardia detectada "
                "durante o encerramento."
            )
            self.solicitar_parada_local()

    # Executa a espera limitada de finalização e sinaliza o término dessa rotina auxiliar.
    def finalizar_servidor(self):
        try:
            print("CONEXAO: aguardando inicialização ou término do servidor.")
            limite_inicializacao = time.monotonic() + 10
            while (
                not self.servidor_inicializado.is_set()
                and not self.servidor_encerrado.is_set()
            ):
                if time.monotonic() >= limite_inicializacao:
                    print(
                        "CONEXAO: timeout aguardando inicialização "
                        "do servidor."
                    )
                    self.finalizacao_confirmada = False
                    return
                self.servidor_encerrado.wait(timeout=0.1)

            if (
                self.servidor_inicializado.is_set()
                and not self.servidor_encerrado.is_set()
            ):
                self.solicitar_parada_local()

            if not self.servidor_encerrado.wait(timeout=10):
                print(
                    "CONEXAO: aviso — servidor não confirmou "
                    "encerramento em 10 segundos."
                )
                self.finalizacao_confirmada = False
                return
            if getattr(self, 'saida_aplicacao', None) is not None:
                print('CONEXAO: rotina do servidor retornou; aplicacao pendente da coordenacao B2.')
            else:
                print("CONEXAO: encerramento do servidor confirmado.")
            self.finalizacao_confirmada = getattr(self, 'saida_aplicacao', None) is None
        finally:
            self.finalizacao_concluida.set()

    # Reconsulta os sinais sem bloquear o Tk; o caminho operacional também consulta SaidaAplicacao.
    def verificar_finalizacao(self):
        if getattr(self, 'saida_aplicacao', None) is not None:
            if self.saida_aplicacao.obter_situacao()['parada_operacional_confirmada']:
                return self.concluir_encerramento_confirmado()
            # O evento legado nao comprova a parada dos donos da aplicacao.
            with self.lock_encerramento:
                self.estado_encerramento = 'encerramento_pendente_b2'
                self.finalizacao_confirmada = False
                self.verificacao_finalizacao_ativa = False
            return
        with self.lock_encerramento:
            if self.estado_encerramento == "encerrado":
                return
            confirmado = not self.servidor_iniciado or self.servidor_encerrado.is_set()
            registrar_falha = (
                not confirmado
                and self.finalizacao_concluida.is_set()
                and self.estado_encerramento != "falha"
            )
            if registrar_falha:
                self.estado_encerramento = "falha"
        if confirmado:
            self.concluir_encerramento_confirmado()
            return
        if registrar_falha:
            print(
                "CONEXAO: tentativa de encerramento terminou "
                "sem confirmação. Aguardando recuperação."
            )
        self._agendar(100, self.verificar_finalizacao)

    # Fecha monitor e raiz respeitando a confirmação exigida pelo caminho operacional.
    def concluir_encerramento_confirmado(self):
        if getattr(self, 'saida_aplicacao', None) is not None:
            if not self.saida_aplicacao.obter_situacao()['parada_operacional_confirmada']:
                return False
        with self.lock_encerramento:
            if self.estado_encerramento == "encerrado":
                return
            self.estado_encerramento = "encerrado"
            self.verificacao_finalizacao_ativa = False
        if self.servidor_iniciado:
            print("CONEXAO: encerramento do servidor confirmado.")
        else:
            print("CONEXAO: concluindo encerramento sem servidor local.")
        monitor = getattr(self, 'monitor', None)
        reconfigurar = (getattr(self, '_reiniciar_admin', False)
                       or getattr(monitor, 'reconfiguracao_solicitada', False))
        if monitor is not None:
            # A raiz de conexão é a dona: só reabre após destruir ambas as telas.
            if reconfigurar:
                monitor.ao_reconfigurar = None
            monitor.concluir_fechamento()
        from interface.ciclo_tk import ciclo
        ciclo(self).fechar()
        self.root.destroy()
        if reconfigurar and self.ao_reconfigurar is not None:
            self.ao_reconfigurar()
        if getattr(self, 'saida_aplicacao', None) is not None:
            print('CONEXAO: parada operacional comprovada no escopo acompanhado; cobertura global desconhecida.')
        else:
            print("CONEXAO: aplicação encerrada.")

    # Prepara os eventos e o trabalhador de finalização do caminho local de encerramento.
    def iniciar_tentativa_encerramento(self):
        with self.lock_encerramento:
            if self.estado_encerramento in ("finalizando", "encerrado"):
                return False
            if self.servidor_encerrado.is_set():
                print(
                    "CONEXAO: servidor já encerrado; "
                    "aguardando conclusão pela interface."
                )
                return False
            if self.estado_encerramento == "falha":
                if not self.finalizacao_concluida.is_set():
                    return False
            if self.thread_finalizacao is not None and self.thread_finalizacao.is_alive():
                return False
            self.estado_encerramento = "finalizando"
            self.encerramento_solicitado.set()
            self.finalizacao_concluida.clear()
            self.finalizacao_confirmada = False
            iniciar_verificacao = not self.verificacao_finalizacao_ativa
            self.verificacao_finalizacao_ativa = True

            print("CONEXAO: iniciando tentativa de encerramento.")
            if self.servidor_iniciado:
                self.thread_finalizacao = threading.Thread(
                    target=self.finalizar_servidor,
                    daemon=True,
                )
                # Publica e inicia sob o lock para impedir outra tentativa
                # antes de a thread passar a responder is_alive().
                self.thread_finalizacao.start()
            else:
                self.finalizacao_confirmada = getattr(self, 'saida_aplicacao', None) is None
                self.finalizacao_concluida.set()

        if iniciar_verificacao:
            self._agendar(100, self.verificar_finalizacao)
        return True

    # Encaminha ao dono operacional quando disponível e conserva o caminho local de compatibilidade.
    def encerrar_aplicacao(self, *, _encaminhada=False):
        if not _encaminhada and getattr(self, 'saida_aplicacao', None) is not None:
            return self._callback_saida()
        tentativa_iniciada = self.iniciar_tentativa_encerramento()
        iniciar_verificacao = False
        if not tentativa_iniciada:
            print("CONEXAO: encerramento já em andamento ou concluído.")
        with self.lock_encerramento:
            if not tentativa_iniciada:
                if (
                    self.estado_encerramento == "encerrado"
                    or not self.servidor_encerrado.is_set()
                ):
                    return
                # O servidor pode ter terminado antes do primeiro pedido:
                # limpa o leitor e garante conclusão no loop da interface.
                self.encerramento_solicitado.set()
                iniciar_verificacao = not self.verificacao_finalizacao_ativa
                self.verificacao_finalizacao_ativa = True
            leitor = self.leitor_rebaixado
            self.leitor_rebaixado = None
        if leitor is not None:
            leitor.parar()
            print("CONEXAO: leitor de CLIENTE encerrado.")
        if iniciar_verificacao:
            self._agendar(100, self.verificar_finalizacao)

    # Mantém a janela disponível e mostra que a parada ainda não foi confirmada.
    def informar_encerramento_pendente(self, estado):
        from interface.ciclo_tk import ciclo
        if not ciclo(self).valido(encerramento=True):
            return
        self.label_status.config(text='Encerramento pendente: ' + estado, fg='red')
        monitor = getattr(self, 'monitor', None)
        if monitor is not None:
            monitor.informar_encerramento_pendente(estado)

    # Oculta o formulário, cria o monitor com os callbacks existentes e conecta o acompanhamento de saída.
    def abrir_monitor_tcp_local(self, leitor):
        if self.saida_aplicacao.parada_solicitada:
            return
        self.root.withdraw()
        self._callback_saida = self.saida_aplicacao.vincular(
            'monitor_tcp_local', lambda: self.encerrar_aplicacao(_encaminhada=True))
        self.monitor = JanelaTC420(master=self.root, ao_fechar=self._callback_saida,
                                 ao_reconfigurar=self.ao_reconfigurar)
        self.monitor.saida_aplicacao = self.saida_aplicacao
        self.monitor.infraestrutura_cliente = self.infraestrutura_cliente
        self.saida_aplicacao.conectar_interface(
            self._callback_saida, self.agendar_saida, self.concluir_encerramento_confirmado,
            self.informar_encerramento_pendente)
        self.monitor.configurar_tcp_local(leitor)
        self.monitor.atualizar_refresh_web()

    def abrir_monitor(self):
        if self.saida_aplicacao.parada_solicitada:
            return
        # Esconde a tela de conexão
        self.root.withdraw()

        self._callback_saida = self.saida_aplicacao.vincular(
            'monitor_principal_manual', lambda: self.encerrar_aplicacao(_encaminhada=True))

        # Cria o monitor usando a MESMA sessão web
        self.monitor = JanelaTC420(
            web=self.web,
            configuracao=self.configuracao,
            fonte_dados=obter_dados_atuais,
            servidor_encerrado=self.servidor_encerrado.is_set,
            ao_reconfigurar=self.ao_reconfigurar,
            master=self.root,
            ao_fechar=self._callback_saida,
        )
        self.saida_aplicacao.conectar_interface(
            self._callback_saida, self.agendar_saida, self.concluir_encerramento_confirmado,
            self.informar_encerramento_pendente)
        self.monitor.saida_aplicacao = self.saida_aplicacao
        self.monitor.infraestrutura_cliente = self.infraestrutura_cliente
        self.monitor.supervisionar_principal(self.contexto_ciclo_servidor)
        self.monitor.atualizar_refresh_web()

    # =========================================================
    # EXECUTAR
    # =========================================================

    # Mantém o mainloop e encaminha ao chamador a transição para cliente se um servidor foi encontrado.
    def executar(self):
        self.root.mainloop()
        servidor = getattr(self, '_servidor_encontrado', None)
        if servidor is not None and not self.saida_aplicacao.parada_solicitada:
            self.ao_encontrar_servidor(servidor)

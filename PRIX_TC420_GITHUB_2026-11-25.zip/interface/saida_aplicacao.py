# Saída coordenada: pedido, limpeza acompanhada e confirmação operacional são etapas distintas.
"""Saida operacional B2: identidade dos donos, espera limitada e Tk observador."""
from contextlib import contextmanager
from threading import Lock, Event, Thread
from time import monotonic


# É o dono da saída operacional: acompanha trabalhos, leitores, ciclos e tarefas de limpeza.
class SaidaAplicacao:
    # Prepara o estado protegido por lock e o prazo máximo de cada avaliação de parada.
    def __init__(self, *, prazo=10, intervalo=0.05):
        self._lock = Lock()
        self._vinculo = None
        self._origem = None
        self._solicitada = False
        self._erro_encaminhamento = None
        self._infra = None
        self._registro = None
        self._registros = []
        self._habilitada = False
        self._parada = Event()
        self._leitores = []
        self._contextos = []
        self._threads = []
        self._trabalhos = 0
        self._tarefas = {}
        self._coordenacao = None
        self._estado = 'executando'
        self._pendencias = []
        self._erros = []
        self._prazo, self._intervalo = prazo, intervalo
        self._tentativa = 0
        self._gate_falhou = False
        self.ao_reconfigurar = None
        self._promocao_ativa = False

    def ciclos_aptos_promocao(self):
        """Consulta positiva dos ciclos/tentativas; não certifica cobertura global."""
        from rede.servidor import avaliar_encerramento_aplicacao, avaliar_encerramento_tentativa
        with self._lock:
            if self._solicitada:
                return False
            contextos, registros = tuple(self._contextos), tuple(self._registros)
        try:
            for registro in registros:
                estado = avaliar_encerramento_aplicacao(registro)
                if not estado['consistente'] or estado['pendentes'] or estado['desconhecidas']:
                    return False
            registrados = {id(t.contexto) for r in registros
                           for t in r.obter_retrato()['tentativas']}
            for contexto in contextos:
                if id(contexto) not in registrados:
                    if avaliar_encerramento_tentativa(contexto)['encerramento_confirmado'] is not True:
                        situacao = contexto.obter_situacao()
                        if not (situacao['reserva_resolvida'] is True
                                and situacao['coordenador_retornou'] is True
                                and situacao['ciclo_id'] is None
                                and situacao['erro_reserva'] == 'falha_antes_reserva'
                                and situacao['erro_coordenador'] is None):
                            return False
            return True
        except Exception:
            return False

    @contextmanager
    def promocao(self):
        """Uma partida por aplicação; saída mantém os mesmos gates de trabalho/start."""
        with self._lock:
            if self._promocao_ativa or self._solicitada:
                raise RuntimeError('promocao_ou_saida_em_curso')
            self._promocao_ativa = True
        try:
            if not self.ciclos_aptos_promocao():
                raise RuntimeError('ciclo_anterior_pendente')
            with self.trabalho():
                yield
        finally:
            with self._lock:
                self._promocao_ativa = False

    # Expõe o evento de parada para bloquear partidas novas nos caminhos que consultam este dono.
    @property
    def parada_solicitada(self):
        return self._parada.is_set()

    # Consulta a identidade da interface vinculada, usada para recusar callbacks antigos.
    @property
    def identidade_interface(self):
        with self._lock:
            return self._vinculo

    # Associa a infraestrutura e registros compatíveis à saída, recusando substituição durante encerramento.
    def configurar(self, infraestrutura=None, registro=None):
        if infraestrutura is not None:
            from rede.infraestrutura_cliente import exigir_infraestrutura_http, InfraestruturaHttpInvalida
            try:
                exigir_infraestrutura_http(infraestrutura)
            except InfraestruturaHttpInvalida:
                # A entrada HTTP conserva sua validacao e mensagem originais.
                return
        with self._lock:
            if self._solicitada and (infraestrutura is not None and self._infra is not infraestrutura
                    or registro is not None and not any(r is registro for r in self._registros)):
                raise RuntimeError('encerramento_em_curso')
            if self._infra is not None and infraestrutura is not None and self._infra is not infraestrutura:
                raise ValueError('infraestrutura_de_outra_execucao')
            if infraestrutura is not None:
                self._infra = infraestrutura
            if registro is not None:
                self._registro = registro
                if not any(r is registro for r in self._registros):
                    self._registros.append(registro)
            self._habilitada = self._infra is not None or self._registro is not None
        if infraestrutura is not None:
            infraestrutura.instalar_saida(self)

    # Conta uma seção de trabalho admitida e decrementa em finally para a saída enxergar inicializações em curso.
    @contextmanager
    def trabalho(self):
        from interface.ciclo_tk import operacao_worker
        operacao = operacao_worker.get()
        with self._lock:
            if self._solicitada or (operacao is not None and not operacao.permite(self, self._vinculo)):
                raise RuntimeError('encerramento_em_curso')
            self._trabalhos += 1
        try:
            yield
        finally:
            with self._lock:
                self._trabalhos -= 1

    # Executa uma função dentro da seção de trabalho acompanhada pelo dono da saída.
    def executar(self, funcao, *args, **kwargs):
        with self.trabalho():
            return funcao(*args, **kwargs)

    # Retém o leitor que deverá receber pedido de parada e ter sua thread observada.
    def acompanhar_leitor(self, leitor):
        with self._lock:
            if not any(l is leitor for l in self._leitores):
                self._leitores.append(leitor)

    # Retém o contexto do servidor para solicitar parada pelo ID correto e avaliar o término.
    def acompanhar_contexto(self, contexto):
        with self._lock:
            if not any(c is contexto for c in self._contextos):
                self._contextos.append(contexto)
            # Evento proprio da execucao: sobrevive ao clear global do servidor.
            contexto.parada_aplicacao = self._parada

    # Acompanha a thread antes de start para conservar partidas pendentes ou ambíguas na avaliação.
    def iniciar_thread(self, thread):
        from interface.ciclo_tk import operacao_worker
        operacao = operacao_worker.get()
        item = {'thread': thread, 'partida_pendente': True, 'start_falhou': False}
        with self._lock:
            if self._solicitada or (operacao is not None and not operacao.permite(self, self._vinculo)):
                return False
            self._threads.append(item)
        try:
            thread.start()
            return True
        except BaseException:
            with self._lock:
                item['start_falhou'] = True
            raise
        finally:
            # Start que lanca pode ter entrado: manter a thread acompanhada.
            with self._lock:
                item['partida_pendente'] = False

    # Associa a thread, o contexto e a tentativa do servidor ao acompanhamento da saída.
    def iniciar_servidor_thread(self, thread, contexto, registro, tentativa):
        self.acompanhar_contexto(contexto)
        if self.iniciar_thread(thread):
            return
        contexto.registrar_falha('falha_antes_reserva')
        contexto.registrar_retorno_coordenador()
        if registro is not None:
            registro.registrar_falha_partida(tentativa, 'falha_partida', execucao_nao_iniciada=True)
        raise RuntimeError('encerramento_em_curso')

    # Produz diagnóstico resumido por classe de erro, sem transportar a mensagem original.
    @staticmethod
    def _categoria(erro):
        return 'falha_io' if isinstance(erro, OSError) else 'falha_operacao'

    # Cria um callback de saída ligado à identidade da janela e à sua origem operacional.
    def vincular(self, origem, solicitar_parada=None):
        if solicitar_parada is not None and not callable(solicitar_parada):
            raise TypeError('destino_saida_invalido')
        vinculo = object()
        with self._lock:
            if self._solicitada:
                raise RuntimeError('saida_ja_solicitada')
            self._vinculo, self._origem = vinculo, origem

        # Deduplica o pedido da janela atual e inicia ou reavalia a coordenação de parada.
        def solicitar():
            # Inicializar antes da criação: não apagar a thread que será iniciada após fechar as admissões.
            coordenacao = None
            with self._lock:
                if vinculo is not self._vinculo:
                    return False
                if self._solicitada and (not self._habilitada or self._estado not in ('timeout', 'falha')):
                    return False
                if self._coordenacao is not None and self._coordenacao.is_alive():
                    return False
                self._solicitada = True
                self._parada.set()
                habilitada = self._habilitada
                if habilitada:
                    self._estado = 'parando'
                    self._tentativa += 1
                    try:
                        self._coordenacao = Thread(target=self._coordenar, daemon=True)
                        coordenacao = self._coordenacao
                    except Exception as erro:
                        self._estado = 'falha'
                        self._erros.append(self._categoria(erro))
                        coordenacao = None
                else:
                    self._estado = 'encerramento_pendente_b2'
            if habilitada:
                # Somente gates locais; nenhuma limpeza/espera na thread Tk.
                falha_gate = False
                acoes = [r.fechar_admissao for r in tuple(self._registros)]
                if self._infra is not None:
                    acoes.append(self._infra.bloquear_novos_trabalhos)
                for acao in acoes:
                    try:
                        acao()
                    except Exception as erro:
                        falha_gate = True
                        with self._lock:
                            self._erros.append(self._categoria(erro))
                with self._lock:
                    self._gate_falhou = falha_gate
                try:
                    if coordenacao is not None:
                        coordenacao.start()
                except Exception as erro:
                    with self._lock:
                        self._estado = 'falha'
                        self._erros.append(self._categoria(erro))
            elif solicitar_parada is not None:
                # Compatibilidade de entrada isolada B1, sem montagem operacional.
                try:
                    solicitar_parada()
                except Exception as erro:
                    with self._lock:
                        self._erro_encaminhamento = self._categoria(erro)
            interface = getattr(solicitar, '_interface', None)
            if interface is not None:
                agendar, concluir, informar = interface
                self._observar_tk(vinculo, agendar, concluir, informar, self._tentativa)
            return True

        return solicitar

    # Guarda os callbacks Tk de agendamento, conclusão e informação no callback vinculado.
    def conectar_interface(self, callback, agendar, concluir, informar=None):
        # Chamado ao montar a janela no Tk; nao cria callbacks em workers.
        callback._interface = (agendar, concluir, informar)

    # Só conclui a janela após confirmação operacional e saída do coordenador; pendências mantêm a janela aberta.
    def _observar_tk(self, vinculo, agendar, concluir, informar, tentativa):
        with self._lock:
            if vinculo is not self._vinculo or tentativa != self._tentativa:
                return
            estado = self._estado
        if estado == 'confirmado_operacional':
            if self._coordenacao is not None and self._coordenacao.is_alive():
                agendar(100, lambda: self._observar_tk(vinculo, agendar, concluir, informar, tentativa))
            else:
                concluir()
        elif estado == 'parando':
            agendar(100, lambda: self._observar_tk(vinculo, agendar, concluir, informar, tentativa))
        else:
            print('SAIDA: encerramento pendente:', estado, '- solicite SIM para reavaliar.')
            if informar is not None:
                informar(estado)

    # Inicia uma tarefa de limpeza por chave, conserva erro e permite observação sem bloquear o Tk.
    def _lancar_tarefa(self, chave, funcao):
        with self._lock:
            if chave in self._tarefas:
                return
            item = {'concluida': False, 'erro': None, 'thread': None, 'start_incerto': False}
            self._tarefas[chave] = item
        # Executa uma função dentro da seção de trabalho acompanhada pelo dono da saída.
        def executar():
            try:
                funcao()
            except BaseException as erro:
                with self._lock:
                    item['erro'] = self._categoria(erro)
                    self._erros.append(item['erro'])
            finally:
                with self._lock:
                    item['concluida'] = True
        try:
            thread = Thread(target=executar, daemon=True)
            item['thread'] = thread
            item['start_incerto'] = True
            thread.start()
            item['start_incerto'] = False
        except BaseException as erro:
            with self._lock:
                item['erro'] = self._categoria(erro)
                item['concluida'] = True
                self._erros.append(item['erro'])

    # Considera conclusão, vida da thread e incerteza de start ao decidir se ainda existe trabalho pendente.
    @staticmethod
    def _tarefa_ativa(item):
        thread = item['thread']
        return (not item['concluida'] or thread is not None and (
            thread.is_alive() or item['start_incerto'] and getattr(thread, 'ident', None) is None))

    # No worker, solicita paradas e reavalia donos e recursos até comprovar a parada operacional ou vencer o prazo.
    def _coordenar(self):
        limite = monotonic() + self._prazo
        # Reavaliacao explicita pode repetir somente uma tarefa falha ja terminada.
        with self._lock:
            self._tarefas = {k: v for k, v in self._tarefas.items()
                             if self._tarefa_ativa(v) or v['erro'] is None}
        while True:
            pendencias = []
            try:
                with self._lock:
                    leitores, contextos = tuple(self._leitores), tuple(self._contextos)
                    threads = tuple(dict(i) for i in self._threads)
                    trabalhos = self._trabalhos
                    if self._gate_falhou:
                        pendencias.append('falha_bloqueio_admissao')
                if trabalhos:
                    pendencias.append('inicializacoes_em_curso')
                for leitor in leitores:
                    self._lancar_tarefa(('leitor', id(leitor)), leitor.parar)
                    thread = getattr(leitor, 'thread', None)
                    if thread is not None and thread.is_alive():
                        pendencias.append('leitor_ativo')
                for item in threads:
                    if item['partida_pendente'] or item['thread'].is_alive():
                        pendencias.append('thread_acompanhada_ativa')
                    elif item['start_falhou'] and getattr(item['thread'], 'ident', None) is None:
                        pendencias.append('partida_incerta')
                from rede.servidor import solicitar_parada_ciclo, avaliar_encerramento_tentativa
                ausencias = set()
                for registro in tuple(self._registros):
                    for tentativa in registro.obter_retrato()['tentativas']:
                        if tentativa.estado_partida == 'falha_partida' and not tentativa.execucao_observada:
                            ausencias.add(tentativa.contexto)
                        if not any(c is tentativa.contexto for c in contextos):
                            self.acompanhar_contexto(tentativa.contexto)
                for contexto in contextos:
                    situacao = contexto.obter_situacao()
                    ciclo = situacao['ciclo_id']
                    if ciclo is not None:
                        if avaliar_encerramento_tentativa(contexto)['encerramento_confirmado'] is not True:
                            self._lancar_tarefa(('ciclo', ciclo), lambda c=ciclo: solicitar_parada_ciclo(c))
                            pendencias.append('ciclo_pendente')
                    elif not (situacao['reserva_resolvida'] and (
                            situacao['coordenador_retornou'] or contexto in ausencias)):
                        pendencias.append('partida_servidor_pendente')
                if self._infra is not None:
                    self._infra.observar_termino_leitores()
                    self._infra.observar_termino_retentativas()
                    with self._lock:
                        limpeza_ativa = any(self._tarefa_ativa(t) for t in self._tarefas.values())
                    retries = self._infra.registro_retentativas.obter_retrato()['retentativas']
                    permitir_retidos = (not trabalhos and not pendencias and not limpeza_ativa
                        and all(r['thread_terminada'] or r['ausencia_comprovada'] for r in retries))
                    for chave, funcao in self._infra.tarefas_encerramento(
                            leitores, limpar_retidos=permitir_retidos):
                        self._lancar_tarefa(chave, funcao)
                    pendencias.extend(self._infra.pendencias_encerramento())
                with self._lock:
                    if any(self._tarefa_ativa(t) for t in self._tarefas.values()):
                        pendencias.append('limpeza_em_curso')
                    falha = any(t['erro'] for t in self._tarefas.values()) or any(
                        p.startswith('falha_') for p in pendencias)
                    # Fence final: nenhum trabalho admitido ou partida desaparece.
                    if self._trabalhos or len(leitores) != len(self._leitores) or len(contextos) != len(self._contextos):
                        pendencias.append('dono_tardio')
                    self._pendencias = sorted(set(pendencias))
                    if not pendencias and not falha:
                        self._estado = 'confirmado_operacional'
                        return
                    if monotonic() >= limite:
                        self._estado = 'falha' if falha else 'timeout'
                        return
            except BaseException as erro:
                with self._lock:
                    self._erros.append(self._categoria(erro))
                    self._estado = 'falha'
                return
            # Espera limitada apenas no worker; Event de parada ja esta setado.
            Event().wait(self._intervalo)

    # Copia o diagnóstico; confirmado_operacional não equivale à certificação global de encerramento.
    def obter_situacao(self):
        with self._lock:
            return {'estado': self._estado, 'origem': self._origem,
                    'solicitada': self._solicitada,
                    'erro_encaminhamento': self._erro_encaminhamento,
                    'pendencias': list(self._pendencias), 'erros': list(self._erros),
                    'tentativa': self._tentativa,
                    'parada_operacional_confirmada': self._estado == 'confirmado_operacional',
                    'encerramento_confirmado': False,
                    'encerramento_global_confirmado': False}

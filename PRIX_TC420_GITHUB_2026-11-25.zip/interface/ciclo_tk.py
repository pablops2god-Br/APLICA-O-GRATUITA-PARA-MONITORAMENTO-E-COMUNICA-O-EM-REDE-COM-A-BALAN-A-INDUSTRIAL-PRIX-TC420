# Concorrência gráfica: fila liga workers ao Tk e a geração invalida callbacks antigos.
"""Fila de resultados e agendamentos de uma janela; Tk somente na thread dona."""
from queue import SimpleQueue, Empty
from threading import Thread, get_ident
from threading import Event
from contextvars import ContextVar


operacao_worker = ContextVar('operacao_interface', default=None)


# Identifica uma operação pelo dono da saída e pela janela que a admitiu, com sinal de cancelamento.
class OperacaoInterface:
    # Captura a identidade atual da janela e cria o evento de cancelamento desta operação.
    def __init__(self, saida):
        self.saida = saida
        self.vinculo = saida.identidade_interface
        self.cancelada = Event()

    # Sinaliza cancelamento lógico; não força a interrupção da thread que executa o trabalho.
    def set(self):
        self.cancelada.set()

    # Consulta o sinal de cancelamento da operação.
    def is_set(self):
        return self.cancelada.is_set()

    # Exige operação não cancelada e as mesmas identidades de saída e janela.
    def permite(self, saida, vinculo):
        return not self.is_set() and self.saida is saida and self.vinculo is vinculo


# Centraliza agendamentos e resultados; somente a thread dona da janela pode chamar Tk.
class CicloTk:
    # Registra a thread dona, prepara a fila e acompanha a destruição da raiz.
    def __init__(self, root, obter_saida):
        self.root = root
        self.obter_saida = obter_saida
        self.dona = get_ident()
        self.aberto = True
        self.geracao = object()
        self.agendados = set()
        self.operacoes = {}
        self.fila = SimpleQueue()
        if self.valido(encerramento=True):
            self.root.bind('<Destroy>', self._destruida, add='+')
        else:
            self.aberto = False

    # Invalida a geração e cancela os agendamentos quando a própria raiz é destruída.
    def _destruida(self, evento):
        if evento.widget is self.root:
            self.aberto = False
            self.geracao = object()
            for token in self.operacoes.values():
                token.set()
            self.operacoes.clear()
            for identidade in tuple(self.agendados):
                self.root.after_cancel(identidade)
            self.agendados.clear()

    # Detecta uso de Tk por outra thread antes de acessar a janela.
    def _tk(self):
        if get_ident() != self.dona:
            raise RuntimeError('tk_fora_da_thread_dona')

    # Verifica dono, existência da janela e pedido de parada, com exceção explícita para observação da saída.
    def valido(self, *, encerramento=False):
        self._tk()
        if not self.aberto:
            return False
        saida = self.obter_saida()
        if not encerramento and saida is not None and saida.parada_solicitada:
            return False
        from tkinter import TclError
        try:
            return bool(self.root.winfo_exists())
        except TclError as erro:
            if 'application has been destroyed' in str(erro):
                self.aberto = False
                return False
            raise

    # Guarda a geração e o ID de after para que callbacks antigos sejam descartados ou cancelados.
    def agendar(self, prazo, callback, *args, encerramento=False):
        if not self.valido(encerramento=encerramento):
            return None
        geracao = self.geracao
        identidade = [None]

        # Remove o ID do conjunto pendente e verifica a geração novamente antes de executar o callback.
        def aplicar():
            self.agendados.discard(identidade[0])
            if geracao is self.geracao and self.valido(encerramento=encerramento):
                callback(*args)

        identidade[0] = self.root.after(prazo, aplicar)
        self.agendados.add(identidade[0])
        return identidade[0]

    # Reutiliza o agendador permitindo callbacks necessários ao acompanhamento de encerramento.
    def agendar_saida(self, prazo, callback):
        return self.agendar(prazo, callback, encerramento=True)

    # Recusa chave duplicada, executa trabalho em worker e devolve resultado pela fila para aplicação no Tk.
    def iniciar(self, chave, trabalho, aplicar):
        if not self.valido() or chave in self.operacoes:
            return False
        saida = self.obter_saida()
        if saida is None:
            raise RuntimeError('worker_sem_proprietario')
        token = OperacaoInterface(saida)
        self.operacoes[chave] = token
        vinculo = token.vinculo

        # Instala o contexto do worker, executa o trabalho e publica retorno ou erro sanitizado na fila.
        def executar():
            contexto = operacao_worker.set(token)
            resultado, erro = None, None
            try:
                with saida.trabalho():
                    resultado = trabalho()
            except Exception as falha:
                # Nao transportar traceback/locals com credenciais para o Tk.
                from interface.mensagens_seguras import mensagem_erro_login
                erro = mensagem_erro_login(falha)
                print('Operacao de interface falhou:', type(falha).__name__)
            finally:
                operacao_worker.reset(contexto)
                self.fila.put((chave, token, resultado, erro,
                               (aplicar, saida, vinculo)))

        try:
            if not saida.iniciar_thread(Thread(target=executar, daemon=True)):
                self.operacoes.pop(chave, None)
                return False
        except BaseException:
            self.operacoes.pop(chave, None)
            raise
        self.agendar(25, self.consumir)
        return True

    # Enfileira dados de outra thread; esta função não chama métodos Tk.
    def publicar(self, callback, *args):
        """Publicacao sem qualquer chamada Tk, inclusive para o leitor legado."""
        self.fila.put((None, self.geracao, args, None, callback))

    # Drena a fila no Tk e aplica apenas retornos que ainda correspondam à geração e às identidades atuais.
    def consumir(self):
        if not self.valido():
            return
        while True:
            try:
                chave, token, resultado, erro, aplicar = self.fila.get_nowait()
            except Empty:
                break
            if chave is None:
                if token is self.geracao and self.valido():
                    aplicar(*resultado)
            elif self.operacoes.get(chave) is token:
                del self.operacoes[chave]
                callback, saida, vinculo = aplicar
                if (self.valido() and saida is self.obter_saida()
                        and vinculo is saida.identidade_interface):
                    callback(None if token.is_set() else resultado, erro)
        if self.operacoes:
            self.agendar(25, self.consumir)

    # Invalida a geração, sinaliza cancelamentos e remove os after ainda agendados.
    def fechar(self):
        self._tk()
        self.aberto = False
        self.geracao = object()
        for token in self.operacoes.values():
            token.set()
        self.operacoes.clear()
        for identidade in tuple(self.agendados):
            self.root.after_cancel(identidade)
        self.agendados.clear()

    # Cancela logicamente uma operação pela chave sem esperar a thread terminar.
    def cancelar(self, chave):
        self._tk()
        token = self.operacoes.get(chave)
        if token is not None:
            token.set()


# Cria sob demanda o controlador associado à janela e reutiliza a mesma instância nas chamadas seguintes.
def ciclo(janela):
    """Criacao lazy permite injetar a mesma janela em caracterizacoes isoladas."""
    atual = getattr(janela, '_ciclo_tk', None)
    if atual is None:
        atual = CicloTk(janela.root, lambda: getattr(janela, 'saida_aplicacao', None))
        janela._ciclo_tk = atual
    return atual


# Combina a flag de execução da janela com as verificações de validade do ciclo Tk.
def ativa(janela):
    if not getattr(janela, 'executando', True):
        return False
    return ciclo(janela).valido()

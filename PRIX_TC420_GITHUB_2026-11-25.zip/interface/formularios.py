"""Estilo aprovado dos formulários; não executa autenticação ou rede."""
from pathlib import Path
from types import SimpleNamespace
import subprocess
import sys
import tkinter as tk

PRETO, CARD, TEXTO, SUAVE, VERDE = '#080a0b', '#171b1e', '#f4f7f6', '#9aa6ad', '#a0dc45'

class Dica:
    """Nome sobreposto ao manter o mouse no botão; sem capturar foco."""
    def __init__(self, widget, texto):
        self.widget, self.texto = widget, texto
        self.popup = None
        self.timer = None
        widget.bind('<Enter>', self.agendar)
        widget.bind('<Leave>', self.ocultar)
        widget.bind('<ButtonPress>', self.ocultar, add='+')
        widget.bind('<Destroy>', self.ocultar, add='+')

    def agendar(self, _evento=None):
        self.ocultar()
        self.timer = self.widget.after(450, self.mostrar)

    def mostrar(self):
        self.ocultar()
        self.popup = tk.Toplevel(self.widget)
        self.popup.overrideredirect(True)
        texto = self.texto() if callable(self.texto) else self.texto
        tk.Label(self.popup, text=texto, bg=CARD, fg=TEXTO, wraplength=380,
                 justify='left', font=('Segoe UI', 11), padx=10, pady=6).pack()
        self.popup.update_idletasks()
        x = min(self.widget.winfo_rootx(),
                self.widget.winfo_screenwidth() - self.popup.winfo_reqwidth() - 8)
        y = max(0, self.widget.winfo_rooty() - self.popup.winfo_reqheight() - 6)
        self.popup.geometry(f'+{max(0, x)}+{y}')

    def ocultar(self, _evento=None):
        if self.timer is not None:
            self.widget.after_cancel(self.timer)
            self.timer = None
        if self.popup is not None:
            self.popup.destroy()
            self.popup = None

def centralizar(janela, largura, altura):
    janela.update_idletasks()
    x = max(0, (janela.winfo_screenwidth() - largura) // 2)
    y = max(0, (janela.winfo_screenheight() - altura) // 2)
    janela.geometry(f'{largura}x{altura}+{x}+{y}')

def abrir_ensaio():
    """Atalho de diagnóstico: somente harness local, sem shell."""
    from tkinter import messagebox
    raiz = Path(__file__).resolve().parents[1]
    script = raiz / 'tests' / 'ensaio_visual_tk.py'
    if getattr(sys, 'frozen', False) or not script.is_file():
        messagebox.showinfo('Ensaio visual', 'Ensaio visual indisponível nesta distribuição.')
        return
    try:
        subprocess.Popen([sys.executable, '-B', str(script)], cwd=str(raiz),
                         creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0)
    except OSError as erro:
        messagebox.showerror('Ensaio visual', 'Não foi possível abrir: ' + type(erro).__name__)


def criar_botao(area, texto, comando, destaque=False):
    return tk.Button(area, text=texto, command=comando, cursor='hand2',
                     bg=VERDE if destaque else CARD, fg=PRETO if destaque else TEXTO,
                     activebackground='#b4ed64', activeforeground=PRETO, bd=0,
                     relief='flat', pady=10, height=1, font=('Segoe UI', 18, 'bold'))

def montar_formulario(janela, assumir, confirmar, administrador_dono=None):
    administrador_dono = administrador_dono or getattr(janela, '_administrador_dono', None)
    janela.configure(bg=PRETO)
    janela.resizable(False, False)
    centralizar(janela, 560, 600 if not assumir else 550)
    raiz_assets = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[1]))
    icone = tk.PhotoImage(master=janela, file=str(raiz_assets / 'assets/logotc420.png'))
    janela.iconphoto(False, icone)
    janela.icone_formulario = icone
    faixa_rodape = tk.Frame(janela, bg=PRETO)
    faixa_rodape.pack(side='bottom', fill='x', padx=20, pady=(0, 10))
    quadrado = tk.Frame(faixa_rodape, bg=CARD, width=34, height=34)
    quadrado.pack(side='right', padx=(10, 0))
    quadrado.pack_propagate(False)
    def ensaio_protegido():
        from interface.administrador import controle_atual
        controle = controle_atual()
        if controle is not None and administrador_dono is not None:
            return controle.pedir(administrador_dono, 'Acesso ao ensaio visual', abrir_ensaio)
        return abrir_ensaio()
    atalho = tk.Button(quadrado, text='▦', command=ensaio_protegido,
                       bg=CARD, fg=TEXTO, activebackground=VERDE,
                       activeforeground=PRETO, relief='flat', bd=0,
                       font=('Segoe UI', 14), cursor='hand2')
    atalho.pack(fill='both', expand=True)
    dica = Dica(atalho, 'Abrir ensaio visual Tk')
    rodape = tk.Label(faixa_rodape, text='v0.0.1 · Pablops2god',
                      bg=PRETO, fg=SUAVE, font=('Segoe UI', 14), anchor='e')
    rodape.pack(side='right')
    area = tk.Frame(janela, bg=PRETO)
    area.pack(fill='both', expand=True, padx=22, pady=(10, 4))
    titulo = tk.Frame(area, bg=PRETO)
    titulo.pack(fill='x', pady=(5, 4))
    # Lanczos suaviza a redução; preserva proporção e canal de transparência.
    janela.tamanho_logo = 90
    caminho_logo = raiz_assets / 'assets' / 'logotc420.png'
    try:
        from PIL import Image, ImageTk
    except ModuleNotFoundError:
        # Asset pré-calculado com Lanczos: mesmo resultado sem dependência no runtime.
        if janela.tamanho_logo != 90:
            raise RuntimeError('Para outro tamanho, instale tests/requirements-visual.txt') from None
        janela.logo_titulo = tk.PhotoImage(
            master=janela, file=str(caminho_logo.with_name('logotc420-90-lanczos.png')))
    else:
        with Image.open(caminho_logo) as original:
            logo_reduzida = original.convert('RGBA')
            logo_reduzida.thumbnail((janela.tamanho_logo, janela.tamanho_logo),
                                   Image.Resampling.LANCZOS)
        janela.logo_titulo = ImageTk.PhotoImage(logo_reduzida, master=janela)
    logo = tk.Label(titulo, image=janela.logo_titulo, bg=PRETO)
    logo.pack(side='right', padx=(8, 0))
    textos_titulo = tk.Frame(titulo, bg=PRETO)
    textos_titulo.pack(side='left')
    tk.Label(textos_titulo, text='PRIX / TC420', bg=PRETO, fg=VERDE,
             font=('Segoe UI', 14)).pack(anchor='w')
    tk.Label(textos_titulo, text='Assumir o serviço' if assumir else 'Conectar à balança',
             bg=PRETO, fg=TEXTO, font=('Segoe UI', 18, 'bold')).pack(anchor='w')
    label_status = tk.Label(area, text='Configure o acesso à TC420', bg=PRETO,
             fg=SUAVE, font=('Segoe UI', 14), wraplength=510,
             justify='left')
    label_status.pack(anchor='w', pady=(0, 10))
    grade = tk.Frame(area, bg=PRETO)
    grade.pack(fill='x')
    grade.columnconfigure(1, weight=1)
    campos = [('IP da TC420', ''), ('Porta TCP', ''),
              ('Usuário', ''), ('Senha', '')]
    if not assumir:
        campos.insert(0, ('Nome da balança', ''))
    entradas = {}
    for linha, (nome, valor) in enumerate(campos):
        tk.Label(grade, text=nome, bg=PRETO, fg=SUAVE,
                 font=('Segoe UI', 14)).grid(row=linha, column=0, sticky='w', padx=(0, 12), pady=3)
        campo = tk.Entry(grade, bg=CARD, fg=TEXTO, insertbackground=VERDE,
                         relief='flat', width=22, font=('Segoe UI', 14),
                         show='•' if nome == 'Senha' else '')
        campo.grid(row=linha, column=1, sticky='ew', ipady=5, pady=3)
        campo.insert(0, valor)
        entradas[nome] = campo
    metodos = tk.Frame(area, bg=PRETO)
    metodos.pack(fill='x', pady=(8, 2))
    tk.Label(metodos, text='Método de conexão', bg=PRETO, fg=SUAVE,
             font=('Segoe UI', 14)).pack(side='left', padx=(0, 8))
    metodo = tk.StringVar(master=janela, value='HTTPS')
    opcoes = {}
    for nome in ('HTTPS', 'TCP'):
        opcao = tk.Radiobutton(
            metodos, text=nome, value=nome, variable=metodo,
            bg=PRETO, fg=TEXTO, selectcolor=CARD, activebackground=PRETO,
            activeforeground=TEXTO, font=('Segoe UI', 14), cursor='hand2')
        opcao.pack(side='left', padx=(0, 6))
        opcoes[nome] = opcao
    informacao = tk.Canvas(metodos, width=28, height=28, bg=PRETO,
                           highlightthickness=0, cursor='hand2')
    informacao.create_oval(2, 2, 26, 26, fill=CARD, outline=SUAVE)
    informacao.create_text(14, 14, text='i', fill=TEXTO,
                           font=('Segoe UI', 14, 'bold'))
    informacao.pack(side='right')
    def explicar_metodo():
        if metodo.get() == 'HTTPS':
            return ('HTTPS: acesso web à TC420 com TLS, já utilizado pelo fluxo atual. '
                    'Requer usuário e senha e permite o fluxo de PRINCIPAL/CLIENTES.')
        return ('TCP: leitura local direta da balança pela porta informada '
                '(padrão 9800), sem usuário ou senha. Não cria servidor, '
                'não distribui dados e não participa da sucessão. '
                'O leitor legado informa somente o peso; TCP não criptografa os dados.')
    dica_metodo = Dica(informacao, explicar_metodo)
    informacao.bind('<ButtonRelease-1>', lambda _evento: dica_metodo.mostrar())
    salvar = tk.BooleanVar(master=janela, value=False)
    check_salvar = tk.Checkbutton(area, text='Salvar senha e ativar login automático', variable=salvar,
                   bg=PRETO, fg=TEXTO, selectcolor=CARD, activebackground=PRETO,
                   activeforeground=TEXTO, wraplength=470, justify='left',
                   font=('Segoe UI', 14))
    check_salvar.pack(anchor='w', pady=6)
    botao = criar_botao(area, 'ASSUMIR' if assumir else 'CONECTAR',
                      confirmar, True)
    botao.pack(fill='x')
    def atualizar_metodo(*_args):
        tcp = metodo.get() == 'TCP'
        estado = 'disabled' if tcp else 'normal'
        entradas['Usuário'].configure(state=estado)
        entradas['Senha'].configure(state=estado)
        check_salvar.configure(state=estado)
        botao.configure(text='CONECTAR TCP' if tcp else ('ASSUMIR' if assumir else 'CONECTAR'))
    metodo.trace_add('write', atualizar_metodo)
    atualizar_metodo()
    janela.botao_acao = botao
    janela.campos_modelo = campos
    janela.rodape_modelo = rodape
    janela.atalho_ensaio = atalho
    janela.dica_ensaio = dica
    janela.logo_widget = logo
    janela.metodo_conexao = metodo
    janela.opcoes_metodo = opcoes
    janela.dica_metodo = dica_metodo
    # Construção visual apenas: validação e trabalho pertencem aos callbacks existentes.
    return SimpleNamespace(entradas=entradas, salvar=salvar, metodo=metodo,
                           botao=botao, status=label_status, check_salvar=check_salvar)

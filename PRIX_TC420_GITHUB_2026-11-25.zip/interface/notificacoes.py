"""Bandeja e avisos Windows opcionais, executados somente no Tk."""
import ctypes as c
from ctypes import wintypes as w
import sys
import tkinter as tk
from time import monotonic

CONFIRMACAO_AVISO_TCP = 2.0

class BandejaWindows:
    """Shell_NotifyIcon nativo; callback preservado até restaurar WndProc."""
    def __init__(self, root, restaurar):
        self.root, self.restaurar = root, restaurar
        self.ativa, self.restauracao_pendente = False, False
        self.fechada, self.timer = False, None
        if sys.platform != 'win32':
            return
        self.user = c.WinDLL('user32', use_last_error=True)
        self.shell = c.WinDLL('shell32', use_last_error=True)
        class Dados(c.Structure):
            _fields_ = [('cbSize', w.DWORD), ('hWnd', w.HWND), ('uID', w.UINT),
                        ('uFlags', w.UINT), ('uCallbackMessage', w.UINT), ('hIcon', w.HICON),
                        ('szTip', w.WCHAR * 128), ('dwState', w.DWORD), ('dwStateMask', w.DWORD),
                        ('szInfo', w.WCHAR * 256), ('uTimeout', w.UINT),
                        ('szInfoTitle', w.WCHAR * 64), ('dwInfoFlags', w.DWORD),
                        ('guidItem', c.c_byte * 16), ('hBalloonIcon', w.HICON)]
        self.user.GetParent.argtypes, self.user.GetParent.restype = [w.HWND], w.HWND
        self.user.LoadIconW.argtypes, self.user.LoadIconW.restype = [w.HINSTANCE, c.c_void_p], w.HICON
        self.shell.Shell_NotifyIconW.argtypes = [w.DWORD, c.POINTER(Dados)]
        self.shell.Shell_NotifyIconW.restype = w.BOOL
        root.update_idletasks()
        self.hwnd = self.user.GetParent(root.winfo_id()) or root.winfo_id()
        self.dados = Dados()
        self.dados.cbSize, self.dados.hWnd, self.dados.uID = c.sizeof(Dados), self.hwnd, 1
        self.dados.uFlags, self.dados.uCallbackMessage = 1 | 2 | 4, 0x8001
        self.dados.hIcon = self.user.LoadIconW(None, c.c_void_p(32512))
        self.dados.szTip = 'PRIX TC420 | clique para restaurar'
        self.proc_tipo = c.WINFUNCTYPE(c.c_ssize_t, w.HWND, w.UINT, w.WPARAM, w.LPARAM)
        setter = 'SetWindowLongPtrW' if c.sizeof(c.c_void_p) == 8 else 'SetWindowLongW'
        self.setter = getattr(self.user, setter)
        self.setter.argtypes, self.setter.restype = [w.HWND, c.c_int, c.c_void_p], c.c_void_p
        self.user.CallWindowProcW.argtypes = [c.c_void_p, w.HWND, w.UINT, w.WPARAM, w.LPARAM]
        self.user.CallWindowProcW.restype = c.c_ssize_t
        def callback(hwnd, msg, wp, lp):
            if msg == 0x8001 and lp in (0x202, 0x203, 0x205, 0x405):
                self.restauracao_pendente = True
            return self.user.CallWindowProcW(self.anterior, hwnd, msg, wp, lp)
        self.callback = self.proc_tipo(callback)
        self.anterior = self.setter(self.hwnd, -4, c.cast(self.callback, c.c_void_p))
        if not self.anterior:
            raise c.WinError(c.get_last_error())
        self.ativa = bool(self.shell.Shell_NotifyIconW(0, c.byref(self.dados)))
        self.timer = root.after(100, self.verificar)

    def verificar(self):
        self.timer = None
        if self.fechada:
            return
        if self.restauracao_pendente:
            self.restauracao_pendente = False
            self.restaurar()
        self.timer = self.root.after(100, self.verificar)

    def notificar(self, titulo, mensagem, erro=False):
        if not self.ativa:
            return False
        self.dados.uFlags = 0x10
        self.dados.szInfoTitle, self.dados.szInfo = titulo[:63], mensagem[:255]
        self.dados.dwInfoFlags, self.dados.uTimeout = (3 if erro else 1), 5000
        return bool(self.shell.Shell_NotifyIconW(1, c.byref(self.dados)))

    def fechar(self):
        if self.fechada:
            return
        self.fechada = True
        if self.timer is not None:
            self.root.after_cancel(self.timer)
            self.timer = None
        if sys.platform == 'win32' and hasattr(self, 'anterior'):
            self.shell.Shell_NotifyIconW(2, c.byref(self.dados))
            self.setter(self.hwnd, -4, self.anterior)
            self.ativa = False


def preparar_monitor(monitor):
    """Sem alterar os widgets do monitor: centro, bandeja e limpeza no Destroy."""
    from interface.formularios import centralizar
    root = monitor.root
    if not isinstance(root, tk.Misc):
        return
    root.update_idletasks()
    centralizar(root, root.winfo_width(), root.winfo_height())
    def restaurar():
        if root.winfo_exists():
            root.deiconify()
            root.lift()
    try:
        bandeja = BandejaWindows(root, restaurar)
    except (OSError, tk.TclError) as erro:
        print('NOTIFICACOES: bandeja indisponível:', type(erro).__name__)
        return
    monitor._bandeja_windows = bandeja
    monitor._conexao_notificada = None
    def limpar(evento):
        if evento.widget is root:
            bandeja.fechar()
    root.bind('<Destroy>', limpar, add='+')


def notificar_estado(monitor, chave):
    """Avisa transições de disponibilidade, sem repetir a cada amostra."""
    bandeja = getattr(monitor, '_bandeja_windows', None)
    if bandeja is None or chave == 'promovendo':
        return
    conectado = chave in ('ap_ok', 'ct_ok', 'tcp_ok')
    anterior = getattr(monitor, '_conexao_notificada', None)
    if chave in ('tcp_ok', 'tcp_falha'):
        if not conectado and anterior is True:
            agora = monotonic()
            inicio = getattr(monitor, '_falha_tcp_desde', None)
            if inicio is None:
                monitor._falha_tcp_desde = agora
                return
            if agora - inicio < CONFIRMACAO_AVISO_TCP:
                return
        else:
            monitor._falha_tcp_desde = None
    else:
        monitor._falha_tcp_desde = None
    monitor._conexao_notificada = conectado
    if conectado == anterior or (anterior is None and not conectado):
        return
    if conectado:
        bandeja.notificar('PRIX TC420', 'Conexão estabelecida; recebendo leituras atuais.')
    else:
        mensagem = ('TCP local sem leitura atual. Verifique a balança e a conexão.'
                    if chave == 'tcp_falha' else
                    'Comunicação indisponível. Verifique o estado no monitor.')
        bandeja.notificar('PRIX TC420', mensagem, erro=True)

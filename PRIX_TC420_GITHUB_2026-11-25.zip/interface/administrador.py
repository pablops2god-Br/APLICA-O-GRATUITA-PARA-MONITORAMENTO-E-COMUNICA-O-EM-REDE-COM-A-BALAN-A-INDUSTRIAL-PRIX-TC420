"""Controle administrativo das telas; persistência e hash executados fora do Tk."""
import tkinter as tk
from tkinter import messagebox
from config import administrador as armazenamento
from interface.ciclo_tk import ciclo
from interface.formularios import PRETO, CARD, TEXTO, SUAVE, VERDE, centralizar

_controle = None


def controle_atual():
    return _controle


class ControleAdministrador:
    def __init__(self):
        self.autorizado = False
        self.tela = None

    def pedir(self, dono, origem, continuar):
        if self.tela is not None:
            self.tela.root.lift()
            return False
        self.tela = TelaAdministrador(self, dono, origem, continuar)
        return True


class TelaAdministrador:
    def __init__(self, controle, dono, origem, continuar):
        self.controle, self.dono, self.continuar = controle, dono, continuar
        self.saida_aplicacao = dono.saida_aplicacao
        self.root = tk.Toplevel(dono.root)
        self.root.configure(bg=PRETO)
        self.root.title('PRIX TC420 — Administrador')
        centralizar(self.root, 560, 480)
        self.root.resizable(False, False)
        self.root.protocol('WM_DELETE_WINDOW', self.cancelar)
        self.root.bind('<Escape>', lambda _e: self.cancelar())
        self.root.grab_set()
        area = tk.Frame(self.root, bg=PRETO)
        area.pack(fill='both', expand=True, padx=24, pady=18)
        self.titulo = tk.Label(area, text='Verificando cadastro...', bg=PRETO, fg=TEXTO,
                               font=('Segoe UI', 18, 'bold'))
        self.titulo.pack(anchor='w')
        tk.Label(area, text=origem, bg=PRETO, fg=SUAVE, font=('Segoe UI', 14)).pack(anchor='w', pady=10)
        tk.Label(area, text='Senha própria do administrador, diferente da senha da balança.',
                 wraplength=500, bg=PRETO, fg=SUAVE, font=('Segoe UI', 14)).pack(anchor='w')
        self.senha = tk.Entry(area, show='•', font=('Segoe UI', 14), bg=CARD, fg=TEXTO,
                              insertbackground=VERDE)
        self.senha.pack(fill='x', ipady=6, pady=10)
        self.repeticao = tk.Entry(area, show='•', font=('Segoe UI', 14), bg=CARD, fg=TEXTO,
                                  insertbackground=VERDE)
        self.status = tk.Label(area, text='', bg=PRETO, fg=SUAVE, wraplength=500, font=('Segoe UI', 12))
        self.status.pack(pady=8)
        self.botao = tk.Button(area, text='ENTRAR', state='disabled', command=self.confirmar,
                               bg=VERDE, fg=PRETO, font=('Segoe UI', 18, 'bold'), pady=8)
        self.botao.pack(fill='x')
        self.esqueci = tk.Button(area, text='Esqueci a senha', command=self.restaurar,
                                 bg=PRETO, fg=VERDE, relief='flat', font=('Segoe UI', 14))
        self.senha.bind('<Return>', lambda _e: self.confirmar())
        self.repeticao.bind('<Return>', lambda _e: self.confirmar())
        self.cadastro = False
        ciclo(self).iniciar('carregar', armazenamento.carregar, self.carregado)

    def carregado(self, dados, erro):
        if erro:
            self.status.config(text='Não foi possível ler o cadastro. Use a restauração para limpar os dados.')
            self.esqueci.pack(pady=10)
            return
        self.cadastro = dados is None
        self.titulo.config(text='Cadastro de administrador' if self.cadastro else 'Login de administrador')
        self.botao.config(text='CADASTRAR' if self.cadastro else 'ENTRAR', state='normal')
        if self.cadastro:
            self.repeticao.pack(before=self.status, fill='x', ipady=6, pady=5)
            self.status.config(text='Crie uma senha com pelo menos 8 caracteres e repita no segundo campo.')
        else:
            self.esqueci.pack(pady=10)
        self.senha.focus_set()

    def confirmar(self):
        if self.botao.cget('state') == 'disabled':
            return
        senha = self.senha.get()
        if self.cadastro and (len(senha) < 8 or senha != self.repeticao.get()):
            self.status.config(text='Use pelo menos 8 caracteres e confirme a mesma senha.')
            return
        self.senha.delete(0, 'end')
        self.repeticao.delete(0, 'end')
        self.botao.config(state='disabled')
        acao = armazenamento.cadastrar if self.cadastro else armazenamento.verificar
        ciclo(self).iniciar('autenticar', lambda: acao(senha), self.aplicar)

    def aplicar(self, resultado, erro):
        if erro or not resultado:
            self.status.config(text='Acesso não autorizado ou falha ao salvar o cadastro.')
            self.botao.config(state='normal')
            return
        dono, continuar, cadastro = self.dono, self.continuar, self.cadastro
        self.fechar()
        if cadastro:
            self.controle.pedir(dono, 'Entre com a senha recém-cadastrada', continuar)
        else:
            self.controle.autorizado = True
            continuar()

    def restaurar(self):
        if any(k != 'carregar' for k in ciclo(self).operacoes):
            return
        if not messagebox.askyesno('Restaurar administrador',
                'Deseja restaurar? A senha de administrador, os dados salvos da conexão '
                'e a credencial da balança associada serão apagados. Continuar?', parent=self.root):
            return
        if not getattr(self.dono, 'cadastro_inicial', False):
            # Primeiro B2 da execução atual; a nova execução fará a limpeza sem
            # competir com leitores ou gravações ainda admitidos nesta geração.
            self.dono.saida_aplicacao.restaurar_administrador = True
            self.controle.autorizado = False
            self.fechar()
            self.dono.reiniciar_administracao()
            return
        self.botao.config(state='disabled')
        self.esqueci.config(state='disabled')
        ciclo(self).iniciar('restaurar', armazenamento.restaurar, self.restaurado)

    def restaurado(self, resultado, erro):
        if erro or not resultado:
            self.status.config(text='Restauração incompleta. Confira acesso ao arquivo/cofre e tente novamente.')
            self.esqueci.config(state='normal')
            return
        self.controle.autorizado = False
        self.fechar()
        self.dono.reiniciar_administracao()

    def fechar(self):
        ciclo(self).fechar()
        self.root.grab_release()
        self.controle.tela = None
        self.root.destroy()

    def cancelar(self):
        if ciclo(self).operacoes:
            self.status.config(text='Aguarde a operação terminar antes de fechar.')
            return
        self.fechar()
        if (getattr(self.dono, 'cadastro_inicial', False)
                or self.dono.root.state() == 'withdrawn'):
            self.dono.cancelar_administracao()


def preparar_inicio(forcar=False, restaurar=False):
    """Antes de qualquer descoberta: cadastra ou autentica TCP, sem tocar a TC420."""
    global _controle
    from interface.saida_aplicacao import SaidaAplicacao
    controle = ControleAdministrador()
    root = tk.Tk()
    root.withdraw()
    class Inicio:
        pass
    dono = Inicio()
    dono.root, dono.saida_aplicacao = root, SaidaAplicacao()
    dono.saida_aplicacao.vincular('inicio_administrativo')
    dono.cadastro_inicial = True
    resultado = {'permitido': False, 'tcp': False}
    def concluir():
        resultado['permitido'] = True
        root.quit()
    dono.cancelar_administracao = root.quit
    def novo_cadastro():
        resultado['tcp'] = False
        controle.pedir(dono, 'Novo cadastro', concluir)
    dono.reiniciar_administracao = novo_cadastro
    def carregado(dados, erro):
        resultado['tcp'] = bool(dados and dados.get('metodo') == 'TCP')
        if not erro and dados is not None and not resultado['tcp'] and not forcar:
            concluir()
        else:
            controle.pedir(dono, 'Configuração da aplicação', concluir)
            if erro:
                controle.tela.status.config(text='Falha ao preparar o cadastro. Confira arquivo/cofre ou use Esqueci a senha.')
    def carregar_inicio():
        if restaurar:
            armazenamento.restaurar()
        return armazenamento.carregar()
    ciclo(dono).iniciar('inicio', carregar_inicio, carregado)
    root.mainloop()
    # A tela só sai após aplicar o resultado do worker; cancelar não altera arquivos.
    if controle.tela is not None:
        controle.tela.fechar()
    for timer in root.tk.call('after', 'info'):
        root.tk.call('after', 'cancel', timer)
    root.destroy()
    if resultado['permitido']:
        controle.metodo_inicial = 'TCP' if resultado['tcp'] else 'HTTPS'
        _controle = controle
    return resultado['permitido'], resultado['tcp']

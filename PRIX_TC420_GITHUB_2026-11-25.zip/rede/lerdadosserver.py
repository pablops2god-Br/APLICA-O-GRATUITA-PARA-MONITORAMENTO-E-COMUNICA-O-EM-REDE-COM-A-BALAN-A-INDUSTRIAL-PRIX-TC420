# Cliente: CONFIG descreve faixas, REGISTER ordena sucessão e SUBSCRIBE entrega medições.
import json
import math
import socket
import threading
import time

try:
    # Execução direta (python lerdadosserver.py, de dentro de rede/)
    from buscarservidor import buscar_servidor

except ImportError:
    # Importação como pacote (from rede.lerdadosserver import ...)
    from rede.buscarservidor import buscar_servidor


PORTA_TCP = 42100
INTERVALO_RECONEXAO = 5
INTERVALO_DESCOBERTA = 5
JANELA_SUCESSAO = 30
MAX_TENTATIVAS_RECUPERACAO = 10
INTERVALO_TENTATIVA_RECUPERACAO = 30
PRAZO_SILENCIO_SUBSCRIBE = 6
TAMANHO_RECEPCAO_SUBSCRIBE = 4096


# Distingue uma conexão aberta sem mensagens válidas de uma recepção de peso constante.
class SilencioSubscribeError(TimeoutError):
    """O servidor manteve o TCP aberto sem entregar uma medição válida."""


# Mantém uma fonte local de medições recebidas por TCP e os estados de reconexão e sucessão.
class LeitorDadosServidor:
    """
    Fonte de dados do MODO CLIENTE.

    Mantém o último pacote recebido do servidor TCP,
    exatamente como o servidor.py mantém 'dados_atuais'
    no PC principal.

    Assim a JanelaTC420 consome a MESMA estrutura nos
    dois computadores, sem saber se está no principal
    ou no cliente:

        dados = fonte_dados()

    onde 'fonte_dados' é, no principal, obter_dados_atuais
    do servidor, e, no cliente, obter_dados_atuais deste
    leitor.
    """

    # Prepara locks, eventos, estados e controles de admissão; a thread só parte em iniciar().
    def __init__(
        self,
        ip_servidor=None,
        permitir_candidatura=True,
        infraestrutura_cliente=None,
    ):
        self.infraestrutura_cliente = infraestrutura_cliente
        self.recursos_cliente = None
        self._partidas_retentativas = None
        self._atividades_permanentes = None
        self._origem_atividade_permanente = None
        if infraestrutura_cliente is not None:
            from rede.infraestrutura_cliente import RecursosLeitorCliente
            self.recursos_cliente = RecursosLeitorCliente(infraestrutura_cliente)
            from rede.retentativas_cliente import PartidasRetentativasCliente
            self._partidas_retentativas = PartidasRetentativasCliente(
                infraestrutura_cliente, self.recursos_cliente._geracao_retentativas)
            self._atividades_permanentes = infraestrutura_cliente.registro_atividades_permanentes
            self._origem_atividade_permanente = self._atividades_permanentes.preparar_leitor(
                self.recursos_cliente)
        from rede.admissao_register_cliente import AdmissaoRegisterCliente
        self._admissao_register = AdmissaoRegisterCliente(
            self.recursos_cliente,
            None if infraestrutura_cliente is None else infraestrutura_cliente.aplicacao_id)
        if self._atividades_permanentes is not None:
            self._atividades_permanentes.reter_admissao_register(
                self._origem_atividade_permanente, self._admissao_register)
        from rede.admissao_descoberta_inicial_cliente import AdmissaoDescobertaInicialCliente
        self._admissao_descoberta_inicial = AdmissaoDescobertaInicialCliente(
            self.recursos_cliente,
            None if infraestrutura_cliente is None else infraestrutura_cliente.aplicacao_id)
        if self.recursos_cliente is not None:
            self.recursos_cliente._admissao_checks = self._admissao_descoberta_inicial._admissao_checks
        if infraestrutura_cliente is not None:
            infraestrutura_cliente.reter_admissao_descoberta_inicial(
                self._admissao_descoberta_inicial)
        from rede.admissao_config_cliente import AdmissaoConfigCliente
        self._admissao_config = AdmissaoConfigCliente(self._admissao_descoberta_inicial)
        if infraestrutura_cliente is not None:
            infraestrutura_cliente.reter_admissao_config(self._admissao_config)
        from rede.admissao_subscribe_cliente import AdmissaoSubscribeCliente
        self._admissao_subscribe = AdmissaoSubscribeCliente(self._admissao_descoberta_inicial)
        if infraestrutura_cliente is not None:
            infraestrutura_cliente.reter_admissao_subscribe(self._admissao_subscribe)
        self.ip_servidor = ip_servidor
        self.permitir_candidatura = permitir_candidatura
        self._autorizar_sucessao_recuperada = None
        self.nome_computador = socket.gethostname()
        self.posicao_sucessao = None
        self.configuracao = None
        self.configuracao_pronta = threading.Event()
        self.servidor_respondendo = threading.Event()
        self.candidatura_liberada = threading.Event()
        self.estado_candidatura = "inativa"
        self.lock_candidatura = threading.Lock()
        self.tentativa_recuperacao = 0

        self.dados_atuais = {
            "estado": "Z0",
            "peso_bruto": "0",
            "tara": "0",
            "peso_liquido": "0",
            "unidade": "kg",
            "multirange": "1",
        }
        self._lock_dados = threading.Lock()
        self._comunicacao_atual = False
        self._ultima_mensagem_monotonica = None

        self.cliente = None
        self._lock_assinatura = threading.Lock()
        # Legado sem infraestrutura não emite provas: reter objetos cujo close
        # falhou. No caminho instrumentado, o registro já conserva esses handles.
        self._falhas_limpeza_subscribe_sem_registro = []
        self.executando = False
        self.thread = None
        self._parada = threading.Event()
        if infraestrutura_cliente is not None and infraestrutura_cliente.saida_aplicacao is not None:
            infraestrutura_cliente.saida_aplicacao.acompanhar_leitor(self)

    # =================================================
    # FONTE DE DADOS
    # =================================================

    # Entrega a última amostra junto da indicação de frescor para a interface reconhecer uma leitura antiga.
    def obter_dados_atuais(self):
        """
        Retorna a última leitura e informa se ela ainda representa comunicação
        atual. O valor é preservado para diagnóstico quando a conexão cai.
        """
        with self._lock_dados:
            return self.dados_atuais.copy()

    # Consulta o estado local de frescor, sem abrir outra conexão de rede.
    def comunicacao_esta_atual(self):
        with self._lock_dados:
            return self._comunicacao_atual

    # Retira a confirmação de comunicação sem apresentar o último peso como uma nova medição.
    def _marcar_comunicacao_indisponivel(self):
        with self._lock_dados:
            self._comunicacao_atual = False
        self.servidor_respondendo.clear()

    # Valida os campos recebidos antes de publicar a amostra e marcar comunicação atual.
    def _publicar_mensagem_valida(self, dados, instante):
        campos = {
            "estado", "peso_bruto", "tara", "peso_liquido",
            "unidade", "multirange",
        }
        if type(dados) is not dict or not campos.issubset(dados):
            raise ValueError("mensagem_subscribe_invalida")
        with self._lock_dados:
            self.dados_atuais = dados
            self._ultima_mensagem_monotonica = instante
            self._comunicacao_atual = True
        self.servidor_respondendo.set()
        if (self._autorizar_sucessao_recuperada is not None
                and type(self.posicao_sucessao) is int and self.posicao_sucessao > 0
                and self._sucessao_recuperada_segura()):
            if not self.permitir_candidatura:
                print('SUCESSAO: CLIENTE registrado e com leitura válida; candidatura rearmada.')
            self.permitir_candidatura = True

    def preparar_sucessao_recuperada(self, autorizar):
        """Não libera imediatamente: exige REGISTER e amostra do novo PRINCIPAL."""
        self._autorizar_sucessao_recuperada = autorizar

    def _sucessao_recuperada_segura(self):
        if self._autorizar_sucessao_recuperada is None:
            return True
        try:
            return self._autorizar_sucessao_recuperada() is True
        except Exception:
            return False

    # Acumula bytes até formar linhas JSON e usa prazo monotônico para detectar silêncio ou linhas inválidas.
    def _receber_subscribe(self, cliente):
        """Recebe linhas JSON sem usar readline() sobre socket com timeout.

        Fragmentos não renovam o prazo: somente uma linha completa e válida
        comprova que a conexão continua transportando medições.
        """
        acumulador = b""
        ultima_valida = time.monotonic()

        while self.executando:
            restante = PRAZO_SILENCIO_SUBSCRIBE - (time.monotonic() - ultima_valida)
            if restante <= 0:
                raise SilencioSubscribeError("silencio_subscribe")

            cliente.settimeout(restante)
            try:
                fragmento = cliente.recv(TAMANHO_RECEPCAO_SUBSCRIBE)
            except socket.timeout as erro:
                if time.monotonic() - ultima_valida >= PRAZO_SILENCIO_SUBSCRIBE:
                    raise SilencioSubscribeError("silencio_subscribe") from erro
                continue

            if not fragmento:
                return
            acumulador += fragmento

            while b"\n" in acumulador:
                linha, acumulador = acumulador.split(b"\n", 1)
                linha = linha.strip()
                if not linha:
                    continue
                dados = json.loads(linha.decode("utf-8"))
                instante = time.monotonic()
                self._publicar_mensagem_valida(dados, instante)
                ultima_valida = instante

                print(
                    f"Estado: {dados['estado']} | "
                    f"Peso: {dados['peso_liquido']} "
                    f"{dados['unidade']} | "
                    f"Tara: {dados['tara']} "
                    f"{dados['unidade']} | "
                    f"Faixa: {dados['multirange']}"
                )

    # Entrega a configuração metrológica recebida do principal.
    def obter_configuracao(self):
        return self.configuracao.copy() if self.configuracao else None

    # Consulta o evento sinalizado após publicação de mensagem válida; não faz um CHECK adicional.
    def servidor_esta_respondendo(self):
        return self.servidor_respondendo.is_set()

    # Consulta o evento que autoriza a interface a iniciar uma tentativa de promoção.
    def candidatura_esta_liberada(self):
        return self.candidatura_liberada.is_set()

    # Altera o estado de candidatura sob o lock compartilhado com a recuperação.
    def definir_estado_candidatura(self, estado):
        with self.lock_candidatura:
            self.estado_candidatura = estado

    # Lê o estado de candidatura com a mesma proteção usada nas escritas.
    def obter_estado_candidatura(self):
        with self.lock_candidatura:
            return self.estado_candidatura

    # Consulta o contador da tentativa atual de recuperação sob lock.
    def obter_tentativa_recuperacao(self):
        with self.lock_candidatura:
            return self.tentativa_recuperacao

    # Expõe o limite usado para interromper a sequência automática de recuperação.
    def obter_max_tentativas_recuperacao(self):
        return MAX_TENTATIVAS_RECUPERACAO

    # Atualiza o estado após falha de promoção e, quando permitido, prepara a próxima espera.
    def registrar_falha_recuperacao(self):
        with self.lock_candidatura:
            if self.estado_candidatura != "liberada":
                return False
            tentativa = self.tentativa_recuperacao
            if tentativa >= MAX_TENTATIVAS_RECUPERACAO:
                print(
                    f"Tentativa de recuperação {tentativa}/"
                    f"{MAX_TENTATIVAS_RECUPERACAO} falhou."
                )
                return False
            partidas = self._partidas_retentativas
            if partidas is None:
                return False
            identidade = partidas.admitir()
            if identidade is None:
                return False
            self.estado_candidatura = "aguardando"
            self.candidatura_liberada.clear()

        print(
            f"Tentativa de recuperação {tentativa}/"
            f"{MAX_TENTATIVAS_RECUPERACAO} falhou."
        )
        print(
            "Nova tentativa de recuperação em "
            f"{INTERVALO_TENTATIVA_RECUPERACAO} segundos."
        )
        return partidas.partir(
            identidade,
            lambda alvo: threading.Thread(target=alvo, daemon=True),
            self._aguardar_proxima_tentativa,
        )

    # Procura um principal durante a espera e só libera nova tentativa se o estado anterior ainda for válido.
    def _aguardar_proxima_tentativa(self):
        prazo = time.monotonic() + INTERVALO_TENTATIVA_RECUPERACAO
        recursos_recuperacao = (self._partidas_retentativas.recursos_da_execucao(
                                   self.recursos_cliente, caminho="espera_recuperacao_descoberta")
                               if self._partidas_retentativas is not None else self.recursos_cliente)
        with self.lock_candidatura:
            tentativa_anterior = self.tentativa_recuperacao

        while self.executando:
            servidor = buscar_servidor(**({"recursos_cliente": recursos_recuperacao}
                                         if recursos_recuperacao is not None else {}))
            if not self.executando:
                return

            with self.lock_candidatura:
                # Não altera uma candidatura já cancelada ou uma conexão ativa.
                if (
                    self.estado_candidatura != "aguardando"
                    or self.tentativa_recuperacao != tentativa_anterior
                ):
                    return

                if servidor:
                    self.ip_servidor = servidor
                    self.estado_candidatura = "cancelada"
                    self.tentativa_recuperacao = 0
                    self.candidatura_liberada.clear()
                    print(
                        "Servidor encontrado durante a espera "
                        f"da próxima tentativa: {servidor}"
                    )
                    return

                tempo_restante = prazo - time.monotonic()
                tentativa = self.tentativa_recuperacao
                if tempo_restante <= 0:
                    self.tentativa_recuperacao += 1
                    tentativa = self.tentativa_recuperacao
                    self.estado_candidatura = "liberada"
                    self.candidatura_liberada.set()

            if tempo_restante <= 0:
                print(
                    f"Tentativa de recuperação {tentativa}/"
                    f"{MAX_TENTATIVAS_RECUPERACAO} liberada."
                )
                return

            espera = min(tempo_restante, INTERVALO_DESCOBERTA)
            if self._parada.wait(espera):
                return

    # Expõe a posição devolvida por REGISTER para calcular a janela de candidatura.
    def obter_posicao_sucessao(self):
        return self.posicao_sucessao

    # Espera o evento de CONFIG por um prazo limitado, devolvendo None se ele não for sinalizado.
    def aguardar_configuracao(self, timeout=5):
        """Aguarda a configuração ou retorna None ao atingir o timeout."""
        recebeu = self.configuracao_pronta.wait(timeout)
        if not recebeu:
            return None
        return self.obter_configuracao()

    # =================================================
    # CICLO DE VIDA
    # =================================================

    # Evita partida duplicada e usa o registro de atividades permanentes quando ele está disponível.
    def iniciar(self):
        """
        Sobe a thread que mantém o estado atualizado.

        Não bloqueia: a conexão é feita em segundo plano.
        """
        saida = None if self.infraestrutura_cliente is None else self.infraestrutura_cliente.saida_aplicacao
        if saida is not None and saida.parada_solicitada:
            return
        if self.executando:
            return

        # Prepara o estado de execução e constrói a thread; o chamador decide como acompanhá-la e iniciá-la.
        def construir(alvo):
            self._parada.clear()
            self.executando = True
            self.thread = threading.Thread(target=alvo, daemon=True)
            return self.thread

        if self._atividades_permanentes is None:
            construir(self._manter_atualizado).start()
            return
        identidade = self._atividades_permanentes.reservar(self._origem_atividade_permanente)
        if identidade is not None:
            try:
                self._atividades_permanentes.partir(identidade, construir, self._manter_atualizado)
            except BaseException as original:
                try:
                    self._atividades_permanentes.comprovar_nao_partida(identidade, nao_iniciada=True)
                except BaseException as diagnostico:
                    original.__cause__ = diagnostico
                    original.__suppress_context__ = True
                raise

    def obter_operacoes_register(self):
        """Consulta local passiva, sem observar threads nem limpar recursos."""
        return self._admissao_register.obter_retrato()

    def obter_operacoes_descoberta_inicial(self):
        """Consulta passiva, inclusive antes da primeira reserva UDP."""
        return self._admissao_descoberta_inicial.obter_retrato()

    def obter_operacoes_config(self):
        """Retrato passivo; uma operação terminada não comprova fim da thread."""
        return self._admissao_config.obter_retrato()

    def obter_tentativas_subscribe(self):
        """Consulta passiva de conexões; não observa término da thread."""
        return self._admissao_subscribe.obter_retrato()

    # Admite a descoberta inicial antes de abrir os recursos de rede correspondentes.
    def _buscar_servidor_inicial(self):
        controle = self._admissao_descoberta_inicial
        identidade = controle.admitir()
        if identidade is None:
            return None
        with controle.executar(identidade) as recursos:
            return buscar_servidor(**({"recursos_cliente": recursos}
                                     if recursos is not None else {
                                         "admissao_checks": controle._admissao_checks}))

    # Fecha admissões, sinaliza parada e tenta interromper a assinatura; não equivale por si só a join da thread.
    def parar(self):
        # Fecha a autoridade da geração; admissões anteriores continuam retidas.
        self._admissao_descoberta_inicial.fechar_admissao()
        # Linearização da parada para REGISTER: não cancela admissões anteriores.
        self._admissao_register.fechar_admissao()
        self.executando = False
        self._parada.set()
        self._marcar_comunicacao_indisponivel()
        self.candidatura_liberada.clear()
        with self.lock_candidatura:
            self.estado_candidatura = "inativa"
            self.tentativa_recuperacao = 0

        with self._lock_assinatura:
            cliente = self.cliente
        if cliente is not None:
            # shutdown() é o que realmente destrava uma leitura
            # bloqueada em makefile()/readline (o close() sozinho
            # não interrompe a leitura em andamento).
            try:
                cliente.shutdown(socket.SHUT_RDWR)

            except Exception:
                pass
            finally:
                self._fechar_recurso_subscribe(cliente)
                with self._lock_assinatura:
                    if self.cliente is cliente:
                        self.cliente = None

    def _fechar_recurso_subscribe(self, recurso):
        """Cleanup individual; o registro publica prova/erro sem lock de leitor.

        Não propagar erro de cleanup sobre erro de leitura nem omitir o próximo
        recurso. Sem infraestrutura, reter handle/diagnóstico sem alegar prova.
        """
        if recurso is None:
            return
        try:
            recurso.close()
        except BaseException as erro:
            if self.recursos_cliente is None:
                categoria = "falha_io" if isinstance(erro, OSError) else "falha_operacao"
                with self._lock_assinatura:
                    self._falhas_limpeza_subscribe_sem_registro.append((recurso, categoria))

    # =================================================
    # THREAD TCP
    # =================================================

    # Espera posição vezes JANELA_SUCESSAO, procurando outro principal para cancelar a candidatura.
    def _aguardar_candidatura(self):
        if not self.permitir_candidatura or not self._sucessao_recuperada_segura():
            print(
                "Candidatura desabilitada. "
                "Aguardando outro servidor TC420."
            )
            return False

        if self.posicao_sucessao is None or not self.executando:
            return False

        with self.lock_candidatura:
            self.estado_candidatura = "aguardando"
            self.tentativa_recuperacao = 0
        tempo_candidatura = self.posicao_sucessao * JANELA_SUCESSAO
        prazo = time.monotonic() + tempo_candidatura
        print(f"Posição de sucessão: {self.posicao_sucessao}")
        print(f"Candidatura liberada em {tempo_candidatura} segundos.")

        while self.executando:
            if not self._sucessao_recuperada_segura():
                self.candidatura_liberada.clear()
                self.definir_estado_candidatura('inativa')
                return False
            tempo_restante = max(0, prazo - time.monotonic())
            if tempo_restante > 0:
                print(
                    "Tempo restante para candidatura: "
                    f"{math.ceil(tempo_restante)} s"
                )

            inicio_busca = time.monotonic()
            servidor = buscar_servidor(**({"recursos_cliente": self.recursos_cliente}
                                         if self.recursos_cliente is not None else {
                                             "admissao_checks": self._admissao_descoberta_inicial._admissao_checks}))
            if not self.executando:
                return False
            if servidor:
                print(f"Servidor encontrado durante a espera: {servidor}")
                self.ip_servidor = servidor
                self.candidatura_liberada.clear()
                with self.lock_candidatura:
                    self.estado_candidatura = "cancelada"
                    self.tentativa_recuperacao = 0
                print("Candidatura cancelada.")
                return False

            tempo_restante = prazo - time.monotonic()
            if tempo_restante <= 0:
                if not self._sucessao_recuperada_segura():
                    return False
                print("Minha vez de tentar assumir.")
                with self.lock_candidatura:
                    self.estado_candidatura = "liberada"
                    self.tentativa_recuperacao = 1
                self.candidatura_liberada.set()
                print("Candidatura sinalizada.")
                return True

            espera = min(
                tempo_restante,
                max(0, INTERVALO_DESCOBERTA - (time.monotonic() - inicio_busca)),
            )
            if self._parada.wait(espera):
                return False

        return False

    # Consulta síncrona na thread permanente do leitor, com admissão por operação.
    def _consultar_configuracao(self):
        """Busca CONFIG mantendo o acompanhamento dos recursos."""
        operacao_config = self._admissao_config.admitir()
        if operacao_config is not None:
            # Decodifica a linha CONFIG e libera quem aguarda a configuração metrológica.
            def receber_configuracao(linha):
                self.configuracao = json.loads(linha)
                self.configuracao_pronta.set()

            with self._admissao_config.executar(operacao_config) as recursos_config:
                recursos_config.ler_configuracao(
                    recursos_config.conectar_tcp(
                        (self.ip_servidor, PORTA_TCP), timeout=5),
                    receber_configuracao)

    def _manter_atualizado(self):
        saida = None if self.infraestrutura_cliente is None else self.infraestrutura_cliente.saida_aplicacao
        if saida is not None and saida.parada_solicitada:
            self.executando = False
            self._parada.set()
            return
        """Recebe CONFIG inicialmente e mantém a fonte de peso conectada."""
        # Se ainda não houver servidor, CONFIG será obtido na descoberta posterior.
        try:
            if not self.ip_servidor:
                print("Procurando servidor TC420...")
                self.ip_servidor = self._buscar_servidor_inicial()
            if self.ip_servidor and self.executando:
                self._consultar_configuracao()
        except Exception as erro:
            if self.executando:
                print(f"Conexão com servidor perdida: {erro}")
            self.ip_servidor = None

        while self.executando:
            arquivo = None
            cliente_assinatura = None
            tentativa_subscribe = None
            erro_subscribe = None
            try:
                if not self.ip_servidor:
                    print("Procurando servidor TC420...")
                    self.ip_servidor = buscar_servidor(**({"recursos_cliente": self.recursos_cliente}
                                                        if self.recursos_cliente is not None else {
                                                            "admissao_checks": self._admissao_descoberta_inicial._admissao_checks}))
                    if not self.executando:
                        break
                    if not self.ip_servidor:
                        print(
                            "Nenhum servidor encontrado. "
                            f"Nova tentativa em {INTERVALO_RECONEXAO} segundos."
                        )
                        self._parada.wait(INTERVALO_RECONEXAO)
                        continue
                    print(f"Servidor encontrado: {self.ip_servidor}")

                if not self.executando:
                    break

                # Repete CONFIG se a descoberta inicial ainda estava sem servidor.
                if not self.configuracao_pronta.is_set():
                    self._consultar_configuracao()
                    if not self.executando:
                        break

                operacao_register = self._admissao_register.admitir()
                if operacao_register is None:
                    break
                with self._admissao_register.executar(operacao_register) as recursos_register:
                    if recursos_register is None:
                        with socket.create_connection(
                            (self.ip_servidor, PORTA_TCP), timeout=5
                        ) as cliente_registro:
                            cliente_registro.sendall(
                                f"REGISTER|{self.nome_computador}\n".encode("utf-8")
                            )
                            with cliente_registro.makefile(
                                "r", encoding="utf-8"
                            ) as arquivo_registro:
                                resposta = json.loads(arquivo_registro.readline())
                                posicao = resposta["posicao"]
                                if (
                                    resposta["nome"] != self.nome_computador
                                    or type(posicao) is not int
                                    or posicao < 1
                                ):
                                    raise ValueError("Resposta REGISTER inválida")
                                self.posicao_sucessao = posicao
                    else:
                        # Só aceita a resposta REGISTER se nome e posição inteira positiva corresponderem ao cliente.
                        def receber_registro(linha):
                            resposta = json.loads(linha)
                            posicao = resposta["posicao"]
                            if (
                                resposta["nome"] != self.nome_computador
                                or type(posicao) is not int
                                or posicao < 1
                            ):
                                raise ValueError("Resposta REGISTER inválida")
                            self.posicao_sucessao = posicao

                        recursos_register.registrar_cliente(
                            recursos_register.conectar_tcp(
                                (self.ip_servidor, PORTA_TCP), timeout=5),
                            self.nome_computador, receber_registro)

                print("Computador registrado:")
                print(f"  Nome: {self.nome_computador}")
                print(f"  Posição de sucessão: {self.posicao_sucessao}")

                if not self.executando:
                    break

                tentativa_subscribe = self._admissao_subscribe.admitir()
                if tentativa_subscribe is None:
                    break
                recursos_subscribe = self._admissao_subscribe.iniciar(tentativa_subscribe)
                if recursos_subscribe is None:
                    cliente_assinatura = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                else:
                    cliente_assinatura = recursos_subscribe.abrir_socket(
                        lambda: socket.socket(socket.AF_INET, socket.SOCK_STREAM))
                with self._lock_assinatura:
                    self.cliente = cliente_assinatura
                cliente_assinatura.settimeout(5)

                print(
                    f"Conectando ao servidor "
                    f"{self.ip_servidor}:{PORTA_TCP}..."
                )

                cliente_assinatura.connect(
                    (self.ip_servidor, PORTA_TCP)
                )

                cliente_assinatura.sendall(
                    b"SUBSCRIBE\n"
                )
                cliente_assinatura.settimeout(PRAZO_SILENCIO_SUBSCRIBE)
                if not self.executando:
                    break

                print("Conectado!")
                print("Recebendo dados...\n")
                self._marcar_comunicacao_indisponivel()
                self.candidatura_liberada.clear()
                with self.lock_candidatura:
                    self.estado_candidatura = "inativa"
                    self.tentativa_recuperacao = 0

                # makefile facilita a leitura de uma mensagem JSON
                # completa por linha.
                arquivo = cliente_assinatura.makefile(
                    "r",
                    encoding="utf-8",
                )
                self._receber_subscribe(cliente_assinatura)
                if self.executando:
                    print("Conexão com servidor perdida.")
            except SilencioSubscribeError as erro:
                erro_subscribe = erro
                if self.executando:
                    print(
                        "Silêncio do servidor detectado: nenhuma mensagem "
                        f"SUBSCRIBE válida por {PRAZO_SILENCIO_SUBSCRIBE} segundos."
                    )
            except Exception as erro:
                erro_subscribe = erro
                if self.executando:
                    print(f"Conexão com servidor perdida: {erro}")

            except BaseException as erro:
                erro_subscribe = erro
                raise

            finally:
                self._marcar_comunicacao_indisponivel()
                self._fechar_recurso_subscribe(cliente_assinatura)
                self._fechar_recurso_subscribe(arquivo)
                with self._lock_assinatura:
                    if self.cliente is cliente_assinatura:
                        self.cliente = None
                if tentativa_subscribe is not None:
                    self._admissao_subscribe.finalizar(tentativa_subscribe, erro_subscribe)

            if self.executando:
                self.ip_servidor = None
                print("Procurando outro servidor TC420...")
                liberado = self._aguardar_candidatura()
                if liberado:
                    print("Aguardando tratamento da candidatura.")
                if liberado or self.ip_servidor is None:
                    self._parada.wait(INTERVALO_RECONEXAO)


if __name__ == "__main__":
    print("=== CLIENTE TC420 ===")
    print("Procurando servidor...")

    leitor = LeitorDadosServidor()
    leitor.iniciar()

    thread_leitura = leitor.thread

    try:
        # Permanece vivo enquanto a thread TCP estiver ativa.
        if thread_leitura is not None:
            thread_leitura.join()

    except KeyboardInterrupt:
        print("\nLeitura encerrada.")

    finally:
        leitor.parar()

# Consulta de evidências: cruza retratos por identidade, sem limpar recursos nem autorizar fechamento global.
"""AC3-D1: composição passiva de atividades, admissões e evidências de IO.

Reutiliza os validadores puros do contrato experimental, sem copiar o avaliador.
Dois ciclos iguais detectam mudanças, mas NÃO constituem snapshot atômico.
Positivo individual exige gates fechados e região terminal monotônica de
guarda/recursos, além do escopo auditado encerrado. HTTP/retenções não ampliam
esse positivo para CLIENTE nem aplicação, cuja cobertura continua incompleta.
"""
from prototipos.composicao_cliente import _validar_recursos, _validar_retentativas


def _ler(infra):
    return (
        infra.registro_retentativas.obter_retrato(),
        infra.registro_recursos.obter_retrato(),
        infra.obter_associacoes_retentativas(),
        infra.registro_http.obter_retrato(),
        tuple((contexto.obter_historico(), contexto.obter_pendencias())
              for contexto in infra.obter_contextos_arquivos()),
        infra.obter_atividades_permanentes(),
        infra.obter_operacoes_register(),
        infra.obter_operacoes_descoberta_inicial(),
        infra.obter_operacoes_config(),
        infra.obter_tentativas_subscribe(),
    )


def _id(valor):
    if type(valor) is not int or valor < 1:
        raise ValueError('identidade_operacional_invalida')
    return valor


def _flags(item, *nomes):
    if any(type(item[nome]) is not bool for nome in nomes):
        raise ValueError('evidencia_operacional_invalida')


def _erro_operacional(erro):
    if erro is not None and (type(erro) is not dict or set(erro) != {'categoria'}
            or erro['categoria'] not in ('falha_io', 'falha_operacao', 'falha_base')):
        raise ValueError('erro_operacional_invalido')
    return None if erro is None else erro.copy()


def _permanentes(retrato, aplicacao):
    if retrato['aplicacao_id'] != aplicacao or type(retrato['atividades']) is not list:
        raise ValueError('atividades_estrangeiras')
    _flags(retrato, 'admissao_fechada')
    atividades, ids = [], set()
    for item in retrato['atividades']:
        identidade = _id(item['atividade_id'])
        _id(item['geracao_id'])
        _id(item['atividade_recursos_id'])
        if identidade in ids or item['tipo'] != 'leitor_permanente':
            raise ValueError('atividade_permanente_invalida')
        ids.add(identidade)
        _flags(item, 'partida_em_curso', 'partida_resolvida', 'start_invocado',
               'partida_ambigua', 'entrada', 'retorno', 'thread_terminada',
               'ausencia_comprovada', 'erro_publicacao', 'erro_observacao',
               'execucao_em_curso', 'termino_confirmado')
        confirmado = (item['partida_resolvida'] and not item['partida_em_curso']
            and not item['erro_publicacao'] and not item['erro_observacao']
            and (item['ausencia_comprovada'] or (
                item['entrada'] and item['retorno'] and item['thread_terminada'])))
        if (item['termino_confirmado'] is not bool(confirmado)
                or item['execucao_em_curso'] is not (item['entrada'] and not item['retorno'])
                or (item['ausencia_comprovada'] and item['entrada'])
                or (item['thread_terminada'] and not (item['entrada'] and item['retorno']))):
            raise ValueError('atividade_permanente_contraditoria')
        pendencias = [] if confirmado else ['termino_nao_comprovado']
        for nome in ('partida_em_curso', 'partida_ambigua', 'erro_publicacao', 'erro_observacao'):
            if item[nome] and not confirmado:
                pendencias.append(nome)
        atividades.append({n: item[n] for n in (
            'atividade_id', 'geracao_id', 'atividade_recursos_id', 'tipo',
            'partida_em_curso', 'partida_resolvida', 'partida_ambigua', 'start_invocado', 'entrada', 'retorno',
            'thread_terminada', 'ausencia_comprovada', 'execucao_em_curso', 'termino_confirmado')}
            | {'erro_operacional': _erro_operacional(item['erro_operacional']),
               'erro_partida': _erro_operacional(item['erro_partida']),
               'erro_publicacao': item['erro_publicacao'], 'erro_observacao': item['erro_observacao'],
               'pendencias': pendencias})
    return atividades


class _Admissoes:
    """Valida retratos e cruza IDs; não acessa controles ou objetos concretos."""
    def __init__(self, aplicacao, recursos, guarda, atividades):
        self.aplicacao, self.recursos = aplicacao, recursos
        self.secundarias = {s['id']: s for s in guarda['secundarias']}
        self.guarda_fechada = guarda['admissao_fechada']
        self.atividades = {}
        self.itens, self.controles, self.donos = [], [], {}
        self.sockets_checks, self.autorizacoes_checks = {}, set()
        self.familias = {n: set() for n in ('register', 'descoberta_inicial', 'config', 'subscribe')}
        for item in atividades:
            self.origem(item['geracao_id'], item['atividade_recursos_id'])

    def origem(self, geracao, atividade):
        _id(geracao)
        _id(atividade)
        if self.atividades.setdefault(geracao, atividade) != atividade:
            raise ValueError('atividade_da_geracao_contraditoria')

    def raiz(self, familia, raiz):
        geracao = _id(raiz['geracao_id'])
        if raiz['aplicacao_id'] != self.aplicacao or geracao in self.familias[familia]:
            raise ValueError('controle_estrangeiro_ou_duplicado')
        self.familias[familia].add(geracao)
        if (type(raiz['tentativas'] if familia == 'subscribe' else raiz['operacoes']) is not list
                or (familia == 'descoberta_inicial' and type(raiz['checks']) is not list)):
            raise ValueError('colecao_admissao_invalida')
        _flags(raiz, 'admissao_fechada', 'encerramento_global_confirmado')
        if (raiz['encerramento_global_confirmado']
                or raiz['cobertura_operacional'] not in ('incompleta', 'completa')):
            raise ValueError('cobertura_controle_invalida')
        self.controles.append({'familia': familia, 'geracao_id': geracao,
            'admissao_fechada': raiz['admissao_fechada'],
            'cobertura_declarada': raiz['cobertura_operacional']})
        if 'atividade_recursos_id' in raiz:
            self.origem(geracao, raiz['atividade_recursos_id'])
        for op in raiz.get('operacoes', []):
            if 'atividade_recursos_id' in op:
                self.origem(geracao, op['atividade_recursos_id'])

    def vinculos(self, item, geracao, atividade, dono, tipos):
        ids, limpeza, publicados = [], True, True
        if type(item['recursos']) is not list:
            raise ValueError('colecao_recursos_admissao_invalida')
        for vinculo in item['recursos']:
            numero = _id(vinculo['recurso_id'])
            recurso = self.recursos[numero]
            _flags(vinculo, 'associacao_publicada', 'limpeza_confirmada')
            if (numero in ids or vinculo['tipo'] not in tipos
                    or recurso['tipo'] != vinculo['tipo']
                    or (recurso['geracao_id'], recurso['retentativa_id']) != (geracao, atividade)
                    or vinculo['limpeza_confirmada'] is not recurso['encerramento_confirmado']
                    or self.donos.setdefault(numero, dono) != dono):
                raise ValueError('vinculo_admissao_invalido')
            ids.append(numero)
            limpeza = limpeza and vinculo['limpeza_confirmada']
            publicados = publicados and vinculo['associacao_publicada']
        for numero in ids:
            recurso = self.recursos[numero]
            if recurso['tipo'] == 'arquivo_socket' and recurso['associado_a'] not in ids:
                raise ValueError('arquivo_de_outra_admissao')
        return ids, bool(limpeza), bool(publicados)

    def operacao(self, familia, item, geracao, atividade, fechada, *, pai=None, dono=None,
                 retorno='retorno', curso='em_curso', numero='identidade_id', extra=True,
                 tipos=('socket_tcp', 'arquivo_socket'), validar_resolucao=True):
        identidade = _id(item[numero])
        _flags(item, retorno, curso, 'erro_publicacao', 'erro_associacao', 'responsabilidade_resolvida')
        if 'iniciada' in item:
            _flags(item, 'iniciada')
            if item[curso] and not item['iniciada']:
                raise ValueError('execucao_sem_inicio')
        ids, limpeza, publicados = self.vinculos(item, geracao, atividade,
            dono or (familia, geracao, pai, identidade), tipos)
        publicacoes = not item['erro_publicacao'] and not item['erro_associacao'] and publicados
        resolvida = item[retorno] and not item[curso] and publicacoes and limpeza and extra
        if validar_resolucao and item['responsabilidade_resolvida'] is not bool(resolvida):
            raise ValueError('resolucao_admissao_contraditoria')
        pendencias = []
        if not item[retorno] or item[curso]:
            pendencias.append('execucao_nao_concluida')
        if not publicacoes:
            pendencias.append('publicacao_incompleta')
        if not limpeza:
            pendencias.append('recursos_ou_vinculos_pendentes')
        if not extra:
            pendencias.append('responsabilidades_vinculadas_pendentes')
        saida = {'familia': familia, 'geracao_id': geracao, 'atividade_recursos_id': atividade,
            'identidade_id': identidade, 'operacao_pai_id': pai, 'recursos': ids,
            'admissao_fechada': fechada, 'execucao_concluida': item[retorno] and not item[curso],
            'publicacoes_resolvidas': publicacoes, 'recursos_resolvidos': limpeza,
            'responsabilidade_resolvida': bool(resolvida), 'pendencias': pendencias,
            'erro_operacao': _erro_operacional(item['erro_operacao'])}
        self.itens.append(saida)
        return saida

    def checks(self, itens, geracao, atividade, fechada, *, retentativa=None, pais=None):
        vistos = set()
        if type(itens) is not list:
            raise ValueError('colecao_checks_invalida')
        for item in itens:
            identidade = _id(item['check_id'])
            if item['resultado'] is not None and type(item['resultado']) is not bool:
                raise ValueError('resultado_check_invalido')
            _id(item['geracao_id'])
            if retentativa is not None:
                _id(item['retentativa_id'])
            if (identidade in vistos or item['aplicacao_id'] != self.aplicacao
                    or item['geracao_id'] != geracao or item['retentativa_id'] != retentativa
                    or item['origem'] != ('recuperacao' if retentativa is not None else 'leitor_permanente')):
                raise ValueError('origem_check_invalida')
            vistos.add(identidade)
            pai, udp = item['descoberta_inicial_id'], item['descoberta_udp_id']
            if udp is not None:
                recurso = self.recursos[_id(udp)]
                if (recurso['tipo'] != 'socket_udp'
                        or (recurso['geracao_id'], recurso['retentativa_id']) != (geracao, atividade)):
                    raise ValueError('udp_check_estrangeiro')
            dono = (('retentativa', geracao, retentativa) if retentativa is not None
                    else ('check_tcp', geracao, retentativa, identidade))
            if pai is not None:
                _id(pai)
                if retentativa is not None or pais is None or pai not in pais:
                    raise ValueError('descoberta_check_ausente')
                ids_pai = {r['recurso_id'] for r in pais[pai]['recursos']}
                if udp not in ids_pai or any(r['recurso_id'] not in ids_pai for r in item['recursos']):
                    raise ValueError('check_fora_da_descoberta')
                dono = ('descoberta_inicial', geracao, None, pai)
            _flags(item, 'autorizacao_secundaria_resolvida', 'responsabilidade_recursos_resolvida')
            if retentativa is not None:
                secundaria = self.secundarias[_id(item['autorizacao_secundaria_id'])]
                if item['autorizacao_secundaria_id'] in self.autorizacoes_checks:
                    raise ValueError('autorizacao_check_duplicada')
                self.autorizacoes_checks.add(item['autorizacao_secundaria_id'])
                if secundaria['retentativa'] != retentativa or secundaria['tipo'] != 'socket':
                    raise ValueError('autorizacao_check_estrangeira')
                if item['autorizacao_secundaria_resolvida'] and (not secundaria['resolvida']
                        or secundaria['publicacao_em_curso'] or secundaria['limpeza_em_curso'] or secundaria['erro']):
                    raise ValueError('prova_secundaria_check_contraditoria')
            elif item['autorizacao_secundaria_id'] is not None or not item['autorizacao_secundaria_resolvida']:
                raise ValueError('check_leitor_com_retry_ficticia')
            saida = self.operacao('check_tcp', item, geracao, atividade, fechada, pai=pai,
                dono=dono, numero='check_id', tipos=('socket_tcp',),
                extra=item['autorizacao_secundaria_resolvida'])
            recursos_resolvidos = (saida['execucao_concluida'] and saida['publicacoes_resolvidas']
                                   and saida['recursos_resolvidos'])
            if item['responsabilidade_recursos_resolvida'] is not bool(recursos_resolvidos):
                raise ValueError('limpeza_check_contraditoria')
            saida.update(origem=item['origem'], retentativa_id=retentativa, descoberta_udp_id=udp,
                         autorizacao_secundaria_id=item['autorizacao_secundaria_id'])
            for numero in saida['recursos']:
                if numero in self.sockets_checks:
                    raise ValueError('socket_reutilizado_entre_checks')
                self.sockets_checks[numero] = (geracao, retentativa, identidade)

    def integrar(self, registros, descobertas, configs, subscribes, associacoes):
        for associacao in associacoes:
            for recurso in associacao['recursos']:
                self.donos[recurso['recurso_id']] = (
                    'retentativa', associacao['geracao_id'], associacao['retentativa_id'])
        for familia, raizes in (('register', registros), ('descoberta_inicial', descobertas),
                               ('config', configs), ('subscribe', subscribes)):
            if type(raizes) is not list:
                raise ValueError('colecao_controles_invalida')
            for raiz in raizes:
                self.raiz(familia, raiz)
        for familia, raizes in (('register', registros), ('descoberta_inicial', descobertas)):
            for raiz in raizes:
                geracao, fechada = raiz['geracao_id'], raiz['admissao_fechada']
                pais = {}
                for item in raiz['operacoes']:
                    identidade = _id(item['operacao_id'])
                    _id(item['geracao_id'])
                    if (identidade in pais or item['tipo'] != familia or item['geracao_id'] != geracao):
                        raise ValueError('operacao_admissao_invalida')
                    pais[identidade] = item
                if familia == 'descoberta_inicial':
                    self.checks(raiz['checks'], geracao, self.atividades.get(geracao), fechada, pais=pais)
                for item in pais.values():
                    filhos = [c for c in self.itens if c['familia'] == 'check_tcp'
                              and c['geracao_id'] == geracao and c['operacao_pai_id'] == item['operacao_id']]
                    self.operacao(familia, item, geracao, item['atividade_recursos_id'], fechada,
                        numero='operacao_id', curso='execucao_em_curso',
                        tipos=('socket_tcp', 'arquivo_socket') if familia == 'register' else ('socket_udp', 'socket_tcp'),
                        extra=all(c['responsabilidade_resolvida'] for c in filhos))
        for familia, raizes in (('config', configs), ('subscribe', subscribes)):
            for raiz in raizes:
                geracao, atividade = raiz['geracao_id'], raiz['atividade_recursos_id']
                fechada, vistos = raiz['admissao_fechada'], set()
                for item in raiz['operacoes'] if familia == 'config' else raiz['tentativas']:
                    chave = _id(item['identidade_id'] if familia == 'config' else item['tentativa_id'])
                    if chave in vistos or (familia == 'config' and item['tipo'] != 'config'):
                        raise ValueError('identidade_admissao_duplicada')
                    vistos.add(chave)
                    filhos, tentativas = [], set()
                    if familia == 'config':
                        if type(item['tentativas']) is not list:
                            raise ValueError('colecao_tentativas_config_invalida')
                        for indice, tentativa in enumerate(item['tentativas'], 1):
                            ident = _id(tentativa['identidade_id'])
                            _flags(tentativa, 'conectada', 'comunicacao_iniciada')
                            if (ident in tentativas or ident in vistos or tentativa['tipo'] != 'endereco_config'
                                    or _id(tentativa['endereco_indice']) != indice):
                                raise ValueError('tentativa_config_invalida')
                            tentativas.add(ident)
                            vistos.add(ident)
                            filho = self.operacao('tentativa_config', tentativa, geracao, atividade,
                                                   fechada, pai=chave)
                            filho['endereco_indice'] = indice
                            filhos.append(filho)
                    elif item['tipo'] not in ('inicial', 'reconexao'):
                        raise ValueError('tipo_subscribe_invalido')
                    saida = self.operacao(familia, item, geracao, atividade, fechada,
                        numero='identidade_id' if familia == 'config' else 'tentativa_id',
                        extra=all(f['responsabilidade_resolvida'] for f in filhos))
                    if familia == 'subscribe':
                        saida['tipo_tentativa'] = item['tipo']
        for associacao in associacoes:
            ids = {r['recurso_id'] for r in associacao['recursos']}
            for check in associacao['checks']:
                if (any(r['recurso_id'] not in ids for r in check['recursos'])
                        or (check['descoberta_udp_id'] is not None and check['descoberta_udp_id'] not in ids)):
                    raise ValueError('check_fora_da_associacao_retentativa')
            self.checks(associacao['checks'], associacao['geracao_id'], associacao['retentativa_id'],
                        self.guarda_fechada, retentativa=associacao['retentativa_id'])
        todas = set(self.atividades) | set().union(*self.familias.values())
        self.origens_completas = all(geracao in familia for geracao in todas for familia in self.familias.values())


def _associacoes(itens, aplicacao, retentativas, recursos):
    pares, donos = {}, set()
    for item in itens:
        par = item['geracao_id'], item['retentativa_id']
        if (par not in retentativas or par in pares or item['aplicacao_id'] != aplicacao
                or any(type(item[n]) is not bool for n in (
                    'execucao_em_curso', 'cobertura_recursos_completa', 'erro_associacao'))):
            raise ValueError('associacao_invalida')
        ids = []
        for vinculo in item['recursos']:
            numero = vinculo['recurso_id']
            recurso = recursos[numero]
            if (numero in donos or (recurso['geracao_id'], recurso['retentativa_id']) != par
                    or vinculo['tipo'] != recurso['tipo']
                    or vinculo['responsabilidade'] != 'proprio'
                    or vinculo['evidencia'] != 'reserva_no_adaptador_da_retentativa'
                    or vinculo['estado'] != recurso['estado']
                    or vinculo['criacao_resolvida'] is not recurso['criacao_resolvida']
                    or vinculo['limpeza_confirmada'] is not recurso['encerramento_confirmado']):
                raise ValueError('vinculo_invalido')
            donos.add(numero)
            ids.append(numero)
        cobertura = item['cobertura_recursos_completa']
        if cobertura and (item['execucao_em_curso'] or item['erro_associacao']
                          or item['evidencia_cobertura'] != 'espera_recuperacao_descoberta'):
            raise ValueError('cobertura_contraditoria')
        pares[par] = (cobertura, ids)
    return pares, donos


def _http(retrato, aplicacao):
    if retrato['aplicacao_id'] != aplicacao:
        raise ValueError('http_estrangeiro')
    _flags(retrato, 'admissao_fechada')
    operacoes, ids = [], set()
    for item in retrato['operacoes']:
        for nome in ('operacao_id', 'geracao_id', 'atividade_id'):
            if type(item[nome]) is not int or item[nome] < 1:
                raise ValueError('identidade_http_invalida')
        if item['operacao_id'] in ids or item['operacao'] not in ('login', 'approval'):
            raise ValueError('operacao_http_invalida')
        ids.add(item['operacao_id'])
        if (item['estado'] not in ('reservada', 'em_andamento', 'concluida', 'desconhecida')
                or item['resultado'] not in (None, 'retorno', 'falha', 'desconhecido')
                or type(item['execucoes_ativas']) is not int or item['execucoes_ativas'] < 0
                or type(item['inicio_confirmado']) is not bool):
            raise ValueError('estado_http_invalido')
        resolvida = (item['publicacao_original'] is not None
                     and not item['conflitos_publicacao'] and not item['incertezas']
                     and item['execucoes_ativas'] == 0 and not item['publicacoes_pendentes'])
        if (item['execucao_resolvida'] is not resolvida
                or item['publicacao_pendente'] is not (not resolvida)
                or resolvida != (item['estado'] == 'concluida')
                or (resolvida and item['resultado'] not in ('retorno', 'falha'))):
            raise ValueError('http_contraditorio')
        erro = item['erro']
        if erro is not None and (set(erro) != {'etapa', 'categoria'}
                or erro['etapa'] != 'operacao' or erro['categoria'] not in (
                    'timeout', 'falha_io', 'falha_operacao', 'falha_base')):
            raise ValueError('erro_http_invalido')
        operacoes.append({n: item[n] for n in (
            'operacao_id', 'geracao_id', 'atividade_id', 'operacao', 'estado',
            'resultado', 'erro', 'execucao_resolvida', 'publicacao_pendente')})
    return operacoes


def _arquivos(contextos, recursos):
    historico, pendentes, ids = [], [], set()
    for registros, retidos in contextos:
        locais = {}
        for item in registros:
            numero = item['recurso_id']
            recurso = recursos[numero]
            if (numero in ids or recurso['tipo'] != 'arquivo_comum'
                    or (item['geracao_id'], item['atividade_id']) != (
                        recurso['geracao_id'], recurso['retentativa_id'])
                    or type(item['handle_retido']) is not bool
                    or type(item['limpeza_comprovada']) is not bool):
                raise ValueError('arquivo_invalido')
            ids.add(numero)
            locais[numero] = item
            historico.append({n: item[n] for n in (
                'recurso_id', 'geracao_id', 'atividade_id', 'handle_retido', 'limpeza_comprovada')})
        numeros_retidos = {item['recurso_id'] for item in retidos}
        if any(item['handle_retido'] and numero not in numeros_retidos
               for numero, item in locais.items()):
            raise ValueError('retencao_omitida')
        for item in retidos:
            numero = item['recurso_id']
            if numero in pendentes or locais.get(numero) != item:
                raise ValueError('retencao_incoerente')
            pendentes.append(numero)
    return historico, pendentes


def avaliar_responsabilidades_cliente(infra):
    """Resultado por identidade original; nenhuma ação sobre registros/handles.

    Igualdade das leituras é reportada como revalidação, jamais atomicidade.
    Falha/incoerência descarta todo candidato positivo e não expõe exceções.
    """
    resultado = {
        'aplicacao_id': infra.aplicacao_id, 'leituras_revalidadas': False,
        'snapshot_atomico': False, 'retentativas': [], 'recursos': [],
        'admissoes_individuais_fechadas': False,
        'recursos_sem_associacao_comprovada': [], 'recursos_pendentes': [],
        'http': [], 'arquivos': [], 'retencoes_pendentes': [],
        'atividades_permanentes': [], 'admissoes': [], 'controles_admissao': [],
        'autorizacoes_secundarias': [],
        'admissoes_operacionais_fechadas': False, 'origens_admissoes_completas': False,
        'responsabilidades_conhecidas_resolvidas': False,
        'cobertura_operacional': 'incompleta',
        'encerramento_cliente_confirmado': False,
        'encerramento_global_confirmado': False,
        'pendencias': ['cobertura_atividades_cliente_incompleta', 'aplicacao_fora_do_escopo'],
    }
    try:
        primeiro, segundo = _ler(infra), _ler(infra)
        if primeiro != segundo:
            resultado['pendencias'].append('consulta_incoerente')
            return resultado
        (guarda, registro, associacoes, http, arquivos, permanentes,
         registros, descobertas, configs, subscribes) = segundo
        retentativas = _validar_retentativas(guarda)
        recursos = _validar_recursos(registro)
        pares, donos = _associacoes(associacoes, infra.aplicacao_id, retentativas, recursos)
        operacoes = _http(http, infra.aplicacao_id)
        historico, retidos = _arquivos(arquivos, recursos)
        atividades = _permanentes(permanentes, infra.aplicacao_id)
        admissoes = _Admissoes(infra.aplicacao_id, recursos, guarda, atividades)
        admissoes.integrar(registros, descobertas, configs, subscribes, associacoes)
        gates = guarda['admissao_fechada'] and registro['admissao_fechada']
        gates_operacionais = (gates and permanentes['admissao_fechada'] and http['admissao_fechada']
            and admissoes.origens_completas
            and all(c['admissao_fechada'] for c in admissoes.controles))
        geracoes_retry = {par[1]: par[0] for par in retentativas}
        secundarias = [{'autorizacao_id': s['id'], 'geracao_id': geracoes_retry[s['retentativa']],
            'retentativa_id': s['retentativa'], 'tipo': s['tipo'],
            'responsabilidade_resolvida': bool(s['resolvida'] and not s['erro']
                and not s['publicacao_em_curso'] and not s['limpeza_em_curso'])}
            for s in guarda['secundarias']]
        individuais = []
        for par, item in retentativas.items():
            cobertura, ids = pares.get(par, (False, []))
            execucao = item['estado'] == 'encerramento_confirmado'
            limpeza = all(recursos[i]['encerramento_confirmado'] for i in ids)
            checks = [c for c in admissoes.itens if c['familia'] == 'check_tcp'
                      and c['geracao_id'] == par[0] and c.get('retentativa_id') == par[1]]
            checks_resolvidos = all(c['responsabilidade_resolvida'] for c in checks)
            secundarias_pendentes = [s['autorizacao_id'] for s in secundarias
                if s['retentativa_id'] == par[1] and not s['responsabilidade_resolvida']]
            individuais.append({
                'geracao_id': par[0], 'retentativa_id': par[1], 'recursos': sorted(ids),
                'execucao_confirmada': execucao, 'cobertura_recursos_completa': cobertura,
                'recursos_resolvidos': limpeza,
                'checks_resolvidos': checks_resolvidos,
                'checks_pendentes': [c['identidade_id'] for c in checks if not c['responsabilidade_resolvida']],
                'autorizacoes_secundarias_pendentes': secundarias_pendentes,
                'encerramento_confirmado': bool(gates and execucao and cobertura and limpeza and checks_resolvidos),
                'pendencias': ([ 'admissoes_abertas' ] if not gates else [])
                + ([ 'execucao_nao_comprovada' ] if not execucao else [])
                + ([ 'cobertura_recursos_incompleta' ] if not cobertura else [])
                + ([ 'recursos_proprios_pendentes' ] if not limpeza else [])
                + ([ 'checks_pendentes' ] if not checks_resolvidos else []),
            })
        pendentes = sorted(i for i, r in recursos.items() if not r['encerramento_confirmado'])
        resultado.update(
            leituras_revalidadas=True, retentativas=individuais, http=operacoes,
            admissoes_individuais_fechadas=gates,
            atividades_permanentes=atividades, admissoes=admissoes.itens,
            autorizacoes_secundarias=secundarias,
            controles_admissao=admissoes.controles,
            admissoes_operacionais_fechadas=bool(gates_operacionais),
            origens_admissoes_completas=admissoes.origens_completas,
            recursos=[{n: r[n] for n in ('recurso_id', 'geracao_id', 'tipo', 'estado',
                                         'encerramento_confirmado')}
                      | {'atividade_id': r['retentativa_id'],
                         'associacao_retentativa_comprovada': i in donos}
                      for i, r in recursos.items()],
            arquivos=historico, retencoes_pendentes=retidos, recursos_pendentes=pendentes,
            recursos_sem_associacao_comprovada=sorted(set(recursos) - donos),
            responsabilidades_conhecidas_resolvidas=(
                all(i['encerramento_confirmado'] for i in individuais)
                and not pendentes and not retidos
                and all(i['execucao_resolvida'] for i in operacoes)
                and all(a['termino_confirmado'] for a in atividades)
                and all(a['responsabilidade_resolvida'] for a in admissoes.itens)
                and all(s['responsabilidade_resolvida'] for s in secundarias)
                and admissoes.origens_completas),
        )
        if any(not a['termino_confirmado'] for a in atividades):
            resultado['pendencias'].append('atividades_permanentes_pendentes')
        if any(not a['responsabilidade_resolvida'] for a in admissoes.itens):
            resultado['pendencias'].append('admissoes_pendentes')
        if any(not s['responsabilidade_resolvida'] for s in secundarias):
            resultado['pendencias'].append('autorizacoes_secundarias_pendentes')
        if not admissoes.origens_completas:
            resultado['pendencias'].append('origens_admissoes_incompletas')
        if not gates_operacionais:
            resultado['pendencias'].append('admissoes_operacionais_abertas')
        if any(c['cobertura_declarada'] == 'incompleta' for c in admissoes.controles):
            resultado['pendencias'].append('cobertura_admissoes_incompleta')
        if not resultado['responsabilidades_conhecidas_resolvidas']:
            resultado['pendencias'].append('responsabilidades_conhecidas_pendentes')
    except Exception:
        resultado['pendencias'].append('falha_consulta_ou_contrato')
    return resultado

# CONFIG: controla admissão e acompanhamento da obtenção das faixas metrológicas.
"""CONFIG por geração: operação e endereços distintos, sem novo registro de IO."""
from contextlib import contextmanager
from dataclasses import dataclass
import socket
from threading import Lock, get_ident

from rede.infraestrutura_cliente import RecursosLeitorCliente, SocketClienteRegistrado


class ConfigRecusado(Exception):
    """Recusa interna; o tratamento de saída do leitor permanece o existente."""


@dataclass(frozen=True, eq=False)
class IdentidadeConfig:
    numero: int
    tipo: str


class AdmissaoConfigCliente:
    def __init__(self, autoridade):
        self._autoridade = autoridade
        self._lock = autoridade._lock
        self._registro = autoridade._registro
        self._aplicacao_id = autoridade._aplicacao_id
        self._geracao_id = autoridade._geracao_id
        self._atividade_id = autoridade._atividade_id
        self._geracao = autoridade._geracao
        self._sequencia = 0
        self._operacoes = {}
        self._lock_publicacoes = Lock()
        self._publicacoes_pendentes = {}

    def _novo(self, tipo):
        self._sequencia += 1
        identidade = IdentidadeConfig(self._sequencia, tipo)
        return identidade, {
            'identidade': identidade, 'iniciada': False, 'em_curso': False,
            'thread': None, 'retorno': False, 'finalizacao_tentada': False,
            'erro_operacao': None, 'erro_publicacao': False,
            'erro_associacao': False, 'dono': None,
        }

    def _buscar(self, identidade):
        if type(identidade) is not IdentidadeConfig or identidade not in self._operacoes:
            raise ValueError('operacao_config_estrangeira')
        return self._operacoes[identidade]

    def admitir(self):
        with self._lock:
            if self._autoridade._fechada:
                return None
            identidade, item = self._novo('config')
            item['tentativas'] = []
            self._operacoes[identidade] = item
            return identidade

    def _validar(self, item):
        if not item['em_curso'] or item['thread'] != get_ident():
            raise RuntimeError('config_fora_da_execucao_admitida')

    def admitir_tentativa(self, operacao):
        with self._lock:
            item = self._buscar(operacao)
            self._validar(item)
            if self._autoridade._fechada:
                return None
            identidade, tentativa = self._novo('endereco_config')
            # Referência segura ao endereço pela ordem operacional, sem host/IP.
            tentativa['endereco_indice'] = len(item['tentativas']) + 1
            tentativa['conectada'] = False
            tentativa['comunicacao_iniciada'] = False
            item['tentativas'].append(tentativa)
            return identidade

    def _tentativa(self, operacao, identidade):
        item = self._buscar(operacao)
        if type(identidade) is not IdentidadeConfig:
            raise ValueError('tentativa_config_estrangeira')
        for tentativa in item['tentativas']:
            if tentativa['identidade'] is identidade:
                return tentativa
        raise ValueError('tentativa_config_estrangeira')

    @staticmethod
    def _erro(erro):
        return None if erro is None else {'categoria': (
            'falha_io' if isinstance(erro, OSError) else
            'falha_operacao' if isinstance(erro, Exception) else 'falha_base')}

    def _publicar_saida(self, item, erro):
        with self._lock:
            item['erro_operacao'] = self._erro(erro)
            item['retorno'] = True

    def _finalizar(self, item, original):
        with self._lock:
            if item['finalizacao_tentada']:
                return
            item['finalizacao_tentada'] = True
            item['erro_operacao'] = self._erro(original)
        try:
            self._publicar_saida(item, original)
        except BaseException as publicacao:
            with self._lock:
                item['erro_publicacao'] = True
                item['retorno'] = False
            if original is None:
                raise
            original.__cause__ = publicacao
            original.__suppress_context__ = True
        finally:
            with self._lock:
                item['em_curso'] = False

    @contextmanager
    def executar(self, identidade):
        with self._lock:
            item = self._buscar(identidade)
            if item['iniciada']:
                raise RuntimeError('config_ja_iniciada')
            item.update(iniciada=True, em_curso=True, thread=get_ident())
        try:
            dono = RecursosConfigCliente(self, identidade)
            with self._lock:
                item['dono'] = dono
            yield dono
        except BaseException as original:
            self._finalizar(item, original)
            raise
        else:
            self._finalizar(item, None)

    def _retrato_item(self, item, estados):
        dono = item['dono']
        vinculos = [] if not isinstance(dono, RecursosTentativaConfig) else dono.obter_vinculos()
        recursos = [{'recurso_id': token.numero, 'tipo': tipo,
                     'associacao_publicada': publicado,
                     'limpeza_confirmada': estados.get(token.numero, {}).get('encerramento_confirmado', False)}
                    for token, tipo, publicado in vinculos]
        resolvida = (self._registro is not None and item['retorno'] and not item['em_curso']
                     and not item['erro_publicacao'] and not item['erro_associacao']
                     and all(r['associacao_publicada'] and r['limpeza_confirmada'] for r in recursos))
        return {
            'identidade_id': item['identidade'].numero, 'tipo': item['identidade'].tipo,
            **{nome: item[nome] for nome in ('iniciada', 'em_curso', 'retorno',
                'erro_publicacao', 'erro_associacao')},
            'erro_operacao': None if item['erro_operacao'] is None else item['erro_operacao'].copy(),
            'recursos': recursos, 'responsabilidade_resolvida': bool(resolvida),
        }

    def obter_retrato(self):
        with self._lock:
            itens = [(item.copy(), [t.copy() for t in item['tentativas']])
                     for item in self._operacoes.values()]
            fechada = self._autoridade._fechada
        estados = {} if self._registro is None else {
            r['recurso_id']: r for r in self._registro.obter_retrato()['recursos']}
        operacoes = []
        for item, tentativas in itens:
            operacao = self._retrato_item(item, estados)
            operacao['tentativas'] = [dict(self._retrato_item(t, estados),
                endereco_indice=t['endereco_indice'], conectada=t['conectada'],
                comunicacao_iniciada=t['comunicacao_iniciada']) for t in tentativas]
            operacao['responsabilidade_resolvida'] = (operacao['responsabilidade_resolvida']
                and all(t['responsabilidade_resolvida'] for t in operacao['tentativas']))
            operacoes.append(operacao)
        return {'aplicacao_id': self._aplicacao_id, 'geracao_id': self._geracao_id,
                'atividade_recursos_id': self._atividade_id, 'admissao_fechada': fechada,
                'operacoes': operacoes, 'cobertura_operacional': 'incompleta',
                'encerramento_global_confirmado': False}


class RecursosConfigCliente:
    def __init__(self, controle, operacao):
        self._controle, self._operacao = controle, operacao

    @contextmanager
    def _escopo_endereco(self, destino):
        controle = self._controle
        identidade = controle.admitir_tentativa(self._operacao)
        if identidade is None:
            raise ConfigRecusado()
        with controle._lock:
            item = controle._tentativa(self._operacao, identidade)
            item.update(iniciada=True, em_curso=True, thread=get_ident())
        try:
            dono = RecursosTentativaConfig(controle, self._operacao, item)
            with controle._lock:
                item['dono'] = dono
            yield dono
        except BaseException as original:
            controle._finalizar(item, original)
            raise
        else:
            with controle._lock:
                if not item['finalizacao_tentada']:
                    item['conectada'] = True

    def conectar_tcp(self, endereco, *, timeout=5):
        # Mesmo subset/ordem do conector compartilhado; restrito a CONFIG.
        host, porta = endereco
        ultimo_erro = None
        for familia, tipo, protocolo, _nome, destino in socket.getaddrinfo(
                host, porta, 0, socket.SOCK_STREAM):
            with self._escopo_endereco(destino) as tentativa:
                cliente = None
                try:
                    cliente = tentativa.abrir_socket(lambda: socket.socket(familia, tipo, protocolo))
                    cliente.settimeout(timeout)
                    cliente.connect(destino)
                    return cliente
                except BaseException as erro:
                    if cliente is not None:
                        try:
                            cliente.close()
                        except BaseException:
                            raise erro from None
                    if not isinstance(erro, OSError):
                        raise
                    self._controle._finalizar(tentativa._item, erro)
                    ultimo_erro = erro
        if ultimo_erro is not None:
            raise ultimo_erro
        raise OSError('getaddrinfo returns an empty list')

    def ler_configuracao(self, cliente, receber_linha):
        controle = self._controle
        if controle._registro is None:
            with controle._lock:
                item = controle._buscar(self._operacao)['tentativas'][-1]
                dono = item['dono']
            if cliente is not dono._cliente_legado:
                raise ValueError('socket_config_estrangeiro')
        else:
            if (not isinstance(cliente, SocketClienteRegistrado)
                    or not isinstance(cliente.dono, RecursosTentativaConfig)
                    or cliente.dono._controle is not controle
                    or cliente.dono._operacao is not self._operacao):
                raise ValueError('socket_config_estrangeiro')
            dono = cliente.dono
            item = dono._item
        with controle._lock:
            controle._validar(item)
            item['comunicacao_iniciada'] = True
        try:
            resultado = dono.ler_configuracao(cliente, receber_linha)
        except BaseException as original:
            controle._finalizar(item, original)
            raise
        else:
            controle._finalizar(item, None)
            return resultado


class RecursosTentativaConfig(RecursosLeitorCliente):
    def __init__(self, controle, operacao, item):
        self._controle, self._operacao, self._item = controle, operacao, item
        self.registro, self.geracao_id = controle._registro, controle._geracao_id
        self.atividade_id = controle._atividade_id
        self._geracao_retentativas = controle._geracao
        self._lock_publicacoes = controle._lock_publicacoes
        self._publicacoes_pendentes = controle._publicacoes_pendentes
        self._lock_vinculos = Lock()
        self._emitidos = {}
        self._cliente_legado = None
        self._handles_legados_pendentes = []

    def _criar(self, tipo, fabrica, *, associado_a=None):
        return super()._criar(tipo, fabrica, associado_a=associado_a,
                              _preservar_erro_ausencia=True)

    def abrir_socket(self, fabrica):
        if self.registro is None:
            self._cliente_legado = fabrica()
            return self._cliente_legado
        return super().abrir_socket(fabrica)

    def _publicar_vinculo(self, token, tipo):
        with self._lock_vinculos:
            self._emitidos[token] = (tipo, True)

    def _reservar_recurso(self, tipo, associado_a):
        with self._controle._lock:
            self._controle._validar(self._controle._buscar(self._operacao))
            self._controle._validar(self._item)
        token = super()._reservar_recurso(tipo, associado_a)
        if token is None:
            return None
        try:
            with self._lock_vinculos:
                self._emitidos[token] = (tipo, False)
            self._publicar_vinculo(token, tipo)
        except BaseException as original:
            with self._controle._lock:
                self._item['erro_associacao'] = True
            try:
                self.registro.comprovar_ausencia(token, nao_alocado=True)
            except BaseException as prova:
                original.__cause__ = prova
                original.__suppress_context__ = True
            raise
        return token

    def obter_vinculos(self):
        with self._lock_vinculos:
            return [(token, tipo, publicado) for token, (tipo, publicado) in self._emitidos.items()]

    def ler_configuracao(self, cliente, receber_linha):
        if self.registro is not None:
            return super().ler_configuracao(cliente, receber_linha)
        arquivo = None
        original = None
        try:
            cliente.sendall(b'CONFIG\n')
            arquivo = cliente.makefile('r', encoding='utf-8')
            return receber_linha(arquivo.readline())
        except BaseException as erro:
            original = erro
            raise
        finally:
            erro_limpeza = None
            for recurso in (arquivo, cliente):
                if recurso is not None:
                    try:
                        recurso.close()
                    except BaseException as erro:
                        self._handles_legados_pendentes.append((recurso, self._controle._erro(erro)))
                        if erro_limpeza is None:
                            erro_limpeza = erro
            if original is None and erro_limpeza is not None:
                raise erro_limpeza

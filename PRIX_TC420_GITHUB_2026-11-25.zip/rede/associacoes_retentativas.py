# Associações: relaciona as identidades de retentativas aos recursos reservados por seus adaptadores.
"""Recursos emitidos explicitamente pela execução de uma retentativa, sem agregado global."""
from threading import Lock

from rede.infraestrutura_cliente import RecursosLeitorCliente


class RecursosRetentativaCliente(RecursosLeitorCliente):
    def __init__(self, acompanhamento, identidade, origem):
        self._acompanhamento = acompanhamento
        self._identidade = identidade
        self.registro = origem.registro
        self.geracao_id = origem.geracao_id
        self.atividade_id = identidade.numero
        self._geracao_retentativas = origem._geracao_retentativas
        self._lock_publicacoes = Lock()
        self._publicacoes_pendentes = {}
        self._lock_vinculos = Lock()
        self._emitidos = []
        self._vinculos = {}
        self._erro_associacao = False
        from rede.admissao_checks_cliente import AdmissaoChecksCliente
        self._admissao_checks = AdmissaoChecksCliente(recuperacao=self)

    def _associar_reserva(self, token, tipo):
        with self._lock_vinculos:
            if not any(token is emitido for emitido in self._emitidos):
                raise ValueError("recurso_sem_evidencia_de_criacao")
            anterior = self._vinculos.get(token)
            if anterior is not None and anterior != tipo:
                raise ValueError("associacao_incompativel")
            self._vinculos[token] = tipo

    def _reservar_recurso(self, tipo, associado_a):
        if not self._acompanhamento.execucao_em_curso(self._identidade):
            raise RuntimeError("recurso_fora_da_execucao_da_retentativa")
        token = super()._reservar_recurso(tipo, associado_a)
        if token is None:
            return None
        try:
            with self._lock_vinculos:
                self._emitidos.append(token)
            self._associar_reserva(token, tipo)
        except BaseException as original:
            with self._lock_vinculos:
                self._erro_associacao = True
            try:
                self.registro.comprovar_ausencia(token, nao_alocado=True)
            except BaseException as prova:
                original.__cause__ = prova
                original.__suppress_context__ = True
            raise
        return token

    def obter_vinculos(self):
        with self._lock_vinculos:
            vinculos = tuple(self._vinculos.items())
            erro = self._erro_associacao
        estados = {r["recurso_id"]: r for r in self.registro.obter_retrato()["recursos"]}
        return erro, [{"recurso_id": token.numero, "tipo": tipo,
                       "responsabilidade": "proprio", "evidencia": "reserva_no_adaptador_da_retentativa",
                       "estado": estados.get(token.numero, {}).get("estado", "desconhecido"),
                       "criacao_resolvida": estados.get(token.numero, {}).get("criacao_resolvida", False),
                       "limpeza_confirmada": estados.get(token.numero, {}).get("encerramento_confirmado", False)}
                      for token, tipo in vinculos]

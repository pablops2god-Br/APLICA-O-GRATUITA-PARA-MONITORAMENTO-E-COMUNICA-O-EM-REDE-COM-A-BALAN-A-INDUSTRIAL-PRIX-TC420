# Fachada operacional: reúne registros e adaptadores de recursos, retentativas, atividades e HTTP.
"""Registros CLIENTE de rede e acompanhamento de login/approval HTTP.

Reutiliza contratos experimentais sem copiá-los. A dependência fica confinada
a esta fachada; não fornece caminho para declarar cobertura operacional completa.
"""
from dataclasses import dataclass
from contextvars import ContextVar
import socket
from threading import Lock, get_ident

from prototipos.composicao_cliente import (
    CoberturaCliente, ContextoClienteExperimental, avaliar_cliente,
)
from prototipos.guarda_retentativas_cliente import GuardaRetentativasCliente
from prototipos.recursos_cliente import RegistroRecursosCliente
from prototipos.operacoes_http_cliente import RegistroOperacoesHttpCliente


# Reúne os componentes da instalação em uma estrutura cuja identidade será validada nas entradas.
@dataclass(frozen=True, slots=True)
class _InstalacaoCliente:
    contexto: ContextoClienteExperimental
    http: RegistroOperacoesHttpCliente
    lock_descobertas: object
    donos_descobertas: list


# Retém as referências originais usadas para verificar coerência da instalação HTTP.
@dataclass(frozen=True, slots=True)
class _ReferenciasHttp:
    """Vínculos fixos, sem copiar registros ou congelar seu estado operacional."""
    instalacao: _InstalacaoCliente
    contexto: ContextoClienteExperimental
    http: RegistroOperacoesHttpCliente
    recursos: RegistroRecursosCliente
    retentativas: GuardaRetentativasCliente
    aplicacao_id: str


# Monta e expõe a infraestrutura compartilhada pelos caminhos operacionais desta execução.
@dataclass(frozen=True, init=False)
class InfraestruturaRegistrosCliente:
    # Slots explícitos preservam o __setattr__ frozen e as exceções anteriores,
    # sem dicionário de instância ou substituição do conjunto fixado por vars().
    __slots__ = ("_instalacao", "_referencias_http", "_lock_arquivos", "_contextos_arquivos",
                 "_lock_retentativas", "_acompanhamentos_retentativas", "_atividades_permanentes", "_admissoes_descoberta_inicial",
                 "_admissoes_config", "_admissoes_subscribe", "_preparacoes", "_saida_aplicacao")
    _instalacao: _InstalacaoCliente

    # Cria registros e vínculos uma única vez para que todos os adaptadores usem as mesmas identidades.
    def __init__(self):
        if hasattr(self, "_instalacao"):
            raise RuntimeError("infraestrutura_ja_inicializada")
        # Montagem local; um único ponto de publicação após todos os registros.
        retentativas = GuardaRetentativasCliente()
        recursos = RegistroRecursosCliente()
        contexto = ContextoClienteExperimental.vincular(retentativas, recursos)
        http = RegistroOperacoesHttpCliente(self, contexto.aplicacao_id)
        instalacao = _InstalacaoCliente(contexto, http, Lock(), [])
        object.__setattr__(self, "_admissoes_descoberta_inicial", [])
        object.__setattr__(self, "_admissoes_config", [])
        object.__setattr__(self, "_admissoes_subscribe", [])
        object.__setattr__(self, "_saida_aplicacao", None)
        referencias = _ReferenciasHttp(instalacao, contexto, http, recursos, retentativas, contexto.aplicacao_id)
        object.__setattr__(self, "_referencias_http", referencias)
        object.__setattr__(self, "_instalacao", instalacao)
        object.__setattr__(self, "_lock_arquivos", Lock())
        object.__setattr__(self, "_contextos_arquivos", [])
        object.__setattr__(self, "_lock_retentativas", Lock())
        object.__setattr__(self, "_acompanhamentos_retentativas", [])
        from rede.atividades_permanentes_cliente import RegistroAtividadesPermanentesCliente
        object.__setattr__(self, "_atividades_permanentes", RegistroAtividadesPermanentesCliente(self))
        from rede.preparacoes_cliente import RegistroPreparacoesCliente
        object.__setattr__(self, "_preparacoes", RegistroPreparacoesCliente(self))

    @property
    def registro_preparacoes(self):
        return self._preparacoes

    @property
    def saida_aplicacao(self):
        return self._saida_aplicacao

    # Associa o dono da saída à infraestrutura sem permitir substituições incompatíveis.
    def instalar_saida(self, saida):
        with self._lock_retentativas:
            if self._saida_aplicacao is not None and self._saida_aplicacao is not saida:
                raise ValueError('saida_de_outra_execucao')
            object.__setattr__(self, '_saida_aplicacao', saida)

    # Fecha as admissões acompanhadas; trabalhos já admitidos continuam precisando de observação e limpeza.
    def bloquear_novos_trabalhos(self):
        # Gates locais existentes; IO e esperas sao tarefas do worker B2.
        controles = (self.registro_retentativas, self.registro_recursos,
                     self.registro_http, self.registro_atividades_permanentes)
        controles += self.registro_atividades_permanentes.obter_controles_register()
        controles += tuple(self._admissoes_descoberta_inicial)
        primeiro = None
        for controle in controles:
            try:
                controle.fechar_admissao()
            except BaseException as erro:
                if primeiro is None:
                    primeiro = erro
        if primeiro is not None:
            raise primeiro

    # Enumera tarefas de limpeza para execução pelo coordenador, em vez de fechar recursos na consulta.
    def tarefas_encerramento(self, leitores=(), *, limpar_retidos=False):
        from functools import partial
        tarefas = [(('recurso', token), partial(self.registro_recursos.interromper_e_fechar, token))
                   for token in self.registro_recursos.identidades_para_encerramento()]
        for item in self.obter_pendencias_arquivos() if limpar_retidos else ():
            numero = item['recurso_id']
            tarefas.append((('arquivo_retido', numero), partial(self.tentar_limpeza_arquivo, numero)))
        if not limpar_retidos:
            return tarefas
        with self._instalacao.lock_descobertas:
            donos = list(self._instalacao.donos_descobertas)
        donos.extend(l.recursos_cliente for l in leitores if getattr(l, 'recursos_cliente', None) is not None)
        with self._lock_retentativas:
            acompanhamentos = tuple(self._acompanhamentos_retentativas)
        for acompanhamento in acompanhamentos:
            with acompanhamento._lock:
                donos.extend(i['recursos'] for i in acompanhamento._escopos.values() if i['recursos'] is not None)
        donos.extend(self.registro_atividades_permanentes.obter_controles_register())
        for dono in donos:
            with dono._lock_publicacoes:
                tokens = tuple(dono._publicacoes_pendentes)
            for token in tokens:
                tarefas.append((('handle_retido', id(dono), token),
                                partial(self._limpar_handle_retido, dono, token)))
        return tarefas

    # Tenta interromper e fechar um objeto retido após falha de associação ou publicação.
    @staticmethod
    def _limpar_handle_retido(dono, token):
        with dono._lock_publicacoes:
            objeto, _erro = dono._publicacoes_pendentes[token]
        registro = getattr(dono, 'registro', None) or dono._registro
        estado = next(r for r in registro.obter_retrato()['recursos'] if r['recurso_id'] == token.numero)
        if estado['encerramento_confirmado']:
            with dono._lock_publicacoes:
                dono._publicacoes_pendentes.pop(token, None)
            return
        interromper = getattr(objeto, 'shutdown', None)
        if interromper is not None:
            try:
                interromper(2)
            except OSError:
                pass
        objeto.close()
        if hasattr(objeto, 'closed') and objeto.closed is not True:
            raise RuntimeError('fechamento_handle_nao_comprovado')
        with dono._lock_publicacoes:
            dono._publicacoes_pendentes.pop(token, None)

    # Reúne os motivos que ainda impedem a confirmação da parada operacional desta infraestrutura.
    def pendencias_encerramento(self):
        """Pendencias operacionais conhecidas; nao certifica cobertura global."""
        pendencias = []
        r = self.registro_recursos.obter_retrato()
        if not r['encerramento_confirmado']:
            pendencias.append('recursos_cliente_pendentes')
        if any(i['erros_limpeza'] or i['erros_evidencia'] for i in r['recursos']):
            pendencias.append('falha_limpeza_cliente')
        if not self.registro_retentativas.obter_retrato()['conjunto_encerrado']:
            pendencias.append('retentativas_pendentes')
        if not self.registro_http.obter_retrato()['conjunto_http_resolvido']:
            pendencias.append('http_pendente')
        for item in self.obter_preparacoes()['preparacoes']:
            if not item['execucao_resolvida'] or not item['recursos_conhecidos_resolvidos']:
                pendencias.append('preparacao_pendente')
        resultado = self.avaliar_responsabilidades_cliente()
        if not resultado['leituras_revalidadas']:
            pendencias.append('consulta_cliente_desconhecida')
        for item in resultado['admissoes']:
            if not item['responsabilidade_resolvida']:
                pendencias.append('operacao_cliente_pendente')
        if resultado['retencoes_pendentes']:
            pendencias.append('retencao_pendente')
        for item in resultado['atividades_permanentes']:
            if not item['termino_confirmado']:
                pendencias.append('atividade_permanente_pendente')
        for item in resultado['autorizacoes_secundarias']:
            if not item['responsabilidade_resolvida']:
                pendencias.append('autorizacao_secundaria_pendente')
        return pendencias

    def obter_preparacoes(self):
        """Acompanhamento separado; ainda nao incorporado a composicao."""
        return self._preparacoes.obter_retrato()

    def obter_evidencia_temporal_preparacoes(self):
        """Estado local e revisao; nao versiona dependencias nem amplia composicao."""
        return self._preparacoes.obter_evidencia_temporal()

    # Admite e acompanha a preparação da descoberta, vinculando os recursos antes de chamar a operação.
    def executar_descoberta_preparacao(self, operacao):
        """Identidade antes de criar o dono existente ou reservar o primeiro UDP."""
        registro = self.registro_preparacoes
        identidade = registro.admitir()

        def executar():
            dono = self.preparar_descoberta()
            registro.vincular_recursos(identidade, dono)
            return operacao(dono)

        return registro.executar(identidade, executar)

    @property
    def registro_atividades_permanentes(self):
        return self._atividades_permanentes

    def obter_atividades_permanentes(self):
        """Retrato passivo, sem consultar a thread concreta."""
        return self._atividades_permanentes.obter_retrato()

    def obter_evidencia_temporal_atividades_permanentes(self):
        """Selo local do registro; sem observacao de thread ou consulta de recursos."""
        return self._atividades_permanentes.obter_evidencia_temporal()

    def obter_operacoes_register(self):
        """Retratos já existentes, inclusive de gerações antigas; sem ações."""
        return [controle.obter_retrato()
                for controle in self._atividades_permanentes.obter_controles_register()]

    def obter_evidencias_temporais_register(self):
        """Selos locais por controle retido; lista sem inventario versionado."""
        return [controle.obter_evidencia_temporal()
                for controle in self._atividades_permanentes.obter_controles_register()]

    # Atualiza evidências de término das threads dos leitores permanentes acompanhados.
    def observar_termino_leitores(self):
        """Ação explícita sem espera; separada da composição e da limpeza."""
        return self._atividades_permanentes.observar_terminos()

    # Conserva os acompanhamentos de recuperação para consulta e limpeza posteriores.
    def _reter_acompanhamento_retentativas(self, acompanhamento):
        if (acompanhamento._proprietario is not self
                or acompanhamento._guarda is not self.registro_retentativas):
            raise ValueError("acompanhamento_retentativas_estrangeiro")
        with self._lock_retentativas:
            if not any(item is acompanhamento for item in self._acompanhamentos_retentativas):
                self._acompanhamentos_retentativas.append(acompanhamento)

    # Observa as threads de recuperação retidas sem interpretar apenas retorno de função como término.
    def observar_termino_retentativas(self):
        """Consulta explícita sem espera; não é avaliação global nem limpeza."""
        with self._lock_retentativas:
            acompanhamentos = tuple(self._acompanhamentos_retentativas)
        return [resultado for acompanhamento in acompanhamentos
                for resultado in acompanhamento.observar_terminos()]

    def obter_evidencia_temporal_retentativas(self):
        """Selo da guarda original; nao observa threads nem consulta recursos."""
        return self.registro_retentativas.obter_evidencia_temporal() | {
            'aplicacao_id': self.aplicacao_id}

    def obter_associacoes_retentativas(self):
        """Vínculos explícitos; não observa término nem fecha recursos."""
        with self._lock_retentativas:
            acompanhamentos = tuple(self._acompanhamentos_retentativas)
        return [resultado for acompanhamento in acompanhamentos
                for resultado in acompanhamento.obter_associacoes()]

    # Conserva o contexto de arquivos pertencente a esta infraestrutura para a saída encontrá-lo depois.
    def _reter_contexto_arquivos(self, contexto):
        if contexto._proprietario is not self:
            raise ValueError("contexto_arquivos_estrangeiro")
        with self._lock_arquivos:
            if not any(item is contexto for item in self._contextos_arquivos):
                self._contextos_arquivos.append(contexto)

    def obter_contextos_arquivos(self):
        with self._lock_arquivos:
            return tuple(self._contextos_arquivos)

    def obter_pendencias_arquivos(self):
        return [pendencia for contexto in self.obter_contextos_arquivos()
                for pendencia in contexto.obter_pendencias()]

    # Procura a identidade nos contextos retidos e solicita nova tentativa de limpeza.
    def tentar_limpeza_arquivo(self, recurso_id):
        """Tentativa explícita e síncrona; nunca chamada pelo encerramento/Tk."""
        for contexto in self.obter_contextos_arquivos():
            if contexto.tentar_limpeza(recurso_id):
                return True
        return False

    @property
    def _contexto(self):
        return self._instalacao.contexto

    @property
    def _lock_descobertas(self):
        return self._instalacao.lock_descobertas

    @property
    def _donos_descobertas(self):
        return self._instalacao.donos_descobertas

    @property
    def registro_http(self):
        """Mesmo registro por aplicação, inclusive depois de promoções."""
        return self._referencias_http.http

    # Usa um contexto inicial admitido para executar o login automático pelo registro HTTP.
    def executar_login_automatico(self, web, usuario, senha, *, contexto_http=None):
        """Preparação sem leitor; apenas login, sem reter argumentos sensíveis.

        A chamada síncrona inteira (incluindo interpretação) roda fora dos locks.
        Não acompanha approval nem transfere o contexto ao objeto compartilhado.
        """
        if contexto_http is None:
            contexto_http = self.preparar_http_inicial()
        return self._executar_login_http(contexto_http, web, usuario, senha)

    # Abre a geração e o contexto de acompanhamento para o primeiro login desta tentativa.
    def preparar_http_inicial(self):
        """Origem explícita da preparação, compartilhável por login e approval."""
        geracao = self.registro_retentativas.nova_geracao_cliente()
        if geracao is None:
            raise RuntimeError("admissao_preparacao_http_recusada")
        registro = self.registro_http
        contexto = registro.criar_contexto(geracao.numero, geracao.numero)
        if contexto is None:
            raise RuntimeError("admissao_contexto_http_recusada")
        return contexto

    # Exige que a origem da promoção pertença à infraestrutura antes de criar o contexto HTTP.
    def preparar_http_promocao(self, recursos_cliente):
        """Captura o leitor de origem, sem criar geração ou inferir a atual."""
        if (not isinstance(recursos_cliente, RecursosLeitorCliente)
                or recursos_cliente.registro is not self.registro_recursos):
            raise ValueError("origem_http_invalida")
        contexto = self.registro_http.criar_contexto(
            recursos_cliente.geracao_id, recursos_cliente.atividade_id,
        )
        if contexto is None:
            raise RuntimeError("admissao_contexto_http_recusada")
        return contexto

    # Valida a origem e executa o login de promoção com o contexto de acompanhamento correspondente.
    def executar_login_promocao(self, recursos_cliente, web, usuario, senha, *, contexto_http=None):
        """Login atribuído ao leitor de origem, sem criar outra geração."""
        if contexto_http is None:
            contexto_http = self.preparar_http_promocao(recursos_cliente)
        elif (not isinstance(recursos_cliente, RecursosLeitorCliente)
              or recursos_cliente.registro is not self.registro_recursos
              or contexto_http.geracao_id != recursos_cliente.geracao_id
              or contexto_http.atividade_id != recursos_cliente.atividade_id):
            raise ValueError("origem_http_invalida")
        return self._executar_login_http(contexto_http, web, usuario, senha)

    # Encaminha as credenciais do formulário pela mesma execução HTTP acompanhada.
    def executar_login_manual(self, web, usuario, senha, *, contexto_http=None):
        """Preparação da conexão inicial, anterior a qualquer leitor CLIENTE."""
        if contexto_http is None:
            contexto_http = self.preparar_http_inicial()
        return self._executar_login_http(contexto_http, web, usuario, senha)

    # Seleciona login como operação registrada, conservando a política associada à instância web.
    def _executar_login_http(self, contexto, web, usuario, senha):
        return self._executar_operacao_http(contexto, "login", web, "login", (usuario, senha))

    # Executa a obtenção interpretada das faixas como operação approval acompanhada.
    def executar_approval(self, contexto_http, web):
        """Um GET e sua interpretação; nenhuma nova origem nem acesso ao Tk."""
        return self._executar_operacao_http(
            contexto_http, "approval", web, "obter_configuracao", (),
        )

    # Cria a política vinculada a este dono para autorizar as chamadas HTTP admitidas.
    def criar_politica_http(self):
        """Vínculo sem registro novo; o dono continua sendo esta infraestrutura."""
        return PoliticaHttpCliente(self)

    # Admite a operação, confere a política e publica retorno/falha sem perder execuções de resultado incerto.
    def _executar_operacao_http(self, contexto, operacao, web, metodo, argumentos):
        # Um único contrato; não instrumentar o método web novamente.
        registro = self.registro_http
        if contexto is None:
            raise RuntimeError("admissao_contexto_http_recusada")
        politica = getattr(web, "politica_http", None)
        if politica is not None and (not isinstance(politica, PoliticaHttpCliente)
                                     or politica.proprietario is not self):
            raise ValueError("politica_http_de_outro_proprietario")
        tipo_operacao = operacao
        operacao = registro.admitir(contexto, operacao)
        if operacao is None:
            raise RuntimeError("admissao_operacao_http_recusada")
        entrou = False
        try:
            chamada = getattr(web, metodo)
            if not callable(chamada):
                raise TypeError(f"{metodo}_nao_executavel")

            def executar():
                nonlocal entrou
                entrou = True
                if politica is not None:
                    return politica._executar_admitida(operacao, web, tipo_operacao, chamada, argumentos)
                return chamada(*argumentos)

            return registro.executar(operacao, executar)
        except BaseException as erro:
            if not entrou:
                # O executor é síncrono e não retém/agenda callbacks: depois de
                # abortar sem entrar não existe chamada futura. Se o registro já
                # observou início, a prova é recusada e a incerteza permanece.
                try:
                    if not registro.comprovar_nao_inicio(operacao, nao_executada=True, erro=erro):
                        registro.marcar_desconhecida(operacao, motivo="inicio_ambiguo")
                except BaseException:
                    registro.marcar_desconhecida(operacao, motivo="falha_publicacao")
            raise

    # Retém o controle da descoberta inicial após conferir sua origem.
    def reter_admissao_descoberta_inicial(self, controle):
        from rede.admissao_descoberta_inicial_cliente import AdmissaoDescobertaInicialCliente
        if (type(controle) is not AdmissaoDescobertaInicialCliente
                or controle._registro is not self.registro_recursos
                or controle._aplicacao_id != self.aplicacao_id):
            raise ValueError("controle_descoberta_inicial_estrangeiro")
        with self._lock_descobertas:
            if not any(item is controle for item in self._admissoes_descoberta_inicial):
                self._admissoes_descoberta_inicial.append(controle)

    def obter_operacoes_descoberta_inicial(self):
        """Ret?m tamb?m gera??es antigas; n?o observa threads nem limpa IO."""
        with self._lock_descobertas:
            controles = tuple(self._admissoes_descoberta_inicial)
        return [controle.obter_retrato() for controle in controles]

    # Retém o controle de CONFIG para consulta posterior de operações e admissões.
    def reter_admissao_config(self, controle):
        from rede.admissao_config_cliente import AdmissaoConfigCliente
        if (type(controle) is not AdmissaoConfigCliente
                or controle._registro is not self.registro_recursos
                or controle._aplicacao_id != self.aplicacao_id):
            raise ValueError("controle_config_estrangeiro")
        with self._lock_descobertas:
            if not any(item is controle for item in self._admissoes_config):
                self._admissoes_config.append(controle)

    def obter_operacoes_config(self):
        with self._lock_descobertas:
            controles = tuple(self._admissoes_config)
        return [controle.obter_retrato() for controle in controles]

    # Retém o controle de SUBSCRIBE para acompanhar tentativas de conexão e limpeza.
    def reter_admissao_subscribe(self, controle):
        from rede.admissao_subscribe_cliente import AdmissaoSubscribeCliente
        if (type(controle) is not AdmissaoSubscribeCliente
                or controle._registro is not self.registro_recursos
                or controle._aplicacao_id != self.aplicacao_id):
            raise ValueError("controle_subscribe_estrangeiro")
        with self._lock_descobertas:
            if not any(item is controle for item in self._admissoes_subscribe):
                self._admissoes_subscribe.append(controle)

    def obter_tentativas_subscribe(self):
        with self._lock_descobertas:
            controles = tuple(self._admissoes_subscribe)
        return [controle.obter_retrato() for controle in controles]

    # Cria um dono de recursos de descoberta e o retém antes da comunicação.
    def preparar_descoberta(self):
        # Preparações não têm leitor durável. Reter também publicações incertas
        # e seus handles, mesmo quando a função de busca retorna ou lança.
        dono = RecursosLeitorCliente(self)
        with self._lock_descobertas:
            self._donos_descobertas.append(dono)
        return dono

    @property
    def aplicacao_id(self):
        return self._referencias_http.aplicacao_id

    @property
    def registro_retentativas(self):
        return self._referencias_http.retentativas

    @property
    def registro_recursos(self):
        return self._referencias_http.recursos

    # Consulta a composição operacional dos registros, sem executar fechamento de recursos.
    def avaliar_responsabilidades_cliente(self):
        """AC3-A: composição passiva, separada da observação explícita de término."""
        from rede.composicao_operacional_cliente import avaliar_responsabilidades_cliente
        return avaliar_responsabilidades_cliente(self)

    # Aciona o avaliador de cobertura disponível na infraestrutura; o resultado respeita o escopo declarado.
    def avaliar(self):
        # Mesmo vazios/fechados, registros não cobrem os caminhos reais ainda.
        cobertura = CoberturaCliente(self._contexto, completa=False)
        resultado = avaliar_cliente(self._contexto, cobertura)
        resultado["cobertura_operacional"] = "incompleta"
        return resultado


# Representa autorização de uma chamada específica, vinculada ao contexto e à thread de execução.
class _PermissaoHttp:
    __slots__ = ("identidade", "web", "tipo", "thread", "usada", "ativa", "lock")

    # Captura os dados da permissão e a thread que pode utilizá-la.
    def __init__(self, identidade, web, tipo):
        self.identidade, self.web, self.tipo = identidade, web, tipo
        self.thread = get_ident()
        self.usada, self.ativa = False, True
        self.lock = Lock()


# Autoriza chamadas apenas durante a execução admitida pelo dono operacional correspondente.
class PoliticaHttpCliente:
    """Autorização efêmera, não registro de operações ou prova de publicação.

    Só o callback admitido pelo executor instala a permissão. ContextVar separa
    execuções; thread e uso único impedem aproveitamento de contexto copiado.
    """
    # Guarda o proprietário e prepara a variável de contexto que transporta a permissão temporária.
    def __init__(self, proprietario):
        self._proprietario = proprietario
        self._permissao = ContextVar("permissao_http_cliente", default=None)

    @property
    def proprietario(self):
        return self._proprietario

    # Instala a permissão apenas durante a chamada e restaura o contexto anterior em finally.
    def _executar_admitida(self, identidade, web, tipo, chamada, argumentos):
        # Método interno chamado somente dentro de registro.executar, depois
        # de validar identidade/início. Não concede permissão só por ter um ID.
        permissao = _PermissaoHttp(identidade, web, tipo)
        anterior = self._permissao.set(permissao)
        try:
            return chamada(*argumentos)
        finally:
            with permissao.lock:
                permissao.ativa = False
            self._permissao.reset(anterior)

    # Confere a permissão corrente, a operação, a instância web e a thread antes de liberar a requisição.
    def autorizar(self, web, tipo):
        permissao = self._permissao.get()
        if permissao is None:
            raise RuntimeError("http_fora_do_executor")
        with permissao.lock:
            if (not permissao.ativa or permissao.usada or permissao.web is not web
                    or permissao.tipo != tipo or permissao.thread != get_ident()):
                raise RuntimeError("autorizacao_http_invalida")
            permissao.usada = True


# Referências de tipo, não registros/globais de aplicação. Mantêm a validação
# independente de fábricas instrumentadas no chamador.
_TIPO_INFRAESTRUTURA_CLIENTE = InfraestruturaRegistrosCliente
_TIPO_REGISTRO_HTTP_CLIENTE = RegistroOperacoesHttpCliente


# Distingue recusas da montagem/identidade HTTP das falhas de transporte do equipamento.
class InfraestruturaHttpInvalida(RuntimeError):
    """Entrada HTTP sem o dono publicado; mensagem contém só código estático."""


# Exige uma instalação operacional reconhecida em vez de aceitar qualquer objeto com métodos parecidos.
def exigir_infraestrutura_http(infraestrutura):
    """Valida a referência recebida; não admite HTTP nem constrói registros."""
    if not isinstance(infraestrutura, _TIPO_INFRAESTRUTURA_CLIENTE):
        raise InfraestruturaHttpInvalida("infraestrutura_http_ausente_ou_invalida")
    try:
        registro = infraestrutura.registro_http
        aplicacao_id = infraestrutura.aplicacao_id
        referencias = infraestrutura._referencias_http
        instalacao = infraestrutura._instalacao
        contexto = instalacao.contexto
    except (AttributeError, TypeError):
        raise InfraestruturaHttpInvalida("registro_http_indisponivel") from None
    if (instalacao is not referencias.instalacao or contexto is not referencias.contexto
            or instalacao.http is not referencias.http
            or contexto.recursos is not referencias.recursos
            or contexto.retentativas is not referencias.retentativas
            or contexto.aplicacao_id != referencias.aplicacao_id):
        raise InfraestruturaHttpInvalida("instalacao_http_substituida")
    if (not isinstance(registro, _TIPO_REGISTRO_HTTP_CLIENTE)
            or registro.proprietario is not infraestrutura
            or registro.aplicacao_id != aplicacao_id):
        raise InfraestruturaHttpInvalida("registro_http_invalido")
    return infraestrutura


# Adapta sockets e arquivos do leitor aos registros de reserva, uso e fechamento de recursos.
class RecursosLeitorCliente:
    """Recursos do leitor; geração não representa uma retry instrumentada."""
    # Associa o adaptador à infraestrutura e à geração de recursos, conservando publicações pendentes.
    def __init__(self, infraestrutura):
        self.registro = infraestrutura.registro_recursos
        geracao = infraestrutura.registro_retentativas.nova_geracao_cliente()
        if geracao is None:
            raise RuntimeError("admissao_cliente_fechada")
        self.geracao_id = geracao.numero
        # Token opaco da mesma geração; não reconstruir identidade pelo número.
        self._geracao_retentativas = geracao
        # ID de atividade do leitor, sem admitir retentativa fictícia.
        self.atividade_id = geracao.numero
        self._lock_publicacoes = Lock()
        self._publicacoes_pendentes = {}

    def obter_publicacoes_pendentes(self):
        with self._lock_publicacoes:
            return [{"recurso_id": token.numero, "geracao_id": self.geracao_id,
                     "erro_limpeza": item[1]}
                    for token, item in self._publicacoes_pendentes.items()]

    # Pede uma identidade de recurso antes de executar a fábrica que aloca o objeto.
    def _reservar_recurso(self, tipo, associado_a):
        return self.registro.reservar(tipo, self.geracao_id, self.atividade_id,
                                     associado_a=associado_a)

    # Acompanha reserva e fábrica, retendo objetos cuja publicação ou limpeza falhe.
    def _criar(self, tipo, fabrica, *, associado_a=None, _preservar_erro_ausencia=False):
        token = self._reservar_recurso(tipo, associado_a)
        if token is None:
            raise RuntimeError("admissao_recurso_fechada")
        entrou, objetos = [], []

        def alocar():
            entrou.append(True)
            objeto = fabrica()
            objetos.append(objeto)
            return objeto

        try:
            self.registro.criar(token, alocar)
        except BaseException as original:
            # Não inferir ausência de um construtor opaco que lançou após entrar.
            if not entrou:
                try:
                    self.registro.comprovar_ausencia(token, nao_alocado=True)
                except BaseException as prova:
                    if not _preservar_erro_ausencia:
                        raise
                    original.__cause__ = prova
                    original.__suppress_context__ = True
            elif objetos:
                with self._lock_publicacoes:
                    self._publicacoes_pendentes[token] = (objetos[0], None)
                try:
                    if self.registro.fechar(token):
                        with self._lock_publicacoes:
                            self._publicacoes_pendentes.pop(token, None)
                    else:
                        estado = next(r for r in self.registro.obter_retrato()["recursos"]
                                      if r["recurso_id"] == token.numero)
                        if estado["criacao_resolvida"]:
                            with self._lock_publicacoes:
                                self._publicacoes_pendentes.pop(token, None)
                        elif not estado["criacao_em_curso"]:
                            # Resultado conhecido fora da publicação normal: reter
                            # handle e limpar sem inventar prova no registro.
                            with self._lock_publicacoes:
                                self._publicacoes_pendentes[token] = (objetos[0], None)
                            try:
                                objetos[0].close()
                            except BaseException as erro_limpeza:
                                categoria = "falha_io" if isinstance(erro_limpeza, OSError) else "falha_operacao"
                                with self._lock_publicacoes:
                                    self._publicacoes_pendentes[token] = (objetos[0], categoria)
                except BaseException as erro_limpeza:
                    categoria = "falha_io" if isinstance(erro_limpeza, OSError) else "falha_operacao"
                    with self._lock_publicacoes:
                        self._publicacoes_pendentes[token] = (objetos[0], categoria)
            raise
        return token, objetos[0]

    # Cria um socket acompanhado e devolve a fachada que contabiliza seus usos.
    def abrir_socket(self, fabrica):
        if isinstance(fabrica, SocketClienteRegistrado):
            # Transferência explícita: preservar token e geração de origem,
            # mesmo se outro adaptador do mesmo registro receber a conexão.
            if fabrica.dono.registro is not self.registro:
                raise ValueError("socket_de_outro_registro")
            return fabrica
        token, objeto = self._criar("socket_tcp", fabrica)
        return SocketClienteRegistrado(self, token, objeto)

    # Resolve endereços e tenta conexão com socket acompanhado, limpando tentativas que falham.
    def conectar_tcp(self, endereco, *, timeout=5):
        """Subset usado por CONFIG/REGISTER de socket.create_connection.

        Mesma resolução, ordem, timeout por endereço e último OSError. Cada
        socket tem reserva própria; o sucesso transfere o wrapper sem fechar.
        Não implementa source_address/all_errors, não utilizados pelos leitores.
        """
        host, porta = endereco
        ultimo_erro = None
        for familia, tipo, protocolo, _nome, destino in socket.getaddrinfo(
                host, porta, 0, socket.SOCK_STREAM):
            cliente = None
            try:
                cliente = self.abrir_socket(lambda: socket.socket(familia, tipo, protocolo))
                cliente.settimeout(timeout)
                cliente.connect(destino)
                return cliente
            except BaseException as erro:
                if cliente is not None:
                    try:
                        cliente.close()
                    except BaseException:
                        # Cleanup falho aborta a sequência, como na fábrica
                        # anterior, mas preserva o erro original da tentativa.
                        # O registro guarda ambos os erros separadamente.
                        raise erro from None
                if not isinstance(erro, OSError):
                    raise
                ultimo_erro = erro
        if ultimo_erro is not None:
            raise ultimo_erro
        raise OSError("getaddrinfo returns an empty list")

    # Envia CONFIG e usa o arquivo de leitura acompanhado para entregar a linha ao callback.
    def ler_configuracao(self, fabrica, receber_linha):
        """Escopo CONFIG: arquivo antes do socket; preservar falha original.

        Aceita fábrica de objeto ou socket já registrado (sem nova identidade).
        usar acompanha parse/publicação e separa erros de limpeza.
        """
        cliente = self.abrir_socket(fabrica)

        def comunicar(_socket):
            cliente.sendall(b"CONFIG\n")
            arquivo = cliente.makefile("r", encoding="utf-8")
            return self._usar_config(
                arquivo.recurso_id, lambda _arquivo: receber_linha(arquivo.readline()))

        return self._usar_config(cliente.recurso_id, comunicar)

    # Envia REGISTER com o nome informado e encaminha a resposta de uma linha ao callback validador.
    def registrar_cliente(self, fabrica, nome_computador, receber_linha):
        """REGISTER com identidade própria e escopos de arquivo/socket distintos."""
        cliente = self.abrir_socket(fabrica)

        def comunicar(_socket):
            cliente.sendall(f"REGISTER|{nome_computador}\n".encode("utf-8"))
            arquivo = cliente.makefile("r", encoding="utf-8")
            return self._usar_config(
                arquivo.recurso_id, lambda _arquivo: receber_linha(arquivo.readline()))

        # O helper de nome histórico CONFIG é apenas uso/limpeza genéricos;
        # não contém mensagem, validação ou configuração de protocolo.
        return self._usar_config(cliente.recurso_id, comunicar)

    # Executa o uso pelo registro e trata o fechamento conforme a propriedade do recurso.
    def _usar_config(self, token, operacao):
        try:
            return self.registro.usar(token, operacao, fechar_ao_sair=True)
        except BaseException:
            # Gate pode fechar depois da publicação e antes de usar entrar.
            # Nesse caso usar não executou seu finally de limpeza.
            try:
                estado = next(r for r in self.registro.obter_retrato()["recursos"]
                              if r["recurso_id"] == token.numero)
                if (not estado["prova_fechamento"] and not estado["limpeza_em_curso"]
                        and not estado["erros_limpeza"] and not estado["erros_evidencia"]):
                    self.registro.fechar(token)
            except BaseException:
                pass  # Preservar original; limpeza mantém evidência no registro.
            raise

    # Acompanha a criação e o uso do socket UDP ou TCP empregado pela descoberta.
    def executar_descoberta(self, tipo, fabrica, operacao):
        """Socket temporário UDP ou CHECK TCP; nenhum arquivo associado."""
        if tipo not in ("socket_udp", "socket_tcp"):
            raise ValueError("tipo_descoberta_invalido")
        controle = getattr(self, '_admissao_checks', None)
        if tipo == 'socket_tcp' and controle is not None:
            return controle.executar(self, fabrica, operacao)
        token, objeto = self._criar(tipo, fabrica)
        cliente = SocketDescobertaRegistrado(self, token, objeto)
        if tipo == 'socket_udp' and controle is not None:
            with controle.descoberta(token.numero):
                return self._usar_config(token, lambda _objeto: operacao(cliente))
        return self._usar_config(token, lambda _objeto: operacao(cliente))


# Fachada: conserva a API necessária ao leitor e contabiliza cada uso no registro do dono.
class SocketClienteRegistrado:
    # Associa o socket real à identidade reservada e ao adaptador proprietário.
    def __init__(self, dono, token, objeto):
        self.dono, self.recurso_id, self._objeto = dono, token, objeto

    # Executa uma operação do socket dentro do acompanhamento de uso do registro.
    def _usar(self, nome, *args):
        return self.dono.registro.usar(
            self.recurso_id, lambda objeto: getattr(objeto, nome)(*args), fechar_ao_sair=False)

    # Encaminha o timeout ao socket através do acompanhamento de uso.
    def settimeout(self, valor):
        return self._usar("settimeout", valor)

    # Encaminha a conexão ao socket através do acompanhamento de uso.
    def connect(self, destino):
        return self._usar("connect", destino)

    # Envia todos os bytes pela operação de uso acompanhada.
    def sendall(self, dados):
        return self._usar("sendall", dados)

    # Recebe bytes do socket pela operação de uso acompanhada.
    def recv(self, tamanho):
        return self._usar("recv", tamanho)

    # Encaminha a interrupção ao socket real para permitir desbloquear operações de recepção.
    def shutdown(self, modo):
        # Interrupção continua disponível mesmo depois de fechar admissão.
        # Não é prova de close, nem resolve arquivo associado.
        return self._objeto.shutdown(modo)

    # Solicita ao registro o fechamento da identidade em vez de perder a evidência de limpeza do objeto.
    def close(self):
        return self.dono.registro.fechar(self.recurso_id)

    # Cria e acompanha separadamente o arquivo de leitura associado ao socket.
    def makefile(self, modo, *, encoding):
        token, objeto = self.dono._criar(
            "arquivo_socket", lambda: self._objeto.makefile(modo, encoding=encoding),
            associado_a=self.recurso_id)
        return ArquivoClienteRegistrado(self.dono, token, objeto)


# Fachada do arquivo gerado por makefile, com uso e fechamento acompanhados pelo mesmo dono.
class ArquivoClienteRegistrado:
    # Conserva dono, identidade e arquivo real para acompanhar leitura e limpeza.
    def __init__(self, dono, token, objeto):
        self.dono, self.recurso_id, self._objeto = dono, token, objeto

    # Executa a leitura de linha pelo registro de uso do arquivo acompanhado.
    def readline(self):
        return self.dono.registro.usar(
            self.recurso_id, lambda objeto: objeto.readline(), fechar_ao_sair=False)

    # Solicita ao registro o fechamento da identidade em vez de perder a evidência de limpeza do objeto.
    def close(self):
        return self.dono.registro.fechar(self.recurso_id)


# Acrescenta à fachada as operações de datagrama necessárias ao broadcast UDP.
class SocketDescobertaRegistrado(SocketClienteRegistrado):
    # Configura opções do socket pela operação acompanhada, incluindo a permissão de broadcast.
    def setsockopt(self, nivel, opcao, valor):
        return self._usar("setsockopt", nivel, opcao, valor)

    # Envia o datagrama ao destino informado mantendo o acompanhamento de uso.
    def sendto(self, dados, destino):
        return self._usar("sendto", dados, destino)

    # Recebe datagrama e endereço de origem pelo uso acompanhado do socket.
    def recvfrom(self, tamanho):
        return self._usar("recvfrom", tamanho)

    # Recebe bytes do socket pela operação de uso acompanhada.
    def recv(self, tamanho):
        return self._usar("recv", tamanho)

# Preparações: acompanha o trabalho anterior à descoberta e seus recursos associados.
"""Atividade sincrona de descoberta sem leitor; sem autoridade de parada global."""
from dataclasses import dataclass
from contextlib import contextmanager
from threading import Lock, get_ident
from uuid import uuid4


@dataclass(frozen=True, eq=False)
class PreparacaoClienteId:
    numero: int


class RegistroPreparacoesCliente:
    def __init__(self, proprietario):
        self._proprietario = proprietario
        self._lock = Lock()
        self._sequencia = 0
        self._preparacoes = {}
        self._fonte_id = uuid4().hex
        self._revisao = 0
        self._revisao_confiavel = True

    @property
    def fonte_id(self):
        return self._fonte_id

    def _avancar_revisao(self):
        self._revisao += 1

    @contextmanager
    def _mudanca_local(self):
        """Chamador ja possui _lock; nenhuma chamada de IO nesta secao."""
        confiavel, anterior = self._revisao_confiavel, self._revisao
        self._revisao_confiavel = False
        yield
        self._avancar_revisao()
        if self._revisao != anterior + 1:
            raise RuntimeError('revisao_preparacao_nao_publicada')
        self._revisao_confiavel = confiavel

    def _atualizar(self, item, **campos):
        alteracoes = {n: v for n, v in campos.items() if item[n] != v}
        if alteracoes:
            with self._mudanca_local():
                item.update(alteracoes)

    def _selo(self):
        return {'aplicacao_id': self._proprietario.aplicacao_id,
                'fonte_id': self._fonte_id, 'revisao': self._revisao,
                'confiavel': self._revisao_confiavel, 'escopo': 'estado_local_preparacoes'}

    def obter_revisao(self):
        with self._lock:
            return self._selo()

    def obter_evidencia_temporal(self):
        """Selo e estado local juntos; recursos externos nao estao versionados."""
        with self._lock:
            preparacoes = []
            for token, item in self._preparacoes.items():
                origem = item['origem_recursos']
                preparacoes.append({
                    'preparacao_id': token.numero, 'origem': 'buscar_servidor.sem_leitor',
                    **{n: item[n] for n in ('iniciada', 'em_curso', 'retorno',
                        'publicacao_em_curso', 'erro_publicacao', 'erro_associacao', 'resultado')},
                    'erro_operacional': None if item['erro_operacional'] is None else item['erro_operacional'].copy(),
                    'origem_recursos': None if origem is None else {
                        'geracao_id': origem[0], 'atividade_id': origem[1]},
                })
            return self._selo() | {'preparacoes': preparacoes,
                'dependencias_temporais_cobertas': False, 'snapshot_atomico': False,
                'cobertura_operacional': 'incompleta',
                'encerramento_cliente_confirmado': False, 'encerramento_global_confirmado': False}

    def admitir(self):
        """Publica antes de qualquer trabalho. Nao inventa gate de encerramento."""
        with self._lock:
            numero = self._sequencia + 1
            identidade = PreparacaoClienteId(numero)
            item = {
                'iniciada': False, 'em_curso': False, 'retorno': False,
                'publicacao_em_curso': False, 'erro_publicacao': False,
                'erro_associacao': False, 'resultado': None, 'erro_operacional': None,
                'thread': None, 'dono_recursos': None, 'origem_recursos': None,
            }
            with self._mudanca_local():
                self._sequencia = numero
                self._preparacoes[identidade] = item
            return identidade

    def _buscar(self, identidade):
        if type(identidade) is not PreparacaoClienteId or identidade not in self._preparacoes:
            raise ValueError('preparacao_estrangeira')
        return self._preparacoes[identidade]

    @staticmethod
    def _erro(erro):
        return None if erro is None else {'categoria': (
            'falha_io' if isinstance(erro, OSError) else
            'falha_operacao' if isinstance(erro, Exception) else 'falha_base')}

    @staticmethod
    def _separar_falha(original, adicional):
        if original is not adicional:
            original.__cause__ = adicional
            original.__suppress_context__ = True

    def vincular_recursos(self, identidade, dono):
        """Correlacao com dono existente, sem criar geracao ou mudar propriedade."""
        from rede.infraestrutura_cliente import RecursosLeitorCliente
        with self._lock:
            item = self._buscar(identidade)
            try:
                if (type(dono) is not RecursosLeitorCliente
                        or dono.registro is not self._proprietario.registro_recursos
                        or not item['em_curso'] or item['thread'] != get_ident()
                        or item['dono_recursos'] is not None):
                    raise ValueError('vinculo_preparacao_invalido')
                self._atualizar(item, dono_recursos=dono,
                                origem_recursos=(dono.geracao_id, dono.atividade_id))
            except BaseException as original:
                try:
                    self._atualizar(item, erro_associacao=True)
                except BaseException as acompanhamento:
                    self._separar_falha(original, acompanhamento)
                raise

    def _publicar_resultado(self, identidade, erro):
        with self._lock:
            item = self._buscar(identidade)
            self._atualizar(item, resultado='retorno' if erro is None else 'falha',
                            erro_operacional=self._erro(erro), retorno=True)

    def executar(self, identidade, chamada):
        if not callable(chamada):
            raise TypeError('preparacao_nao_executavel')
        with self._lock:
            item = self._buscar(identidade)
            if item['iniciada']:
                raise RuntimeError('preparacao_ja_iniciada')
            self._atualizar(item, iniciada=True, em_curso=True, thread=get_ident())
        original = None
        try:
            try:
                return chamada()
            except BaseException as erro:
                original = erro
                raise
        finally:
            falha = None
            try:
                with self._lock:
                    self._atualizar(item, publicacao_em_curso=True,
                                    erro_operacional=self._erro(original))
                self._publicar_resultado(identidade, original)
            except BaseException as publicacao:
                falha = publicacao
            finally:
                with self._lock:
                    if falha is not None:
                        self._revisao_confiavel = False
                    campos = dict(publicacao_em_curso=False, em_curso=False, thread=None)
                    if falha is not None:
                        campos.update(erro_publicacao=True, retorno=False, resultado=None)
                    try:
                        self._atualizar(item, **campos)
                    except BaseException as acompanhamento:
                        if falha is not None:
                            self._separar_falha(falha, acompanhamento)
                        else:
                            falha = acompanhamento
                        self._revisao_confiavel = False
                        try:
                            self._atualizar(item, erro_publicacao=True, retorno=False, resultado=None)
                        except BaseException as secundaria:
                            self._separar_falha(acompanhamento, secundaria)
            if falha is not None:
                if original is None:
                    raise falha
                self._separar_falha(original, falha)

    def obter_retrato(self):
        """Passivo; cruza recursos conhecidos, nao certifica corte temporal/global."""
        with self._lock:
            itens = [(token, item.copy()) for token, item in self._preparacoes.items()]
        recursos = self._proprietario.registro_recursos.obter_retrato()['recursos']
        preparacoes = []
        for token, item in itens:
            dono = item['dono_recursos']
            origem = None if dono is None else {
                'geracao_id': dono.geracao_id, 'atividade_id': dono.atividade_id}
            proprios = [] if dono is None else [r for r in recursos if
                (r['geracao_id'], r['retentativa_id']) == (dono.geracao_id, dono.atividade_id)]
            pendentes = [r['recurso_id'] for r in proprios if not r['encerramento_confirmado']]
            publicacoes = [] if dono is None else dono.obter_publicacoes_pendentes()
            execucao = (item['iniciada'] and item['retorno'] and not item['em_curso']
                and not item['publicacao_em_curso'] and not item['erro_publicacao'])
            preparacoes.append({
                'preparacao_id': token.numero, 'origem': 'buscar_servidor.sem_leitor',
                **{n: item[n] for n in ('iniciada', 'em_curso', 'retorno',
                    'publicacao_em_curso', 'erro_publicacao', 'erro_associacao', 'resultado')},
                'erro_operacional': None if item['erro_operacional'] is None else item['erro_operacional'].copy(),
                'execucao_resolvida': bool(execucao), 'origem_recursos': origem,
                'recursos': [r['recurso_id'] for r in proprios],
                'recursos_pendentes': pendentes,
                'publicacoes_recursos_pendentes': [r['recurso_id'] for r in publicacoes],
                'recursos_conhecidos_resolvidos': bool(dono is not None and not pendentes
                    and not publicacoes and not item['erro_associacao']),
            })
        return {
            'aplicacao_id': self._proprietario.aplicacao_id,
            'autoridade_encerramento': 'nao_estabelecida',
            'preparacoes': preparacoes, 'cobertura_operacional': 'incompleta',
            'snapshot_atomico': False, 'encerramento_cliente_confirmado': False,
            'encerramento_global_confirmado': False,
        }

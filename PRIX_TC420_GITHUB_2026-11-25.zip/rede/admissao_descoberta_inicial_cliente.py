# Descoberta inicial: acompanha a admissão UDP e as confirmações CHECK relacionadas.
"""Autoridade da descoberta inicial por geração; admissão e parada atômicas.

Autorização aceita não é cancelamento de IO. Reservas/handles pertencem ao
registro existente, sem lock de admissão sobre fábricas, IO ou fechamento.
"""
from contextlib import contextmanager
from dataclasses import dataclass
from threading import Lock, get_ident

from rede.infraestrutura_cliente import RecursosLeitorCliente


@dataclass(frozen=True, eq=False)
class OperacaoDescobertaInicialId:
    numero: int


class AdmissaoDescobertaInicialCliente:
    def __init__(self, recursos, aplicacao_id=None):
        self._aplicacao_id = aplicacao_id
        self._geracao_id = None if recursos is None else recursos.geracao_id
        self._atividade_id = None if recursos is None else recursos.atividade_id
        self._registro = None if recursos is None else recursos.registro
        self._geracao = None if recursos is None else recursos._geracao_retentativas
        self._lock = Lock()
        self._lock_publicacoes = Lock()
        self._publicacoes_pendentes = {}
        self._fechada = False
        self._sequencia = 0
        self._operacoes = {}
        from rede.admissao_checks_cliente import AdmissaoChecksCliente
        self._admissao_checks = AdmissaoChecksCliente(leitor=self)

    def admitir(self):
        with self._lock:
            if self._fechada:
                return None
            self._sequencia += 1
            identidade = OperacaoDescobertaInicialId(self._sequencia)
            self._operacoes[identidade] = {
                'iniciada': False, 'execucao_aberta': False, 'thread': None,
                'retorno': False, 'erro_operacao': None, 'erro_publicacao': False,
                'erro_associacao': False, 'dono': None,
            }
            return identidade

    def fechar_admissao(self):
        with self._lock:
            anterior = self._fechada
            self._fechada = True
            return not anterior

    def _buscar(self, identidade):
        if type(identidade) is not OperacaoDescobertaInicialId or identidade not in self._operacoes:
            raise ValueError('operacao_descoberta_inicial_estrangeira')
        return self._operacoes[identidade]

    @staticmethod
    def _erro(erro):
        return None if erro is None else {'categoria': (
            'falha_io' if isinstance(erro, OSError) else
            'falha_operacao' if isinstance(erro, Exception) else 'falha_base')}

    def _validar_execucao(self, identidade):
        with self._lock:
            item = self._buscar(identidade)
            if not item['execucao_aberta'] or item['thread'] != get_ident():
                raise RuntimeError('descoberta_inicial_fora_da_execucao_admitida')

    def _publicar_saida(self, identidade, erro):
        with self._lock:
            item = self._buscar(identidade)
            item['erro_operacao'] = self._erro(erro)
            item['retorno'] = True

    def _saida_preservando(self, identidade, original):
        # Conservar o diagnóstico funcional mesmo se o publicador falhar antes
        # de escrever. Texto/objeto da exceção nunca entra no retrato.
        with self._lock:
            self._buscar(identidade)['erro_operacao'] = self._erro(original)
        try:
            self._publicar_saida(identidade, original)
        except BaseException as publicacao:
            with self._lock:
                item = self._buscar(identidade)
                item['erro_publicacao'] = True
                item['retorno'] = False
            if original is None:
                raise
            original.__cause__ = publicacao
            original.__suppress_context__ = True

    @contextmanager
    def executar(self, identidade):
        with self._lock:
            item = self._buscar(identidade)
            if item['iniciada']:
                raise RuntimeError('descoberta_inicial_ja_iniciada')
            item['iniciada'] = True
            item['execucao_aberta'] = True
            item['thread'] = get_ident()
        try:
            dono = None if self._registro is None else RecursosDescobertaInicialCliente(self, identidade)
            with self._lock:
                item['dono'] = dono
            yield dono
        except BaseException as original:
            self._saida_preservando(identidade, original)
            raise
        else:
            self._saida_preservando(identidade, None)
        finally:
            with self._lock:
                item['execucao_aberta'] = False

    def obter_retrato(self):
        with self._lock:
            itens = [(chave, item.copy()) for chave, item in self._operacoes.items()]
            fechada = self._fechada
        estados = {} if self._registro is None else {
            r['recurso_id']: r for r in self._registro.obter_retrato()['recursos']}
        checks = self._admissao_checks.obter_retrato()
        operacoes = []
        for chave, item in itens:
            dono = item['dono']
            vinculos = [] if dono is None else dono.obter_vinculos()
            recursos = [{'recurso_id': numero, 'tipo': tipo, 'associacao_publicada': publicado,
                         'limpeza_confirmada': estados.get(numero, {}).get('encerramento_confirmado', False)}
                        for numero, tipo, publicado in vinculos]
            resolvida = (self._registro is not None and item['retorno']
                         and not item['execucao_aberta'] and not item['erro_publicacao']
                         and not item['erro_associacao']
                         and all(c['responsabilidade_resolvida'] for c in checks
                                 if c['descoberta_inicial_id'] == chave.numero)
                         and all(r['associacao_publicada'] and r['limpeza_confirmada'] for r in recursos))
            operacoes.append({
                'operacao_id': chave.numero, 'tipo': 'descoberta_inicial',
                'geracao_id': self._geracao_id, 'atividade_recursos_id': self._atividade_id,
                'iniciada': item['iniciada'], 'retorno': item['retorno'],
                'execucao_em_curso': item['execucao_aberta'],
                'erro_operacao': None if item['erro_operacao'] is None else item['erro_operacao'].copy(),
                'erro_publicacao': item['erro_publicacao'], 'erro_associacao': item['erro_associacao'],
                'recursos': recursos, 'responsabilidade_resolvida': bool(resolvida),
            })
        return {'aplicacao_id': self._aplicacao_id, 'geracao_id': self._geracao_id,
                'admissao_fechada': fechada, 'operacoes': operacoes,
                'checks': checks,
                'cobertura_operacional': 'incompleta', 'encerramento_global_confirmado': False}


class RecursosDescobertaInicialCliente(RecursosLeitorCliente):
    """UDP e CHECK no registro existente, com vínculo antes da fábrica."""
    def __init__(self, controle, identidade):
        self._controle = controle
        self._identidade = identidade
        self._descoberta_inicial_id = identidade.numero
        self._admissao_checks = controle._admissao_checks
        self.registro = controle._registro
        self.geracao_id = controle._geracao_id
        self.atividade_id = controle._atividade_id
        self._geracao_retentativas = controle._geracao
        # Retém somente as reservas desta busca, sem copiar registros ou retries.
        self._lock_publicacoes = controle._lock_publicacoes
        self._publicacoes_pendentes = controle._publicacoes_pendentes
        self._lock_vinculos = Lock()
        self._emitidos = {}
        self._publicados = set()

    def _publicar_vinculo(self, token):
        with self._lock_vinculos:
            if token not in self._emitidos:
                raise ValueError('reserva_descoberta_inicial_estrangeira')
            self._publicados.add(token)

    def _reservar_recurso(self, tipo, associado_a):
        self._controle._validar_execucao(self._identidade)
        token = super()._reservar_recurso(tipo, associado_a)
        if token is None:
            return None
        try:
            with self._lock_vinculos:
                self._emitidos[token] = tipo
            self._publicar_vinculo(token)
        except BaseException as original:
            with self._controle._lock:
                self._controle._buscar(self._identidade)['erro_associacao'] = True
            try:
                self.registro.comprovar_ausencia(token, nao_alocado=True)
            except BaseException as prova:
                original.__cause__ = prova
                original.__suppress_context__ = True
            raise
        return token

    def obter_vinculos(self):
        with self._lock_vinculos:
            return [(token.numero, tipo, token in self._publicados)
                    for token, tipo in self._emitidos.items()]

# REGISTER: acompanha as operações que obtêm a posição de sucessão do cliente.
"""Autoridade REGISTER por geração; admitir e parar usam o mesmo lock.

Autorização aceita não é cancelamento de IO. Reservas/handles pertencem ao
registro existente, sem lock de admissão sobre fábricas, IO ou fechamento.
"""
from contextlib import contextmanager
from dataclasses import dataclass
from threading import Lock, get_ident, local
from sys import exc_info
from uuid import uuid4

from rede.infraestrutura_cliente import RecursosLeitorCliente, SocketClienteRegistrado


class _SincronizacaoRegister:
    """Adaptador reutilizavel dos pequenos blocos locais herdados, sem IO."""
    def __init__(self, controle):
        self._controle = controle
        self._contextos = local()

    def __enter__(self):
        contexto = self._controle._publicacao_local(original=exc_info()[1])
        self._contextos.atual = contexto
        return contexto.__enter__()

    def __exit__(self, *erro):
        contexto = self._contextos.atual
        del self._contextos.atual
        return contexto.__exit__(*erro)


@dataclass(frozen=True, eq=False)
class OperacaoRegisterId:
    numero: int


class AdmissaoRegisterCliente:
    def __init__(self, recursos, aplicacao_id=None):
        self._aplicacao_id = aplicacao_id
        self._geracao_id = None if recursos is None else recursos.geracao_id
        self._atividade_id = None if recursos is None else recursos.atividade_id
        self._registro = None if recursos is None else recursos.registro
        self._geracao = None if recursos is None else recursos._geracao_retentativas
        self._lock = Lock()
        self._lock_publicacoes = _SincronizacaoRegister(self)
        self._publicacoes_pendentes = {}
        self._fechada = False
        self._sequencia = 0
        self._operacoes = {}
        self._fonte_id = uuid4().hex
        self._revisao = 0
        self._temporal_comprometida = False
        self._revisao_confiavel = True

    @property
    def fonte_id(self):
        return self._fonte_id

    def _estado_local(self):
        operacoes = []
        for token, item in self._operacoes.items():
            dono = item['dono']
            campos = tuple((nome, id(valor) if nome == 'dono' else
                            tuple(valor.items()) if type(valor) is dict else valor)
                           for nome, valor in item.items())
            vinculos = () if dono is None else (tuple(dono._emitidos.items()),
                                                frozenset(dono._publicados))
            operacoes.append((token, campos, vinculos))
        retidos = tuple((token, id(objeto), erro)
                        for token, (objeto, erro) in self._publicacoes_pendentes.items())
        return (self._fechada, self._sequencia, tuple(operacoes), retidos,
                self._temporal_comprometida)

    def _avancar_revisao(self):
        self._revisao += 1

    @staticmethod
    def _separar_falha(original, adicional):
        if original is not adicional:
            anteriores = getattr(original, '_falhas_acompanhamento_register', ())
            if not any(erro is adicional for erro in anteriores):
                original._falhas_acompanhamento_register = anteriores + (adicional,)
            original.__cause__ = adicional
            original.__suppress_context__ = True

    @contextmanager
    def _publicacao_local(self, original=None):
        # Somente estado local, sob o lock anterior; nunca chamar a thread/controle.
        with self._lock:
            antes, anterior = self._estado_local(), self._revisao
            self._revisao_confiavel = False
            falha = None
            try:
                yield
            except BaseException as erro:
                falha = erro
                if original is None:
                    raise
                # Diagnostico adicional em um handler nao substitui o primario.
                self._temporal_comprometida = True
                self._separar_falha(original, erro)
            finally:
                try:
                    if antes != self._estado_local():
                        if falha is not None:
                            self._temporal_comprometida = True
                        self._avancar_revisao()
                        if self._revisao != anterior + 1:
                            raise RuntimeError('revisao_register_nao_publicada')
                    self._revisao_confiavel = not self._temporal_comprometida
                except BaseException as acompanhamento:
                    self._temporal_comprometida = True
                    self._revisao_confiavel = False
                    primario = falha if falha is not None else original
                    if primario is None:
                        raise
                    self._separar_falha(primario, acompanhamento)

    def _selo(self):
        return {'aplicacao_id': self._aplicacao_id, 'geracao_id': self._geracao_id,
                'fonte_id': self._fonte_id, 'revisao': self._revisao,
                'confiavel': self._revisao_confiavel, 'escopo': 'estado_local_register'}

    def obter_revisao(self):
        with self._lock:
            return self._selo()

    def obter_evidencia_temporal(self):
        # Nunca chamar o registro de recursos: somente estado deste controle.
        with self._lock:
            operacoes = []
            for token, item in self._operacoes.items():
                dono = item['dono']
                operacoes.append({
                    'operacao_id': token.numero,
                    'iniciada': item['iniciada'], 'retorno': item['retorno'],
                    'execucao_em_curso': item['execucao_aberta'],
                    'erro_operacao': None if item['erro_operacao'] is None else item['erro_operacao'].copy(),
                    'erro_publicacao': item['erro_publicacao'],
                    'erro_associacao': item['erro_associacao'],
                    'dono_publicado': dono is not None,
                    'vinculos': [] if dono is None else [
                        {'recurso_id': t.numero, 'tipo': tipo,
                         'associacao_publicada': t in dono._publicados}
                        for t, tipo in dono._emitidos.items()]})
            return self._selo() | {
                'retrato': {'admissao_fechada': self._fechada, 'operacoes': operacoes,
                    'publicacoes_pendentes': [
                        {'recurso_id': t.numero, 'erro_limpeza': erro}
                        for t, (_objeto, erro) in self._publicacoes_pendentes.items()]},
                'dependencias_temporais_cobertas': False, 'snapshot_atomico': False,
                'cobertura_operacional': 'incompleta',
                'encerramento_cliente_confirmado': False, 'encerramento_global_confirmado': False}

    def admitir(self):
        with self._publicacao_local():
            if self._fechada:
                return None
            self._sequencia += 1
            identidade = OperacaoRegisterId(self._sequencia)
            self._operacoes[identidade] = {
                'iniciada': False, 'execucao_aberta': False, 'thread': None,
                'retorno': False, 'erro_operacao': None, 'erro_publicacao': False,
                'erro_associacao': False, 'dono': None,
            }
            return identidade

    def fechar_admissao(self):
        with self._publicacao_local():
            anterior = self._fechada
            self._fechada = True
            return not anterior

    def _buscar(self, identidade):
        if type(identidade) is not OperacaoRegisterId or identidade not in self._operacoes:
            raise ValueError('operacao_register_estrangeira')
        return self._operacoes[identidade]

    @staticmethod
    def _erro(erro):
        return None if erro is None else {'categoria': (
            'falha_io' if isinstance(erro, OSError) else
            'falha_operacao' if isinstance(erro, Exception) else 'falha_base')}

    def _validar_execucao(self, identidade):
        with self._lock:
            item = self._buscar(identidade)
            if not item['execucao_aberta'] or item['thread'] != get_ident():
                raise RuntimeError('register_fora_da_execucao_admitida')

    def _publicar_saida(self, identidade, erro):
        with self._publicacao_local():
            item = self._buscar(identidade)
            item['erro_operacao'] = self._erro(erro)
            item['retorno'] = True

    def _saida_preservando(self, identidade, original):
        # Conservar o diagnóstico funcional mesmo se o publicador falhar antes
        # de escrever. Texto/objeto da exceção nunca entra no retrato.
        with self._publicacao_local(original=original):
            self._buscar(identidade)['erro_operacao'] = self._erro(original)
        try:
            self._publicar_saida(identidade, original)
        except BaseException as publicacao:
            with self._lock:
                self._temporal_comprometida = True
                self._revisao_confiavel = False
            with self._publicacao_local(original=original if original is not None else publicacao):
                self._temporal_comprometida = True
                item = self._buscar(identidade)
                item['erro_publicacao'] = True
                item['retorno'] = False
            if original is None:
                raise
            self._separar_falha(original, publicacao)

    @contextmanager
    def executar(self, identidade):
        with self._publicacao_local():
            item = self._buscar(identidade)
            if item['iniciada']:
                raise RuntimeError('register_ja_iniciado')
            item['iniciada'] = True
            item['execucao_aberta'] = True
            item['thread'] = get_ident()
        primario = None
        try:
            dono = None if self._registro is None else RecursosRegisterCliente(self, identidade)
            with self._publicacao_local():
                item['dono'] = dono
            yield dono
        except BaseException as original:
            primario = original
            self._saida_preservando(identidade, original)
            raise
        else:
            try:
                self._saida_preservando(identidade, None)
            except BaseException as erro:
                primario = erro
                raise
        finally:
            with self._publicacao_local(original=primario):
                item['execucao_aberta'] = False

    def obter_retrato(self):
        with self._lock:
            itens = [(chave, item.copy()) for chave, item in self._operacoes.items()]
            fechada = self._fechada
        estados = {} if self._registro is None else {
            r['recurso_id']: r for r in self._registro.obter_retrato()['recursos']}
        operacoes = []
        for chave, item in itens:
            dono = item['dono']
            vinculos = [] if dono is None else dono.obter_vinculos()
            recursos = [{'recurso_id': numero, 'tipo': tipo, 'associacao_publicada': publicado,
                         'limpeza_confirmada': estados.get(numero, {}).get('encerramento_confirmado', False)}
                        for numero, tipo, publicado in vinculos]
            resolvida = (self._registro is not None and item['retorno']
                         and not item['execucao_aberta'] and not item['erro_publicacao']
                         and not item['erro_associacao']
                         and all(r['associacao_publicada'] and r['limpeza_confirmada'] for r in recursos))
            operacoes.append({
                'operacao_id': chave.numero, 'tipo': 'register',
                'geracao_id': self._geracao_id, 'atividade_recursos_id': self._atividade_id,
                'iniciada': item['iniciada'], 'retorno': item['retorno'],
                'execucao_em_curso': item['execucao_aberta'],
                'erro_operacao': None if item['erro_operacao'] is None else item['erro_operacao'].copy(),
                'erro_publicacao': item['erro_publicacao'], 'erro_associacao': item['erro_associacao'],
                'recursos': recursos, 'responsabilidade_resolvida': bool(resolvida),
            })
        return {'aplicacao_id': self._aplicacao_id, 'geracao_id': self._geracao_id,
                'admissao_fechada': fechada, 'operacoes': operacoes,
                'cobertura_operacional': 'incompleta', 'encerramento_global_confirmado': False}


class RecursosRegisterCliente(RecursosLeitorCliente):
    """Mesmo contrato de IO; apenas publica o vínculo antes da fábrica."""
    def __init__(self, controle, identidade):
        self._controle = controle
        self._identidade = identidade
        self.registro = controle._registro
        self.geracao_id = controle._geracao_id
        self.atividade_id = controle._atividade_id
        self._geracao_retentativas = controle._geracao
        # Retenção exclusiva de REGISTER pelo dono da geração. Não reter o
        # adaptador original nem suas pendências de CONFIG/SUBSCRIBE/descoberta.
        self._lock_publicacoes = controle._lock_publicacoes
        self._publicacoes_pendentes = controle._publicacoes_pendentes
        self._lock_vinculos = _SincronizacaoRegister(controle)
        self._emitidos = {}
        self._publicados = set()

    def abrir_socket(self, fabrica):
        self._controle._validar_execucao(self._identidade)
        if isinstance(fabrica, SocketClienteRegistrado):
            with self._lock_vinculos:
                if fabrica.dono is not self or fabrica.recurso_id not in self._emitidos:
                    raise ValueError('socket_de_outra_operacao_register')
        return super().abrir_socket(fabrica)

    def _publicar_vinculo(self, token):
        with self._lock_vinculos:
            if token not in self._emitidos:
                raise ValueError('reserva_register_estrangeira')
            self._publicados.add(token)

    def _reservar_recurso(self, tipo, associado_a):
        self._controle._validar_execucao(self._identidade)
        token = super()._reservar_recurso(tipo, associado_a)
        if token is None:
            return None
        try:
            with self._lock_vinculos:
                self._emitidos[token] = tipo
            self._publicar_vinculo(token)
        except BaseException as original:
            with self._controle._publicacao_local(original=original):
                self._controle._temporal_comprometida = True
                self._controle._buscar(self._identidade)['erro_associacao'] = True
            try:
                self.registro.comprovar_ausencia(token, nao_alocado=True)
            except BaseException as prova:
                original.__cause__ = prova
                original.__suppress_context__ = True
            raise
        return token

    def obter_vinculos(self):
        with self._controle._lock:
            return [(token.numero, tipo, token in self._publicados)
                    for token, tipo in self._emitidos.items()]

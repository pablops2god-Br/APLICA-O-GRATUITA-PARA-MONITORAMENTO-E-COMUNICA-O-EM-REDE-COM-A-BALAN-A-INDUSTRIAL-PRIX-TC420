# Descoberta: broadcast UDP local seguido de confirmação do protocolo por TCP.
"""
Módulo de Descoberta Automática de Servidores na Rede Local (LAN)
================================================================

Este módulo implementa o mecanismo 'Zero-Config' para localização automática
do computador PRINCIPAL pelos computadores CLIENTES sem intervenção manual de IP.

Funcionamento em Duas Etapas:
1. ETAPA UDP (Broadcast 42101):
   - O cliente envia o datagrama 'TC420_SERVER_DISCOVERY' para o endereço de difusão '255.255.255.255';
   - O servidor Principal (se estiver saudável) responde com 'TC420_SERVER_HERE'.
2. ETAPA TCP (Validação 42100):
   - O cliente não confia cegamente no UDP (que pode sofrer com respostas forjadas ou residuais);
   - Ele abre um socket TCP na porta 42100 do IP que respondeu e envia o comando 'CHECK';
   - Se o servidor responder 'TC420_SERVER_OK', a descoberta é confirmada com sucesso.
"""

import socket


class CheckRecusado(Exception):
    """Sinal interno de recusa; a API pública de confirmação retorna False."""


PORTA_TCP = 42100
PORTA_DESCOBERTA = 42101
TIMEOUT_DESCOBERTA = 2
TIMEOUT_TCP = 2

MENSAGEM_DESCOBERTA = "TC420_SERVER_DISCOVERY"
RESPOSTA_DESCOBERTA = "TC420_SERVER_HERE"
RESPOSTA_TCP = "TC420_SERVER_OK"


# CHECK confirma a resposta esperada do protocolo; não fornece autenticação criptográfica do servidor.
def confirmar_servidor(ip, recursos_cliente=None, *, admissao_checks=None, _propagar_recusa=False):
    """
    Confirma via handshake TCP (porta 42100) se o servidor encontrado está saudável e ativo.
    
    Envia o comando 'CHECK' e aguarda a resposta 'TC420_SERVER_OK'.
    Retorna True se confirmado com sucesso, ou False em caso de recusa/timeout.
    """
    try:
        if admissao_checks is not None:
            return admissao_checks.executar(None, legado=lambda: confirmar_servidor(ip))
        if recursos_cliente is not None:
            return recursos_cliente.executar_descoberta(
                "socket_tcp", lambda: socket.socket(socket.AF_INET, socket.SOCK_STREAM),
                lambda cliente: _confirmar_observado(cliente, ip))
    except CheckRecusado:
        if _propagar_recusa:
            raise
        return False
    cliente = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM,
    )
    cliente.settimeout(TIMEOUT_TCP)

    try:
        cliente.connect((ip, PORTA_TCP))
        cliente.sendall(b"CHECK\n")
        resposta = cliente.recv(1024).decode(
            "utf-8",
            errors="ignore",
        ).strip()
        return resposta == RESPOSTA_TCP

    except (ConnectionRefusedError, socket.timeout, OSError):
        return False

    finally:
        cliente.close()


# Usa broadcast para localizar candidatos e só devolve o IP depois de confirmar CHECK por TCP.
def buscar_servidor(recursos_cliente=None, infraestrutura_cliente=None, *, admissao_checks=None, estrito=False):
    """
    Procura automaticamente um servidor TC420
    na rede local usando UDP broadcast.
    Retorna o IP do servidor se encontrado.
    Retorna None caso contrário.
    """
    if recursos_cliente is None and infraestrutura_cliente is not None:
        return infraestrutura_cliente.executar_descoberta_preparacao(
            lambda recursos: buscar_servidor(recursos_cliente=recursos, admissao_checks=admissao_checks,
                                             estrito=estrito))
    if recursos_cliente is not None:
        return recursos_cliente.executar_descoberta(
            "socket_udp", lambda: socket.socket(socket.AF_INET, socket.SOCK_DGRAM),
            lambda udp: _buscar_observado(udp, recursos_cliente, estrito=estrito))

    udp = socket.socket(
        socket.AF_INET,
        socket.SOCK_DGRAM,
    )

    # Permite envio para broadcast
    udp.setsockopt(
        socket.SOL_SOCKET,
        socket.SO_BROADCAST,
        1,
    )
    udp.settimeout(TIMEOUT_DESCOBERTA)

    try:
        udp.sendto(
            MENSAGEM_DESCOBERTA.encode("utf-8"),
            ("255.255.255.255", PORTA_DESCOBERTA),
        )

        while True:
            dados, endereco = udp.recvfrom(1024)
            resposta = dados.decode(
                "utf-8",
                errors="ignore",
            )

            if resposta != RESPOSTA_DESCOBERTA:
                continue

            ip_servidor = endereco[0]

            # Não confiamos apenas no UDP.
            # Confirmamos também pelo servidor TCP.
            if confirmar_servidor(ip_servidor, admissao_checks=admissao_checks, _propagar_recusa=True):
                return ip_servidor
            if estrito:
                raise RuntimeError('descoberta_inconclusiva')

    except CheckRecusado:
        if estrito:
            raise
        return None
    except socket.timeout:
        return None

    except OSError as erro:
        if estrito:
            raise
        print(f"Erro ao procurar servidor: {erro}")
        return None

    finally:
        udp.close()


# Executa a confirmação com um socket cujo uso e fechamento são acompanhados pelo adaptador chamador.
def _confirmar_observado(cliente, ip):
    cliente.settimeout(TIMEOUT_TCP)
    try:
        cliente.connect((ip, PORTA_TCP))
        cliente.sendall(b"CHECK\n")
        resposta = cliente.recv(1024).decode("utf-8", errors="ignore").strip()
        return resposta == RESPOSTA_TCP
    except (ConnectionRefusedError, socket.timeout, OSError):
        return False


# Executa a descoberta UDP com recursos acompanhados e confirma cada resposta reconhecida por TCP.
def _buscar_observado(udp, recursos_cliente, *, estrito=False):
    udp.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    udp.settimeout(TIMEOUT_DESCOBERTA)
    enviado = False
    try:
        udp.sendto(MENSAGEM_DESCOBERTA.encode("utf-8"), ("255.255.255.255", PORTA_DESCOBERTA))
        enviado = True
        while True:
            dados, endereco = udp.recvfrom(1024)
            resposta = dados.decode("utf-8", errors="ignore")
            if resposta != RESPOSTA_DESCOBERTA:
                continue
            ip_servidor = endereco[0]
            if confirmar_servidor(ip_servidor, recursos_cliente=recursos_cliente, _propagar_recusa=True):
                return ip_servidor
            if estrito:
                raise RuntimeError('descoberta_inconclusiva')
    except CheckRecusado:
        if estrito:
            raise
        return None
    except socket.timeout:
        if estrito and not enviado:
            raise
        return None
    except OSError as erro:
        if estrito:
            raise
        print(f"Erro ao procurar servidor: {erro}")
        return None


if __name__ == "__main__":
    print("=== BUSCA SERVIDOR TC420 ===")
    print("Procurando servidor na rede...")
    print()

    servidor = buscar_servidor()

    if servidor:
        print("SERVIDOR TC420 ENCONTRADO!")
        print(f"IP: {servidor}")
        print(f"Porta: {PORTA_TCP}")
    else:
        print("Nenhum servidor TC420 encontrado.")

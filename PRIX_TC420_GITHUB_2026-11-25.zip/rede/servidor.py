# Principal: uma fonte HTTPS alimenta os clientes TCP; ciclos e registros acompanham a saída.
import json
import logging
import socket
import sys
import threading
import time
from dataclasses import dataclass, replace

from mensagens_seguras import mensagem_erro_http


HOST = "0.0.0.0"
PORTA_TCP = 42100
PORTA_DESCOBERTA = 42101

INTERVALO_LEITURA = 1
MAX_FALHAS_CONSECUTIVAS = 3
TEMPO_ABANDONO_PRINCIPAL = 25

MENSAGEM_DESCOBERTA = b"TC420_SERVER_DISCOVERY"
MENSAGEM_RESPOSTA = b"TC420_SERVER_HERE"


# =====================================================
# ESTADO GLOBAL DOS DADOS
# =====================================================
#
# Esta é a ÚNICA fonte de dados do servidor.
#
# A rotina ler_tc420() consulta a balança
# (web.obter_estado) e atualiza este dicionário.
# Todos os clientes apenas leem o valor aqui presente.
#
# Assim, N clientes conectados continuam gerando apenas
# 1 consulta à TC420 por segundo.

dados_atuais = {
    "estado": "Z0",
    "peso_bruto": 0,
    "tara": 0,
    "peso_liquido": 0,
    "unidade": "kg",
    "multirange": "1",
}


configuracao_atual = {}
clientes_registrados = {}
lock_clientes = threading.Lock()
saude_tc420 = {
    "saudavel": False,
    "falhas_consecutivas": 0,
    "ultimo_sucesso": None,
    "ultimo_erro": None,
    "inicio_indisponibilidade": None,
}
lock_saude = threading.Lock()
evento_parada_servidor = threading.Event()


# Sinaliza o evento global de parada; a conclusão depende da saída dos trabalhadores e da limpeza.
def solicitar_parada_servidor():
    print("")
    print("Parada do servidor TC420 solicitada.")
    evento_parada_servidor.set()


# Permite consultar o sinal global sem alterar o estado do ciclo.
def servidor_deve_parar():
    return evento_parada_servidor.is_set()

# Confere o ID para não parar outra geração e tenta interromper/fechar os sockets do ciclo correto.
def solicitar_parada_ciclo(ciclo_id):
    """Nao sinalizar outra geracao; handles sao interrompidos fora dos locks."""
    with controle_ciclo_servidor.lock:
        if controle_ciclo_servidor.ciclo_id != ciclo_id:
            return False
        registro = controle_ciclo_servidor.registro_atual
        if registro is None:
            return False
        evento_parada_servidor.set()
    registro.bloquear_criacao()
    with registro.lock:
        sockets = tuple(e.recurso for e in registro._reservas_socket.values() if e.recurso is not None)
    erro_original = None
    for recurso in sockets:
        try:
            recurso.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        except BaseException as erro:
            if erro_original is None:
                erro_original = erro
    try:
        registro.limpar_sockets()
    except BaseException as limpeza:
        if erro_original is not None:
            raise erro_original from limpeza
        raise
    if erro_original is not None:
        raise erro_original
    return True


# Consulta o ciclo atual e distingue identidade ausente, correspondente ou divergente.
def consultar_estado_ciclo_servidor(ciclo_id=None):
    with controle_ciclo_servidor.lock:
        ciclo_id_atual = controle_ciclo_servidor.ciclo_id
        estado = controle_ciclo_servidor.estado
        registro = controle_ciclo_servidor.registro_atual
        if registro is None:
            return {
                "ciclo_id": None,
                "correspondencia": "ausente",
                "estado": "livre",
                "trabalhadores_encerrados": True if ciclo_id is None else None,
            }
        if ciclo_id is not None and ciclo_id != ciclo_id_atual:
            return {
                "ciclo_id": ciclo_id_atual,
                "correspondencia": "divergente",
                "trabalhadores_encerrados": None,
            }
        situacao = registro.obter_situacao()
        return {
            "ciclo_id": ciclo_id_atual,
            "correspondencia": "correspondente",
            "estado": estado,
            "trabalhadores_encerrados": (
                situacao["criacao_bloqueada"]
                and not situacao["threads_vivas"]
                and not situacao["erros_limpeza"]
            ),
            "threads_vivas": situacao["threads_vivas"],
            "erros_limpeza": situacao["erros_limpeza"],
        }


# Consulta pelo ID original, inclusive após outro ciclo ter assumido o lugar do anterior.
def consultar_historico_ciclo_servidor(ciclo_id):
    if type(ciclo_id) is not int or ciclo_id <= 0:
        return {
            "ciclo_id": None,
            "estado": "desconhecido",
            "encerramento_confirmado": None,
            "threads_vivas": None,
            "erros_limpeza": None,
        }
    situacao = controle_ciclo_servidor._obter_situacao_historica(ciclo_id)
    conhecido = situacao["estado"] != "desconhecido"
    return {
        "ciclo_id": ciclo_id,
        "estado": situacao["estado"],
        "encerramento_confirmado": situacao["encerramento_confirmado"],
        "threads_vivas": len(situacao["threads_vivas"]) if conhecido else None,
        "erros_limpeza": bool(situacao["erros_limpeza"]) if conhecido else None,
    }


# Cruza contexto e histórico; inconsistência ou evidência ausente conservam resultado desconhecido.
def avaliar_encerramento_tentativa(contexto):
    resultado = {
        "ciclo_id": None,
        "estado": "desconhecido",
        "encerramento_confirmado": None,
        "erro_reserva": None,
        "erro_coordenador": None,
    }

    # Registra somente a categoria da inconsistência e retorna a avaliação conservadora já montada.
    def desconhecido(categoria):
        logging.getLogger(__name__).warning(
            "SERVIDOR: avaliação de encerramento: %s", categoria
        )
        return resultado

    try:
        situacao = contexto.obter_situacao()
    except Exception:
        return desconhecido("falha_consulta_contexto")
    campos = {
        "reserva_resolvida", "ciclo_id", "erro_reserva",
        "coordenador_retornou", "erro_coordenador",
    }
    if type(situacao) is not dict or not campos.issubset(situacao):
        return desconhecido("contexto_invalido")
    resolvida = situacao["reserva_resolvida"]
    retornou = situacao["coordenador_retornou"]
    ciclo_id = situacao["ciclo_id"]
    erro_reserva = situacao["erro_reserva"]
    erro_coordenador = situacao["erro_coordenador"]
    if type(resolvida) is not bool or type(retornou) is not bool:
        return desconhecido("contexto_invalido")
    if erro_reserva is not None and type(erro_reserva) is not str:
        return desconhecido("contexto_invalido")
    if erro_coordenador is not None and type(erro_coordenador) is not str:
        return desconhecido("contexto_invalido")
    if erro_reserva not in (None, "sessao_invalida", "reserva_recusada", "falha_antes_reserva", "falha"):
        return desconhecido("contexto_invalido")
    if erro_coordenador not in (None, "falha_execucao", "falha_limpeza"):
        return desconhecido("contexto_invalido")
    if ciclo_id is not None and (type(ciclo_id) is not int or ciclo_id <= 0):
        return desconhecido("contexto_invalido")
    resultado.update(ciclo_id=ciclo_id, erro_reserva=erro_reserva, erro_coordenador=erro_coordenador)
    if not resolvida:
        if retornou or ciclo_id is not None or erro_reserva is not None or erro_coordenador is not None:
            return desconhecido("contexto_inconsistente")
        resultado.update(estado="reserva_pendente", encerramento_confirmado=False)
        return resultado
    if ciclo_id is None:
        resultado["estado"] = "sem_ciclo"
        return resultado
    if erro_reserva is not None or (not retornou and erro_coordenador is not None):
        return desconhecido("contexto_inconsistente")
    if not retornou:
        resultado.update(estado="coordenador_executando", encerramento_confirmado=False)
        return resultado
    try:
        historico = consultar_historico_ciclo_servidor(ciclo_id)
    except Exception:
        return desconhecido("falha_consulta_historico")
    campos = {"ciclo_id", "estado", "encerramento_confirmado", "threads_vivas", "erros_limpeza"}
    if type(historico) is not dict or not campos.issubset(historico):
        return desconhecido("historico_invalido")
    if type(historico["ciclo_id"]) is not int or historico["ciclo_id"] != ciclo_id:
        return desconhecido("identidade_divergente")
    estado = historico["estado"]
    confirmado = historico["encerramento_confirmado"]
    vivos = historico["threads_vivas"]
    erros = historico["erros_limpeza"]
    if type(estado) is not str:
        return desconhecido("historico_invalido")
    if estado == "desconhecido":
        return desconhecido("historico_desconhecido" if confirmado is None and vivos is None and erros is None else "historico_inconsistente")
    if type(vivos) is not int or vivos < 0 or type(erros) is not bool:
        return desconhecido("historico_invalido")
    if estado == "confirmado":
        if confirmado is not True or vivos != 0 or erros:
            return desconhecido("historico_inconsistente")
        resultado.update(estado="confirmado", encerramento_confirmado=True)
        return resultado
    if estado not in ("executando", "pendente") or confirmado is not False:
        return desconhecido("historico_inconsistente")
    resultado.update(estado="trabalhadores_pendentes", encerramento_confirmado=False)
    return resultado


# Guarda uma cópia rasa das faixas usadas para responder CONFIG aos clientes.
def definir_configuracao(configuracao):
    global configuracao_atual
    configuracao_atual = configuracao.copy()


def obter_dados_atuais():
    """
    Retorna uma cópia do último estado conhecido da TC420.

    É a função usada por quem precisa apenas OBSERVAR os
    dados (a janela local, por exemplo), sem disparar
    nenhuma consulta à balança.
    """
    return dados_atuais.copy()


# Copia o diagnóstico de saúde sob lock para não expor diretamente o dicionário compartilhado.
def obter_saude_tc420():
    with lock_saude:
        return saude_tc420.copy()


# Centraliza a leitura HTTPS, atualiza a saúde e solicita abandono após indisponibilidade prolongada.
def ler_tc420(web, contexto_ciclo=None):
    """
    Atualiza 'dados_atuais' continuamente a partir da TC420.

    Existe apenas UMA instância desta rotina, portanto
    N clientes conectados continuam gerando apenas
    1 leitura à TC420 por segundo.

    'web' é a MESMA sessão autenticada usada pela janela
    local. Existe um único login HTTP na máquina principal.
    """
    global dados_atuais

    print("Leitura HTTP da TC420 iniciada.\n")

    while not evento_parada_servidor.is_set():
        try:
            estado = web.obter_estado()
            with lock_saude:
                estava_saudavel = saude_tc420["saudavel"]
                saude_tc420["saudavel"] = True
                saude_tc420["falhas_consecutivas"] = 0
                saude_tc420["ultimo_sucesso"] = time.time()
                saude_tc420["ultimo_erro"] = None
                saude_tc420["inicio_indisponibilidade"] = None
            if not estava_saudavel:
                print("TC420 saudável: comunicação HTTP estabelecida.")

            # Mantém exatamente os campos que os clientes
            # já conhecem, sem expor o protocolo bruto.
            dados_atuais = {
                "estado": estado["estado"],
                "peso_bruto": estado["peso_bruto"],
                "tara": estado["tara"],
                "peso_liquido": estado["peso_liquido"],
                "unidade": estado["unidade"],
                "multirange": estado["multirange"],
            }
            if contexto_ciclo is not None:
                contexto_ciclo.ultimo_dado_monotonico = time.monotonic()
                contexto_ciclo.dados_prontos.set()

            print(
                f"TC420 | "
                f"Estado: {dados_atuais['estado']} | "
                f"Peso: {dados_atuais['peso_liquido']} "
                f"{dados_atuais['unidade']} | "
                f"Tara: {dados_atuais['tara']} "
                f"{dados_atuais['unidade']} | "
                f"Faixa: {dados_atuais['multirange']}"
            )

        except Exception as erro:
            diagnostico = mensagem_erro_http(erro)
            with lock_saude:
                saude_tc420["falhas_consecutivas"] += 1
                saude_tc420["ultimo_erro"] = diagnostico
                falhas = saude_tc420["falhas_consecutivas"]
                estava_saudavel = saude_tc420["saudavel"]
                if falhas >= MAX_FALHAS_CONSECUTIVAS:
                    saude_tc420["saudavel"] = False
                    if saude_tc420["inicio_indisponibilidade"] is None:
                        saude_tc420["inicio_indisponibilidade"] = time.monotonic()
                    inicio_indisponibilidade = saude_tc420["inicio_indisponibilidade"]
                else:
                    inicio_indisponibilidade = None
            print(
                "Erro na leitura HTTP da TC420 "
                f"({falhas}/{MAX_FALHAS_CONSECUTIVAS}): {diagnostico}"
            )
            if estava_saudavel and falhas == MAX_FALHAS_CONSECUTIVAS:
                print("")
                print("ATENÇÃO: TC420 NÃO SAUDÁVEL.")
                print(
                    "A comunicação HTTP falhou "
                    f"{MAX_FALHAS_CONSECUTIVAS} vezes consecutivas."
                )
                print("")

            if inicio_indisponibilidade is not None:
                tempo_indisponivel = time.monotonic() - inicio_indisponibilidade
                if tempo_indisponivel >= TEMPO_ABANDONO_PRINCIPAL:
                    print("")
                    print(
                        "TC420 permaneceu não saudável por "
                        f"{TEMPO_ABANDONO_PRINCIPAL} segundos."
                    )
                    print("Abandonando o papel de PRINCIPAL.")
                    solicitar_parada_servidor()
                    break

        if evento_parada_servidor.wait(INTERVALO_LEITURA):
            break

    print("Leitura HTTP da TC420 encerrada.")


# =====================================================
# SERVIDOR TCP
# =====================================================


# Lê um comando por conexão: CHECK, CONFIG, REGISTER ou envio contínuo de amostras em SUBSCRIBE.
def atender_cliente(cliente, endereco, registro_trabalhadores=None, reserva_socket=None):
    try:
        cliente.settimeout(5)

        comando = cliente.recv(1024).decode(
            "utf-8",
            errors="ignore",
        ).strip()

        # ---------------------------------------------
        # Apenas confirmação usada pelo buscarservidor
        # ---------------------------------------------
        if comando == "CHECK":
            saude = obter_saude_tc420()
            if saude["saudavel"]:
                cliente.sendall(
                    b"TC420_SERVER_OK\n"
                )
            return

        # ---------------------------------------------
        # Cliente quer receber dados continuamente
        # ---------------------------------------------
        if comando == "CONFIG":
            mensagem = (
                json.dumps(configuracao_atual) + "\n"
            ).encode("utf-8")
            cliente.sendall(mensagem)
            return

        if comando.startswith("REGISTER|"):
            nome = comando.partition("|")[2].strip()
            if not nome:
                return

            with lock_clientes:
                if nome not in clientes_registrados:
                    clientes_registrados[nome] = len(clientes_registrados) + 1
                posicao = clientes_registrados[nome]

            resposta = {"nome": nome, "posicao": posicao}
            cliente.sendall(
                (json.dumps(resposta) + "\n").encode("utf-8")
            )
            print(f"Cliente registrado: {nome} | Posição: {posicao}")
            return

        if comando == "SUBSCRIBE":
            print(
                f"Cliente inscrito para dados: "
                f"{endereco[0]}"
            )

            cliente.settimeout(None)

            while not evento_parada_servidor.is_set():
                saude = obter_saude_tc420()
                if not saude["saudavel"]:
                    print(
                        f"Encerrando SUBSCRIBE de {endereco[0]}: "
                        "TC420 não saudável."
                    )
                    return
                mensagem = (
                    json.dumps(dados_atuais) + "\n"
                ).encode("utf-8")

                cliente.sendall(mensagem)

                if evento_parada_servidor.wait(1):
                    return

            return

        print(
            f"Comando desconhecido de "
            f"{endereco[0]}: {comando!r}"
        )

    except (
        ConnectionResetError,
        ConnectionAbortedError,
        BrokenPipeError,
        socket.timeout,
        OSError,
    ):
        print(
            f"Cliente desconectado: "
            f"{endereco[0]}"
        )

    finally:
        _finalizar_cliente_handler(
            cliente, registro_trabalhadores, reserva_socket, sys.exc_info()[1])


# Fecha o cliente e publica a evidência de limpeza do handler sem substituir um erro anterior.
def _finalizar_cliente_handler(cliente, registro, reserva, erro_atendimento):
    try:
        if cliente.fileno() != -1:
            cliente.close()
    except BaseException as erro_limpeza:
        if registro is not None:
            try:
                if not registro.publicar_limpeza_handler(reserva, erro_limpeza):
                    print("SERVIDOR: resultado de limpeza do handler permanece pendente.")
            except BaseException:
                # A pendência não é liberada se a publicação falhar. Não troca
                # a exceção de atendimento/close pela exceção do registro.
                print("SERVIDOR: falha ao publicar limpeza do handler.")
        if erro_atendimento is None:
            raise
    else:
        if registro is not None:
            try:
                if not registro.publicar_limpeza_handler(reserva):
                    print("SERVIDOR: resultado de limpeza do handler permanece pendente.")
            except BaseException:
                if erro_atendimento is None:
                    raise
                print("SERVIDOR: falha ao publicar limpeza do handler.")


# Finaliza a marca de uso antes de pedir ao registro o fechamento do socket.
def _encerrar_socket_do_ciclo(registro, reserva):
    registro.encerrar_uso_socket(reserva)
    return registro.fechar_socket(reserva)


# Reserva antes da alocação, associa o socket e publica a criação após sua preparação.
def _criar_socket_do_ciclo(registro, familia, tipo, preparar):
    reserva = registro.reservar_criacao_socket()
    if reserva is None:
        return None, None
    recurso = None
    try:
        recurso = socket.socket(familia, tipo)
        registro.anexar_socket(reserva, recurso)
        preparar(recurso)
        if not registro.publicar_socket(reserva):
            registro.fechar_socket(reserva)
            return None, None
        return reserva, recurso
    except BaseException:
        registro.resolver_falha_criacao_socket(reserva, recurso)
        if recurso is not None:
            registro.fechar_socket(reserva)
        raise


# Envolve o handler com acompanhamento do uso e da limpeza do socket aceito.
def _atender_cliente_do_ciclo(cliente, endereco, registro, reserva):
    if not registro.iniciar_limpeza_handler(reserva):
        raise RuntimeError("SERVIDOR: responsabilidade de limpeza do handler recusada.")
    try:
        atender_cliente(cliente, endereco, registro_trabalhadores=registro, reserva_socket=reserva)
    finally:
        erro_ativo = sys.exc_info()[1]
        try:
            _encerrar_socket_do_ciclo(registro, reserva)
        except BaseException:
            if erro_ativo is None:
                raise
            print("SERVIDOR: falha na finalização da responsabilidade do handler.")


# Escuta clientes e inicia um handler acompanhado para cada conexão aceita.
def servidor_tcp(registro_trabalhadores=None):
    registro = registro_trabalhadores if registro_trabalhadores is not None else RegistroTrabalhadores()

    # Configura reutilização do endereço, bind, escuta e timeout do listener TCP.
    def preparar(servidor):
        servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        servidor.bind((HOST, PORTA_TCP))
        servidor.listen()
        servidor.settimeout(1)

    reserva_servidor, servidor = _criar_socket_do_ciclo(
        registro, socket.AF_INET, socket.SOCK_STREAM, preparar)
    if servidor is None:
        return
    contexto = getattr(registro, 'contexto_prontidao', None)
    if contexto is not None:
        contexto.tcp_pronto.set()
    print(f"Servidor TCP ativo na porta {PORTA_TCP}.")
    print("Aguardando conexões...")
    print()
    try:
        while not evento_parada_servidor.is_set():
            reserva = registro.reservar_criacao_socket()
            if reserva is None:
                break
            try:
                cliente, endereco = servidor.accept()
            except socket.timeout:
                registro.resolver_falha_criacao_socket(reserva, sem_alocacao_comprovada=True)
                continue
            except BaseException:
                registro.resolver_falha_criacao_socket(reserva)
                raise
            start_solicitado = False
            try:
                registro.anexar_socket(reserva, cliente)
                if not registro.publicar_socket(reserva):
                    registro.fechar_socket(reserva)
                    continue
                print(f"Cliente conectado: {endereco[0]}:{endereco[1]}")
                thread = threading.Thread(
                    target=_atender_cliente_do_ciclo,
                    args=(cliente, endereco, registro, reserva),
                    daemon=True,
                )
                start_solicitado = True
                iniciado = registro.registrar_e_iniciar(thread)
                if not iniciado:
                    _encerrar_socket_do_ciclo(registro, reserva)
            except BaseException:
                if not start_solicitado:
                    registro.resolver_falha_criacao_socket(reserva, cliente)
                    registro.fechar_socket(reserva)
                raise
    finally:
        _encerrar_socket_do_ciclo(registro, reserva_servidor)
        print("Servidor TCP encerrado.")


# =====================================================
# DESCOBERTA UDP
# =====================================================


# Responde ao broadcast de descoberta apenas quando a saúde da TC420 permite anunciar o principal.
def servidor_descoberta(registro_trabalhadores=None):
    registro = registro_trabalhadores if registro_trabalhadores is not None else RegistroTrabalhadores()

    # Configura o socket UDP, associa a porta de descoberta e limita a espera por datagramas.
    def preparar(udp):
        udp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        udp.bind((HOST, PORTA_DESCOBERTA))
        udp.settimeout(1)

    reserva, udp = _criar_socket_do_ciclo(registro, socket.AF_INET, socket.SOCK_DGRAM, preparar)
    if udp is None:
        return
    contexto = getattr(registro, 'contexto_prontidao', None)
    if contexto is not None:
        contexto.udp_pronto.set()
    print(f"Descoberta UDP ativa na porta {PORTA_DESCOBERTA}.")
    try:
        while not evento_parada_servidor.is_set():
            try:
                dados, endereco = udp.recvfrom(1024)
            except socket.timeout:
                continue
            if dados == MENSAGEM_DESCOBERTA:
                saude = obter_saude_tc420()
                if saude["saudavel"]:
                    udp.sendto(MENSAGEM_RESPOSTA, endereco)
    except Exception as erro:
        print(f"Erro na descoberta UDP: {erro}")
    finally:
        _encerrar_socket_do_ciclo(registro, reserva)
        print("Descoberta UDP encerrada.")


# Representa a identidade de uma reserva, separada do socket que poderá ser criado depois.
@dataclass(frozen=True)
class _ReservaCriacaoSocket:
    criacao_id: int
    ciclo_id: object
    dono: object


# Agrupa os dados de acompanhamento de criação, uso e fechamento de um socket do ciclo.
@dataclass(frozen=True)
class _CriacaoSocket:
    reserva: object
    estado: str = "reservada"
    recurso: object = None
    em_uso: bool = True
    erro: object = None
    limpeza_handler_pendente: bool = False
    resultado_limpeza_handler_publicado: bool = False
    erro_fechamento_handler: object = None


@dataclass(frozen=True, slots=True)
class _CriacaoSocketResolvida:
    """Mesmos campos, sem dicionário por instância; conserva o token original.

    Usada somente para ausência comprovada de recurso sem erro/pendência.
    Não elimina histórico nem representa responsabilidades ainda ativas.
    """
    reserva: object
    estado: str = "sem_recurso"
    recurso: object = None
    em_uso: bool = False
    erro: object = None
    limpeza_handler_pendente: bool = False
    resultado_limpeza_handler_publicado: bool = False
    erro_fechamento_handler: object = None


# Concentra threads, reservas de sockets e erros de limpeza pertencentes a um único ciclo servidor.
class RegistroTrabalhadores:
    # Cria o lock e as coleções que mantêm alcançáveis as threads e os sockets deste registro.
    def __init__(self):
        self.lock = threading.Lock()
        self.threads = []
        self.criacao_bloqueada = False
        self.erros_limpeza = []
        self.publicacao_limpeza_concluida = False
        self._reservas_socket = {}
        self._ultimo_socket_id = 0

    # Recusa novas reservas após o bloqueio de criação e devolve uma identidade para a alocação admitida.
    def reservar_criacao_socket(self):
        with self.lock:
            if self.criacao_bloqueada or self.publicacao_limpeza_concluida:
                return None
            self._ultimo_socket_id += 1
            reserva = _ReservaCriacaoSocket(
                self._ultimo_socket_id, getattr(self, "ciclo_id", None), self)
            self._reservas_socket[reserva.criacao_id] = _CriacaoSocket(reserva)
            return reserva

    # Valida a identidade no registro; deve ser chamado com a proteção do lock já adquirida.
    def _buscar_socket_sob_lock(self, reserva):
        if type(reserva) is not _ReservaCriacaoSocket or reserva.dono is not self:
            return None
        entrada = self._reservas_socket.get(reserva.criacao_id)
        return entrada if entrada is not None and entrada.reserva is reserva else None

    # Associa à reserva o objeto realmente criado, rejeitando uma associação incompatível.
    def anexar_socket(self, reserva, recurso):
        if recurso is None:
            raise ValueError("socket_ausente")
        with self.lock:
            entrada = self._buscar_socket_sob_lock(reserva)
            if entrada is None or entrada.estado != "reservada":
                raise ValueError("reserva_socket_invalida")
            self._reservas_socket[reserva.criacao_id] = replace(
                entrada, estado="alocada", recurso=recurso)

    # Registra que a preparação do socket terminou e seu uso pode ser acompanhado.
    def publicar_socket(self, reserva):
        with self.lock:
            entrada = self._buscar_socket_sob_lock(reserva)
            if entrada is None or entrada.estado != "alocada":
                raise ValueError("publicacao_socket_invalida")
            permitido = not (self.criacao_bloqueada or self.publicacao_limpeza_concluida)
            self._reservas_socket[reserva.criacao_id] = replace(
                entrada, estado="publicada" if permitido else "aguarda_limpeza",
                em_uso=permitido)
            return permitido

    # Registra a resolução da tentativa de criação sem transformar incerteza em prova de ausência.
    def resolver_falha_criacao_socket(self, reserva, recurso=None, *, sem_alocacao_comprovada=False):
        with self.lock:
            entrada = self._buscar_socket_sob_lock(reserva)
            if entrada is None:
                return False
            if entrada.estado in ("fechada", "sem_recurso", "fechando", "erro_limpeza"):
                return False
            # Retém inclusive handle conhecido cuja anexação/publicação falhou.
            if recurso is not None:
                atualizada = replace(entrada, estado="aguarda_limpeza", recurso=recurso,
                                     em_uso=False, erro="falha_criacao_com_socket")
            elif sem_alocacao_comprovada is True and entrada.recurso is None:
                atualizada = replace(entrada, estado="sem_recurso", em_uso=False)
                # Não apagar identidade nem diagnósticos. Erros e publicações
                # pendentes conservam integralmente a representação original.
                if (atualizada.erro is None and not atualizada.limpeza_handler_pendente
                        and atualizada.erro_fechamento_handler is None):
                    atualizada = _CriacaoSocketResolvida(
                        reserva=atualizada.reserva,
                        resultado_limpeza_handler_publicado=
                            atualizada.resultado_limpeza_handler_publicado)
            else:
                atualizada = replace(entrada, estado="criacao_incerta", erro="falha_criacao_incerta")
            self._reservas_socket[reserva.criacao_id] = atualizada
            return True

    # Publica que o uso acompanhado do socket terminou, antes da limpeza correspondente.
    def encerrar_uso_socket(self, reserva):
        with self.lock:
            entrada = self._buscar_socket_sob_lock(reserva)
            if entrada is None or entrada.estado not in ("publicada", "aguarda_limpeza"):
                return False
            self._reservas_socket[reserva.criacao_id] = replace(
                entrada, estado="aguarda_limpeza", em_uso=False)
            return True

    # Marca a responsabilidade de limpeza do handler associado à reserva.
    def iniciar_limpeza_handler(self, reserva):
        with self.lock:
            entrada = self._buscar_socket_sob_lock(reserva)
            if (entrada is None or entrada.estado != "publicada" or not entrada.em_uso
                    or entrada.resultado_limpeza_handler_publicado):
                return False
            self._reservas_socket[reserva.criacao_id] = replace(
                entrada, limpeza_handler_pendente=True)
            return True

    # Registra o resultado observado do fechamento e eventuais erros da limpeza do handler.
    def publicar_limpeza_handler(self, reserva, erro=None):
        with self.lock:
            entrada = self._buscar_socket_sob_lock(reserva)
            if entrada is None:
                return False
            if entrada.resultado_limpeza_handler_publicado:
                return True
            if not entrada.limpeza_handler_pendente:
                return False
            categoria = None
            if erro is not None:
                categoria = ("OSError" if isinstance(erro, OSError) else
                             "Exception" if isinstance(erro, Exception) else "BaseException")
            atualizada = replace(
                entrada, limpeza_handler_pendente=False,
                resultado_limpeza_handler_publicado=True, erro_fechamento_handler=categoria)
            if categoria is not None:
                # Publica o erro antes de resolver a pendência, sob o mesmo lock.
                # A publicação do coordenador não encerra responsabilidades antigas.
                self.erros_limpeza.append("handler.close:" + categoria)
            self._reservas_socket[reserva.criacao_id] = atualizada
            return True

    # Fecha fora da região de decisão protegida e publica a evidência ou erro de limpeza no registro.
    def fechar_socket(self, reserva):
        with self.lock:
            entrada = self._buscar_socket_sob_lock(reserva)
            if entrada is None:
                return False
            if entrada.estado in ("fechada", "sem_recurso"):
                return True
            if (entrada.em_uso or entrada.limpeza_handler_pendente
                    or entrada.estado != "aguarda_limpeza"):
                return False
            self._reservas_socket[reserva.criacao_id] = replace(entrada, estado="fechando")
            recurso = entrada.recurso
        try:
            if recurso.fileno() != -1:
                recurso.close()
            if recurso.fileno() != -1:
                raise RuntimeError("socket_sem_liberacao_comprovada")
        except Exception:
            with self.lock:
                atual = self._buscar_socket_sob_lock(reserva)
                self._reservas_socket[reserva.criacao_id] = replace(
                    atual, estado="erro_limpeza", erro="falha_limpeza_socket")
                # Resolução de recurso já conhecido continua após publicação do
                # coordenador; o histórico não compacta enquanto houver pendência.
                self.erros_limpeza.append("falha_limpeza_socket")
            return False
        with self.lock:
            atual = self._buscar_socket_sob_lock(reserva)
            self._reservas_socket[reserva.criacao_id] = replace(atual, estado="fechada")
        return True

    # Bloqueia novas criações e tenta fechar os recursos reservados que ainda exigem limpeza.
    def limpar_sockets(self):
        self.bloquear_criacao()
        with self.lock:
            reservas = tuple(e.reserva for e in self._reservas_socket.values())
        for reserva in reservas:
            self.fechar_socket(reserva)

    # Resume as evidências de fechamento dos sockets sob a proteção do registro.
    def _sockets_encerrados_sob_lock(self):
        return all(e.estado in ("fechada", "sem_recurso") and not e.limpeza_handler_pendente
                   and e.erro_fechamento_handler is None for e in self._reservas_socket.values())

    # Serializa admissão e start para impedir que uma thread nova escape ao bloqueio de criação.
    def registrar_e_iniciar(self, thread):
        with self.lock:
            if self.criacao_bloqueada or self.publicacao_limpeza_concluida:
                return False
            self.threads.append(thread)
            try:
                thread.start()
            except Exception:
                # Start pode lançar depois de executar. Preserva o trabalhador;
                # não transfere/fecha seu socket enquanto a entrada for incerta.
                raise
            return True

    # Fecha a admissão de novos trabalhadores e sockets neste registro.
    def bloquear_criacao(self):
        with self.lock:
            self.criacao_bloqueada = True

    # Retém um diagnóstico de limpeza para impedir confirmação indevida de encerramento.
    def registrar_erro_limpeza(self, erro):
        with self.lock:
            if self.publicacao_limpeza_concluida:
                raise RuntimeError("SERVIDOR: publicação de limpeza já concluída.")
            self.erros_limpeza.append(str(erro))

    # Calcula um retrato com threads vivas e erros, incluindo pendências de sockets no diagnóstico de limpeza.
    def obter_situacao(self):
        with self.lock:
            return {
                "criacao_bloqueada": self.criacao_bloqueada,
                "threads_vivas": [
                    thread.name
                    for thread in self.threads
                    if thread.is_alive()
                ],
                "erros_limpeza": list(self.erros_limpeza),
                "sockets_encerrados": self._sockets_encerrados_sob_lock(),
                "criacoes_socket": tuple({
                    "criacao_id": e.reserva.criacao_id, "ciclo_id": e.reserva.ciclo_id,
                    "estado": e.estado, "em_uso": e.em_uso, "erro": e.erro,
                    "limpeza_handler_pendente": e.limpeza_handler_pendente,
                    "resultado_limpeza_handler_publicado": e.resultado_limpeza_handler_publicado,
                } for e in self._reservas_socket.values()),
                "falhas_fechamento_handlers": tuple({
                    "criacao_id": e.reserva.criacao_id, "ciclo_id": e.reserva.ciclo_id,
                    "origem": "handler.close", "tipo": e.erro_fechamento_handler,
                } for e in self._reservas_socket.values() if e.erro_fechamento_handler is not None),
            }

    # Exige criação bloqueada, ausência de threads vivas e ausência dos erros de limpeza publicados.
    def encerramento_confirmado(self):
        situacao = self.obter_situacao()
        return (
            situacao["criacao_bloqueada"]
            and not situacao["threads_vivas"]
            and not situacao["erros_limpeza"]
            and situacao["sockets_encerrados"]
        )


# Entrega ao chamador a identidade reservada e os sinais de resolução e retorno do coordenador.
class ContextoCicloServidor:
    # Começa com reserva e retorno ainda não resolvidos; cada evento representa uma evidência diferente.
    def __init__(self):
        self._lock = threading.Lock()
        self.resolvido = threading.Event()
        self.ciclo_id = None
        self.erro = None
        self.coordenador_retornou = threading.Event()
        self.erro_coordenador = None
        # Sinais pertencem à tentativa, nunca são reutilizados por outro ciclo.
        self.tcp_pronto = threading.Event()
        self.udp_pronto = threading.Event()
        self.dados_prontos = threading.Event()
        self.ultimo_dado_monotonico = None
        self.trabalhadores_prontidao = ()
        self.cancelar_partida = threading.Event()

    # Resolve o contexto com o ID efetivamente atribuído ao ciclo servidor.
    def registrar_reserva(self, ciclo_id):
        with self._lock:
            if self.resolvido.is_set():
                return False
            self.ciclo_id = ciclo_id
            self.resolvido.set()
            return True

    # Resolve o contexto com uma categoria de falha, sem inventar um ID de ciclo.
    def registrar_falha(self, erro):
        with self._lock:
            if self.resolvido.is_set():
                return False
            self.erro = (
                erro
                if isinstance(erro, str) and erro in (
                    "sessao_invalida", "reserva_recusada", "falha_antes_reserva"
                )
                else "falha"
            )
            self.resolvido.set()
            return True


    # Publica que a rotina coordenadora retornou; isso não comprova a saída de todas as threads.
    def registrar_retorno_coordenador(self, falha=None):
        with self._lock:
            if self.coordenador_retornou.is_set():
                return False
            if not self.resolvido.is_set():
                return False
            self.erro_coordenador = (
                None if falha is None else
                falha if isinstance(falha, str) and falha in (
                    "falha_execucao", "falha_limpeza"
                ) else "falha_execucao"
            )
            self.coordenador_retornou.set()
            return True

    # Copia sob lock os sinais e as categorias publicados pela tentativa, sem esperar os eventos.
    def obter_situacao(self):
        with self._lock:
            return {
                "reserva_resolvida": self.resolvido.is_set(),
                "ciclo_id": self.ciclo_id,
                "erro_reserva": self.erro,
                "coordenador_retornou": self.coordenador_retornou.is_set(),
                "erro_coordenador": self.erro_coordenador,
            }


# Mantém o estado de partida de uma tentativa junto do seu contexto original.
@dataclass(frozen=True)
class _TentativaAplicacao:
    tentativa_id: int
    contexto: object
    estado_partida: str = "admitida"
    erro_partida: object = None
    execucao_observada: bool = False


# Acompanha as tentativas da execução para que falhas de partida não desapareçam da avaliação de saída.
class RegistroTentativasAplicacao:
    # Prepara índices por contexto e ID, contador crescente e admissão inicialmente aberta.
    def __init__(self):
        self._lock = threading.Lock()
        self._tentativas = {}
        self._tentativas_por_id = {}
        self._admissao_fechada = False
        self._ultimo_id_tentativa = 0

    # Cria uma tentativa acompanhada enquanto a admissão da aplicação permanece aberta.
    def admitir(self, contexto):
        with self._lock:
            if self._admissao_fechada:
                return None
            chave = id(contexto)
            existente = self._tentativas.get(chave)
            if existente is not None:
                return existente.tentativa_id
            self._ultimo_id_tentativa += 1
            tentativa = _TentativaAplicacao(self._ultimo_id_tentativa, contexto)
            self._tentativas[chave] = tentativa
            self._tentativas_por_id[tentativa.tentativa_id] = tentativa
            return tentativa.tentativa_id

    # Valida e procura a identidade no índice de tentativas deste registro.
    def _buscar_tentativa(self, tentativa_id):
        if type(tentativa_id) is not int or tentativa_id <= 0:
            return None
        return self._tentativas_por_id.get(tentativa_id)

    # Substitui o retrato da tentativa conservando os índices usados nas consultas.
    def _atualizar_tentativa(self, tentativa, **alteracoes):
        atualizada = replace(tentativa, **alteracoes)
        self._tentativas[id(tentativa.contexto)] = atualizada
        self._tentativas_por_id[tentativa.tentativa_id] = atualizada

    # Publica a transição de uma tentativa admitida para a preparação de sua partida.
    def marcar_iniciando(self, tentativa_id):
        with self._lock:
            tentativa = self._buscar_tentativa(tentativa_id)
            if tentativa is None:
                return False
            if tentativa.estado_partida == "iniciando":
                return True
            if tentativa.estado_partida != "admitida":
                return False
            self._atualizar_tentativa(tentativa, estado_partida="iniciando")
            return True

    # Registra a confirmação de partida sem confundi-la com término da execução.
    def marcar_iniciada(self, tentativa_id):
        with self._lock:
            tentativa = self._buscar_tentativa(tentativa_id)
            if tentativa is None:
                return False
            if tentativa.estado_partida == "iniciada":
                return True
            if tentativa.estado_partida != "iniciando":
                return False
            self._atualizar_tentativa(tentativa, estado_partida="iniciada")
            return True

    # Confirma pela própria execução que o alvo da thread chegou a ser chamado.
    def registrar_entrada_execucao(self, tentativa_id):
        with self._lock:
            tentativa = self._buscar_tentativa(tentativa_id)
            if tentativa is None or tentativa.estado_partida not in ("iniciando", "iniciada"):
                return False
            if not tentativa.execucao_observada:
                self._atualizar_tentativa(tentativa, execucao_observada=True)
            return True

    # Diferencia falha comprovadamente anterior à execução de uma partida cujo resultado ficou incerto.
    def registrar_falha_partida(self, tentativa_id, erro, *, execucao_nao_iniciada=False):
        with self._lock:
            tentativa = self._buscar_tentativa(tentativa_id)
            if tentativa is None or execucao_nao_iniciada is not True:
                return False
            if tentativa.estado_partida == "falha_partida":
                return True
            if tentativa.estado_partida == "iniciada" or tentativa.execucao_observada:
                return False
            categoria = (
                erro if type(erro) is str and erro in ("falha_criacao_thread", "falha_start")
                else "falha_partida"
            )
            self._atualizar_tentativa(
                tentativa, estado_partida="falha_partida", erro_partida=categoria
            )
            return True

    # Recusa novas tentativas sem remover as que já precisam continuar acompanhadas.
    def fechar_admissao(self):
        with self._lock:
            if self._admissao_fechada:
                return False
            self._admissao_fechada = True
            return True

    # Entrega uma fotografia das tentativas retidas e do estado de admissão da execução.
    def obter_retrato(self):
        with self._lock:
            return {
                "admissao_fechada": self._admissao_fechada,
                "tentativas": tuple(self._tentativas.values()),
            }


_AGREGADO_ERROS_RESERVA = {None, "sessao_invalida", "reserva_recusada", "falha_antes_reserva", "falha"}
_AGREGADO_ERROS_COORDENADOR = {None, "falha_execucao", "falha_limpeza"}
_AGREGADO_ERROS_PARTIDA = {"falha_partida", "falha_criacao_thread", "falha_start"}
_AGREGADO_PRE_RESERVA = {"sessao_invalida", "reserva_recusada", "falha_antes_reserva"}


# Valida o formato dos sinais publicados pelo contexto antes de compor a avaliação.
def _obter_contexto_agregado(contexto):
    if not isinstance(contexto, ContextoCicloServidor):
        raise ValueError("contexto_invalido")
    situacao = contexto.obter_situacao()
    campos = {"reserva_resolvida", "ciclo_id", "erro_reserva",
              "coordenador_retornou", "erro_coordenador"}
    if type(situacao) is not dict or set(situacao) != campos:
        raise ValueError("contexto_invalido")
    resolvida, ciclo, erro, retornou, falha = (
        situacao["reserva_resolvida"], situacao["ciclo_id"],
        situacao["erro_reserva"], situacao["coordenador_retornou"],
        situacao["erro_coordenador"],
    )
    if type(resolvida) is not bool or type(retornou) is not bool:
        raise ValueError("contexto_invalido")
    if ciclo is not None and (type(ciclo) is not int or ciclo <= 0):
        raise ValueError("contexto_invalido")
    if erro is not None and type(erro) is not str:
        raise ValueError("contexto_invalido")
    if falha is not None and type(falha) is not str:
        raise ValueError("contexto_invalido")
    if erro not in _AGREGADO_ERROS_RESERVA or falha not in _AGREGADO_ERROS_COORDENADOR:
        raise ValueError("contexto_invalido")
    if (not resolvida and (ciclo is not None or erro is not None or retornou or falha is not None)
            or ciclo is not None and erro is not None
            or not retornou and falha is not None):
        raise ValueError("contexto_inconsistente")
    return (resolvida, ciclo, erro, retornou, falha)


# Valida a estrutura do retrato de tentativas que será usada na composição.
def _obter_retrato_agregado(registro):
    retrato = registro.obter_retrato()
    if type(retrato) is not dict or set(retrato) != {"admissao_fechada", "tentativas"}:
        raise ValueError("retrato_invalido")
    if type(retrato["admissao_fechada"]) is not bool or type(retrato["tentativas"]) is not tuple:
        raise ValueError("retrato_invalido")
    return retrato["admissao_fechada"], retrato["tentativas"]


# Rejeita IDs duplicados e contextos indevidamente reaproveitados entre tentativas.
def _validar_identidades_agregado(tentativas):
    ids, contextos = set(), set()
    for tentativa in tentativas:
        chave = tentativa.tentativa_id
        if type(chave) is not int or chave <= 0 or chave in ids:
            raise ValueError("identidade_invalida")
        if id(tentativa.contexto) in contextos:
            raise ValueError("contexto_duplicado")
        ids.add(chave)
        contextos.add(id(tentativa.contexto))


# Interpreta as evidências de partida e execução de uma tentativa sem executar limpeza.
def _classificar_tentativa_agregada(tentativa, situacao, individual):
    estado = tentativa.estado_partida
    erro = tentativa.erro_partida
    observada = tentativa.execucao_observada
    if type(estado) is not str or type(observada) is not bool:
        raise ValueError("partida_invalida")
    if estado == "falha_partida":
        if observada or type(erro) is not str or erro not in _AGREGADO_ERROS_PARTIDA:
            raise ValueError("falha_partida_inconsistente")
        # O registro terminal real exige evidência de não execução. None é a
        # única ausência de contexto aceita; contexto fornecido deve ser válido.
        if situacao is not None:
            resolvida, ciclo, erro_reserva, retornou, erro_coordenador = situacao
            if ciclo is not None or retornou or erro_coordenador is not None:
                raise ValueError("falha_partida_inconsistente")
            if resolvida and erro_reserva != "falha_antes_reserva":
                raise ValueError("falha_partida_inconsistente")
        return "falhas_partida_confirmadas"
    if erro is not None or estado not in ("admitida", "iniciando", "iniciada"):
        raise ValueError("partida_inconsistente")
    if situacao is None:
        raise ValueError("contexto_ausente")
    resolvida, ciclo, erro_reserva, retornou, erro_coordenador = situacao
    if estado == "admitida" and (observada or ciclo is not None or retornou):
        raise ValueError("partida_inconsistente")
    if not observada and (ciclo is not None or retornou):
        raise ValueError("execucao_sem_evidencia")
    if type(individual) is not dict or set(individual) != {
        "ciclo_id", "estado", "encerramento_confirmado", "erro_reserva", "erro_coordenador"
    }:
        raise ValueError("avaliacao_invalida")
    if (type(individual["ciclo_id"]) is not type(ciclo)
            or individual["ciclo_id"] != ciclo
            or individual["erro_reserva"] != erro_reserva
            or individual["erro_coordenador"] != erro_coordenador):
        raise ValueError("avaliacao_divergente")
    estado_individual = individual["estado"]
    confirmado = individual["encerramento_confirmado"]
    esperado = {
        "confirmado": True, "reserva_pendente": False,
        "coordenador_executando": False, "trabalhadores_pendentes": False,
        "sem_ciclo": None, "desconhecido": None,
    }
    if type(estado_individual) is not str or estado_individual not in esperado:
        raise ValueError("avaliacao_invalida")
    if confirmado is not esperado[estado_individual]:
        raise ValueError("avaliacao_inconsistente")
    if estado_individual == "desconhecido":
        return "desconhecidas"
    if estado_individual == "reserva_pendente" and resolvida:
        raise ValueError("avaliacao_inconsistente")
    if estado_individual == "sem_ciclo" and (not resolvida or ciclo is not None):
        raise ValueError("avaliacao_inconsistente")
    if estado_individual in ("confirmado", "coordenador_executando", "trabalhadores_pendentes"):
        if not resolvida or ciclo is None:
            raise ValueError("avaliacao_inconsistente")
        if estado_individual == "coordenador_executando" and retornou:
            raise ValueError("avaliacao_inconsistente")
        if estado_individual != "coordenador_executando" and not retornou:
            raise ValueError("avaliacao_inconsistente")
    # A fotografia de partida prevalece: entrada observada não resolve start
    # ambíguo, nem um ciclo já limpo autoriza pular iniciando -> iniciada.
    if estado in ("admitida", "iniciando"):
        return "pendentes"
    if estado_individual == "confirmado":
        return "confirmadas"
    if estado_individual == "sem_ciclo":
        if not retornou:
            return "pendentes"
        # Antes da reserva o coordenador não cria workers. Erro genérico ou
        # de limpeza não demonstra ausência de efeitos operacionais pendentes.
        if observada and erro_reserva in _AGREGADO_PRE_RESERVA and erro_coordenador in (None, "falha_execucao"):
            return "confirmadas"
        return "desconhecidas"
    return "pendentes"


# Compõe a situação das tentativas registradas; esta consulta não autoriza destruir a interface.
def avaliar_encerramento_aplicacao(registro):
    """Consulta o encerramento das tentativas registradas, sem autorizar fechamento.

    O registro real e o avaliador individual são autoridades das evidências.
    Não comprova liberação de sessões HTTP antigas ou de recursos externos.
    Falha comprovada cobre ausência de execução do servidor.
    Não consulta ciclo global nem executa espera, rede ou mutação.
    """
    resultado = dict(admissao_fechada=False, total_tentativas=0, confirmadas=0,
                     falhas_partida_confirmadas=0, pendentes=0, desconhecidas=0,
                     consistente=False, encerramento_confirmado=False)
    if not isinstance(registro, RegistroTentativasAplicacao):
        return resultado
    try:
        fechado, tentativas = _obter_retrato_agregado(registro)
    except Exception:
        return resultado
    resultado.update(admissao_fechada=fechado, total_tentativas=len(tentativas), consistente=True)
    try:
        _validar_identidades_agregado(tentativas)
    except Exception:
        resultado.update(desconhecidas=len(tentativas), consistente=False)
        return resultado
    situacoes = []
    ciclos = set()
    for tentativa in tentativas:
        situacoes.append(None)
        try:
            situacao = None if tentativa.contexto is None else _obter_contexto_agregado(tentativa.contexto)
            situacoes[-1] = situacao
            if situacao is not None and situacao[1] is not None:
                if situacao[1] in ciclos:
                    raise ValueError("ciclo_duplicado")
                ciclos.add(situacao[1])
            individual = (None if tentativa.estado_partida == "falha_partida"
                          else avaliar_encerramento_tentativa(tentativa.contexto))
            categoria = _classificar_tentativa_agregada(tentativa, situacao, individual)
        except Exception:
            # Mantém uma categoria por tentativa, sem mensagens de exceção.
            categoria = "desconhecidas"
            resultado["consistente"] = False
        resultado[categoria] += 1
    try:
        fechado_final, finais = _obter_retrato_agregado(registro)
        if fechado_final is not fechado or len(finais) != len(tentativas):
            raise ValueError("retrato_alterado")
        for tentativa, final, situacao in zip(tentativas, finais, situacoes, strict=True):
            if tentativa is not final:
                raise ValueError("partida_alterada")
            if tentativa.contexto is not None and _obter_contexto_agregado(tentativa.contexto) != situacao:
                raise ValueError("contexto_alterado")
    except Exception:
        resultado.update(confirmadas=0, falhas_partida_confirmadas=0, pendentes=0,
                         desconhecidas=len(tentativas), consistente=False)
    resultado["encerramento_confirmado"] = (
        fechado and resultado["consistente"] and resultado["pendentes"] == 0
        and resultado["desconhecidas"] == 0
        and resultado["confirmadas"] + resultado["falhas_partida_confirmadas"] == len(tentativas)
    )
    return resultado


# Retém o registro necessário para acompanhar um ciclo ainda não compactado.
@dataclass
class _EntradaHistoricoCiclo:
    ciclo_id: int
    registro: object
    coordenador_finalizado: bool = False


# Conserva um resumo do ciclo após a resolução que permite sua compactação.
@dataclass(frozen=True)
class _ResumoHistoricoCiclo:
    ciclo_id: int

    # Reconstitui o diagnóstico compacto sem recuperar os objetos completos do ciclo antigo.
    def obter_situacao(self):
        return {
            "criacao_bloqueada": True,
            "threads_vivas": [],
            "erros_limpeza": [],
        }

    # Expõe a confirmação conservada no resumo histórico do ciclo.
    def encerramento_confirmado(self):
        return True


# Serializa a reserva de ciclos e conserva histórico por ID para consultas de contextos antigos.
class ControleCicloServidor:
    # Começa sem ciclo ativo e mantém um histórico local por identidade crescente.
    def __init__(self):
        self.lock = threading.Lock()
        self.registro_atual = None
        self.estado = "livre"
        self.ultimo_ciclo_id = 0
        self.ciclo_id = None
        self._historico = {}

    # Reserva novo ciclo somente quando o anterior permite a passagem e atribui um ID crescente.
    def tentar_iniciar(self, registro):
        with self.lock:
            if self.estado == "executando":
                return False
            if self.estado == "pendente":
                if not self._situacao_historica_sob_lock(self.ciclo_id)["encerramento_confirmado"]:
                    return False
            self.ultimo_ciclo_id += 1
            self.ciclo_id = self.ultimo_ciclo_id
            registro.ciclo_id = self.ciclo_id
            self.registro_atual = registro
            self._historico[self.ciclo_id] = _EntradaHistoricoCiclo(self.ciclo_id, registro)
            self.estado = "executando"
            return True

    # Finaliza somente o registro correspondente e conserva estado pendente quando faltam evidências de término.
    def finalizar(self, registro):
        with self.lock:
            ciclo_id = getattr(registro, "ciclo_id", None)
            entrada = self._historico.get(ciclo_id)
            if not isinstance(entrada, _EntradaHistoricoCiclo):
                return False
            if entrada.registro is not registro or entrada.coordenador_finalizado:
                return False
            with registro.lock:
                # Todas as leituras potencialmente falhas precedem o commit.
                confirmado = (
                    registro.criacao_bloqueada
                    and not any(thread.is_alive() for thread in registro.threads)
                    and not registro.erros_limpeza
                    and registro._sockets_encerrados_sob_lock()
                )
                registro.publicacao_limpeza_concluida = True
                entrada.coordenador_finalizado = True
                if self.registro_atual is registro and self.ciclo_id == ciclo_id:
                    self.estado = "livre" if confirmado else "pendente"
            return True

    # Obtém a situação histórica de um ID com o lock do controle já adquirido.
    def _situacao_historica_sob_lock(self, ciclo_id):
        entrada = self._historico.get(ciclo_id)
        if entrada is None:
            return {"ciclo_id": ciclo_id, "estado": "desconhecido", "encerramento_confirmado": None}
        if isinstance(entrada, _ResumoHistoricoCiclo):
            return {
                "ciclo_id": ciclo_id, "estado": "confirmado",
                "coordenador_finalizado": True, "publicacao_limpeza_concluida": True,
                "criacao_bloqueada": True, "threads_vivas": (),
                "erros_limpeza": (), "encerramento_confirmado": True,
            }
        registro = entrada.registro
        with registro.lock:
            vivos = tuple(thread.name for thread in registro.threads if thread.is_alive())
            erros = tuple("falha_limpeza" for _ in registro.erros_limpeza)
            bloqueada = registro.criacao_bloqueada
            publicada = registro.publicacao_limpeza_concluida
            finalizado = entrada.coordenador_finalizado
            confirmado = (finalizado and publicada and bloqueada and not vivos and not erros
                          and registro._sockets_encerrados_sob_lock())
            return {
                "ciclo_id": ciclo_id,
                "estado": "confirmado" if confirmado else "pendente" if finalizado else "executando",
                "coordenador_finalizado": finalizado, "publicacao_limpeza_concluida": publicada,
                "criacao_bloqueada": bloqueada, "threads_vivas": vivos,
                "erros_limpeza": erros, "encerramento_confirmado": bool(confirmado),
            }

    # Protege com lock a leitura do histórico para consumidores externos ao controle.
    def _obter_situacao_historica(self, ciclo_id):
        with self.lock:
            return self._situacao_historica_sob_lock(ciclo_id)

    # Troca o registro histórico completo por um resumo quando o estado permite essa redução.
    def _compactar_ciclo(self, ciclo_id):
        with self.lock:
            entrada = self._historico.get(ciclo_id)
            if entrada is None:
                return False
            if isinstance(entrada, _ResumoHistoricoCiclo):
                return True
            if not self._situacao_historica_sob_lock(ciclo_id)["encerramento_confirmado"]:
                return False
            resumo = _ResumoHistoricoCiclo(ciclo_id)
            if self.registro_atual is entrada.registro:
                self.registro_atual = resumo
            self._historico[ciclo_id] = resumo
            return True


controle_ciclo_servidor = ControleCicloServidor()


# Valida a sessão, reserva um ciclo e coordena TCP, UDP, leitura HTTP e limpeza, inclusive na partida parcial.
def iniciar_servidor(web, evento_inicializacao=None, contexto_ciclo=None):
    """
    Inicia o servidor usando uma sessão WebTC420 JÁ autenticada.

    A criação e o login da sessão são responsabilidade da
    interface (interface/conexao.py). O servidor NUNCA executa
    login, garantindo um único token HTTP na máquina principal.

    Quem chama deve rodar esta função em uma thread, pois ela
    permanece ativa enquanto o servidor estiver no ar.
    """
    falha_coordenador = None
    limpeza_iniciada = False
    try:
        try:
            registro_trabalhadores = RegistroTrabalhadores()

            parada_aplicacao = getattr(contexto_ciclo, 'parada_aplicacao', None)
            cancelada = getattr(contexto_ciclo, 'cancelar_partida', None)
            if ((parada_aplicacao is not None and parada_aplicacao.is_set())
                    or (cancelada is not None and cancelada.is_set())):
                if contexto_ciclo is not None:
                    contexto_ciclo.registrar_falha('falha_antes_reserva')
                return
            if web is None or getattr(web, "token", None) is None:
                if contexto_ciclo is not None:
                    contexto_ciclo.registrar_falha("sessao_invalida")
                print(
                    "Sessão WebTC420 não autenticada. "
                    "Chame iniciar_servidor(web) com a sessão "
                    "criada em interface/conexao.py."
                )
                return

            if not controle_ciclo_servidor.tentar_iniciar(registro_trabalhadores):
                if contexto_ciclo is not None:
                    contexto_ciclo.registrar_falha("reserva_recusada")
                raise RuntimeError(
                    "SERVIDOR: inicialização recusada; "
                    "existe um ciclo ativo ou pendente."
                )
        except BaseException:
            if contexto_ciclo is not None:
                contexto_ciclo.registrar_falha("falha_antes_reserva")
            raise

        limpeza_iniciada = False
        try:
            if contexto_ciclo is not None:
                contexto_ciclo.registrar_reserva(registro_trabalhadores.ciclo_id)
                registro_trabalhadores.contexto_prontidao = contexto_ciclo
            with lock_saude:
                saude_tc420.update(saudavel=False, falhas_consecutivas=0,
                                   ultimo_sucesso=None, ultimo_erro=None,
                                   inicio_indisponibilidade=None)
            evento_parada_servidor.clear()
            if ((parada_aplicacao is not None and parada_aplicacao.is_set())
                    or (cancelada is not None and cancelada.is_set())):
                evento_parada_servidor.set()
                return
            if evento_inicializacao is not None:
                evento_inicializacao.set()
            print("=== SERVIDOR TC420 ===")

            thread_tcp = threading.Thread(
                target=servidor_tcp,
                kwargs={"registro_trabalhadores": registro_trabalhadores},
                daemon=True,
            )
            thread_udp = threading.Thread(
                target=servidor_descoberta,
                kwargs={"registro_trabalhadores": registro_trabalhadores},
                daemon=True,
            )

            # ---------------------------------------------
            # Fonte única de dados: esta é a ÚNICA rotina
            # que consulta a TC420 e alimenta 'dados_atuais'.
            # Os clientes apenas copiam o estado já existente.
            # ---------------------------------------------
            thread_dados = threading.Thread(
                target=ler_tc420,
                args=(web,),
                kwargs={"contexto_ciclo": contexto_ciclo},
                daemon=True,
            )
            if contexto_ciclo is not None:
                contexto_ciclo.trabalhadores_prontidao = (thread_tcp, thread_udp, thread_dados)

            principais_iniciados = []
            for trabalhador in (thread_tcp, thread_udp, thread_dados):
                if registro_trabalhadores.registrar_e_iniciar(trabalhador):
                    principais_iniciados.append(trabalhador)

            try:
                while not evento_parada_servidor.is_set():
                    for trabalhador in principais_iniciados:
                        trabalhador.join(timeout=1)

            except KeyboardInterrupt:
                print("\nServidor encerrado.")
                solicitar_parada_servidor()

            limpeza_iniciada = True
            registro_trabalhadores.bloquear_criacao()
            for trabalhador in principais_iniciados:
                trabalhador.join(timeout=2)
            registro_trabalhadores.limpar_sockets()
            situacao = registro_trabalhadores.obter_situacao()
            print(
                "SERVIDOR: trabalhadores principais restantes:",
                situacao["threads_vivas"],
            )
            print("Servidor TC420 encerrado.")
        except Exception as erro_original:
            if limpeza_iniciada:
                registro_trabalhadores.registrar_erro_limpeza(erro_original)
            for operacao in (
                registro_trabalhadores.bloquear_criacao,
                solicitar_parada_servidor,
            ):
                try:
                    operacao()
                except Exception as erro_limpeza:
                    falha_coordenador = "falha_limpeza"
                    registro_trabalhadores.registrar_erro_limpeza(erro_limpeza)

            with registro_trabalhadores.lock:
                trabalhadores_iniciados = list(registro_trabalhadores.threads)
            prazo_limpeza = time.monotonic() + 2
            for trabalhador in trabalhadores_iniciados:
                if trabalhador is threading.current_thread():
                    registro_trabalhadores.registrar_erro_limpeza(
                        "SERVIDOR: limpeza recusou join da thread atual."
                    )
                    continue
                try:
                    trabalhador.join(timeout=max(0, prazo_limpeza - time.monotonic()))
                except Exception as erro_limpeza:
                    falha_coordenador = "falha_limpeza"
                    registro_trabalhadores.registrar_erro_limpeza(erro_limpeza)
            try:
                registro_trabalhadores.limpar_sockets()
                situacao = registro_trabalhadores.obter_situacao()
                print("SERVIDOR: recuperação de falha de inicialização:", situacao)
            except Exception as erro_limpeza:
                falha_coordenador = "falha_limpeza"
                registro_trabalhadores.registrar_erro_limpeza(erro_limpeza)
            raise
        finally:
            erro_ativo = sys.exc_info()[1]
            try:
                try:
                    try:
                        registro_trabalhadores.bloquear_criacao()
                    except Exception as erro_limpeza:
                        falha_coordenador = "falha_limpeza"
                        registro_trabalhadores.registrar_erro_limpeza(erro_limpeza)
                finally:
                    controle_ciclo_servidor.finalizar(registro_trabalhadores)
            except BaseException:
                falha_coordenador = "falha_limpeza"
                try:
                    registro_trabalhadores.registrar_erro_limpeza("falha_finalizacao")
                except BaseException:
                    pass
                if erro_ativo is None:
                    raise
    except BaseException:
        if falha_coordenador is None:
            falha_coordenador = "falha_limpeza" if limpeza_iniciada else "falha_execucao"
        raise
    finally:
        if contexto_ciclo is not None:
            erro_ativo = sys.exc_info()[1]
            try:
                contexto_ciclo.registrar_retorno_coordenador(falha_coordenador)
            except BaseException:
                if erro_ativo is None:
                    raise



if __name__ == "__main__":
    print(
        "Este servidor não faz login e não pede usuário/senha.\n"
        "Ele deve ser iniciado pela interface, recebendo a\n"
        "sessão WebTC420 já autenticada:\n"
        "\n"
        "    from rede.servidor import iniciar_servidor\n"
        "    iniciar_servidor(web)\n"
    )

# SUBSCRIBE: acompanha as tentativas de assinatura e a resolução da sua limpeza.
"""Tentativa SUBSCRIBE por geração, separada da thread e dos recursos de IO."""
from dataclasses import dataclass
from threading import Lock, get_ident

from rede.infraestrutura_cliente import RecursosLeitorCliente, SocketClienteRegistrado


@dataclass(frozen=True, eq=False)
class TentativaSubscribeId:
    numero: int


class AdmissaoSubscribeCliente:
    def __init__(self, autoridade):
        self._autoridade = autoridade
        self._lock = autoridade._lock
        self._registro = autoridade._registro
        self._aplicacao_id = autoridade._aplicacao_id
        self._geracao_id = autoridade._geracao_id
        self._atividade_id = autoridade._atividade_id
        self._geracao = autoridade._geracao
        self._sequencia = 0
        self._tentativas = {}
        self._lock_publicacoes = Lock()
        self._publicacoes_pendentes = {}

    def admitir(self):
        with self._lock:
            if self._autoridade._fechada:
                return None
            self._sequencia += 1
            identidade = TentativaSubscribeId(self._sequencia)
            self._tentativas[identidade] = {
                'tipo': 'inicial' if identidade.numero == 1 else 'reconexao',
                'iniciada': False, 'em_curso': False, 'thread': None,
                'retorno': False, 'finalizacao_tentada': False,
                'erro_operacao': None, 'erro_publicacao': False,
                'erro_associacao': False, 'dono': None,
            }
            return identidade

    def _buscar(self, identidade):
        if type(identidade) is not TentativaSubscribeId or identidade not in self._tentativas:
            raise ValueError('tentativa_subscribe_estrangeira')
        return self._tentativas[identidade]

    def iniciar(self, identidade):
        with self._lock:
            item = self._buscar(identidade)
            if item['iniciada'] or item['finalizacao_tentada']:
                raise RuntimeError('subscribe_ja_iniciado')
            item.update(iniciada=True, em_curso=True, thread=get_ident())
        dono = None if self._registro is None else RecursosSubscribeCliente(self, identidade)
        with self._lock:
            item['dono'] = dono
        return dono

    def _validar_execucao(self, identidade):
        with self._lock:
            item = self._buscar(identidade)
            if not item['em_curso'] or item['thread'] != get_ident():
                raise RuntimeError('subscribe_fora_da_execucao_admitida')

    @staticmethod
    def _erro(erro):
        return None if erro is None else {'categoria': (
            'falha_io' if isinstance(erro, OSError) else
            'falha_operacao' if isinstance(erro, Exception) else 'falha_base')}

    def _publicar_saida(self, identidade, erro):
        with self._lock:
            item = self._buscar(identidade)
            item['erro_operacao'] = self._erro(erro)
            item['retorno'] = True

    def finalizar(self, identidade, original=None):
        with self._lock:
            item = self._buscar(identidade)
            if item['finalizacao_tentada']:
                return
            item['finalizacao_tentada'] = True
            item['erro_operacao'] = self._erro(original)
        try:
            self._publicar_saida(identidade, original)
        except BaseException as publicacao:
            with self._lock:
                item['erro_publicacao'] = True
                item['retorno'] = False
            if original is None:
                raise
            original.__cause__ = publicacao
            original.__suppress_context__ = True
        finally:
            with self._lock:
                item['em_curso'] = False

    def obter_retrato(self):
        with self._lock:
            itens = [(chave, item.copy()) for chave, item in self._tentativas.items()]
            fechada = self._autoridade._fechada
        estados = {} if self._registro is None else {
            r['recurso_id']: r for r in self._registro.obter_retrato()['recursos']}
        tentativas = []
        for chave, item in itens:
            vinculos = [] if item['dono'] is None else item['dono'].obter_vinculos()
            recursos = [{'recurso_id': token.numero, 'tipo': tipo,
                         'associacao_publicada': publicado,
                         'limpeza_confirmada': estados.get(token.numero, {}).get('encerramento_confirmado', False)}
                        for token, tipo, publicado in vinculos]
            resolvida = (self._registro is not None and item['retorno'] and not item['em_curso']
                and not item['erro_publicacao'] and not item['erro_associacao']
                and all(r['associacao_publicada'] and r['limpeza_confirmada'] for r in recursos))
            tentativas.append({
                'tentativa_id': chave.numero,
                **{nome: item[nome] for nome in ('tipo', 'iniciada', 'em_curso', 'retorno',
                    'erro_publicacao', 'erro_associacao')},
                'erro_operacao': None if item['erro_operacao'] is None else item['erro_operacao'].copy(),
                'recursos': recursos, 'responsabilidade_resolvida': bool(resolvida),
            })
        return {'aplicacao_id': self._aplicacao_id, 'geracao_id': self._geracao_id,
                'atividade_recursos_id': self._atividade_id, 'admissao_fechada': fechada,
                'tentativas': tentativas, 'cobertura_operacional': 'incompleta',
                'encerramento_global_confirmado': False}


class RecursosSubscribeCliente(RecursosLeitorCliente):
    def __init__(self, controle, identidade):
        self._controle, self._identidade = controle, identidade
        self.registro, self.geracao_id = controle._registro, controle._geracao_id
        self.atividade_id = controle._atividade_id
        self._geracao_retentativas = controle._geracao
        self._lock_publicacoes = controle._lock_publicacoes
        self._publicacoes_pendentes = controle._publicacoes_pendentes
        self._lock_vinculos = Lock()
        self._emitidos = {}

    def _criar(self, tipo, fabrica, *, associado_a=None):
        return super()._criar(tipo, fabrica, associado_a=associado_a,
                              _preservar_erro_ausencia=True)

    def abrir_socket(self, fabrica):
        self._controle._validar_execucao(self._identidade)
        if isinstance(fabrica, SocketClienteRegistrado):
            with self._lock_vinculos:
                if fabrica.dono is not self or fabrica.recurso_id not in self._emitidos:
                    raise ValueError('socket_de_outra_tentativa_subscribe')
        return super().abrir_socket(fabrica)

    def _publicar_vinculo(self, token, tipo):
        with self._lock_vinculos:
            self._emitidos[token] = (tipo, True)

    def _reservar_recurso(self, tipo, associado_a):
        self._controle._validar_execucao(self._identidade)
        token = super()._reservar_recurso(tipo, associado_a)
        if token is None:
            return None
        try:
            with self._lock_vinculos:
                self._emitidos[token] = (tipo, False)
            self._publicar_vinculo(token, tipo)
        except BaseException as original:
            with self._controle._lock:
                self._controle._buscar(self._identidade)['erro_associacao'] = True
            try:
                self.registro.comprovar_ausencia(token, nao_alocado=True)
            except BaseException as prova:
                original.__cause__ = prova
                original.__suppress_context__ = True
            raise
        return token

    def obter_vinculos(self):
        with self._lock_vinculos:
            return [(token, tipo, publicado) for token, (tipo, publicado) in self._emitidos.items()]

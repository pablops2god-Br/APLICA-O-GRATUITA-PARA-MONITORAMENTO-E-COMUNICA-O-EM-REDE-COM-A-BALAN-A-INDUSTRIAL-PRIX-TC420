# CHECK: controla a admissão das confirmações TCP secundárias da descoberta.
"""Admissão individual de CHECK; rede e evidências fora do lock da autoridade."""
from contextlib import contextmanager
from contextvars import ContextVar
from threading import Lock

from rede.infraestrutura_cliente import RecursosLeitorCliente
from rede.buscarservidor import CheckRecusado


class AdmissaoChecksCliente:
    def __init__(self, *, leitor=None, recuperacao=None):
        if (leitor is None) == (recuperacao is None):
            raise ValueError('autoridade_check_invalida')
        self._leitor = leitor
        self._recuperacao = recuperacao
        self._lock = Lock() if leitor is None else leitor._lock
        self._udp = ContextVar('origem_udp_check', default=None)
        self._sequencia = 0
        self._tentativas = {}

    @contextmanager
    def descoberta(self, recurso_id):
        contexto = self._udp.set(recurso_id)
        try:
            yield
        finally:
            self._udp.reset(contexto)

    def admitir(self, recursos):
        secundaria = None
        if self._recuperacao is not None:
            # Esta reserva é a decisão atômica da autoridade AC2-C existente.
            secundaria = self._recuperacao._acompanhamento._guarda.reservar_secundaria(
                self._recuperacao._identidade, 'socket')
            if secundaria is None:
                return None
        with self._lock:
            if self._leitor is not None and self._leitor._fechada:
                return None
            self._sequencia += 1
            identidade = self._sequencia
            self._tentativas[identidade] = {
                'secundaria': secundaria, 'origem': recursos,
                'secundaria_resolvida': secundaria is None,
                'descoberta_udp_id': self._udp.get(),
                'descoberta_inicial_id': getattr(recursos, '_descoberta_inicial_id', None),
                'em_curso': False, 'retorno': False, 'resultado': None,
                'erro_operacao': None, 'erro_publicacao': False,
                'erro_associacao': False, 'dono': None,
            }
            return identidade

    def _publicar_saida(self, identidade, resultado, erro):
        with self._lock:
            item = self._tentativas[identidade]
            item['resultado'] = resultado
            item['erro_operacao'] = self._erro(erro)
            item['retorno'] = True

    @staticmethod
    def _erro(erro):
        return None if erro is None else {
            'categoria': 'falha_io' if isinstance(erro, OSError) else 'falha_operacao'}

    def _publicar_preservando(self, identidade, resultado, original):
        with self._lock:
            self._tentativas[identidade]['erro_operacao'] = self._erro(original)
        try:
            self._publicar_saida(identidade, resultado, original)
        except BaseException as publicacao:
            with self._lock:
                item = self._tentativas[identidade]
                item['retorno'] = False
                item['erro_publicacao'] = True
            if original is None:
                raise
            original.__cause__ = publicacao
            original.__suppress_context__ = True

    def executar(self, recursos, fabrica=None, operacao=None, *, legado=None):
        identidade = self.admitir(recursos)
        if identidade is None:
            raise CheckRecusado()
        with self._lock:
            item = self._tentativas[identidade]
            item['em_curso'] = True
        erro_primario = None
        try:
            try:
                dono = None if recursos is None else RecursosCheckCliente(self, identidade, recursos)
                with self._lock:
                    item['dono'] = dono
                resultado = legado() if dono is None else dono.executar_descoberta(
                    'socket_tcp', fabrica, operacao)
            except BaseException as original:
                erro_primario = original
                self._publicar_preservando(identidade, None, original)
                raise
            else:
                self._publicar_preservando(identidade, resultado, None)
        finally:
            with self._lock:
                item['em_curso'] = False
                estado = item.copy()
            # Prova secundária é ação explícita; consultar nunca a publica.
            if estado['secundaria'] is not None:
                try:
                    if self._retrato(identidade, estado)['responsabilidade_recursos_resolvida']:
                        prova = self._recuperacao._acompanhamento._guarda.resolver_secundaria(
                            estado['secundaria'], responsabilidades_resolvidas=True)
                        if prova is not True:
                            raise RuntimeError('publicacao_secundaria_check_nao_confirmada')
                        with self._lock:
                            item['secundaria_resolvida'] = True
                except BaseException as publicacao:
                    with self._lock:
                        item['erro_publicacao'] = True
                    if erro_primario is None:
                        raise
                    erro_primario.__cause__ = publicacao
                    erro_primario.__suppress_context__ = True
        return resultado

    def _retrato(self, identidade, item):
        origem, dono = item['origem'], item['dono']
        estados = {} if origem is None else {
            r['recurso_id']: r for r in origem.registro.obter_retrato()['recursos']}
        vinculos = [] if dono is None else dono.obter_vinculos()
        recursos = [{'recurso_id': token.numero, 'tipo': 'socket_tcp',
                     'associacao_publicada': publicado,
                     'limpeza_confirmada': estados.get(token.numero, {}).get('encerramento_confirmado', False)}
                    for token, publicado in vinculos]
        leitor = self._leitor
        recuperacao = self._recuperacao
        aplicacao = (leitor._aplicacao_id if leitor is not None else
                     recuperacao._acompanhamento._proprietario.aplicacao_id)
        geracao = leitor._geracao_id if leitor is not None else recuperacao.geracao_id
        recursos_resolvidos = bool(origem is not None and item['retorno']
            and not item['em_curso'] and not item['erro_publicacao'] and not item['erro_associacao']
            and all(r['associacao_publicada'] and r['limpeza_confirmada'] for r in recursos))
        return {
            'check_id': identidade, 'aplicacao_id': aplicacao, 'geracao_id': geracao,
            'origem': 'leitor_permanente' if leitor is not None else 'recuperacao',
            'retentativa_id': None if recuperacao is None else recuperacao._identidade.numero,
            'autorizacao_secundaria_id': None if item['secundaria'] is None else item['secundaria'].numero,
            'autorizacao_secundaria_resolvida': item['secundaria_resolvida'],
            **{nome: item[nome] for nome in ('descoberta_udp_id', 'descoberta_inicial_id',
               'em_curso', 'retorno', 'resultado', 'erro_publicacao', 'erro_associacao')},
            'erro_operacao': None if item['erro_operacao'] is None else item['erro_operacao'].copy(),
            'recursos': recursos,
            'responsabilidade_recursos_resolvida': recursos_resolvidos,
            'responsabilidade_resolvida': recursos_resolvidos and item['secundaria_resolvida'],
        }

    def obter_retrato(self):
        with self._lock:
            itens = [(chave, item.copy()) for chave, item in self._tentativas.items()]
        return [self._retrato(chave, item) for chave, item in itens]


class RecursosCheckCliente(RecursosLeitorCliente):
    """Delega a reserva ao dono original, preservando vínculos AC2-C/AC3-C4."""
    def __init__(self, controle, identidade, origem):
        self._controle, self._identidade, self._origem = controle, identidade, origem
        self.registro, self.geracao_id = origem.registro, origem.geracao_id
        self.atividade_id = origem.atividade_id
        self._geracao_retentativas = origem._geracao_retentativas
        self._lock_publicacoes = origem._lock_publicacoes
        self._publicacoes_pendentes = origem._publicacoes_pendentes
        self._lock_vinculos = Lock()
        self._emitidos = {}

    def _publicar_vinculo(self, token):
        with self._lock_vinculos:
            self._emitidos[token] = True

    def _reservar_recurso(self, tipo, associado_a):
        token = self._origem._reservar_recurso(tipo, associado_a)
        if token is None:
            return None
        try:
            with self._lock_vinculos:
                self._emitidos[token] = False
            self._publicar_vinculo(token)
        except BaseException as original:
            with self._controle._lock:
                self._controle._tentativas[self._identidade]['erro_associacao'] = True
            try:
                self.registro.comprovar_ausencia(token, nao_alocado=True)
            except BaseException as prova:
                original.__cause__ = prova
                original.__suppress_context__ = True
            raise
        return token

    def obter_vinculos(self):
        with self._lock_vinculos:
            return list(self._emitidos.items())

# Entradas HTTP: valida a identidade da instalação recebida pelo caminho operacional.
"""Montagem de entradas com referência externa à instalação HTTP apresentada.

Não cria proprietário, registro ou autorização de requisição. O bootstrap é
main.iniciar; ferramentas isoladas podem montar explicitamente seu próprio vínculo.
"""
from dataclasses import dataclass, field

from rede.infraestrutura_cliente import exigir_infraestrutura_http, InfraestruturaHttpInvalida


# Captura referências da instalação para detectar troca da infraestrutura entre montagem e chamada.
@dataclass(frozen=True, init=False, eq=False, repr=False, slots=True)
class VinculoEntradasHttp:
    _infraestrutura: object = field(repr=False)
    _instalacao: object = field(repr=False)
    _contexto: object = field(repr=False)
    _http: object = field(repr=False)
    _recursos: object = field(repr=False)
    _retentativas: object = field(repr=False)
    _aplicacao_id: str = field(repr=False)

    # Valida e fixa as referências do dono e dos registros que pertencem à mesma instalação HTTP.
    def __init__(self, infraestrutura):
        exigir_infraestrutura_http(infraestrutura)
        if hasattr(self, "_infraestrutura"):
            raise InfraestruturaHttpInvalida("vinculo_http_ja_estabelecido")
        for nome, valor in (
                ("_infraestrutura", infraestrutura), ("_instalacao", infraestrutura._instalacao),
                ("_contexto", infraestrutura._contexto), ("_http", infraestrutura.registro_http),
                ("_recursos", infraestrutura.registro_recursos),
                ("_retentativas", infraestrutura.registro_retentativas),
                ("_aplicacao_id", infraestrutura.aplicacao_id)):
            object.__setattr__(self, nome, valor)

    # Exige a mesma instância e os mesmos registros capturados antes de permitir a entrada operacional.
    def validar(self, apresentada):
        if apresentada is not self._infraestrutura:
            raise InfraestruturaHttpInvalida("infraestrutura_http_estrangeira")
        exigir_infraestrutura_http(apresentada)
        if (apresentada._instalacao is not self._instalacao
                or apresentada._contexto is not self._contexto
                or apresentada.registro_http is not self._http
                or apresentada.registro_recursos is not self._recursos
                or apresentada.registro_retentativas is not self._retentativas
                or apresentada.aplicacao_id != self._aplicacao_id
                or self._http.proprietario is not self._infraestrutura):
            raise InfraestruturaHttpInvalida("instalacao_http_substituida")
        return apresentada

    # Envolve uma entrada com uma closure que injeta o vínculo criado na montagem.
    def vincular(self, entrada):
        # A autoridade fica na closure, não num argumento que o chamador possa
        # substituir junto com a infraestrutura apresentada.
        # Acrescenta o vínculo capturado e encaminha os demais argumentos à entrada original.
        def vinculada(*args, **kwargs):
            kwargs["vinculo_http"] = self
            return entrada(*args, **kwargs)
        return vinculada


# Escolhe validação isolada explícita ou validação do vínculo; valores inválidos produzem recusa.
def criar_validador_entrada(vinculo_http=False):
    """False é construção isolada explícita; None/inválido nunca vira isolado."""
    if vinculo_http is False:
        return exigir_infraestrutura_http
    if type(vinculo_http) is VinculoEntradasHttp:
        return vinculo_http.validar

    # Rejeita uma entrada que não apresentou um vínculo válido, sem criar uma instalação substituta.
    def recusar(_apresentada):
        raise InfraestruturaHttpInvalida("vinculo_http_ausente_ou_invalido")
    return recusar

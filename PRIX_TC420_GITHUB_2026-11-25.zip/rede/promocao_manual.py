"""Promoção recuperada: fila configurada, worker B2 e prontidão por ciclo."""
from threading import Event, Thread
from time import monotonic

from rede import servidor
from rede.buscarservidor import buscar_servidor
from tc420.web import WebTC420


def tentar_recuperacao_automatica(supervisao):
    """Após a fila liberar: usa só a opção/credencial já salvas, senão formulário."""
    from config.configuracao import carregar_configuracao, carregar_senha
    from config.arquivos import ContextoArquivosConfiguracao
    if not supervisao.vigente() or not supervisao.saida.ciclos_aptos_promocao():
        return False
    leitor = supervisao.obter_leitor()
    if (leitor is None or not leitor.permitir_candidatura
            or not leitor.candidatura_esta_liberada()):
        return False
    contexto = ContextoArquivosConfiguracao(supervisao.infraestrutura)
    config = carregar_configuracao(contexto_arquivos=contexto)
    if not isinstance(config, dict) or not config.get('salvar_login', False):
        return False
    ip, usuario = config.get('ip'), config.get('usuario')
    if not ip or not usuario:
        return False
    senha = carregar_senha(usuario)
    if not senha:
        return False
    return promover_recuperado(supervisao, ip, usuario, senha)


def operacao_vigente(saida):
    from interface.ciclo_tk import operacao_worker
    operacao = operacao_worker.get()
    return (not saida.parada_solicitada and
            (operacao is None or operacao.permite(saida, saida.identidade_interface)))


def aguardar_prontidao(contexto, saida, prazo=15):
    """Worker apenas: bind TCP/UDP, amostra deste ciclo e workers ainda vivos."""
    limite = monotonic() + prazo
    while operacao_vigente(saida) and not contexto.coordenador_retornou.is_set():
        trabalhadores = contexto.trabalhadores_prontidao
        if (contexto.tcp_pronto.is_set() and contexto.udp_pronto.is_set()
                and contexto.dados_prontos.is_set() and len(trabalhadores) == 3
                and contexto.ultimo_dado_monotonico is not None
                and 0 <= monotonic() - contexto.ultimo_dado_monotonico <= 6
                and all(t.is_alive() for t in trabalhadores)
                and servidor.obter_saude_tc420()['saudavel'] is True
                and not servidor.servidor_deve_parar()):
            return True
        if monotonic() >= limite:
            break
        Event().wait(.05)
    return False


def interromper_tentativa(contexto):
    # ID original e sinal persistente: inclui partida que ainda não reservou ciclo.
    contexto.cancelar_partida.set()
    ciclo = contexto.obter_situacao()['ciclo_id']
    if ciclo is not None:
        servidor.solicitar_parada_ciclo(ciclo)


def cliente_resolvido(infra):
    """Após parar leitores: exige provas individuais, sem fechar a aplicação."""
    infra.observar_termino_leitores()
    infra.observar_termino_retentativas()
    retrato = infra.avaliar_responsabilidades_cliente()
    return (retrato['leituras_revalidadas'] is True
            and retrato['responsabilidades_conhecidas_resolvidas'] is True
            and not retrato['retencoes_pendentes']
            and all(a['termino_confirmado'] is True for a in retrato['atividades_permanentes'])
            and all(a['responsabilidade_resolvida'] is True for a in retrato['admissoes'])
            and all(a['responsabilidade_resolvida'] is True for a in retrato['autorizacoes_secundarias'])
            and all(r['encerramento_confirmado'] is True and not r['erros_limpeza']
                    and not r['erros_evidencia'] for r in infra.registro_recursos.obter_retrato()['recursos']))


def promover_recuperado(supervisao, ip, usuario, senha):
    """Nunca chamado automaticamente. Usa o leitor publicado por esta supervisão."""
    saida, infra = supervisao.saida, supervisao.infraestrutura
    contexto, tentativa, start_solicitado, sucesso = None, None, False, False
    leitor_suspenso = False
    print('PROMOCAO: recuperação solicitada; verificando ciclos e admissão.')
    try:
        with saida.promocao():
            if not supervisao.vigente() or infra is None:
                print('PROMOCAO: recusada; supervisão encerrada ou infraestrutura indisponível.')
                return None
            leitor = supervisao.obter_leitor()
            if leitor is None or leitor.comunicacao_esta_atual():
                print('PROMOCAO: recusada; CLIENTE conectado ou leitor indisponível.')
                return None
            # Suspende todos os leitores conhecidos, incluindo o leitor pré-promoção.
            with saida._lock:
                leitores = tuple(saida._leitores)
            leitor_suspenso = True
            for anterior in leitores:
                anterior.parar()
            limite = monotonic() + 8
            for anterior in leitores:
                if anterior.thread is not None:
                    anterior.thread.join(max(0, limite - monotonic()))
            if not cliente_resolvido(infra) or not operacao_vigente(saida):
                print('PROMOCAO: recusada; responsabilidades CLIENTE pendentes.')
                return None
            if buscar_servidor(infraestrutura_cliente=infra, estrito=True):
                print('PROMOCAO: recusada; outro PRINCIPAL identificado.')
                return None
            print('PROMOCAO: verificando login, configuração e leitura da TC420.')
            web = WebTC420(ip, politica_http=infra.criar_politica_http())
            origem_http = infra.preparar_http_promocao(leitor.recursos_cliente)
            infra.executar_login_promocao(leitor.recursos_cliente, web, usuario, senha,
                                         contexto_http=origem_http)
            configuracao = infra.executar_approval(origem_http, web)
            # Consulta real da fonte antes de reservar/start; não anuncia sucesso por login.
            web.obter_estado()
            if not operacao_vigente(saida):
                print('PROMOCAO: interrompida; operação cancelada ou saída solicitada após acesso à fonte.')
                return None
            if not saida.ciclos_aptos_promocao():
                print('PROMOCAO: recusada; ciclos anteriores pendentes após acesso à fonte.')
                return None
            if not cliente_resolvido(infra):
                print('PROMOCAO: recusada; responsabilidades CLIENTE pendentes após acesso à fonte.')
                return None
            if buscar_servidor(infraestrutura_cliente=infra, estrito=True):
                print('PROMOCAO: recusada; PRINCIPAL apareceu durante a tentativa.')
                return None
            if not operacao_vigente(saida):
                print('PROMOCAO: interrompida; operação cancelada ou saída solicitada antes da partida.')
                return None
            contexto = servidor.ContextoCicloServidor()
            saida.acompanhar_contexto(contexto)
            registro = saida._registro
            if registro is None:
                print('PROMOCAO: recusada; registro de tentativas indisponível.')
                contexto.registrar_falha('falha_antes_reserva')
                contexto.registrar_retorno_coordenador()
                return None
            tentativa = registro.admitir(contexto)
            if tentativa is None or not registro.marcar_iniciando(tentativa):
                raise RuntimeError('admissao_promocao_recusada')
            servidor.definir_configuracao(configuracao)
            def executar():
                if registro.registrar_entrada_execucao(tentativa):
                    servidor.iniciar_servidor(web, contexto_ciclo=contexto)
            thread = Thread(target=executar, daemon=True)
            start_solicitado = True
            saida.iniciar_servidor_thread(thread, contexto, registro, tentativa)
            if not registro.marcar_iniciada(tentativa):
                raise RuntimeError('partida_nao_confirmada')
            print('PROMOCAO: partida solicitada; aguardando prontidão TCP/UDP e leitura TC420.')
            if not aguardar_prontidao(contexto, saida):
                interromper_tentativa(contexto)
                print('PROMOCAO: prontidão não comprovada; ciclo permanece acompanhado.')
                return None
            sucesso = True
            return dict(web=web, configuracao=configuracao,
                        fonte_dados=servidor.obter_dados_atuais,
                        obter_saude_principal=servidor.obter_saude_tc420,
                        contexto_ciclo=contexto)
    except Exception as erro:
        if contexto is not None:
            if not start_solicitado:
                contexto.registrar_falha('falha_antes_reserva')
                if tentativa is not None:
                    saida._registro.registrar_falha_partida(
                        tentativa, 'falha_criacao_thread', execucao_nao_iniciada=True)
                else:
                    contexto.registrar_retorno_coordenador()
            else:
                interromper_tentativa(contexto)
        motivos = {'promocao_ou_saida_em_curso', 'ciclo_anterior_pendente',
                   'encerramento_em_curso', 'admissao_promocao_recusada',
                   'partida_nao_confirmada'}
        motivo = (erro.args[0] if type(erro) is RuntimeError and len(erro.args) == 1
                  and type(erro.args[0]) is str and erro.args[0] in motivos
                  else type(erro).__name__)
        print('PROMOCAO: recusada:', motivo)
        return None
    finally:
        if leitor_suspenso and not sucesso and supervisao.vigente():
            supervisao.solicitar_retomada()

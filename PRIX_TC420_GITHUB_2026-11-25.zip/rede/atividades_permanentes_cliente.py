# Leitor permanente: separa admissão, partida, execução, retorno e observação de término.
"""Ciclo da thread permanente, separado de retentativas e de recursos.

Um registro por infraestrutura da aplicação. Fábrica, start, alvo e is_alive
sempre fora do lock. Consultar não observa término e não executa limpeza.
"""
from dataclasses import dataclass
from contextlib import contextmanager
from threading import Lock
from uuid import uuid4


@dataclass(frozen=True, eq=False)
class OrigemLeitor:
    geracao_id: int
    atividade_recursos_id: int


@dataclass(frozen=True, eq=False)
class AtividadePermanenteId:
    numero: int


class RegistroAtividadesPermanentesCliente:
    def __init__(self, proprietario):
        self._proprietario = proprietario
        self._lock = Lock()
        self._origens = set()
        # Retenção auxiliar por geração; não participa da prova de término.
        self._admissoes_register = {}
        self._atividades = {}
        self._sequencia = 0
        self._fechada = False
        self._fonte_id = uuid4().hex
        self._revisao = 0
        self._temporal_comprometida = False
        self._revisao_confiavel = True

    @property
    def fonte_id(self):
        return self._fonte_id

    def _estado_local(self):
        atividades = tuple((token, tuple((nome, id(valor) if nome == 'thread'
            else tuple(valor.items()) if type(valor) is dict else valor)
            for nome, valor in item.items())) for token, item in self._atividades.items())
        return (frozenset(self._origens),
                tuple((geracao, id(controle)) for geracao, controle in self._admissoes_register.items()),
                atividades, self._sequencia, self._fechada, self._temporal_comprometida)

    def _avancar_revisao(self):
        self._revisao += 1

    @staticmethod
    def _separar_falha(original, adicional):
        if original is not adicional:
            original.__cause__ = adicional
            original.__suppress_context__ = True

    @contextmanager
    def _publicacao_local(self, original=None):
        # Somente estado local, sob o lock anterior; nunca chamar a thread/controle.
        with self._lock:
            antes, anterior = self._estado_local(), self._revisao
            self._revisao_confiavel = False
            falha = None
            try:
                yield
            except BaseException as erro:
                falha = erro
                if original is None:
                    raise
                # Diagnostico adicional em um handler nao substitui o primario.
                self._temporal_comprometida = True
                self._separar_falha(original, erro)
            finally:
                try:
                    if antes != self._estado_local():
                        if falha is not None:
                            self._temporal_comprometida = True
                        self._avancar_revisao()
                        if self._revisao != anterior + 1:
                            raise RuntimeError('revisao_atividades_nao_publicada')
                    self._revisao_confiavel = not self._temporal_comprometida
                except BaseException as acompanhamento:
                    self._temporal_comprometida = True
                    self._revisao_confiavel = False
                    primario = falha if falha is not None else original
                    if primario is None:
                        raise
                    self._separar_falha(primario, acompanhamento)

    def _selo(self):
        return {'aplicacao_id': self._proprietario.aplicacao_id,
                'fonte_id': self._fonte_id, 'revisao': self._revisao,
                'confiavel': self._revisao_confiavel, 'escopo': 'estado_local_atividades_permanentes'}

    def obter_revisao(self):
        with self._lock:
            return self._selo()

    def obter_evidencia_temporal(self):
        with self._lock:
            return self._selo() | {'retrato': self._retrato_local(),
                'origens_preparadas': [{'geracao_id': geracao, 'atividade_recursos_id': atividade}
                    for geracao, atividade in sorted((o.geracao_id, o.atividade_recursos_id)
                                                    for o in self._origens)],
                'geracoes_register_retidas': sorted(self._admissoes_register),
                'dependencias_temporais_cobertas': False, 'snapshot_atomico': False,
                'cobertura_operacional': 'incompleta', 'encerramento_cliente_confirmado': False,
                'encerramento_global_confirmado': False}

    def preparar_leitor(self, recursos):
        from rede.infraestrutura_cliente import RecursosLeitorCliente
        if (type(recursos) is not RecursosLeitorCliente
                or recursos.registro is not self._proprietario.registro_recursos):
            raise ValueError('origem_leitor_estrangeira')
        origem = OrigemLeitor(recursos.geracao_id, recursos.atividade_id)
        with self._publicacao_local():
            self._origens.add(origem)
        return origem

    def reter_admissao_register(self, origem, controle):
        from rede.admissao_register_cliente import AdmissaoRegisterCliente
        if (type(controle) is not AdmissaoRegisterCliente
                or controle._registro is not self._proprietario.registro_recursos
                or controle._aplicacao_id != self._proprietario.aplicacao_id):
            raise ValueError('controle_register_estrangeiro')
        with self._publicacao_local():
            if (type(origem) is not OrigemLeitor or origem not in self._origens
                    or controle._geracao_id != origem.geracao_id
                    or controle._atividade_id != origem.atividade_recursos_id):
                raise ValueError('origem_register_invalida')
            anterior = self._admissoes_register.get(origem.geracao_id)
            if anterior is not None and anterior is not controle:
                raise ValueError('controle_register_duplicado')
            self._admissoes_register[origem.geracao_id] = controle

    def obter_controles_register(self):
        """Origens retidas, incluindo leitores antigos; sem observar/limpar."""
        with self._lock:
            return tuple(self._admissoes_register.values())

    def reservar(self, origem):
        with self._publicacao_local():
            if type(origem) is not OrigemLeitor or origem not in self._origens:
                raise ValueError('origem_leitor_invalida')
            if self._fechada:
                return None
            self._sequencia += 1
            identidade = AtividadePermanenteId(self._sequencia)
            self._atividades[identidade] = {
                'origem': origem, 'thread': None, 'reivindicada': False,
                'partida_em_curso': False, 'partida_resolvida': False,
                'start_invocado': False, 'partida_ambigua': False,
                'entrada': False, 'retorno': False, 'thread_terminada': False,
                'ausencia_comprovada': False, 'resultado_alvo': None,
                'erro_operacional': None, 'erro_partida': None,
                'erro_publicacao': False, 'erro_observacao': False,
            }
            return identidade

    def fechar_admissao(self):
        with self._publicacao_local():
            anterior = self._fechada
            self._fechada = True
            return not anterior

    def _buscar(self, identidade):
        if type(identidade) is not AtividadePermanenteId or identidade not in self._atividades:
            raise ValueError('atividade_permanente_invalida')
        return self._atividades[identidade]

    @staticmethod
    def _erro(erro):
        return {'categoria': ('falha_io' if isinstance(erro, OSError) else
                              'falha_operacao' if isinstance(erro, Exception) else 'falha_base')}

    def _publicar_entrada(self, identidade):
        with self._publicacao_local():
            item = self._buscar(identidade)
            if item['entrada'] or item['ausencia_comprovada']:
                self._temporal_comprometida = True
                item['erro_publicacao'] = True
                return False
            item['entrada'] = True
            return True

    def _publicar_saida(self, identidade, erro):
        with self._publicacao_local():
            item = self._buscar(identidade)
            item['resultado_alvo'] = 'falha' if erro is not None else 'retorno'
            item['erro_operacional'] = None if erro is None else self._erro(erro)
            item['retorno'] = True

    def _publicar_partida(self, identidade):
        with self._publicacao_local():
            item = self._buscar(identidade)
            item['partida_em_curso'] = False
            item['partida_resolvida'] = True

    def _invalidar(self, identidade, prova):
        with self._publicacao_local():
            self._temporal_comprometida = True
            item = self._buscar(identidade)
            item['erro_publicacao'] = True
            item[prova] = False
            if prova == 'partida_resolvida':
                item['partida_em_curso'] = False

    def _invalidar_preservando(self, identidade, prova, original):
        try:
            self._invalidar(identidade, prova)
        except BaseException as adicional:
            with self._lock:
                self._temporal_comprometida = True
                self._revisao_confiavel = False
            self._separar_falha(original, adicional)

    def _saida_preservando(self, identidade, original):
        if original is not None:
            with self._publicacao_local(original):
                self._buscar(identidade)['erro_operacional'] = self._erro(original)
        try:
            self._publicar_saida(identidade, original)
        except BaseException as publicacao:
            self._invalidar_preservando(identidade, 'retorno', publicacao)
            if original is None:
                raise
            self._separar_falha(original, publicacao)

    def partir(self, identidade, construir, rotina):
        if not callable(construir) or not callable(rotina):
            raise ValueError('executor_permanente_invalido')
        with self._publicacao_local():
            item = self._buscar(identidade)
            if item['reivindicada']:
                return False
            item['reivindicada'] = True
            if self._fechada:
                item['ausencia_comprovada'] = True
                item['partida_resolvida'] = True
                return False
            item['partida_em_curso'] = True

        def executar():
            try:
                if not self._publicar_entrada(identidade):
                    return
            except BaseException as original:
                self._invalidar_preservando(identidade, 'entrada', original)
                raise
            try:
                retorno = rotina()
            except BaseException as original:
                self._saida_preservando(identidade, original)
                raise
            else:
                self._saida_preservando(identidade, None)
                return retorno

        try:
            thread = construir(executar)
            with self._publicacao_local():
                item['thread'] = thread
                item['start_invocado'] = True
            thread.start()
        except BaseException as original:
            with self._publicacao_local(original):
                item['erro_partida'] = self._erro(original)
                item['partida_ambigua'] = item['start_invocado'] or item['entrada']
                item['ausencia_comprovada'] = not item['partida_ambigua']
            try:
                self._publicar_partida(identidade)
            except BaseException as publicacao:
                self._invalidar_preservando(identidade, 'partida_resolvida', publicacao)
                self._separar_falha(original, publicacao)
            raise
        else:
            try:
                self._publicar_partida(identidade)
            except BaseException as original:
                self._invalidar_preservando(identidade, 'partida_resolvida', original)
                raise
        return True

    def comprovar_nao_partida(self, identidade, *, nao_iniciada):
        """Prova do executor síncrono: nenhuma fábrica/start ficou em curso."""
        if nao_iniciada is not True:
            raise ValueError('nao_partida_sem_prova')
        with self._publicacao_local():
            item = self._buscar(identidade)
            if item['partida_em_curso'] or item['start_invocado'] or item['entrada']:
                return False
            item['reivindicada'] = True
            item['ausencia_comprovada'] = True
            item['partida_resolvida'] = True
            return True

    def observar_termino(self, identidade):
        with self._publicacao_local():
            item = self._buscar(identidade)
            if (not item['partida_resolvida'] or item['partida_em_curso']
                    or not item['entrada'] or not item['retorno'] or item['erro_publicacao']):
                return False
            thread = item['thread']
        try:
            viva = thread.is_alive()
            if type(viva) is not bool:
                raise ValueError('observacao_invalida')
        except Exception as original:
            with self._publicacao_local(original):
                item['erro_observacao'] = True
            return False
        with self._publicacao_local():
            # Revalidar: consulta externa pode coincidir com publicação tardia.
            if (item['thread'] is not thread or not item['partida_resolvida']
                    or not item['entrada'] or not item['retorno'] or item['erro_publicacao']):
                return False
            if viva:
                if item['thread_terminada']:
                    item['erro_observacao'] = True
                return False
            item['thread_terminada'] = True
            return not item['erro_observacao']

    def observar_terminos(self):
        with self._lock:
            identidades = tuple((chave, item['origem'].geracao_id)
                                for chave, item in self._atividades.items())
        return [{'atividade_id': identidade.numero,
                 'geracao_id': geracao,
                 'termino_observado': self.observar_termino(identidade)}
                for identidade, geracao in identidades]

    def obter_retrato(self):
        with self._lock:
            return self._retrato_local()

    def _retrato_local(self):
        atividades = []
        for identidade, item in self._atividades.items():
            confirmado = (item['partida_resolvida'] and not item['partida_em_curso']
                          and not item['erro_publicacao'] and not item['erro_observacao']
                          and (item['ausencia_comprovada'] or (
                              item['entrada'] and item['retorno'] and item['thread_terminada'])))
            origem = item['origem']
            atividades.append({
                'atividade_id': identidade.numero, 'tipo': 'leitor_permanente',
                'geracao_id': origem.geracao_id, 'atividade_recursos_id': origem.atividade_recursos_id,
                **{n: item[n] for n in (
                    'partida_em_curso', 'partida_resolvida', 'start_invocado', 'partida_ambigua',
                    'entrada', 'retorno', 'thread_terminada', 'ausencia_comprovada', 'resultado_alvo',
                    'erro_publicacao', 'erro_observacao')},
                'erro_operacional': None if item['erro_operacional'] is None else item['erro_operacional'].copy(),
                'erro_partida': None if item['erro_partida'] is None else item['erro_partida'].copy(),
                'execucao_em_curso': item['entrada'] and not item['retorno'],
                'termino_confirmado': bool(confirmado),
            })
        return {'aplicacao_id': self._proprietario.aplicacao_id,
                'admissao_fechada': self._fechada, 'atividades': atividades,
                'cobertura_operacional': 'incompleta', 'encerramento_global_confirmado': False}

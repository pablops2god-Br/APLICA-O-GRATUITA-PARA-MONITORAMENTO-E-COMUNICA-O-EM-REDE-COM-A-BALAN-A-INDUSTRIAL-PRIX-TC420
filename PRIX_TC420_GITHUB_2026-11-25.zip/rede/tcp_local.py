"""TCP direto local: sem descoberta, HTTPS, servidor, credenciais ou candidatura."""
import socket
from threading import Event, Lock, Thread
from time import monotonic

from tc420.protocolo import interpretar_peso

TOLERANCIA_LEITURA_TCP = 10.0


class ErroTCPLocal(ConnectionError):
    """Código controlado: nenhuma mensagem de socket/frame é repassada ao Tk."""
    MENSAGENS = {
        'recusada': 'A conexão TCP foi recusada. Confira a porta e o serviço TCP da TC420.',
        'timeout_conexao': 'Tempo esgotado ao abrir TCP. Confira IP, porta e acesso de rede.',
        'rede': 'Não foi possível alcançar a TC420 por TCP. Confira IP e acesso de rede.',
        'encerrada': 'A conexão TCP foi encerrada pelo equipamento.',
        'sem_dados': 'TCP conectado, mas nenhum dado recebido. Verifique se a TC420 envia dados nesta porta.',
        'frame_incompleto': 'TCP recebeu dados, mas não completou o frame esperado de 18 bytes.',
        'formato': 'TCP recebeu dados, mas o formato não corresponde ao leitor legado de 18 bytes.',
        'sem_frame': 'Não foi possível confirmar uma leitura TCP válida.',
        'nao_atual': 'A leitura TCP deixou de estar atual antes de concluir a conexão.',
        'cancelada': 'A tentativa TCP foi cancelada ou o encerramento foi solicitado.',
    }

    def __init__(self, codigo):
        self.codigo = codigo if codigo in self.MENSAGENS else 'sem_frame'
        super().__init__(self.codigo)


class LeitorTCPLocal:
    """Socket retido até close comprovado; leitor/thread acompanhados pela B2."""
    def __init__(self, ip, porta, *, tolerancia=TOLERANCIA_LEITURA_TCP):
        self.ip, self.porta = ip, int(porta)
        if tolerancia <= 0:
            raise ValueError('tolerancia_tcp_invalida')
        self.tolerancia = float(tolerancia)
        self.thread = None
        self.pronto, self.terminou, self.parada = Event(), Event(), Event()
        self._lock = Lock()
        self._socket = None
        self._dados = None
        self._ultimo = None
        self._conectado = False
        self._iniciado = False
        self._abriu = False
        self._bytes = self._rejeitados = self._pendentes = 0
        self._falha = self._erro_sistema = None
        self._validos = 0
        self._intervalo_ultimo = self._intervalo_maximo = None
        self._estado_diagnostico = None
        self._instante_diagnostico = None

    def diagnostico(self):
        with self._lock:
            return dict(abriu=self._abriu, bytes=self._bytes, rejeitados=self._rejeitados,
                        pendentes=self._pendentes, falha=self._falha, erro_sistema=self._erro_sistema,
                        validos=self._validos, intervalo_ultimo_s=self._intervalo_ultimo,
                        intervalo_maximo_s=self._intervalo_maximo, tolerancia_s=self.tolerancia,
                        idade_leitura_s=None if self._ultimo is None else round(monotonic() - self._ultimo, 3))

    def registrar_diagnostico(self, atual):
        """Uma linha na mudança de estado ou a cada 30 s; nunca conteúdo dos frames."""
        agora = monotonic()
        with self._lock:
            emitir = (atual != self._estado_diagnostico or self._instante_diagnostico is None
                      or agora - self._instante_diagnostico >= 30)
            if emitir:
                self._estado_diagnostico, self._instante_diagnostico = atual, agora
        if emitir:
            print('TCP LOCAL: amostra', 'atual' if atual else 'indisponível', self.diagnostico())

    def _publicar_peso(self, peso):
        with self._lock:
            if self.parada.is_set():
                return False
            agora = monotonic()
            if self._ultimo is not None:
                self._intervalo_ultimo = round(agora - self._ultimo, 3)
                self._intervalo_maximo = max(self._intervalo_maximo or 0, self._intervalo_ultimo)
            self._validos += 1
            self._dados = dict(peso_liquido=str(peso), peso_bruto=str(peso),
                               tara='—', estado='TCP', unidade='kg', multirange='—')
            self._ultimo, self._conectado = agora, True
        self.pronto.set()
        return True

    def erro_leitura(self):
        d = self.diagnostico()
        if d['falha']:
            return ErroTCPLocal(d['falha'])
        if d['abriu'] and not d['bytes']:
            return ErroTCPLocal('sem_dados')
        if d['rejeitados']:
            return ErroTCPLocal('formato')
        return ErroTCPLocal('frame_incompleto' if d['pendentes'] else 'sem_frame')

    def iniciar(self, saida):
        with self._lock:
            if self._iniciado:
                raise RuntimeError('leitor_tcp_ja_iniciado')
            self._iniciado = True
        saida.acompanhar_leitor(self)
        self.thread = Thread(target=self._executar, daemon=True, name='TC420-TCP-local')
        if not saida.iniciar_thread(self.thread):
            self.parar()
            return False
        return True

    def _executar(self):
        try:
            with self._lock:
                if self.parada.is_set():
                    return
                self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock = self._socket
            sock.settimeout(5)
            print('TCP LOCAL: abrindo conexão; porta', self.porta)
            sock.connect((self.ip, self.porta))
            with self._lock:
                self._abriu = True
            print('TCP LOCAL: socket conectado; aguardando frame válido de 18 bytes.')
            sock.settimeout(0.5)
            buffer = bytearray()
            while not self.parada.is_set():
                try:
                    bloco = sock.recv(1024)
                except socket.timeout:
                    continue
                if not bloco:
                    with self._lock:
                        self._falha = 'encerrada'
                    if not self.parada.is_set():
                        print('TCP LOCAL: conexão encerrada pelo equipamento.')
                    break
                buffer.extend(bloco)
                with self._lock:
                    self._bytes += len(bloco)
                    self._pendentes = len(buffer) % 18
                while len(buffer) >= 18:
                    frame = bytes(buffer[:18])
                    del buffer[:18]
                    try:
                        peso = interpretar_peso(frame)
                    except ValueError:
                        with self._lock:
                            self._rejeitados += 1
                        continue
                    if not self._publicar_peso(peso):
                        return
        except Exception as erro:
            if not self.parada.is_set():
                codigo = ('recusada' if isinstance(erro, ConnectionRefusedError) else
                          'timeout_conexao' if isinstance(erro, TimeoutError) else
                          'encerrada' if isinstance(erro, ConnectionResetError) else 'rede')
                numero = getattr(erro, 'winerror', None) or getattr(erro, 'errno', None)
                with self._lock:
                    self._falha = codigo
                    self._erro_sistema = numero if type(numero) is int else None
                print('TCP LOCAL: comunicação encerrada:', type(erro).__name__)
        finally:
            with self._lock:
                self._conectado = False
            try:
                self._fechar_socket()
            except Exception as erro:
                # Referência preservada para parada/retentativa explícita da B2.
                print('TCP LOCAL: limpeza pendente:', type(erro).__name__)
            finally:
                self.terminou.set()

    def _fechar_socket(self):
        with self._lock:
            sock = self._socket
            if sock is not None:
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass  # Não conectado/encerrado; close continua obrigatório.
                sock.close()
                if sock.fileno() != -1:
                    raise OSError('socket_nao_encerrado')
                self._socket = None

    def parar(self):
        with self._lock:
            self.parada.set()
            self._conectado = False
        self._fechar_socket()

    def comunicacao_esta_atual(self):
        with self._lock:
            return bool(self._conectado and self._ultimo is not None
                        and monotonic() - self._ultimo <= self.tolerancia and not self.parada.is_set())

    def obter_dados_atuais(self):
        with self._lock:
            return dict(self._dados) if self._dados is not None else {}


def conectar_local(ip, porta, saida, infraestrutura=None, supervisao=None, prazo=8):
    """Worker: primeiro frame válido; troca de fonte exige responsabilidades resolvidas."""
    from rede.promocao_manual import operacao_vigente, cliente_resolvido
    leitor, sucesso = None, False
    try:
        with saida.promocao():
            if not saida.ciclos_aptos_promocao() or not operacao_vigente(saida):
                raise RuntimeError('ciclo_anterior_pendente')
            with saida._lock:
                anteriores = tuple(saida._leitores)
            leitor = LeitorTCPLocal(ip, porta)
            if not leitor.iniciar(saida):
                raise RuntimeError('saida_em_curso')
            limite = monotonic() + prazo
            while not leitor.pronto.wait(0.05):
                if not operacao_vigente(saida):
                    raise ErroTCPLocal('cancelada')
                if leitor.terminou.is_set() or monotonic() >= limite:
                    raise leitor.erro_leitura()
            if not leitor.comunicacao_esta_atual() or not operacao_vigente(saida):
                raise ErroTCPLocal('nao_atual')
            # Falha antes deste ponto mantém o CLIENTE anterior em operação.
            for anterior in anteriores:
                anterior.parar()
            limite = monotonic() + 8
            for anterior in anteriores:
                thread = getattr(anterior, 'thread', None)
                if thread is not None:
                    thread.join(max(0, limite - monotonic()))
                    if thread.is_alive():
                        raise RuntimeError('leitor_anterior_pendente')
            if infraestrutura is not None and not cliente_resolvido(infraestrutura):
                raise RuntimeError('responsabilidades_cliente_pendentes')
            if not saida.ciclos_aptos_promocao() or not operacao_vigente(saida):
                raise RuntimeError('encerramento_pendente')
            if not leitor.comunicacao_esta_atual():
                raise ErroTCPLocal('nao_atual')
            if supervisao is not None:
                supervisao.cancelar()
            sucesso = True
            print('TCP LOCAL: leitura válida; modo local, sem servidor ou sucessão.')
            return leitor
    except ErroTCPLocal as erro:
        print('TCP LOCAL:', ErroTCPLocal.MENSAGENS[erro.codigo])
        if leitor is not None:
            print('TCP LOCAL: diagnóstico:', leitor.diagnostico())
        raise
    finally:
        if leitor is not None and not sucesso:
            leitor.parar()
            if supervisao is not None and supervisao.vigente():
                supervisao.solicitar_retomada()

# Retentativas: acompanha partidas, execução e observação de término das threads de recuperação.
"""Partida e observação explícita da espera de recuperação, sem cleanup global."""
from threading import Lock
from contextvars import ContextVar


class _ThreadPartida:
    def __init__(self, thread, invocacao):
        self._thread, self._invocacao = thread, invocacao

    def start(self):
        # Marcar antes da chamada: exceção de start nunca comprova ausência.
        self._invocacao.append(True)
        return self._thread.start()

    def is_alive(self):
        return self._thread.is_alive()


class PartidasRetentativasCliente:
    def __init__(self, infraestrutura, geracao):
        # Captura o proprietário e a guarda originais, não a geração "atual".
        self._proprietario = infraestrutura
        self._guarda = infraestrutura.registro_retentativas
        self._geracao = geracao
        self._lock = Lock()
        self._identidades = []
        self._execucao = ContextVar("retentativa_em_execucao", default=None)
        self._escopos = {}
        infraestrutura._reter_acompanhamento_retentativas(self)

    def admitir(self):
        identidade = self._guarda.reservar_retentativa(self._geracao)
        if identidade is not None:
            try:
                with self._lock:
                    self._identidades.append(identidade)
                    self._escopos[identidade] = {"em_curso": False, "encerrada": False, "recursos": None,
                                                 "caminho_auditado": False}
            except BaseException as original:
                try:
                    self._guarda.comprovar_nao_execucao(identidade, ausencia_comprovada=True)
                except BaseException as diagnostico:
                    original.__cause__ = diagnostico
                    original.__suppress_context__ = True
                raise
        return identidade

    def execucao_em_curso(self, identidade):
        with self._lock:
            return self._execucao.get() is identidade and self._escopos[identidade]["em_curso"]

    def recursos_da_execucao(self, origem, *, caminho=None):
        identidade = self._execucao.get()
        if identidade is None:
            return origem  # Chamada isolada não alega vínculo com uma retry.
        if caminho not in (None, "espera_recuperacao_descoberta"):
            raise ValueError("caminho_retentativa_nao_auditado")
        recursos = self.recursos_da_retentativa(identidade, origem)
        if caminho is not None:
            with self._lock:
                self._escopos[identidade]["caminho_auditado"] = True
        return recursos

    def recursos_da_retentativa(self, identidade, origem):
        from rede.associacoes_retentativas import RecursosRetentativaCliente
        with self._lock:
            if not any(identidade is item for item in self._identidades):
                raise ValueError("retentativa_estrangeira")
            if (origem.registro is not self._proprietario.registro_recursos
                    or origem._geracao_retentativas is not self._geracao):
                raise ValueError("origem_recurso_estrangeira")
            escopo = self._escopos[identidade]
            if not escopo["em_curso"]:
                raise RuntimeError("retentativa_fora_de_execucao")
            if escopo["recursos"] is None:
                escopo["recursos"] = RecursosRetentativaCliente(self, identidade, origem)
            return escopo["recursos"]

    def obter_associacoes(self):
        with self._lock:
            escopos = [(token, item.copy()) for token, item in self._escopos.items()]
        resultados = []
        for token, item in escopos:
            erro, vinculos = (False, []) if item["recursos"] is None else item["recursos"].obter_vinculos()
            resultados.append({"aplicacao_id": self._proprietario.aplicacao_id,
                               "geracao_id": self._geracao.numero, "retentativa_id": token.numero,
                               "execucao_em_curso": item["em_curso"],
                               "cobertura_recursos_completa": item["encerrada"] and item["caminho_auditado"] and not erro,
                               "evidencia_cobertura": "espera_recuperacao_descoberta" if item["caminho_auditado"] else None,
                               "erro_associacao": erro, "recursos": vinculos,
                               "checks": [] if item["recursos"] is None else
                                   item["recursos"]._admissao_checks.obter_retrato()})
        return resultados

    def observar_terminos(self):
        with self._lock:
            identidades = tuple(self._identidades)
        resultados = []
        for identidade in identidades:
            comprovado = self._guarda.observar_termino_thread(identidade)
            resultados.append({"retentativa_id": identidade.numero,
                               "geracao_id": self._geracao.numero,
                               "termino_observado": comprovado})
        return resultados

    def partir(self, identidade, construir, rotina):
        invocacao = []
        def fabrica(alvo):
            return _ThreadPartida(construir(alvo), invocacao)
        def executar():
            contexto = self._execucao.set(identidade)
            with self._lock:
                self._escopos[identidade]["em_curso"] = True
            try:
                return rotina()
            finally:
                with self._lock:
                    self._escopos[identidade]["em_curso"] = False
                    self._escopos[identidade]["encerrada"] = True
                self._execucao.reset(contexto)
        try:
            return self._guarda.partir(identidade, fabrica, executar)
        except BaseException as original:
            if not invocacao:
                # Fábrica síncrona abortou e o alvo não foi entregue a start.
                # Não se consulta is_alive nem se usa essa prova após start.
                try:
                    self._guarda.comprovar_nao_execucao(identidade, ausencia_comprovada=True)
                except BaseException as diagnostico:
                    original.__cause__ = diagnostico
                    original.__suppress_context__ = True
            raise

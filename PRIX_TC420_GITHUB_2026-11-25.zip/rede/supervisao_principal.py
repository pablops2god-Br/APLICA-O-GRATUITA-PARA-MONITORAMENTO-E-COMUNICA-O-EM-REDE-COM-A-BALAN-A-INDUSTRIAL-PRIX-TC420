"""Supervisão de um ciclo PRINCIPAL, sem acesso ao Tk nem posse de outro ciclo."""
from threading import Event, Lock, Thread

from rede.lerdadosserver import LeitorDadosServidor
from rede.servidor import avaliar_encerramento_tentativa


class SupervisaoPrincipal:
    """Retorno do coordenador inicia a avaliação; só prova B2 permite rebaixar.

    O worker permanece acompanhado até cancelamento ou saída da aplicação para
    que um leitor publicado também receba parada se a janela trocar de ciclo.
    """

    def __init__(self, contexto, saida, infraestrutura=None, *, intervalo=0.1):
        self.contexto = contexto
        self.saida = saida
        self.infraestrutura = infraestrutura
        self.pronto = Event()
        self.cancelada = Event()
        self.terminou = Event()
        self._lock = Lock()
        self._leitor = None
        self._iniciada = False
        self._intervalo = intervalo
        self.thread = None
        self._retomar = Event()

    def solicitar_retomada(self):
        self._retomar.set()

    def obter_leitor(self):
        with self._lock:
            return self._leitor

    def cancelar(self):
        # Somente sinalização local: parada/limpeza do leitor fica no worker.
        self.cancelada.set()

    def vigente(self):
        return not self.cancelada.is_set() and not self.saida.parada_solicitada

    def iniciar(self):
        with self._lock:
            if self._iniciada:
                return False
            self._iniciada = True
            self.thread = Thread(target=self._executar, daemon=True)
        try:
            if not self.saida.iniciar_thread(self.thread):
                self.cancelar()
                self.terminou.set()
                return False
        except BaseException:
            # A B2 conserva a partida ambígua. Cancelar não inventa prova de término.
            self.cancelar()
            raise
        return True

    def _esperar(self):
        self.cancelada.wait(self._intervalo)

    def _executar(self):
        leitor = None
        try:
            while self.vigente():
                situacao = self.contexto.obter_situacao()
                if situacao['reserva_resolvida'] and situacao['ciclo_id'] is None:
                    return  # Tentativa sem ciclo não representa abandono de PRINCIPAL.
                if (situacao['coordenador_retornou']
                        and avaliar_encerramento_tentativa(self.contexto)['encerramento_confirmado'] is True):
                    break
                self._esperar()
            if not self.vigente():
                return

            try:
                with self.saida.trabalho():
                    if not self.vigente():
                        return
                    leitor = LeitorDadosServidor(
                        permitir_candidatura=False,
                        **({'infraestrutura_cliente': self.infraestrutura}
                           if self.infraestrutura is not None else {}))
                    self.saida.acompanhar_leitor(leitor)
                    leitor.preparar_sucessao_recuperada(
                        lambda: self.vigente() and self.saida.ciclos_aptos_promocao())
                    if not self.vigente():
                        return
                    leitor.iniciar()
                    if not self.vigente():
                        return
                    with self._lock:
                        self._leitor = leitor
                    self.pronto.set()
            except RuntimeError:
                if self.vigente():
                    raise
                return  # Saída voluntária venceu a admissão da recuperação.

            # Após REGISTER/amostra/prova, o leitor volta à fila na perda seguinte.
            # Uma tentativa recusada pode pedir retomada
            # com nova geração, somente depois de resolver os ciclos conhecidos.
            while self.vigente():
                if self._retomar.is_set():
                    if leitor.executando:
                        self._retomar.clear()
                    elif self.saida.ciclos_aptos_promocao():
                        from rede.promocao_manual import cliente_resolvido
                        if self.infraestrutura is not None and not cliente_resolvido(self.infraestrutura):
                            self._esperar()
                            continue
                        try:
                            # A retomada não pode vencer uma promoção manual em curso.
                            with self.saida.promocao():
                                if not self.vigente():
                                    return
                                novo = LeitorDadosServidor(
                                    permitir_candidatura=False,
                                    **({'infraestrutura_cliente': self.infraestrutura}
                                       if self.infraestrutura is not None else {}))
                                self.saida.acompanhar_leitor(novo)
                                novo.preparar_sucessao_recuperada(
                                    lambda: self.vigente() and self.saida.ciclos_aptos_promocao())
                                leitor = novo
                                leitor.iniciar()
                                with self._lock:
                                    self._leitor = leitor
                                self._retomar.clear()
                        except RuntimeError:
                            if not self.vigente():
                                return
                            # Gate ocupado/pendente: mantém o pedido para reavaliação.
                self._esperar()
        except Exception as erro:
            print('SUPERVISAO: falha no acompanhamento:', type(erro).__name__)
        finally:
            try:
                if leitor is not None:
                    leitor.parar()
            finally:
                self.terminou.set()
